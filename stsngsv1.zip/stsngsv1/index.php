<?php
session_start();

// 1. Check if logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// 2. SECURITY CHECK:
// If the user HAS a reference_id, they are a TEACHER. 
// Kick them out to the Teacher Dashboard.
if (!empty($_SESSION['reference_id'])) {
    header("Location: teacher-dashboard.php");
    exit;
}

// If code reaches here, it means reference_id is empty, so they are an ADMIN.
?>
<!doctype html>
<!doctype html>
<html lang="en">
  <!--begin::Head-->
 <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>STSN Grading System | Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
    <meta name="color-scheme" content="light dark" />
    <meta name="theme-color" content="#007bff" media="(prefers-color-scheme: light)" />
    <meta name="theme-color" content="#1a1a1a" media="(prefers-color-scheme: dark)" />
    <meta name="title" content="STSN | Dashboard" />
    <meta name="author" content="G" />
    <meta
    name="description"
    content="STSN Grading System - A modern and accessible Bootstrap 5-based grading and student management platform for Schools. Secure, fast, and WCAG 2.1 AA compliant."
    />
    <meta
    name="keywords"
    content="STSN, STSN Grading System, school grading system, student information system, bootstrap 5 admin dashboard, grading dashboard, student records, class management, teacher tools, accessible admin panel"
    />


    <meta name="supported-color-schemes" content="light dark" />
    <link rel="preload" href="./css/adminlte.css" as="style" />

    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
      integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q="
      crossorigin="anonymous"
      media="print"
      onload="this.media='all'"
    />
 
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
      crossorigin="anonymous"
    />
  
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
      crossorigin="anonymous"
    />
    <!--end::Third Party Plugin(Bootstrap Icons)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <link rel="stylesheet" href="./css/adminlte.css" />
    <!--end::Required Plugin(AdminLTE)-->

  </head>
  <body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">
    <!--begin::App Wrapper-->
    <div class="app-wrapper">
      <?php
        require_once("includes/header.php");
        require_once("includes/sidebar.php");
      ?>

      <!--begin::App Main-->
      <main class="app-main">
        <!--begin::App Content Header-->
        <div class="app-content-header">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-sm-6"><h3 class="mb-0">Dashboard</h3></div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Dashboard v2</li>
                </ol>
              </div>
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <div class="app-content">
          <div class="container-fluid">

            <!-- 1.  Top info boxes  -->
            <div class="row">
              <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box">
                  <span class="info-box-icon text-bg-primary shadow-sm">
                    <i class="bi bi-mortarboard-fill"></i>
                  </span>
                  <div class="info-box-content">
                    <span class="info-box-text">Teachers</span>
                    <span class="info-box-number">41</span>
                  </div>
                </div>
              </div>

              <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box">
                  <span class="info-box-icon text-bg-success shadow-sm">
                    <i class="bi bi-people-fill"></i>
                  </span>
                  <div class="info-box-content">
                    <span class="info-box-text">Students</span>
                    <span class="info-box-number">2 000</span>
                  </div>
                </div>
              </div>

              <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box">
                  <span class="info-box-icon text-bg-warning shadow-sm">
                    <i class="bi bi-book-half"></i>
                  </span>
                  <div class="info-box-content">
                    <span class="info-box-text">Subjects</span>
                    <span class="info-box-number">76</span>
                  </div>
                </div>
              </div>

              <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box">
                  <span class="info-box-icon text-bg-danger shadow-sm">
                    <i class="bi bi-clipboard-data-fill"></i>
                  </span>
                  <div class="info-box-content">
                    <span class="info-box-text">Sections</span>
                    <span class="info-box-number">120</span>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.row -->

            <!-- 2.  Monthly academic recap (kept for trend) -->
            <div class="row">
              <div class="col-md-12">
                <div class="card mb-4">
                  <div class="card-header">
                    <h5 class="card-title">Monthly Academic Recap</h5>
                    <div class="card-tools">
                      <button type="button" class="btn btn-tool" data-lte-toggle="card-collapse">
                        <i class="bi bi-dash-lg"></i>
                      </button>
                    </div>
                  </div>
                  <div class="card-body">
                    <div class="row">
                      <div class="col-md-8">
                        <p class="text-center"><strong>Enrollment: 1 Jan 2023 – 30 Jul 2023</strong></p>
                        <div id="enrolment-chart"></div>
                      </div>
                      <div class="col-md-4">
                        <p class="text-center"><strong>Goal Completion</strong></p>

                        <div class="progress-group">
                          Curriculum Uploaded
                          <span class="float-end"><b>160</b>/200</span>
                          <div class="progress progress-sm">
                            <div class="progress-bar bg-primary" style="width: 80%"></div>
                          </div>
                        </div>

                        <div class="progress-group">
                          Grades Finalised
                          <span class="float-end"><b>310</b>/400</span>
                          <div class="progress progress-sm">
                            <div class="progress-bar bg-danger" style="width: 75%"></div>
                          </div>
                        </div>

                        <div class="progress-group">
                          Attendance >90 %
                          <span class="float-end"><b>480</b>/800</span>
                          <div class="progress progress-sm">
                            <div class="progress-bar bg-success" style="width: 60%"></div>
                          </div>
                        </div>

                        <div class="progress-group">
                          Parent Feedback
                          <span class="float-end"><b>250</b>/500</span>
                          <div class="progress progress-sm">
                            <div class="progress-bar bg-warning" style="width: 50%"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- /.card-body -->

                </div>
                <!-- /.card -->
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
          </div>
        <!--end::Container-->
      </div>
        <!--end::App Content-->
      </main>
      <!--end::App Main-->
      <?php
        require_once("includes/footer.php");
      ?>
    </div>
    <!--end::App Wrapper-->
    <!--begin::Script-->
    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <script
      src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
      crossorigin="anonymous"
    ></script>
    <!--end::Third Party Plugin(OverlayScrollbars)--><!--begin::Required Plugin(popperjs for Bootstrap 5)-->
    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
      crossorigin="anonymous"
    ></script>
    <!--end::Required Plugin(popperjs for Bootstrap 5)--><!--begin::Required Plugin(Bootstrap 5)-->
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js"
      crossorigin="anonymous"
    ></script>
    <!--end::Required Plugin(Bootstrap 5)--><!--begin::Required Plugin(AdminLTE)-->
    <script src="./js/adminlte.js"></script>
    <!--end::Required Plugin(AdminLTE)--><!--begin::OverlayScrollbars Configure-->
    <script>
      const SELECTOR_SIDEBAR_WRAPPER = '.sidebar-wrapper';
      const Default = {
        scrollbarTheme: 'os-theme-light',
        scrollbarAutoHide: 'leave',
        scrollbarClickScroll: true,
      };
      document.addEventListener('DOMContentLoaded', function () {
        const sidebarWrapper = document.querySelector(SELECTOR_SIDEBAR_WRAPPER);
        if (sidebarWrapper && OverlayScrollbarsGlobal?.OverlayScrollbars !== undefined) {
          OverlayScrollbarsGlobal.OverlayScrollbars(sidebarWrapper, {
            scrollbars: {
              theme: Default.scrollbarTheme,
              autoHide: Default.scrollbarAutoHide,
              clickScroll: Default.scrollbarClickScroll,
            },
          });
        }
      });
    </script>
    <!--end::OverlayScrollbars Configure-->
    <!-- OPTIONAL SCRIPTS -->
    <!-- apexcharts -->
    <script src="https://cdn.jsdelivr.net/npm/apexcharts@3.37.1/dist/apexcharts.min.js"></script>

    <script>
      /* ---- enrolment trend (single line) ---- */
      const enrolment_options = {
        series: [{
          name: 'Active Students',
          data: [1850, 1920, 1950, 1970, 2000, 1990, 2010]
        }],
        chart: {
          height: 180,
          type: 'area',
          toolbar: { show: false }
        },
        colors: ['#0d6efd'],
        stroke: { curve: 'smooth' },
        xaxis: {
          type: 'datetime',
          categories: [
            '2023-01-01','2023-02-01','2023-03-01','2023-04-01',
            '2023-05-01','2023-06-01','2023-07-01'
          ]
        },
        tooltip: { x: { format: 'MMMM yyyy' } }
      };
      new ApexCharts(document.querySelector('#enrolment-chart'), enrolment_options).render();
    </script>
      <!--end::Script-->
  </body>
  <!--end::Body-->
</html>
