<?php
require_once 'api/shared/db_connect.php';

$id = $_GET['id'] ?? null;
$teacher = null;
if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM tblTeacher WHERE id = ? AND is_active = 1");
    $stmt->execute([$id]);
    $teacher = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$teacher) { header("Location: teacher.php"); exit; }
}


/* DROP DOWN  */
$countries = $pdo->query('SELECT id, country_name   FROM tblCountry   ORDER BY country_name')->fetchAll(PDO::FETCH_ASSOC);
$regions   = $pdo->query('SELECT id, region_name, country_id FROM tblRegion   ORDER BY region_name')->fetchAll(PDO::FETCH_ASSOC);
$provinces = $pdo->query('SELECT id, province_name, region_id FROM tblProvince ORDER BY province_name')->fetchAll(PDO::FETCH_ASSOC);
$cities    = $pdo->query('SELECT id, city_name, province_id FROM tblCity     ORDER BY city_name')->fetchAll(PDO::FETCH_ASSOC);
$barangays = $pdo->query('SELECT id, barangay_name, city_id FROM tblBarangay ORDER BY barangay_name')->fetchAll(PDO::FETCH_ASSOC);

$oldCountry  = $old['country_id']  ?? '';
$oldRegion   = $old['region_id']   ?? '';
$oldProvince = $old['province_id'] ?? '';
$oldCity     = $old['city_id']     ?? '';
$oldBarangay = $old['barangay_id'] ?? '';
?>
<!doctype html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>STSN Grading System | Teacher</title>
    <!--begin::Accessibility Meta Tags-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
    <meta name="color-scheme" content="light dark" />
    <meta name="theme-color" content="#007bff" media="(prefers-color-scheme: light)" />
    <meta name="theme-color" content="#1a1a1a" media="(prefers-color-scheme: dark)" />
    <!--end::Accessibility Meta Tags-->
    <!--begin::Primary Meta Tags-->
    <meta name="title" content="AdminLTE | Dashboard v2" />
    <meta name="author" content="ColorlibHQ" />
    <meta
      name="description"
      content="AdminLTE is a Free Bootstrap 5 Admin Dashboard, 30 example pages using Vanilla JS. Fully accessible with WCAG 2.1 AA compliance."
    />
    <meta
      name="keywords"
      content="bootstrap 5, bootstrap, bootstrap 5 admin dashboard, bootstrap 5 dashboard, bootstrap 5 charts, bootstrap 5 calendar, bootstrap 5 datepicker, bootstrap 5 tables, bootstrap 5 datatable, vanilla js datatable, colorlibhq, colorlibhq dashboard, colorlibhq admin dashboard, accessible admin panel, WCAG compliant"
    />
    <meta name="supported-color-schemes" content="light dark" />
    <link rel="preload" href="./css/adminlte.css" as="style" />

    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css "
      integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q="
      crossorigin="anonymous"
      media="print"
      onload="this.media='all'"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css "
      crossorigin="anonymous"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css "
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="./css/adminlte.css" />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/apexcharts@3.37.1/dist/apexcharts.css "
      integrity="sha256-4MX+61mt9NVvvuPjUWdUdyfZfxSB1/Rf9WtqRHgG5S0="
      crossorigin="anonymous"
    />
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content-header">
        <div class="container-fluid">
            <div class="row">
            <div class="col-sm-6"><h3><i class="bi bi-person-workspace"></i> <?=$id?'Edit':'Add'?> Teacher</h3></div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="teacher.php">Teachers</a></li>
                <li class="breadcrumb-item active"><?=$id?'Edit':'Add'?></li>
                </ol>
            </div>
            </div>
        </div>
        </div>

        <div class="card m-3">
            <div class="card-header"><h5 class="mb-0">Teacher Information</h5></div>
            <form method="post" action="api/teacher/save.php" class="needs-validation" novalidate>
                <input type="hidden" name="id" value="<?= $id ?>">

                <!-- =====  ALERT AREA  ===== -->
                <?php if (isset($_GET['duplicate'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show m-3" role="alert">
                    <i class="bi bi-exclamation-triangle me-2"></i>Teacher ID already exists!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                <?php if (isset($_GET['duplicate'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show m-3" role="alert">
                        <i class="bi bi-exclamation-triangle me-2"></i>Teacher ID already exists!
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                <!-- END ALERT -->

                <div class="row g-4 m-3">
                    <!-- ==========  PERSONAL INFO CARD  ========== -->
                    <div class="col-md-6">
                    <div class="card card-danger card-outline">
                        <div class="card-header">
                        <h3 class="card-title"><i class="bi bi-person"></i> Personal Info</h3>
                        </div>
                        <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                            <label>Teacher ID <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="teacher_id" required
                                    value="<?= htmlspecialchars($teacher['teacher_id'] ?? '') ?>">
                            </div>
                            <div class="col-md-6">
                            <label>Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" name="email" required
                                    value="<?= htmlspecialchars($teacher['email'] ?? '') ?>">
                            </div>

                            <div class="col-md-4">
                            <label>First Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="fname" required
                                    value="<?= htmlspecialchars($teacher['fname'] ?? '') ?>">
                            </div>
                            <div class="col-md-4">
                            <label>Middle Name</label>
                            <input type="text" class="form-control" name="mname"
                                    value="<?= htmlspecialchars($teacher['mname'] ?? '') ?>">
                            </div>
                            <div class="col-md-4">
                            <label>Last Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="lname" required
                                    value="<?= htmlspecialchars($teacher['lname'] ?? '') ?>">
                            </div>

                            <div class="col-md-4">
                            <label>Birth-date <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" name="date_of_birth" required
                                    value="<?= $teacher['date_of_birth'] ?? '' ?>">
                            </div>
                            <div class="col-md-4">
                            <label>Gender <span class="text-danger">*</span></label>
                            <select class="form-select" name="gender" required>
                                <option value="">Select</option>
                                <option <?= ($teacher['gender'] ?? '') === 'Male' ? 'selected' : '' ?>>Male</option>
                                <option <?= ($teacher['gender'] ?? '') === 'Female' ? 'selected' : '' ?>>Female</option>
                                <option <?= ($teacher['gender'] ?? '') === 'Other' ? 'selected' : '' ?>>Other</option>
                            </select>
                            </div>
                            <div class="col-md-4">
                            <label>Civil Status <span class="text-danger">*</span></label>
                            <select class="form-select" name="civil_status" required>
                                <option value="">Select</option>
                                <?php foreach(['Single','Married','Widowed','Divorced'] as $c): ?>
                                <option <?= ($teacher['civil_status'] ?? '') === $c ? 'selected' : '' ?>><?= $c ?></option>
                                <?php endforeach; ?>
                            </select>
                            </div>

                            <div class="col-md-6">
                            <label>Contact Number <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="contact_number" required
                                    value="<?= htmlspecialchars($teacher['contact_number'] ?? '') ?>">
                            </div>
                        </div>
                        </div>
                    </div>
                    </div><!-- PERSONAL -->

                    <!-- ==========  ADDRESS INFO CARD  ========== -->
                    <div class="col-md-6">
                        <div class="card card-dark card-outline">
                          <div class="card-header">
                              <h3 class="card-title"><i class="bi bi-geo-alt"></i> Address Info</h3>
                          </div>

                          <div class="card-body">
                              <div class="row g-3">

                              <div class="col-md-12">
                                  <label>Street / House No. <span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" name="street_name" required
                                  value="<?= htmlspecialchars($old['street_name'] ?? '') ?>">
                              </div>

                              <div class="col-md-6">
                                  <label>Country <span class="text-danger">*</span></label>
                                  <select class="form-select" id="country" name="country_id" required>
                                  <option value="">Select Country</option>
                                  <?php foreach ($countries as $c): ?>
                                      <option value="<?= $c['id'] ?>" <?= ($oldCountry == $c['id']) ? 'selected' : '' ?>>
                                      <?= htmlspecialchars($c['country_name']) ?>
                                      </option>
                                  <?php endforeach; ?>
                                  </select>
                              </div>

                              <div class="col-md-6">
                                  <label>Region <span class="text-danger">*</span></label>
                                  <select class="form-select" id="region" name="region_id" required>
                                  <option value="">Select Region</option>
                                  </select>
                              </div>

                              <div class="col-md-6">
                                  <label>Province <span class="text-danger">*</span></label>
                                  <select class="form-select" id="province" name="province_id" required>
                                  <option value="">Select Province</option>
                                  </select>
                              </div>

                              <div class="col-md-6">
                                  <label>City / Municipality <span class="text-danger">*</span></label>
                                  <select class="form-select" id="city" name="city_id" required>
                                  <option value="">Select City</option>
                                  </select>
                              </div>

                              <div class="col-md-6">
                                  <label>Barangay <span class="text-danger">*</span></label>
                                  <select class="form-select" id="barangay" name="barangay_id" required>
                                  <option value="">Select Barangay</option>
                                  </select>
                              </div>

                              <div class="col-md-6">
                                  <label>Postal Code</label>
                                  <input type="text" class="form-control" name="postal_code"
                                  value="<?= htmlspecialchars($old['postal_code'] ?? '') ?>">
                              </div>

                              </div>
                          </div>
                        </div>
                      </div><!--ADDRESS -->
                </div><!-- /row -->

                <!-- BUTTONS -->
                <div class="text-end m-3">
                    <a href="teacher.php" class="btn btn-danger">Cancel</a>
                    <button type="submit" class="btn btn-info">
                    <i class="bi bi-save"></i> <?= $id ? "Update" : "Save" ?>
                    </button>
                </div>
            </form>
        </div>
    </main>
    <?php require_once("includes/footer.php"); ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./js/adminlte.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
     <script>
    (() => {
      const form = document.querySelector('.needs-validation');
      if (!form) return;
      const alertBox = document.createElement('div');
      alertBox.className = 'alert alert-danger alert-dismissible fade show d-none';
      alertBox.innerHTML = `<i class="bi bi-exclamation-triangle me-2"></i>
                            <span class="fw-bold">Please fill in the following fields:</span>
                            <ul class="mb-0 mt-1"></ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
      form.prepend(alertBox);

      form.addEventListener('submit', e => {
        const missing = [...form.querySelectorAll('[required]')]
                        .filter(el => !el.value.trim())
                        .map(el => el.closest('.col-md-4, .col-md-6, .col-md-12')  
                                      ?.querySelector('label')?.textContent.replace('*','').trim() || el.name);

        if (missing.length) {
          e.preventDefault();                 
          alertBox.querySelector('ul').innerHTML = missing.map(m => `<li>${m}</li>`).join('');
          alertBox.classList.remove('d-none');
          alertBox.scrollIntoView({behavior:'smooth', block:'center'});
        }
      });
    })();
    </script>
     <script>
      /* chained selects (unchanged)*/
      const regions   = <?= json_encode($regions) ?>;
      const provinces = <?= json_encode($provinces) ?>;
      const cities    = <?= json_encode($cities) ?>;
      const barangays = <?= json_encode($barangays) ?>;

      document.addEventListener('DOMContentLoaded', () => {
      const country  = document.getElementById('country');
      const region   = document.getElementById('region');
      const province = document.getElementById('province');
      const city     = document.getElementById('city');
      const barangay = document.getElementById('barangay');

      function fillSelect(select, list, nameField, firstText, preSel = null) {
          const keep = select.value;
          select.innerHTML = `<option value="">${firstText}</option>`;
          list.forEach(item => {
          const opt = document.createElement('option');
          opt.value = item.id;
          opt.text  = item[nameField];
          if (opt.value == keep || opt.value == preSel) opt.selected = true;
          select.appendChild(opt);
          });
      }

      if (+country.value) {
          fillSelect(region, regions.filter(r => r.country_id == country.value), 'region_name', 'Select Region', '<?= $oldRegion ?>');
          if (+region.value)   fillSelect(province, provinces.filter(p => p.region_id == region.value), 'province_name', 'Select Province', '<?= $oldProvince ?>');
          if (+province.value) fillSelect(city, cities.filter(c => c.province_id == province.value), 'city_name', 'Select City', '<?= $oldCity ?>');
          if (+city.value)     fillSelect(barangay, barangays.filter(b => b.city_id == city.value), 'barangay_name', 'Select Barangay', '<?= $oldBarangay ?>');
      }

      country.addEventListener('change', () => {
          fillSelect(region, regions.filter(r => r.country_id == country.value), 'region_name', 'Select Region');
          province.innerHTML = city.innerHTML = barangay.innerHTML = '<option value="">Select...</option>';
      });
      region.addEventListener('change', () => {
          fillSelect(province, provinces.filter(p => p.region_id == region.value), 'province_name', 'Select Province');
          city.innerHTML = barangay.innerHTML = '<option value="">Select...</option>';
      });
      province.addEventListener('change', () => {
          fillSelect(city, cities.filter(c => c.province_id == province.value), 'city_name', 'Select City');
          barangay.innerHTML = '<option value="">Select...</option>';
      });
      city.addEventListener('change', () => {
          fillSelect(barangay, barangays.filter(b => b.city_id == city.value), 'barangay_name', 'Select Barangay');
      });
      });
    </script>
</body>
</html>