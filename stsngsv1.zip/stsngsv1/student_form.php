<?php
require_once __DIR__ . '/api/shared/db_connect.php';  
$id   = isset($_GET['id'])   ? (int)$_GET['id']   : 0;
$edit = ($id > 0);

if ($edit) {                    
    $stmt = $pdo->prepare('SELECT * FROM vwStudentInfo WHERE id = ? AND is_active = 1');
    $stmt->execute([$id]);
    $old  = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$old) {                   
        header('Location: student.php?error=Not found');
        exit;
    }
} else {                         
    $old = [];
}

/* DROP DOWN  */
$grades    = $pdo->query('SELECT id, grade_level_name FROM tblGradeLevel ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
$countries = $pdo->query('SELECT id, country_name   FROM tblCountry   ORDER BY country_name')->fetchAll(PDO::FETCH_ASSOC);
$regions   = $pdo->query('SELECT id, region_name, country_id FROM tblRegion   ORDER BY region_name')->fetchAll(PDO::FETCH_ASSOC);
$provinces = $pdo->query('SELECT id, province_name, region_id FROM tblProvince ORDER BY province_name')->fetchAll(PDO::FETCH_ASSOC);
$cities    = $pdo->query('SELECT id, city_name, province_id FROM tblCity     ORDER BY city_name')->fetchAll(PDO::FETCH_ASSOC);
$barangays = $pdo->query('SELECT id, barangay_name, city_id FROM tblBarangay ORDER BY barangay_name')->fetchAll(PDO::FETCH_ASSOC);

$oldCountry  = $old['country_id']  ?? '';
$oldRegion   = $old['region_id']   ?? '';
$oldProvince = $old['province_id'] ?? '';
$oldCity     = $old['city_id']     ?? '';
$oldBarangay = $old['barangay_id'] ?? '';
?>
<html lang="en">
  <!--begin::Head-->
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>STSN Grading System | Student</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
    <meta name="color-scheme" content="light dark" />
    <meta name="theme-color" content="#007bff" media="(prefers-color-scheme: light)" />
    <meta name="theme-color" content="#1a1a1a" media="(prefers-color-scheme: dark)" />
    <meta name="title" content="STSN | Dashboard" />
    <meta name="author" content="G" />
    <meta
    name="description"
    content="STSN Grading System - A modern and accessible Bootstrap 5-based grading and student management platform for Schools. Secure, fast, and WCAG 2.1 AA compliant."
    />
    <meta
    name="keywords"
    content="STSN, STSN Grading System, school grading system, student information system, bootstrap 5 admin dashboard, grading dashboard, student records, class management, teacher tools, accessible admin panel"
    />


    <meta name="supported-color-schemes" content="light dark" />
    <link rel="preload" href="./css/adminlte.css" as="style" />

    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
      integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q="
      crossorigin="anonymous"
      media="print"
      onload="this.media='all'"
    />
 
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
      crossorigin="anonymous"
    />
  
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
      crossorigin="anonymous"
    />
    <!--end::Third Party Plugin(Bootstrap Icons)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <link rel="stylesheet" href="./css/adminlte.css" />
    <!--end::Required Plugin(AdminLTE)-->

  </head>
  <!--end::Head-->
  <body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
      <div class="app-wrapper">
        <?php require_once("includes/header.php"); ?>
        <?php require_once("includes/sidebar.php"); ?>

        <main class="app-main">
            <div class="app-content-header">
              <div class="container-fluid">
                  <div class="row">
                    <div class="col-sm-6"><h3><i class="bi bi-person-plus"></i> <?= $edit ? 'Edit' : 'Add' ?> Student</h3></div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item">Users</li>
                        <li class="breadcrumb-item active"><?= $edit ? 'Edit' : 'Add' ?> Student</li>
                        </ol>
                    </div>
                  </div>
              </div>
            </div>

          <div class="card m-3">
            <div class="card-header"><h5 class="mb-0">Student Information</h5></div>
            <form method="post" action="api/student/save.php" class="needs-validation" novalidate>
              <input type="hidden" name="id" value="<?= $id ?>">


                  <!-- ALERT-->
                  <?php if (isset($_GET['msg'])): ?>
                      <div class="alert alert-success alert-dismissible fade show" role="alert">
                      <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($_GET['msg']) ?>
                      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                      </div>
                  <?php endif; ?>

                  <?php if (isset($_GET['error'])): ?>
                      <div class="alert alert-danger alert-dismissible fade show" role="alert">
                      <i class="bi bi-exclamation-triangle me-2"></i><?= htmlspecialchars($_GET['error']) ?>
                      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                      </div>
                  <?php endif; ?>
                  <?php if (isset($_GET['duplicate'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show m-3" role="alert">
                        <i class="bi bi-exclamation-triangle me-2"></i>LRN already exists!
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                  <!-- END ALERT -->

                  <!-- ROW 1 -->
                  <div class="row g-4 m-3">
                  <!-- STUDENT INFO -->
                      <div class="col-md-6">
                        <div class="card card-danger card-outline">
                          <div class="card-header">
                            <h3 class="card-title"><i class="bi bi-person"></i> Student Info</h3>
                          </div>

                          <div class="card-body">
                            <div class="row g-3">

                              <div class="col-md-6">
                                <label>LRN <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="lrn" required
                                  value="<?= htmlspecialchars($old['lrn'] ?? '') ?>">
                              </div>

                              <div class="col-md-6">
                                <label>Grade Level <span class="text-danger">*</span></label>
                                <select class="form-select" name="grade_level_id" required>
                                  <option value="">Select Grade</option>
                                  <?php foreach ($grades as $g): ?>
                                    <option value="<?= $g['id'] ?>" <?= ($old['grade_level_id'] ?? '') == $g['id'] ? 'selected' : '' ?>>
                                      <?= htmlspecialchars($g['grade_level_name']) ?>
                                    </option>
                                  <?php endforeach; ?>
                                </select>
                              </div>

                              <div class="col-md-4">
                                <label>First Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="fname" required
                                  value="<?= htmlspecialchars($old['fname'] ?? '') ?>">
                              </div>

                              <div class="col-md-4">
                                <label>Middle Name</label>
                                <input type="text" class="form-control" name="mname"
                                  value="<?= htmlspecialchars($old['mname'] ?? '') ?>">
                              </div>

                              <div class="col-md-4">
                                <label>Last Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="lname" required
                                  value="<?= htmlspecialchars($old['lname'] ?? '') ?>">
                              </div>

                              <div class="col-md-4">
                                <label>Birthdate <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" name="birthdate" required
                                  value="<?= htmlspecialchars($old['birthdate'] ?? '') ?>">
                              </div>

                              <div class="col-md-4">
                                <label>Sex <span class="text-danger">*</span></label>
                                <select class="form-select" name="gender" required>
                                  <option value="">Select</option>
                                  <option <?= ($old['gender'] ?? '') === 'Male' ? 'selected' : '' ?>>Male</option>
                                  <option <?= ($old['gender'] ?? '') === 'Female' ? 'selected' : '' ?>>Female</option>
                                </select>
                              </div>

                              <div class="col-md-4">
                                <label>Citizenship</label>
                                <input type="text" class="form-control" name="citizenship"
                                  value="<?= htmlspecialchars($old['citizenship'] ?? '') ?>">
                              </div>

                            </div>
                          </div>
                        </div>
                      </div>


                      <!-- PARENTS -->
                      <div class="col-md-6">
                        <div class="card card-success card-outline">
                          <div class="card-header">
                            <h3 class="card-title"><i class="bi bi-people"></i> Parents / Guardian</h3>
                          </div>

                          <div class="card-body">
                            <div class="row g-3">

                              <div class="col-md-6">
                                <label>Father's Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="fathers_name" required
                                  value="<?= htmlspecialchars($old['fathers_name'] ?? '') ?>">
                              </div>

                              <div class="col-md-6">
                                <label>Father's Contact <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="fathers_contact_num" required
                                  value="<?= htmlspecialchars($old['fathers_contact_num'] ?? '') ?>">
                              </div>

                              <div class="col-md-6">
                                <label>Mother's Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="mothers_name" required
                                  value="<?= htmlspecialchars($old['mothers_name'] ?? '') ?>">
                              </div>

                              <div class="col-md-6">
                                <label>Mother's Contact <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="mothers_contact_num" required
                                  value="<?= htmlspecialchars($old['mothers_contact_num'] ?? '') ?>">
                              </div>

                              <div class="col-md-6">
                                <label>Guardian Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="guardian_name" required
                                  value="<?= htmlspecialchars($old['guardian_name'] ?? '') ?>">
                              </div>

                              <div class="col-md-6">
                                <label>Guardian Contact <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="guardian_contact_num" required
                                  value="<?= htmlspecialchars($old['guardian_contact_num'] ?? '') ?>">
                              </div>

                            </div>
                          </div>
                        </div>
                      </div>


                      <!-- ADDRESS -->
                      <div class="col-md-12 mt-4">
                        <div class="card card-dark card-outline">
                          <div class="card-header">
                              <h3 class="card-title"><i class="bi bi-geo-alt"></i> Address Info</h3>
                          </div>

                          <div class="card-body">
                              <div class="row g-3">

                              <div class="col-md-4">
                                  <label>Street / House No. <span class="text-danger">*</span></label>
                                  <input type="text" class="form-control" name="street_name" required
                                  value="<?= htmlspecialchars($old['street_name'] ?? '') ?>">
                              </div>

                              <div class="col-md-4">
                                  <label>Country <span class="text-danger">*</span></label>
                                  <select class="form-select" id="country" name="country_id" required>
                                  <option value="">Select Country</option>
                                  <?php foreach ($countries as $c): ?>
                                      <option value="<?= $c['id'] ?>" <?= ($oldCountry == $c['id']) ? 'selected' : '' ?>>
                                      <?= htmlspecialchars($c['country_name']) ?>
                                      </option>
                                  <?php endforeach; ?>
                                  </select>
                              </div>

                              <div class="col-md-4">
                                  <label>Region <span class="text-danger">*</span></label>
                                  <select class="form-select" id="region" name="region_id" required>
                                  <option value="">Select Region</option>
                                  </select>
                              </div>

                              <div class="col-md-4">
                                  <label>Province <span class="text-danger">*</span></label>
                                  <select class="form-select" id="province" name="province_id" required>
                                  <option value="">Select Province</option>
                                  </select>
                              </div>

                              <div class="col-md-4">
                                  <label>City / Municipality <span class="text-danger">*</span></label>
                                  <select class="form-select" id="city" name="city_id" required>
                                  <option value="">Select City</option>
                                  </select>
                              </div>

                              <div class="col-md-4">
                                  <label>Barangay <span class="text-danger">*</span></label>
                                  <select class="form-select" id="barangay" name="barangay_id" required>
                                  <option value="">Select Barangay</option>
                                  </select>
                              </div>

                              <div class="col-md-4">
                                  <label>Postal Code</label>
                                  <input type="text" class="form-control" name="postal_code"
                                  value="<?= htmlspecialchars($old['postal_code'] ?? '') ?>">
                              </div>

                              </div>
                          </div>
                        </div>
                      </div>
      
                <!--BUTTONS -->
                <div class="text-end mt-4">
                    <a href="student.php" class="btn btn-danger">Cancel</a>
                    <button type="submit" class="btn btn-info">
                    <i class="bi bi-save"></i> <?= $edit ? "Update" : "Save" ?>
                    </button>
                </div>
            </form>
         </div>                               
        </div>
      </main>
    <?php require_once("includes/footer.php"); ?>                                
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./js/adminlte.js"></script>
    <!--MISSING-FIELDS ALERT -->
    <script>
    (() => {
      const form = document.querySelector('.needs-validation');
      if (!form) return;
      const alertBox = document.createElement('div');
      alertBox.className = 'alert alert-danger alert-dismissible fade show d-none';
      alertBox.innerHTML = `<i class="bi bi-exclamation-triangle me-2"></i>
                            <span class="fw-bold">Please fill in the following fields:</span>
                            <ul class="mb-0 mt-1"></ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
      form.prepend(alertBox);

      form.addEventListener('submit', e => {
        const missing = [...form.querySelectorAll('[required]')]
                        .filter(el => !el.value.trim())
                        .map(el => el.closest('.col-md-4, .col-md-6, .col-md-12')  
                                      ?.querySelector('label')?.textContent.replace('*','').trim() || el.name);

        if (missing.length) {
          e.preventDefault();                 
          alertBox.querySelector('ul').innerHTML = missing.map(m => `<li>${m}</li>`).join('');
          alertBox.classList.remove('d-none');
          alertBox.scrollIntoView({behavior:'smooth', block:'center'});
        }
      });
    })();
    </script>
    <script>
      /* chained selects (unchanged)*/
      const regions   = <?= json_encode($regions) ?>;
      const provinces = <?= json_encode($provinces) ?>;
      const cities    = <?= json_encode($cities) ?>;
      const barangays = <?= json_encode($barangays) ?>;

      document.addEventListener('DOMContentLoaded', () => {
      const country  = document.getElementById('country');
      const region   = document.getElementById('region');
      const province = document.getElementById('province');
      const city     = document.getElementById('city');
      const barangay = document.getElementById('barangay');

      function fillSelect(select, list, nameField, firstText, preSel = null) {
          const keep = select.value;
          select.innerHTML = `<option value="">${firstText}</option>`;
          list.forEach(item => {
          const opt = document.createElement('option');
          opt.value = item.id;
          opt.text  = item[nameField];
          if (opt.value == keep || opt.value == preSel) opt.selected = true;
          select.appendChild(opt);
          });
      }

      if (+country.value) {
          fillSelect(region, regions.filter(r => r.country_id == country.value), 'region_name', 'Select Region', '<?= $oldRegion ?>');
          if (+region.value)   fillSelect(province, provinces.filter(p => p.region_id == region.value), 'province_name', 'Select Province', '<?= $oldProvince ?>');
          if (+province.value) fillSelect(city, cities.filter(c => c.province_id == province.value), 'city_name', 'Select City', '<?= $oldCity ?>');
          if (+city.value)     fillSelect(barangay, barangays.filter(b => b.city_id == city.value), 'barangay_name', 'Select Barangay', '<?= $oldBarangay ?>');
      }

      country.addEventListener('change', () => {
          fillSelect(region, regions.filter(r => r.country_id == country.value), 'region_name', 'Select Region');
          province.innerHTML = city.innerHTML = barangay.innerHTML = '<option value="">Select...</option>';
      });
      region.addEventListener('change', () => {
          fillSelect(province, provinces.filter(p => p.region_id == region.value), 'province_name', 'Select Province');
          city.innerHTML = barangay.innerHTML = '<option value="">Select...</option>';
      });
      province.addEventListener('change', () => {
          fillSelect(city, cities.filter(c => c.province_id == province.value), 'city_name', 'Select City');
          barangay.innerHTML = '<option value="">Select...</option>';
      });
      city.addEventListener('change', () => {
          fillSelect(barangay, barangays.filter(b => b.city_id == city.value), 'barangay_name', 'Select Barangay');
      });
      });
    </script>
</body>
</html>