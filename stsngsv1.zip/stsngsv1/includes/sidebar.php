<aside class="app-sidebar bg-secondary-subtle" data-bs-theme="dark">
  <div class="sidebar-brand">
    <a href="index.php" class="brand-link d-flex align-items-center">
      <i class="bi bi-person-fill-gear fs-4 me-2 ms-2 opacity-75"></i>
      <span class="brand-text fw-light">STSN ADMIN</span>
    </a>
  </div>

  <div class="sidebar-wrapper">
    <nav class="mt-2">
      <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" data-accordion="false">

        <li class="nav-item">
          <a href="index.php" class="nav-link">
            <i class="nav-icon bi bi-speedometer"></i>
            <p>Dashboard</p>
          </a>
        </li>
        <li class="nav-header text-uppercase text-xs opacity-75">Users</li>

        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon bi bi-easel"></i>
            <p>Teacher<i class="nav-arrow bi bi-chevron-right"></i></p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="teacher.php" class="nav-link">
                <i class="nav-icon bi bi-people"></i>
                <p class="text-center small mb-0">Manage Teachers</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="assign.php" class="nav-link">
                <i class="nav-icon bi bi-person-badge"></i>
                <p class="text-center small mb-0">Assign Section</p>
              </a>
            </li>
          </ul>
        </li>

        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon bi bi-person-check"></i>
            <p>Student<i class="nav-arrow bi bi-chevron-right"></i></p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="student.php" class="nav-link">
                <i class="nav-icon bi bi-people"></i>
                <p class="text-center small mb-0">Manage Students</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item">
          <a href="manageA.php" class="nav-link">
            <i class="nav-icon bi bi-diagram-3"></i>
            <p>Manage Account</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="scheduling.php" class="nav-link">
            <i class="bi bi-calendar-week-fill"></i>
            <p>Scheduling</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="sectioning.php" class="nav-link">
            <i class="bi bi-pin-map"></i>
            <p>Sectioning</p>
          </a>
        </li>
        <li class="nav-header">MAINTENANCE</li>
        <li class="nav-item">
          <a href="academic_year.php" class="nav-link">
            <i class="nav-icon bi bi-calendar"></i>
            <p>Academic Year</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="section.php" class="nav-link">
            <i class="nav-icon bi bi-journals"></i>
            <p>Section</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="subject.php" class="nav-link">
            <i class="nav-icon bi bi-book"></i>
            <p>Subjects</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon bi bi-file-earmark-text"></i>
            <p>Curriculum Setup</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon bi bi-gear-wide"></i>
            <p>
              System Settings
              <i class="nav-arrow bi bi-chevron-right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="#" class="nav-link">
                <i class="nav-icon bi bi-bar-chart-steps"></i>
                <p class="text-center small mb-0">Grading Scale</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="#" class="nav-link">
                <i class="nav-icon bi bi-calendar2-x"></i>
                <p class="text-center small mb-0">Deadlines</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="#" class="nav-link">
                <i class="nav-icon bi bi-person-circle"></i>
                <p class="text-center small mb-0">Profile</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="#" class="nav-link">
                <i class="nav-icon bi bi-gear-wide-connected"></i>
                <p class="text-center small mb-0">Account Settings</p>
              </a>
            </li>
          </ul>
        </li>

        <li class="nav-item mt-2">
          <a href="api/login/logout.php" class="nav-link text-danger">
            <i class="nav-icon bi bi-box-arrow-right"></i>
            <p>Logout</p>
          </a>
        </li>

      </ul>
      </nav>
  </div>
  </aside>