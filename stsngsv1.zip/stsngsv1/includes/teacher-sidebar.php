<aside class="app-sidebar bg-secondary-subtle" data-bs-theme="dark">
  <div class="sidebar-brand">
    <a href="teacher-dashboard.php" class="brand-link d-flex align-items-center">
      <i class="bi bi-person-video3 fs-4 me-2 ms-2 opacity-75"></i>
      <span class="brand-text fw-light">STSN TEACHER</span>
    </a>
  </div>

  <div class="sidebar-wrapper">
    <nav class="mt-2">
      <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" data-accordion="false">

        <li class="nav-item">
          <a href="teacher-dashboard.php" class="nav-link active">
            <i class="nav-icon bi bi-speedometer"></i>
            <p>Dashboard</p>
          </a>
        </li>
        <li class="nav-header text-uppercase text-xs opacity-75">Teaching</li>

        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon bi bi-easel"></i>
            <p>My Classes <i class="nav-arrow bi bi-chevron-right"></i></p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="teacher-section.php" class="nav-link"><i class="nav-icon bi bi-list-ul"></i><p>View Classes</p></a>
            </li>
            <li class="nav-item">
              <a href="teacher_gradebook.php" class="nav-link"><i class="nav-icon bi bi-table"></i><p>Gradebook Grid</p></a>
            </li>
            <li class="nav-item">
              <a href="class-roster.php" class="nav-link"><i class="nav-icon bi bi-people"></i><p>Class Roster</p></a>
            </li>
          </ul>
        </li>

        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon bi bi-person-check"></i>
            <p>My Advisory <i class="nav-arrow bi bi-chevron-right"></i></p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="teacher-student-record.php" class="nav-link"><i class="nav-icon bi bi-hourglass-split"></i><p>Pending Sheets</p></a>
            </li>
            <li class="nav-item">
              <a href="teacher_attendance.php" class="nav-link"><i class="nav-icon bi bi-calendar-check"></i><p>Attendance</p></a>
            </li>
            <li class="nav-item">
              <a href="teacher_behavior.php" class="nav-link"><i class="nav-icon bi bi-journal-text"></i><p>Behaviour Notes</p></a>
            </li>
            <li class="nav-item">
              <a href="teacher_advisory_report.php" class="nav-link"><i class="nav-icon bi bi-file-earmark-pdf"></i><p>Advisory Report</p></a>
            </li>
          </ul>
        </li>

        <li class="nav-item">
          <a href="teacher_schedule.php" class="nav-link">
            <i class="nav-icon bi bi-calendar-week"></i>
            <p>View Schedule</p>
          </a>
        </li>

        <li class="nav-item">
          <a href="teacher_account.php" class="nav-link">
            <i class="nav-icon bi bi-gear"></i>
            <p>My Account</p>
          </a>
        </li>

        <li class="nav-header text-uppercase text-xs opacity-75">Admin</li>
        <li class="nav-item">
          <a href="reports.php" class="nav-link">
            <i class="nav-icon bi bi-file-earmark-pdf"></i>
            <p>Registrar Reports</p>
          </a>
        </li>

        <li class="nav-item mt-2">
          <a href="api/login/logout.php" class="nav-link text-danger">
            <i class="nav-icon bi bi-box-arrow-right"></i>
            <p>Logout</p>
          </a>
        </li>

      </ul>
    </nav>
  </div>
</aside>