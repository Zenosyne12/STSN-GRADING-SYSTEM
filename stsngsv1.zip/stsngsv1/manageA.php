<?php
require_once __DIR__ . '/api/shared/db_connect.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Manage Accounts</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0/dist/css/select2.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="./css/adminlte.css">
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
  <?php require_once("includes/header.php"); ?>
  <?php require_once("includes/sidebar.php"); ?>

  <main class="app-main">
    <div class="app-content-header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6"><h3 class="mb-0"><i class="nav-icon bi bi-diagram-3"></i> Manage Accounts</h3></div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-end">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item">Users</li>
              <li class="breadcrumb-item active">Manage Accounts</li>
            </ol>
          </div>
        </div>
      </div>
    </div>

    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Account List</h3>
              <div class="card-tools">
                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addAccountModal">
                  <i class="bi bi-plus-circle me-1"></i> New Account
                </button>
              </div>
            </div>

            <div class="card-body px-2 px-md-3">
              <div class="table-responsive">
                <table class="table table-bordered table-striped text-nowrap mb-0">
                  <thead>
                    <tr>
                      <th style="width:50px;">#</th>
                      <th>Teacher ID</th>
                      <th>Name</th>
                      <th>Username</th>
                      <th>Role</th>
                      <th>Status</th>
                      <th>Created</th>
                      <th style="width:140px;">Actions</th>
                    </tr>
                  </thead>
                  <tbody id="accountTableBody">
                    <tr><td colspan="9" class="text-center text-muted">Loading accounts...</td></tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
  <?php require_once("includes/footer.php"); ?>
</div>

<!-- Add Account Modal -->
<div class="modal fade" id="addAccountModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="false">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Create New Account</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label class="form-label fw-bold">Select Teacher ID</label>
          <select id="teacherIdInput" class="form-select" onchange="searchTeacher()">
            <option value="">-- Loading Teacher IDs... --</option>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label fw-bold">Teacher Information</label>
          <input type="hidden" id="teacherDbIdInput">
          <div class="row mb-2">
            <div class="col-md-6">
              <input type="text" id="fullNameInput" class="form-control" placeholder="First Name" readonly>
            </div>
            <div class="col-md-6">
              <input type="text" id="lastnameInput" class="form-control" placeholder="Last Name" readonly>
            </div>
          </div>
          <input type="date" id="birthdateInput" class="form-control mb-2" placeholder="Birthdate" readonly>
          <input type="email" id="emailInput" class="form-control" placeholder="Email Address" readonly>
        </div>

        <div class="mb-3">
          <label class="form-label fw-bold">Account Credentials</label>
          <input type="text" id="usernameInput" class="form-control mb-2" placeholder="Username will be auto-generated" readonly>
          <div class="alert alert-info py-2">
            <small><i class="bi bi-info-circle me-1"></i> Credentials will be sent to teacher's email</small>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-success" onclick="createAccount()">Save & Send Email</button>
      </div>
    </div>
  </div>
</div>

<!-- Success Modal -->
<div class="modal fade" id="successModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="false">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="bi bi-check-circle-fill text-success"></i> Account Created!</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <p class="mb-2"><strong>Username:</strong> <span id="newUsername" class="text-primary"></span></p>
        <div class="alert alert-success py-2">
          <small><i class="bi bi-envelope-check me-1"></i><span id="successMessage">Temporary password sent via email!</span></small>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- View Account Modal -->
<div class="modal fade" id="viewModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="false">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Account Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="viewModalBody"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>

<script>
async function fetchAccounts() {
    try {
        const res = await fetch('api/accounts/list.php');
        const json = await res.json();
        if (json.success && json.data) {
            const tbody = document.getElementById('accountTableBody');
            tbody.innerHTML = json.data.map((acc, i) => `
                <tr>
                    <td>${i + 1}</td>
                    <td>${acc.teacher_id || 'N/A'}</td>
                    <td class="text-start">${acc.name || 'N/A'}</td>
                    <td>${acc.username}</td>
                    <td><span class="badge ${acc.role === 'Admin' ? 'bg-danger' : 'bg-primary'}">${acc.role || 'Teacher'}</span></td>
                    <td><span class="badge ${acc.status === 'Active' ? 'bg-success' : 'bg-warning'}">${acc.status || 'Active'}</span></td>
                    <td>${acc.created || 'N/A'}</td>
                    <td>
                        <button class="btn btn-sm btn-info" onclick="viewAccount(${acc.id})" title="View"><i class="bi bi-eye"></i></button>
                        <button class="btn btn-sm ${acc.status === 'Active' ? 'btn-danger' : 'btn-success'}" onclick="toggleStatus(${acc.id}, '${acc.status}')">
                            <i class="bi ${acc.status === 'Active' ? 'bi-person-dash' : 'bi-person-check'}"></i>
                        </button>
                    </td>
                </tr>`).join('');
        }
    } catch (err) {
        document.getElementById('accountTableBody').innerHTML = `<tr><td colspan="9" class="text-center text-danger">Failed: ${err.message}</td></tr>`;
    }
}

async function toggleStatus(userId, current) {
    const newStatus = current === 'Active' ? 'Inactive' : 'Active';
    if (!confirm(`Mark this account as ${newStatus}?`)) return;
    try {
        const res = await fetch('api/accounts/update.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ id: userId, status: newStatus })
        });
        const json = await res.json();
        if (json.success) fetchAccounts();
        else alert(json.error || 'Update failed');
    } catch (err) {
        alert('Could not change status: ' + err.message);
    }
}

async function loadTeacherIDs() {
    try {
        const res = await fetch('api/teacher/ids.php');
        const json = await res.json();
        const dropdown = document.getElementById('teacherIdInput');
        if (json.success && json.teacher_ids) {
            dropdown.innerHTML = '<option value="">-- Select Teacher ID --</option>';
            json.teacher_ids.forEach(id => {
                const option = document.createElement('option');
                option.value = id;
                option.textContent = id;
                dropdown.appendChild(option);
            });
        } else {
            dropdown.innerHTML = '<option value="">-- No teachers found --</option>';
        }
    } catch (err) {
        console.error('Failed to load teacher IDs:', err);
        document.getElementById('teacherIdInput').innerHTML = '<option value="">-- Error loading --</option>';
    }
}

async function searchTeacher() {
    const tid = document.getElementById('teacherIdInput').value.trim();
    if (!tid) {
        clearForm();
        return;
    }
    try {
        const res = await fetch(`api/accounts/search_teacher.php?id=${encodeURIComponent(tid)}`);
        const json = await res.json();
        if (json.success) {
            document.getElementById('teacherDbIdInput').value = json.teacher_db_id;
            document.getElementById('fullNameInput').value = json.fname;
            document.getElementById('lastnameInput').value = json.lname;
            document.getElementById('birthdateInput').value = json.birthdate;
            document.getElementById('emailInput').value = json.email || '';
            
            const username = (json.lname.toLowerCase().replace(/\s+/g, '') + json.teacher_id.toLowerCase());
            document.getElementById('usernameInput').value = username;
        } else {
            alert(json.error || 'Teacher not found');
            clearForm();
        }
    } catch (err) {
        alert('Search failed: ' + err.message);
    }
}

async function createAccount() {
    const teacher_db_id = document.getElementById('teacherDbIdInput').value.trim();
    const username = document.getElementById('usernameInput').value.trim();
    
    if (!teacher_db_id) {
        alert('Please select a teacher first');
        return;
    }
    
    try {
        const res = await fetch('api/accounts/create.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ teacher_db_id: parseInt(teacher_db_id), username })
        });
        const json = await res.json();
        if (json.success) {
            document.getElementById('newUsername').textContent = json.username;
            document.getElementById('successMessage').textContent = json.message;
            
            bootstrap.Modal.getInstance(document.getElementById('addAccountModal')).hide();
            bootstrap.Modal.getOrCreateInstance(document.getElementById('successModal')).show();
            
            fetchAccounts();
            clearForm();
        } else {
            alert(' ' + (json.error || 'Creation failed'));
        }
    } catch (err) {
        alert('Failed: ' + err.message);
    }
}

async function viewAccount(userId) {
    try {
        const res = await fetch(`api/accounts/view.php?id=${userId}`);
        const json = await res.json();
        if (json.success && json.data) {
            const a = json.data;
            document.getElementById('viewModalBody').innerHTML = `
                <div class="row"><div class="col-md-6"><strong>User ID:</strong><br>${a.id}</div><div class="col-md-6"><strong>Teacher ID:</strong><br>${a.teacher_id || 'N/A'}</div></div>
                <hr><div class="row"><div class="col-md-6"><strong>Name:</strong><br>${a.name || 'N/A'}</div><div class="col-md-6"><strong>Username:</strong><br>${a.username}</div></div>
                <hr><div class="row"><div class="col-md-6"><strong>Role:</strong><br><span class="badge bg-${a.role === 'Admin' ? 'danger' : 'primary'}">${a.role || 'Teacher'}</span></div><div class="col-md-6"><strong>Status:</strong><br><span class="badge bg-${a.status === 'Active' ? 'success' : 'warning'}">${a.status || 'Active'}</span></div></div>
                <hr><div class="row"><div class="col-12"><strong>Created:</strong><br>${a.created || 'N/A'}</div></div>`;
            bootstrap.Modal.getOrCreateInstance(document.getElementById('viewModal')).show();
        } else {
            alert('Account not found');
        }
    } catch (err) {
        alert('Failed to load details: ' + err.message);
    }
}

function clearForm() {
    document.getElementById('teacherIdInput').selectedIndex = 0;
    ['teacherDbIdInput', 'fullNameInput', 'lastnameInput', 'birthdateInput', 'emailInput', 'usernameInput'].forEach(id => {
        document.getElementById(id).value = '';
    });
}

document.addEventListener('DOMContentLoaded', () => {
    fetchAccounts();
    loadTeacherIDs();
    document.getElementById('addAccountModal').addEventListener('hidden.bs.modal', clearForm);
});
</script>
</body>
</html>