<?php
require_once __DIR__ . '/api/shared/db_connect.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Assign Teacher</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css ">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css ">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css ">
    <link rel="stylesheet" href="./css/adminlte.css">

    <!-- =====  RESPONSIVE-CARD STYLES  ===== -->
    <style>
        @media (max-width: 767.98px) {
            #assignTable thead { display: none; }
            #assignTable tbody tr {
                display: block;
                border: 1px solid #dee2e6;
                margin-bottom: .5rem;
                border-radius: .25rem;
                padding: .5rem;
            }
            #assignTable tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                border: none !important;
                padding: .35rem .5rem;
            }
            #assignTable tbody td::before {
                content: attr(data-label);
                font-weight: 600;
                margin-right: .5rem;
                white-space: nowrap;
            }
            #assignTable tbody td:last-child {
                flex-direction: column;
                gap: .25rem;
            }
            #assignTable tbody td:last-child .btn {
                width: 100%;
                font-size: .9rem;
                padding: .4rem;
            }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once 'includes/header.php'; ?>
    <?php require_once 'includes/sidebar.php'; ?>

    <main class="app-main">
        <div class="app-content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6"><h3 class="mb-0"><i class="bi bi-person-check"></i> Assign Teacher</h3></div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item">Academic</li>
                            <li class="breadcrumb-item active">Assign Teacher</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="card m-3">
            <div class="card-header d-flex justify-content-between align-items-center flex-wrap">
                <h3 class="card-title mb-0">Teacher Assignment List</h3>
                <div class="d-flex align-items-center gap-2 ms-auto">
                    <input class="form-control form-control-sm" id="searchInput" placeholder="Search…" style="max-width:150px;">
                    <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#assignModal">
                        <i class="bi bi-plus-circle"></i> Assign Teacher
                    </button>
                </div>
            </div>

            <div class="card-body">
                <!-- desktop table -->
                <div class="table-responsive d-none d-md-block">
                    <table id="assignTable" class="table table-bordered table-hover align-middle text-center mb-0">
                        <thead class="table-light">
                        <tr>
                            <th style="width:50px;">#</th>
                            <th>Teacher</th>
                            <th>Subject</th>
                            <th>Section</th>
                            <th>A.Y.</th>
                            <th style="width:120px;">Status</th>
                            <th style="width:200px;">Actions</th>
                        </tr>
                        </thead>
                        <tbody id="tableBody"></tbody>
                    </table>
                </div>

                <!-- phone cards -->
                <div class="d-block d-md-none" id="cardView"></div>
            </div>

            <div class="card-footer clearfix">
                <ul class="pagination pagination-sm m-0 float-end" id="pagination"></ul>
            </div>
        </div>
    </main>
    <?php require_once 'includes/footer.php'; ?>
</div>

<!-- Modal -->
<div class="modal fade" id="assignModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="assignForm">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">Assign Teacher</h5>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="assignId">

                    <div class="mb-3">
                        <label class="form-label">Academic Year</label>
                        <select class="form-select" id="ay_id" required></select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Teacher</label>
                        <select class="form-select" id="teacher_id" required></select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Subject</label>
                        <select class="form-select" id="subject_id" required></select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Section</label>
                        <select class="form-select" id="section_id" required></select>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="isAdvisory">
                        <label class="form-check-label" for="isAdvisory">Advisory class</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js "></script>
<script src="./js/adminlte.js"></script>
<script>
let currentPage = 1;
let searchTerm  = '';

/* ----------  LOAD TABLE  ---------- */
function loadAssignments(page = 1, search = ''){
    fetch(`api/assign/read.php?p=${page}&s=${encodeURIComponent(search)}`)
        .then(r => r.json())
        .then(data => renderTable(data.assignments||[], data.page, data.pages));
}

/* ----------  RENDER  ---------- */
function renderTable(list, page, pages){
    const headers = ['#', 'Teacher', 'Subject', 'Section', 'A.Y.', 'Status', 'Actions'];

    /* ---- desktop rows ---- */
    const row = (r, i) => `
        <tr>
            <td data-label="${headers[0]}">${((page-1)*10)+i+1}</td>
            <td data-label="${headers[1]}" class="text-start">${r.teacher}</td>
            <td data-label="${headers[2]}">${r.subject}</td>
            <td data-label="${headers[3]}">${r.section}</td>
            <td data-label="${headers[4]}">${r.ay}</td>
            <td data-label="${headers[5]}">
                <span class="badge bg-${r.is_active ? 'success' : 'secondary'}">${r.is_active ? 'Active' : 'Inactive'}</span>
            </td>
            <td data-label="${headers[6]}">
                <button class="btn btn-sm btn-warning me-1" onclick="editAssign(${r.id})"><i class="bi bi-pencil-square"></i> Edit</button>
                <button class="btn btn-sm ${r.is_active ? 'btn-danger' : 'btn-outline-success'}"
                        onclick="toggleAssign(${r.id},${r.is_active})"
                        data-bs-toggle="tooltip" title="${r.is_active ? 'Deactivate' : 'Activate'}">
                    <i class="bi ${r.is_active ? 'bi-toggle-off' : 'bi-toggle-on'}"></i> ${r.is_active ? 'Deactivate' : 'Activate'}
                </button>
            </td>
        </tr>`;

    /* ---- phone cards ---- */
    const card = (r, i) => `
        <div class="card mb-3 shadow-sm">
            <div class="card-header bg-light d-flex justify-content-between">
                <span class="fw-bold">${((page-1)*10)+i+1}. ${r.teacher}</span>
                <span class="badge bg-${r.is_active ? 'success' : 'secondary'}">${r.is_active ? 'Active' : 'Inactive'}</span>
            </div>
            <div class="card-body py-2 small">
                <div class="row mb-1"><div class="col-4 text-muted">Subject</div><div class="col-8">${r.subject}</div></div>
                <div class="row mb-1"><div class="col-4 text-muted">Section</div><div class="col-8">${r.section}</div></div>
                <div class="row mb-1"><div class="col-4 text-muted">A.Y.</div><div class="col-8">${r.ay}</div></div>
                <div class="row mb-1"><div class="col-4 text-muted">Role</div><div class="col-8">${r.advisory ? 'Adviser' : 'Teacher'}</div></div>
            </div>
            <div class="card-footer d-grid gap-2">
                <button class="btn btn-sm btn-warning" onclick="editAssign(${r.id})"><i class="bi bi-pencil-square"></i> Edit</button>
                <button class="btn btn-sm ${r.is_active ? 'btn-danger' : 'btn-outline-success'}"
                        onclick="toggleAssign(${r.id},${r.is_active})"
                        data-bs-toggle="tooltip" title="${r.is_active ? 'Deactivate' : 'Activate'}">
                    <i class="bi ${r.is_active ? 'bi-toggle-off' : 'bi-toggle-on'}"></i> ${r.is_active ? 'Deactivate' : 'Activate'}
                </button>
            </div>
        </div>`;

    document.getElementById('tableBody').innerHTML = list.map(row).join('');
    document.getElementById('cardView').innerHTML  = list.map(card).join('');

    let p = '';
    for (let i = 1; i <= pages; i++) p += `<li class="page-item ${i === page ? 'active' : ''}"><a class="page-link" href="#" onclick="loadAssignments(${i}, searchTerm)">${i}</a></li>`;
    document.getElementById('pagination').innerHTML = p;
}

/* ----------  FILL DROPDOWNS  ---------- */
function fillSelects(){
    fetch('api/assign/read.php?drop=1')
        .then(r => r.json())
        .then(d => {
            ['ay_id','teacher_id','subject_id','section_id'].forEach(sel=>{
                const el = document.getElementById(sel);
                el.innerHTML = '';
                d[sel].forEach(o=>{
                    const opt = document.createElement('option');
                    opt.value = o.id;
                    opt.textContent = o.name;
                    el.appendChild(opt);
                });
            });
        });
}

/* ----------  ADD / EDIT  ---------- */
document.getElementById('assignForm').addEventListener('submit', e=>{
    e.preventDefault();
    const data = {
        id: document.getElementById('assignId').value || undefined,
        ay_id: document.getElementById('ay_id').value,
        teacher_id: document.getElementById('teacher_id').value,
        subject_id: document.getElementById('subject_id').value,
        section_id: document.getElementById('section_id').value,
        isAdvisory: document.getElementById('isAdvisory').checked ? 1 : 0
    };
    fetch('api/assign/save.php',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify(data)
    })
    .then(r=>r.json())
    .then(res=>{
        if(res.success){
            bootstrap.Modal.getInstance(document.getElementById('assignModal')).hide();
            loadAssignments(currentPage, searchTerm);
            document.getElementById('assignForm').reset();
        }else{
            alert(res.error||'Save failed');
        }
    });
});

function editAssign(id){
    fetch(`api/assign/fetch.php?id=${id}`)
        .then(r=>r.json())
        .then(d=>{
            document.getElementById('assignId').value       = d.id;
            document.getElementById('ay_id').value          = d.ay_id;
            document.getElementById('teacher_id').value     = d.teacher_id;
            document.getElementById('subject_id').value     = d.subject_id;
            document.getElementById('section_id').value     = d.section_id;
            document.getElementById('isAdvisory').checked   = parseInt(d.isAdvisory);
            document.getElementById('modalTitle').textContent = 'Edit Assignment';
            new bootstrap.Modal(document.getElementById('assignModal')).show();
        });
}

/* ----------  ASYNC TOGGLE  ---------- */
async function toggleAssign(id, currentState){
    const newStatus = currentState ? 0 : 1;
    const action = newStatus ? 'Activate' : 'Deactivate';
    if (!confirm(`${action} this assignment?`)) return;

    try{
        const res = await fetch('api/assign/toggle.php', {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({id: id})
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const json = await res.json();
        if (json.success) {
            loadAssignments(currentPage, searchTerm);
        } else {
            alert(json.error || 'Toggle failed');
        }
    }catch(err){
        console.error(err);
        alert('Could not change status: ' + err.message);
    }
}

/* ----------  SEARCH  ---------- */
document.getElementById('searchInput').addEventListener('input', e=>{
    searchTerm = e.target.value;
    currentPage = 1;
    loadAssignments(currentPage, searchTerm);
});

/* ----------  RESET MODAL  ---------- */
document.getElementById('assignModal').addEventListener('hidden.bs.modal', ()=>{
    document.getElementById('assignForm').reset();
    document.getElementById('assignId').value = '';
    document.getElementById('modalTitle').textContent = 'Assign Teacher';
});

/* ----------  INIT  ---------- */
fillSelects();
loadAssignments();
</script>
</body>
</html>