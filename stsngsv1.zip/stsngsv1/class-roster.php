<!doctype html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>STSN Grading System | Roster</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
    <meta name="color-scheme" content="light dark" />
    <meta name="theme-color" content="#007bff" media="(prefers-color-scheme: light)" />
    <meta name="theme-color" content="#1a1a1a" media="(prefers-color-scheme: dark)" />
    
    <link rel="preload" href="css/adminlte.css" as="style" />
    
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
      integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q="
      crossorigin="anonymous"
      media="print"
      onload="this.media='all'"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
      crossorigin="anonymous"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
      crossorigin="anonymous"
    />
    
    <link rel="stylesheet" href="css/adminlte.css" />
    
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/apexcharts@3.37.1/dist/apexcharts.css"
      integrity="sha256-4MX+61mt9NVvvuPjUWdUdyfZfxSB1/Rf9WtqRHgG5S0="
      crossorigin="anonymous"
    />
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">

  <div class="app-wrapper">

    <?php
      require_once __DIR__ . '/includes/teacher-header.php';
      require_once __DIR__ . '/includes/teacher-sidebar.php';
    ?>

    <main class="app-main">
      <div class="app-content-header">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-6">
              <h3><i class="bi bi-people"></i> Class Roster</h3>
            </div>
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-end">
                <li class="breadcrumb-item"><a href="teacher_dashboard.php">Home</a></li>
                <li class="breadcrumb-item"><a href="teacher-section.php">My Classes</a></li>
                <li class="breadcrumb-item active">Roster</li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div class="card m-3">
        <div class="card-header d-flex justify-content-between align-items-center flex-wrap">
            <div class="card-title mb-0">Student List</div>
            
            <div class="d-flex align-items-center gap-2 ms-auto">
                <input class="form-control form-control-sm" id="searchInput" placeholder="Search..." style="max-width:150px;">
                
                <button class="btn btn-outline-secondary btn-xs" type="button">
                    <i class="bi bi-search"></i>
                </button>
                
                <button class="btn btn-success btn-xs" data-bs-toggle="modal" data-bs-target="#addStudentModal">
                    <i class="bi bi-plus-circle"></i> Add Student
                </button>
            </div>
        </div>

        <div class="card-body p-0">
          <div class="table-responsive">
            <table class="table table-bordered table-sm text-nowrap align-middle text-center mb-0" id="rosterTable">
              <thead class="table-light">
                <tr>
                  <th class="sticky-col">#</th>
                  <th>LRN</th>
                  <th class="text-start">Full Name</th>
                  <th>Gender</th>
                  <th>Birth Date</th>
                  <th>Contact No.</th>
                  <th style="width:160px;">Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr data-student-id="1">
                  <td class="sticky-col fw-semibold">1</td>
                  <td>123456789012</td>
                  <td class="text-start">Delos Santos, Juan A.</td>
                  <td>M</td>
                  <td>2005-04-14</td>
                  <td>0917-123-4567</td>
                  <td>
                    <button class="btn btn-xs btn-warning me-1" data-bs-toggle="tooltip" title="Edit">
                      <i class="bi bi-pencil-square"></i>
                    </button>
                    <button class="btn btn-xs btn-danger" data-bs-toggle="tooltip" title="Remove" onclick="removeStudent(1)">
                      <i class="bi bi-trash"></i>
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div class="card-footer clearfix">
          <ul class="pagination pagination-sm m-0 float-end">
            <li class="page-item"><a class="page-link" href="#">&laquo;</a></li>
            <li class="page-item"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">&raquo;</a></li>
          </ul>
        </div>
      </div>
    </main>

    <?php 
        require_once __DIR__ . '/includes/teacher-footer.php';
    ?>

  </div>

  <div class="modal fade" id="addStudentModal" tabindex="-1" aria-labelledby="addStudentModalLabel" aria-hidden="true" data-bs-backdrop="false">
    <div class="modal-dialog modal-dialog-centered modal-md">
      <div class="modal-content">
        <div class="modal-header bg-secondary text-white">
          <h5 class="modal-title" id="addStudentModalLabel"><i class="bi bi-person-plus me-2"></i>Add Student to Roster</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
        </div>

        <form id="studentForm">
          <div class="modal-body">
            <div class="row">
              <div class="col-md-4 mb-3"><label>LRN</label><input type="text" name="lrn" class="form-control" required></div>
              <div class="col-md-8 mb-3"><label>Full Name</label><input type="text" name="name" class="form-control" required></div>
            </div>

            <div class="row">
              <div class="col-md-4 mb-3">
                <label>Gender</label>
                <select name="gender" class="form-select" required>
                  <option disabled selected>Gender</option>
                  <option>M</option><option>F</option>
                </select>
              </div>
              <div class="col-md-4 mb-3"><label>Birth Date</label><input type="date" name="bdate" class="form-control" required></div>
              <div class="col-md-4 mb-3"><label>Contact</label><input type="text" name="contact" class="form-control"></div>
            </div>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-success">Add Student</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  
  <script src="js/adminlte.js"></script>

  <script>
    const ttList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    ttList.map(el => new bootstrap.Tooltip(el));

    function removeStudent(id){
      if(confirm('Remove this student from roster?')){
        fetch('remove_student.php', {
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify({student_id:id})
        })
        .then(r=>r.json()).then(res=>{
          if(res.success){
            document.querySelector(`tr[data-student-id="${id}"]`).remove();
          }
        });
      }
    }
  </script>

  <style>
    .sticky-col { position: sticky; left: 0; background: #fff; z-index: 10; }
    #rosterTable thead th.sticky-col { background: #f2f2f2; }
    
    /* NEW STYLE: Extra Small Button */
    .btn-xs {
        padding: 0.2rem 0.4rem;
        font-size: 0.75rem;
        line-height: 1.5;
        border-radius: 0.2rem;
    }
  </style>

</body>
</html>