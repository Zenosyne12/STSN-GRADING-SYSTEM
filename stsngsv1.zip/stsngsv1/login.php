
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - St. Theresa's School of Novaliches</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  
  <link rel="stylesheet" href="css/login.css">
</head>
<body>

  <div class="main-wrapper">
    <div class="split-card animate-up">
      <div class="login-side">
        <div class="school-branding">
          <img src="assets/img/stsn logo.png" alt="STSN Logo" class="school-logo">
          <h2 class="login-title">Welcome!</h2>
          <p class="text-muted small">Please sign in to continue.</p>
        </div>
        <div id="js-alert-container" style="min-height: 54px;"></div>
        <?php if (isset($_GET['e'])): ?>
          <div id="php-alert" class="alert alert-danger py-2 small shadow-sm border-0 mb-4 d-flex align-items-center justify-content-center">
            <i class="bi bi-exclamation-circle-fill me-2"></i> 
            <div>Invalid username or password.</div>
          </div>
        <?php endif; ?>
        <form id="loginForm" action="./api/login/authenticate.php" method="post">
          <div class="form-floating mb-3">
            <input type="text" class="form-control" name="username" id="username" placeholder="Username" required autofocus>
            <label for="username"><i class="bi bi-person me-2"></i>Username</label>
          </div>
          <div class="form-floating mb-3">
            <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
            <label for="password"><i class="bi bi-lock-fill me-2"></i>Password</label>
          </div>
          <div class="d-flex justify-content-between align-items-center mb-4">
            <div class="form-check">
              <input class="form-check-input" type="checkbox" id="togglePassword">
              <label class="form-check-label small text-muted" for="togglePassword">Show Password</label>
            </div>
            <a href="#" class="small text-danger text-decoration-none fw-semibold">Forgot Password?</a>
          </div>
          <button type="submit" class="btn btn-primary btn-login w-100 text-white shadow-sm">
            LOG IN <i class="bi bi-arrow-right-short ms-1"></i>
          </button>
        </form>
        <div class="text-center mt-5">
          <p class="small text-muted mb-0 opacity-75">&copy; 2025 St. Theresa's School of Novaliches, Inc. All Rights Reserved.</p>
        </div>
      </div>
      <div class="info-side">
        <div class="decorative-circle"></div>
        <div class="info-content">
          <div class="vm-box">
            <div class="vm-title"><i class="bi bi-bullseye"></i> Our Vision</div>
            <p class="vm-text">
              A leading Catholic learning community that forms principled, innovative leaders who transform society through faith, excellence, and service.
            </p>
          </div>
          <div class="vm-box">
            <div class="vm-title"><i class="bi bi-compass-fill"></i> Our Mission</div>
            <p class="vm-text">
              We nurture every learner’s mind, heart, and spirit through rigorous academics, values-based formation, and collaborative outreach.
            </p>
          </div>
        </div>
        <div class="info-footer">
          <div class="footer-item"><i class="bi bi-geo-alt-fill"></i> 7 Kingfisher St., Zabarte Subd., Brgy. Kaligayahan, Novaliches, Quezon City, Philippines</div>
          <div class="footer-item"><i class="bi bi-telephone-fill"></i> +63 333 444 2232</div>
          <div class="footer-item mt-2 w-100 email-text">
            <i class="bi bi-envelope-fill"></i> stsngradingsys@gmail.com
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const toggleCheckbox = document.getElementById('togglePassword');
      const passwordInput = document.getElementById('password');
      toggleCheckbox.addEventListener('change', function() {
        passwordInput.type = this.checked ? 'text' : 'password';
      });

      const phpAlert = document.getElementById('php-alert');
      if (phpAlert) {
        setTimeout(() => {
          phpAlert.style.transition = 'opacity 0.5s';
          phpAlert.style.opacity = '0';
          setTimeout(() => phpAlert.remove(), 500);
        }, 3000);
      }
    });
    </script>
    <script>
      window.addEventListener('scroll', () => {
        document.getElementById('siteHeader').classList.toggle('scrolled', window.scrollY > 20);
      });
  </script>

</body>
</html>