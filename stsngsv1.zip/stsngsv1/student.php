<?php
require_once __DIR__ . '/api/shared/db_connect.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Students</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        @media (max-width: 767.98px) {
            #studentTable thead { display: none; }
            #studentTable tbody tr {
                display: block;
                border: 1px solid #dee2e6;
                margin-bottom: .5rem;
                border-radius: .25rem;
                padding: .5rem;
            }
            #studentTable tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                border: none !important;
                padding: .35rem .5rem;
            }
            #studentTable tbody td::before {
                content: attr(data-label);
                font-weight: 600;
                margin-right: .5rem;
                white-space: nowrap;
            }
            #studentTable tbody td:last-child {
                flex-direction: column;
                gap: .25rem;
            }
            #studentTable tbody td:last-child .btn {
                width: 100%;
                font-size: .9rem;
                padding: .4rem;
            }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6"><h3 class="mb-0"><i class="bi bi-person"></i> Students</h3></div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item">Users</li>
                            <li class="breadcrumb-item active">Students</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-4 m-3">
            <div class="card-header d-flex justify-content-between align-items-center flex-wrap">
                <h3 class="card-title mb-0">Student List</h3>
                <div class="d-flex align-items-center gap-2 ms-auto">
                    <input class="form-control form-control-sm" type="search" id="searchInput" placeholder="Search…">
                    <a href="student_form.php" class="btn btn-success btn-sm text-nowrap">
                        <i class="bi bi-plus-circle me-1"></i> New Student
                    </a>
                </div>
            </div>

            <div class="card-body">
                <div class="table-responsive-sm">
                    <table id="studentTable" class="table table-bordered table-hover align-middle mb-0 text-center">
                        <thead class="table-light">
                        <tr>
                            <th style="width:50px;">#</th>
                            <th>LRN</th>
                            <th>Name</th>
                            <th>Grade</th>
                            <th>Age</th>
                            <th>Sex</th>
                            <th>Guardian</th>
                            <th>Contact</th>
                            <th style="width:100px;">Status</th>
                            <th style="width:200px;">Actions</th>
                        </tr>
                        </thead>
                        <tbody id="studentTableBody"></tbody>
                    </table>
                </div>
            </div>

            <div class="card-footer clearfix">
                <ul class="pagination pagination-sm m-0 float-end" id="pagination"></ul>
            </div>
        </div>
    </main>

    <?php require_once("includes/footer.php"); ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script>
let currentPage = 1;
let searchTerm  = '';

function loadStudents(page = 1, search = ''){
    fetch(`api/student/read.php?p=${page}&s=${encodeURIComponent(search)}`)
        .then(r => r.json())
        .then(data => renderTable(data.students, data.page, data.pages))
        .catch(err => console.error('LOAD ERROR:', err));
}

function renderTable(list, page, pages){
    const tbody = document.getElementById('studentTableBody');
    const headers = Array.from(document.querySelectorAll('#studentTable thead th')).map(th => th.textContent);

    tbody.innerHTML = list.map((s, i) => `
        <tr>
            <td data-label="${headers[0]}">${((page-1)*10)+i+1}</td>
            <td data-label="${headers[1]}">${s.lrn}</td>
            <td data-label="${headers[2]}">${s.fname} ${s.mname||''} ${s.lname}</td>
            <td data-label="${headers[3]}">${s.grade_level_name}</td>
            <td data-label="${headers[4]}">${s.age}</td>
            <td data-label="${headers[5]}">${s.gender}</td>
            <td data-label="${headers[6]}">${s.guardian_name}</td>
            <td data-label="${headers[7]}"><a href="tel:${s.guardian_contact_num}}">${s.guardian_contact_num}</a></td>
            <td data-label="${headers[8]}">${s.is_active==1?'<span class="badge bg-success">Active</span>':'<span class="badge bg-secondary">Inactive</span>'}</td>
            <td data-label="${headers[9]}">
                <a href="student_form.php?id=${s.id}" class="btn btn-sm btn-warning me-1"><i class="bi bi-pencil-square"></i> Edit</a>
                <button class="btn btn-sm ${s.is_active==1?'btn-danger':'btn-outline-success'}"
                        onclick="toggleStudent(${s.id},${s.is_active})"
                        data-bs-toggle="tooltip" data-bs-placement="top"
                        title="${s.is_active==1?'Deactivate':'Activate'}">
                    <i class="bi ${s.is_active==1?'bi-toggle-off':'bi-toggle-on'}"></i> ${s.is_active==1?'Deactivate':'Activate'}
                </button>
            </td>
        </tr>`).join('');

    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(el => new bootstrap.Tooltip(el));

    const ul = document.getElementById('pagination');
    ul.innerHTML = '';
    for(let p = 1; p <= pages; p++){
        ul.innerHTML += `<li class="page-item ${p===page?'active':''}"><a class="page-link" href="#" onclick="loadStudents(${p},'${searchTerm}')">${p}</a></li>`;
    }
}

async function toggleStudent(id, currentState){
    const newStatus = currentState === 1 ? 0 : 1;
    const action    = newStatus === 1 ? 'Activate' : 'Deactivate';
    if (!confirm(`${action} this student?`)) return;

    try {
        const res = await fetch('api/student/toggle.php?id=' + id, { method: 'GET' });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const json = await res.json();
        if (json.success) {
            loadStudents(currentPage, searchTerm);
        } else {
            alert(json.error || 'Toggle failed');
        }
    } catch (err) {
        console.error(err);
        alert('Could not change status: ' + err.message);
    }
}

document.getElementById('searchInput').addEventListener('input', e => {
    searchTerm = e.target.value;
    currentPage = 1;
    loadStudents(currentPage, searchTerm);
});

document.addEventListener('DOMContentLoaded', () => loadStudents());
</script>
</body>
</html>