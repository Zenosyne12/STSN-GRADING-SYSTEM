<?php
/* api/accounts/update.php  –  quick field update (status only) */
error_reporting(E_ALL);
ini_set('display_errors', 0);          // keep JSON clean
header('Content-Type: application/json');

require_once __DIR__ . '/../shared/db_connect.php';   // gives $pdo

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$in = json_decode(file_get_contents('php://input'), true);
if (empty($in['id']) || !isset($in['status'])) {
    echo json_encode(['success' => false, 'error' => 'Missing id or status']);
    exit;
}

$id   = (int) $in['id'];
$stat = ($in['status'] === 'Active' ? 'Active' : 'Inactive'); // whitelist

try {
    $st = $pdo->prepare('UPDATE tblusers SET status = ? WHERE id = ?');
    $st->execute([$stat, $id]);

    if ($st->rowCount()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Account not found or no change']);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'DB error: ' . $e->getMessage()]);
}