<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$connect_path = __DIR__ . '/../../api/shared/db_connect.php';
if (!file_exists($connect_path)) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'db_connect.php not found at: ' . $connect_path]);
    exit;
}
require_once $connect_path;

// PHPMailer
$phpmailer_path = __DIR__ . '/../../api/shared/phpmailer.php';
if (!file_exists($phpmailer_path)) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'phpmailer.php not found']);
    exit;
}
require_once $phpmailer_path;

if (!isset($pdo) || $pdo === null) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => '$pdo not defined or connection failed']);
    exit;
}

header('Content-Type: application/json');
$data = json_decode(file_get_contents('php://input'), true);

if (empty($data['teacher_db_id']) || empty($data['username'])) {
    echo json_encode(['success' => false, 'error' => 'Missing required data']);
    exit;
}

$teacher_db_id = (int)$data['teacher_db_id'];
$username = trim($data['username']);

try {
    //  Fetch teacher sa manage accounts
    $stmt = $pdo->prepare("SELECT teacher_id, fname, lname, date_hired, email FROM tblteacher WHERE id = ?");
    $stmt->execute([$teacher_db_id]);
    $teacher = $stmt->fetch();

    if (!$teacher) {
        throw new Exception('Teacher not found');
    }

    if (empty($teacher['email'])) {
        throw new Exception('Teacher has no email address');
    }

    //  Generate temp password 
    $temp_password = strtolower(str_replace(' ', '', $teacher['lname'])) . str_replace('-', '', $teacher['date_hired']);
    $password_hash = password_hash($temp_password, PASSWORD_DEFAULT);

    // duplicate ng usernames
    $check_stmt = $pdo->prepare("SELECT id FROM tblusers WHERE username = ?");
    $check_stmt->execute([$username]);
    if ($check_stmt->fetch()) {
        throw new Exception('Username already exists');
    }

    // Insert sa tblusers
    $role_id = 2;
    $status = 'Active';
    $must_change_password = 1;

    $insert_stmt = $pdo->prepare("INSERT INTO tblusers (username, password_hash, role_id, reference_id, status, must_change_password) VALUES (?, ?, ?, ?, ?, ?)");
    $insert_stmt->execute([$username, $password_hash, $role_id, $teacher_db_id, $status, $must_change_password]);

    //  PHP mailer send
    $mail = createMailer();
    $mail->addAddress($teacher['email'], $teacher['fname'] . ' ' . $teacher['lname']);
    $mail->Subject = 'STSN Grading System - Account Created';
    $mail->Body = "
        <html>
        <body style='font-family: Arial, sans-serif; padding: 20px;'>
            <h2 style='color: #2c3e50;'>Welcome to STSN Grading System!</h2>
            <p>Hello {$teacher['fname']},</p>
            <p>Your account has been successfully created. Please use the following credentials to log in:</p>
            <div style='background: #f8f9fa; padding: 15px; border-left: 4px solid #007bff; margin: 20px 0;'>
                <p style='margin: 0;'><strong>Username:</strong> {$username}</p>
                <p style='margin: 0;'><strong>Temporary Password:</strong> {$temp_password}</p>
            </div>
            <p>We recommend changing your password after your first login.</p>
            <p>Best regards,<br>STSN Administration</p>
        </body>
        </html>
    ";
    $mail->AltBody = "Welcome {$teacher['fname']}!\n\nUsername: {$username}\nTemporary Password: {$temp_password}\n\nPlease change your password after logging in.\n\nSTSN Administration";

    if (!$mail->send()) {
        throw new Exception('Account created but email failed: ' . $mail->ErrorInfo);
    }

    // return
    echo json_encode([
        'success' => true,
        'username' => $username,
        'message' => 'Account created! Temporary password sent via email to ' . $teacher['email']
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>