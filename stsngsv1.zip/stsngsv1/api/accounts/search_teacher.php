<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$connect_path = __DIR__ . '/../../api/shared/db_connect.php';
if (!file_exists($connect_path)) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'db_connect.php not found at: ' . $connect_path]);
    exit;
}
require_once $connect_path;

if (!isset($pdo) || $pdo === null) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => '$pdo not defined or connection failed']);
    exit;
}

header('Content-Type: application/json');

$id = $_GET['id'] ?? '';
if (empty($id)) {
    echo json_encode(['success' => false, 'error' => 'No Teacher ID provided']);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT id, teacher_id, fname, lname, date_hired, email FROM tblteacher WHERE teacher_id = ? AND is_active = 1");
    $stmt->execute([$id]);
    $teacher = $stmt->fetch();

    if ($teacher) {
        echo json_encode([
            'success' => true,
            'teacher_db_id' => $teacher['id'],
            'teacher_id' => $teacher['teacher_id'],
            'fname' => $teacher['fname'],
            'lname' => $teacher['lname'],
            'birthdate' => $teacher['date_hired'],
            'email' => $teacher['email'] ?? ''
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Teacher not found or inactive']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Query failed: ' . $e->getMessage()]);
}
?>