<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
header('Content-Type: application/json');

require_once __DIR__ . '/../shared/db_connect.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$id) {
    echo json_encode(['success' => false, 'error' => 'No ID supplied']);
    exit;
}

try {
    $st = $pdo->prepare(
        "SELECT u.id, u.username, t.teacher_id,
                CONCAT(t.fname,' ',t.lname) AS name,
                CASE WHEN u.role_id = 1 THEN 'Admin' ELSE 'Teacher' END AS role,
                u.status, DATE(u.created_at) AS created
         FROM tblusers u
         LEFT JOIN tblteacher t ON t.id = u.reference_id
         WHERE u.id = ?"
    );
    $st->execute([$id]);
    $row = $st->fetch();
    if ($row) {
        echo json_encode(['success' => true, 'data' => $row]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Account not found']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Query failed: ' . $e->getMessage()]);
}