<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$connect_path = __DIR__ . '/../../api/shared/db_connect.php';
if (!file_exists($connect_path)) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'db_connect.php not found at: ' . $connect_path]);
    exit;
}
require_once $connect_path;

if (!isset($pdo) || $pdo === null) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => '$pdo not defined or connection failed']);
    exit;
}

header('Content-Type: application/json');

try {
    // CHANGED: FROM tblusers u
    $stmt = $pdo->prepare("
        SELECT u.id, u.username, t.teacher_id, CONCAT(upper(t.lname), ', ', t.fname) AS name, 
               CASE WHEN u.role_id = 1 THEN 'Admin' ELSE 'Teacher' END AS role, 
               u.status, DATE(u.created_at) AS created
        FROM tblusers u
        LEFT JOIN tblteacher t ON u.reference_id = t.id
        ORDER BY u.id DESC
    ");
    $stmt->execute();
    $data = $stmt->fetchAll();

    echo json_encode(['success' => true, 'data' => $data]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Query failed: ' . $e->getMessage()]);
}
?>