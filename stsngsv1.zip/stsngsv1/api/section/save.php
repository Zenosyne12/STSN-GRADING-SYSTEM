<?php
require_once __DIR__.'/../shared/db_connect.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

$id            = (int)($data['id'] ?? 0);
$section_code  = trim($data['section_code'] ?? '');
$section_name  = trim($data['section_name'] ?? '');
$description   = trim($data['description']  ?? '');

if ($section_code === '' || $section_name === '') {
    http_response_code(422);
    echo json_encode(['success'=>false,'error'=>'Code and Name required']);
    exit;
}

if ($id) { // update
    $stmt = $pdo->prepare("UPDATE tblsection
                           SET section_code = ?, section_name = ?, description = ?
                           WHERE id = ?");
    $stmt->execute([$section_code, $section_name, $description, $id]);
} else { // create
    $stmt = $pdo->prepare("INSERT INTO tblsection (section_code, section_name, description)
                           VALUES (?,?,?)");
    $stmt->execute([$section_code, $section_name, $description]);
}

echo json_encode(['success' => true]);