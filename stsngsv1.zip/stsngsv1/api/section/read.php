<?php
require_once __DIR__.'/../shared/db_connect.php';
header('Content-Type: application/json');

$search = isset($_GET['s']) ? trim($_GET['s']) : '';
$page   = max(1, (int)($_GET['p'] ?? 1));
$limit  = 10;
$offset = ($page - 1) * $limit;

$where  = '';
$params = [];
if ($search !== '') {
    $where = " WHERE (section_code LIKE :s OR section_name LIKE :s OR description LIKE :s) ";
    $params['s'] = "%$search%";
}

/* count */
$cnt = $pdo->prepare("SELECT COUNT(*) FROM tblsection $where");
$cnt->execute($params);
$total = (int)$cnt->fetchColumn();
$pages = max(1, ceil($total / $limit));

/* rows */
$sql = "SELECT id, section_code, section_name, description, is_active
        FROM tblsection
        $where
        ORDER BY id DESC
        LIMIT $offset,$limit";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);

echo json_encode([
    'sections' => $stmt->fetchAll(PDO::FETCH_ASSOC),
    'page'     => $page,
    'pages'    => $pages,
    'total'    => $total
]);