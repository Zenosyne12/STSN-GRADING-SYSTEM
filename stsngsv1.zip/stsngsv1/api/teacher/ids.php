<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$connect_path = __DIR__ . '/../../api/shared/db_connect.php';
if (!file_exists($connect_path)) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'db_connect.php not found']);
    exit;
}
require_once $connect_path;

if (!isset($pdo) || $pdo === null) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => '$pdo not defined']);
    exit;
}

header('Content-Type: application/json');

try {
    $stmt = $pdo->prepare("SELECT teacher_id FROM tblteacher WHERE is_active = 1 ORDER BY teacher_id ASC");
    $stmt->execute();
    $teacher_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);

    echo json_encode([
        'success' => true,
        'teacher_ids' => $teacher_ids
    ]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Query failed: ' . $e->getMessage()]);
}
?>