<?php
require_once __DIR__.'/../shared/db_connect.php';
header('Content-Type: application/json');

$search = isset($_GET['s']) ? trim($_GET['s']) : '';
$page   = max(1, (int)($_GET['p'] ?? 1));
$limit  = 10;
$offset = ($page - 1) * $limit;

$where  = '';
$params = [];
if ($search !== '') {
    $where = " WHERE teacher_id LIKE :s
              OR fname        LIKE :s
              OR mname        LIKE :s
              OR lname        LIKE :s
              OR email        LIKE :s ";
    $params['s'] = "%$search%";
}

/* ----------  COUNT  ---------- */
$cnt = $pdo->prepare("SELECT COUNT(*) FROM tblteacher $where");
$cnt->execute($params);
$total = (int)$cnt->fetchColumn();
$pages = max(1, ceil($total / $limit));

/* ----------  ROWS  ---------- */
$sql = "SELECT id, teacher_id, email, fname, mname, lname, date_hired, sex, contact_no, is_active
        FROM tblteacher
        $where
        ORDER BY lname ASC
        LIMIT $offset,$limit";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);

echo json_encode([
    'teachers' => $stmt->fetchAll(PDO::FETCH_ASSOC),
    'page'  => $page,
    'pages' => $pages,
    'total' => $total
]);

?>