<?php
require_once __DIR__ . '/../shared/db_connect.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

/* flip the active flag instead of hard-setting to 0 */
$stmt = $pdo->prepare("UPDATE tblteacher
                       SET is_active = 1 - is_active 
                       WHERE id = ?");
$stmt->execute([$id]);

header('Content-Type: application/json');
echo json_encode(['success' => $stmt->rowCount() > 0]);