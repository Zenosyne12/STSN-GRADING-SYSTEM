<?php
session_start();
require_once __DIR__ . '/../shared/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../../login.php');
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = $_POST['password']   ?? '';

if ($username === '' || $password === '') {
    header('Location: ../../login.php?e=1');
    exit;
}

// 1. Fetch User Details (including 'must_change_password')
$stmt = $pdo->prepare(
    "SELECT id, password_hash, reference_id, status, must_change_password 
     FROM tblusers 
     WHERE username = ? 
     LIMIT 1"
);
$stmt->execute([$username]);
$user = $stmt->fetch();

// 2. Verify Password
if ($user && password_verify($password, $user['password_hash'])) {
    
    // Check Status
    if ($user['status'] !== 'Active') {
        header('Location: ../../login.php?e=inactive');
        exit;
    }

    // Login Success: Set Session
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['reference_id'] = $user['reference_id'];
    $_SESSION['username'] = $username; 

    // ---------------------------------------------------------
    // 3. CHECK: FORCE CHANGE PASSWORD
    // ---------------------------------------------------------
    if ($user['must_change_password'] == 1) {
        // Redirect to the MAIN folder (Go up 2 levels)
        header('Location: ../../change-password.php');
        exit;
    }

    // ---------------------------------------------------------
    // 4. NORMAL ROUTING (If password change is NOT required)
    // ---------------------------------------------------------
    
    // If reference_id is empty -> ADMIN
    if (empty($user['reference_id'])) {
        header('Location: ../../index.php');
    } else {
        // If reference_id exists -> TEACHER
        header('Location: ../../teacher-dashboard.php');
    }
    exit;
}

// Login Failed
header('Location: ../../login.php?e=1');
exit;
?>