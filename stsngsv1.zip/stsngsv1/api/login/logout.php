<?php
session_start();
session_destroy();
// Use ../../ to go up from 'login' then up from 'api' to the root
header('Location: ../../login.php'); 
exit;
?>