<?php
session_start();
require_once __DIR__ . '/../shared/db_connect.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit;
}
$new_pass = $_POST['new_password'] ?? '';
$confirm_pass = $_POST['confirm_password'] ?? '';
if ($new_pass !== $confirm_pass) {
    echo "<script>alert('Passwords do not match'); window.location.href='../../change-password.php';</script>";
    exit;
}
if (strlen($new_pass) < 6) {
    echo "<script>alert('Password must be at least 6 characters'); window.location.href='../../change-password.php';</script>";
    exit;
}
$new_hash = password_hash($new_pass, PASSWORD_DEFAULT);
$stmt = $pdo->prepare("UPDATE tblusers SET password_hash = ?, must_change_password = 0 WHERE id = ?");
$stmt->execute([$new_hash, $_SESSION['user_id']]);
if (empty($_SESSION['reference_id'])) {
    header('Location: ../../index.php');
} else {
    header('Location: ../../teacher-dashboard.php');
}
exit;
?>