<?php
require_once __DIR__.'/../shared/db_connect.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$id = (int)($data['id'] ?? 0);
$on = (int)($data['is_active'] ?? 0);

if (!$id) { http_response_code(400); exit(json_encode(['success'=>false,'error'=>'Bad ID'])); }

try {
    $pdo->beginTransaction();

    /* 1.  disable ALL years */
    $pdo->exec("UPDATE tblacademicyear SET is_active = 0");

    /* 2.  enable only the chosen one */
    $stmt = $pdo->prepare("UPDATE tblacademicyear SET is_active = 1 WHERE id = ?");
    $stmt->execute([$id]);

    $pdo->commit();
    echo json_encode(['success'=>true]);
} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}