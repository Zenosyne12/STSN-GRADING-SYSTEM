<?php
require_once __DIR__.'/../shared/db_connect.php';
header('Content-Type: application/json');

$search = isset($_GET['s']) ? trim($_GET['s']) : '';
$page   = max(1, (int)($_GET['p'] ?? 1));
$limit  = 10;
$offset = ($page - 1) * $limit;

$where = '';
$params = [];
if ($search !== '') {
    $where = ' WHERE year_label LIKE :s ';
    $params['s'] = "%$search%";
}

/* ----------  count  ---------- */
$cnt = $pdo->prepare("SELECT COUNT(*) FROM tblacademicyear $where");
$cnt->execute($params);
$total = (int)$cnt->fetchColumn();
$pages = max(1, ceil($total / $limit));

/* ----------  rows  ---------- */
$sql = "SELECT id, year_label, is_active
        FROM tblacademicyear
        $where
        ORDER BY year_label DESC
        LIMIT $offset,$limit";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);

echo json_encode([
    'success' => true,
    'years'   => $stmt->fetchAll(PDO::FETCH_ASSOC),
    'page'    => $page,
    'pages'   => $pages
]);