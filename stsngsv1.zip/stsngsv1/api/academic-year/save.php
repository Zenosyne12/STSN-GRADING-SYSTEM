<?php
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

$data  = json_decode(file_get_contents('php://input'), true);
$label = trim($data['year_label'] ?? '');
$id    = intval($data['id'] ?? 0);

if ($label === '') {
    echo json_encode(['success' => false, 'error' => 'Year label required']);
    exit;
}

try {
    if ($id === 0) {                 // NEW
        $pdo->exec('UPDATE tblAcademicYear SET is_active = 0');
        $stmt = $pdo->prepare('INSERT INTO tblAcademicYear (year_label, is_active) VALUES (?, 1)');
        $stmt->execute([$label]);
    } else {                         // EDIT
        $stmt = $pdo->prepare('UPDATE tblAcademicYear SET year_label = ? WHERE id = ?');
        $stmt->execute([$label, $id]);
    }
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}