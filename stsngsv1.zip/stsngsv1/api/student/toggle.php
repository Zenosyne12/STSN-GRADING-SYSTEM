<?php
require_once __DIR__.'/../shared/db_connect.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id) {
    $pdo->prepare('UPDATE tblStudents SET is_active = NOT is_active WHERE id = ?')->execute([$id]);
}
echo json_encode(['success' => true]);