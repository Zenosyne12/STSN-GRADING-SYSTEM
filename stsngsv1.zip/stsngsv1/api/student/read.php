<?php
require_once __DIR__.'/../shared/db_connect.php';

header('Content-Type: application/json; charset=utf-8');

$page   = isset($_GET['p'])   ? max(1,(int)$_GET['p'])  : 1;
$search = isset($_GET['s'])   ? trim($_GET['s'])        : '';
$limit  = 10;
$offset = ($page-1)*$limit;

/* ---- count ALL students (no is_active filter) ---- */
$cnt = $pdo->prepare("SELECT COUNT(*) 
                      FROM vwStudentInfo 
                      WHERE (fname LIKE :s OR lname LIKE :s OR lrn LIKE :s)");
$cnt->execute(['s'=>"%$search%"]);
$total = (int)$cnt->fetchColumn();
$pages = max(1, ceil($total/$limit));

/* ---- fetch ALL students ---- */
$stmt = $pdo->prepare(
   "SELECT id, lrn, fname, mname, lname, birthdate, gender, citizenship, grade_level_name,
           guardian_name, guardian_contact_num,
           TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) AS age,
           CONCAT_WS(', ', street_name, barangay_name, city_name, province_name, region_name, country_name) AS full_address,
           is_active
    FROM vwStudentInfo
    WHERE (fname LIKE :s OR lname LIKE :s OR lrn LIKE :s)
    ORDER BY lname ASC
    LIMIT :offset, :limit");
$stmt->bindValue(':s', "%$search%", PDO::PARAM_STR);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->bindValue(':limit',  $limit,  PDO::PARAM_INT);
$stmt->execute();

echo json_encode([
    'students' => $stmt->fetchAll(PDO::FETCH_ASSOC),
    'page'     => $page,
    'pages'    => $pages
]);