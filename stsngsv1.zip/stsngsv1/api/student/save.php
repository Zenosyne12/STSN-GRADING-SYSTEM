<?php
require_once '../shared/db_connect.php';

/* ---------- required fields ---------- */
$req = ['lrn','grade_level_id','fname','lname','birthdate','gender',
        'fathers_name','fathers_contact_num','mothers_name','mothers_contact_num',
        'guardian_name','guardian_contact_num','street_name','barangay_id','city_id',
        'province_id','region_id','country_id'];
foreach ($req as $f) if (empty($_POST[$f])) { http_response_code(400); exit("Missing $f"); }

$id          = (int)($_POST['id'] ?? 0);          // 0 = insert
$mname       = $_POST['mname'] ?? '';
$postal_code = $_POST['postal_code'] ?? '';

/* ---------- common data ---------- */
$data = [
    'lrn'                  => $_POST['lrn'],
    'grade_level_id'       => $_POST['grade_level_id'],
    'fname'                => $_POST['fname'],
    'mname'                => $mname,
    'lname'                => $_POST['lname'],
    'birthdate'            => $_POST['birthdate'],
    'gender'               => $_POST['gender'],
    'citizenship'          => $_POST['citizenship'] ?? 'Filipino',
    'fathers_name'         => $_POST['fathers_name'],
    'fathers_contact_num'  => $_POST['fathers_contact_num'],
    'mothers_name'         => $_POST['mothers_name'],
    'mothers_contact_num'  => $_POST['mothers_contact_num'],
    'guardian_name'        => $_POST['guardian_name'],
    'guardian_contact_num' => $_POST['guardian_contact_num'],
    'street_name'          => $_POST['street_name'],
    'postal_code'          => $postal_code,
    'barangay_id'          => $_POST['barangay_id'],
    'city_id'              => $_POST['city_id'],
    'province_id'          => $_POST['province_id'],
    'region_id'            => $_POST['region_id'],
    'country_id'           => $_POST['country_id'],
    'is_active'            => 1
];
if (!$id) {
    $chk = $pdo->prepare("SELECT id FROM tblStudents WHERE lrn = :lrn");
    $chk->execute(['lrn' => $data['lrn']]);
    if ($chk->fetchColumn()) {
        header("Location: ../../student_form.php?duplicate=1");
        exit;
    }
}
if ($id) {                  // UPDATE
    $set = implode(', ', array_map(fn($k) => "$k = :$k", array_keys($data)));
    $sql = "UPDATE tblStudents SET $set WHERE id = :id";
    $data['id'] = $id;
} else {                    // INSERT
    $keys = implode(', ', array_keys($data));
    $placeholders = implode(', ', array_map(fn($k) => ":$k", array_keys($data)));
    $sql = "INSERT INTO tblStudents ($keys) VALUES ($placeholders)";
}

$stmt = $pdo->prepare($sql);
$stmt->execute($data);

header('Location: ../../student.php?' . ($id ? 'updated' : 'added') . '=1');
exit;