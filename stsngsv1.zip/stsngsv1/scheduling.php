<?php
require_once __DIR__ . '/api/shared/db_connect.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Schedule</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <!-- =====  RESPONSIVE-CARD STYLES (copied from subject.php)  ===== -->
    <style>
        @media (max-width: 767.98px) {
            #schedTable thead { display: none; }
            #schedTable tbody tr {
                display: block;
                border: 1px solid #dee2e6;
                margin-bottom: .5rem;
                border-radius: .25rem;
                padding: .5rem;
            }
            #schedTable tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                border: none !important;
                padding: .35rem .5rem;
            }
            #schedTable tbody td::before {
                content: attr(data-label);
                font-weight: 600;
                margin-right: .5rem;
                white-space: nowrap;
            }
            #schedTable tbody td:last-child {
                flex-direction: column;
                gap: .25rem;
            }
            #schedTable tbody td:last-child .btn {
                width: 100%;
                font-size: .9rem;
                padding: .4rem;
            }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6"><h3 class="mb-0"><i class="bi bi-calendar3"></i> Schedule</h3></div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item">Academic</li>
                            <li class="breadcrumb-item active">Schedule</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-4 m-3">
            <div class="card-header d-flex justify-content-between align-items-center flex-wrap">
                <h3 class="card-title mb-0">Schedule List</h3>
                <div class="d-flex align-items-center gap-2 ms-auto">
                    <input class="form-control form-control-sm" type="search" id="searchInput" placeholder="Search…">
                    <button class="btn btn-success btn-sm text-nowrap" data-bs-toggle="modal" data-bs-target="#scheduleModal">
                        <i class="bi bi-plus-circle me-1"></i> New Schedule
                    </button>
                </div>
            </div>

            <div class="card-body">
                <!-- desktop table -->
                <div class="table-responsive d-none d-md-block">
                    <table id="schedTable" class="table table-bordered table-hover align-middle text-center mb-0">
                        <thead class="table-light">
                        <tr>
                            <th style="width:50px;">#</th>
                            <th>Day</th><th>Time</th><th>Room</th>
                            <th>Teacher</th><th>Subject</th><th>Section</th>
                            <th style="width:120px;">Status</th>
                            <th style="width:200px;">Actions</th>
                        </tr>
                        </thead>
                        <tbody id="schedTableBody"></tbody>
                    </table>
                </div>

                <!-- phone cards -->
                <div class="d-block d-md-none" id="cardView"></div>
            </div>

            <div class="card-footer clearfix">
                <ul class="pagination pagination-sm m-0 float-end" id="pagination"></ul>
            </div>
        </div>
    </main>

    <?php require_once("includes/footer.php"); ?>
</div>

<!-- Modal -->
<div class="modal fade" id="scheduleModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="false">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form id="scheduleForm">
        <div class="modal-header">
          <h5 class="modal-title" id="modalTitle">Add Schedule</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="schedId">
          <div class="row g-2">
            <div class="col-md-6"><label class="form-label">Teacher</label>
              <select class="form-select" id="teacher" required></select></div>
            <div class="col-md-6"><label class="form-label">Subject</label>
              <select class="form-select" id="subject" required></select></div>
            <div class="col-md-6"><label class="form-label">Section</label>
              <select class="form-select" id="section" required></select></div>
            <div class="col-md-6"><label class="form-label">Room</label>
              <input type="text" class="form-control" id="room" required></div>
            <div class="col-md-6"><label class="form-label">Day</label>
              <select class="form-select" id="day" required>
                <option>Mon</option><option>Tue</option><option>Wed</option><option>Thu</option><option>Fri</option><option>Sat</option><option>Sun</option>
              </select></div>
            <div class="col-md-3"><label class="form-label">Start</label>
              <input type="time" class="form-control" id="start" required></div>
            <div class="col-md-3"><label class="form-label">End</label>
              <input type="time" class="form-control" id="end" required></div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-success">Save</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script>
let currentPage = 1;
let searchTerm  = '';

/* ----------  LOAD  ---------- */
function loadSched(page = 1, search = ''){
    fetch(`api/schedule/read.php?p=${page}&s=${encodeURIComponent(search)}`)
        .then(r => r.json())
        .then(d => renderTable(d.schedules || [], d.page, d.pages));
}

/* ----------  RENDER  ---------- */
function renderTable(list, page, pages){
    const headers = ['#','Day','Time','Room','Teacher','Subject','Section','Status','Actions'];

    /* ---- desktop rows ---- */
    const row = (s, i) => `
        <tr>
            <td data-label="${headers[0]}">${((page-1)*10)+i+1}</td>
            <td data-label="${headers[1]}">${s.day}</td>
            <td data-label="${headers[2]}">${s.start_time} - ${s.end_time}</td>
            <td data-label="${headers[3]}">${s.room}</td>
            <td data-label="${headers[4]}">${s.teacher_name}</td>
            <td data-label="${headers[5]}">${s.subject_code}</td>
            <td data-label="${headers[6]}">${s.section_name}</td>
            <td data-label="${headers[7]}">
                <span class="badge bg-${s.is_active?'success':'secondary'}">${s.is_active?'Active':'Inactive'}</span>
            </td>
            <td data-label="${headers[8]}">
                <button class="btn btn-sm btn-warning me-1" onclick="editSched(${s.id})"><i class="bi bi-pencil-square"></i> Edit</button>
                <button class="btn btn-sm ${s.is_active?'btn-danger':'btn-outline-success'}" onclick="toggleSched(${s.id},${s.is_active})">
                    <i class="bi ${s.is_active?'bi-toggle-off':'bi-toggle-on'}"></i> ${s.is_active?'Deactivate':'Activate'}
                </button>
            </td>
        </tr>`;

    /* ---- phone cards ---- */
    const card = (s, i) => `
        <div class="card mb-3 shadow-sm">
            <div class="card-header bg-light d-flex justify-content-between">
                <span class="fw-bold">${s.day} ${s.start_time}-${s.end_time}</span>
                <span class="badge bg-${s.is_active?'success':'secondary'}">${s.is_active?'Active':'Inactive'}</span>
            </div>
            <div class="card-body py-2 small">
                <div class="row mb-1"><div class="col-4 text-muted">Room</div><div class="col-8">${s.room}</div></div>
                <div class="row mb-1"><div class="col-4 text-muted">Teacher</div><div class="col-8">${s.teacher_name}</div></div>
                <div class="row mb-1"><div class="col-4 text-muted">Subject</div><div class="col-8">${s.subject_code}</div></div>
                <div class="row mb-1"><div class="col-4 text-muted">Section</div><div class="col-8">${s.section_name}</div></div>
            </div>
            <div class="card-footer d-grid gap-2">
                <button class="btn btn-sm btn-warning" onclick="editSched(${s.id})"><i class="bi bi-pencil-square"></i> Edit</button>
                <button class="btn btn-sm ${s.is_active?'btn-danger':'btn-outline-success'}" onclick="toggleSched(${s.id},${s.is_active})">
                    <i class="bi ${s.is_active?'bi-toggle-off':'bi-toggle-on'}"></i> ${s.is_active?'Deactivate':'Activate'}
                </button>
            </div>
        </div>`;

    document.getElementById('schedTableBody').innerHTML = list.map(row).join('');
    document.getElementById('cardView').innerHTML       = list.map(card).join('');

    let p = '';
    for (let i = 1; i <= pages; i++) p += `<li class="page-item ${i === page ? 'active' : ''}"><a class="page-link" href="#" onclick="loadSched(${i}, searchTerm)">${i}</a></li>`;
    document.getElementById('pagination').innerHTML = p;
}

/* ----------  FILL DROP-DOWNS  ---------- */
fetch('api/schedule/read_dd.php').then(r => r.json()).then(d => {
    const opt = (a, f) => a.map(x => `<option value="${x.id}">${x[f]}</option>`).join('');
    document.getElementById('teacher').innerHTML = opt(d.teachers, 'teacher_name');
    document.getElementById('subject').innerHTML = opt(d.subjects,  'subject_name');
    document.getElementById('section').innerHTML = opt(d.sections,  'section_name');
});

/* ----------  ADD / EDIT  ---------- */
document.getElementById('scheduleForm').addEventListener('submit', e => {
    e.preventDefault();
    const data = {
        id: document.getElementById('schedId').value || undefined,
        teacher_id: document.getElementById('teacher').value,
        subject_id: document.getElementById('subject').value,
        section_id: document.getElementById('section').value,
        room: document.getElementById('room').value,
        day: document.getElementById('day').value,
        start_time: document.getElementById('start').value,
        end_time: document.getElementById('end').value
    };
    fetch('api/schedule/save.php', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify(data)
    })
        .then(r => r.json())
        .then(res => {
            if (res.success) {
                bootstrap.Modal.getInstance(document.getElementById('scheduleModal')).hide();
                loadSched(currentPage, searchTerm);
                e.target.reset();
            } else {
                alert(res.error || 'Save failed');
            }
        });
});

function editSched(id){
    fetch(`api/schedule/fetch.php?id=${id}`).then(r => r.json()).then(d => {
        document.getElementById('schedId').value      = id;
        document.getElementById('teacher').value      = d.teacher_id;
        document.getElementById('subject').value      = d.subject_id;
        document.getElementById('section').value      = d.section_id;
        document.getElementById('room').value         = d.room;
        document.getElementById('day').value          = d.day;
        document.getElementById('start').value        = d.start_time;
        document.getElementById('end').value          = d.end_time;
        document.getElementById('modalTitle').textContent = 'Edit Schedule';
        new bootstrap.Modal(document.getElementById('scheduleModal')).show();
    });
}

async function toggleSched(id, cur){
    const n   = cur ? 0 : 1;
    const act = n ? 'Activate' : 'Deactivate';
    if (!confirm(`${act} this schedule?`)) return;
    try {
        const r = await fetch('api/schedule/toggle.php', {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({id:id, is_active:n})
        });
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const j = await r.json();
        if (j.success) loadSched(currentPage, searchTerm);
        else alert(j.error || 'Toggle failed');
    } catch (e) { alert('Could not change status: '+e.message); }
}

/* ----------  SEARCH  ---------- */
document.getElementById('searchInput').addEventListener('input', e => {
    searchTerm = e.target.value;
    currentPage = 1;
    loadSched(currentPage, searchTerm);
});

/* ----------  RESET MODAL  ---------- */
document.getElementById('scheduleModal').addEventListener('hidden.bs.modal', () => {
    document.getElementById('scheduleForm').reset();
    document.getElementById('schedId').value = '';
    document.getElementById('modalTitle').textContent = 'Add Schedule';
});

/* ----------  INIT  ---------- */
loadSched();
</script>
</body>
</html>