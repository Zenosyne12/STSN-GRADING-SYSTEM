<?php
require_once __DIR__ . '/api/shared/db_connect.php';
?>
<!doctype html>
<html lang="en">
<!-- ===== SECTION: HEAD ===== -->
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Subjects</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        @media (max-width: 767.98px) {
            #subjectTable thead { display: none; }
            #subjectTable tbody tr {
                display: block;
                border: 1px solid #dee2e6;
                margin-bottom: .5rem;
                border-radius: .25rem;
                padding: .5rem;
            }
            #subjectTable tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                border: none !important;
                padding: .35rem .5rem;
            }
            #subjectTable tbody td::before {
                content: attr(data-label);
                font-weight: 600;
                margin-right: .5rem;
                white-space: nowrap;
            }
            #subjectTable tbody td:last-child {
                flex-direction: column;
                gap: .25rem;
            }
            #subjectTable tbody td:last-child .btn {
                width: 100%;
                font-size: .9rem;
                padding: .4rem;
            }
        }
    </style>
</head>

<!-- ===== SECTION: BODY ===== -->
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6"><h3 class="mb-0"><i class="nav-icon bi bi-book"></i> Subject Page</h3></div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item">Academic</li>
                            <li class="breadcrumb-item active">Subjects</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        
    </main>

    <?php require_once("includes/footer.php"); ?>
</div>



<!-- ===== SECTION: SCRIPTS ===== -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script>
/* ==========  ALL JS IN ONE PLACE  ========== */
let currentPage = 1;
let searchTerm  = '';

/* ----------  LOAD  ---------- */
function loadSubjects(page = 1, search = ''){
    fetch(`api/subject/read.php?p=${page}&s=${encodeURIComponent(search)}`)
        .then(r => r.json())
        .then(data => renderTable(data.subjects || [], data.page, data.pages));
}

/* ----------  RENDER  ---------- */
function renderTable(list, page, pages){
    const headers = ['#','Subject Code','Subject Name','Description','Status','Actions'];

    /* desktop row */
    const row = (s,i) => `
        <tr>
            <td data-label="${headers[0]}">${((page-1)*10)+i+1}</td>
            <td data-label="${headers[1]}">${s.subject_code}</td>
            <td data-label="${headers[2]}">${s.subject_name}</td>
            <td data-label="${headers[3]}">${s.description||'-'}</td>
            <td data-label="${headers[4]}">
                <span class="badge bg-${s.is_active?'success':'secondary'}">${s.is_active?'Active':'Inactive'}</span>
            </td>
            <td data-label="${headers[5]}">
                <button class="btn btn-sm btn-warning me-1" onclick="editSubject(${s.id})">
                    <i class="bi bi-pencil-square"></i> Edit
                </button>
                <button class="btn btn-sm ${s.is_active?'btn-danger':'btn-outline-success'}"
                        onclick="toggleSubject(${s.id},${s.is_active})"
                        title="${s.is_active?'Deactivate':'Activate'}">
                    <i class="bi ${s.is_active?'bi-toggle-off':'bi-toggle-on'}"></i>
                    ${s.is_active?'Deactivate':'Activate'}
                </button>
            </td>
        </tr>`;

    /* phone card */
    const card = (s,i) => `
        <div class="card mb-3 shadow-sm">
            <div class="card-header bg-light d-flex justify-content-between">
                <span class="fw-bold">${((page-1)*10)+i+1}. ${s.subject_name}</span>
                <span class="badge bg-${s.is_active?'success':'secondary'}">${s.is_active?'Active':'Inactive'}</span>
            </div>
            <div class="card-body py-2 small">
                <div class="row mb-1"><div class="col-4 text-muted">Code</div><div class="col-8">${s.subject_code}</div></div>
                <div class="row mb-1"><div class="col-4 text-muted">Description</div><div class="col-8">${s.description||'-'}</div></div>
            </div>
            <div class="card-footer d-grid gap-2">
                <button class="btn btn-sm btn-warning" onclick="editSubject(${s.id})"><i class="bi bi-pencil-square"></i> Edit</button>
                <button class="btn btn-sm ${s.is_active?'btn-danger':'btn-outline-success'}"
                        onclick="toggleSubject(${s.id},${s.is_active})"
                        title="${s.is_active?'Deactivate':'Activate'}">
                    <i class="bi ${s.is_active?'bi-toggle-off':'bi-toggle-on'}"></i> ${s.is_active?'Deactivate':'Activate'}
                </button>
            </div>
        </div>`;

    document.getElementById('subjectTableBody').innerHTML = list.map(row).join('');
    document.getElementById('cardView').innerHTML        = list.map(card).join('');

    /* pagination */
    let p = '';
    for(let i=1;i<=pages;i++){
        p += `<li class="page-item ${i===page?'active':''}"><a class="page-link" href="#" onclick="loadSubjects(${i},searchTerm)">${i}</a></li>`;
    }
    document.getElementById('pagination').innerHTML = p;
}

/* ----------  ADD / EDIT  ---------- */
document.getElementById('subjectForm').addEventListener('submit', e => {
    e.preventDefault();
    const id = document.getElementById('subjectId').value;
    const payload = {
        id: id || undefined,
        subject_code: document.getElementById('subjectCode').value.trim(),
        subject_name: document.getElementById('subjectName').value.trim(),
        description:  document.getElementById('subjectDesc').value.trim()
    };

    fetch('api/subject/save.php',{
        method : 'POST',
        headers: {'Content-Type':'application/json'},
        body   : JSON.stringify(payload)
    })
    .then(r => r.json())
    .then(res => {
        if(res.success){
            bootstrap.Modal.getInstance(document.getElementById('subjectModal')).hide();
            loadSubjects(currentPage, searchTerm);
            e.target.reset();
        }else{
            alert(res.error || 'Save failed');
        }
    });
});

function editSubject(id){
    fetch(`api/subject/fetch.php?id=${id}`)
        .then(r => r.json())
        .then(data => {
            document.getElementById('subjectId').value   = data.id;
            document.getElementById('subjectCode').value = data.subject_code;
            document.getElementById('subjectName').value = data.subject_name;
            document.getElementById('subjectDesc').value = data.description || '';
            document.getElementById('modalTitle').textContent = 'Edit Subject';
            new bootstrap.Modal(document.getElementById('subjectModal')).show();
        });
}

/* ----------  TOGGLE STATUS  ---------- */
async function toggleSubject(id, currentState){
    const newStatus = currentState ? 0 : 1;
    const action    = newStatus ? 'Activate' : 'Deactivate';
    if(!confirm(`${action} this subject?`)) return;

    try{
        const res = await fetch('api/subject/toggle.php',{
            method : 'POST',
            headers: {'Content-Type':'application/json'},
            body   : JSON.stringify({id, is_active:newStatus})
        });
        if(!res.ok) throw new Error(`HTTP ${res.status}`);
        const json = await res.json();
        if(json.success){
            loadSubjects(currentPage, searchTerm);
        }else{
            alert(json.error || 'Toggle failed');
        }
    }catch(err){
        console.error(err);
        alert('Could not change status: '+err.message);
    }
}

/* ----------  SEARCH  ---------- */
document.getElementById('searchInput').addEventListener('input', e => {
    searchTerm = e.target.value;
    currentPage = 1;
    loadSubjects(currentPage, searchTerm);
});

/* ----------  RESET MODAL  ---------- */
document.getElementById('subjectModal').addEventListener('hidden.bs.modal', () => {
    document.getElementById('subjectForm').reset();
    document.getElementById('subjectId').value = '';
    document.getElementById('modalTitle').textContent = 'Add Subject';
});

/* ----------  INIT  ---------- */
loadSubjects();
</script>
</body>
</html>