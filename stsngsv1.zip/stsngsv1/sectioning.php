<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/api/shared/db_connect.php';

// Check if connection exists
if (!isset($pdo) || $pdo === null) {
    die("Database connection failed. Please check your database configuration.");
}

// Get all grade levels
$gradeLevels = [];
$gradeStmt = $pdo->query("SELECT id, grade_level_name FROM tblgradelevel ORDER BY id");
while ($grade = $gradeStmt->fetch()) {
    $gradeLevels[] = $grade;
}

// Define level categories
$levelCategories = [
    'kinder' => [
        'name' => 'Kindergarten',
        'grade_ids' => [1],
        'icon' => 'bi-emoji-smile',
        'color' => 'warning'
    ],
    'elementary' => [
        'name' => 'Elementary',
        'grade_ids' => [2, 3, 4, 5, 6, 7],
        'icon' => 'bi-book',
        'color' => 'info'
    ],
    'highschool' => [
        'name' => 'High School',
        'grade_ids' => [8, 9, 10, 11, 12, 13],
        'icon' => 'bi-mortarboard',
        'color' => 'success'
    ]
];

// Get all sections
$sections = [];
$secStmt = $pdo->query("SELECT * FROM tblsection WHERE is_active = 1 ORDER BY section_name");
while ($section = $secStmt->fetch()) {
    $sections[$section['id']] = $section;
}

// Get assignments for all sections
$assignments = [];
$assignStmt = $pdo->query("
    SELECT 
        ta.section_id,
        CONCAT(t.fname, ' ', t.lname) AS teacher_name,
        s.subject_name
    FROM tblteacher_assignment ta
    LEFT JOIN tblteacher t ON ta.teacher_id = t.id
    LEFT JOIN tblsubjects s ON ta.subject_id = s.id
    WHERE ta.is_active = 1
");
while ($assign = $assignStmt->fetch()) {
    $assignments[$assign['section_id']][] = $assign;
}

// Map sections to grade levels (you should add grade_level_id to tblsection)
$sectionGrades = [];
foreach ($sections as $id => $section) {
    $name = strtolower($section['section_name']);
    $code = strtolower($section['section_code']);
    
    if (strpos($name, 'kinder') !== false || strpos($code, 'kinder') !== false) {
        $sectionGrades[$id] = 1;
    } elseif (preg_match('/(grade|gr)[\s-]*([1-6])/i', $name, $matches) || preg_match('/(grade|gr)[\s-]*([1-6])/i', $code, $matches)) {
        $gradeNum = isset($matches[2]) ? intval($matches[2]) : 0;
        if ($gradeNum >= 1 && $gradeNum <= 6) {
            $sectionGrades[$id] = $gradeNum + 1;
        }
    } elseif (preg_match('/(grade|gr)[\s-]*([7-9]|1[0-2])/i', $name, $matches) || preg_match('/(grade|gr)[\s-]*([7-9]|1[0-2])/i', $code, $matches)) {
        $gradeNum = isset($matches[2]) ? intval($matches[2]) : 0;
        if ($gradeNum >= 7 && $gradeNum <= 12) {
            $sectionGrades[$id] = $gradeNum + 1;
        }
    } else {
        static $counter = 0;
        $gradeIds = [2,3,4,5,6,7,8,9,10,11,12,13];
        $sectionGrades[$id] = $gradeIds[$counter % count($gradeIds)];
        $counter++;
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Sectioning</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        /* Level Cards */
        .level-card {
            background: #ffffff;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 20px;
            cursor: pointer;
            transition: all 0.2s;
            height: 100%;
            text-align: center;
        }
        .level-card:hover { 
            border-color: #0d6efd; 
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,.05);
        }
        .level-card.active { 
            border-color: #0d6efd;
            background-color: #f0f7ff;
        }
        .level-icon { font-size: 2rem; color: #0d6efd; margin-bottom: 8px; }
        .level-title { font-weight: 600; font-size: 1.1rem; }
        .level-count { font-size: .85rem; color: #6c757d; }

        /* Content Areas */
        .level-content { display: none; }
        .level-content.active { display: block; animation: fadeIn 0.3s; }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        /* Grade Headers */
        .grade-section {
            margin-bottom: 20px;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            overflow: hidden;
        }
        .grade-header {
            background: #f8f9fa;
            padding: 12px 15px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #dee2e6;
            transition: background 0.2s;
        }
        .grade-header:hover {
            background: #e9ecef;
        }
        .grade-header i {
            transition: transform 0.2s;
        }
        .grade-header.active i {
            transform: rotate(90deg);
        }
        .grade-badge {
            background: #6c757d;
            color: white;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.8rem;
        }

        /* Sections Grid */
        .grade-sections {
            display: none;
            padding: 15px;
            background: white;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 15px;
        }
        .grade-sections.show { 
            display: grid; 
        }

        /* Section Cards */
        .section-card {
            background: white;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            padding: 15px;
            transition: all 0.2s;
        }
        .section-card:hover {
            border-color: #0d6efd;
            box-shadow: 0 2px 8px rgba(0,0,0,.05);
        }
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 10px;
        }
        .section-name {
            font-weight: 600;
            font-size: 1rem;
            color: #212529;
        }
        .section-code {
            font-size: 0.8rem;
            color: #6c757d;
            margin-top: 2px;
        }
        .section-actions {
            display: flex;
            gap: 5px;
        }
        .btn-icon {
            padding: 4px 8px;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            background: white;
            color: #495057;
            cursor: pointer;
            text-decoration: none;
            font-size: 0.85rem;
            transition: all 0.2s;
        }
        .btn-icon:hover {
            background: #f8f9fa;
            border-color: #0d6efd;
            color: #0d6efd;
        }
        .btn-icon.assign:hover {
            background: #28a745;
            border-color: #28a745;
            color: white;
        }

        /* Subject Tags */
        .subject-tags {
            margin-top: 10px;
            display: flex;
            flex-wrap: wrap;
            gap: 5px;
        }
        .subject-tag {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.75rem;
            color: #495057;
        }
        .subject-tag small {
            color: #6c757d;
            margin-left: 3px;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px;
            background: #f8f9fa;
            border-radius: 6px;
            color: #6c757d;
        }
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 10px;
        }

        /* Navigation */
        .nav-links {
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6">
                        <h3 class="mb-0"><i class="bi bi-diagram-3"></i> Sectioning</h3>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item">Academic</li>
                            <li class="breadcrumb-item active">Sectioning</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="app-content">
            <div class="container-fluid">
                <!-- Navigation -->
                <div class="nav-links">
                    <a href="section.php" class="btn btn-primary btn-sm">
                        <i class="bi bi-building"></i> Manage Sections
                    </a>
                    <a href="assign.php" class="btn btn-success btn-sm">
                        <i class="bi bi-person-check"></i> Assign Teachers
                    </a>
                </div>

                <!-- Level Cards -->
                <div class="row mb-4">
                    <?php foreach ($levelCategories as $key => $category): ?>
                        <div class="col-md-4">
                            <div class="level-card <?php echo $key === 'kinder' ? 'active' : ''; ?>" data-level="<?php echo $key; ?>">
                                <div class="level-icon"><i class="bi <?php echo $category['icon']; ?>"></i></div>
                                <div class="level-title"><?php echo $category['name']; ?></div>
                                <div class="level-count">
                                    <?php 
                                    $count = 0;
                                    foreach ($sectionGrades as $sid => $gid) {
                                        if (in_array($gid, $category['grade_ids'])) $count++;
                                    }
                                    echo $count . ' sections';
                                    ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Level Content -->
                <?php foreach ($levelCategories as $levelKey => $category): ?>
                    <div class="level-content <?php echo $levelKey === 'kinder' ? 'active' : ''; ?>" id="content-<?php echo $levelKey; ?>">
                        
                        <?php foreach ($category['grade_ids'] as $gradeId): 
                            // Find grade name
                            $gradeName = '';
                            foreach ($gradeLevels as $g) {
                                if ($g['id'] == $gradeId) {
                                    $gradeName = $g['grade_level_name'];
                                    break;
                                }
                            }
                            
                            // Get sections for this grade
                            $gradeSections = [];
                            foreach ($sections as $sid => $section) {
                                if (isset($sectionGrades[$sid]) && $sectionGrades[$sid] == $gradeId) {
                                    $gradeSections[] = $section;
                                }
                            }
                            
                            if (empty($gradeSections)) continue;
                        ?>
                            <div class="grade-section">
                                <div class="grade-header" data-grade="<?php echo $gradeId; ?>">
                                    <span>
                                        <i class="bi bi-chevron-right me-2"></i>
                                        <?php echo $gradeName; ?>
                                    </span>
                                    <span class="grade-badge"><?php echo count($gradeSections); ?> sections</span>
                                </div>
                                
                                <div class="grade-sections" id="grade-<?php echo $gradeId; ?>">
                                    <?php foreach ($gradeSections as $section): ?>
                                        <div class="section-card">
                                            <div class="section-header">
                                                <div>
                                                    <div class="section-name"><?php echo htmlspecialchars($section['section_name']); ?></div>
                                                    <div class="section-code"><?php echo htmlspecialchars($section['section_code']); ?></div>
                                                </div>
                                                <div class="section-actions">
                                                    <a href="assign.php?section_id=<?php echo $section['id']; ?>" class="btn-icon assign" title="Assign Teacher">
                                                        <i class="bi bi-person-plus"></i>
                                                    </a>
                                                    <a href="section.php?edit=<?php echo $section['id']; ?>" class="btn-icon" title="Edit Section">
                                                        <i class="bi bi-pencil"></i>
                                                    </a>
                                                </div>
                                            </div>
                                            
                                            <?php if (!empty($assignments[$section['id']])): ?>
                                                <div class="subject-tags">
                                                    <?php foreach (array_slice($assignments[$section['id']], 0, 3) as $assign): ?>
                                                        <span class="subject-tag">
                                                            <?php echo htmlspecialchars($assign['subject_name']); ?>
                                                            <small><?php echo htmlspecialchars($assign['teacher_name']); ?></small>
                                                        </span>
                                                    <?php endforeach; ?>
                                                    <?php if (count($assignments[$section['id']]) > 3): ?>
                                                        <span class="subject-tag">+<?php echo count($assignments[$section['id']]) - 3; ?> more</span>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        
                        <?php 
                        // Check if no sections for this level
                        $hasSections = false;
                        foreach ($category['grade_ids'] as $gradeId) {
                            foreach ($sections as $sid => $section) {
                                if (isset($sectionGrades[$sid]) && $sectionGrades[$sid] == $gradeId) {
                                    $hasSections = true;
                                    break 2;
                                }
                            }
                        }
                        
                        if (!$hasSections): ?>
                            <div class="empty-state">
                                <i class="bi bi-inbox"></i>
                                <h6>No Sections Found</h6>
                                <p class="text-muted small">Click "Manage Sections" to create a new section.</p>
                                <a href="section.php" class="btn btn-sm btn-primary mt-2">
                                    <i class="bi bi-plus-circle"></i> New Section
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </main>
    <?php require_once("includes/footer.php"); ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script>
    // Level switching
    document.querySelectorAll('.level-card').forEach(card => {
        card.addEventListener('click', () => {
            document.querySelectorAll('.level-card').forEach(c => c.classList.remove('active'));
            card.classList.add('active');
            
            const level = card.dataset.level;
            document.querySelectorAll('.level-content').forEach(content => {
                content.classList.remove('active');
            });
            document.getElementById('content-' + level).classList.add('active');
            
            // Reset all grade sections to closed
            document.querySelectorAll('.grade-sections').forEach(g => {
                g.classList.remove('show');
            });
            document.querySelectorAll('.grade-header i').forEach(i => {
                i.className = 'bi bi-chevron-right me-2';
            });
        });
    });

    // Grade header click
    document.querySelectorAll('.grade-header').forEach(header => {
        header.addEventListener('click', () => {
            const gradeId = header.dataset.grade;
            const gradeSections = document.getElementById('grade-' + gradeId);
            const icon = header.querySelector('i');
            
            // Toggle current grade
            gradeSections.classList.toggle('show');
            
            // Update icon
            if (gradeSections.classList.contains('show')) {
                icon.className = 'bi bi-chevron-down me-2';
            } else {
                icon.className = 'bi bi-chevron-right me-2';
            }
        });
    });

    // Open first grade by default
    document.addEventListener('DOMContentLoaded', () => {
        const firstGrade = document.querySelector('.grade-header');
        if (firstGrade) {
            setTimeout(() => {
                firstGrade.click();
            }, 100);
        }
    });
</script>
</body>
</html>