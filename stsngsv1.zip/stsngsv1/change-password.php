<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Change Password - St. Theresa's School of Novaliches</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  
  <link rel="stylesheet" href="css/login.css">
</head>
<body>
  <nav class="navbar fixed-top">
    <div class="container-fluid px-5 py-3">
      <div class="d-flex align-items-center gap-3">
        <img src="assets/img/stns logo.png" alt="Logo" width="45" height="45" class="d-inline-block align-text-top drop-shadow">
        <div class="text-white">
          <h6 class="m-0 fw-bold tracking-wide text-uppercase" style="letter-spacing: 1px;">St. Theresa's School of Novaliches</h6>
        </div>
      </div>
    </div>
  </nav>
  <div class="main-wrapper">  
    <div class="split-card animate-up"> 
      <div class="login-side">
        <div class="school-branding">
          <img src="assets/img/stns logo.png" alt="STSN Logo" class="school-logo">
          <h2 class="login-title">Change Password</h2>
          <p class="text-muted small">For security, please create a new password.</p>
        </div>
        <?php if (isset($_GET['error'])): ?>
          <div class="alert alert-danger py-2 small shadow-sm border-0 mb-4 d-flex align-items-center justify-content-center text-center">
            <i class="bi bi-exclamation-circle-fill me-2"></i> 
            <div><?php echo htmlspecialchars($_GET['error']); ?></div>
          </div>
        <?php endif; ?>
        <form action="api/login/process_change_password.php" method="post">
          
          <div class="form-floating mb-3">
            <input type="password" class="form-control" name="new_password" id="new_password" placeholder="New Password" required autofocus minlength="6">
            <label for="new_password"><i class="bi bi-lock-fill me-2"></i>New Password</label>
          </div>
          <div class="form-floating mb-3">
            <input type="password" class="form-control" name="confirm_password" id="confirm_password" placeholder="Confirm Password" required minlength="6">
            <label for="confirm_password"><i class="bi bi-check-circle-fill me-2"></i>Confirm Password</label>
          </div>
          <div class="d-flex justify-content-between align-items-center mb-4">
            <div class="form-check">
              <input class="form-check-input" type="checkbox" id="showPass">
              <label class="form-check-label small text-muted" for="showPass">Show Password</label>
            </div>
          </div>
          <button type="submit" class="btn btn-primary btn-login w-100 text-white shadow-sm">
            UPDATE PASSWORD <i class="bi bi-arrow-right-short ms-1"></i>
          </button>
        </form>      
        <div class="text-center mt-4">
           <a href="api/login/logout.php" class="small text-danger text-decoration-none fw-semibold">Cancel & Logout</a>
        </div>
      </div>
      <div class="info-side">
        <div class="decorative-circle"></div>        
        <div class="info-content">    
          <div class="vm-box">
            <div class="vm-title"><i class="bi bi-bullseye"></i> Our Vision</div>
            <p class="vm-text">
              A leading Catholic learning community that forms principled, innovative leaders who transform society through faith, excellence, and service.
            </p>
          </div>
          <div class="vm-box">
            <div class="vm-title"><i class="bi bi-compass-fill"></i> Our Mission</div>
            <p class="vm-text">
              We nurture every learner’s mind, heart, and spirit through rigorous academics, values-based formation, and collaborative outreach.
            </p>
          </div>
        </div>
        <div class="info-footer">
          <div class="footer-item"><i class="bi bi-geo-alt-fill"></i> 7 Kingfisher St., Zabarte Subd., Brgy. Kaligayahan, Novaliches, Quezon City, Philippines</div>
          <div class="footer-item"><i class="bi bi-telephone-fill"></i> +63 333 444 2232</div>
          <div class="footer-item mt-2 w-100 email-text">
            <i class="bi bi-envelope-fill"></i> stsngradingsys@gmail.com
          </div>
        </div>
      </div>

    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const showPassCheckbox = document.getElementById('showPass');
      const newPassInput = document.getElementById('new_password');
      const confirmPassInput = document.getElementById('confirm_password');
      if(showPassCheckbox && newPassInput && confirmPassInput) {
          showPassCheckbox.addEventListener('change', function() {
            // Toggle type for both fields simultaneously
            const type = this.checked ? 'text' : 'password';
            newPassInput.type = type;
            confirmPassInput.type = type;
          });
      }
    });
  </script>

</body>
</html>