<?php
require_once __DIR__ . '/api/shared/db_connect.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Teachers</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        @media (max-width: 767.98px) {
            #teacherTable thead { display: none; }
            #teacherTable tbody tr {
                display: block;
                border: 1px solid #dee2e6;
                margin-bottom: .5rem;
                border-radius: .25rem;
                padding: .5rem;
            }
            #teacherTable tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                border: none !important;
                padding: .35rem .5rem;
            }
            #teacherTable tbody td::before {
                content: attr(data-label);
                font-weight: 600;
                margin-right: .5rem;
                white-space: nowrap;
            }
            /* actions stack + big buttons */
            #teacherTable tbody td:last-child {
                flex-direction: column;
                gap: .25rem;
            }
            #teacherTable tbody td:last-child .btn {
                width: 100%;
                font-size: .9rem;
                padding: .4rem;
            }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6"><h3 class="mb-0"><i class="nav-icon bi bi-person-badge"></i> Teachers</h3></div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item">Users</li>
                            <li class="breadcrumb-item active">Teachers</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-4 m-3">
            <div class="card-header d-flex justify-content-between align-items-center flex-wrap">
                <h3 class="card-title mb-0">Teacher List</h3>
                <div class="d-flex align-items-center gap-2 ms-auto">
                    <input class="form-control form-control-sm" type="search" id="searchInput" placeholder="Search…">
                    <button class="btn btn-success btn-sm text-nowrap" data-bs-toggle="modal" data-bs-target="#teacherModal">
                        <i class="bi bi-plus-circle me-1"></i> New Teacher
                    </button>
                </div>
            </div>

            <div class="card-body">
                <div class="table-responsive-sm">
                    <table id="teacherTable" class="table table-bordered table-hover align-middle mb-0 text-center">
                        <thead class="table-light">
                        <tr>
                            <th style="width:50px;">#</th>
                            <th>Teacher ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Sex</th>
                            <th>Contact</th>
                            <th>Date Hired</th>
                            <th style="width:100px;">Status</th>
                            <th style="width:200px;">Actions</th>
                        </tr>
                        </thead>
                        <tbody id="teacherTableBody"></tbody>
                    </table>
                </div>
            </div>

            <div class="card-footer clearfix">
                <ul class="pagination pagination-sm m-0 float-end" id="pagination"></ul>
            </div>
        </div>
    </main>

    <?php require_once("includes/footer.php"); ?>
</div>

<!-- Modal -->
<div class="modal fade" id="teacherModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="false">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <form id="teacherForm">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">Add Teacher</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="teacherRecId">
                    <div class="row">
                        <div class="col-md-6 mb-3"><label class="form-label">Teacher ID</label><input type="text" class="form-control" id="teacherId" required></div>
                        <div class="col-md-6 mb-3"><label class="form-label">Email</label><input type="email" class="form-control" id="email" required></div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3"><label class="form-label">First Name</label><input type="text" class="form-control" id="fname" required></div>
                        <div class="col-md-4 mb-3"><label class="form-label">Middle Name</label><input type="text" class="form-control" id="mname"></div>
                        <div class="col-md-4 mb-3"><label class="form-label">Last Name</label><input type="text" class="form-control" id="lname" required></div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3"><label class="form-label">Date Hired</label><input type="date" class="form-control" id="dateHired" required></div>
                        <div class="col-md-4 mb-3"><label class="form-label">Sex</label>
                            <select class="form-select" id="sex" required>
                                <option value="">-- select --</option><option>Male</option><option>Female</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3"><label class="form-label">Contact No</label><input type="text" class="form-control" id="contactNo" required></div>
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="isActive"><label class="form-check-label" for="isActive">Active</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success" id="saveBtn">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script>
let currentPage = 1;
let searchTerm  = '';

function loadTeachers(page = 1, search = ''){
    fetch(`api/teacher/read.php?p=${page}&s=${encodeURIComponent(search)}`)
        .then(r => r.json())
        .then(data => renderTable(data.teachers, data.page, data.pages))
        .catch(err => console.error('LOAD ERROR:', err));
}

function renderTable(list, page, pages){
    const tbody = document.getElementById('teacherTableBody');
    const headers = Array.from(document.querySelectorAll('#teacherTable thead th')).map(th => th.textContent);

    tbody.innerHTML = list.map((t, i) => `
        <tr>
            <td data-label="${headers[0]}">${((page-1)*10)+i+1}</td>
            <td data-label="${headers[1]}">${t.teacher_id}</td>
            <td data-label="${headers[2]}">${t.fname} ${t.mname||''} ${t.lname}</td>
            <td data-label="${headers[3]}">${t.email}</td>
            <td data-label="${headers[4]}">${t.sex}</td>
            <td data-label="${headers[5]}"><a href="tel:${t.contact_no}}">${t.contact_no}</a></td>
            <td data-label="${headers[6]}">${t.date_hired}</td>
            <td data-label="${headers[7]}">${t.is_active==1?'<span class="badge bg-success">Active</span>':'<span class="badge bg-secondary">Inactive</span>'}</td>
            <td data-label="${headers[8]}">
                <button class="btn btn-sm btn-warning me-1" onclick="editTeacher(${t.id})"><i class="bi bi-pencil-square"></i> Edit</button>
                <button class="btn btn-sm ${t.is_active==1?'btn-danger':'btn-outline-success'}"
                        onclick="toggleTeacher(${t.id},${t.is_active})"
                        data-bs-toggle="tooltip" data-bs-placement="top"
                        title="${t.is_active==1?'Deactivate':'Activate'}">
                    <i class="bi ${t.is_active==1?'bi-toggle-off':'bi-toggle-on'}"></i> ${t.is_active==1?'Deactivate':'Activate'}
                </button>
            </td>
        </tr>`).join('');

    // bootstrap tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(el => new bootstrap.Tooltip(el));

    const ul = document.getElementById('pagination');
    ul.innerHTML = '';
    for(let p = 1; p <= pages; p++){
        ul.innerHTML += `<li class="page-item ${p===page?'active':''}"><a class="page-link" href="#" onclick="loadTeachers(${p},'${searchTerm}')">${p}</a></li>`;
    }
}

document.getElementById('teacherForm').addEventListener('submit', e => {
    e.preventDefault();
    const id = document.getElementById('teacherRecId').value;
    const payload = {
        id: id || undefined,
        teacher_id: document.getElementById('teacherId').value,
        email:      document.getElementById('email').value,
        fname:      document.getElementById('fname').value,
        mname:      document.getElementById('mname').value,
        lname:      document.getElementById('lname').value,
        date_hired: document.getElementById('dateHired').value,
        sex:        document.getElementById('sex').value,
        contact_no: document.getElementById('contactNo').value,
        is_active:  document.getElementById('isActive').checked ? 1 : 0
    };

    fetch('api/teacher/save.php', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify(payload)
    })
        .then(r => r.json())
        .then(res => {
            if(res.success){
                bootstrap.Modal.getInstance(document.getElementById('teacherModal')).hide();
                loadTeachers(currentPage, searchTerm);
                document.getElementById('teacherForm').reset();
            }
        });
});

function editTeacher(id){
    fetch(`api/teacher/fetch.php?id=${id}`)
        .then(r => r.json())
        .then(t => {
            document.getElementById('teacherRecId').value   = t.id;
            document.getElementById('teacherId').value      = t.teacher_id;
            document.getElementById('email').value          = t.email;
            document.getElementById('fname').value          = t.fname;
            document.getElementById('mname').value          = t.mname || '';
            document.getElementById('lname').value          = t.lname;
            document.getElementById('dateHired').value      = t.date_hired;
            document.getElementById('sex').value            = t.sex;
            document.getElementById('contactNo').value      = t.contact_no;
            document.getElementById('isActive').checked     = t.is_active == 1;
            document.getElementById('modalTitle').textContent = 'Edit Teacher';
            new bootstrap.Modal(document.getElementById('teacherModal')).show();
        });
}

/* ----------  ASYNC TOGGLE  ---------- */
async function toggleTeacher(id, currentState) {
    const newStatus = currentState === 1 ? 0 : 1;
    const action = newStatus === 1 ? 'Activate' : 'Deactivate';
    if (!confirm(`${action} this teacher?`)) return;

    try {
        const res = await fetch('api/teacher/delete.php?id=' + id, { method: 'GET' });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const json = await res.json();
        if (json.success) {
            loadTeachers(currentPage, searchTerm);
        } else {
            alert(json.error || 'Toggle failed');
        }
    } catch (err) {
        console.error(err);
        alert('Could not change status: ' + err.message);
    }
}

document.getElementById('searchInput').addEventListener('input', e => {
    searchTerm = e.target.value;
    currentPage = 1;
    loadTeachers(currentPage, searchTerm);
});

document.getElementById('teacherModal').addEventListener('hidden.bs.modal', () => {
    document.getElementById('teacherForm').reset();
    document.getElementById('teacherRecId').value = '';
    document.getElementById('modalTitle').textContent = 'Add Teacher';
});

loadTeachers();
</script>
</body>
</html>