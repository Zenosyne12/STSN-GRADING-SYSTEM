<?php
require_once 'api/shared/db_connect.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Academic Years</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <!-- =====  RESPONSIVE-CARD STYLES  ===== -->
    <style>
        @media (max-width: 767.98px) {
            #yearTable thead { display: none; }
            #yearTable tbody tr {
                display: block;
                border: 1px solid #dee2e6;
                margin-bottom: .5rem;
                border-radius: .25rem;
                padding: .5rem;
            }
            #yearTable tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                border: none !important;
                padding: .35rem .5rem;
            }
            #yearTable tbody td::before {
                content: attr(data-label);
                font-weight: 600;
                margin-right: .5rem;
                white-space: nowrap;
            }
            /* actions stack + big buttons */
            #yearTable tbody td:last-child {
                flex-direction: column;
                gap: .25rem;
            }
            #yearTable tbody td:last-child .btn {
                width: 100%;
                font-size: .9rem;
                padding: .4rem;
            }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6"><h3><i class="bi bi-calendar"></i> Manage Academic Years</h3></div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item">Academic</li>
                            <li class="breadcrumb-item active">Years</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <?php if (isset($_GET['added'])): ?>
            <div class="alert alert-success alert-dismissible fade show m-3">Academic year added & older ones disabled.</div>
        <?php endif; ?>
        <?php if (isset($_GET['updated'])): ?>
            <div class="alert alert-info alert-dismissible fade show m-3">Academic year updated.</div>
        <?php endif; ?>

        <div class="card mb-4 m-3">
            <div class="card-header d-flex justify-content-between align-items-center flex-wrap">
                <h3 class="card-title mb-0">Academic Year List</h3>
                <div class="d-flex align-items-center gap-2 ms-auto">
                    <input class="form-control form-control-sm" type="search" id="searchInput" placeholder="Search…">
                    <button class="btn btn-success btn-sm text-nowrap" data-bs-toggle="modal" data-bs-target="#yearModal">
                        <i class="bi bi-plus-circle me-1"></i> New Academic Year
                    </button>
                </div>
            </div>

            <div class="card-body">
                <!-- desktop table -->
                <div class="table-responsive d-none d-md-block">
                    <table id="yearTable" class="table table-bordered table-hover align-middle text-center mb-0">
                        <thead class="table-light">
                            <tr>
                                <th style="width:50px;">#</th>
                                <th>Year</th>
                                <th style="width:120px;">Status</th>
                                <th style="width:180px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="tableBody"></tbody>
                    </table>
                </div>

                <!-- phone cards -->
                <div class="d-block d-md-none" id="cardView"></div>
            </div>

            <div class="card-footer clearfix">
                <ul class="pagination pagination-sm m-0 float-end" id="pagination"></ul>
            </div>
        </div>
    </main>

    <?php require_once("includes/footer.php"); ?>
</div>

<!-- Modal -->
<div class="modal fade" id="yearModal" tabindex="-1" data-bs-backdrop="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="yearForm">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">Add Academic Year</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="yearId">
                    <div class="mb-3">
                        <label class="form-label">School Year <span class="text-danger">*</span></label>
                        <!--  DROPDOWN 2020-21 … 2030-31  -->
                        <select class="form-select" id="yearLabel" required>
                            <option value="">-- select --</option>
                            <?php for ($y = 2020; $y <= 2030; $y++): ?>
                                <option><?= $y ?>-<?= $y + 1 ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script>
let currentPage = 1, search = '';

/* ----------  LOAD  ---------- */
function loadYears(page = 1, s = '') {
    fetch(`api/academic-year/read.php?p=${page}&s=${encodeURIComponent(s)}`)
        .then(r => r.json())
        .then(d => render(d.years || [], d.page, d.pages));
}

/* ----------  RENDER  ---------- */
function render(list, page, pages) {
    const headers = ['#', 'Year', 'Status', 'Actions'];

    /* ---- desktop table rows ---- */
    const row = (y, i) => `
        <tr>
            <td data-label="${headers[0]}">${((page - 1) * 10) + i + 1}</td>
            <td data-label="${headers[1]}">${y.year_label}</td>
            <td data-label="${headers[2]}">
                <span class="badge bg-${y.is_active ? 'success' : 'secondary'}">${y.is_active ? 'Active' : 'Inactive'}</span>
            </td>
            <td data-label="${headers[3]}">
                <button class="btn btn-sm ${y.is_active ? 'btn-warning' : 'btn-outline-success'}" onclick="toggleYear(${y.id}, ${y.is_active ? 0 : 1})">
                    <i class="bi ${y.is_active ? 'bi-toggle-off' : 'bi-toggle-on'}"></i> ${y.is_active ? 'Deactivate' : 'Activate'}
                </button>
            </td>
        </tr>`;

    /* ---- phone cards ---- */
    const card = (y, i) => `
        <div class="card mb-2">
            <div class="card-header bg-light d-flex justify-content-between">
                <span>${((page - 1) * 10) + i + 1}. ${y.year_label}</span>
                <span class="badge bg-${y.is_active ? 'success' : 'secondary'}">${y.is_active ? 'Active' : 'Inactive'}</span>
            </div>
            <div class="card-footer d-grid">
                <button class="btn btn-sm ${y.is_active ? 'btn-warning' : 'btn-outline-success'}" onclick="toggleYear(${y.id}, ${y.is_active ? 0 : 1})">
                    <i class="bi ${y.is_active ? 'bi-toggle-off' : 'bi-toggle-on'}"></i> ${y.is_active ? 'Deactivate' : 'Activate'}
                </button>
            </div>
        </div>`;

    document.getElementById('tableBody').innerHTML = list.map(row).join('');
    document.getElementById('cardView').innerHTML  = list.map(card).join('');

    let p = '';
    for (let i = 1; i <= pages; i++) p += `<li class="page-item ${i === page ? 'active' : ''}"><a class="page-link" href="#" onclick="loadYears(${i}, search)">${i}</a></li>`;
    document.getElementById('pagination').innerHTML = p;
}

/* ----------  SAVE  ---------- */
document.getElementById('yearForm').addEventListener('submit', e => {
    e.preventDefault();
    const payload = {
        id: document.getElementById('yearId').value || undefined,
        year_label: document.getElementById('yearLabel').value.trim()
    };
    fetch('api/academic-year/save.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload)
    })
        .then(r => r.json())
        .then(res => {
            if (res.success) {
                bootstrap.Modal.getInstance(document.getElementById('yearModal')).hide();
                loadYears(currentPage, search);
                e.target.reset();
            } else {
                alert(res.error || 'Save failed');
            }
        });
});

/* ----------  ACTIVATE / DEACTIVATE  ---------- */
function toggleYear(id, newState) {
    const action = newState ? 'Activate' : 'Deactivate';
    if (!confirm(` ${action} this academic year?`)) return;

    fetch('api/academic-year/toggle.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({id: id, is_active: newState})
    })
        .then(r => r.json())
        .then(res => {
            if (res.success) loadYears(currentPage, search);
            else alert(res.error || 'Toggle failed');
        });
}

/* ----------  SEARCH  ---------- */
document.getElementById('searchInput').addEventListener('input', e => {
    search = e.target.value;
    currentPage = 1;
    loadYears(currentPage, search);
});

/* ----------  RESET MODAL  ---------- */
document.getElementById('yearModal').addEventListener('hidden.bs.modal', () => {
    document.getElementById('yearForm').reset();
    document.getElementById('yearId').value = '';
    document.getElementById('modalTitle').textContent = 'Add Academic Year';
});

/* ----------  INIT  ---------- */
loadYears();
</script>
</body>
</html>