<!doctype html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>STSN Grading System | Teacher</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
    <meta name="color-scheme" content="light dark" />
    <meta name="theme-color" content="#007bff" media="(prefers-color-scheme: light)" />
    <meta name="theme-color" content="#1a1a1a" media="(prefers-color-scheme: dark)" />
    <meta name="title" content="AdminLTE | Dashboard v2" />
    <meta name="author" content="ColorlibHQ" />
    <meta
      name="description"
      content="AdminLTE is a Free Bootstrap 5 Admin Dashboard, 30 example pages using Vanilla JS. Fully accessible with WCAG 2.1 AA compliance."
    />
    <meta
      name="keywords"
      content="bootstrap 5, bootstrap, bootstrap 5 admin dashboard, bootstrap 5 dashboard, bootstrap 5 charts, bootstrap 5 calendar, bootstrap 5 datepicker, bootstrap 5 tables, bootstrap 5 datatable, vanilla js datatable, colorlibhq, colorlibhq dashboard, colorlibhq admin dashboard, accessible admin panel, WCAG compliant"
    />
    <meta name="supported-color-schemes" content="light dark" />
    
    <link rel="preload" href="css/adminlte.css" as="style" />
    
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css "
      integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q="
      crossorigin="anonymous"
      media="print"
      onload="this.media='all'"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css "
      crossorigin="anonymous"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css "
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="css/adminlte.css" />
    
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/apexcharts@3.37.1/dist/apexcharts.css "
      integrity="sha256-4MX+61mt9NVvvuPjUWdUdyfZfxSB1/Rf9WtqRHgG5S0="
      crossorigin="anonymous"
    />
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">

  <div class="app-wrapper">

    <?php
      // FIX: Removed "/.." because this file is in the root folder
      require_once __DIR__ . '/includes/teacher-header.php';
      require_once __DIR__ . '/includes/teacher-sidebar.php';
    ?>

    <main class="app-main">
      <div class="app-content-header">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-6">
              <h3><i class="bi bi-building"></i> My Classes</h3>
            </div>
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-end">
                <li class="breadcrumb-item"><a href="teacher_dashboard.php">Home</a></li>
                <li class="breadcrumb-item active">Classes</li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div class="card m-3">
        <div class="card-header d-flex justify-content-between align-items-center flex-wrap">
                <div class="card-title mb-0">Class List</div>
                <div class="d-flex align-items-center gap-2 ms-auto">
                    <input class="form-control form-control-sm" id="searchInput" placeholder="Search classes..." style="max-width:200px;">
                </div>
            </div>

        <div class="card-body p-0">
          <div class="table-responsive">
            <table class="table table-bordered table-sm text-nowrap align-middle text-center mb-0" id="classesTable">
              <thead class="table-light">
                <tr>
                  <th class="sticky-col">#</th>
                  <th>Class Code</th>
                  <th class="text-start">Class Name</th>
                  <th>Section</th>
                  <th>Grade Level</th>
                  <th>Students</th>
                  <th>School Year</th>
                  <th>Schedule</th>
                  <th style="width:160px;">Actions</th>
                </tr>
              </thead>
              <tbody>
            <tr data-class-id="1" >
                <td class="sticky-col fw-semibold">1</td>
                <td>MATH7-001</td>
                <td class="text-start">
                Mathematics 7
                </td>
                <td>Section A</td>
                <td>Grade 7</td>
                <td><span class="badge bg-primary">35</span></td>
                <td>2024-2025</td>
                <td>MWF 8:00-9:00 AM</td>
                <td>
                <button class="btn btn-sm btn-info me-1" data-bs-toggle="tooltip" title="View Roster" onclick="viewRoster(1)">
                    <i class="bi bi-people"></i>
                </button>
                <button class="btn btn-sm btn-outline-secondary me-1" disabled data-bs-toggle="tooltip" title="Not Adviser">
                    <i class="bi bi-lock"></i>
                </button>
                <button class="btn btn-sm btn-outline-secondary" disabled data-bs-toggle="tooltip" title="Not Adviser">
                    <i class="bi bi-lock"></i>
                </button>
                </td>
            </tr>

            <tr data-class-id="2">
                <td class="sticky-col fw-semibold">2</td>
                <td>SCI8-002</td>
                <td class="text-start">Science 8</td>
                <td>Section B</td>
                <td>Grade 8</td>
                <td><span class="badge bg-primary">32</span></td>
                <td>2024-2025</td>
                <td>TTh 10:00-11:30 AM</td>
                <td>
                <button class="btn btn-sm btn-info me-1" data-bs-toggle="tooltip" title="View Roster" onclick="viewRoster(2)">
                    <i class="bi bi-people"></i>
                </button>
                <button class="btn btn-sm btn-outline-secondary me-1" disabled data-bs-toggle="tooltip" title="Not Adviser">
                    <i class="bi bi-lock"></i>
                </button>
                <button class="btn btn-sm btn-outline-secondary" disabled data-bs-toggle="tooltip" title="Not Adviser">
                    <i class="bi bi-lock"></i>
                </button>
                </td>
            </tr>

            <tr data-class-id="3" class="table-success">
                <td class="sticky-col fw-semibold">3</td>
                <td>ENG9-001</td>
                <td class="text-start">
                English 9
                <span class="badge bg-success ms-2">Advisory</span>
                </td>
                <td>Section C</td>
                <td>Grade 9</td>
                <td><span class="badge bg-primary">28</span></td>
                <td>2024-2025</td>
                <td>MWF 2:00-3:00 PM</td>
                <td>
                <button class="btn btn-sm btn-info me-1" data-bs-toggle="tooltip" title="View Roster" onclick="viewRoster(3)">
                    <i class="bi bi-people"></i>
                </button>
                <button class="btn btn-sm btn-secondary me-1" data-bs-toggle="tooltip" title="Edit">
                    <i class="bi bi-pencil-square"></i>
                </button>
                <button class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Archive" onclick="archiveClass(3)">
                    <i class="bi bi-archive"></i>
                </button>
                </td>
            </tr>
            </tbody>
            </table>
          </div>
        </div>

        <div class="card-footer clearfix">
          <ul class="pagination pagination-sm m-0 float-end">
            <li class="page-item"><a class="page-link" href="#">&laquo;</a></li>
            <li class="page-item"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item"><a class="page-link" href="#">&raquo;</a></li>
          </ul>
        </div>
      </div>
    </main>

    <?php 
        // FIX: Removed "/.."
        require_once __DIR__ . '/includes/teacher-footer.php';
    ?>

  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js "></script>
  
  <script src="js/adminlte.js"></script>

  <script>
    // FIXED TOOLTIP SELECTOR
    const ttList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    ttList.map(el => new bootstrap.Tooltip(el));

    // Search functionality
    document.getElementById('searchInput').addEventListener('keyup', function() {
      const searchTerm = this.value.toLowerCase();
      const rows = document.querySelectorAll('#classesTable tbody tr');
      
      rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
      });
    });

    function viewRoster(classId) {
      window.location.href = `class-roster.php?class_id=${classId}`;
    }

    function archiveClass(id) {
      if(confirm('Archive this class? This will remove it from active classes but keep all records.')) {
        fetch('archive_class.php', {
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify({class_id:id})
        })
        .then(r=>r.json()).then(res=>{
          if(res.success){
            document.querySelector(`tr[data-class-id="${id}"]`).remove();
          }
        });
      }
    }

    // Form submission
    /* Note: classForm and addClassModal are not in the HTML provided, 
       so this might cause a JS error if they don't exist in the footer 
       or elsewhere. I kept it as is. */
    if(document.getElementById('classForm')) {
        document.getElementById('classForm').addEventListener('submit', function(e) {
        e.preventDefault();
        // Add your form submission logic here
        alert('Class added successfully!');
        bootstrap.Modal.getInstance(document.getElementById('addClassModal')).hide();
        });
    }
  </script>

  <style>
    .sticky-col { position: sticky; left: 0; background: #fff; z-index: 10; }
    #classesTable thead th.sticky-col { background: #f2f2f2; }
    .badge { font-size: 0.75em; }
  </style>

</body>
</html>