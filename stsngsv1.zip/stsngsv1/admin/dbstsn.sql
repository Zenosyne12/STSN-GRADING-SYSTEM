-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 24, 2025 at 06:47 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbstsn`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblacademicyear`
--

CREATE TABLE `tblacademicyear` (
  `id` int(11) NOT NULL,
  `year_label` varchar(9) NOT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblacademicyear`
--

INSERT INTO `tblacademicyear` (`id`, `year_label`, `is_active`, `created_at`) VALUES
(1, '2025-2026', 1, '2025-11-17 13:40:48');

-- --------------------------------------------------------

--
-- Table structure for table `tblbarangay`
--

CREATE TABLE `tblbarangay` (
  `id` int(11) NOT NULL,
  `barangay_name` varchar(100) NOT NULL,
  `city_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblbarangay`
--

INSERT INTO `tblbarangay` (`id`, `barangay_name`, `city_id`) VALUES
(1, 'Barangay 1', 1),
(2, 'Barangay 2', 2),
(3, 'Barangay 3', 3),
(4, 'Barangay 4', 4),
(5, 'Barangay 5', 5);

-- --------------------------------------------------------

--
-- Table structure for table `tblcity`
--

CREATE TABLE `tblcity` (
  `id` int(11) NOT NULL,
  `city_name` varchar(100) NOT NULL,
  `province_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblcity`
--

INSERT INTO `tblcity` (`id`, `city_name`, `province_id`) VALUES
(1, 'Manila', 1),
(2, 'Quezon City', 1),
(3, 'Makati', 1),
(4, 'Dasmariñas', 2),
(5, 'Santa Rosa', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tblcountry`
--

CREATE TABLE `tblcountry` (
  `id` int(11) NOT NULL,
  `country_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblcountry`
--

INSERT INTO `tblcountry` (`id`, `country_name`) VALUES
(1, 'Philippines');

-- --------------------------------------------------------

--
-- Table structure for table `tblgradelevel`
--

CREATE TABLE `tblgradelevel` (
  `id` int(11) NOT NULL,
  `grade_level_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblgradelevel`
--

INSERT INTO `tblgradelevel` (`id`, `grade_level_name`) VALUES
(1, 'Kindergarten'),
(2, 'Grade 1'),
(3, 'Grade 2'),
(4, 'Grade 3'),
(5, 'Grade 4'),
(6, 'Grade 5'),
(7, 'Grade 6'),
(8, 'Grade 7'),
(9, 'Grade 8'),
(10, 'Grade 9'),
(11, 'Grade 10'),
(12, 'Grade 11'),
(13, 'Grade 12');

-- --------------------------------------------------------

--
-- Table structure for table `tblprovince`
--

CREATE TABLE `tblprovince` (
  `id` int(11) NOT NULL,
  `province_name` varchar(100) NOT NULL,
  `region_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblprovince`
--

INSERT INTO `tblprovince` (`id`, `province_name`, `region_id`) VALUES
(1, 'Metro Manila', 1),
(2, 'Cavite', 2),
(3, 'Laguna', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tblregion`
--

CREATE TABLE `tblregion` (
  `id` int(11) NOT NULL,
  `region_name` varchar(100) NOT NULL,
  `country_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblregion`
--

INSERT INTO `tblregion` (`id`, `region_name`, `country_id`) VALUES
(1, 'National Capital Region (NCR)', 1),
(2, 'Calabarzon (IV-A)', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblrole`
--

CREATE TABLE `tblrole` (
  `id` int(11) NOT NULL,
  `role_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblrole`
--

INSERT INTO `tblrole` (`id`, `role_name`) VALUES
(1, 'Admin'),
(2, 'Teacher');

-- --------------------------------------------------------

--
-- Table structure for table `tblsection`
--

CREATE TABLE `tblsection` (
  `id` int(11) NOT NULL,
  `section_code` varchar(30) NOT NULL,
  `section_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblsection`
--

INSERT INTO `tblsection` (`id`, `section_code`, `section_name`, `description`, `is_active`, `created_at`, `updated_at`) VALUES
(15, 'SEC-01', 'Grade 7 - Ruby', 'Junior-high first-section track', 1, '2025-11-22 14:36:10', '2025-11-22 14:36:10'),
(16, 'SEC-02', 'Grade 7 - Sapphire', 'Junior-high second-section track', 1, '2025-11-22 14:36:10', '2025-11-22 14:36:10'),
(17, 'SEC-03', 'Grade 8 - Emerald', 'Junior-high third-section track', 1, '2025-11-22 14:36:10', '2025-11-22 14:36:10'),
(18, 'SEC-04', 'Grade 8 - Diamond', 'Junior-high fourth-section track', 1, '2025-11-22 14:36:10', '2025-11-22 14:36:10'),
(19, 'SEC-05', 'Grade 9 - Gold', 'Junior-high fifth-section track', 1, '2025-11-22 14:36:10', '2025-11-22 14:36:10'),
(20, 'SEC-06', 'Grade 9 - Silver', 'Junior-high sixth-section track', 1, '2025-11-22 14:36:10', '2025-11-22 14:36:10'),
(21, 'SEC-07', 'Grade 10 - Pearl', 'Junior-high seventh-section track', 1, '2025-11-22 14:36:10', '2025-11-22 14:36:10'),
(22, 'SEC-08', 'Grade 10 - Onyx', 'Junior-high eighth-section track', 1, '2025-11-22 14:36:10', '2025-11-22 14:36:10'),
(23, 'SEC-09', 'Grade 11 - Amethyst', 'Senior-high first-section track', 1, '2025-11-22 14:36:10', '2025-11-22 14:36:10'),
(24, 'SEC-10', 'Grade 12 - Topaz', 'Senior-high second-section track', 1, '2025-11-22 14:36:10', '2025-11-22 14:36:10');

-- --------------------------------------------------------

--
-- Table structure for table `tblstudents`
--

CREATE TABLE `tblstudents` (
  `id` int(11) NOT NULL,
  `lrn` varchar(12) DEFAULT NULL,
  `fname` varchar(100) DEFAULT NULL,
  `mname` varchar(100) DEFAULT NULL,
  `lname` varchar(100) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `citizenship` varchar(50) DEFAULT NULL,
  `grade_level_id` int(11) DEFAULT NULL,
  `fathers_name` varchar(100) DEFAULT NULL,
  `fathers_contact_num` varchar(20) DEFAULT NULL,
  `mothers_name` varchar(100) DEFAULT NULL,
  `mothers_contact_num` varchar(100) DEFAULT NULL,
  `guardian_name` varchar(100) DEFAULT NULL,
  `guardian_contact_num` varchar(20) DEFAULT NULL,
  `street_name` varchar(100) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `barangay_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `province_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblstudents`
--

INSERT INTO `tblstudents` (`id`, `lrn`, `fname`, `mname`, `lname`, `birthdate`, `gender`, `citizenship`, `grade_level_id`, `fathers_name`, `fathers_contact_num`, `mothers_name`, `mothers_contact_num`, `guardian_name`, `guardian_contact_num`, `street_name`, `postal_code`, `barangay_id`, `city_id`, `region_id`, `province_id`, `country_id`, `is_active`) VALUES
(1, '010000000001', 'Andre', 'Delos', 'Santo', '2001-01-15', 'Male', 'Filipino', 5, 'Pedro Santos', '0917-111-1111', 'Maria Santos', '84651', 'Maria Santos', '0917-111-1111', '123 Mabini St', '1000', 1, 1, 1, 1, 1, 1),
(2, '010000000002', 'Maria', 'Isabel', 'Reyes', '2011-03-22', 'Female', 'Filipino', 4, 'Jose Reyes', '0922-222-2222', 'Ana Reyes', '7461', 'Ana Reyes', '0922-222-2222', '456 Quezon Ave', '1100', 2, 2, 1, 1, 1, 1),
(3, '010000000003', 'Carlos', 'Dim', 'Garcia', '2009-07-08', 'Male', 'Filipino', 6, 'Ramon Garcia', '0933-333-3333', 'Clara Garcia', '09944', 'Clara Garcia', '0933-333-3333', '789 Rizal Blvd', '1200', 3, 3, 1, 1, 1, 1),
(4, '010000000004', 'Sophia', 'Lane', 'Mendoza', '2012-11-30', 'Female', 'Filipino', 3, 'Miguel Mendoza', '0944-444-4444', 'Elena Mendoza', '096230', 'Elena Mendoza', '0944-444-4444', '321 Luna St', '4114', 4, 4, 2, 2, 1, 1),
(5, '010000000005', 'Andrew', 'Mark', 'Torres', '2008-05-14', 'Male', 'Filipino', 7, 'Robert Torres', '0955-555-5555', 'Liza Torres', '098555', 'Liza Torres', '0955-555-5555', '654 Del Pilar', '4026', 5, 5, 2, 3, 1, 1),
(6, '010000000006', 'Angela', 'Rose', 'Cruz', '2013-08-20', 'Female', 'Filipino', 2, 'Danilo Cruz', '0966-666-6666', 'Fe Cruz', '096555', 'Fe Cruz', '0966-666-6666', '987 Bonifacio St', '1000', 1, 1, 1, 1, 1, 1),
(7, '010000000007', 'Mark', 'Paul', 'Lim', '2007-12-03', 'Male', 'Filipino', 8, 'Arthur Lim', '0977-777-7777', 'Grace Lim', '08444', 'Grace Lim', '0977-777-7777', '147 Taft Ave', '1100', 2, 2, 1, 1, 1, 1),
(8, '010000000008', 'Jusipin', 'Kay', 'Flores', '2014-02-28', 'Female', 'Filipino', 1, 'Ryan Flores', '0988-888-8888', 'Cathy Flores', '096666', 'Cathy Flores', '0988-888-8888', '258 Shaw Blvd', '1200', 3, 3, 1, 1, 1, 1),
(9, '010000000009', 'Bryan', 'James', 'Villanueva', '2006-09-11', 'Male', 'Filipino', 9, 'Raul Villanueva', '0999-999-9999', 'Nina Villanueva', '092222', 'Nina Villanueva', '0999-999-9999', '369 Aguinaldo Hwy', '4114', 4, 4, 2, 2, 1, 1),
(10, '010000000010', 'Trisha', 'May', 'Delos', '2015-06-17', 'Female', 'Filipino', 1, 'Leo Delos', '0912-121-2121', 'Mila Delos', '093333', 'Mila Delos', '0912-121-2121', '753 Bayan St', '4026', 5, 5, 2, 3, 1, 1),
(13, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblsubjects`
--

CREATE TABLE `tblsubjects` (
  `id` int(11) NOT NULL,
  `subject_code` varchar(20) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblsubjects`
--

INSERT INTO `tblsubjects` (`id`, `subject_code`, `subject_name`, `description`, `created_at`) VALUES
(8, 'MATH101', 'Algebra I', 'Fundamental algebraic concepts and operations', '2025-11-22 14:42:05'),
(9, 'ENG101', 'English Grammar', 'Basic grammar, syntax, and writing skills', '2025-11-22 14:42:05'),
(10, 'SCI101', 'General Biology', 'Introduction to living organisms and life processes', '2025-11-22 14:42:05'),
(11, 'FIL101', 'Komunikasyon', 'Pag-aaral ng wikang Filipino at kasanayan sa komunikasyon', '2025-11-22 14:42:05'),
(12, 'PE101', 'Physical Fitness', 'Individual and team sports for health and wellness', '2025-11-22 14:42:05'),
(13, 'HIST101', 'Philippine History', 'Philippine history from pre-colonial to contemporary times', '2025-11-22 14:42:05'),
(14, 'CHEM101', 'Basic Chemistry', 'Elements, compounds, and chemical reactions', '2025-11-22 14:42:05'),
(15, 'PHY101', 'Physics I', 'Mechanics, energy, and wave motion', '2025-11-22 14:42:05'),
(16, 'COMP101', 'Computer Basics', 'Computer hardware, software, and productivity tools', '2025-11-22 14:42:05'),
(17, 'VALUES', 'Good Manners & Right Conduct', 'Values education and character formation', '2025-11-22 14:42:05');

-- --------------------------------------------------------

--
-- Table structure for table `tblteacher`
--

CREATE TABLE `tblteacher` (
  `id` int(11) NOT NULL,
  `teacher_id` varchar(30) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `date_of_birth` date NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `civil_status` enum('Single','Married','Widowed','Divorced') NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `street_name` varchar(255) NOT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `barangay_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `province_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblteacher`
--

INSERT INTO `tblteacher` (`id`, `teacher_id`, `fname`, `lname`, `date_of_birth`, `gender`, `civil_status`, `contact_number`, `email`, `street_name`, `postal_code`, `barangay_id`, `city_id`, `region_id`, `province_id`, `country_id`, `is_active`) VALUES
(4, 'T00001', 'Maria', 'Clara', '1985-03-12', 'Female', 'Single', '09123456789', 'maria.clara@example.com', '123 Rizal St', '4000', NULL, NULL, NULL, NULL, NULL, 1),
(5, 'T00002', 'Jose', 'Rizal', '1980-06-19', 'Male', 'Married', '09223456789', 'jose.rizal@example.com', '456 Bonifacio St', '4001', NULL, NULL, NULL, NULL, NULL, 1),
(6, 'T00003', 'Andres', 'Bonifacio', '1979-11-30', 'Male', 'Married', '09333456789', 'andres.boni@example.com', '789 Del Pilar St', '4002', NULL, NULL, NULL, NULL, NULL, 1),
(7, 'T00004', 'Melchora', 'Aquino', '1990-01-06', 'Female', 'Widowed', '09443456789', 'melchora.aquino@example.com', '111 Tandang Sora St', '4003', NULL, NULL, NULL, NULL, NULL, 1),
(8, 'T00005', 'Emilio', 'Aguinaldo', '1987-10-14', 'Male', 'Married', '09553456789', 'emilio.aguinaldo@example.com', '30 Narra st', '', 1, 1, 1, 1, 1, 1),
(9, 'T00006', 'Gabriela', 'Silang', '1992-03-19', 'Female', 'Single', '09663456789', 'gabriela.silang@example.com', '333 Ilocos St', '4005', NULL, NULL, NULL, NULL, NULL, 1),
(10, 'T00007', 'Apolinario', 'Mabini', '1987-10-08', 'Male', 'Single', '09773456789', 'apol.mabini@example.com', 'Matrix', '', 3, 3, 1, 1, 1, 1),
(11, 'T00008', 'Lapu-Lapu', 'Datu', '1965-01-01', 'Male', 'Married', '09883456789', 'lapu.datu@example.com', '555 Mactan Ave', '4007', NULL, NULL, NULL, NULL, NULL, 1),
(12, 'T00009', 'Katherine', 'Li', '1988-05-15', 'Female', 'Single', '09993456789', 'katherine.li@example.com', '666 Chinatown St', '4008', NULL, NULL, NULL, NULL, NULL, 1),
(13, 'T00010', 'Rizalino', 'Torres', '1975-10-25', 'Male', 'Divorced', '09004567890', 'riz.torres@example.com', '777 Taft Ave', '4009', NULL, NULL, NULL, NULL, NULL, 1),
(14, '1123129837891275', 'Anndre', 'wawawa', '2002-02-20', 'Male', 'Married', '0977123812318', 'lovelove25@gmail.com', 'Waka waka', '23232', 4, 4, 2, 2, 1, 1),
(15, 'T00023', 'Justin ', 'Hechanova', '2005-02-20', 'Male', 'Single', '9771995088', 'hechanova919@gmail.com', 'Quezon city', '1400', 1, 1, 1, 1, 1, 1),
(16, 'T00044', 'Luke', 'San Jose', '2006-02-03', 'Male', 'Single', '09771885768', 'sanjose2020@gmail.com', 'Lot 12 Blk12 Phase 7 Quezon City', '1399', 3, 3, 1, 1, 1, 1),
(17, 'T00099', 'Cristine', 'Gonzales', '2003-03-20', 'Female', 'Divorced', '9886758464324', 'CristineGonzales123@gmail.com', 'Baguio City', '1600', 4, 4, 2, 2, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblteacher_assignment`
--

CREATE TABLE `tblteacher_assignment` (
  `id` int(11) NOT NULL,
  `ay_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `isAdvisory` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblteacher_assignment`
--

INSERT INTO `tblteacher_assignment` (`id`, `ay_id`, `teacher_id`, `subject_id`, `section_id`, `isAdvisory`, `is_active`) VALUES
(3, 1, 8, 16, 20, 0, 1),
(4, 1, 4, 13, 16, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `must_change_password` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`id`, `username`, `password_hash`, `role_id`, `reference_id`, `status`, `created_at`, `updated_at`, `must_change_password`) VALUES
(1, 'hechanovat00023', '$2y$10$SrK.vj7gIUxBpIZCxUROyOR9eluzSSSld8xR/QiKaTyHtuxU0UpoC', 2, 15, 'Active', '2025-11-24 13:25:38', '2025-11-24 16:48:55', 0),
(2, 'sanjoset00044', '$2y$10$xPIFID.JvAjjbonL4vbsjOED953RSDJKHsRErLWW7aYsWOJn2loE2', 2, 16, 'Active', '2025-11-24 15:19:39', '2025-11-24 15:19:39', 1),
(4, 'admin', '$2y$10$nw7Ah4oao/TjpSxaV6o8UO/EfPT2r3k/gsIFw2RxMWSgOUXaFCDc.', 1, NULL, 'Active', '2025-11-24 16:37:53', '2025-11-24 16:54:25', 0),
(5, 'gonzalest00099', '$2y$10$ax/BmuaYJhpu.NwZ1OzH2.qbS/d1mdj6Fs7uPVvDG.dqrDtsqb7rm', 2, 17, 'Active', '2025-11-24 16:58:51', '2025-11-24 16:59:16', 0);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vwstudentinfo`
-- (See below for the actual view)
--
CREATE TABLE `vwstudentinfo` (
`id` int(11)
,`lrn` varchar(12)
,`fname` varchar(100)
,`mname` varchar(100)
,`lname` varchar(100)
,`birthdate` date
,`gender` varchar(10)
,`citizenship` varchar(50)
,`grade_level_id` int(11)
,`grade_level_name` varchar(50)
,`fathers_name` varchar(100)
,`fathers_contact_num` varchar(20)
,`mothers_name` varchar(100)
,`mothers_contact_num` varchar(100)
,`guardian_name` varchar(100)
,`guardian_contact_num` varchar(20)
,`street_name` varchar(100)
,`postal_code` varchar(20)
,`barangay_id` int(11)
,`barangay_name` varchar(100)
,`city_id` int(11)
,`city_name` varchar(100)
,`province_id` int(11)
,`province_name` varchar(100)
,`region_id` int(11)
,`region_name` varchar(100)
,`country_id` int(11)
,`country_name` varchar(100)
,`is_active` tinyint(1)
,`age` bigint(21)
,`full_address` text
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vwteacherinfo`
-- (See below for the actual view)
--
CREATE TABLE `vwteacherinfo` (
`id` int(11)
,`teacher_id` varchar(30)
,`fname` varchar(100)
,`lname` varchar(100)
,`date_of_birth` date
,`gender` enum('Male','Female','Other')
,`civil_status` enum('Single','Married','Widowed','Divorced')
,`contact_number` varchar(20)
,`email` varchar(255)
,`street_name` varchar(255)
,`postal_code` varchar(10)
,`is_active` tinyint(1)
,`barangay_name` varchar(100)
,`city_name` varchar(100)
,`province_name` varchar(100)
,`region_name` varchar(100)
,`country_name` varchar(100)
);

-- --------------------------------------------------------

--
-- Structure for view `vwstudentinfo`
--
DROP TABLE IF EXISTS `vwstudentinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vwstudentinfo`  AS SELECT `s`.`id` AS `id`, `s`.`lrn` AS `lrn`, `s`.`fname` AS `fname`, `s`.`mname` AS `mname`, `s`.`lname` AS `lname`, `s`.`birthdate` AS `birthdate`, `s`.`gender` AS `gender`, `s`.`citizenship` AS `citizenship`, `s`.`grade_level_id` AS `grade_level_id`, `gl`.`grade_level_name` AS `grade_level_name`, `s`.`fathers_name` AS `fathers_name`, `s`.`fathers_contact_num` AS `fathers_contact_num`, `s`.`mothers_name` AS `mothers_name`, `s`.`mothers_contact_num` AS `mothers_contact_num`, `s`.`guardian_name` AS `guardian_name`, `s`.`guardian_contact_num` AS `guardian_contact_num`, `s`.`street_name` AS `street_name`, `s`.`postal_code` AS `postal_code`, `s`.`barangay_id` AS `barangay_id`, `b`.`barangay_name` AS `barangay_name`, `s`.`city_id` AS `city_id`, `c`.`city_name` AS `city_name`, `s`.`province_id` AS `province_id`, `p`.`province_name` AS `province_name`, `s`.`region_id` AS `region_id`, `r`.`region_name` AS `region_name`, `s`.`country_id` AS `country_id`, `co`.`country_name` AS `country_name`, `s`.`is_active` AS `is_active`, timestampdiff(YEAR,`s`.`birthdate`,curdate()) AS `age`, concat_ws(', ',`s`.`street_name`,`b`.`barangay_name`,`c`.`city_name`,`p`.`province_name`,`r`.`region_name`,`co`.`country_name`) AS `full_address` FROM ((((((`tblstudents` `s` join `tblgradelevel` `gl` on(`gl`.`id` = `s`.`grade_level_id`)) join `tblbarangay` `b` on(`b`.`id` = `s`.`barangay_id`)) join `tblcity` `c` on(`c`.`id` = `s`.`city_id`)) join `tblprovince` `p` on(`p`.`id` = `s`.`province_id`)) join `tblregion` `r` on(`r`.`id` = `s`.`region_id`)) join `tblcountry` `co` on(`co`.`id` = `s`.`country_id`)) ;

-- --------------------------------------------------------

--
-- Structure for view `vwteacherinfo`
--
DROP TABLE IF EXISTS `vwteacherinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vwteacherinfo`  AS SELECT `t`.`id` AS `id`, `t`.`teacher_id` AS `teacher_id`, `t`.`fname` AS `fname`, `t`.`lname` AS `lname`, `t`.`date_of_birth` AS `date_of_birth`, `t`.`gender` AS `gender`, `t`.`civil_status` AS `civil_status`, `t`.`contact_number` AS `contact_number`, `t`.`email` AS `email`, `t`.`street_name` AS `street_name`, `t`.`postal_code` AS `postal_code`, `t`.`is_active` AS `is_active`, `b`.`barangay_name` AS `barangay_name`, `c`.`city_name` AS `city_name`, `p`.`province_name` AS `province_name`, `r`.`region_name` AS `region_name`, `co`.`country_name` AS `country_name` FROM (((((`tblteacher` `t` left join `tblbarangay` `b` on(`b`.`id` = `t`.`barangay_id`)) left join `tblcity` `c` on(`c`.`id` = `t`.`city_id`)) left join `tblprovince` `p` on(`p`.`id` = `t`.`province_id`)) left join `tblregion` `r` on(`r`.`id` = `t`.`region_id`)) left join `tblcountry` `co` on(`co`.`id` = `t`.`country_id`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblacademicyear`
--
ALTER TABLE `tblacademicyear`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `year_label` (`year_label`);

--
-- Indexes for table `tblbarangay`
--
ALTER TABLE `tblbarangay`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_barangay_city` (`city_id`);

--
-- Indexes for table `tblcity`
--
ALTER TABLE `tblcity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_city_province` (`province_id`);

--
-- Indexes for table `tblcountry`
--
ALTER TABLE `tblcountry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblgradelevel`
--
ALTER TABLE `tblgradelevel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblprovince`
--
ALTER TABLE `tblprovince`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_province_region` (`region_id`);

--
-- Indexes for table `tblregion`
--
ALTER TABLE `tblregion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_region_country` (`country_id`);

--
-- Indexes for table `tblrole`
--
ALTER TABLE `tblrole`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `role_name` (`role_name`);

--
-- Indexes for table `tblsection`
--
ALTER TABLE `tblsection`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `section_code` (`section_code`);

--
-- Indexes for table `tblstudents`
--
ALTER TABLE `tblstudents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `lrn` (`lrn`),
  ADD KEY `fk_name_grade` (`grade_level_id`),
  ADD KEY `fk_name_barangay` (`barangay_id`),
  ADD KEY `fk_name_city` (`city_id`),
  ADD KEY `fk_name_region` (`region_id`),
  ADD KEY `fk_name_province` (`province_id`),
  ADD KEY `fk_name_country` (`country_id`);

--
-- Indexes for table `tblsubjects`
--
ALTER TABLE `tblsubjects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `subject_code` (`subject_code`);

--
-- Indexes for table `tblteacher`
--
ALTER TABLE `tblteacher`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `teacher_id` (`teacher_id`),
  ADD KEY `fk_teacher_bar` (`barangay_id`),
  ADD KEY `fk_teacher_city` (`city_id`),
  ADD KEY `fk_teacher_prov` (`province_id`),
  ADD KEY `fk_teacher_reg` (`region_id`),
  ADD KEY `fk_teacher_cnt` (`country_id`);

--
-- Indexes for table `tblteacher_assignment`
--
ALTER TABLE `tblteacher_assignment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ay_id` (`ay_id`),
  ADD KEY `teacher_id` (`teacher_id`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `section_id` (`section_id`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `idx_reference` (`reference_id`),
  ADD KEY `idx_role` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblacademicyear`
--
ALTER TABLE `tblacademicyear`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblrole`
--
ALTER TABLE `tblrole`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblsection`
--
ALTER TABLE `tblsection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tblstudents`
--
ALTER TABLE `tblstudents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tblsubjects`
--
ALTER TABLE `tblsubjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tblteacher`
--
ALTER TABLE `tblteacher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tblteacher_assignment`
--
ALTER TABLE `tblteacher_assignment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblbarangay`
--
ALTER TABLE `tblbarangay`
  ADD CONSTRAINT `fk_barangay_city` FOREIGN KEY (`city_id`) REFERENCES `tblcity` (`id`);

--
-- Constraints for table `tblcity`
--
ALTER TABLE `tblcity`
  ADD CONSTRAINT `fk_city_province` FOREIGN KEY (`province_id`) REFERENCES `tblprovince` (`id`);

--
-- Constraints for table `tblprovince`
--
ALTER TABLE `tblprovince`
  ADD CONSTRAINT `fk_province_region` FOREIGN KEY (`region_id`) REFERENCES `tblregion` (`id`);

--
-- Constraints for table `tblregion`
--
ALTER TABLE `tblregion`
  ADD CONSTRAINT `fk_region_country` FOREIGN KEY (`country_id`) REFERENCES `tblcountry` (`id`);

--
-- Constraints for table `tblstudents`
--
ALTER TABLE `tblstudents`
  ADD CONSTRAINT `fk_name_barangay` FOREIGN KEY (`barangay_id`) REFERENCES `tblbarangay` (`id`),
  ADD CONSTRAINT `fk_name_city` FOREIGN KEY (`city_id`) REFERENCES `tblcity` (`id`),
  ADD CONSTRAINT `fk_name_country` FOREIGN KEY (`country_id`) REFERENCES `tblcountry` (`id`),
  ADD CONSTRAINT `fk_name_grade` FOREIGN KEY (`grade_level_id`) REFERENCES `tblgradelevel` (`id`),
  ADD CONSTRAINT `fk_name_province` FOREIGN KEY (`province_id`) REFERENCES `tblprovince` (`id`),
  ADD CONSTRAINT `fk_name_region` FOREIGN KEY (`region_id`) REFERENCES `tblregion` (`id`);

--
-- Constraints for table `tblteacher`
--
ALTER TABLE `tblteacher`
  ADD CONSTRAINT `fk_teacher_bar` FOREIGN KEY (`barangay_id`) REFERENCES `tblbarangay` (`id`),
  ADD CONSTRAINT `fk_teacher_city` FOREIGN KEY (`city_id`) REFERENCES `tblcity` (`id`),
  ADD CONSTRAINT `fk_teacher_cnt` FOREIGN KEY (`country_id`) REFERENCES `tblcountry` (`id`),
  ADD CONSTRAINT `fk_teacher_prov` FOREIGN KEY (`province_id`) REFERENCES `tblprovince` (`id`),
  ADD CONSTRAINT `fk_teacher_reg` FOREIGN KEY (`region_id`) REFERENCES `tblregion` (`id`);

--
-- Constraints for table `tblteacher_assignment`
--
ALTER TABLE `tblteacher_assignment`
  ADD CONSTRAINT `tblteacher_assignment_ibfk_1` FOREIGN KEY (`ay_id`) REFERENCES `tblacademicyear` (`id`),
  ADD CONSTRAINT `tblteacher_assignment_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `tblteacher` (`id`),
  ADD CONSTRAINT `tblteacher_assignment_ibfk_3` FOREIGN KEY (`subject_id`) REFERENCES `tblsubjects` (`id`),
  ADD CONSTRAINT `tblteacher_assignment_ibfk_4` FOREIGN KEY (`section_id`) REFERENCES `tblsection` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
