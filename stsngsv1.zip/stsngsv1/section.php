<?php
require_once __DIR__ . '/api/shared/db_connect.php';
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Sections</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css ">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css ">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css ">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        @media (max-width: 767.98px) {
            #sectionTable thead {
                display: none;
            }

            #sectionTable tbody tr {
                display: block;
                border: 1px solid #dee2e6;
                margin-bottom: .5rem;
                border-radius: .25rem;
                padding: .5rem;
            }

            #sectionTable tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                border: none !important;
                padding: .35rem .5rem;
            }

            #sectionTable tbody td::before {
                content: attr(data-label);
                font-weight: 600;
                margin-right: .5rem;
                white-space: nowrap;
            }

            #sectionTable tbody td:last-child {
                flex-direction: column;
                gap: .25rem;
            }

            #sectionTable tbody td:last-child .btn {
                width: 100%;
                font-size: .9rem;
                padding: .4rem;
            }
        }
    </style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <div class="app-wrapper">
        <?php require_once("includes/header.php"); ?>
        <?php require_once("includes/sidebar.php"); ?>

        <main class="app-main">
            <div class="app-content-header">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-6">
                            <h3 class="mb-0"><i class="bi bi-building"></i> Manage Sections</h3>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item">Academic</li>
                                <li class="breadcrumb-item active">Sections</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-4 m-3">
                <div class="card-header d-flex justify-content-between align-items-center flex-wrap">
                    <h3 class="card-title mb-0">Section List</h3>
                    <div class="d-flex align-items-center gap-2 ms-auto">
                        <input class="form-control form-control-sm" type="search" id="searchInput"
                            placeholder="Search…">
                        <button class="btn btn-success btn-sm text-nowrap" data-bs-toggle="modal"
                            data-bs-target="#sectionModal">
                            <i class="bi bi-plus-circle me-1"></i> New Section
                        </button>
                    </div>
                </div>

                <div class="card-body">
                    <!-- desktop table -->
                    <div class="table-responsive d-none d-md-block">
                        <table id="sectionTable" class="table table-bordered table-hover align-middle text-center mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th style="width:50px;">#</th>
                                    <th>Section Code</th>
                                    <th>Section Name</th>
                                    <th>Description</th>
                                    <th style="width:120px;">Status</th>
                                    <th style="width:200px;">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="sectionTableBody"></tbody>
                        </table>
                    </div>

                    <!-- phone cards -->
                    <div class="d-block d-md-none" id="cardView"></div>
                </div>

                <div class="card-footer clearfix">
                    <ul class="pagination pagination-sm m-0 float-end" id="pagination"></ul>
                </div>
            </div>
        </main>

        <?php require_once("includes/footer.php"); ?>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="sectionModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form id="sectionForm">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalTitle">Add Section</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="sectionId">
                        <div class="mb-3">
                            <label class="form-label">Section Code</label>
                            <input type="text" class="form-control" id="sectionCode" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Section Name</label>
                            <input type="text" class="form-control" id="sectionName" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" id="description" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-success">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js "></script>
    <script src="./js/adminlte.js"></script>
    <script>
        let currentPage = 1;
        let searchTerm = '';

        /* ----------  LOAD  ---------- */
        function loadSections(page = 1, search = '') {
            fetch(`api/section/read.php?p=${page}&s=${encodeURIComponent(search)}`)
                .then(r => r.json())
                .then(data => renderTable(data.sections || [], data.page, data.pages));
        }

        /* ----------  RENDER  ---------- */
        function renderTable(list, page, pages) {
            const headers = ['#', 'Section Code', 'Section Name', 'Description', 'Status', 'Actions'];

            /* ---- desktop rows ---- */
            const row = (s, i) => `
        <tr>
            <td data-label="${headers[0]}">${((page - 1) * 10) + i + 1}</td>
            <td data-label="${headers[1]}">${s.section_code}</td>
            <td data-label="${headers[2]}" class="text-start">${s.section_name}</td>
            <td data-label="${headers[3]}">${s.description || '-'}</td>
            <td data-label="${headers[4]}">
                <span class="badge bg-${s.is_active ? 'success' : 'secondary'}">${s.is_active ? 'Active' : 'Inactive'}</span>
            </td>
            <td data-label="${headers[5]}">
                <button class="btn btn-sm btn-warning me-1" onclick="editSection(${s.id})"><i class="bi bi-pencil-square"></i> Edit</button>
                <button class="btn btn-sm ${s.is_active ? 'btn-danger' : 'btn-outline-success'}"
                        onclick="toggleSection(${s.id},${s.is_active})"
                        data-bs-toggle="tooltip" data-bs-placement="top"
                        title="${s.is_active ? 'Deactivate' : 'Activate'}">
                    <i class="bi ${s.is_active ? 'bi-toggle-off' : 'bi-toggle-on'}"></i> ${s.is_active ? 'Deactivate' : 'Activate'}
                </button>
            </td>
        </tr>`;

            /* ---- phone cards ---- */
            const card = (s, i) => `
        <div class="card mb-3 shadow-sm">
            <div class="card-header bg-light d-flex justify-content-between">
                <span class="fw-bold">${((page - 1) * 10) + i + 1}. ${s.section_name}</span>
                <span class="badge bg-${s.is_active ? 'success' : 'secondary'}">${s.is_active ? 'Active' : 'Inactive'}</span>
            </div>
            <div class="card-body py-2 small">
                <div class="row mb-1"><div class="col-4 text-muted">Code</div><div class="col-8">${s.section_code}</div></div>
                <div class="row mb-1"><div class="col-4 text-muted">Description</div><div class="col-8">${s.description || '-'}</div></div>
            </div>
            <div class="card-footer d-grid gap-2">
                <button class="btn btn-sm btn-warning" onclick="editSection(${s.id})"><i class="bi bi-pencil-square"></i> Edit</button>
                <button class="btn btn-sm ${s.is_active ? 'btn-danger' : 'btn-outline-success'}"
                        onclick="toggleSection(${s.id},${s.is_active})"
                        data-bs-toggle="tooltip" data-bs-placement="top"
                        title="${s.is_active ? 'Deactivate' : 'Activate'}">
                    <i class="bi ${s.is_active ? 'bi-toggle-off' : 'bi-toggle-on'}"></i> ${s.is_active ? 'Deactivate' : 'Activate'}
                </button>
            </div>
        </div>`;

            document.getElementById('sectionTableBody').innerHTML = list.map(row).join('');
            document.getElementById('cardView').innerHTML = list.map(card).join('');

            let p = '';
            for (let i = 1; i <= pages; i++) p += `<li class="page-item ${i === page ? 'active' : ''}"><a class="page-link" href="#" onclick="loadSections(${i}, searchTerm)">${i}</a></li>`;
            document.getElementById('pagination').innerHTML = p;
        }

        /* ----------  ADD / EDIT  ---------- */
        document.getElementById('sectionForm').addEventListener('submit', e => {
            e.preventDefault();
            const id = document.getElementById('sectionId').value;
            const data = {
                id: id || undefined,
                section_code: document.getElementById('sectionCode').value.trim(),
                section_name: document.getElementById('sectionName').value.trim(),
                description: document.getElementById('description').value.trim()
            };

            fetch('api/section/save.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            })
                .then(r => r.json())
                .then(res => {
                    if (res.success) {
                        bootstrap.Modal.getInstance(document.getElementById('sectionModal')).hide();
                        loadSections(currentPage, searchTerm);
                        e.target.reset();
                    } else {
                        alert(res.error || 'Save failed');
                    }
                });
        });

        function editSection(id) {
            fetch(`api/section/fetch.php?id=${id}`)
                .then(r => r.json())
                .then(data => {
                    document.getElementById('sectionId').value = data.id;
                    document.getElementById('sectionCode').value = data.section_code;
                    document.getElementById('sectionName').value = data.section_name;
                    document.getElementById('description').value = data.description || '';
                    document.getElementById('modalTitle').textContent = 'Edit Section';
                    new bootstrap.Modal(document.getElementById('sectionModal')).show();
                });
        }

        /* ----------  ASYNC TOGGLE  ---------- */
        async function toggleSection(id, currentState) {
            const newStatus = currentState === 1 ? 0 : 1;
            const action = newStatus === 1 ? 'Activate' : 'Deactivate';
            if (!confirm(`${action} this section?`)) return;

            try {
                const res = await fetch('api/section/toggle.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: id })
                });
                if (!res.ok) throw new Error(`HTTP ${res.status}`);
                const json = await res.json();
                if (json.success) {
                    loadSections(currentPage, searchTerm);
                } else {
                    alert(json.error || 'Toggle failed');
                }
            } catch (err) {
                console.error(err);
                alert('Could not change status: ' + err.message);
            }
        }

        /* ----------  SEARCH  ---------- */
        document.getElementById('searchInput').addEventListener('input', e => {
            searchTerm = e.target.value;
            currentPage = 1;
            loadSections(currentPage, searchTerm);
        });

        /* ----------  RESET MODAL  ---------- */
        document.getElementById('sectionModal').addEventListener('hidden.bs.modal', () => {
            document.getElementById('sectionForm').reset();
            document.getElementById('sectionId').value = '';
            document.getElementById('modalTitle').textContent = 'Add Section';
        });

        /* ----------  INIT  ---------- */
        loadSections();
    </script>
</body>

</html>