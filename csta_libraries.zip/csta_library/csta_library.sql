-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 03, 2026 at 07:43 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `csta_library`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`id`, `user_id`, `action`, `module`, `details`, `ip_address`, `created_at`) VALUES
(83, 1, 'Logout', 'Auth', 'User logged out', '::1', '2026-05-03 16:13:45'),
(84, 1, 'Login', 'Auth', 'Borrower logged in', '::1', '2026-05-03 16:13:51'),
(85, 1, 'Borrow', 'Borrowing', 'TXN-0004 via borrower portal', '::1', '2026-05-03 16:13:56'),
(86, 1, 'Borrow', 'Borrowing', 'TXN-0005 via borrower portal', '::1', '2026-05-03 16:13:59'),
(87, 1, 'Borrow', 'Borrowing', 'TXN-0006 via borrower portal', '::1', '2026-05-03 16:14:00'),
(88, 1, 'Logout', 'Auth', 'User logged out', '::1', '2026-05-03 16:14:08'),
(89, 1, 'Login', 'Auth', 'Borrower logged in', '::1', '2026-05-03 16:14:40'),
(90, 1, 'Logout', 'Auth', 'User logged out', '::1', '2026-05-03 16:24:01'),
(91, 1, 'Login', 'Auth', 'Admin logged in', '::1', '2026-05-03 16:24:06'),
(92, 1, 'Payment', 'Borrowing', 'Marked penalty paid for TXN-002: PHP 45.00', '::1', '2026-05-03 16:24:19'),
(93, 1, 'Payment', 'Borrowing', 'Marked penalty paid for TXN-0003: PHP 500.00', '::1', '2026-05-03 16:24:33'),
(94, 1, 'Logout', 'Auth', 'User logged out', '::1', '2026-05-03 16:30:05'),
(95, 1, 'Login', 'Auth', 'Admin logged in', '::1', '2026-05-03 17:11:20'),
(96, 1, 'Logout', 'Auth', 'User logged out', '::1', '2026-05-03 17:11:40'),
(97, 1, 'Login', 'Auth', 'Borrower logged in', '::1', '2026-05-03 17:19:27'),
(98, 1, 'Logout', 'Auth', 'User logged out', '::1', '2026-05-03 17:19:30'),
(99, 1, 'Login', 'Auth', 'Borrower logged in', '::1', '2026-05-03 17:19:38'),
(100, 1, 'Logout', 'Auth', 'User logged out', '::1', '2026-05-03 17:19:48'),
(101, 1, 'Login', 'Auth', 'Admin logged in', '::1', '2026-05-03 17:19:52'),
(102, 1, 'Logout', 'Auth', 'User logged out', '::1', '2026-05-03 17:23:41'),
(103, 1, 'Login', 'Auth', 'Admin logged in', '::1', '2026-05-03 17:35:52'),
(104, 1, 'Logout', 'Auth', 'User logged out', '::1', '2026-05-03 17:35:59'),
(105, 1, 'Login', 'Auth', 'Borrower logged in', '::1', '2026-05-03 17:37:38'),
(106, 1, 'Logout', 'Auth', 'User logged out', '::1', '2026-05-03 17:37:56'),
(107, 1, 'Login', 'Auth', 'Admin logged in', '::1', '2026-05-03 17:38:01'),
(108, 1, 'Logout', 'Auth', 'User logged out', '::1', '2026-05-03 17:40:03'),
(109, 1, 'Login', 'Auth', 'Borrower logged in', '::1', '2026-05-03 17:40:08');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `book_code` varchar(20) NOT NULL,
  `title` varchar(200) NOT NULL,
  `author` varchar(150) NOT NULL,
  `isbn` varchar(30) DEFAULT NULL,
  `category` varchar(80) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `available` int(11) NOT NULL DEFAULT 1,
  `description` text DEFAULT NULL,
  `cover_image` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `book_code`, `title`, `author`, `isbn`, `category`, `quantity`, `available`, `description`, `cover_image`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'BK-001', 'Introduction to Python', 'Noel Gagolinan', '978-1590282410', 'Computer Science', 26, 19, '', 'book_1777296219_d2f88e95.jpg', 1, '2026-04-27 11:39:07', '2026-05-03 16:14:00'),
(2, 'BK-002', 'Database Systems', 'Jeffry Drilon', '978-0072465631', 'Computer Science', 7, 4, NULL, NULL, 0, '2026-04-27 11:39:07', '2026-04-27 13:21:44'),
(3, 'BK-003', 'The Great Gatsby', 'Malou Sahagun', '978-0743273565', 'Literature', 5, 2, '', 'book_1777296313_5ce1562a.jpg', 1, '2026-04-27 11:39:07', '2026-05-03 15:07:25'),
(4, 'BK-004', 'Calculus Early Transcendentals', 'Harold Lucero', '978-1285741550', 'Mathematics', 4, 2, '', 'book_1777824784_0a5fad65.jpg', 1, '2026-04-27 11:39:07', '2026-05-03 16:13:56'),
(5, 'BK-005', 'Philippine History', 'Michael Pangilinan', '978-9710803002', 'Social Studies', 15, 10, '', 'book_1777296250_4100e397.jpg', 1, '2026-04-27 11:39:07', '2026-05-03 15:07:08'),
(6, 'BK-006', 'Introduction to Java', 'Larry Salva', '978-1285741331', 'Computer Science', 54, 53, '', 'book_1777296164_1798dbad.jpg', 1, '2026-04-27 12:01:04', '2026-05-03 16:13:59'),
(7, 'BK-0007', 'Leaning SQL', 'Andre Hechanova', '0-5064-1539-2', 'Computer Science', 90, 50, '', 'book_1777824793_9c0fa516.jpg', 1, '2026-05-03 15:14:32', '2026-05-03 16:13:13');

-- --------------------------------------------------------

--
-- Table structure for table `borrowers`
--

CREATE TABLE `borrowers` (
  `id` int(11) NOT NULL,
  `borrower_code` varchar(20) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `borrower_type` enum('student','faculty','staff') NOT NULL DEFAULT 'student',
  `department` varchar(100) DEFAULT NULL,
  `year_level` varchar(30) DEFAULT NULL,
  `contact` varchar(30) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `borrowers`
--

INSERT INTO `borrowers` (`id`, `borrower_code`, `full_name`, `borrower_type`, `department`, `year_level`, `contact`, `email`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'BR-001', 'Cristine Gonzales', 'student', 'Computer Science', '3rd Year', '09123456789', NULL, 1, '2026-04-27 11:39:08', '2026-04-27 11:39:08'),
(2, 'BR-002', 'Luke San Jose', 'student', 'Education', '2nd Year', '09234567890', NULL, 1, '2026-04-27 11:39:08', '2026-04-27 11:39:08'),
(3, 'BR-003', 'Renwel Lucero', 'student', 'Computer Science', '2nd Year', '09667890123', NULL, 0, '2026-04-27 11:39:08', '2026-05-03 15:17:17'),
(4, 'BR-004', 'James Abenir', 'faculty', 'Science Department', '', '09111222333', '', 1, '2026-04-27 11:39:08', '2026-05-03 11:53:48'),
(5, 'BR-005', 'Renwel Lucero', 'student', 'Information Technology', '3rd Year', '9880983434342', 'renwellucero69@gmail.com', 1, '2026-05-03 11:34:11', '2026-05-03 11:34:11');

-- --------------------------------------------------------

--
-- Table structure for table `borrowing`
--

CREATE TABLE `borrowing` (
  `id` int(11) NOT NULL,
  `transaction_no` varchar(20) NOT NULL,
  `borrower_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `borrowed_date` date NOT NULL,
  `due_date` date NOT NULL,
  `returned_date` date DEFAULT NULL,
  `condition_out` varchar(50) DEFAULT 'Good',
  `condition_in` varchar(50) DEFAULT NULL,
  `status` enum('active','returned','overdue','lost') NOT NULL DEFAULT 'active',
  `penalty_amount` decimal(8,2) DEFAULT 0.00,
  `penalty_paid` tinyint(1) DEFAULT 0,
  `notes` text DEFAULT NULL,
  `processed_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `borrowing`
--

INSERT INTO `borrowing` (`id`, `transaction_no`, `borrower_id`, `book_id`, `borrowed_date`, `due_date`, `returned_date`, `condition_out`, `condition_in`, `status`, `penalty_amount`, `penalty_paid`, `notes`, `processed_by`, `created_at`, `updated_at`) VALUES
(1, 'TXN-001', 1, 1, '2026-04-27', '2026-05-04', '2026-05-03', 'Good', 'Damaged', 'returned', 0.00, 0, NULL, 1, '2026-04-27 11:39:08', '2026-05-03 13:16:33'),
(2, 'TXN-002', 2, 4, '2026-04-17', '2026-04-24', '2026-05-03', 'Good', 'Good', 'returned', 45.00, 1, NULL, 1, '2026-04-27 11:39:08', '2026-05-03 16:24:19'),
(3, 'TXN-0003', 1, 5, '2026-04-27', '2026-05-04', '2026-05-03', 'Good', 'Lost', 'returned', 500.00, 1, 'Borrowed via portal', 1, '2026-04-27 17:12:57', '2026-05-03 16:24:33'),
(4, 'TXN-0004', 1, 4, '2026-05-03', '2026-05-10', NULL, 'Good', NULL, 'active', 0.00, 0, 'Borrowed via portal', 1, '2026-05-03 16:13:56', '2026-05-03 16:13:56'),
(5, 'TXN-0005', 1, 6, '2026-05-03', '2026-05-10', NULL, 'Good', NULL, 'active', 0.00, 0, 'Borrowed via portal', 1, '2026-05-03 16:13:59', '2026-05-03 16:13:59'),
(6, 'TXN-0006', 1, 1, '2026-05-03', '2026-05-10', NULL, 'Good', NULL, 'active', 0.00, 0, 'Borrowed via portal', 1, '2026-05-03 16:14:00', '2026-05-03 16:14:00');

-- --------------------------------------------------------

--
-- Table structure for table `supplies`
--

CREATE TABLE `supplies` (
  `id` int(11) NOT NULL,
  `supply_code` varchar(20) NOT NULL,
  `item_name` varchar(150) NOT NULL,
  `category` varchar(80) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `reorder_level` int(11) NOT NULL DEFAULT 10,
  `unit` varchar(30) DEFAULT 'pcs',
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `supplies`
--

INSERT INTO `supplies` (`id`, `supply_code`, `item_name`, `category`, `quantity`, `reorder_level`, `unit`, `description`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'SUP-001', 'Ballpen', 'Writing Materials', 150, 50, 'pcs', NULL, 1, '2026-04-27 11:39:08', '2026-04-27 11:39:08'),
(2, 'SUP-002', 'Bond Paper', 'Paper Products', 25, 20, 'ream', NULL, 1, '2026-04-27 11:39:08', '2026-04-27 11:39:08'),
(3, 'SUP-003', 'Acrylic Paint Set', 'Art Supplies', 24, 5, 'set', '', 1, '2026-04-27 11:39:08', '2026-05-03 12:57:04'),
(4, 'SUP-004', 'Whiteboard Marker', 'Writing Materials', 33, 10, 'pcs', '', 1, '2026-04-27 11:39:08', '2026-05-03 12:55:59'),
(5, 'SUP-005', 'Correction Tape', 'Office Supplies', 45, 15, 'pcs', NULL, 1, '2026-04-27 11:39:08', '2026-04-27 11:39:08'),
(6, 'SUP-006', 'Pencil', 'Writing Materials', 33, 10, 'pcs', '', 1, '2026-05-03 12:55:53', '2026-05-03 12:55:53'),
(7, 'SUP-007', 'Folders', 'Office Supplies', 44, 10, 'pcs', '', 1, '2026-05-03 13:01:23', '2026-05-03 13:01:23'),
(8, 'SUP-008', 'Japanese Paper', 'Paper Products', 59, 10, 'pcs', '', 1, '2026-05-03 13:01:51', '2026-05-03 13:01:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `role` enum('admin','staff') NOT NULL DEFAULT 'staff',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `full_name`, `role`, `is_active`, `created_at`) VALUES
(1, 'admin', '$2y$10$jmA51so.HNC9VVWvEbblaepI0zPiANrKYK/xqFOw.xb9AW3CJGX3C', 'Administrator', 'admin', 1, '2026-04-27 11:39:07'),
(2, 'librarian', '$2y$10$jmA51so.HNC9VVWvEbblaepI0zPiANrKYK/xqFOw.xb9AW3CJGX3C', 'Head Librarian', 'staff', 1, '2026-04-27 11:39:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `book_code` (`book_code`);

--
-- Indexes for table `borrowers`
--
ALTER TABLE `borrowers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `borrower_code` (`borrower_code`);

--
-- Indexes for table `borrowing`
--
ALTER TABLE `borrowing`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transaction_no` (`transaction_no`),
  ADD KEY `borrower_id` (`borrower_id`),
  ADD KEY `book_id` (`book_id`),
  ADD KEY `processed_by` (`processed_by`);

--
-- Indexes for table `supplies`
--
ALTER TABLE `supplies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `supply_code` (`supply_code`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `borrowers`
--
ALTER TABLE `borrowers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `borrowing`
--
ALTER TABLE `borrowing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `supplies`
--
ALTER TABLE `supplies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD CONSTRAINT `activity_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `borrowing`
--
ALTER TABLE `borrowing`
  ADD CONSTRAINT `borrowing_ibfk_1` FOREIGN KEY (`borrower_id`) REFERENCES `borrowers` (`id`),
  ADD CONSTRAINT `borrowing_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`),
  ADD CONSTRAINT `borrowing_ibfk_3` FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
