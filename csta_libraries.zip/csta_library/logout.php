<?php
require_once __DIR__ . '/includes/config.php';
if (isLoggedIn()) {
    $u = getCurrentUser();
    logActivity($u['id'], 'Logout', 'Auth', 'User logged out');
}
session_destroy();
header('Location: ' . BASE_URL . '/login.php');
exit;
