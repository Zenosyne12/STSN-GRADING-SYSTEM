<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireLogin();
if ($_SESSION['role'] !== 'borrower') {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}
$pageTitle = 'Dashboard';
$borrowerId = $_SESSION['user_id'];

$borrower = $pdo->prepare("SELECT * FROM borrowers WHERE id=?");
$borrower->execute([$borrowerId]);
$borrower = $borrower->fetch();
if (!$borrower) {
    echo "Borrower not found";
    exit;
}

$activeBorrow = $pdo->query("SELECT COUNT(*) FROM borrowing WHERE borrower_id=$borrowerId AND status IN('active','overdue')")->fetchColumn();
$returned = $pdo->query("SELECT COUNT(*) FROM borrowing WHERE borrower_id=$borrowerId AND status='returned'")->fetchColumn();
$overdue = $pdo->query("SELECT COUNT(*) FROM borrowing WHERE borrower_id=$borrowerId AND status='overdue'")->fetchColumn();

$totalPenalty = $pdo->query("SELECT COALESCE(SUM(penalty_amount),0) FROM borrowing WHERE borrower_id=$borrowerId AND penalty_amount > 0 AND penalty_paid=0")->fetchColumn();
?>
<?php require_once __DIR__ . '/layout/header.php'; ?>
<h1 style="font-size:1.8rem;font-weight:800;color:#1a3a2a;margin-bottom:.5rem;">Welcome,
        <?= esc($borrower['full_name']) ?>!
    </h1>
    <p style="color:#6c757d;margin-bottom:1.5rem;"><?= ucfirst(esc($borrower['borrower_type'])) ?> •
        <?= esc($borrower['department']) ?>
    </p>

    <div class="row g-3 mb-3">
        <div class="col-md-4">
            <div class="stat-card">
                <div class="stat-icon" style="background:#e8f5e9;color:#2e7d32;"><i class="bi bi-book-half"></i></div>
                <div>
                    <div class="stat-num"><?= $activeBorrow ?></div>
                    <div class="stat-lbl">Currently Borrowed</div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-card">
                <div class="stat-icon" style="background:#e3f2fd;color:#1565c0;"><i class="bi bi-check-circle"></i>
                </div>
                <div>
                    <div class="stat-num"><?= $returned ?></div>
                    <div class="stat-lbl">Books Returned</div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-card" style="flex-direction:row;justify-content:space-between;align-items:center;">
                <div style="display:flex;gap:1rem;align-items:center;">
                    <div class="stat-icon" style="background:#fff3e0;color:#e65100;"><i
                            class="bi bi-exclamation-triangle"></i></div>
                    <div>
                        <div class="stat-num">₱<?= number_format($totalPenalty, 2) ?></div>
                        <div class="stat-lbl">Pending Penalties</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if ($overdue > 0): ?>
        <div class="alert-danger"><i class="bi bi-exclamation-circle"></i>
            <div><strong><?= $overdue ?> overdue book(s)!</strong> You have ₱<?= number_format($totalPenalty, 2) ?> in
                penalties. Please return them as soon as possible.</div>
        </div>
    <?php endif; ?>

    <div class="row g-3">
        <div class="col-lg-8">
            <div class="card-custom">
                <div class="card-header-custom">
                    <div>
                        <p class="card-title-custom">Your Borrowing Status</p>
                        <p style="font-size:.75rem;color:#6c757d;margin:.1rem 0 0;">Overview of your account</p>
                    </div>
                </div>
                <div style="padding:1.5rem;">
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                        <div style="padding:1rem;background:#f0faf5;border-radius:10px;border:1px solid #c8e6c9;">
                            <p
                                style="font-size:.8rem;font-weight:700;color:#2e7d32;margin:0;text-transform:uppercase;letter-spacing:.05em;">
                                Active Loans</p>
                            <p style="font-size:1.8rem;font-weight:800;color:#1a3a2a;margin:.3rem 0 0;">
                                <?= $activeBorrow ?>/5</p>
                            <p style="font-size:.75rem;color:#6c757d;margin:.2rem 0 0;">You can borrow
                                <?= max(0, 5 - $activeBorrow) ?> more</p>
                        </div>
                        <div style="padding:1rem;background:#e3f2fd;border-radius:10px;border:1px solid #90caf9;">
                            <p
                                style="font-size:.8rem;font-weight:700;color:#1565c0;margin:0;text-transform:uppercase;letter-spacing:.05em;">
                                Total Returned</p>
                            <p style="font-size:1.8rem;font-weight:800;color:#1a3a2a;margin:.3rem 0 0;"><?= $returned ?>
                            </p>
                            <p style="font-size:.75rem;color:#6c757d;margin:.2rem 0 0;">All time borrowing history</p>
                        </div>
                    </div>
                    <div
                        style="margin-top:1rem;padding:1rem;background:#fafafa;border-radius:10px;border:1px solid #e9ecef;">
                        <p
                            style="font-size:.8rem;font-weight:700;color:#495057;margin:0 0 .5rem;text-transform:uppercase;letter-spacing:.05em;">
                            ⏱️ Borrowing Policy</p>
                        <ul style="font-size:.8rem;color:#6c757d;padding-left:1.2rem;margin:0;line-height:1.6;">
                            <li>Borrow up to <strong>5 books</strong> at a time</li>
                            <li>Keep books for <strong>7 days</strong></li>
                            <li>Late return: <strong>₱5/day</strong> penalty</li>
                            <li>Return books in good condition</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card-custom">
                <div class="card-header-custom">
                    <p class="card-title-custom">Borrower Info</p>
                </div>
                <div style="padding:1rem;font-size:.85rem;">
                    <div style="margin-bottom:.75rem;">
                        <p
                            style="color:#6c757d;margin:0 0 .2rem;font-size:.75rem;font-weight:700;text-transform:uppercase;">
                            ID</p>
                        <p style="color:#1a3a2a;margin:0;font-weight:700;"><?= esc($borrower['borrower_code']) ?></p>
                    </div>
                    <div style="margin-bottom:.75rem;">
                        <p
                            style="color:#6c757d;margin:0 0 .2rem;font-size:.75rem;font-weight:700;text-transform:uppercase;">
                            Type</p>
                        <p style="color:#1a3a2a;margin:0;"><?= ucfirst(esc($borrower['borrower_type'])) ?></p>
                    </div>
                    <div style="margin-bottom:.75rem;">
                        <p
                            style="color:#6c757d;margin:0 0 .2rem;font-size:.75rem;font-weight:700;text-transform:uppercase;">
                            Department</p>
                        <p style="color:#1a3a2a;margin:0;"><?= esc($borrower['department']) ?></p>
                    </div>
                    <div>
                        <p
                            style="color:#6c757d;margin:0 0 .2rem;font-size:.75rem;font-weight:700;text-transform:uppercase;">
                            Contact</p>
                        <p style="color:#1a3a2a;margin:0;"><?= esc($borrower['contact']) ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php require_once __DIR__ . '/layout/footer.php'; ?>
