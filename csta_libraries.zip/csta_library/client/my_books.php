<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireLogin();
$pageTitle = 'My Books';
$borrowerId = $_SESSION['user_id'];

$borrowed = $pdo->query("
    SELECT b.*, bk.title, bk.book_code
    FROM borrowing b
    JOIN books bk ON bk.id=b.book_id
    WHERE b.borrower_id=$borrowerId
    ORDER BY CASE WHEN b.status IN('active','overdue') THEN 0 ELSE 1 END, b.due_date ASC")->fetchAll();
?>
<?php require_once __DIR__ . '/layout/header.php'; ?>

<div style="margin-bottom:1.5rem;">
  <h1 style="font-size:1.5rem;font-weight:800;color:#1a3a2a;margin-bottom:.5rem;">My Books</h1>
  <p style="color:#6c757d;">All your borrowed and returned books.</p>
</div>

<div class="card-custom">
  <div class="card-header-custom">
    <div>
      <p class="card-title-custom">Borrowing History</p>
    </div>
  </div>
  <div style="overflow-x:auto;">
    <?php if (!$borrowed): ?>
      <div style="padding:3rem 1rem;text-align:center;color:#6c757d;">
        <i class="bi bi-inbox" style="font-size:2.5rem;opacity:.3;"></i>
        <p style="font-size:1rem;margin-top:1rem;">No borrowing history yet.</p>
        <a href="<?= BASE_URL ?>/client/browse.php" class="btn-primary-custom"><i class="bi bi-book"></i> Start
          Browsing</a>
      </div>
    <?php else: ?>
      <table class="tbl">
        <thead>
          <tr>
            <th>Transaction ID</th>
            <th>Book Title</th>
            <th>Borrowed Date</th>
            <th>Due Date</th>
            <th>Returned Date</th>
            <th>Status</th>
            <th>Penalty</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($borrowed as $b):
            $isOverdue = ($b['status'] === 'overdue');
            $daysPassed = ceil((time() - strtotime($b['due_date'])) / 86400);
            ?>
            <tr style="<?= $isOverdue ? 'background:#fff8f8;' : '' ?>">
              <td style="font-weight:700;color:#2d4a3e;font-size:.8rem;"><?= esc($b['transaction_no']) ?></td>
              <td style="font-weight:600;"><?= esc($b['title']) ?></td>
              <td style="font-size:.82rem;"><?= date('M d, Y', strtotime($b['borrowed_date'])) ?></td>
              <td style="font-size:.82rem;<?= $isOverdue ? 'color:#b71c1c;font-weight:700;' : '' ?>">
                <?= date('M d, Y', strtotime($b['due_date'])) ?></td>
              <td style="font-size:.82rem;color:#6c757d;">
                <?= $b['returned_date'] ? date('M d, Y', strtotime($b['returned_date'])) : '—' ?></td>
              <td>
                <?php if ($b['status'] === 'active'): ?>
                  <span
                    style="background:#e8f5e9;color:#2e7d32;padding:.2rem .5rem;border-radius:6px;font-size:.7rem;font-weight:700;">ACTIVE</span>
                <?php elseif ($b['status'] === 'overdue'): ?>
                  <span
                    style="background:#fce4ec;color:#b71c1c;padding:.2rem .5rem;border-radius:6px;font-size:.7rem;font-weight:700;">⚠️
                    OVERDUE</span>
                <?php else: ?>
                  <span
                    style="background:#e3f2fd;color:#1565c0;padding:.2rem .5rem;border-radius:6px;font-size:.7rem;font-weight:700;">RETURNED</span>
                <?php endif; ?>
              </td>
              <td style="text-align:center;font-weight:700;<?= $b['penalty_amount'] > 0 && !$b['penalty_paid'] ? 'color:#b71c1c;' : '' ?>">
                <?php if ($b['penalty_amount'] > 0): ?>
                  &#8369;<?= number_format($b['penalty_amount'], 2) ?>
                  <?php if ($b['penalty_paid']): ?>
                    <span style="display:block;color:#2e7d32;font-size:.7rem;">Paid</span>
                  <?php else: ?>
                    <span style="display:block;color:#b71c1c;font-size:.7rem;">Pending</span>
                  <?php endif; ?>
                <?php else: ?>
                  —
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/layout/footer.php'; ?>
