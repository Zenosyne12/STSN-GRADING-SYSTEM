<?php $user = getCurrentUser();
$currentPage = basename($_SERVER['PHP_SELF'], '.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= esc($pageTitle ?? 'Borrower Portal') ?> | CSTA Library</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <style>
:root {
      --primary: #6E412A;
      --primary-dark: #5a3520;
    }

    * {
      box-sizing: border-box;
    }

    body {
      background: #f4f6f8;
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      padding: 0;
    }

    .navbar-custom {
      background: linear-gradient(135deg, #6E412A 0%, #4a2511 100%);
      border-bottom: 1px solid rgba(255,255,255,.1);
      padding: .7rem 1.5rem;
      box-shadow: 0 2px 12px rgba(0,0,0,.08);
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: .6rem;
      font-size: 1.1rem;
      font-weight: 800;
      color: #fff;
      text-decoration: none;
    }

    .brand-icon {
      width: 34px;
      height: 34px;
      background: rgba(255,255,255,.15);
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fff;
      font-weight: 900;
      backdrop-filter: blur(10px);
    }

    .nav-link-custom {
      color: rgba(255,255,255,.85);
      text-decoration: none;
      font-size: .9rem;
      font-weight: 500;
      padding: .5rem .9rem;
      border-radius: 8px;
      transition: all .2s;
    }

    .nav-link-custom:hover {
      background: rgba(255,255,255,.12);
      color: #fff;
    }

    .nav-link-custom.active {
      background: rgba(255,255,255,.18);
      color: #fff;
      font-weight: 700;
    }

    .container-custom {
      max-width: 1200px;
      margin: 0 auto;
      padding: 1.5rem;
    }

    .stat-card {
      background: #fff;
      border-radius: 14px;
      padding: 1.2rem;
      border: 1px solid #e9ecef;
      box-shadow: 0 2px 12px rgba(0, 0, 0, .05);
      display: flex;
      align-items: center;
      gap: 1rem;
      transition: transform .2s, box-shadow .2s;
    }

    .stat-card:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 20px rgba(0, 0, 0, .08);
    }

    .stat-icon {
      width: 52px;
      height: 52px;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.4rem;
    }

    .stat-num {
      font-size: 1.6rem;
      font-weight: 800;
      color: #2c1a0d;
      line-height: 1;
    }

    .stat-lbl {
      font-size: .78rem;
      color: #8d6b52;
      margin-top: .2rem;
    }

    .card-custom {
      background: #fff;
      border-radius: 14px;
      border: 1px solid #e9ecef;
      box-shadow: 0 2px 12px rgba(0, 0, 0, .05);
      overflow: hidden;
    }

    .card-header-custom {
      padding: 1rem 1.3rem;
      border-bottom: 1px solid #f0f0f0;
      background: #faf8f7;
    }

    .card-title-custom {
      font-size: .95rem;
      font-weight: 700;
      color: #4a2511;
      margin: 0;
    }

    .btn-primary-custom {
      background: linear-gradient(135deg, #6E412A 0%, #5a3520 100%);
      color: #fff;
      border: none;
      border-radius: 8px;
      padding: .45rem 1rem;
      font-size: .85rem;
      font-weight: 600;
      cursor: pointer;
      transition: all .2s;
      display: inline-flex;
      align-items: center;
      gap: .3rem;
      text-decoration: none;
      box-shadow: 0 2px 8px rgba(110, 65, 42, .25);
    }

    .btn-primary-custom:hover {
      background: linear-gradient(135deg, #8a5537 0%, #6a3d25 100%);
      color: #fff;
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(110, 65, 42, .35);
    }

    .btn-outline-custom {
      background: #fff;
      color: #6E412A;
      border: 1.5px solid #6E412A;
      border-radius: 8px;
      padding: .42rem .9rem;
      font-size: .85rem;
      font-weight: 600;
      cursor: pointer;
      transition: all .2s;
      display: inline-flex;
      align-items: center;
      gap: .3rem;
      text-decoration: none;
    }

    .btn-outline-custom:hover {
      background: #f9f4f0;
      border-color: #5a3520;
      color: #5a3520;
    }

    .book-card {
      background: #fff;
      border-radius: 14px;
      border: 1px solid #e9ecef;
      overflow: hidden;
      transition: all .25s;
      height: 100%;
      display: flex;
      flex-direction: column;
    }

    .book-card:hover {
      box-shadow: 0 12px 30px rgba(110, 65, 42, .15);
      transform: translateY(-5px);
      border-color: #d4b89f;
    }

    .book-cover {
      background: linear-gradient(135deg, #f5f0eb 0%, #e8e0d5 100%);
      height: 160px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #6E412A;
      font-size: 2rem;
      border-bottom: 1px solid #e9ecef;
    }

    .book-info {
      padding: .9rem;
      flex: 1;
      display: flex;
      flex-direction: column;
    }

    .book-title {
      font-size: .9rem;
      font-weight: 700;
      color: #4a2511;
      margin: 0 0 .25rem;
      line-height: 1.3;
    }

    .book-author {
      font-size: .78rem;
      color: #8d6b52;
      margin: 0;
    }

    .book-footer {
      padding: .75rem .9rem;
      border-top: 1px solid #f0f0f0;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: .5rem;
    }

    .badge-available {
      background: #e8f5e9;
      color: #2e7d32;
      padding: .2rem .5rem;
      border-radius: 6px;
      font-size: .66rem;
      font-weight: 700;
    }

    .badge-borrowed {
      background: #fce4ec;
      color: #b71c1c;
      padding: .2rem .5rem;
      border-radius: 6px;
      font-size: .66rem;
      font-weight: 700;
    }

    .tbl {
      width: 100%;
      border-collapse: collapse;
    }

    .tbl thead th {
      background: #faf8f7;
      color: #6a422a;
      font-size: .72rem;
      font-weight: 700;
      text-transform: uppercase;
      padding: .75rem 1rem;
      border-bottom: 1.5px solid #e0d5cc;
    }

    .tbl tbody tr:not(:last-child) td {
      border-bottom: 1px solid #f0f0f0;
    }

    .tbl tbody tr:hover td {
      background: #fefdfb;
    }

    .tbl tbody td {
      padding: .75rem 1rem;
      font-size: .85rem;
      color: #4a2511;
    }

    .alert-info {
      background: #fff8e6;
      border: 1px solid #ffd28d;
      border-radius: 10px;
      padding: .6rem .9rem;
      font-size: .82rem;
      color: #856404;
      display: flex;
      gap: .5rem;
      margin-bottom: 1rem;
    }

    .alert-danger {
      background: #fff5f5;
      border: 1px solid #ffd6d7;
      border-radius: 10px;
      padding: .6rem .9rem;
      font-size: .82rem;
      color: #b71c1c;
      display: flex;
      gap: .5rem;
      margin-bottom: 1rem;
    }

    .srch {
      border: 1.5px solid #d4b89f;
      border-radius: 9px;
      padding: .4rem .85rem;
      font-size: .88rem;
      color: #4a2511;
      width: 260px;
      max-width: 100%;
      transition: border-color .2s;
      background: #fff;
    }

    .srch:focus {
      border-color: #6E412A;
      outline: none;
      box-shadow: 0 0 0 3px rgba(110, 65, 42, .15);
    }
  </style>
</head>

<body>
  <nav class="navbar-custom">
    <div
      style="max-width:1200px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;gap:1rem;flex-wrap:wrap;">
<a href="<?= BASE_URL ?>/client/dashboard.php" class="brand-logo">
        <img src="../assets/img/TeresianLOGO.jpg" alt="CSTA Logo" style="width:34px;height:34px;border-radius:8px;">
        <div>CSTA Library</div>
      </a>
      <div style="display:flex;align-items:center;gap:1.5rem;flex-wrap:wrap;">
        <a href="<?= BASE_URL ?>/client/dashboard.php"
          class="nav-link-custom <?= $currentPage === 'dashboard' ? 'active' : '' ?>"><i class="bi bi-speedometer2"></i>
          Dashboard</a>
        <a href="<?= BASE_URL ?>/client/browse.php"
          class="nav-link-custom <?= $currentPage === 'browse' ? 'active' : '' ?>"><i class="bi bi-book"></i> Browse</a>
        <a href="<?= BASE_URL ?>/client/my_books.php"
          class="nav-link-custom <?= $currentPage === 'my_books' ? 'active' : '' ?>"><i class="bi bi-bookmark"></i> My
          Books</a>
        <a href="<?= BASE_URL ?>/logout.php" class="nav-link-custom"><i class="bi bi-box-arrow-right"></i> Logout</a>
      </div>
    </div>
  </nav>
  <div class="container-custom">