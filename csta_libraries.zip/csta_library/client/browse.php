<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireLogin();
$pageTitle = 'Browse Books';
$borrowerId = $_SESSION['user_id'];

$search = trim($_GET['s'] ?? '');
$page = max(1, (int) ($_GET['p'] ?? 1));
$limit = 12;
$offset = ($page - 1) * $limit;

$where = ['is_active=1'];
$params = [];
if ($search) {
  $where[] = "(title LIKE ? OR author LIKE ? OR isbn LIKE ?)";
  $p = "%$search%";
  $params = [$p, $p, $p];
}

$sql = "SELECT * FROM books WHERE " . implode(' AND ', $where) . " ORDER BY title LIMIT $limit OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();

$total = $pdo->prepare("SELECT COUNT(*) FROM books WHERE " . implode(' AND ', $where));
$total->execute($params);
$total = (int) $total->fetchColumn();
$pages = max(1, ceil($total / $limit));

$borrowedCount = $pdo->query("SELECT COUNT(*) FROM borrowing WHERE borrower_id=$borrowerId AND status IN('active','overdue')")->fetchColumn();
?>
<?php require_once __DIR__ . '/layout/header.php'; ?>
<style>
  .book-card .book-cover {
    height: 160px;
    background: #f4f7f9;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px 8px 0 0;
    overflow: hidden;
    cursor: pointer;

  }

  .book-card .book-cover img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.2s;
  }

  .book-card .book-cover:hover img {
    transform: scale(1.05);
  }

  .book-card .book-cover i {
    font-size: 3rem;
    color: #b0bec5;
  }
</style>

<div style="margin-bottom:1.5rem;">
  <h1 style="font-size:1.5rem;font-weight:800;color:#1a3a2a;margin-bottom:.5rem;">Browse Books</h1>
  <p style="color:#6c757d;">Search for books and request to borrow them.</p>
</div>

<?php if ($borrowedCount >= 5): ?>
  <div class="alert-danger"><i class="bi bi-exclamation-circle"></i>
    <div>You've reached the maximum borrowing limit (5 books). Please return a book before borrowing another.</div>
  </div>
<?php endif; ?>

<div class="card-custom mb-3">
  <div style="padding:1rem;border-bottom:1px solid #f0f0f0;display:flex;gap:.5rem;flex-wrap:wrap;">
    <form method="GET" style="display:contents;">
      <input class="srch" type="search" name="s" value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>" placeholder="Search by title or author">
      <button class="btn-primary-custom" type="submit"><i class="bi bi-search"></i> Search</button>
    </form>
  </div>
</div>

<div style="margin-bottom:1.5rem;">
  <?php if (!$books): ?>
    <div style="text-align:center;padding:3rem 1rem;color:#6c757d;">
      <i class="bi bi-search" style="font-size:2.5rem;opacity:.3;"></i>
      <p style="font-size:1.1rem;">No books found</p>
      <a href="browse.php" class="btn-primary-custom">Clear Filters</a>
    </div>
  <?php else: ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:1rem;">
      <?php foreach ($books as $b):
        $borrowed = $pdo->prepare("SELECT id FROM borrowing WHERE book_id=? AND borrower_id=? AND status IN('active','overdue')");
        $borrowed->execute([$b['id'], $borrowerId]);
        $isBorrowed = $borrowed->fetch() ? true : false;

        $imgUrl = !empty($b['cover_image']) ? BASE_URL . '/assets/uploads/books/' . $b['cover_image'] : '';
        ?>
        <div class="book-card">
          <div class="book-cover" onclick="zoomCover('<?= esc($imgUrl) ?>')">
            <?php if ($imgUrl): ?>
              <img src="<?= esc($imgUrl) ?>" alt="<?= esc($b['title']) ?>">
            <?php else: ?>
              <i class="bi bi-book"></i>
            <?php endif; ?>
          </div>
          <div class="book-info">
            <p class="book-title"><?= esc($b['title']) ?></p>
            <p class="book-author"><?= esc($b['author']) ?></p>
            <p class="book-cat"><?= esc($b['category']) ?></p>
          </div>
          <div class="book-footer">
            <div>
              <?php if ($b['available'] > 0): ?>
                <span class="badge-available">AVAILABLE (<?= $b['available'] ?>)</span>
              <?php else: ?>
                <span class="badge-borrowed">ALL BORROWED</span>
              <?php endif; ?>
            </div>
          </div>
          <div style="padding:0 .9rem .75rem;">
            <?php if ($isBorrowed): ?>
              <button class="btn-outline-custom" style="width:100%;justify-content:center;cursor:default;opacity:.6;"
                disabled>
                <i class="bi bi-check-circle"></i> Already Borrowed
              </button>
            <?php elseif ($b['available'] > 0 && $borrowedCount < 5): ?>
              <button class="btn-primary-custom" style="width:100%;justify-content:center;"
                onclick="borrowBook(<?= $b['id'] ?>, '<?= htmlspecialchars($b['title']) ?>')">
                <i class="bi bi-plus-circle"></i> Borrow Now
              </button>
            <?php else: ?>
              <button class="btn-outline-custom" style="width:100%;justify-content:center;cursor:default;opacity:.5;"
                disabled>
                <i class="bi bi-lock"></i> Not Available
              </button>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<?php if ($pages > 1): ?>
  <div style="display:flex;justify-content:center;gap:.3rem;margin-top:2rem;">
    <?php for ($n = 1; $n <= $pages; $n++): ?>
      <a href="?s=<?= urlencode($search) ?>&p=<?= $n ?>"
        style="display:inline-flex;align-items:center;justify-content:center;min-width:32px;height:32px;border-radius:7px;border:1px solid #dee2e6;text-decoration:none;font-size:.8rem;font-weight:600;<?= $n == $page ? 'background:#4a8264;color:#fff;border-color:#4a8264;' : 'background:#fff;color:#4a8264;' ?>">
        <?= $n ?>
      </a>
    <?php endfor; ?>
  </div>
<?php endif; ?>

<script>
  function zoomCover(imgSrc) {
    if (!imgSrc) return;

    Swal.fire({
      imageUrl: imgSrc,
      imageAlt: 'Book Cover',
      imageWidth: 'auto',
      imageHeight: '80vh',
      showCloseButton: true,
      showConfirmButton: false,
      background: '#fff',
      customClass: {
        popup: 'swal-cover-popup'
      }
    });
  }

  function borrowBook(bookId, title) {
    Swal.fire({
      title: 'Borrow Book?',
      html: `<strong>${title}</strong><br><span style="font-size:.85rem;color:#6c757d;">You will have 7 days to return it.</span>`,
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#4a8264',
      cancelButtonColor: '#6c757d',
      confirmButtonText: 'Yes, Borrow!'
    }).then(async result => {
      if (result.isConfirmed) {
        const r = await fetch('<?= BASE_URL ?>/api/client_borrow.php', {
          method: 'POST',
          body: new URLSearchParams({ book_id: bookId })
        });
        const d = await r.json();
        toast(d.message, d.success ? 'success' : 'error');
        if (d.success) setTimeout(() => location.reload(), 1000);
      }
    });
  }
</script>

<?php require_once __DIR__ . '/layout/footer.php'; ?>
