<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireLogin();
header('Content-Type: application/json');

$borrowerId = (int) $_SESSION['user_id'];
$bookId = (int) ($_POST['book_id'] ?? 0);

if (!$bookId) {
    echo json_encode(['success' => false, 'message' => 'Book not found.']);
    exit;
}

$count = $pdo->query("SELECT COUNT(*) FROM borrowing WHERE borrower_id=$borrowerId AND status IN('active','overdue')")->fetchColumn();
if ($count >= 5) {
    echo json_encode(['success' => false, 'message' => 'You\'ve reached the maximum borrowing limit (5 books).']);
    exit;
}

$chk = $pdo->prepare("SELECT id FROM borrowing WHERE book_id=? AND borrower_id=? AND status IN('active','overdue') LIMIT 1");
$chk->execute([$bookId, $borrowerId]);
if ($chk->fetch()) {
    echo json_encode(['success' => false, 'message' => 'You\'re already borrowing this book.']);
    exit;
}

$book = $pdo->prepare("SELECT * FROM books WHERE id=? AND is_active=1 AND available>0");
$book->execute([$bookId]);
$book = $book->fetch();
if (!$book) {
    echo json_encode(['success' => false, 'message' => 'Book is not available.']);
    exit;
}

try {
    $pdo->beginTransaction();
    $txn = 'TXN-' . str_pad($pdo->query("SELECT COUNT(*)+1 FROM borrowing")->fetchColumn(), 4, '0', STR_PAD_LEFT);
    $now = date('Y-m-d');
    $due = date('Y-m-d', strtotime($now . ' +' . LOAN_DAYS . ' days'));

    $stmt = $pdo->prepare("INSERT INTO borrowing (transaction_no,borrower_id,book_id,borrowed_date,due_date,status,notes,processed_by) VALUES (?,?,?,?,?,'active','Borrowed via portal',?)");
    $stmt->execute([$txn, $borrowerId, $bookId, $now, $due, 1]);

    $pdo->prepare("UPDATE books SET available=available-1 WHERE id=?")->execute([$bookId]);
    $pdo->commit();

    logActivity($borrowerId, 'Borrow', 'Borrowing', "$txn via borrower portal");
    echo json_encode(['success' => true, 'message' => "✓ Book borrowed successfully! Due date: " . date('M d, Y', strtotime($due))]);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
