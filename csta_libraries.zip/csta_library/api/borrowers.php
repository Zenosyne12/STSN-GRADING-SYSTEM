<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireLogin();
header('Content-Type: application/json');
$user = getCurrentUser();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$id = (int) ($_POST['id'] ?? 0);
$name = trim($_POST['full_name'] ?? '');
$type = trim($_POST['borrower_type'] ?? 'student');
$dept = trim($_POST['department'] ?? '');
$year = trim($_POST['year_level'] ?? '');
$contact = trim($_POST['contact'] ?? '');
$email = trim($_POST['email'] ?? '');

if (!$name) {
    echo json_encode(['success' => false, 'message' => 'Name is required.']);
    exit;
}

try {
    if ($id > 0) {
        $stmt = $pdo->prepare("UPDATE borrowers SET full_name=?,borrower_type=?,department=?,year_level=?,contact=?,email=?,updated_at=NOW() WHERE id=?");
        $stmt->execute([$name, $type, $dept, $year, $contact, $email, $id]);
        logActivity($user['id'], 'Update', 'Borrowers', "Updated borrower: $name");
        echo json_encode(['success' => true, 'message' => 'Borrower updated successfully.']);
    } else {
        $code = generateCode('BR', 'borrowers', 'id');
        $stmt = $pdo->prepare("INSERT INTO borrowers (borrower_code,full_name,borrower_type,department,year_level,contact,email) VALUES (?,?,?,?,?,?,?)");
        $stmt->execute([$code, $name, $type, $dept, $year, $contact, $email]);
        logActivity($user['id'], 'Create', 'Borrowers', "Added borrower: $name");
        echo json_encode(['success' => true, 'message' => 'Borrower added successfully.']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
