<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireLogin();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
    exit;
}

$id = isset($_POST['id']) && $_POST['id'] !== '' ? (int) $_POST['id'] : null;
$book_code = trim($_POST['book_code'] ?? '');
$title = trim($_POST['title'] ?? '');
$author = trim($_POST['author'] ?? '');
$isbn = trim($_POST['isbn'] ?? '');
$category = trim($_POST['category'] ?? '');
$quantity = (int) ($_POST['quantity'] ?? 0);
$available = isset($_POST['available']) && $_POST['available'] !== '' ? (int) $_POST['available'] : $quantity;
$description = trim($_POST['description'] ?? '');

if (!$title || !$author || $quantity < 1) {
    echo json_encode(['success' => false, 'message' => 'Title, author and quantity are required.']);
    exit;
}

$uploadDir = dirname(__DIR__) . '/assets/uploads/books/';
$cover_image = trim($_POST['existing_cover'] ?? '');

if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

if (!empty($_FILES['cover_image']['tmp_name'])) {
    $file = $_FILES['cover_image'];
    $maxSize = 2 * 1024 * 1024;
    $allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    $extMap = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = $finfo->file($file['tmp_name']);

    if (!in_array($mimeType, $allowed)) {
        echo json_encode(['success' => false, 'message' => 'Only JPG, PNG, WEBP, and GIF images are allowed.']);
        exit;
    }
    if ($file['size'] > $maxSize) {
        echo json_encode(['success' => false, 'message' => 'Image must be under 2MB.']);
        exit;
    }

    $ext = $extMap[$mimeType];
    $newFilename = 'book_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $destPath = $uploadDir . $newFilename;

    if (!move_uploaded_file($file['tmp_name'], $destPath)) {
        echo json_encode(['success' => false, 'message' => 'Failed to save the cover image.']);
        exit;
    }

    if ($cover_image && file_exists($uploadDir . $cover_image)) {
        @unlink($uploadDir . $cover_image);
    }

    $cover_image = $newFilename;
}

if ($id) {
    $stmt = $pdo->prepare("
        UPDATE books
        SET title=?, author=?, isbn=?, category=?, quantity=?, available=?,
            description=?, cover_image=?
        WHERE id=?
    ");
    $stmt->execute([$title, $author, $isbn, $category, $quantity, $available, $description, $cover_image, $id]);
    logActivity($_SESSION['user_id'], 'Update', 'Books', 'Updated book ID ' . $id);
    echo json_encode(['success' => true, 'message' => 'Book updated successfully.']);
} else {
    if (!$cover_image) {
        echo json_encode(['success' => false, 'message' => 'A cover image is required when adding a book.']);
        exit;
    }

    if (!$book_code) {
        $last = $pdo->query("SELECT book_code FROM books ORDER BY id DESC LIMIT 1")->fetchColumn();
        $num = $last ? ((int) preg_replace('/\D/', '', $last) + 1) : 1;
        $book_code = 'BK-' . str_pad($num, 4, '0', STR_PAD_LEFT);
    }

    $stmt = $pdo->prepare("
        INSERT INTO books (book_code, title, author, isbn, category, quantity, available, description, cover_image, is_active)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
    ");
    $stmt->execute([$book_code, $title, $author, $isbn, $category, $quantity, $available, $description, $cover_image]);
    logActivity($_SESSION['user_id'], 'Add', 'Books', 'Added book: ' . $title);
    echo json_encode(['success' => true, 'message' => 'Book added successfully.']);
}
?>