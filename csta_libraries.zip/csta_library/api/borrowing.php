<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireLogin();
header('Content-Type: application/json');
$user = getCurrentUser();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$action = $_POST['action'] ?? 'borrow';

if (($user['role'] ?? '') === 'borrower') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized request.']);
    exit;
}

defined('PENALTY_PER_DAY') or define('PENALTY_PER_DAY', 10);
defined('DAMAGE_PENALTY') or define('DAMAGE_PENALTY', 50);
defined('LOST_PENALTY') or define('LOST_PENALTY', 500);

if ($action === 'borrow') {
    $borrowerId = (int) ($_POST['borrower_id'] ?? 0);
    $bookId = (int) ($_POST['book_id'] ?? 0);
    $borrowDate = $_POST['borrowed_date'] ?? date('Y-m-d');
    $notes = trim($_POST['notes'] ?? '');

    if (!$borrowerId || !$bookId) {
        echo json_encode(['success' => false, 'message' => 'Borrower and book are required.']);
        exit;
    }

    $book = $pdo->prepare("SELECT * FROM books WHERE id=? AND is_active=1 AND available>0");
    $book->execute([$bookId]);
    $book = $book->fetch();
    if (!$book) {
        echo json_encode(['success' => false, 'message' => 'Book not available.']);
        exit;
    }

    try {
        $pdo->beginTransaction();
        $txn = 'TXN-' . str_pad($pdo->query("SELECT COUNT(*)+1 FROM borrowing")->fetchColumn(), 4, '0', STR_PAD_LEFT);
        $due = date('Y-m-d', strtotime($borrowDate . ' +' . LOAN_DAYS . ' days'));
        $stmt = $pdo->prepare("INSERT INTO borrowing (transaction_no,borrower_id,book_id,borrowed_date,due_date,status,notes,processed_by) VALUES (?,?,?,?,?,'active',?,?)");
        $stmt->execute([$txn, $borrowerId, $bookId, $borrowDate, $due, $notes, $user['id']]);
        $pdo->prepare("UPDATE books SET available=available-1 WHERE id=?")->execute([$bookId]);
        $pdo->commit();
        logActivity($user['id'], 'Borrow', 'Borrowing', "$txn: Book ID $bookId borrowed by Borrower ID $borrowerId");
        echo json_encode(['success' => true, 'message' => "Book borrowed. Transaction: $txn. Due: $due"]);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }

} elseif ($action === 'return') {
    $txnId = (int) ($_POST['transaction_id'] ?? 0);
    $condIn = trim($_POST['condition_in'] ?? 'Good');
    $retDate = $_POST['returned_date'] ?? date('Y-m-d');

    $txn = $pdo->prepare("SELECT * FROM borrowing WHERE id=? AND status IN('active','overdue')");
    $txn->execute([$txnId]);
    $txn = $txn->fetch();
    if (!$txn) {
        echo json_encode(['success' => false, 'message' => 'Transaction not found or already returned.']);
        exit;
    }
    $dueTime = strtotime($txn['due_date']);
    $returnTime = strtotime($retDate);
    $overdueDays = max(0, floor(($returnTime - $dueTime) / 86400));
    $overdueFee = $overdueDays * PENALTY_PER_DAY;

    $conditionFee = 0;
    if ($condIn === 'Damaged')
        $conditionFee = DAMAGE_PENALTY;
    if ($condIn === 'Lost')
        $conditionFee = LOST_PENALTY;

    $totalPenalty = $overdueFee + $conditionFee;

    try {
        $pdo->beginTransaction();
        $pdo->prepare("UPDATE borrowing SET status='returned',returned_date=?,condition_in=?,penalty_amount=?,updated_at=NOW() WHERE id=?")
            ->execute([$retDate, $condIn, $totalPenalty, $txnId]);
        $pdo->prepare("UPDATE books SET available=available+1 WHERE id=?")->execute([$txn['book_id']]);
        $pdo->commit();
        logActivity($user['id'], 'Return', 'Borrowing', "Returned transaction ID $txnId, penalty=₱$totalPenalty");
        $msg = "Book returned successfully." . ($totalPenalty > 0 ? " Penalty: ₱$totalPenalty" : '');
        echo json_encode(['success' => true, 'message' => $msg, 'penalty' => $totalPenalty]);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
} elseif ($action === 'mark_penalty_paid') {
    $txnId = (int) ($_POST['transaction_id'] ?? 0);

    if (!$txnId) {
        echo json_encode(['success' => false, 'message' => 'Transaction is required.']);
        exit;
    }

    $stmt = $pdo->prepare("SELECT transaction_no, penalty_amount, penalty_paid FROM borrowing WHERE id=? AND penalty_amount > 0");
    $stmt->execute([$txnId]);
    $txn = $stmt->fetch();

    if (!$txn) {
        echo json_encode(['success' => false, 'message' => 'No penalty found for this transaction.']);
        exit;
    }

    if ((int) $txn['penalty_paid'] === 1) {
        echo json_encode(['success' => true, 'message' => 'Penalty is already marked as paid.']);
        exit;
    }

    $pdo->prepare("UPDATE borrowing SET penalty_paid=1, updated_at=NOW() WHERE id=?")->execute([$txnId]);
    logActivity($user['id'], 'Payment', 'Borrowing', 'Marked penalty paid for ' . $txn['transaction_no'] . ': PHP ' . $txn['penalty_amount']);
    echo json_encode(['success' => true, 'message' => 'Penalty marked as paid.']);
}
