<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireLogin();
header('Content-Type: application/json');

$q = trim($_GET['q'] ?? '');
$type = trim($_GET['type'] ?? 'all');
$results = [];

if (strlen($q) < 1) {
    echo json_encode([]);
    exit;
}

$like = "%$q%";

if (in_array($type, ['all', 'book'])) {
    $stmt = $pdo->prepare("SELECT 'book' as type, book_code as code, title as name, author as detail, available as extra FROM books WHERE is_active=1 AND (title LIKE ? OR author LIKE ? OR isbn LIKE ?) LIMIT 10");
    $stmt->execute([$like, $like, $like]);
    $results = array_merge($results, $stmt->fetchAll());
}
if (in_array($type, ['all', 'supply'])) {
    $stmt = $pdo->prepare("SELECT 'supply' as type, supply_code as code, item_name as name, category as detail, quantity as extra FROM supplies WHERE is_active=1 AND (item_name LIKE ? OR category LIKE ?) LIMIT 10");
    $stmt->execute([$like, $like]);
    $results = array_merge($results, $stmt->fetchAll());
}
if (in_array($type, ['all', 'borrower'])) {
    $stmt = $pdo->prepare("SELECT 'borrower' as type, borrower_code as code, full_name as name, department as detail, 0 as extra FROM borrowers WHERE is_active=1 AND (full_name LIKE ? OR borrower_code LIKE ?) LIMIT 10");
    $stmt->execute([$like, $like]);
    $results = array_merge($results, $stmt->fetchAll());
}

echo json_encode($results);
