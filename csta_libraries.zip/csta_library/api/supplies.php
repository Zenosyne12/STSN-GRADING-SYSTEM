<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireLogin();
header('Content-Type: application/json');
$user = getCurrentUser();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { echo json_encode(['success'=>false,'message'=>'Method not allowed']); exit; }

$id       = (int)($_POST['id'] ?? 0);
$name     = trim($_POST['item_name'] ?? '');
$category = trim($_POST['category'] ?? '');
$qty      = (int)($_POST['quantity'] ?? 0);
$reorder  = (int)($_POST['reorder_level'] ?? 10);
$unit     = trim($_POST['unit'] ?? 'pcs');
$desc     = trim($_POST['description'] ?? '');

if (!$name) { echo json_encode(['success'=>false,'message'=>'Item name is required.']); exit; }

try {
    if ($id > 0) {
        $stmt = $pdo->prepare("UPDATE supplies SET item_name=?,category=?,quantity=?,reorder_level=?,unit=?,description=?,updated_at=NOW() WHERE id=?");
        $stmt->execute([$name,$category,$qty,$reorder,$unit,$desc,$id]);
        logActivity($user['id'],'Update','Supplies',"Updated supply: $name");
        echo json_encode(['success'=>true,'message'=>'Supply updated successfully.']);
    } else {
        $code = generateCode('SUP','supplies','id');
        $stmt = $pdo->prepare("INSERT INTO supplies (supply_code,item_name,category,quantity,reorder_level,unit,description) VALUES (?,?,?,?,?,?,?)");
        $stmt->execute([$code,$name,$category,$qty,$reorder,$unit,$desc]);
        logActivity($user['id'],'Create','Supplies',"Added supply: $name");
        echo json_encode(['success'=>true,'message'=>'Supply added successfully.']);
    }
} catch (Exception $e) {
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
