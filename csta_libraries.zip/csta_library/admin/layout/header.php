<?php $user = getCurrentUser();
$currentPage = basename($_SERVER['PHP_SELF'], '.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= esc($pageTitle ?? 'Admin Dashboard') ?> | CSTA Library</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <style>
    :root {
      --sb: #4a2511;
      --sb-h: #6E412A;
      --sb-a: #6E412A;
      --acc: #6E412A;
      --acc-d: #5a3520;
    }

    * {
      box-sizing: border-box;
    }

    body {
      background: #f4f6f8;
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      min-height: 100vh;
      margin: 0;
    }

    #sidebar {
      width: 220px;
      min-height: 100vh;
      background: linear-gradient(180deg, #4a2511 0%, #6E412A 100%);
      display: flex;
      flex-direction: column;
      position: fixed;
      left: 0;
      top: 0;
      z-index: 100;
    }

    .sb-brand {
      padding: 1rem;
      border-bottom: 1px solid rgba(255, 255, 255, .15);
      display: flex;
      align-items: center;
      gap: .6rem;
      text-decoration: none;
    }

    .sb-name {
      font-size: .82rem;
      font-weight: 700;
      color: #fff;
      line-height: 1.2;
    }

    .sb-sub {
      font-size: .68rem;
      color: rgba(255, 255, 255, .55);
    }

    .sb-nav {
      flex: 1;
      padding: .75rem 0;
      overflow-y: auto;
    }

    .nav-sec {
      font-size: .64rem;
      font-weight: 700;
      color: rgba(255, 255, 255, .4);
      text-transform: uppercase;
      letter-spacing: .08em;
      padding: .8rem 1rem .3rem;
    }

    .nav-lnk {
      display: flex;
      align-items: center;
      gap: .65rem;
      padding: .6rem 1rem;
      color: rgba(255, 255, 255, .85);
      text-decoration: none;
      font-size: .85rem;
      font-weight: 500;
      transition: all .2s;
    }

    .nav-lnk:hover {
      background: rgba(255, 255, 255, .1);
      color: #fff;
    }

    .nav-lnk.active {
      background: var(--sb-a);
      color: #fff;
      font-weight: 700;
      border-left: 3px solid #c9a88c;
    }

    .nav-lnk i {
      font-size: 1rem;
      width: 20px;
      text-align: center;
    }

    .sb-foot {
      padding: .75rem 1rem;
      border-top: 1px solid rgba(255, 255, 255, .12);
    }

    .u-box {
      display: flex;
      align-items: center;
      gap: .5rem;
    }

    .u-av {
      width: 32px;
      height: 32px;
      background: var(--acc);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fff;
      font-size: .8rem;
      font-weight: 700;
      flex-shrink: 0;
    }

    .u-nm {
      font-size: .8rem;
      color: #fff;
      font-weight: 600;
    }

    .u-rl {
      font-size: .68rem;
      color: rgba(255, 255, 255, .55);
    }

    #main {
      margin-left: 220px;
      flex: 1;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    .topbar {
      background: #fff;
      border-bottom: 1px solid #e9ecef;
      padding: .65rem 1.5rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      position: sticky;
      top: 0;
      z-index: 50;
      box-shadow: 0 1px 6px rgba(0, 0, 0, .03);
    }

    .tb-title {
      font-size: 1rem;
      font-weight: 700;
      color: #4a2511;
    }

    .tb-sub {
      font-size: .74rem;
      color: #6c757d;
    }

    .pc {
      padding: 1.5rem;
      flex: 1;
    }

    .stat-card {
      background: #fff;
      border-radius: 14px;
      padding: 1.2rem 1.4rem;
      border: 1px solid #e9ecef;
      box-shadow: 0 2px 12px rgba(0, 0, 0, .05);
      display: flex;
      align-items: center;
      gap: 1rem;
      transition: transform .2s, box-shadow .2s;
    }

    .stat-card:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 20px rgba(0, 0, 0, .08);
    }

    .stat-icon {
      width: 52px;
      height: 52px;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.4rem;
      flex-shrink: 0;
    }

    .stat-num {
      font-size: 1.8rem;
      font-weight: 800;
      color: #4a2511;
      line-height: 1;
    }

    .stat-lbl {
      font-size: .78rem;
      color: #8d6b52;
      margin-top: .2rem;
    }

    .cc {
      background: #fff;
      border-radius: 14px;
      border: 1px solid #e9ecef;
      box-shadow: 0 2px 12px rgba(0, 0, 0, .05);
      overflow: hidden;
    }

    .cch {
      padding: 1rem 1.3rem;
      border-bottom: 1px solid #f0f0f0;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: .75rem;
      flex-wrap: wrap;
    }

    .cct {
      font-size: .95rem;
      font-weight: 700;
      color: #4a2511;
      margin: 0;
    }

    .ccs {
      font-size: .75rem;
      color: #8d6b52;
      margin: .1rem 0 0;
    }

    .tbl {
      width: 100%;
      border-collapse: collapse;
    }

    .tbl thead th {
      background: #faf8f7;
      color: #6a422a;
      font-size: .72rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: .05em;
      padding: .75rem 1rem;
      border-bottom: 1.5px solid #e0d5cc;
      white-space: nowrap;
    }

    .tbl tbody tr:not(:last-child) td {
      border-bottom: 1px solid #f0f0f0;
    }

    .tbl tbody tr:hover td {
      background: #fefdfb;
    }

    .tbl tbody td {
      padding: .78rem 1rem;
      font-size: .88rem;
      color: #4a2511;
      vertical-align: middle;
    }

    .btn-csta {
      background: linear-gradient(135deg, #6E412A 0%, #5a3520 100%);
      color: #fff;
      border: none;
      border-radius: 8px;
      padding: .42rem .95rem;
      font-size: .82rem;
      font-weight: 600;
      cursor: pointer;
      transition: all .2s;
      display: inline-flex;
      align-items: center;
      gap: .3rem;
      text-decoration: none;
      box-shadow: 0 2px 8px rgba(110, 65, 42, .25);
    }

    .btn-csta:hover {
      background: linear-gradient(135deg, #8a5537 0%, #6a3d25 100%);
      color: #fff;
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(110, 65, 42, .35);
    }

    .btn-csta-o {
      background: #fff;
      color: #6E412A;
      border: 1.5px solid #6E412A;
      border-radius: 8px;
      padding: .38rem .9rem;
      font-size: .82rem;
      font-weight: 600;
      cursor: pointer;
      transition: all .2s;
      display: inline-flex;
      align-items: center;
      gap: .3rem;
      text-decoration: none;
    }

    .btn-csta-o:hover {
      background: #f9f4f0;
      border-color: #5a3520;
      color: #5a3520;
    }

    .ic-btn {
      width: 30px;
      height: 30px;
      border-radius: 7px;
      border: 1px solid #d4b89f;
      background: #fff;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      font-size: .85rem;
      color: #6a422a;
      transition: all .13s;
      text-decoration: none;
    }

    .ic-btn:hover {
      background: #f5f0eb;
      border-color: #8d6b52;
    }

    .ic-btn.del {
      color: #dc3545;
    }

    .ic-btn.del:hover {
      background: #fff5f5;
      border-color: #f5c6cb;
    }

    .form-lbl {
      font-size: .8rem;
      font-weight: 700;
      color: #6E412A;
      margin-bottom: .28rem;
      display: block;
    }

    .f-ctrl {
      border-radius: 9px;
      border: 1.5px solid #ced4da;
      padding: .42rem .85rem;
      font-size: .9rem;
      color: #343a40;
      width: 100%;
      transition: border-color .15s;
    }

    .f-ctrl:focus {
      border-color: var(--acc);
      outline: none;
      box-shadow: 0 0 0 3px rgba(110, 65, 42, .12);
    }

    .srch {
      border: 1.5px solid #dee2e6;
      border-radius: 9px;
      padding: .38rem .85rem;
      font-size: .88rem;
      color: #343a40;
      width: 260px;
      max-width: 100%;
      min-width: 160px;
      transition: border-color .15s;
    }

    .srch:focus {
      border-color: var(--acc);
      outline: none;
    }

    .srch[type="search"],
    #searchBox {
      width: 260px;
      max-width: 100%;
    }

    @media(max-width:768px) {
      #sidebar {
        width: 60px;
      }

      .sb-name,
      .sb-sub,
      .nav-lnk span,
      .nav-sec,
      .u-nm,
      .u-rl {
        display: none;
      }

      #main {
        margin-left: 60px;
      }
    }
  </style>
</head>

<body>
  <div id="sidebar">
    <a class="sb-brand" href="<?= BASE_URL ?>/admin/dashboard.php">
      <img src="../assets/img/TeresianLOGO.jpg" alt="CSTA Logo" style="width:36px;height:36px;border-radius:8px;">
      <div>
        <div class="sb-name">Library System</div>
        <div class="sb-sub">CSTA Admin</div>
      </div>
    </a>
    <nav class="sb-nav">
      <div class="nav-sec">Main</div>
      <a href="<?= BASE_URL ?>/admin/dashboard.php"
        class="nav-lnk <?= $currentPage === 'dashboard' ? 'active' : '' ?>"><i
          class="bi bi-speedometer2"></i><span>Dashboard</span></a>
      <div class="nav-sec">Inventory</div>
      <a href="<?= BASE_URL ?>/admin/books.php" class="nav-lnk <?= $currentPage === 'books' ? 'active' : '' ?>"><i
          class="bi bi-book"></i><span>Books</span></a>
      <a href="<?= BASE_URL ?>/admin/supplies.php" class="nav-lnk <?= $currentPage === 'supplies' ? 'active' : '' ?>"><i
          class="bi bi-box-seam"></i><span>Supplies</span></a>
      <div class="nav-sec">Transactions</div>
      <a href="<?= BASE_URL ?>/admin/borrowers.php"
        class="nav-lnk <?= $currentPage === 'borrowers' ? 'active' : '' ?>"><i
          class="bi bi-people"></i><span>Borrowers</span></a>
      <a href="<?= BASE_URL ?>/admin/borrowing.php"
        class="nav-lnk <?= $currentPage === 'borrowing' ? 'active' : '' ?>"><i
          class="bi bi-arrow-left-right"></i><span>Borrowing &amp; Return</span></a>
      <div class="nav-sec">Tools</div>
      <a href="<?= BASE_URL ?>/admin/search.php" class="nav-lnk <?= $currentPage === 'search' ? 'active' : '' ?>"><i
          class="bi bi-search"></i><span>Search</span></a>
      <a href="<?= BASE_URL ?>/admin/activity_log.php"
        class="nav-lnk <?= $currentPage === 'activity_log' ? 'active' : '' ?>"><i
          class="bi bi-clock-history"></i><span>Activity Log</span></a>
    </nav>
    <div class="sb-foot">
      <div class="u-box">
        <div class="u-av"><?= strtoupper(substr($user['full_name'], 0, 1)) ?></div>
        <div>
          <div class="u-nm"><?= esc($user['full_name']) ?></div>
          <div class="u-rl"><?= esc(ucfirst($user['role'])) ?></div>
        </div>
      </div>
      <a href="<?= BASE_URL ?>/logout.php" class="nav-lnk mt-2" style="color:rgba(255,100,100,.85);"><i
          class="bi bi-box-arrow-right"></i><span>Logout</span></a>
    </div>
  </div>
  <div id="main">
    <div class="topbar">
      <div>
        <div class="tb-title"><?= esc($pageTitle ?? 'Dashboard') ?></div>
        <div class="tb-sub">LIBRARY AND SUPPLIES MANAGEMENT SYSTEM</div>
      </div>
      <div><span style="font-size:.78rem;color:#6c757d;"><?= date('M d, Y') ?></span></div>
    </div>
    <div class="pc">