<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireLogin();
$pageTitle = 'Borrowing & Return';

$pdo->exec("UPDATE borrowing SET status='overdue' WHERE status='active' AND due_date < CURDATE()");

$borrowers = $pdo->query("SELECT id, borrower_code, full_name FROM borrowers WHERE is_active=1 ORDER BY full_name")->fetchAll();
$books = $pdo->query("SELECT id, book_code, title, available FROM books WHERE is_active=1 AND available>0 ORDER BY title")->fetchAll();
$activeTxns = $pdo->query("
    SELECT b.*, br.full_name borrower_name, bk.title book_title, bk.book_code
    FROM borrowing b
    JOIN borrowers br ON br.id=b.borrower_id
    JOIN books bk ON bk.id=b.book_id
    WHERE b.status IN('active','overdue')
    ORDER BY b.due_date ASC
")->fetchAll();
$pendingPenalties = $pdo->query("
    SELECT b.*, br.full_name borrower_name, bk.title book_title, bk.book_code
    FROM borrowing b
    JOIN borrowers br ON br.id=b.borrower_id
    JOIN books bk ON bk.id=b.book_id
    WHERE b.penalty_amount > 0 AND b.penalty_paid=0
    ORDER BY b.returned_date DESC, b.updated_at DESC
")->fetchAll();

defined('PENALTY_PER_DAY') or define('PENALTY_PER_DAY', 10);
defined('DAMAGE_PENALTY') or define('DAMAGE_PENALTY', 50);
defined('LOST_PENALTY') or define('LOST_PENALTY', 500);
?>
<?php require_once __DIR__ . '/layout/header.php'; ?>
<div class="row g-3 mb-3">
<div class="col-lg-5">
    <div class="cc">
      <div class="cch">
        <div>
          <p class="cct">Issue Borrowing</p>
          <p class="ccs">Issue books, track due dates.</p>
        </div>
      </div>
      <form id="borrowForm" style="padding:1.2rem;">
        <div class="mb-3">
          <label class="form-lbl">Borrower *</label>
          <select class="f-ctrl" name="borrower_id" id="borrowerId" required>
            <option value="">Select Borrower</option>
            <?php foreach ($borrowers as $br): ?>
              <option value="<?= $br['id'] ?>"><?= esc($br['borrower_code']) ?> - <?= esc($br['full_name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-3">
          <label class="form-lbl">Book *</label>
          <select class="f-ctrl" name="book_id" id="bookId" required>
            <option value="">Select Book</option>
            <?php foreach ($books as $bk): ?>
              <option value="<?= $bk['id'] ?>"><?= esc($bk['book_code']) ?> - <?= esc($bk['title']) ?>
                (<?= $bk['available'] ?> avail)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="row g-2 mb-3">
          <div class="col-6">
            <label class="form-lbl">Date Borrowed</label>
            <input class="f-ctrl" type="date" name="borrowed_date" id="borrowDate" value="<?= date('Y-m-d') ?>">
          </div>
          <div class="col-6">
            <label class="form-lbl">Due Date</label>
            <input class="f-ctrl" type="date" id="dueDateDisplay" readonly style="background:#f8f9fa;">
          </div>
        </div>
        <div class="mb-3">
          <label class="form-lbl">Notes</label>
          <textarea class="f-ctrl" name="notes" rows="2" placeholder="Optional notes..."></textarea>
        </div>
        <button type="submit" class="btn-csta w-100"><i class="bi bi-arrow-down-circle"></i> Save Borrowing</button>
      </form>
    </div>
  </div>
<div class="col-lg-7">
    <div class="cc">
      <div class="cch">
        <div>
          <p class="cct">Process Return</p>
          <p class="ccs">Mark books as returned.</p>
        </div>
      </div>
      <form id="returnForm" style="padding:1.2rem;">
        <div class="mb-3">
          <label class="form-lbl">Select Active Transaction *</label>
          <select class="f-ctrl" name="transaction_id" id="txnSelect" required onchange="showPenalty()">
            <option value="">— Select transaction —</option>
            <?php foreach ($activeTxns as $t):
              $overdue = strtotime($t['due_date']) < time(); ?>
              <option value="<?= $t['id'] ?>" data-due="<?= $t['due_date'] ?>"
                style="<?= $overdue ? 'background:#fff0f0;' : '' ?>">
                <?= esc($t['transaction_no']) ?> – <?= esc($t['borrower_name']) ?> / <?= esc($t['book_title']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="row g-2 mb-3">
          <div class="col-md-6">
            <label class="form-lbl">Return Date</label>
            <input class="f-ctrl" type="date" name="returned_date" value="<?= date('Y-m-d') ?>">
          </div>
          <div class="col-md-6">
            <label class="form-lbl">Book Condition</label>
            <select class="f-ctrl" name="condition_in" id="conditionSelect" onchange="showPenalty()">
              <option>Good</option>
              <option>Fair</option>
              <option>Damaged</option>
              <option>Lost</option>
            </select>
          </div>
        </div>
<div id="penaltyBox"
          style="display:none; background:#fff3e0; border:1px solid #ffb74d; border-radius:9px; padding:.7rem 1rem; margin-bottom:1rem; font-size:.88rem;">
          <i class="bi bi-exclamation-triangle me-1" style="color:#e65100;"></i>
          <strong>Penalty Breakdown:</strong><br>
          <span id="overdueInfo" style="display:none;">Overdue: <strong id="penaltyDays">0</strong> day(s) ×
            ₱<?= PENALTY_PER_DAY ?> = ₱<strong id="overdueFee">0.00</strong><br></span>
          <span id="conditionInfo" style="display:none;">Condition fee (<span id="conditionLabel"></span>): ₱<strong
              id="conditionFee">0.00</strong><br></span>
          <strong>Total Penalty: ₱<span id="totalPenalty">0.00</span></strong>
        </div>
        <button type="submit" class="btn-csta w-100" style="background:#1565c0;">
          <i class="bi bi-check2-circle"></i> Process Return
        </button>
      </form>
    </div>
  </div>
</div>
<div class="cc mb-3">
  <div class="cch">
    <div>
      <p class="cct">Pending Penalties</p>
      <p class="ccs">Payments waiting for staff confirmation.</p>
    </div>
  </div>
  <div style="overflow-x:auto;">
    <table class="tbl">
      <thead>
        <tr>
          <th>Transaction</th>
          <th>Borrower</th>
          <th>Book</th>
          <th>Returned</th>
          <th>Penalty</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$pendingPenalties): ?>
          <tr>
            <td colspan="6" style="text-align:center;padding:2rem;color:#6c757d;">No pending penalties.</td>
          </tr>
        <?php endif; ?>
        <?php foreach ($pendingPenalties as $p): ?>
          <tr>
            <td style="font-weight:700;color:#2d4a3e;"><?= esc($p['transaction_no']) ?></td>
            <td><?= esc($p['borrower_name']) ?></td>
            <td><?= esc($p['book_code']) ?> - <?= esc($p['book_title']) ?></td>
            <td style="font-size:.82rem;"><?= $p['returned_date'] ? date('M d, Y', strtotime($p['returned_date'])) : '—' ?></td>
            <td style="font-weight:700;color:#b71c1c;">&#8369;<?= number_format($p['penalty_amount'], 2) ?></td>
            <td>
              <button class="btn-csta" type="button" onclick="markPenaltyPaid(<?= $p['id'] ?>)">
                <i class="bi bi-cash-coin"></i> Mark Paid
              </button>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<div class="cc">
  <div class="cch">
    <div>
      <p class="cct">Active Borrowings</p>
      <p class="ccs">Currently issued books.</p>
    </div>
  </div>
  <div style="overflow-x:auto;">
    <table class="tbl">
      <thead>
        <tr>
          <th>Transaction</th>
          <th>Borrower</th>
          <th>Book</th>
          <th>Borrowed</th>
          <th>Due Date</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$activeTxns): ?>
          <tr>
            <td colspan="6" style="text-align:center;padding:2rem;color:#6c757d;">No active borrowings.</td>
          </tr>
        <?php endif; ?>
        <?php foreach ($activeTxns as $t):
          $overdue = strtotime($t['due_date']) < time(); ?>
          <tr style="<?= $overdue ? 'background:#fff8f8;' : '' ?>">
            <td style="font-weight:700;color:#2d4a3e;"><?= esc($t['transaction_no']) ?></td>
            <td><?= esc($t['borrower_name']) ?></td>
            <td><?= esc($t['book_title']) ?></td>
            <td style="font-size:.82rem;"><?= date('M d, Y', strtotime($t['borrowed_date'])) ?></td>
            <td style="font-size:.82rem;<?= $overdue ? 'color:#b71c1c;font-weight:700;' : '' ?>">
              <?= date('M d, Y', strtotime($t['due_date'])) ?>
            </td>
            <td><?= statusBadge($t['status']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
  document.getElementById('borrowDate').addEventListener('change', function () {
    const d = new Date(this.value);
    d.setDate(d.getDate() + <?= LOAN_DAYS ?>);
    document.getElementById('dueDateDisplay').value = d.toISOString().split('T')[0];
  });
  document.getElementById('borrowDate').dispatchEvent(new Event('change'));

  function showPenalty() {
    const txn = document.getElementById('txnSelect');
    const opt = txn.options[txn.selectedIndex];
    const cond = document.getElementById('conditionSelect').value;
    const box = document.getElementById('penaltyBox');

    if (!opt.value) {
      box.style.display = 'none';
      return;
    }

    const returnDateInput = document.querySelector('input[name="returned_date"]').value;
    const returnDate = returnDateInput ? new Date(returnDateInput) : new Date();
    if (returnDateInput) returnDate.setHours(0, 0, 0, 0);

    const due = new Date(opt.dataset.due);
    const overdueDays = Math.max(0, Math.floor((returnDate - due) / (1000 * 60 * 60 * 24)));
    const overdueFee = overdueDays * <?= PENALTY_PER_DAY ?>;

    let conditionFee = 0;
    if (cond === 'Damaged') conditionFee = <?= DAMAGE_PENALTY ?>;
    if (cond === 'Lost') conditionFee = <?= LOST_PENALTY ?>;

    document.getElementById('penaltyDays').textContent = overdueDays;
    document.getElementById('overdueFee').textContent = overdueFee.toFixed(2);
    document.getElementById('conditionFee').textContent = conditionFee.toFixed(2);
    document.getElementById('conditionLabel').textContent = cond;
    document.getElementById('totalPenalty').textContent = (overdueFee + conditionFee).toFixed(2);

    document.getElementById('overdueInfo').style.display = overdueDays > 0 ? 'inline' : 'none';
    document.getElementById('conditionInfo').style.display = conditionFee > 0 ? 'inline' : 'none';
    box.style.display = (overdueFee + conditionFee) > 0 ? 'block' : 'none';
  }

  document.querySelector('input[name="returned_date"]').addEventListener('change', showPenalty);

  document.getElementById('borrowForm').addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target); fd.append('action', 'borrow');
    const r = await fetch('<?= BASE_URL ?>/api/borrowing.php', { method: 'POST', body: new URLSearchParams(fd) });
    const d = await r.json();
    toast(d.message, d.success ? 'success' : 'error');
    if (d.success) setTimeout(() => location.reload(), 1200);
  });

  document.getElementById('returnForm').addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target); fd.append('action', 'return');
    const r = await fetch('<?= BASE_URL ?>/api/borrowing.php', { method: 'POST', body: new URLSearchParams(fd) });
    const d = await r.json();
    toast(d.message, d.success ? 'success' : 'error');
    if (d.success) setTimeout(() => location.reload(), 1200);
  });

  async function markPenaltyPaid(transactionId) {
    const result = await Swal.fire({
      title: 'Mark penalty as paid?',
      text: 'This will remove it from the borrower pending penalties.',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#4a8264',
      cancelButtonColor: '#6c757d',
      confirmButtonText: 'Yes, mark paid'
    });

    if (!result.isConfirmed) return;

    const r = await fetch('<?= BASE_URL ?>/api/borrowing.php', {
      method: 'POST',
      body: new URLSearchParams({
        action: 'mark_penalty_paid',
        transaction_id: transactionId
      })
    });
    const d = await r.json();
    toast(d.message, d.success ? 'success' : 'error');
    if (d.success) setTimeout(() => location.reload(), 1000);
  }

  document.getElementById('conditionSelect').addEventListener('change', showPenalty);
</script>

<?php require_once __DIR__ . '/layout/footer.php'; ?>
