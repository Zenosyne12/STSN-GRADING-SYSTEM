<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireLogin();
$pageTitle = 'Activity Log';

if (isset($_GET['clear'])) {
  try {
    if ($_GET['clear'] == 'old') {
      $deleteStmt = $pdo->prepare("DELETE FROM activity_log WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");
      $deleteStmt->execute();
      $deletedCount = $deleteStmt->rowCount();

      $_SESSION['alert'] = [
        'type' => 'success',
        'message' => "Cleared $deletedCount old log(s) successfully!"
      ];
    } elseif ($_GET['clear'] == 'all') {
      $deleteStmt = $pdo->prepare("DELETE FROM activity_log");
      $deleteStmt->execute();
      $deletedCount = $deleteStmt->rowCount();

      $_SESSION['alert'] = [
        'type' => 'success',
        'message' => "Cleared all $deletedCount log(s) successfully!"
      ];
    }
  } catch (Exception $e) {
    $_SESSION['alert'] = [
      'type' => 'error',
      'message' => 'Failed to clear logs: ' . $e->getMessage()
    ];
  }
  header('Location: activity_log.php');
  exit;
}

$filter_user = trim($_GET['user'] ?? '');
$filter_action = trim($_GET['action'] ?? '');
$filter_module = trim($_GET['module'] ?? '');
$filter_date = trim($_GET['date'] ?? '');
$page = max(1, (int) ($_GET['p'] ?? 1));
$limit = 10;
$offset = ($page - 1) * $limit;

$where = [];
$params = [];
if ($filter_user) {
  $where[] = "u.full_name LIKE ?";
  $params[] = "%$filter_user%";
}
if ($filter_action) {
  $where[] = "al.action=?";
  $params[] = $filter_action;
}
if ($filter_module) {
  $where[] = "al.module=?";
  $params[] = $filter_module;
}
if ($filter_date) {
  $where[] = "DATE(al.created_at)=?";
  $params[] = $filter_date;
}

$whereStr = $where ? "WHERE " . implode(' AND ', $where) : '';
$sql = "SELECT al.*, u.full_name FROM activity_log al LEFT JOIN users u ON u.id=al.user_id $whereStr ORDER BY al.created_at DESC LIMIT $limit OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$logs = $stmt->fetchAll();

$totalSql = "SELECT COUNT(*) FROM activity_log al LEFT JOIN users u ON u.id=al.user_id $whereStr";
$totalStmt = $pdo->prepare($totalSql);
$totalStmt->execute($params);
$total = (int) $totalStmt->fetchColumn();
$pages = max(1, ceil($total / $limit));

$actions = $pdo->query("SELECT DISTINCT action FROM activity_log ORDER BY action")->fetchAll(PDO::FETCH_COLUMN);
$modules = $pdo->query("SELECT DISTINCT module FROM activity_log ORDER BY module")->fetchAll(PDO::FETCH_COLUMN);
?>
<?php require_once __DIR__ . '/layout/header.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<div class="cc">
  <div class="cch">
    <div>
      <p class="cct">Activity Log</p>
      <p class="ccs">Monitor system actions.</p>
    </div>
    <div style="display:flex;gap:0.5rem;">
      <button onclick="confirmClearOldLogs()" class="btn-csta-o">
        <i class="bi bi-trash"></i> Clear Old Logs (30+ days)
      </button>
      <button onclick="confirmClearAllLogs()" class="btn-csta-o"
        style="background:#dc3545;color:#fff;border-color:#dc3545;">
        <i class="bi bi-trash-fill"></i> Clear All Logs
      </button>
    </div>
  </div>
  <div
    style="padding:.75rem 1rem;border-bottom:1px solid #f0f0f0;display:flex;gap:.5rem;flex-wrap:wrap;align-items:center;">
    <form method="GET" style="display:contents;" id="filterForm">
      <select class="srch" name="action" style="min-width:140px;" id="actionSelect">
        <option value="">All Actions</option>
        <?php foreach ($actions as $a): ?>
          <option <?= $filter_action === $a ? 'selected' : '' ?> value="<?= esc($a) ?>"><?= esc($a) ?></option>
        <?php endforeach; ?>
      </select>
      <select class="srch" name="module" style="min-width:140px;" id="moduleSelect">
        <option value="">All Modules</option>
        <?php foreach ($modules as $m): ?>
          <option <?= $filter_module === $m ? 'selected' : '' ?> value="<?= esc($m) ?>"><?= esc($m) ?></option>
        <?php endforeach; ?>
      </select>
      <input class="srch" type="date" name="date" value="<?= esc($filter_date) ?>" id="dateInput"
        style="min-width:150px;">
      <?php if ($filter_action || $filter_module || $filter_date): ?>
        <a href="activity_log.php" class="btn-csta-o" style="white-space:nowrap;">
          <i class="bi bi-x-circle"></i> Clear Filters
        </a>
      <?php endif; ?>
    </form>
  </div>
  <div style="overflow-x:auto;">
    <table class="tbl">
      <thead>
        <tr>
          <th>Log ID</th>
          <th>User</th>
          <th>Action</th>
          <th>Module</th>
          <th>Details</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$logs): ?>
          <tr>
            <td colspan="6" style="text-align:center;padding:2rem;color:#6c757d;">No logs found.</td>
          </tr>
        <?php endif; ?>
        <?php foreach ($logs as $l): ?>
          <tr>
            <td style="color:#aaa;font-size:.78rem;"><?= $l['id'] ?></td>
            <td><?= esc($l['full_name'] ?? 'System') ?></td>
            <td><span
                style="background:#f0faf5;color:#2d5943;border:1px solid #c8e6c9;border-radius:6px;padding:.15rem .5rem;font-size:.75rem;font-weight:700;"><?= esc($l['action']) ?></span>
            </td>
            <td style="font-size:.83rem;"><?= esc($l['module']) ?></td>
            <td style="max-width:250px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.83rem;">
              <?= esc($l['details']) ?>
            </td>
            <td style="font-size:.78rem;color:#6c757d;"><?= date('M d Y, g:ia', strtotime($l['created_at'])) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php if ($pages > 1): ?>
    <div style="padding:.75rem;border-top:1px solid #f0f0f0;display:flex;justify-content:flex-end;gap:.3rem;">
      <?php
      $filterQuery = http_build_query([
        'user' => $filter_user,
        'action' => $filter_action,
        'module' => $filter_module,
        'date' => $filter_date
      ]);
      $filterQuery = $filterQuery ? '&' . $filterQuery : '';

      for ($n = 1; $n <= $pages; $n++):
        ?>
        <a href="?p=<?= $n ?><?= $filterQuery ?>"
          style="display:inline-flex;align-items:center;justify-content:center;min-width:30px;height:30px;border-radius:7px;border:1px solid #dee2e6;text-decoration:none;font-size:.8rem;<?= $n == $page ? 'background:#4a8264;color:#fff;' : 'background:#fff;color:#4a8264;' ?>">
          <?= $n ?>
        </a>
      <?php endfor; ?>
    </div>
  <?php endif; ?>
</div>

<script>
  const actionModulePairs = {
    'Login': ['Auth', 'Authentication'],
    'Logout': ['Auth', 'Authentication'],
    'Failed Login': ['Auth', 'Authentication'],
    'Create': ['Books', 'Supplies', 'Borrowers', 'Users'],
    'Update': ['Books', 'Supplies', 'Borrowers', 'Users', 'Profile'],
    'Delete': ['Books', 'Supplies', 'Borrowers', 'Users'],
    'Borrow': ['Borrowing', 'Books'],
    'Return': ['Borrowing', 'Books'],
    'View': ['Books', 'Supplies', 'Borrowers', 'Reports'],
    'Export': ['Reports', 'Books', 'Supplies']
  };

  let allModules = [];
  const moduleSelect = document.getElementById('moduleSelect');

  document.addEventListener('DOMContentLoaded', function () {
    allModules = Array.from(moduleSelect.options).map(opt => ({
      value: opt.value,
      text: opt.text
    }));

    const currentAction = document.getElementById('actionSelect').value;
    if (currentAction) {
      filterModulesByAction(currentAction, false);
    }
  });

  document.getElementById('actionSelect').addEventListener('change', function () {
    const selectedAction = this.value;
    filterModulesByAction(selectedAction, true);
  });

  document.getElementById('moduleSelect').addEventListener('change', function () {
    submitForm();
  });

  document.getElementById('dateInput').addEventListener('change', function () {
    submitForm();
  });

  function filterModulesByAction(action, shouldSubmit = true) {
    const moduleSelect = document.getElementById('moduleSelect');
    const currentModule = moduleSelect.value;

    moduleSelect.innerHTML = '<option value="">All Modules</option>';

    if (!action || action === '') {
      allModules.forEach(mod => {
        if (mod.value !== '') {
          const option = document.createElement('option');
          option.value = mod.value;
          option.text = mod.text;
          if (mod.value === currentModule) option.selected = true;
          moduleSelect.appendChild(option);
        }
      });
    } else {
      const relatedModules = actionModulePairs[action] || [];

      let hasRelatedModules = false;
      allModules.forEach(mod => {
        if (mod.value !== '') {
          const isRelated = relatedModules.some(rm =>
            mod.value.toLowerCase().includes(rm.toLowerCase()) ||
            rm.toLowerCase().includes(mod.value.toLowerCase())
          );

          if (isRelated) {
            const option = document.createElement('option');
            option.value = mod.value;
            option.text = mod.text;
            if (mod.value === currentModule) option.selected = true;
            moduleSelect.appendChild(option);
            hasRelatedModules = true;
          }
        }
      });

      if (!hasRelatedModules) {
        allModules.forEach(mod => {
          if (mod.value !== '') {
            const option = document.createElement('option');
            option.value = mod.value;
            option.text = mod.text;
            if (mod.value === currentModule) option.selected = true;
            moduleSelect.appendChild(option);
          }
        });
      }
    }

    if (shouldSubmit) {
      submitForm();
    }
  }

  function submitForm() {
    const action = document.getElementById('actionSelect').value;
    const module = document.getElementById('moduleSelect').value;
    const date = document.getElementById('dateInput').value;

    let url = 'activity_log.php?';
    const params = [];

    if (action) params.push('action=' + encodeURIComponent(action));
    if (module) params.push('module=' + encodeURIComponent(module));
    if (date) params.push('date=' + encodeURIComponent(date));

    url += params.join('&');

    window.location.href = url;
  }

  function confirmClearOldLogs() {
    Swal.fire({
      title: 'Clear Old Logs?',
      text: "This will delete all logs older than 30 days. This action cannot be undone!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#4a8264',
      cancelButtonColor: '#6c757d',
      confirmButtonText: 'Yes, clear them!',
      cancelButtonText: 'Cancel'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '?clear=old';
      }
    });
  }

  function confirmClearAllLogs() {
    Swal.fire({
      title: 'Clear ALL Logs?',
      text: "This will delete EVERY log in the system! This action cannot be undone!",
      icon: 'error',
      showCancelButton: true,
      confirmButtonColor: '#dc3545',
      cancelButtonColor: '#6c757d',
      confirmButtonText: 'Yes, delete everything!',
      cancelButtonText: 'Cancel',
      showClass: {
        popup: 'animate__animated animate__shakeX'
      }
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '?clear=all';
      }
    });
  }

  <?php if (isset($_SESSION['alert'])): ?>
    Swal.fire({
      toast: true,
      position: 'top-end',
      icon: '<?= $_SESSION['alert']['type'] ?>',
      title: '<?= $_SESSION['alert']['message'] ?>',
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true
    });
    <?php unset($_SESSION['alert']); ?>
  <?php endif; ?>
</script>

<?php require_once __DIR__ . '/layout/footer.php'; ?>
