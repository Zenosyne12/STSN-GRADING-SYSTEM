<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireLogin();
$pageTitle = 'Books Management';

$search = trim($_GET['s'] ?? '');
$page = max(1, (int) ($_GET['p'] ?? 1));
$limit = 10;
$offset = ($page - 1) * $limit;

$where = ['b.is_active=1'];
$params = [];
if ($search) {
  $where[] = "(b.title LIKE ? OR b.author LIKE ? OR b.isbn LIKE ? OR b.book_code LIKE ?)";
  $p = "%$search%";
  $params = array_merge($params, [$p, $p, $p, $p]);
}

$sql = "SELECT b.* FROM books b WHERE " . implode(' AND ', $where) . " ORDER BY b.title ASC LIMIT $limit OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();

$total = $pdo->prepare("SELECT COUNT(*) FROM books b WHERE " . implode(' AND ', $where));
$total->execute($params);
$total = (int) $total->fetchColumn();
$pages = max(1, ceil($total / $limit));

$categories = $pdo->query("SELECT DISTINCT category FROM books WHERE is_active=1 AND category IS NOT NULL ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);
?>
<?php require_once __DIR__ . '/layout/header.php'; ?>
<div class="cc">
  <div class="cch">
    <div>
      <p class="cct">Books Management</p>
      <p class="ccs">Inventory of library books.</p>
    </div>
    <button class="btn-csta" onclick="openAddModal()"><i class="bi bi-plus-circle"></i> Add Book</button>
  </div>

  <!-- Compact search bar -->
  <div style="padding:.75rem 1rem;border-bottom:1px solid #f0f0f0;">
    <form method="GET" style="display:flex; gap:0.5rem; align-items:center;">
      <input class="srch" type="search" name="s" value="<?= esc($search) ?>" placeholder="Search books..."
        style="width:300px;">
      <button class="btn-csta" type="submit"><i class="bi bi-search"></i> Search</button>
      <a href="books.php" class="btn-csta-o">Clear</a>
    </form>
  </div>

  <div style="overflow-x:auto;">
    <table class="tbl">
      <thead>
        <tr>
          <th>#</th>
          <th>Cover</th>
          <th>ID</th>
          <th>Title</th>
          <th>Author</th>
          <th>ISBN</th>
          <th>Category</th>
          <th>Qty</th>
          <th>Available</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$books): ?>
          <tr>
            <td colspan="11" style="text-align:center;padding:2rem;color:#6c757d;"><i class="bi bi-book"
                style="font-size:1.8rem;display:block;opacity:.4;"></i>No books found.</td>
          </tr>
        <?php endif; ?>
        <?php foreach ($books as $i => $b): ?>
          <tr>
            <td style="color:#aaa;font-size:.78rem;"><?= $offset + $i + 1 ?></td>
            <td>
              <?php if (!empty($b['cover_image'])): ?>
                <img src="<?= BASE_URL ?>/assets/uploads/books/<?= esc($b['cover_image']) ?>" alt="Cover"
                  style="width:38px;height:50px;object-fit:cover;border-radius:5px;border:1px solid #e0e0e0;">
              <?php else: ?>
                <div
                  style="width:38px;height:50px;background:#f0f4f2;border-radius:5px;border:1px solid #e0e0e0;display:flex;align-items:center;justify-content:center;">
                  <i class="bi bi-book" style="color:#b0bec5;font-size:.9rem;"></i>
                </div>
              <?php endif; ?>
            </td>
            <td style="font-weight:700;color:#2d4a3e;"><?= esc($b['book_code']) ?></td>
            <td style="font-weight:600;"><?= esc($b['title']) ?></td>
            <td><?= esc($b['author']) ?></td>
            <td style="font-size:.8rem;color:#6c757d;"><?= esc($b['isbn']) ?></td>
            <td><?= esc($b['category']) ?></td>
            <td style="text-align:center;font-weight:700;"><?= $b['quantity'] ?></td>
            <td style="text-align:center;font-weight:700;color:<?= $b['available'] > 0 ? '#2e7d32' : '#b71c1c'; ?>">
              <?= $b['available'] ?>
            </td>
            <td><?= statusBadge(getBookStatus($b['available'], $b['quantity'])) ?></td>
            <td>
              <div style="display:flex;gap:.3rem;">
                <button class="ic-btn" onclick="editBook(<?= htmlspecialchars(json_encode($b)) ?>)" title="Edit"><i
                    class="bi bi-pencil-square"></i></button>
                <a class="ic-btn del" href="?delete=<?= $b['id'] ?>"
                  onclick="event.preventDefault();confirmDel('?delete=<?= $b['id'] ?>','Delete this book?');"
                  title="Delete"><i class="bi bi-trash"></i></a>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <?php if ($pages > 1): ?>
    <div style="padding:.75rem 1rem;border-top:1px solid #f0f0f0;display:flex;justify-content:flex-end;gap:.3rem;">
      <?php for ($n = 1; $n <= $pages; $n++): ?>
        <a href="?s=<?= urlencode($search) ?>&p=<?= $n ?>"
          style="display:inline-flex;align-items:center;justify-content:center;min-width:30px;height:30px;border-radius:7px;border:1px solid #dee2e6;text-decoration:none;font-size:.8rem;font-weight:600;<?= $n == $page ? 'background:#4a8264;color:#fff;border-color:#4a8264;' : 'background:#fff;color:#4a8264;' ?>">
          <?= $n ?>
        </a>
      <?php endfor; ?>
    </div>
  <?php endif; ?>
</div>

<!-- Book Modal (unchanged) -->
<div class="modal fade" id="bookModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content" style="border-radius:14px;">
      <div
        style="padding:1rem 1.2rem;border-bottom:1px solid #dee2e6;display:flex;align-items:center;justify-content:space-between;">
        <span style="font-size:.95rem;font-weight:700;color:#1a3a2a;" id="bookModalTitle">Add Book</span>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form id="bookForm" method="POST" action="<?= BASE_URL ?>/api/books.php" enctype="multipart/form-data">
        <div style="padding:1.2rem;">
          <input type="hidden" id="bId" name="id">
          <input type="hidden" id="bExistingCover" name="existing_cover">
          <div class="row g-3">

            <!-- Cover Image Upload -->
            <div class="col-12">
              <label class="form-lbl">Book Cover Image <span class="text-danger">*</span></label>
              <div style="display:flex;align-items:flex-start;gap:1rem;flex-wrap:wrap;">
                <div id="coverPreviewWrap"
                  style="width:80px;height:110px;border-radius:8px;border:2px dashed #b0bec5;background:#f8fafb;display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0;cursor:pointer;"
                  onclick="document.getElementById('bCover').click()">
                  <img id="coverPreview" src="" alt=""
                    style="width:100%;height:100%;object-fit:cover;display:none;border-radius:6px;">
                  <div id="coverPlaceholder" style="text-align:center;color:#b0bec5;font-size:.72rem;padding:.3rem;">
                    <i class="bi bi-image" style="font-size:1.6rem;display:block;margin-bottom:.2rem;"></i>
                    Click to upload
                  </div>
                </div>
                <div style="flex:1;min-width:180px;">
                  <input type="file" id="bCover" name="cover_image" accept="image/jpeg,image/png,image/webp,image/gif"
                    style="display:none;">
                  <button type="button" class="btn-csta" style="font-size:.8rem;padding:.35rem .8rem;"
                    onclick="document.getElementById('bCover').click()">
                    <i class="bi bi-upload"></i> Choose Image
                  </button>
                  <p id="coverFileName" style="margin:.45rem 0 .25rem;font-size:.78rem;color:#6c757d;">No file chosen
                  </p>
                  <p style="margin:0;font-size:.73rem;color:#aaa;">Accepted: JPG, PNG, WEBP, GIF &nbsp;·&nbsp; Max: 2MB
                  </p>
                  <p style="margin:.2rem 0 0;font-size:.73rem;color:#aaa;">Recommended size: 300 × 420 px</p>
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <label class="form-lbl">Book Code</label>
              <input class="f-ctrl" type="text" name="book_code" id="bCode" placeholder="Auto-generated" readonly>
            </div>
            <div class="col-md-8">
              <label class="form-lbl">Title <span class="text-danger">*</span></label>
              <input class="f-ctrl" type="text" name="title" id="bTitle" required>
            </div>
            <div class="col-md-6">
              <label class="form-lbl">Author <span class="text-danger">*</span></label>
              <input class="f-ctrl" type="text" name="author" id="bAuthor" required>
            </div>
            <div class="col-md-6">
              <label class="form-lbl">ISBN</label>
              <input class="f-ctrl" type="text" name="isbn" id="bIsbn">
            </div>
            <div class="col-md-6">
              <label class="form-lbl">Category</label>
              <input class="f-ctrl" type="text" name="category" id="bCat" list="catList">
              <datalist id="catList"><?php foreach ($categories as $c): ?>
                  <option value="<?= esc($c) ?>"><?php endforeach; ?>
              </datalist>
            </div>
            <div class="col-md-3">
              <label class="form-lbl">Total Quantity <span class="text-danger">*</span></label>
              <input class="f-ctrl" type="number" name="quantity" id="bQty" min="1" required>
            </div>
            <div class="col-md-3">
              <label class="form-lbl">Available Copies</label>
              <input class="f-ctrl" type="number" name="available" id="bAvail" min="0">
            </div>
            <div class="col-12">
              <label class="form-lbl">Description</label>
              <textarea class="f-ctrl" name="description" id="bDesc" rows="2"></textarea>
            </div>
          </div>
        </div>
        <div
          style="padding:.9rem 1.2rem;border-top:1px solid #dee2e6;display:flex;justify-content:flex-end;gap:.5rem;background:#fafafa;border-radius:0 0 14px 14px;">
          <button type="button" class="btn-csta-o" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn-csta" id="bookSaveBtn"><i class="bi bi-check-circle"></i> Save Book</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  // --- Cover Image Preview ---
  document.getElementById('bCover').addEventListener('change', function () {
    const file = this.files[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      toast('Image must be under 2MB.', 'error');
      this.value = '';
      return;
    }

    document.getElementById('coverFileName').textContent = file.name;
    const reader = new FileReader();
    reader.onload = function (e) {
      const img = document.getElementById('coverPreview');
      const placeholder = document.getElementById('coverPlaceholder');
      img.src = e.target.result;
      img.style.display = 'block';
      placeholder.style.display = 'none';
    };
    reader.readAsDataURL(file);
  });

  function resetCoverPreview() {
    document.getElementById('coverPreview').src = '';
    document.getElementById('coverPreview').style.display = 'none';
    document.getElementById('coverPlaceholder').style.display = 'block';
    document.getElementById('coverFileName').textContent = 'No file chosen';
    document.getElementById('bCover').value = '';
    document.getElementById('bExistingCover').value = '';
  }

  function setCoverPreview(filename) {
    if (!filename) { resetCoverPreview(); return; }
    const img = document.getElementById('coverPreview');
    const placeholder = document.getElementById('coverPlaceholder');
    img.src = '<?= BASE_URL ?>/assets/uploads/books/' + filename;
    img.style.display = 'block';
    placeholder.style.display = 'none';
    document.getElementById('coverFileName').textContent = filename;
    document.getElementById('bExistingCover').value = filename;
  }

  // --- Modal Open ---
  function openAddModal() {
    document.getElementById('bookModalTitle').textContent = 'Add Book';
    document.getElementById('bookForm').reset();
    document.getElementById('bId').value = '';
    document.getElementById('bCode').value = '';
    resetCoverPreview();
    new bootstrap.Modal(document.getElementById('bookModal')).show();
  }

  function editBook(b) {
    document.getElementById('bookModalTitle').textContent = 'Edit Book';
    document.getElementById('bId').value = b.id;
    document.getElementById('bCode').value = b.book_code;
    document.getElementById('bTitle').value = b.title;
    document.getElementById('bAuthor').value = b.author;
    document.getElementById('bIsbn').value = b.isbn || '';
    document.getElementById('bCat').value = b.category || '';
    document.getElementById('bQty').value = b.quantity;
    document.getElementById('bAvail').value = b.available;
    document.getElementById('bDesc').value = b.description || '';
    setCoverPreview(b.cover_image || '');
    new bootstrap.Modal(document.getElementById('bookModal')).show();
  }

  // --- Form Submit ---
  document.getElementById('bookForm').addEventListener('submit', async e => {
    e.preventDefault();

    const isAdd = !document.getElementById('bId').value;
    const coverFile = document.getElementById('bCover').files[0];

    if (isAdd && !coverFile) {
      toast('Please upload a cover image.', 'error');
      return;
    }

    const btn = document.getElementById('bookSaveBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="bi bi-hourglass-split"></i> Saving...';

    const fd = new FormData(e.target);
    try {
      const r = await fetch('<?= BASE_URL ?>/api/books.php', { method: 'POST', body: fd });
      const d = await r.json();
      bootstrap.Modal.getInstance(document.getElementById('bookModal')).hide();
      toast(d.message, d.success ? 'success' : 'error');
      if (d.success) setTimeout(() => location.reload(), 1000);
    } catch (err) {
      toast('Something went wrong. Please try again.', 'error');
    } finally {
      btn.disabled = false;
      btn.innerHTML = '<i class="bi bi-check-circle"></i> Save Book';
    }
  });

  // Delete handler (same logic, executed server-side)
  <?php if (isset($_GET['delete']) && is_numeric($_GET['delete'])):
    $did = (int) $_GET['delete'];
    $pdo->prepare("UPDATE books SET is_active=0 WHERE id=?")->execute([$did]);
    logActivity($_SESSION['user_id'], 'Delete', 'Books', 'Deleted book ID ' . $did);
    header('Location: books.php');
    exit;
  endif; ?>
</script>
<?php require_once __DIR__ . '/layout/footer.php'; ?>