<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireLogin();
$pageTitle = 'Borrowers Management';

if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
  $pdo->prepare("UPDATE borrowers SET is_active=0 WHERE id=?")->execute([(int) $_GET['delete']]);
  header('Location: borrowers.php');
  exit;
}

$search = trim($_GET['s'] ?? '');
$type = trim($_GET['type'] ?? '');
$page = max(1, (int) ($_GET['p'] ?? 1));
$limit = 10;
$offset = ($page - 1) * $limit;

$where = ['is_active=1'];
$params = [];
if ($search) {
  $where[] = "(full_name LIKE ? OR borrower_code LIKE ? OR department LIKE ?)";
  $p = "%$search%";
  $params = array_merge($params, [$p, $p, $p]);
}
if ($type) {
  $where[] = "LOWER(borrower_type) LIKE LOWER(?)";
  $params[] = "%$type%";
}

$sql = "SELECT * FROM borrowers WHERE " . implode(' AND ', $where) . " ORDER BY full_name ASC LIMIT $limit OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$borrowers = $stmt->fetchAll();

$total = $pdo->prepare("SELECT COUNT(*) FROM borrowers WHERE " . implode(' AND ', $where));
$total->execute($params);
$total = (int) $total->fetchColumn();
$pages = max(1, ceil($total / $limit));
?>
<?php require_once __DIR__ . '/layout/header.php'; ?>
<div class="cc">
  <div class="cch">
    <div>
      <p class="cct">Borrowers Management</p>
      <p class="ccs">List of borrower records.</p>
    </div>
    <button class="btn-csta" onclick="openAddBr()"><i class="bi bi-person-plus"></i> Add Borrower</button>
  </div>
  <div style="padding:.75rem 1rem;border-bottom:1px solid #f0f0f0;display:flex;gap:.5rem;flex-wrap:wrap;">
    <form method="GET" style="display:contents;">
      <input class="srch" type="search" name="s" id="searchInput" value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>"
        placeholder="Search name, ID, department">
      <select class="srch" name="type" style="min-width:130px;" onchange="clearSearchAndSubmit()">
        <option value="">All Types</option>
        <option <?= $type === 'student' ? 'selected' : '' ?> value="student">Student</option>
        <option <?= $type === 'faculty' ? 'selected' : '' ?> value="faculty">Faculty</option>
      </select>
      <button class="btn-csta" type="submit"><i class="bi bi-search"></i></button>
      <a href="borrowers.php" class="btn-csta-o">Clear</a>
    </form>
  </div>

  <div style="overflow-x:auto;">
    <table class="tbl">
      <thead>
        <tr>
          <th>#</th>
          <th>ID</th>
          <th>Name</th>
          <th>Type</th>
          <th>Department</th>
          <th>Year</th>
          <th>Contact</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$borrowers): ?>
          <tr>
            <td colspan="9" style="text-align:center;padding:2rem;color:#6c757d;">No borrowers found.</td>
          </tr>
        <?php endif; ?>
        <?php foreach ($borrowers as $i => $b): ?>
          <tr>
            <td style="color:#aaa;font-size:.78rem;"><?= $offset + $i + 1 ?></td>
            <td style="font-weight:700;color:#2d4a3e;"><?= esc($b['borrower_code']) ?></td>
            <td style="font-weight:600;"><?= esc($b['full_name']) ?></td>
            <td><?= ucfirst(esc($b['borrower_type'])) ?></td>
            <td><?= esc($b['department']) ?></td>
            <td><?= esc($b['year_level']) ?></td>
            <td><?= esc($b['contact']) ?></td>
            <td><?= statusBadge($b['is_active'] ? 'Active' : 'Inactive') ?></td>
            <td>
              <div style="display:flex;gap:.3rem;">
                <button class="ic-btn" onclick="editBr(<?= htmlspecialchars(json_encode($b)) ?>)"><i
                    class="bi bi-pencil-square"></i></button>
                <a class="ic-btn del" href="?delete=<?= $b['id'] ?>"
                  onclick="event.preventDefault();confirmDel('?delete=<?= $b['id'] ?>','Delete this borrower?');"><i
                    class="bi bi-trash"></i></a>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php if ($pages > 1): ?>
    <div style="padding:.75rem;border-top:1px solid #f0f0f0;display:flex;justify-content:flex-end;gap:.3rem;">
      <?php for ($n = 1; $n <= $pages; $n++): ?>
        <a href="?p=<?= $n ?>&s=<?= urlencode($search) ?>&type=<?= urlencode($type) ?>"
          style="display:inline-flex;align-items:center;justify-content:center;min-width:30px;height:30px;border-radius:7px;border:1px solid #dee2e6;text-decoration:none;font-size:.8rem;<?= $n == $page ? 'background:#4a8264;color:#fff;' : 'background:#fff;color:#4a8264;' ?>">
          <?= $n ?>
        </a>
      <?php endfor; ?>
    </div>
  <?php endif; ?>
</div>

<div class="modal fade" id="brModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content" style="border-radius:14px;">
      <div
        style="padding:1rem 1.2rem;border-bottom:1px solid #dee2e6;display:flex;align-items:center;justify-content:space-between;">
        <span style="font-size:.95rem;font-weight:700;color:#1a3a2a;" id="brModalTitle">Add Borrower</span>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form id="brForm">
        <div style="padding:1.2rem;">
          <input type="hidden" id="brId" name="id">
          <div class="row g-3">
            <div class="col-md-8"><label class="form-lbl">Full Name *</label><input class="f-ctrl" type="text"
                name="full_name" id="brName" required></div>
            <div class="col-md-4"><label class="form-lbl">Type</label>
              <select class="f-ctrl" name="borrower_type" id="brType">
                <option value="student">Student</option>
                <option value="faculty">Faculty</option>
              </select>
            </div>
            <div class="col-md-6"><label class="form-lbl">Department</label><input class="f-ctrl" type="text"
                name="department" id="brDept"></div>
            <div class="col-md-6"><label class="form-lbl">Year Level</label><input class="f-ctrl" type="text"
                name="year_level" id="brYear" placeholder="e.g. 3rd Year"></div>
            <div class="col-md-6"><label class="form-lbl">Contact</label><input class="f-ctrl" type="text"
                name="contact" id="brContact"></div>
            <div class="col-md-6"><label class="form-lbl">Email</label><input class="f-ctrl" type="email" name="email"
                id="brEmail"></div>
          </div>
        </div>
        <div
          style="padding:.9rem 1.2rem;border-top:1px solid #dee2e6;display:flex;justify-content:flex-end;gap:.5rem;background:#fafafa;border-radius:0 0 14px 14px;">
          <button type="button" class="btn-csta-o" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn-csta"><i class="bi bi-check-circle"></i> Save</button>
        </div>
      </form>
    </div>
  </div>
</div>
<script>
  function clearSearchAndSubmit() {
    document.getElementById('searchInput').value = '';
    event.target.form.submit();
  }

  function openAddBr() {
    document.getElementById('brModalTitle').textContent = 'Add Borrower';
    document.getElementById('brForm').reset();
    document.getElementById('brId').value = '';
    new bootstrap.Modal(document.getElementById('brModal')).show();
  }
  function editBr(b) {
    document.getElementById('brModalTitle').textContent = 'Edit Borrower';
    const mapping = { brId: 'id', brName: 'full_name', brType: 'borrower_type', brDept: 'department', brYear: 'year_level', brContact: 'contact', brEmail: 'email' };
    for (const [id, key] of Object.entries(mapping)) {
      document.getElementById(id).value = b[key] || '';
    }
    new bootstrap.Modal(document.getElementById('brModal')).show();
  }
  document.getElementById('brForm').addEventListener('submit', async e => {
    e.preventDefault();
    const r = await fetch('<?= BASE_URL ?>/api/borrowers.php', {
      method: 'POST',
      body: new URLSearchParams(new FormData(e.target))
    });
    const d = await r.json();
    bootstrap.Modal.getInstance(document.getElementById('brModal')).hide();
    toast(d.message, d.success ? 'success' : 'error');
    if (d.success) setTimeout(() => location.reload(), 1000);
  });
</script>
<?php require_once __DIR__ . '/layout/footer.php'; ?>
