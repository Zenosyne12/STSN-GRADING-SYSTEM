<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireLogin();
$pageTitle = 'Supplies Management';

if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
  $pdo->prepare("UPDATE supplies SET is_active=0 WHERE id=?")->execute([(int) $_GET['delete']]);
  logActivity($_SESSION['user_id'], 'Delete', 'Supplies', 'Deleted supply ID ' . (int) $_GET['delete']);
  header('Location: supplies.php');
  exit;
}

$search = trim($_GET['s'] ?? '');
$cat = trim($_GET['cat'] ?? '');
$status = trim($_GET['status'] ?? '');
$page = max(1, (int) ($_GET['p'] ?? 1));
$limit = 10;
$offset = ($page - 1) * $limit;

$where = ['s.is_active=1'];
$params = [];
if ($search) {
  $where[] = "(s.item_name LIKE ? OR s.supply_code LIKE ?)";
  $p = "%$search%";
  $params = array_merge($params, [$p, $p]);
}
if ($cat) {
  $where[] = "s.category=?";
  $params[] = $cat;
}
if ($status === 'in') {
  $where[] = "s.quantity > s.reorder_level";
} elseif ($status === 'low') {
  $where[] = "s.quantity > 0 AND s.quantity <= s.reorder_level";
} elseif ($status === 'out') {
  $where[] = "s.quantity = 0";
}

$sql = "SELECT s.* FROM supplies s WHERE " . implode(' AND ', $where) . " ORDER BY s.item_name ASC LIMIT $limit OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$supplies = $stmt->fetchAll();

$total = $pdo->prepare("SELECT COUNT(*) FROM supplies s WHERE " . implode(' AND ', $where));
$total->execute($params);
$total = (int) $total->fetchColumn();
$pages = max(1, ceil($total / $limit));

$categories = $pdo->query("SELECT DISTINCT category FROM supplies WHERE is_active=1 AND category IS NOT NULL AND category != '' ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);
?>
<?php require_once __DIR__ . '/layout/header.php'; ?>
<div class="cc">
    <div class="cch">
      <div>
        <p class="cct">Supplies Management</p>
        <p class="ccs">Inventory of supplies inventory.</p>
      </div>
      <button class="btn-csta" onclick="openAddSup()"><i class="bi bi-plus-circle"></i> Add Supply</button>
    </div>
    <div style="padding:.75rem 1rem;border-bottom:1px solid #f0f0f0;display:flex;gap:.5rem;flex-wrap:wrap;">
      <form method="GET" style="display:contents;">
        <input class="srch" type="search" name="s" id="searchInput" value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>"
          placeholder="Search supply name or code">
        <select class="srch" name="cat" style="min-width:140px;" onchange="clearSearchAndSubmit()">
          <option value="">All Categories</option>
          <?php foreach ($categories as $c): ?>
            <option <?= $cat === $c ? 'selected' : '' ?> value="<?= esc($c) ?>"><?= esc($c) ?></option>
          <?php endforeach; ?>
        </select>
        <select class="srch" name="status" style="min-width:130px;" onchange="clearSearchAndSubmit()">
          <option value="">All Status</option>
          <option <?= $status === 'in' ? 'selected' : '' ?> value="in">In Stock</option>
          <option <?= $status === 'low' ? 'selected' : '' ?> value="low">Low Stock</option>
          <option <?= $status === 'out' ? 'selected' : '' ?> value="out">Out of Stock</option>
        </select>
        <button class="btn-csta" type="submit"><i class="bi bi-search"></i> Search</button>
        <a href="supplies.php" class="btn-csta-o">Clear</a>
      </form>
    </div>
    <div style="overflow-x:auto;">
      <table class="tbl">
        <thead>
          <tr>
            <th>#</th>
            <th>ID</th>
            <th>Item Name</th>
            <th>Category</th>
            <th>Qty</th>
            <th>Unit</th>
            <th>Reorder Level</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!$supplies): ?>
            <tr>
              <td colspan="9" style="text-align:center;padding:2rem;color:#6c757d;">
                <i class="bi bi-box-seam" style="font-size:1.8rem;display:block;opacity:.4;"></i>
                No supplies found.
              </td>
            </tr>
          <?php endif; ?>
          <?php foreach ($supplies as $i => $s):
            $st = getSupplyStatus($s['quantity'], $s['reorder_level']); ?>
            <tr>
              <td style="color:#aaa;font-size:.78rem;"><?= $offset + $i + 1 ?></td>
              <td style="font-weight:700;color:#2d4a3e;"><?= esc($s['supply_code']) ?></td>
              <td style="font-weight:600;"><?= esc($s['item_name']) ?></td>
              <td><?= esc($s['category']) ?></td>
              <td
                style="text-align:center;font-weight:700;color:<?= $s['quantity'] <= $s['reorder_level'] ? '#b71c1c' : '#2e7d32' ?>">
                <?= $s['quantity'] ?>
              </td>
              <td><?= esc($s['unit']) ?></td>
              <td style="text-align:center;"><?= $s['reorder_level'] ?></td>
              <td><?= statusBadge($st) ?></td>
              <td>
                <div style="display:flex;gap:.3rem;">
                  <button class="ic-btn" onclick="editSup(<?= htmlspecialchars(json_encode($s)) ?>)">
                    <i class="bi bi-pencil-square"></i>
                  </button>
                  <a class="ic-btn del" href="?delete=<?= $s['id'] ?>"
                    onclick="event.preventDefault();confirmDel('?delete=<?= $s['id'] ?>','Delete this supply?');">
                    <i class="bi bi-trash"></i>
                  </a>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php if ($pages > 1): ?>
      <div style="padding:.75rem 1rem;border-top:1px solid #f0f0f0;display:flex;justify-content:flex-end;gap:.3rem;">
        <?php for ($n = 1; $n <= $pages; $n++): ?>
          <a href="?p=<?= $n ?>&s=<?= urlencode($search) ?>&cat=<?= urlencode($cat) ?>&status=<?= urlencode($status) ?>"
            style="display:inline-flex;align-items:center;justify-content:center;min-width:30px;height:30px;border-radius:7px;border:1px solid #dee2e6;text-decoration:none;font-size:.8rem;font-weight:600;<?= $n == $page ? 'background:#4a8264;color:#fff;border-color:#4a8264;' : 'background:#fff;color:#4a8264;' ?>">
            <?= $n ?>
          </a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>
  </div>
<div class="modal fade" id="supModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content" style="border-radius:14px;">
        <div
          style="padding:1rem 1.2rem;border-bottom:1px solid #dee2e6;display:flex;align-items:center;justify-content:space-between;">
          <span style="font-size:.95rem;font-weight:700;color:#1a3a2a;" id="supModalTitle">Add Supply</span>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <form id="supForm">
          <div style="padding:1.2rem;">
            <input type="hidden" id="sId" name="id">
            <div class="row g-3">
              <div class="col-12">
                <label class="form-lbl">Item Name *</label>
                <input class="f-ctrl" type="text" name="item_name" id="sName" required>
              </div>
              <div class="col-md-6">
                <label class="form-lbl">Category</label>
                <select class="f-ctrl" name="category" id="sCat">
                  <option value="">Select Category</option>
                  <?php foreach ($categories as $c): ?>
                    <option value="<?= esc($c) ?>"><?= esc($c) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-3">
                <label class="form-lbl">Quantity *</label>
                <input class="f-ctrl" type="number" name="quantity" id="sQty" min="0" required>
              </div>
              <div class="col-md-3">
                <label class="form-lbl">Unit</label>
                <input class="f-ctrl" type="text" name="unit" id="sUnit" value="pcs">
              </div>
              <div class="col-md-6">
                <label class="form-lbl">Reorder Level</label>
                <input class="f-ctrl" type="number" name="reorder_level" id="sReorder" min="0" value="10">
              </div>
              <div class="col-12">
                <label class="form-lbl">Description</label>
                <textarea class="f-ctrl" name="description" id="sDesc" rows="2"></textarea>
              </div>
            </div>
          </div>
          <div
            style="padding:.9rem 1.2rem;border-top:1px solid #dee2e6;display:flex;justify-content:flex-end;gap:.5rem;background:#fafafa;border-radius:0 0 14px 14px;">
            <button type="button" class="btn-csta-o" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn-csta"><i class="bi bi-check-circle"></i> Save</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script>
    function clearSearchAndSubmit() {
      document.getElementById('searchInput').value = '';
      event.target.form.submit();
    }

    function openAddSup() {
      document.getElementById('supModalTitle').textContent = 'Add Supply';
      document.getElementById('supForm').reset();
      document.getElementById('sId').value = '';
      document.getElementById('sCat').selectedIndex = 0;
      new bootstrap.Modal(document.getElementById('supModal')).show();
    }

    function editSup(s) {
      document.getElementById('supModalTitle').textContent = 'Edit Supply';
      document.getElementById('sId').value = s.id;
      document.getElementById('sName').value = s.item_name;
      document.getElementById('sQty').value = s.quantity;
      document.getElementById('sUnit').value = s.unit || 'pcs';
      document.getElementById('sReorder').value = s.reorder_level;
      document.getElementById('sDesc').value = s.description || '';

      const catSelect = document.getElementById('sCat');
      const catValue = s.category || '';
      if (catValue !== '') {
        let optionExists = false;
        for (let opt of catSelect.options) {
          if (opt.value === catValue) {
            optionExists = true;
            break;
          }
        }
        if (!optionExists) {
          const newOption = new Option(catValue, catValue, true, true);
          catSelect.add(newOption);
        }
        catSelect.value = catValue;
      } else {
        catSelect.selectedIndex = 0;
      }

      new bootstrap.Modal(document.getElementById('supModal')).show();
    }

    document.getElementById('supForm').addEventListener('submit', async e => {
      e.preventDefault();
      const r = await fetch('<?= BASE_URL ?>/api/supplies.php', {
        method: 'POST',
        body: new URLSearchParams(new FormData(e.target))
      });
      const d = await r.json();
      bootstrap.Modal.getInstance(document.getElementById('supModal')).hide();
      toast(d.message, d.success ? 'success' : 'error');
      if (d.success) setTimeout(() => location.reload(), 1000);
    });
  </script>

  <?php require_once __DIR__ . '/layout/footer.php'; ?>
