<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireLogin();
$pageTitle = 'Admin Dashboard';

$pdo->exec("UPDATE borrowing SET status='overdue' WHERE status='active' AND due_date < CURDATE()");

$totalBooks = $pdo->query("SELECT COUNT(*) FROM books WHERE is_active=1")->fetchColumn();
$totalSupplies = $pdo->query("SELECT COUNT(*) FROM supplies WHERE is_active=1")->fetchColumn();
$activeBorrow = $pdo->query("SELECT COUNT(*) FROM borrowing WHERE status IN('active','overdue')")->fetchColumn();
$pendingReturn = $pdo->query("SELECT COUNT(*) FROM borrowing WHERE status='overdue'")->fetchColumn();

$lowStock = $pdo->query("SELECT * FROM supplies WHERE quantity <= reorder_level AND is_active=1 ORDER BY quantity ASC LIMIT 5")->fetchAll();

// Most Borrowed Books (Top 5)
$mostBorrowed = $pdo->query("
    SELECT b.title, b.author, COUNT(br.id) as borrow_count 
    FROM borrowing br
    JOIN books b ON b.id = br.book_id
    WHERE br.created_at >= DATE_SUB(NOW(), INTERVAL 3 MONTH)
    GROUP BY br.book_id
    ORDER BY borrow_count DESC
    LIMIT 5
")->fetchAll();

// Monthly Borrowing Trends (Last 6 months)
$monthlyTrends = $pdo->query("
    SELECT 
        DATE_FORMAT(created_at, '%b %Y') as month,
        DATE_FORMAT(created_at, '%Y-%m') as month_key,
        COUNT(*) as count
    FROM borrowing
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY month_key
    ORDER BY month_key ASC
")->fetchAll();
?>
<?php require_once __DIR__ . '/layout/header.php'; ?>

<div class="row g-3 mb-3">
  <div class="col-6 col-md-3">
    <div class="stat-card">
      <div class="stat-icon" style="background:#f0e6df;color:#6E412A;"><i class="bi bi-book"></i></div>
      <div>
        <div class="stat-num" style="color:#4a2511;"><?= $totalBooks ?></div>
        <div class="stat-lbl">Total Books</div>
      </div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="stat-card">
      <div class="stat-icon" style="background:#e8dfdc;color:#8B5A2B;"><i class="bi bi-box-seam"></i></div>
      <div>
        <div class="stat-num" style="color:#4a2511;"><?= $totalSupplies ?></div>
        <div class="stat-lbl">Total Supplies</div>
      </div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="stat-card">
      <div class="stat-icon" style="background:#f5efe9;color:#6E412A;"><i class="bi bi-arrow-left-right"></i></div>
      <div>
        <div class="stat-num" style="color:#4a2511;"><?= $activeBorrow ?></div>
        <div class="stat-lbl">Active Borrowings</div>
      </div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="stat-card">
      <div class="stat-icon" style="background:#f9e9e0;color:#b71c1c;"><i class="bi bi-clock-history"></i></div>
      <div>
        <div class="stat-num" style="color:#4a2511;"><?= $pendingReturn ?></div>
        <div class="stat-lbl">Pending Returns</div>
      </div>
    </div>
  </div>
</div>

<?php if (count($lowStock)): ?>
  <div
    style="background:#fff9f0;border:1px solid #6E412A;border-radius:10px;padding:.7rem 1rem;margin-bottom:1rem;font-size:.84rem;color:#5a3520;display:flex;align-items:flex-start;gap:.5rem;">
    <i class="bi bi-exclamation-triangle-fill" style="margin-top:.1rem;flex-shrink:0;color:#6E412A;"></i>
    <div>
      <strong style="color:#6E412A;">Stock Alerts:</strong>
      <div style="margin-top:.4rem;">
        <?php foreach ($lowStock as $s): ?>
          <div style="margin-bottom:.3rem;color:#4a2511;">
            <strong><?= esc($s['item_name']) ?></strong> — Only <?= $s['quantity'] ?>     <?= esc($s['unit']) ?> left
            (Reorder: <?= $s['reorder_level'] ?>)
          </div>
        <?php endforeach; ?>
      </div>
      <a href="<?= BASE_URL ?>/admin/supplies.php" class="btn-csta" style="margin-top:.5rem;font-size:.75rem;">
        <i class="bi bi-box-seam"></i> Go to Supplies
      </a>
    </div>
  </div>
<?php endif; ?>

<!-- Most Borrowed Books & Monthly Trends -->
<div class="row g-3 mb-3">
  <!-- Most Borrowed Books -->
  <div class="col-md-6">
    <div class="cc">
      <div class="cch">
        <div>
          <p class="cct">Most Borrowed Books</p>
          <p class="ccs">Top 5 books in the last 3 months</p>
        </div>
      </div>
      <div style="padding:1.2rem;">
        <?php if (count($mostBorrowed)): ?>
          <div style="display:flex;flex-direction:column;gap:.8rem;">
            <?php foreach ($mostBorrowed as $index => $book): ?>
              <div
                style="display:flex;align-items:center;gap:.8rem;padding:.6rem;background:#f9f6f3;border-radius:8px;border-left:4px solid #6E412A;">
                <div
                  style="background:#6E412A;color:#fff;width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.9rem;flex-shrink:0;">
                  <?= $index + 1 ?>
                </div>
                <div style="flex:1;">
                  <div style="font-weight:600;color:#4a2511;font-size:.88rem;">
                    <?= esc($book['title']) ?>
                  </div>
                  <div style="font-size:.78rem;color:#8d6b52;">
                    by <?= esc($book['author']) ?>
                  </div>
                </div>
                <div
                  style="background:#6E412A;color:#fff;padding:.3rem .7rem;border-radius:6px;font-weight:700;font-size:.8rem;">
                  <?= $book['borrow_count'] ?>x
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <div style="text-align:center;padding:2rem;color:#8d6b52;">
            <i class="bi bi-book" style="font-size:2.5rem;opacity:0.3;"></i>
            <p style="margin-top:.5rem;font-size:.88rem;">No borrowing data available</p>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Monthly Borrowing Trends -->
  <div class="col-md-6">
    <div class="cc">
      <div class="cch">
        <div>
          <p class="cct">Monthly Borrowing Trends</p>
          <p class="ccs">Borrowing activity over the last 6 months</p>
        </div>
      </div>
      <div style="padding:1.2rem;">
        <?php if (count($monthlyTrends)): ?>
          <?php
          $maxCount = max(array_column($monthlyTrends, 'count'));
          ?>
          <div style="display:flex;flex-direction:column;gap:.6rem;">
            <?php foreach ($monthlyTrends as $trend): ?>
              <?php
              $percentage = $maxCount > 0 ? ($trend['count'] / $maxCount) * 100 : 0;
              ?>
              <div>
                <div style="display:flex;justify-content:space-between;margin-bottom:.3rem;font-size:.8rem;">
                  <span style="font-weight:600;color:#4a2511;"><?= esc($trend['month']) ?></span>
                  <span style="color:#6E412A;font-weight:700;"><?= $trend['count'] ?> borrowings</span>
                </div>
                <div style="background:#f0e6df;height:24px;border-radius:6px;overflow:hidden;">
                  <div
                    style="background:linear-gradient(90deg, #6E412A 0%, #8B5A2B 100%);height:100%;width:<?= $percentage ?>%;transition:width 0.3s ease;display:flex;align-items:center;justify-content:flex-end;padding-right:.5rem;color:#fff;font-size:.75rem;font-weight:600;">
                    <?php if ($percentage > 20): ?>
                      <?= $trend['count'] ?>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <div style="text-align:center;padding:2rem;color:#8d6b52;">
            <i class="bi bi-graph-up" style="font-size:2.5rem;opacity:0.3;"></i>
            <p style="margin-top:.5rem;font-size:.88rem;">No trend data available</p>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<div class="cc">
  <div class="cch">
    <div>
      <p class="cct">Audit & Reports</p>
      <p class="ccs">View system activity and logs</p>
    </div>
  </div>
  <div style="padding:1.2rem;">
    <a href="<?= BASE_URL ?>/admin/activity_log.php" class="btn-csta"
      style="width:100%;justify-content:center;margin-bottom:.75rem;"><i class="bi bi-clock-history"></i> View
      Activity Log</a>
    <p style="font-size:.8rem;color:#8d6b52;margin:1rem 0;"><strong>System Stats:</strong></p>
    <ul style="font-size:.84rem;color:#6a422a;padding-left:1.2rem;margin:0;">
      <li><?= $pendingReturn ?> overdue book(s) requiring follow-up</li>
      <li><?= count($lowStock) ?> supplies below reorder level</li>
      <li><?= $activeBorrow ?> books currently borrowed</li>
      <li>All user actions logged for accountability</li>
    </ul>
  </div>
</div>

<?php require_once __DIR__ . '/layout/footer.php'; ?>