<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireLogin();
$pageTitle = 'Search';
?>
<?php require_once __DIR__ . '/layout/header.php'; ?>
<div class="cc mb-3">
    <div class="cch">
      <div>
        <p class="cct">Search Module</p>
        <p class="ccs">Search books, supplies, and borrowers in real time.</p>
      </div>
    </div>
    <div style="padding:1.2rem;">
      <div style="display:flex;gap:.5rem;margin-bottom:1rem;">
        <input class="srch" type="text" id="searchBox" placeholder="Search books, supplies, or borrowers..."
          oninput="liveSearch(this.value)" autocomplete="off">
        <select class="srch" id="searchType" style="min-width:130px;"
          onchange="liveSearch(document.getElementById('searchBox').value)">
          <option value="all">All</option>
          <option value="book">Books</option>
          <option value="supply">Supplies</option>
          <option value="borrower">Borrowers</option>
        </select>
      </div>
      <div id="searchResults">
        <div style="text-align:center;padding:2rem;color:#6c757d;">
          <i class="bi bi-search" style="font-size:2rem;display:block;opacity:.3;margin-bottom:.5rem;"></i>
          Start typing to search...
        </div>
      </div>
    </div>
  </div>
  <script>
    let timer;
    function liveSearch(q) {
      clearTimeout(timer);
      if (!q.trim()) {
        document.getElementById('searchResults').innerHTML = '<div style="text-align:center;padding:2rem;color:#6c757d;"><i class="bi bi-search" style="font-size:2rem;display:block;opacity:.3;margin-bottom:.5rem;"></i>Start typing to search...</div>';
        return;
      }
      timer = setTimeout(async () => {
        const type = document.getElementById('searchType').value;
        const r = await fetch(`<?= BASE_URL ?>/api/search.php?q=${encodeURIComponent(q)}&type=${type}`);
        const d = await r.json();
        const icons = { book: 'bi-book', supply: 'bi-box-seam', borrower: 'bi-person' };
        const colors = { book: '#e8f5e9', supply: '#e3f2fd', borrower: '#fff3e0' };
        const fc = { book: '#2e7d32', supply: '#1565c0', borrower: '#e65100' };
        if (!d.length) {
          document.getElementById('searchResults').innerHTML = '<div style="text-align:center;padding:2rem;color:#6c757d;">No results found.</div>';
          return;
        }
        document.getElementById('searchResults').innerHTML = `
                <table class="tbl">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Code</th>
                            <th>Name</th>
                            <th>Details</th>
                            <th>Extra</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${d.map(i => `
                            <tr>
                                <td><span style="background:${colors[i.type]};color:${fc[i.type]};border-radius:6px;padding:.2rem .55rem;font-size:.76rem;font-weight:700;display:inline-flex;align-items:center;gap:.3rem;"><i class="bi ${icons[i.type] || 'bi-circle'}"></i>${i.type}</span></td>
                                <td style="font-weight:700;color:#2d4a3e;">${i.code || '-'}</td>
                                <td style="font-weight:600;">${i.name || '-'}</td>
                                <td style="font-size:.84rem;color:#6c757d;">${i.detail || '-'}</td>
                                <td style="font-size:.84rem;">${i.type === 'book' ? `${i.extra} available` : (i.type === 'supply' ? `${i.extra} in stock` : '')}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;
      }, 300);
    }
  </script>
  <?php require_once __DIR__ . '/layout/footer.php'; ?>
