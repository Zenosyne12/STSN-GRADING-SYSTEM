<?php
require_once __DIR__ . '/includes/config.php';
if (isLoggedIn()) {
  header('Location: ' . BASE_URL . '/admin/dashboard.php');
  exit;
}

$error = '';
$loginAs = trim($_GET['as'] ?? 'admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = trim($_POST['username'] ?? '');
  $password = $_POST['password'] ?? '';
  $type = trim($_POST['type'] ?? 'admin');

  if (!$username || !$password) {
    $error = 'Please enter credentials.';
  } else {
    if ($type === 'borrower') {
      $stmt = $pdo->prepare("SELECT * FROM borrowers WHERE borrower_code=?");
      $stmt->execute([$username]);
      $user = $stmt->fetch();
      if ($user && $password === '1234') {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['borrower_code'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['role'] = 'borrower';
        logActivity($user['id'], 'Login', 'Auth', 'Borrower logged in');
        header('Location: ' . BASE_URL . '/client/dashboard.php');
        exit;
      }
      $error = 'Invalid borrower ID or PIN.';
      $loginAs = 'borrower';
    } else {
      $stmt = $pdo->prepare("SELECT * FROM users WHERE username=? AND is_active=1");
      $stmt->execute([$username]);
      $user = $stmt->fetch();
      if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['role'] = $user['role'];
        logActivity($user['id'], 'Login', 'Auth', 'Admin logged in');
        header('Location: ' . BASE_URL . '/admin/dashboard.php');
        exit;
      }
      $error = 'Invalid username or password.';
      $loginAs = 'admin';
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login | CSTA Library</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Playfair+Display:wght@700;800&display=swap"
    rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  <style>
    :root {
      --brand: #6E412A;
      --brand-dark: #4a2a18;
      --brand-light: #a87354;
      --cream: #f8f3ec;
      --ink: #2a1a10;
      --muted: #8a7a6e;
      --border: #ead9c7;
    }

    * {
      box-sizing: border-box;
    }

    html,
    body {
      height: 100%;
    }

    body {
      margin: 0;
      font-family: 'Inter', system-ui, -apple-system, sans-serif;
      color: var(--ink);
      background: var(--cream);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 1.5rem;
      position: relative;
      overflow-x: hidden;
    }

    /* Decorative background */
    body::before,
    body::after {
      content: '';
      position: fixed;
      border-radius: 50%;
      filter: blur(80px);
      z-index: 0;
      pointer-events: none;
    }

    body::before {
      width: 520px;
      height: 520px;
      background: radial-gradient(circle, rgba(168, 115, 84, .45), transparent 70%);
      top: -180px;
      left: -120px;
    }

    body::after {
      width: 600px;
      height: 600px;
      background: radial-gradient(circle, rgba(110, 65, 42, .35), transparent 70%);
      bottom: -220px;
      right: -160px;
    }

    .login-wrap {
      position: relative;
      z-index: 1;
      background: #fff;
      border-radius: 24px;
      box-shadow:
        0 30px 60px -20px rgba(74, 42, 24, .25),
        0 10px 30px -10px rgba(74, 42, 24, .15);
      overflow: hidden;
      width: 100%;
      max-width: 980px;
      display: grid;
      grid-template-columns: 1.05fr 1fr;
      min-height: 600px;
    }

    /* LEFT: brand panel */
    .login-left {
      position: relative;
      background:
        linear-gradient(135deg, rgba(74, 42, 24, .92), rgba(110, 65, 42, .85)),
        url('assets/img/BACKGROUND.jpg') center/cover no-repeat;
      color: #fff;
      padding: 3rem 2.75rem;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      overflow: hidden;
    }

    .login-left::after {
      content: '';
      position: absolute;
      inset: 0;
      background:
        radial-gradient(600px circle at 80% 10%, rgba(255, 255, 255, .08), transparent 50%),
        radial-gradient(400px circle at 10% 90%, rgba(255, 255, 255, .06), transparent 50%);
      pointer-events: none;
    }

    .brand-row {
      display: flex;
      align-items: center;
      gap: .85rem;
      position: relative;
      z-index: 1;
    }

    .brand-logo {
      width: 52px;
      height: 52px;
      border-radius: 14px;
      object-fit: cover;
      box-shadow: 0 8px 20px rgba(0, 0, 0, .25);
      background: #fff;
    }

    .brand-name {
      font-weight: 700;
      letter-spacing: .02em;
      font-size: .95rem;
      text-transform: uppercase;
      opacity: .9;
    }

    .hero {
      position: relative;
      z-index: 1;
    }

    .hero-eyebrow {
      display: inline-flex;
      align-items: center;
      gap: .4rem;
      font-size: .72rem;
      font-weight: 600;
      letter-spacing: .14em;
      text-transform: uppercase;
      padding: .35rem .7rem;
      border: 1px solid rgba(255, 255, 255, .25);
      border-radius: 999px;
      background: rgba(255, 255, 255, .08);
      backdrop-filter: blur(8px);
      margin-bottom: 1.25rem;
    }

    .hero-title {
      font-family: 'Playfair Display', serif;
      font-weight: 800;
      font-size: 2.4rem;
      line-height: 1.1;
      letter-spacing: -0.01em;
      margin: 0 0 1rem;
    }

    .hero-desc {
      font-size: .95rem;
      line-height: 1.65;
      color: rgba(255, 255, 255, .82);
      max-width: 36ch;
    }

    .features {
      position: relative;
      z-index: 1;
      display: grid;
      gap: .75rem;
      margin-top: 1.5rem;
    }

    .feature {
      display: flex;
      align-items: center;
      gap: .7rem;
      font-size: .87rem;
      color: rgba(255, 255, 255, .9);
    }

    .feature i {
      width: 32px;
      height: 32px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      background: rgba(255, 255, 255, .12);
      border: 1px solid rgba(255, 255, 255, .18);
      border-radius: 9px;
      font-size: .95rem;
    }

    /* RIGHT: form panel */
    .login-right {
      padding: 3rem 2.75rem;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    .form-head {
      margin-bottom: 1.75rem;
    }

    .form-head h2 {
      margin: 0 0 .35rem;
      font-size: 1.6rem;
      font-weight: 800;
      color: var(--ink);
      letter-spacing: -0.01em;
    }

    .form-head p {
      margin: 0;
      color: var(--muted);
      font-size: .9rem;
    }

    .tabs {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: .35rem;
      padding: .35rem;
      background: var(--cream);
      border: 1px solid var(--border);
      border-radius: 12px;
      margin-bottom: 1.5rem;
    }

    .tab-btn {
      background: transparent;
      border: none;
      padding: .65rem .8rem;
      color: var(--muted);
      font-weight: 600;
      font-size: .87rem;
      cursor: pointer;
      border-radius: 9px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: .45rem;
      transition: all .2s ease;
      font-family: inherit;
    }

    .tab-btn:hover {
      color: var(--brand);
    }

    .tab-btn.active {
      background: #fff;
      color: var(--brand);
      box-shadow: 0 2px 8px rgba(74, 42, 24, .12);
    }

    .field {
      margin-bottom: 1rem;
    }

    .f-lbl {
      font-size: .78rem;
      font-weight: 600;
      color: var(--ink);
      margin-bottom: .4rem;
      display: block;
      letter-spacing: .01em;
    }

    .input-wrap {
      position: relative;
    }

    .input-wrap>i {
      position: absolute;
      left: .9rem;
      top: 50%;
      transform: translateY(-50%);
      color: var(--muted);
      font-size: 1rem;
      pointer-events: none;
    }

    .f-inp {
      border: 1.5px solid var(--border);
      background: #fff;
      border-radius: 11px;
      padding: .75rem 1rem .75rem 2.5rem;
      font-size: .92rem;
      width: 100%;
      transition: all .15s ease;
      font-family: inherit;
      color: var(--ink);
    }

    .f-inp::placeholder {
      color: #b9a899;
    }

    .f-inp:focus {
      border-color: var(--brand);
      outline: none;
      box-shadow: 0 0 0 4px rgba(110, 65, 42, .12);
    }

    .toggle-pw {
      position: absolute;
      right: .6rem;
      top: 50%;
      transform: translateY(-50%);
      background: none;
      border: none;
      color: var(--muted);
      cursor: pointer;
      padding: .35rem .5rem;
      border-radius: 7px;
      font-size: 1rem;
    }

    .toggle-pw:hover {
      color: var(--brand);
      background: var(--cream);
    }

    .btn-login {
      background: linear-gradient(135deg, var(--brand), var(--brand-dark));
      color: #fff;
      border: none;
      border-radius: 11px;
      padding: .85rem 1rem;
      font-size: .95rem;
      font-weight: 700;
      width: 100%;
      cursor: pointer;
      transition: transform .12s ease, box-shadow .2s ease, filter .2s ease;
      margin-top: .5rem;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: .5rem;
      box-shadow: 0 8px 20px -6px rgba(110, 65, 42, .5);
      font-family: inherit;
    }

    .btn-login:hover {
      filter: brightness(1.05);
      box-shadow: 0 12px 24px -8px rgba(110, 65, 42, .55);
    }

    .btn-login:active {
      transform: translateY(1px);
    }

    .err {
      background: #fdecec;
      border: 1px solid #f5c2c2;
      border-radius: 11px;
      padding: .7rem .9rem;
      font-size: .85rem;
      color: #9b1c1c;
      margin-bottom: 1rem;
      display: flex;
      align-items: center;
      gap: .5rem;
    }

    .tab-content {
      display: none;
      animation: fade .25s ease;
    }

    .tab-content.active {
      display: block;
    }

    @keyframes fade {
      from {
        opacity: 0;
        transform: translateY(4px);
      }

      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .foot {
      margin-top: 1.5rem;
      text-align: center;
      font-size: .8rem;
      color: var(--muted);
    }

    @media (max-width: 860px) {
      .login-wrap {
        grid-template-columns: 1fr;
        max-width: 460px;
      }

      .login-left {
        padding: 2rem;
        min-height: auto;
      }

      .hero-title {
        font-size: 1.8rem;
      }

      .features {
        display: none;
      }

      .login-right {
        padding: 2rem;
      }
    }
  </style>
</head>

<body>
  <main class="login-wrap" role="main">
    <aside class="login-left">
      <div class="brand-row">
        <img src="assets/img/TeresianLOGO.jpg" alt="CSTA Logo" class="brand-logo">
        <div class="brand-name">CSTA Library</div>
      </div>

      <div class="hero">
        <span class="hero-eyebrow"><i class="bi bi-stars"></i> Library &amp; Supplies</span>
        <h1 class="hero-title">Welcome back to your library workspace.</h1>
        <p class="hero-desc">Manage inventory, track loans, and let users borrow on their own terms all from one calm,
          organized place.</p>

        <div class="features">
          <div class="feature"><i class="bi bi-box-seam"></i> Smart inventory tracking</div>
          <div class="feature"><i class="bi bi-arrow-left-right"></i> Effortless loan management</div>
          <div class="feature"><i class="bi bi-shield-check"></i> Secure self-service borrowing</div>
        </div>
      </div>

      <div style="position:relative;z-index:1;font-size:.78rem;color:rgba(255,255,255,.65);">
        © <?= date('Y') ?> CSTA. All rights reserved.
      </div>
    </aside>

    <section class="login-right">
      <div class="form-head">
        <h2>Sign in</h2>
        <p>Choose your account type to continue.</p>
      </div>

      <div class="tabs" role="tablist">
        <button type="button" class="tab-btn <?= $loginAs === 'admin' ? 'active' : '' ?>"
          onclick="switchTab(event,'admin')">
          <i class="bi bi-shield-lock"></i> Admin
        </button>
        <button type="button" class="tab-btn <?= $loginAs === 'borrower' ? 'active' : '' ?>"
          onclick="switchTab(event,'borrower')">
          <i class="bi bi-book"></i> Borrower
        </button>
      </div>

      <div id="admin-tab" class="tab-content <?= $loginAs === 'admin' ? 'active' : '' ?>">
        <?php if ($error && $loginAs === 'admin'): ?>
          <div class="err"><i class="bi bi-exclamation-circle"></i><?= esc($error) ?></div>
        <?php endif; ?>
        <form method="POST" autocomplete="on">
          <input type="hidden" name="type" value="admin">
          <div class="field">
            <label class="f-lbl" for="admin-user">Username</label>
            <div class="input-wrap">
              <i class="bi bi-person"></i>
              <input id="admin-user" class="f-inp" type="text" name="username" placeholder="Enter your username"
                required>
            </div>
          </div>
          <div class="field">
            <label class="f-lbl" for="admin-pass">Password</label>
            <div class="input-wrap">
              <i class="bi bi-lock"></i>
              <input id="admin-pass" class="f-inp" type="password" name="password" placeholder="Enter your password"
                required>
              <button type="button" class="toggle-pw" onclick="togglePw('admin-pass', this)" aria-label="Show password">
                <i class="bi bi-eye"></i>
              </button>
            </div>
          </div>
          <button type="submit" class="btn-login">
            <i class="bi bi-box-arrow-in-right"></i> Login as Admin
          </button>
        </form>
      </div>

      <div id="borrower-tab" class="tab-content <?= $loginAs === 'borrower' ? 'active' : '' ?>">
        <?php if ($error && $loginAs === 'borrower'): ?>
          <div class="err"><i class="bi bi-exclamation-circle"></i><?= esc($error) ?></div>
        <?php endif; ?>
        <form method="POST" autocomplete="on">
          <input type="hidden" name="type" value="borrower">
          <div class="field">
            <label class="f-lbl" for="b-user">Borrower ID</label>
            <div class="input-wrap">
              <i class="bi bi-person-badge"></i>
              <input id="b-user" class="f-inp" type="text" name="username" placeholder="Enter your borrower ID"
                required>
            </div>
          </div>
          <div class="field">
            <label class="f-lbl" for="b-pass">PIN</label>
            <div class="input-wrap">
              <i class="bi bi-key"></i>
              <input id="b-pass" class="f-inp" type="password" name="password" placeholder="Enter your PIN" required>
              <button type="button" class="toggle-pw" onclick="togglePw('b-pass', this)" aria-label="Show PIN">
                <i class="bi bi-eye"></i>
              </button>
            </div>
          </div>
          <button type="submit" class="btn-login">
            <i class="bi bi-box-arrow-in-right"></i> Login as Borrower
          </button>
        </form>
      </div>

      <div class="foot">Need help? Contact the library administrator.</div>
    </section>
  </main>

  <script>
    function switchTab(e, tab) {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      e.currentTarget.classList.add('active');
      document.getElementById(tab + '-tab').classList.add('active');
    }
    function togglePw(id, btn) {
      const el = document.getElementById(id);
      const icon = btn.querySelector('i');
      if (el.type === 'password') { el.type = 'text'; icon.className = 'bi bi-eye-slash'; }
      else { el.type = 'password'; icon.className = 'bi bi-eye'; }
    }
  </script>
</body>

</html>