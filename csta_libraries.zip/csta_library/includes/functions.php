<?php
require_once __DIR__ . '/db.php';

function logActivity(int $userId = null, string $action, string $module, string $details = ''): void{
    global $pdo;
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $stmt = $pdo->prepare("INSERT INTO activity_log (user_id, action, module, details, ip_address) VALUES (?,?,?,?,?)");
    $stmt->execute([$userId, $action, $module, $details, $ip]);
}

function generateCode(string $prefix, string $table, string $col): string{
    global $pdo;
    $stmt = $pdo->query("SELECT COUNT(*) FROM $table");
    $count = (int) $stmt->fetchColumn() + 1;
    return $prefix . '-' . str_pad($count, 3, '0', STR_PAD_LEFT);
}

function getPenalty(string $dueDate): float{
    $due = new DateTime($dueDate);
    $now = new DateTime();
    if ($now <= $due)
        return 0.0;
    $days = (int) $now->diff($due)->days;
    return $days * 5.00;
}

function statusBadge(string $status): string{
    $map = [
        'active' => ['bg' => '#e8f5e9', 'color' => '#2e7d32', 'border' => '#a5d6a7', 'label' => 'Active'],
        'returned' => ['bg' => '#e3f2fd', 'color' => '#1565c0', 'border' => '#90caf9', 'label' => 'Returned'],
        'overdue' => ['bg' => '#fce4ec', 'color' => '#b71c1c', 'border' => '#ef9a9a', 'label' => 'Overdue'],
        'lost' => ['bg' => '#f3e5f5', 'color' => '#6a1b9a', 'border' => '#ce93d8', 'label' => 'Lost'],
        'In Stock' => ['bg' => '#e8f5e9', 'color' => '#2e7d32', 'border' => '#a5d6a7', 'label' => 'In Stock'],
        'Low Stock' => ['bg' => '#fff3e0', 'color' => '#e65100', 'border' => '#ffcc80', 'label' => 'Low Stock'],
        'Out of Stock' => ['bg' => '#fce4ec', 'color' => '#b71c1c', 'border' => '#ef9a9a', 'label' => 'Out of Stock'],
        'Available' => ['bg' => '#e8f5e9', 'color' => '#2e7d32', 'border' => '#a5d6a7', 'label' => 'Available'],
        'All Borrowed' => ['bg' => '#fce4ec', 'color' => '#b71c1c', 'border' => '#ef9a9a', 'label' => 'All Borrowed'],
    ];
    $d = $map[$status] ?? ['bg' => '#f5f5f5', 'color' => '#616161', 'border' => '#e0e0e0', 'label' => ucfirst($status)];
    return "<span style='background:{$d['bg']};color:{$d['color']};border:1px solid {$d['border']};padding:.2rem .65rem;border-radius:999px;font-size:.76rem;font-weight:700;'>{$d['label']}</span>";
}

function getBookStatus(int $available, int $quantity): string{
    if ($available <= 0)
        return 'All Borrowed';
    return 'Available';
}

function getSupplyStatus(int $qty, int $reorder): string{
    if ($qty <= 0)
        return 'Out of Stock';
    if ($qty <= $reorder)
        return 'Low Stock';
    return 'In Stock';
}

function esc($v): string {
    if ($v === null || $v === '') {
        return '—';
    }
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}
