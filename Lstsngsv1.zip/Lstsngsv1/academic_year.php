<?php
require_once 'includes/auth.php';
requireAdmin();
require_once 'api/shared/db_connect.php';

$activeYearLabel = '';

try {
    $stmtActive = $pdo->query("SELECT year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
    $activeYearLabel = $stmtActive ? (string) $stmtActive->fetchColumn() : '';
} catch (Throwable $e) {
    $activeYearLabel = '';
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Academic Years</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">

    <style>
        body {
            background: #f3f7fd;
        }

        .ay-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }

        .ay-page-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 0.2rem;
            letter-spacing: 0.01em;
        }

        .ay-page-header p {
            margin: 0;
            font-size: 0.88rem;
            opacity: 0.85;
        }

        .ay-active-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            background: rgba(255, 255, 255, 0.15);
            border: 1.5px solid rgba(255, 255, 255, 0.3);
            border-radius: 999px;
            padding: 0.45rem 1rem;
            font-size: 0.88rem;
            font-weight: 700;
            color: #fff;
            white-space: nowrap;
        }

        .ay-active-chip i {
            font-size: 0.9rem;
            opacity: 0.9;
        }

        .ay-card {
            background: #fff;
            border: 1px solid #dce8f8;
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18, 72, 168, 0.06);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }

        .ay-card-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid #e8f0fb;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
            background: #fff;
        }

        .ay-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: #132f62;
            margin: 0 0 0.15rem;
        }

        .ay-card-subtitle {
            font-size: 0.8rem;
            color: #7a93b8;
            margin: 0;
        }

        .ay-card-body {
            padding: 0;
        }

        .ay-card-footer {
            padding: 0.75rem 1.2rem;
            border-top: 1px solid #e8f0fb;
            background: #fafcff;
        }

        .ay-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
        }

        .ay-table thead th {
            background: #f4f8ff;
            color: #3b5e96;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 0.85rem 1.2rem;
            border-bottom: 1.5px solid #dce8f8;
            white-space: nowrap;
        }

        .ay-table tbody tr {
            transition: background 0.12s;
        }

        .ay-table tbody tr:not(:last-child) td {
            border-bottom: 1px solid #f0f5fc;
        }

        .ay-table tbody tr:hover td {
            background: #f7fbff;
        }

        .ay-table tbody td {
            padding: 0.9rem 1.2rem;
            font-size: 0.93rem;
            color: #213a5e;
            vertical-align: middle;
        }

        .ay-table tbody td .row-num {
            color: #a0b4cc;
            font-size: 0.82rem;
            font-weight: 600;
        }

        .ay-table tbody td .year-label {
            font-weight: 700;
            color: #132f62;
        }

        .ay-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.32rem 0.75rem;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }

        .ay-badge-active {
            background: #e6f0ff;
            color: #1248a8;
            border: 1.5px solid #b8d0fa;
        }

        .ay-badge-inactive {
            background: #f3f5f8;
            color: #7a8ea8;
            border: 1.5px solid #dde4ee;
        }

        .btn-ay {
            font-weight: 600;
            font-size: 0.82rem;
            border-radius: 8px;
            padding: 0.42rem 0.9rem;
            cursor: pointer;
            transition: background 0.15s, border-color 0.15s, color 0.15s, box-shadow 0.15s;
            border: 1.5px solid transparent;
            line-height: 1.4;
        }

        .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            border-color: transparent;
            box-shadow: 0 2px 8px rgba(26, 110, 245, 0.2);
        }

        .btn-ay-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
            box-shadow: 0 3px 12px rgba(26, 110, 245, 0.3);
        }

        .btn-ay-activate {
            background: #1a6ef5;
            color: #fff;
            border-color: #1a6ef5;
        }

        .btn-ay-activate:hover {
            background: #1560d8;
            border-color: #1560d8;
            color: #fff;
        }

        .btn-ay-deactivate {
            background: #fff;
            color: #1248a8;
            border-color: #b8d0fa;
        }

        .btn-ay-deactivate:hover {
            background: #eef4ff;
            border-color: #8db5f7;
            color: #0f3d90;
        }

        .ay-pagination {
            display: flex;
            gap: 0.3rem;
            list-style: none;
            margin: 0;
            padding: 0;
            justify-content: flex-end;
        }

        .ay-pagination .ay-page-item .ay-page-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
            border-radius: 7px;
            font-size: 0.83rem;
            font-weight: 600;
            cursor: pointer;
            border: 1.5px solid #dce8f8;
            color: #1a6ef5;
            background: #fff;
            transition: all 0.13s;
            padding: 0 0.5rem;
        }

        .ay-pagination .ay-page-item .ay-page-link:hover {
            background: #eef4ff;
            border-color: #9cc2fc;
        }

        .ay-pagination .ay-page-item.active .ay-page-link {
            background: #1a6ef5;
            border-color: #1a6ef5;
            color: #fff;
        }

        .ay-empty {
            text-align: center;
            padding: 2.5rem 1.5rem;
            color: #9ab0c8;
        }

        .ay-empty i {
            font-size: 2.2rem;
            display: block;
            margin-bottom: 0.6rem;
            opacity: 0.5;
        }

        .ay-empty p {
            margin: 0;
            font-size: 0.95rem;
        }

        .ay-modal .modal-content {
            border: 0;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(18, 72, 168, 0.16);
        }

        .ay-modal .modal-header {
            background: #f4f8ff;
            border-bottom: 1px solid #dce8f8;
            border-radius: 16px 16px 0 0;
            padding: 1rem 1.3rem;
        }

        .ay-modal .modal-title {
            font-size: 1rem;
            font-weight: 700;
            color: #132f62;
        }

        .ay-modal .modal-body {
            padding: 1.3rem;
        }

        .ay-modal .modal-footer {
            border-top: 1px solid #e8f0fb;
            padding: 0.9rem 1.3rem;
            background: #fafcff;
            border-radius: 0 0 16px 16px;
        }

        .ay-modal .form-label {
            font-size: 0.85rem;
            font-weight: 700;
            color: #3b5e96;
            margin-bottom: 0.4rem;
        }

        .ay-modal .form-select {
            border-radius: 10px;
            border: 1.5px solid #c8daf8;
            min-height: 42px;
            font-size: 0.9rem;
            color: #213a5e;
            padding: 0.45rem 0.85rem;
        }

        .ay-modal .form-select:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.12);
        }

        .ay-modal .form-text {
            font-size: 0.8rem;
            color: #8fa8c8;
            margin-top: 0.45rem;
        }

        .ay-mobile-card {
            background: #fff;
            border: 1.5px solid #dce8f8;
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 1px 6px rgba(18, 72, 168, 0.05);
        }

        .ay-mobile-card + .ay-mobile-card {
            margin-top: 0.75rem;
        }

        .ay-mobile-card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.85rem 1rem;
            border-bottom: 1px solid #edf3fc;
            background: #f9fbff;
        }

        .ay-mobile-card-title {
            font-weight: 700;
            color: #132f62;
            font-size: 0.95rem;
        }

        .ay-mobile-card-body {
            padding: 0.85rem 1rem;
        }

        @media (max-width: 767.98px) {
            .ay-page-header {
                padding: 1.1rem 1.2rem;
                border-radius: 14px;
            }
        }
    </style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <div class="app-wrapper">
        <?php require_once("includes/header.php"); ?>
        <?php require_once("includes/sidebar.php"); ?>

        <main class="app-main">
            <div class="app-content">
                <div class="container-fluid py-3">

                    <div class="ay-page-header">
                        <div>
                            <h3><i class="bi bi-calendar-range me-2"></i>Academic Year Management</h3>
                            <p>Manage and Set Active Academic Year</p>
                        </div>
                        <div class="ay-active-chip">
                            <i class="bi bi-calendar2-check-fill"></i>
                            Active:&nbsp;<span id="activeYearText"><?= htmlspecialchars($activeYearLabel ?: 'None', ENT_QUOTES, 'UTF-8') ?></span>
                        </div>
                    </div>

                    <div class="ay-card">
                        <div class="ay-card-header">
                            <div>
                                <p class="ay-card-title">Academic Year List</p>
                                <p class="ay-card-subtitle">Only one academic year should remain active at a time.</p>
                            </div>
                            <button class="btn btn-ay btn-ay-primary" data-bs-toggle="modal" data-bs-target="#yearModal">
                                <i class="bi bi-plus-circle me-1"></i> New Academic Year
                            </button>
                        </div>

                        <div class="ay-card-body">
                            <div class="d-none d-md-block">
                                <table class="ay-table" id="yearTable">
                                    <thead>
                                        <tr>
                                            <th style="width:64px; text-align:center;">#</th>
                                            <th>Academic Year</th>
                                            <th style="width:130px; text-align:center;">Status</th>
                                            <th style="width:180px; text-align:center;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="tableBody">
                                        <tr>
                                            <td colspan="4">
                                                <div class="ay-empty">
                                                    <i class="bi bi-hourglass-split"></i>
                                                    <p>Loading academic years...</p>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <div class="d-block d-md-none p-3" id="cardView"></div>
                        </div>

                        <div class="ay-card-footer">
                            <ul class="ay-pagination" id="pagination"></ul>
                        </div>
                    </div>

                </div>
            </div>
        </main>

        <?php require_once("includes/footer.php"); ?>
    </div>

    <div class="modal fade ay-modal" id="yearModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form id="yearForm">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalTitle"><i class="bi bi-calendar-plus me-2"></i>Add Academic Year</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <div class="modal-body">
                        <input type="hidden" id="yearId">

                        <div class="mb-2">
                            <label class="form-label">School Year <span class="text-danger">*</span></label>
                            <select class="form-select" id="yearLabel" required>
                                <option value="">— Select academic year —</option>
                                <?php for ($y = 2020; $y <= 2035; $y++): ?>
                                    <option value="<?= $y ?>-<?= $y + 1 ?>"><?= $y ?>-<?= $y + 1 ?></option>
                                <?php endfor; ?>
                            </select>
                            <div class="form-text">New years are inactive by default. Activate them when needed.</div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-ay" style="border:1.5px solid #dce8f8; background:#fff; color:#5a7299;" data-bs-dismiss="modal">
                            Cancel
                        </button>
                        <button type="submit" class="btn btn-ay btn-ay-primary">
                            <i class="bi bi-check-circle me-1"></i> Save Academic Year
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./js/adminlte.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>

    <script>
        let currentPage = 1;

        function showAlert(message, type = 'success') {
            const config = {
                success: {
                    title: 'Success',
                    color: 'blue',
                    icon: 'bi bi-check-circle-fill'
                },
                danger: {
                    title: 'Error',
                    color: 'red',
                    icon: 'bi bi-exclamation-octagon-fill'
                },
                warning: {
                    title: 'Warning',
                    color: 'yellow',
                    icon: 'bi bi-exclamation-triangle-fill'
                },
                info: {
                    title: 'Info',
                    color: 'blue',
                    icon: 'bi bi-info-circle-fill'
                }
            };

            const selected = config[type] || config.success;

            iziToast.show({
                title: selected.title,
                message: message,
                color: selected.color,
                icon: selected.icon,
                iconColor: '#fff',
                theme: 'light',
                position: 'topRight',
                timeout: 4000,
                progressBar: true,
                close: true,
                pauseOnHover: true,
                drag: true,
                transitionIn: 'fadeInDown',
                transitionOut: 'fadeOutUp',
                maxWidth: 420
            });
        }

        function updateAcademicYearDisplays(activeYear = '') {
            const headerText = document.getElementById('activeYearText');
            const footerBadge = document.getElementById('footerAcademicYear');
            const hasYear = activeYear && activeYear.trim() !== '';

            if (headerText) {
                headerText.textContent = hasYear ? activeYear : 'None';
            }

            if (footerBadge) {
                if (hasYear) {
                    footerBadge.classList.remove('no-year');
                    footerBadge.innerHTML = `
                        <i class="bi bi-calendar2-check-fill"></i>
                        S.Y. ${activeYear}
                    `;
                } else {
                    footerBadge.classList.add('no-year');
                    footerBadge.innerHTML = `
                        <i class="bi bi-calendar2-x"></i>
                        No Active Year
                    `;
                }
            }
        }

        async function fetchJson(url, options = {}) {
            const response = await fetch(url, options);
            const raw = await response.text();

            try {
                return JSON.parse(raw);
            } catch (e) {
                console.error('Non-JSON response:', raw);
                throw new Error('Server returned an invalid response.');
            }
        }

        async function loadYears(page = 1) {
            currentPage = page;
            try {
                const data = await fetchJson(`api/academic-year/read.php?p=${page}`);
                render(data.years || [], data.page || 1, data.pages || 1, data.active_year || '');
            } catch (error) {
                showAlert(error.message, 'danger');
            }
        }

        function render(list, page, pages, activeYear = '') {
            const tableBody = document.getElementById('tableBody');
            const cardView = document.getElementById('cardView');

            updateAcademicYearDisplays(activeYear);

            if (!list.length) {
                const emptyHtml = `<div class="ay-empty"><i class="bi bi-calendar-x"></i><p>No academic years found.</p></div>`;
                tableBody.innerHTML = `<tr><td colspan="4">${emptyHtml}</td></tr>`;
                cardView.innerHTML = emptyHtml;
                document.getElementById('pagination').innerHTML = '';
                return;
            }

            const offset = (page - 1) * 10;

            tableBody.innerHTML = list.map((y, i) => {
                const isActive = Number(y.is_active) === 1;
                const badge = isActive
                    ? `<span class="ay-badge ay-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                    : `<span class="ay-badge ay-badge-inactive">Inactive</span>`;
                const action = isActive
                    ? `<button class="btn btn-ay btn-ay-deactivate" onclick="toggleYear(${y.id}, 0)">Deactivate</button>`
                    : `<button class="btn btn-ay btn-ay-activate" onclick="toggleYear(${y.id}, 1)">Activate</button>`;

                return `<tr>
                    <td style="text-align:center;"><span class="row-num">${offset + i + 1}</span></td>
                    <td><span class="year-label">${y.year_label}</span></td>
                    <td style="text-align:center;">${badge}</td>
                    <td style="text-align:center;">${action}</td>
                </tr>`;
            }).join('');

            cardView.innerHTML = list.map((y, i) => {
                const isActive = Number(y.is_active) === 1;
                const badge = isActive
                    ? `<span class="ay-badge ay-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                    : `<span class="ay-badge ay-badge-inactive">Inactive</span>`;
                const action = isActive
                    ? `<button class="btn btn-ay btn-ay-deactivate w-100" onclick="toggleYear(${y.id}, 0)">Deactivate</button>`
                    : `<button class="btn btn-ay btn-ay-activate w-100" onclick="toggleYear(${y.id}, 1)">Activate</button>`;

                return `<div class="ay-mobile-card">
                    <div class="ay-mobile-card-header">
                        <span class="ay-mobile-card-title">${offset + i + 1}. &nbsp;${y.year_label}</span>
                        ${badge}
                    </div>
                    <div class="ay-mobile-card-body">${action}</div>
                </div>`;
            }).join('');

            document.getElementById('pagination').innerHTML = Array.from({ length: pages }, (_, idx) => {
                const n = idx + 1;
                return `<li class="ay-page-item ${n === page ? 'active' : ''}">
                    <a class="ay-page-link" onclick="loadYears(${n})">${n}</a>
                </li>`;
            }).join('');
        }

        document.getElementById('yearForm').addEventListener('submit', async function (e) {
            e.preventDefault();

            const payload = {
                id: document.getElementById('yearId').value || null,
                year_label: document.getElementById('yearLabel').value.trim()
            };

            try {
                const res = await fetchJson('api/academic-year/save.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });

                if (res.success) {
                    bootstrap.Modal.getInstance(document.getElementById('yearModal')).hide();
                    this.reset();
                    showAlert(res.message || 'Academic year saved successfully.', 'success');
                    loadYears(currentPage);
                } else {
                    showAlert(res.error || res.message || 'Save failed.', 'danger');
                }
            } catch (error) {
                showAlert(error.message, 'danger');
            }
        });

        function toggleYear(id, newState) {
            const action = newState ? 'activate' : 'deactivate';

            iziToast.question({
                timeout: 20000,
                close: false,
                overlay: true,
                displayMode: 'once',
                id: 'academic-year-confirm',
                zindex: 9999,
                title: 'Confirm',
                message: `Are you sure you want to ${action} this academic year?`,
                position: 'center',
                color: 'blue',
                icon: 'bi bi-question-circle-fill',
                buttons: [
                    [
                        '<button><b>Yes</b></button>',
                        async function (instance, toast) {
                            instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');

                            try {
                                const res = await fetchJson('api/academic-year/toggle.php', {
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify({ id, is_active: newState })
                                });

                                if (res.success) {
                                    showAlert(res.message || `Academic year ${action}d successfully.`, 'success');
                                    loadYears(currentPage);
                                } else {
                                    showAlert(res.error || res.message || 'Toggle failed.', 'danger');
                                }
                            } catch (error) {
                                showAlert(error.message, 'danger');
                            }
                        },
                        true
                    ],
                    [
                        '<button>No</button>',
                        function (instance, toast) {
                            instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');
                            showAlert(`Academic year ${action} cancelled.`, 'info');
                        }
                    ]
                ]
            });
        }

        document.getElementById('yearModal').addEventListener('hidden.bs.modal', () => {
            document.getElementById('yearForm').reset();
            document.getElementById('yearId').value = '';
            document.getElementById('modalTitle').textContent = 'Add Academic Year';
        });

        loadYears();
    </script>
</body>

</html>