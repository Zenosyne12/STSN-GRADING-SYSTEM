/*
SQLyog Ultimate v8.55 
MySQL - 5.5.5-10.4.32-MariaDB : Database - dbstsn
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`dbstsn` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `dbstsn`;

/*Table structure for table `tblacademicyear` */

DROP TABLE IF EXISTS `tblacademicyear`;

CREATE TABLE `tblacademicyear` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year_label` varchar(9) NOT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `year_label` (`year_label`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tblacademicyear` */

insert  into `tblacademicyear`(`id`,`year_label`,`is_active`,`created_at`) values (1,'2025-2026',1,'2025-11-17 21:40:48');

/*Table structure for table `tblbarangay` */

DROP TABLE IF EXISTS `tblbarangay`;

CREATE TABLE `tblbarangay` (
  `id` int(11) NOT NULL,
  `barangay_name` varchar(100) NOT NULL,
  `city_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_barangay_city` (`city_id`),
  CONSTRAINT `fk_barangay_city` FOREIGN KEY (`city_id`) REFERENCES `tblcity` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tblbarangay` */

insert  into `tblbarangay`(`id`,`barangay_name`,`city_id`) values (1,'Barangay 1',1),(2,'Barangay 2',2),(3,'Barangay 3',3),(4,'Barangay 4',4),(5,'Barangay 5',5);

/*Table structure for table `tblcity` */

DROP TABLE IF EXISTS `tblcity`;

CREATE TABLE `tblcity` (
  `id` int(11) NOT NULL,
  `city_name` varchar(100) NOT NULL,
  `province_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_city_province` (`province_id`),
  CONSTRAINT `fk_city_province` FOREIGN KEY (`province_id`) REFERENCES `tblprovince` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tblcity` */

insert  into `tblcity`(`id`,`city_name`,`province_id`) values (1,'Manila',1),(2,'Quezon City',1),(3,'Makati',1),(4,'Dasmariñas',2),(5,'Santa Rosa',3);

/*Table structure for table `tblcountry` */

DROP TABLE IF EXISTS `tblcountry`;

CREATE TABLE `tblcountry` (
  `id` int(11) NOT NULL,
  `country_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tblcountry` */

insert  into `tblcountry`(`id`,`country_name`) values (1,'Philippines');

/*Table structure for table `tblgradelevel` */

DROP TABLE IF EXISTS `tblgradelevel`;

CREATE TABLE `tblgradelevel` (
  `id` int(11) NOT NULL,
  `grade_level_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tblgradelevel` */

insert  into `tblgradelevel`(`id`,`grade_level_name`) values (1,'Kindergarten'),(2,'Grade 1'),(3,'Grade 2'),(4,'Grade 3'),(5,'Grade 4'),(6,'Grade 5'),(7,'Grade 6'),(8,'Grade 7'),(9,'Grade 8'),(10,'Grade 9'),(11,'Grade 10'),(12,'Grade 11'),(13,'Grade 12');

/*Table structure for table `tblprovince` */

DROP TABLE IF EXISTS `tblprovince`;

CREATE TABLE `tblprovince` (
  `id` int(11) NOT NULL,
  `province_name` varchar(100) NOT NULL,
  `region_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_province_region` (`region_id`),
  CONSTRAINT `fk_province_region` FOREIGN KEY (`region_id`) REFERENCES `tblregion` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tblprovince` */

insert  into `tblprovince`(`id`,`province_name`,`region_id`) values (1,'Metro Manila',1),(2,'Cavite',2),(3,'Laguna',2);

/*Table structure for table `tblregion` */

DROP TABLE IF EXISTS `tblregion`;

CREATE TABLE `tblregion` (
  `id` int(11) NOT NULL,
  `region_name` varchar(100) NOT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_region_country` (`country_id`),
  CONSTRAINT `fk_region_country` FOREIGN KEY (`country_id`) REFERENCES `tblcountry` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tblregion` */

insert  into `tblregion`(`id`,`region_name`,`country_id`) values (1,'National Capital Region (NCR)',1),(2,'Calabarzon (IV-A)',1);

/*Table structure for table `tblrole` */

DROP TABLE IF EXISTS `tblrole`;

CREATE TABLE `tblrole` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_name` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tblrole` */

insert  into `tblrole`(`id`,`role_name`) values (1,'Admin'),(2,'Teacher');

/*Table structure for table `tblschedule` */

DROP TABLE IF EXISTS `tblschedule`;

CREATE TABLE `tblschedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `day_name` varchar(20) NOT NULL,
  `time_start` time NOT NULL,
  `time_end` time NOT NULL,
  `room` varchar(100) DEFAULT NULL,
  `semester` varchar(50) DEFAULT '1st Semester',
  `school_year` varchar(50) DEFAULT '2025-2026',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_schedule_section` (`section_id`),
  KEY `fk_schedule_subject` (`subject_id`),
  KEY `fk_schedule_teacher` (`teacher_id`),
  CONSTRAINT `fk_schedule_section` FOREIGN KEY (`section_id`) REFERENCES `tblsection` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_schedule_subject` FOREIGN KEY (`subject_id`) REFERENCES `tblsubjects` (`id`),
  CONSTRAINT `fk_schedule_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `tblteacher` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tblschedule` */

insert  into `tblschedule`(`id`,`section_id`,`subject_id`,`teacher_id`,`day_name`,`time_start`,`time_end`,`room`,`semester`,`school_year`,`is_active`,`created_at`,`updated_at`) values (1,24,16,12,'Tue','09:25:00','10:28:00','','1st Quarter','2025-2026',1,'2026-03-12 22:25:17','2026-03-12 22:25:17'),(2,22,16,13,'Mon','12:32:00','13:33:00','sdasda','quarter','2025-2026',1,'2026-03-12 22:31:21','2026-03-12 22:31:21');

/*Table structure for table `tblsection` */

DROP TABLE IF EXISTS `tblsection`;

CREATE TABLE `tblsection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `grade_level_id` int(11) DEFAULT NULL,
  `section_code` varchar(30) NOT NULL,
  `section_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_code` (`section_code`),
  KEY `fk_tblsection_grade_level` (`grade_level_id`),
  CONSTRAINT `fk_tblsection_grade_level` FOREIGN KEY (`grade_level_id`) REFERENCES `tblgradelevel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tblsection` */

insert  into `tblsection`(`id`,`grade_level_id`,`section_code`,`section_name`,`description`,`is_active`,`created_at`,`updated_at`) values (15,NULL,'SEC-01','Ruby','Junior-high first-section track',1,'2025-11-22 22:36:10','2026-01-30 01:07:12'),(16,NULL,'SEC-02','Sapphire','Junior-high second-section track',1,'2025-11-22 22:36:10','2026-01-30 01:07:07'),(17,NULL,'SEC-03','Emerald','Junior-high third-section track',1,'2025-11-22 22:36:10','2026-01-30 01:07:03'),(18,NULL,'SEC-04','Diamond','Junior-high fourth-section track',1,'2025-11-22 22:36:10','2026-01-30 01:06:57'),(19,NULL,'SEC-05','Gold','Junior-high fifth-section track',1,'2025-11-22 22:36:10','2026-01-30 01:06:46'),(20,NULL,'SEC-06','Silver','Junior-high sixth-section track',1,'2025-11-22 22:36:10','2026-01-30 01:06:51'),(21,NULL,'SEC-07','Pearl','Junior-high seventh-section track',1,'2025-11-22 22:36:10','2026-01-30 01:06:41'),(22,11,'SEC-08','Onyx','Junior-high eighth-section track',1,'2025-11-22 22:36:10','2026-03-12 22:30:00'),(23,6,'SEC-09','Amethyst','Senior-high first-section track',1,'2025-11-22 22:36:10','2026-03-12 18:41:51'),(24,3,'SEC-10','Topaz','Senior-high second-section track',1,'2025-11-22 22:36:10','2026-03-12 18:40:44');

/*Table structure for table `tblsection_adviser` */

DROP TABLE IF EXISTS `tblsection_adviser`;

CREATE TABLE `tblsection_adviser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_section_adviser` (`section_id`),
  KEY `fk_sa_section` (`section_id`),
  KEY `fk_sa_teacher` (`teacher_id`),
  CONSTRAINT `fk_sa_section` FOREIGN KEY (`section_id`) REFERENCES `tblsection` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sa_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `tblteacher` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tblsection_adviser` */

insert  into `tblsection_adviser`(`id`,`section_id`,`teacher_id`,`is_active`,`created_at`) values (1,24,2,1,'2026-03-12 16:35:19'),(2,23,6,1,'2026-03-12 18:03:49'),(3,22,4,1,'2026-03-12 22:29:11');

/*Table structure for table `tblsection_student` */

DROP TABLE IF EXISTS `tblsection_student`;

CREATE TABLE `tblsection_student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_section_student` (`section_id`,`student_id`),
  KEY `fk_ss_section` (`section_id`),
  KEY `fk_ss_student` (`student_id`),
  CONSTRAINT `fk_ss_section` FOREIGN KEY (`section_id`) REFERENCES `tblsection` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ss_student` FOREIGN KEY (`student_id`) REFERENCES `tblstudents` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tblsection_student` */

insert  into `tblsection_student`(`id`,`section_id`,`student_id`,`is_active`,`created_at`) values (1,24,10,1,'2026-03-12 16:48:20'),(2,24,6,1,'2026-03-12 16:48:20'),(4,24,3,1,'2026-03-12 16:48:20'),(6,24,7,1,'2026-03-12 16:49:50'),(8,24,2,1,'2026-03-12 16:49:50'),(11,23,13,1,'2026-03-12 18:04:02'),(12,23,8,1,'2026-03-12 18:04:31'),(13,22,4,1,'2026-03-12 22:29:54'),(14,22,1,1,'2026-03-12 22:29:54'),(15,22,5,1,'2026-03-12 22:29:54'),(16,22,9,1,'2026-03-12 22:29:54');

/*Table structure for table `tblsection_teacher_subject` */

DROP TABLE IF EXISTS `tblsection_teacher_subject`;

CREATE TABLE `tblsection_teacher_subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `weekly_sessions` int(11) DEFAULT 5,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_sts_section` (`section_id`),
  KEY `fk_sts_subject` (`subject_id`),
  KEY `fk_sts_teacher` (`teacher_id`),
  CONSTRAINT `fk_sts_section` FOREIGN KEY (`section_id`) REFERENCES `tblsection` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sts_subject` FOREIGN KEY (`subject_id`) REFERENCES `tblsubjects` (`id`),
  CONSTRAINT `fk_sts_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `tblteacher` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tblsection_teacher_subject` */

insert  into `tblsection_teacher_subject`(`id`,`section_id`,`subject_id`,`teacher_id`,`weekly_sessions`,`is_active`,`created_at`) values (1,24,13,2,5,1,'2026-03-12 16:48:10'),(2,24,16,12,3,1,'2026-03-12 16:49:42'),(3,23,17,2,5,1,'2026-03-12 18:03:55'),(4,22,16,13,5,1,'2026-03-12 22:29:24'),(6,22,8,11,5,1,'2026-03-12 22:29:42');

/*Table structure for table `tblstudents` */

DROP TABLE IF EXISTS `tblstudents`;

CREATE TABLE `tblstudents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lrn` varchar(12) DEFAULT NULL,
  `fname` varchar(100) DEFAULT NULL,
  `mname` varchar(100) DEFAULT NULL,
  `lname` varchar(100) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `citizenship` varchar(50) DEFAULT NULL,
  `grade_level_id` int(11) DEFAULT NULL,
  `fathers_name` varchar(100) DEFAULT NULL,
  `fathers_contact_num` varchar(20) DEFAULT NULL,
  `mothers_name` varchar(100) DEFAULT NULL,
  `mothers_contact_num` varchar(100) DEFAULT NULL,
  `guardian_name` varchar(100) DEFAULT NULL,
  `guardian_contact_num` varchar(20) DEFAULT NULL,
  `street_name` varchar(100) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `barangay_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `province_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lrn` (`lrn`),
  KEY `fk_name_grade` (`grade_level_id`),
  KEY `fk_name_barangay` (`barangay_id`),
  KEY `fk_name_city` (`city_id`),
  KEY `fk_name_region` (`region_id`),
  KEY `fk_name_province` (`province_id`),
  KEY `fk_name_country` (`country_id`),
  CONSTRAINT `fk_name_barangay` FOREIGN KEY (`barangay_id`) REFERENCES `tblbarangay` (`id`),
  CONSTRAINT `fk_name_city` FOREIGN KEY (`city_id`) REFERENCES `tblcity` (`id`),
  CONSTRAINT `fk_name_country` FOREIGN KEY (`country_id`) REFERENCES `tblcountry` (`id`),
  CONSTRAINT `fk_name_grade` FOREIGN KEY (`grade_level_id`) REFERENCES `tblgradelevel` (`id`),
  CONSTRAINT `fk_name_province` FOREIGN KEY (`province_id`) REFERENCES `tblprovince` (`id`),
  CONSTRAINT `fk_name_region` FOREIGN KEY (`region_id`) REFERENCES `tblregion` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tblstudents` */

insert  into `tblstudents`(`id`,`lrn`,`fname`,`mname`,`lname`,`birthdate`,`gender`,`citizenship`,`grade_level_id`,`fathers_name`,`fathers_contact_num`,`mothers_name`,`mothers_contact_num`,`guardian_name`,`guardian_contact_num`,`street_name`,`postal_code`,`barangay_id`,`city_id`,`region_id`,`province_id`,`country_id`,`is_active`) values (1,'010000000001','Andre','Delos','Santo','2001-01-15','Male','Filipino',5,'Pedro Santos','0917-111-1111','Maria Santos','84651','Maria Santos','0917-111-1111','123 Mabini St','1000',1,1,1,1,1,1),(2,'010000000002','Maria','Isabel','Reyes','2011-03-22','Female','Filipino',4,'Jose Reyes','0922-222-2222','Ana Reyes','7461','Ana Reyes','0922-222-2222','456 Quezon Ave','1100',2,2,1,1,1,1),(3,'010000000003','Carlos','Dim','Garcia','2009-07-08','Male','Filipino',6,'Ramon Garcia','0933-333-3333','Clara Garcia','09944','Clara Garcia','0933-333-3333','789 Rizal Blvd','1200',3,3,1,1,1,1),(4,'010000000004','Sophia','Lane','Mendoza','2012-11-30','Female','Filipino',3,'Miguel Mendoza','0944-444-4444','Elena Mendoza','096230','Elena Mendoza','0944-444-4444','321 Luna St','4114',4,4,2,2,1,1),(5,'010000000005','Andrew','Mark','Torres','2008-05-14','Male','Filipino',7,'Robert Torres','0955-555-5555','Liza Torres','098555','Liza Torres','0955-555-5555','654 Del Pilar','4026',5,5,2,3,1,1),(6,'010000000006','Angela','Rose','Cruz','2013-08-20','Female','Filipino',2,'Danilo Cruz','0966-666-6666','Fe Cruz','096555','Fe Cruz','0966-666-6666','987 Bonifacio St','1000',1,1,1,1,1,1),(7,'010000000007','Mark','Paul','Lim','2007-12-03','Male','Filipino',8,'Arthur Lim','0977-777-7777','Grace Lim','08444','Grace Lim','0977-777-7777','147 Taft Ave','1100',2,2,1,1,1,1),(8,'010000000008','Jusipin','Kay','Flores','2014-02-28','Female','Filipino',1,'Ryan Flores','0988-888-8888','Cathy Flores','096666','Cathy Flores','0988-888-8888','258 Shaw Blvd','1200',3,3,1,1,1,1),(9,'010000000009','Bryan','James','Villanueva','2006-09-11','Male','Filipino',9,'Raul Villanueva','0999-999-9999','Nina Villanueva','092222','Nina Villanueva','0999-999-9999','369 Aguinaldo Hwy','4114',4,4,2,2,1,1),(10,'010000000010','Trisha','May','Delos','2015-06-17','Female','Filipino',1,'Leo Delos','0912-121-2121','Mila Delos','093333','Mila Delos','0912-121-2121','753 Bayan St','4026',5,5,2,3,1,1),(13,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `tblsubjects` */

DROP TABLE IF EXISTS `tblsubjects`;

CREATE TABLE `tblsubjects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_code` varchar(20) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `subject_code` (`subject_code`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tblsubjects` */

insert  into `tblsubjects`(`id`,`subject_code`,`subject_name`,`description`,`is_active`,`created_at`) values (8,'MATH101','Algebra I','Fundamental algebraic concepts and operations',1,'2025-11-22 22:42:05'),(9,'ENG101','English Grammar','Basic grammar, syntax, and writing skills',1,'2025-11-22 22:42:05'),(10,'SCI101','General Biology','Introduction to living organisms and life processes',1,'2025-11-22 22:42:05'),(11,'FIL101','Komunikasyon','Pag-aaral ng wikang Filipino at kasanayan sa komunikasyon',1,'2025-11-22 22:42:05'),(12,'PE101','Physical Fitness','Individual and team sports for health and wellness',1,'2025-11-22 22:42:05'),(13,'HIST101','Philippine History','Philippine history from pre-colonial to contemporary times',1,'2025-11-22 22:42:05'),(14,'CHEM101','Basic Chemistry','Elements, compounds, and chemical reactions',1,'2025-11-22 22:42:05'),(15,'PHY101','Physics I','Mechanics, energy, and wave motion',1,'2025-11-22 22:42:05'),(16,'COMP101','Computer Basics','Computer hardware, software, and productivity tools',1,'2025-11-22 22:42:05'),(17,'VALUES','Good Manners & Right Conduct','Values education and character formation',1,'2025-11-22 22:42:05');

/*Table structure for table `tblteacher` */

DROP TABLE IF EXISTS `tblteacher`;

CREATE TABLE `tblteacher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` varchar(30) NOT NULL,
  `email` varchar(255) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `mname` varchar(100) DEFAULT '',
  `lname` varchar(100) NOT NULL,
  `date_hired` date NOT NULL,
  `sex` enum('Male','Female') NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `teacher_id` (`teacher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tblteacher` */

insert  into `tblteacher`(`id`,`teacher_id`,`email`,`fname`,`mname`,`lname`,`date_hired`,`sex`,`contact_no`,`is_active`) values (1,'T00001','maria.clara@example.com','Maria','','Clara','2025-11-27','Female','09123456789',1),(2,'T00002','jose.rizal@example.com','Jose','','Rizal','2025-11-27','Male','09223456789',1),(3,'T00003','andres.boni@example.com','Andres','','Bonifacio','2025-11-27','Male','09333456789',1),(4,'T00004','melchora.aquino@example.com','Melchora','','Aquino','2025-11-27','Female','09443456789',1),(5,'T00005','emilio.aguinaldo@example.com','Emilio','','Aguinaldo','2025-11-27','Male','09553456789',1),(6,'T00006','gabriela.silang@example.com','Gabriela','','Silang','2025-11-27','Female','09663456789',1),(7,'T00007','apol.mabini@example.com','Apolinario','','Mabini','2025-11-27','Male','09773456789',1),(8,'T00008','lapu.datu@example.com','Lapu-Lapu','','Datu','2025-11-27','Male','09883456789',1),(9,'T00009','katherine.li@example.com','Katherine','','Li','2025-11-27','Female','09993456789',1),(10,'T00010','riz.torres@example.com','Rizalino','','Torres','2025-11-27','Male','09004567890',1),(11,'T00023','hechanova919@gmail.com','Justin ','','Hechanova','2025-11-27','Male','9771995088',1),(12,'T00044','sanjose2020@gmail.com','Luke','','San Jose','2025-11-27','Male','09771885768',1),(13,'T00099','CristineGonzales123@gmail.com','Cristines','','Gonzales','2025-11-27','Female','9886758464324',1);

/*Table structure for table `tblteacher_assignment` */

DROP TABLE IF EXISTS `tblteacher_assignment`;

CREATE TABLE `tblteacher_assignment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ay_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `isAdvisory` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `ay_id` (`ay_id`),
  KEY `teacher_id` (`teacher_id`),
  KEY `subject_id` (`subject_id`),
  KEY `section_id` (`section_id`),
  CONSTRAINT `tblteacher_assignment_ibfk_1` FOREIGN KEY (`ay_id`) REFERENCES `tblacademicyear` (`id`),
  CONSTRAINT `tblteacher_assignment_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `tblteacher_old` (`id`),
  CONSTRAINT `tblteacher_assignment_ibfk_3` FOREIGN KEY (`subject_id`) REFERENCES `tblsubjects` (`id`),
  CONSTRAINT `tblteacher_assignment_ibfk_4` FOREIGN KEY (`section_id`) REFERENCES `tblsection` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tblteacher_assignment` */

insert  into `tblteacher_assignment`(`id`,`ay_id`,`teacher_id`,`subject_id`,`section_id`,`isAdvisory`,`is_active`) values (3,1,8,16,20,0,1),(4,1,4,13,16,1,1);

/*Table structure for table `tblteacher_old` */

DROP TABLE IF EXISTS `tblteacher_old`;

CREATE TABLE `tblteacher_old` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` varchar(30) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `date_of_birth` date NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `civil_status` enum('Single','Married','Widowed','Divorced') NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `street_name` varchar(255) NOT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `barangay_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `province_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `fk_teacher_bar` (`barangay_id`),
  KEY `fk_teacher_city` (`city_id`),
  KEY `fk_teacher_prov` (`province_id`),
  KEY `fk_teacher_reg` (`region_id`),
  KEY `fk_teacher_cnt` (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tblteacher_old` */

insert  into `tblteacher_old`(`id`,`teacher_id`,`fname`,`lname`,`date_of_birth`,`gender`,`civil_status`,`contact_number`,`email`,`street_name`,`postal_code`,`barangay_id`,`city_id`,`region_id`,`province_id`,`country_id`,`is_active`) values (4,'T00001','Maria','Clara','1985-03-12','Female','Single','09123456789','maria.clara@example.com','123 Rizal St','4000',NULL,NULL,NULL,NULL,NULL,1),(5,'T00002','Jose','Rizal','1980-06-19','Male','Married','09223456789','jose.rizal@example.com','456 Bonifacio St','4001',NULL,NULL,NULL,NULL,NULL,1),(6,'T00003','Andres','Bonifacio','1979-11-30','Male','Married','09333456789','andres.boni@example.com','789 Del Pilar St','4002',NULL,NULL,NULL,NULL,NULL,1),(7,'T00004','Melchora','Aquino','1990-01-06','Female','Widowed','09443456789','melchora.aquino@example.com','111 Tandang Sora St','4003',NULL,NULL,NULL,NULL,NULL,1),(8,'T00005','Emilio','Aguinaldo','1987-10-14','Male','Married','09553456789','emilio.aguinaldo@example.com','30 Narra st','',1,1,1,1,1,1),(9,'T00006','Gabriela','Silang','1992-03-19','Female','Single','09663456789','gabriela.silang@example.com','333 Ilocos St','4005',NULL,NULL,NULL,NULL,NULL,1),(10,'T00007','Apolinario','Mabini','1987-10-08','Male','Single','09773456789','apol.mabini@example.com','Matrix','',3,3,1,1,1,1),(11,'T00008','Lapu-Lapu','Datu','1965-01-01','Male','Married','09883456789','lapu.datu@example.com','555 Mactan Ave','4007',NULL,NULL,NULL,NULL,NULL,1),(12,'T00009','Katherine','Li','1988-05-15','Female','Single','09993456789','katherine.li@example.com','666 Chinatown St','4008',NULL,NULL,NULL,NULL,NULL,1),(13,'T00010','Rizalino','Torres','1975-10-25','Male','Divorced','09004567890','riz.torres@example.com','777 Taft Ave','4009',NULL,NULL,NULL,NULL,NULL,1),(14,'1123129837891275','Anndre','wawawa','2002-02-20','Male','Married','0977123812318','lovelove25@gmail.com','Waka waka','23232',4,4,2,2,1,0),(15,'T00023','Justin ','Hechanova','2005-02-20','Male','Single','9771995088','hechanova919@gmail.com','Quezon city','1400',1,1,1,1,1,1),(16,'T00044','Luke','San Jose','2006-02-03','Male','Single','09771885768','sanjose2020@gmail.com','Lot 12 Blk12 Phase 7 Quezon City','1399',3,3,1,1,1,1),(17,'T00099','Cristine','Gonzales','2003-03-20','Female','Divorced','9886758464324','CristineGonzales123@gmail.com','Baguio City','1600',4,4,2,2,1,1),(18,'t00014','Luke','san jose','2025-11-05','Male','Married','4978598579568','lukenazaren@gmail.com','ssdgsd','adfgadf',4,4,2,2,1,0),(19,'TCH-2025009','Luke','san jose','2025-11-27','Male','Married','09123456789','lukenazaren@gmail.com','ssdgsd','adfgadf',4,4,2,2,1,0);

/*Table structure for table `tblusers` */

DROP TABLE IF EXISTS `tblusers`;

CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `must_change_password` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_reference` (`reference_id`),
  KEY `idx_role` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `tblusers` */

insert  into `tblusers`(`id`,`username`,`password_hash`,`role_id`,`reference_id`,`status`,`created_at`,`updated_at`,`must_change_password`) values (4,'admin','$2y$10$nw7Ah4oao/TjpSxaV6o8UO/EfPT2r3k/gsIFw2RxMWSgOUXaFCDc.',1,NULL,'Active','2025-11-25 00:37:53','2025-11-25 00:54:25',0),(6,'bonifaciot00003','$2y$10$xoWBnl.LW1OgIc78ELoDyuRSbiaU6Ju.F2xf6m9VJ4BWFsDhYMJ9u',2,6,'Active','2025-11-25 01:52:13','2025-11-26 13:50:01',0),(7,'aquinot00004','$2y$10$n24MLonVmdMu2aH3f9pTAeV3avVFSbKPyRGlJXi2Yg7pK4MnlK20m',2,7,'Active','2025-11-26 13:50:30','2025-11-27 22:58:36',0),(8,'aguinaldot00005','$2y$10$NFKWDtXKpGeseCOTd2iAZe7I9wqbO81LI58cH1uo/w8lH4LVNEEaW',2,5,'Active','2025-11-29 00:52:22','2025-11-29 00:53:48',0),(9,'gonzalest00099','$2y$10$Jjzw06koQ1b3xKTemgrXlOFCBtORrf2yaQAlBzGPKptps2GzFhnmy',2,13,'Active','2025-11-29 01:15:39','2025-11-29 01:15:39',1),(10,'Lukas','dodong',1,NULL,'Active','2026-01-12 11:18:13','2026-01-12 11:18:13',0);

/*Table structure for table `vwstudentinfo` */

DROP TABLE IF EXISTS `vwstudentinfo`;

/*!50001 DROP VIEW IF EXISTS `vwstudentinfo` */;
/*!50001 DROP TABLE IF EXISTS `vwstudentinfo` */;

/*!50001 CREATE TABLE  `vwstudentinfo`(
 `id` int(11) ,
 `lrn` varchar(12) ,
 `fname` varchar(100) ,
 `mname` varchar(100) ,
 `lname` varchar(100) ,
 `birthdate` date ,
 `gender` varchar(10) ,
 `citizenship` varchar(50) ,
 `grade_level_id` int(11) ,
 `grade_level_name` varchar(50) ,
 `fathers_name` varchar(100) ,
 `fathers_contact_num` varchar(20) ,
 `mothers_name` varchar(100) ,
 `mothers_contact_num` varchar(100) ,
 `guardian_name` varchar(100) ,
 `guardian_contact_num` varchar(20) ,
 `street_name` varchar(100) ,
 `postal_code` varchar(20) ,
 `barangay_id` int(11) ,
 `barangay_name` varchar(100) ,
 `city_id` int(11) ,
 `city_name` varchar(100) ,
 `province_id` int(11) ,
 `province_name` varchar(100) ,
 `region_id` int(11) ,
 `region_name` varchar(100) ,
 `country_id` int(11) ,
 `country_name` varchar(100) ,
 `is_active` tinyint(1) ,
 `age` bigint(21) ,
 `full_address` text 
)*/;

/*View structure for view vwstudentinfo */

/*!50001 DROP TABLE IF EXISTS `vwstudentinfo` */;
/*!50001 DROP VIEW IF EXISTS `vwstudentinfo` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vwstudentinfo` AS select `s`.`id` AS `id`,`s`.`lrn` AS `lrn`,`s`.`fname` AS `fname`,`s`.`mname` AS `mname`,`s`.`lname` AS `lname`,`s`.`birthdate` AS `birthdate`,`s`.`gender` AS `gender`,`s`.`citizenship` AS `citizenship`,`s`.`grade_level_id` AS `grade_level_id`,`gl`.`grade_level_name` AS `grade_level_name`,`s`.`fathers_name` AS `fathers_name`,`s`.`fathers_contact_num` AS `fathers_contact_num`,`s`.`mothers_name` AS `mothers_name`,`s`.`mothers_contact_num` AS `mothers_contact_num`,`s`.`guardian_name` AS `guardian_name`,`s`.`guardian_contact_num` AS `guardian_contact_num`,`s`.`street_name` AS `street_name`,`s`.`postal_code` AS `postal_code`,`s`.`barangay_id` AS `barangay_id`,`b`.`barangay_name` AS `barangay_name`,`s`.`city_id` AS `city_id`,`c`.`city_name` AS `city_name`,`s`.`province_id` AS `province_id`,`p`.`province_name` AS `province_name`,`s`.`region_id` AS `region_id`,`r`.`region_name` AS `region_name`,`s`.`country_id` AS `country_id`,`co`.`country_name` AS `country_name`,`s`.`is_active` AS `is_active`,timestampdiff(YEAR,`s`.`birthdate`,curdate()) AS `age`,concat_ws(', ',`s`.`street_name`,`b`.`barangay_name`,`c`.`city_name`,`p`.`province_name`,`r`.`region_name`,`co`.`country_name`) AS `full_address` from ((((((`tblstudents` `s` join `tblgradelevel` `gl` on(`gl`.`id` = `s`.`grade_level_id`)) join `tblbarangay` `b` on(`b`.`id` = `s`.`barangay_id`)) join `tblcity` `c` on(`c`.`id` = `s`.`city_id`)) join `tblprovince` `p` on(`p`.`id` = `s`.`province_id`)) join `tblregion` `r` on(`r`.`id` = `s`.`region_id`)) join `tblcountry` `co` on(`co`.`id` = `s`.`country_id`)) */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
