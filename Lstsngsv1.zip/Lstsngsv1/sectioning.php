<?php
require_once __DIR__ . '/api/shared/db_connect.php';

function h($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

function getStudentColumns(PDO $pdo): array {
    static $cache = null;
    if ($cache !== null) return $cache;

    $colsStmt = $pdo->query('SHOW COLUMNS FROM tblstudents');
    $columns = $colsStmt->fetchAll(PDO::FETCH_COLUMN);

    $fnameCol = in_array('fname', $columns, true) ? 'fname' : (in_array('firstname', $columns, true) ? 'firstname' : null);
    $mnameCol = in_array('mname', $columns, true) ? 'mname' : (in_array('middlename', $columns, true) ? 'middlename' : null);
    $lnameCol = in_array('lname', $columns, true) ? 'lname' : (in_array('lastname', $columns, true) ? 'lastname' : null);

    $genderCol = null;
    foreach (['gender', 'sex', 'student_gender'] as $candidate) {
        if (in_array($candidate, $columns, true)) {
            $genderCol = $candidate;
            break;
        }
    }

    $studentNoCol = null;
    foreach (['student_no', 'lrn', 'school_id'] as $candidate) {
        if (in_array($candidate, $columns, true)) {
            $studentNoCol = $candidate;
            break;
        }
    }

    $cache = compact('fnameCol', 'mnameCol', 'lnameCol', 'genderCol', 'studentNoCol');
    return $cache;
}

function fetchSectionViewData(PDO $pdo, int $sectionId, int $academicYearId = 0): array {
    if ($sectionId <= 0) {
        throw new RuntimeException('Invalid section.');
    }

    if ($academicYearId <= 0) {
        $ayStmt = $pdo->query("
            SELECT id, year_label
            FROM tblacademicyear
            WHERE COALESCE(is_active, 1) = 1
            ORDER BY id DESC
            LIMIT 1
        ");
        $activeAy = $ayStmt->fetch(PDO::FETCH_ASSOC);
        $academicYearId = (int)($activeAy['id'] ?? 0);
    }

    $stmt = $pdo->prepare("
        SELECT s.id, s.section_name, s.grade_level_id, g.grade_level_name
        FROM tblsection s
        LEFT JOIN tblgradelevel g ON g.id = s.grade_level_id
        WHERE s.id = ?
    ");
    $stmt->execute([$sectionId]);
    $section = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$section) {
        throw new RuntimeException('Section not found.');
    }

    $schoolYear = '';
    if ($academicYearId > 0) {
        $ay = $pdo->prepare("SELECT year_label FROM tblacademicyear WHERE id = ?");
        $ay->execute([$academicYearId]);
        $schoolYear = (string)($ay->fetchColumn() ?: '');
    }

    $cols = getStudentColumns($pdo);
    if (!$cols['fnameCol'] || !$cols['lnameCol']) {
        throw new RuntimeException('Student name columns not found in tblstudents.');
    }

    $studentIdentifierExpr = $cols['studentNoCol'] ? "st.`{$cols['studentNoCol']}`" : "st.id";
    $middleExpr = $cols['mnameCol']
        ? "CASE WHEN COALESCE(st.`{$cols['mnameCol']}`, '') = '' THEN '' ELSE CONCAT(' ', LEFT(st.`{$cols['mnameCol']}`, 1), '.') END"
        : "''";
    $genderSelect = $cols['genderCol'] ? "st.`{$cols['genderCol']}`" : "NULL";

    $allStudents = [];
    if ($academicYearId > 0) {
        $sqlStudents = "
            SELECT
                ss.id AS section_student_id,
                st.id,
                {$studentIdentifierExpr} AS student_identifier,
                CONCAT(
                    st.`{$cols['lnameCol']}`,
                    ', ',
                    st.`{$cols['fnameCol']}`,
                    {$middleExpr}
                ) AS full_name,
                {$genderSelect} AS gender
            FROM tblsectionstudent ss
            INNER JOIN tblstudents st ON st.id = ss.student_id
            WHERE ss.section_id = ?
              AND ss.academic_year_id = ?
              AND ss.is_active = 1
            ORDER BY st.`{$cols['lnameCol']}` ASC, st.`{$cols['fnameCol']}` ASC
        ";
        $stmt = $pdo->prepare($sqlStudents);
        $stmt->execute([$sectionId, $academicYearId]);
        $allStudents = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    $maleStudents = [];
    $femaleStudents = [];
    $unknownGender = [];

    foreach ($allStudents as $student) {
        $gender = strtolower(trim((string)($student['gender'] ?? '')));
        if (in_array($gender, ['male', 'm', 'boy', 'boys', '1'], true)) {
            $student['gender_label'] = 'Male';
            $maleStudents[] = $student;
        } elseif (in_array($gender, ['female', 'f', 'girl', 'girls', '0', '2'], true)) {
            $student['gender_label'] = 'Female';
            $femaleStudents[] = $student;
        } else {
            $student['gender_label'] = 'Unspecified';
            $unknownGender[] = $student;
        }
    }

    $schedules = [];
    if ($academicYearId > 0) {
        $sqlSchedule = "
            SELECT
                sc.id,
                sc.day_of_week,
                sc.time_start,
                sc.time_end,
                sc.room,
                sc.remarks,
                sub.subject_code,
                sub.subject_name,
                CONCAT(t.fname, ' ', t.lname) AS teacher_name
            FROM tblschedule sc
            INNER JOIN tblsubjects sub ON sub.id = sc.subject_id
            INNER JOIN tblteacher t ON t.id = sc.teacher_id
            WHERE sc.section_id = ?
              AND sc.academic_year_id = ?
              AND sc.is_active = 1
            ORDER BY
                FIELD(sc.day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'),
                sc.time_start ASC,
                sub.subject_name ASC
        ";
        $stmt = $pdo->prepare($sqlSchedule);
        $stmt->execute([$sectionId, $academicYearId]);
        $schedules = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    return [
        'section' => [
            'id' => (int)$section['id'],
            'section_name' => $section['section_name'] ?? '',
            'grade_level_name' => $section['grade_level_name'] ?? '',
            'school_year' => $schoolYear !== '' ? $schoolYear : 'Not set',
            'academic_year_id' => $academicYearId,
        ],
        'stats' => [
            'total_students' => count($allStudents),
            'male_students' => count($maleStudents),
            'female_students' => count($femaleStudents),
            'unspecified_students' => count($unknownGender),
            'total_schedules' => count($schedules),
        ],
        'students' => $allStudents,
        'male_students_list' => $maleStudents,
        'female_students_list' => $femaleStudents,
        'unknown_students_list' => $unknownGender,
        'schedules' => $schedules,
    ];
}

if (isset($_GET['ajax']) && $_GET['ajax'] === 'view_section') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $sectionId = (int)($_GET['id'] ?? 0);
        $academicYearId = (int)($_GET['academic_year_id'] ?? 0);
        echo json_encode([
            'success' => true,
            'data' => fetchSectionViewData($pdo, $sectionId, $academicYearId)
        ]);
    } catch (Throwable $e) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
    exit;
}

$gradeLevels = [];
try {
    $stmt = $pdo->query("SELECT id, grade_level_name FROM tblgradelevel ORDER BY id ASC");
    $gradeLevels = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    $gradeLevels = [];
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Sectioning</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">

    <style>
        body {
            background: #f3f7fd;
        }

        .ay-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }

        .ay-page-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 0.2rem;
            letter-spacing: 0.01em;
        }

        .ay-page-header p {
            margin: 0;
            font-size: 0.88rem;
            opacity: 0.85;
        }

        .ay-active-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            background: rgba(255, 255, 255, 0.15);
            border: 1.5px solid rgba(255, 255, 255, 0.3);
            border-radius: 999px;
            padding: 0.45rem 1rem;
            font-size: 0.88rem;
            font-weight: 700;
            color: #fff;
            white-space: nowrap;
        }

        .ay-card {
            background: #fff;
            border: 1px solid #dce8f8;
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18, 72, 168, 0.06);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }

        .ay-card-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid #e8f0fb;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
            background: #fff;
        }

        .ay-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: #132f62;
            margin: 0 0 0.15rem;
        }

        .ay-card-subtitle {
            font-size: 0.8rem;
            color: #7a93b8;
            margin: 0;
        }

        .ay-toolbar {
            display: flex;
            gap: .6rem;
            flex-wrap: wrap;
            align-items: center;
        }

        .ay-card-body {
            padding: 0;
        }

        .ay-card-footer {
            padding: 0.75rem 1.2rem;
            border-top: 1px solid #e8f0fb;
            background: #fafcff;
            display: flex;
            justify-content: flex-end;
        }

        .ay-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
        }

        .ay-table thead th {
            background: #f4f8ff;
            color: #3b5e96;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 0.85rem 1rem;
            border-bottom: 1.5px solid #dce8f8;
            white-space: nowrap;
            text-align: center;
        }

        .ay-table tbody tr {
            transition: background 0.12s;
        }

        .ay-table tbody tr:not(:last-child) td {
            border-bottom: 1px solid #f0f5fc;
        }

        .ay-table tbody tr:hover td {
            background: #f7fbff;
        }

        .ay-table tbody td {
            padding: 0.9rem 1rem;
            font-size: 0.93rem;
            color: #213a5e;
            vertical-align: middle;
            text-align: center;
        }

        .ay-left {
            text-align: left !important;
        }

        .row-num {
            color: #a0b4cc;
            font-size: 0.82rem;
            font-weight: 600;
        }

        .year-label {
            font-weight: 700;
            color: #132f62;
        }

        .ay-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.32rem 0.75rem;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }

        .ay-badge-active {
            background: #e6f0ff;
            color: #1248a8;
            border: 1.5px solid #b8d0fa;
        }

        .ay-badge-inactive {
            background: #f3f5f8;
            color: #7a8ea8;
            border: 1.5px solid #dde4ee;
        }

        .btn-ay {
            font-weight: 600;
            font-size: 0.82rem;
            border-radius: 8px;
            padding: 0.42rem 0.9rem;
            cursor: pointer;
            transition: background 0.15s, border-color 0.15s, color 0.15s, box-shadow 0.15s;
            border: 1.5px solid transparent;
            line-height: 1.4;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: .35rem;
        }

        .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            border-color: transparent;
            box-shadow: 0 2px 8px rgba(26, 110, 245, 0.2);
        }

        .btn-ay-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
        }

        .btn-ay-secondary {
            background: #fff;
            color: #1248a8;
            border-color: #b8d0fa;
        }

        .btn-ay-secondary:hover {
            background: #eef4ff;
            border-color: #8db5f7;
            color: #0f3d90;
        }

        .ay-pagination {
            display: flex;
            gap: 0.3rem;
            list-style: none;
            margin: 0;
            padding: 0;
            justify-content: flex-end;
            flex-wrap: wrap;
        }

        .ay-pagination .ay-page-item .ay-page-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
            border-radius: 7px;
            font-size: 0.83rem;
            font-weight: 600;
            cursor: pointer;
            border: 1.5px solid #dce8f8;
            color: #1a6ef5;
            background: #fff;
            transition: all 0.13s;
            padding: 0 0.5rem;
            text-decoration: none;
        }

        .ay-pagination .ay-page-item .ay-page-link:hover {
            background: #eef4ff;
            border-color: #9cc2fc;
        }

        .ay-pagination .ay-page-item.active .ay-page-link {
            background: #1a6ef5;
            border-color: #1a6ef5;
            color: #fff;
        }

        .ay-empty {
            text-align: center;
            padding: 2.5rem 1.5rem;
            color: #9ab0c8;
        }

        .ay-empty i {
            font-size: 2.2rem;
            display: block;
            margin-bottom: 0.6rem;
            opacity: 0.5;
        }

        .ay-empty p {
            margin: 0;
            font-size: 0.95rem;
        }

        .ay-mobile-card {
            background: #fff;
            border: 1.5px solid #dce8f8;
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 1px 6px rgba(18, 72, 168, 0.05);
        }

        .ay-mobile-card + .ay-mobile-card {
            margin-top: 0.75rem;
        }

        .ay-mobile-card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.85rem 1rem;
            border-bottom: 1px solid #edf3fc;
            background: #f9fbff;
            gap: .75rem;
        }

        .ay-mobile-card-title {
            font-weight: 700;
            color: #132f62;
            font-size: 0.95rem;
        }

        .ay-mobile-card-body {
            padding: 0.85rem 1rem;
        }

        .ay-mobile-row {
            display: flex;
            justify-content: space-between;
            gap: .75rem;
            padding: .2rem 0;
            font-size: .9rem;
        }

        .ay-mobile-label {
            color: #7a93b8;
            font-weight: 600;
        }

        .ay-mobile-actions {
            display: grid;
            gap: .5rem;
            padding: 0 1rem 1rem;
        }

        .section-view-modal .modal-dialog {
            max-width: 1180px;
        }

        .section-view-modal .modal-content {
            border: 0;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 10px 34px rgba(18, 72, 168, 0.18);
        }

        .section-view-modal .modal-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            color: #fff;
            border-bottom: 0;
            padding: 1rem 1.25rem;
        }

        .section-view-modal .modal-header .btn-close {
            filter: invert(1);
        }

        .section-view-modal .modal-body {
            background: #fff;
            padding: 1.2rem;
        }

        .sv-school-name {
            font-size: 1.25rem;
            font-weight: 900;
            letter-spacing: .02em;
            text-align: center;
            margin: 0;
            color: #132f62;
        }

        .sv-subhead {
            font-size: .85rem;
            text-align: center;
            color: #6f84a6;
            margin: .2rem 0 1rem;
        }

        .sv-section-bar {
            background: #132f62;
            color: #fff;
            text-align: center;
            font-size: 1.35rem;
            font-weight: 900;
            line-height: 1.1;
            padding: .55rem .75rem;
            border-radius: 12px 12px 0 0;
        }

        .sv-semester-line {
            text-align: center;
            font-size: 1rem;
            font-weight: 800;
            margin: 0 0 1rem;
            padding: .6rem .75rem;
            background: #f4f8ff;
            border: 1px solid #dce8f8;
            border-top: 0;
            border-radius: 0 0 12px 12px;
            color: #132f62;
        }

        .sv-summary {
            text-align: center;
            font-size: .95rem;
            margin-bottom: 1rem;
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .sv-summary span {
            font-weight: 700;
            background: #f8fbff;
            border: 1px solid #dce8f8;
            border-radius: 999px;
            padding: .35rem .85rem;
        }

        .male-count { color: #1248a8; }
        .female-count { color: #c2185b; }
        .total-count { color: #355177; }

        .sv-block-title {
            font-size: 1rem;
            font-weight: 900;
            margin: 1.2rem 0 .8rem;
            text-align: center;
            text-transform: uppercase;
            border-bottom: 2px solid #132f62;
            padding-bottom: 0.45rem;
            color: #132f62;
        }

        .sv-table-wrap {
            border: 1px solid #dce8f8;
            border-radius: 12px;
            overflow: hidden;
        }

        .sv-table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            font-size: 0.9rem;
            margin: 0;
        }

        .sv-table th, .sv-table td {
            border: 1px solid #dce8f8;
            padding: 0.7rem;
            vertical-align: middle;
        }

        .sv-table th {
            background: #f4f8ff;
            font-size: 0.8rem;
            font-weight: 900;
            text-align: center;
            color: #132f62;
        }

        .sv-year-row td {
            font-size: 1rem;
            font-weight: 900;
            text-align: center;
            padding: 0.8rem 0;
            background: #eef4ff;
            color: #132f62;
        }

        .sv-center {
            text-align: center;
        }

        .students-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .gender-column {
            border: 1px solid #dce8f8;
            border-radius: 12px;
            overflow: hidden;
            background: #fff;
        }

        .gender-header {
            font-size: 0.88rem;
            font-weight: 800;
            text-align: center;
            padding: 0.75rem;
            border-bottom: 1px solid #dce8f8;
            background: #f4f8ff;
            color: #132f62;
        }

        .student-list {
            font-size: 0.92rem;
            line-height: 1.65;
            max-height: 360px;
            overflow: auto;
            padding: .4rem 0;
        }

        .student-item {
            margin: 0;
            display: flex;
            align-items: baseline;
            gap: .55rem;
            padding: .55rem .85rem;
            border-bottom: 1px solid #eef4ff;
        }

        .student-item:last-child {
            border-bottom: 0;
        }

        .student-number {
            font-weight: bold;
            min-width: 26px;
            color: #7a93b8;
        }

        .student-id {
            font-family: monospace;
            font-size: 0.9rem;
            min-width: 105px;
            color: #555;
        }

        .student-name {
            font-weight: 600;
            color: #132f62;
        }

        .sv-empty-inline {
            text-align: center;
            color: #7a93b8;
            font-style: italic;
            padding: 1.25rem;
        }

        .unknown-wrap {
            border: 1px solid #dce8f8;
            border-radius: 12px;
            overflow: hidden;
            background: #fff;
            margin-top: 1rem;
        }

        @media (max-width: 991.98px) {
            .students-container {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 767.98px) {
            .ay-page-header {
                padding: 1.1rem 1.2rem;
                border-radius: 14px;
            }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <div class="app-wrapper">
        <?php require_once("includes/header.php"); ?>
        <?php require_once("includes/sidebar.php"); ?>

        <main class="app-main">
            <div class="app-content">
                <div class="container-fluid py-3">

                    <div class="ay-page-header">
                        <div>
                            <h3><i class="bi bi-diagram-3 me-2"></i>Sectioning</h3>
                            <p>Create Sections for a Grade Level.</p>
                        </div>
                        <div class="ay-active-chip">
                            <i class="bi bi-collection-fill"></i>
                            Section Directory
                        </div>
                    </div>

                    <div class="ay-card">
                        <div class="ay-card-header">
                            <div>
                                <p class="ay-card-title">Section List</p>
                                <p class="ay-card-subtitle">Filter sections, open the masterlist page, or view the full class record in a modal.</p>
                            </div>

                            <div class="ay-toolbar">
                                <select class="form-select form-select-sm" id="gradeLevelFilter" style="min-width:180px; border-radius:10px; border:1.5px solid #dce8f8;">
                                    <option value="">All Grade Levels</option>
                                    <?php foreach ($gradeLevels as $gl): ?>
                                        <option value="<?= h($gl['id']) ?>"><?= h($gl['grade_level_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>

                                <div class="input-group input-group-sm" style="min-width:220px;">
                                    <span class="input-group-text bg-white" style="border:1.5px solid #dce8f8; border-right:0;"><i class="bi bi-search"></i></span>
                                    <input class="form-control" type="search" id="searchInput" placeholder="Search section..." style="border:1.5px solid #dce8f8; border-left:0;">
                                </div>
                            </div>
                        </div>

                        <div class="ay-card-body">
                            <div class="d-none d-md-block">
                                <table class="ay-table" id="sectionTable">
                                    <thead>
                                        <tr>
                                            <th style="width:64px;">#</th>
                                            <th>Grade Level</th>
                                            <th>Section Name</th>
                                            <th>Adviser</th>
                                            <th>Total Students</th>
                                            <th>Status</th>
                                            <th style="width:220px;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="sectionTableBody">
                                        <tr>
                                            <td colspan="7">
                                                <div class="ay-empty">
                                                    <i class="bi bi-hourglass-split"></i>
                                                    <p>Loading sections...</p>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <div class="d-block d-md-none p-3" id="sectionCardView"></div>
                        </div>

                        <div class="ay-card-footer">
                            <ul class="ay-pagination" id="pagination"></ul>
                        </div>
                    </div>

                </div>
            </div>
        </main>

        <?php require_once("includes/footer.php"); ?>
    </div>

    <div class="modal fade section-view-modal" id="sectionViewModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title mb-1"><i class="bi bi-eye-fill me-2"></i>Section View</h5>
                        <div class="small opacity-75" id="modalSectionSubtitle">Loading section details...</div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <p class="sv-school-name">ST. TERESA SCHOOL OF NOVALICHES</p>
                    <p class="sv-subhead">Zabarte Subd., Novaliches, Q.C.</p>

                    <div class="sv-section-bar" id="svSectionBar">-</div>
                    <p class="sv-semester-line" id="svSchoolYearLine">School Year -</p>

                    <div class="sv-summary" id="svSummary"></div>

                    <div class="sv-block-title">Class Schedule</div>
                    <div class="sv-table-wrap" id="scheduleWrap"></div>

                    <div class="sv-block-title">Class List</div>
                    <div id="studentListsWrap"></div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./js/adminlte.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>

    <script>
        const sectionViewModal = new bootstrap.Modal(document.getElementById('sectionViewModal'));
        let allSections = [];
        let filteredSections = [];
        let currentPage = 1;
        const rowsPerPage = 10;

        function esc(str) {
            return (str ?? '').toString()
                .replaceAll('&', '&amp;')
                .replaceAll('<', '&lt;')
                .replaceAll('>', '&gt;')
                .replaceAll('"', '&quot;')
                .replaceAll("'", '&#039;');
        }

        function showAlert(message, type = 'success') {
            const config = {
                success: { title: 'Success', color: 'blue', icon: 'bi bi-check-circle-fill' },
                danger: { title: 'Error', color: 'red', icon: 'bi bi-exclamation-octagon-fill' },
                warning: { title: 'Warning', color: 'yellow', icon: 'bi bi-exclamation-triangle-fill' },
                info: { title: 'Info', color: 'blue', icon: 'bi bi-info-circle-fill' }
            };

            const selected = config[type] || config.success;

            iziToast.show({
                title: selected.title,
                message: message,
                color: selected.color,
                icon: selected.icon,
                iconColor: '#fff',
                theme: 'light',
                position: 'topRight',
                timeout: 4000,
                progressBar: true,
                close: true,
                pauseOnHover: true,
                drag: true,
                transitionIn: 'fadeInDown',
                transitionOut: 'fadeOutUp',
                maxWidth: 420
            });
        }

        async function fetchJson(url, options = {}) {
            const response = await fetch(url, options);
            const raw = await response.text();

            try {
                const json = JSON.parse(raw);
                if (!response.ok || json.success === false) {
                    throw new Error(json.error || `HTTP ${response.status}`);
                }
                return json;
            } catch (error) {
                if (error instanceof SyntaxError) {
                    console.error('Non-JSON response:', raw);
                    throw new Error('Server returned an invalid response.');
                }
                throw error;
            }
        }

        async function loadSections() {
            try {
                const search = document.getElementById('searchInput').value.trim();
                const gradeLevelId = document.getElementById('gradeLevelFilter').value;

                let url = `api/sectioning/sections.php?s=${encodeURIComponent(search)}`;
                if (gradeLevelId) {
                    url += `&grade_level_id=${encodeURIComponent(gradeLevelId)}`;
                }

                const data = await fetchJson(url);
                allSections = data.sections || [];
                filteredSections = [...allSections];
                currentPage = 1;
                renderPage();
            } catch (error) {
                console.error(error);
                showAlert(error.message || 'Failed to load sections.', 'danger');
            }
        }

        function renderPage() {
            const start = (currentPage - 1) * rowsPerPage;
            const pageRows = filteredSections.slice(start, start + rowsPerPage);
            renderTable(pageRows, start);
            renderCards(pageRows, start);
            renderPagination();
        }

        function renderTable(list, startIndex) {
            const tableBody = document.getElementById('sectionTableBody');

            if (!list.length) {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="7">
                            <div class="ay-empty">
                                <i class="bi bi-folder2-open"></i>
                                <p>No sections found.</p>
                            </div>
                        </td>
                    </tr>
                `;
                return;
            }

            tableBody.innerHTML = list.map((s, i) => {
                const isActive = String(s.is_active) === '1';
                return `
                    <tr>
                        <td><span class="row-num">${startIndex + i + 1}</span></td>
                        <td>${esc(s.grade_level_name || '-')}</td>
                        <td class="ay-left"><span class="year-label">${esc(s.section_name || '-')}</span></td>
                        <td>${esc(s.adviser_name || '-')}</td>
                        <td>${esc(s.total_students ?? 0)}</td>
                        <td>
                            ${
                                isActive
                                ? `<span class="ay-badge ay-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                                : `<span class="ay-badge ay-badge-inactive">Inactive</span>`
                            }
                        </td>
                        <td>
                            <div class="d-flex justify-content-center gap-2 flex-wrap">
                                <a class="btn-ay btn-ay-primary" href="sectioning_manage.php?section_id=${encodeURIComponent(s.id)}">
                                    <i class="bi bi-people-fill"></i> Manage
                                </a>
                                <button class="btn-ay btn-ay-secondary" type="button" onclick="openSectionViewModal(${Number(s.id)})">
                                    <i class="bi bi-eye"></i> View
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            }).join('');
        }

        function renderCards(list, startIndex) {
            const cardView = document.getElementById('sectionCardView');

            if (!list.length) {
                cardView.innerHTML = `
                    <div class="ay-empty">
                        <i class="bi bi-folder2-open"></i>
                        <p>No sections found.</p>
                    </div>
                `;
                return;
            }

            cardView.innerHTML = list.map((s, i) => {
                const isActive = String(s.is_active) === '1';
                return `
                    <div class="ay-mobile-card">
                        <div class="ay-mobile-card-header">
                            <span class="ay-mobile-card-title">${startIndex + i + 1}. ${esc(s.section_name || '-')}</span>
                            ${
                                isActive
                                ? `<span class="ay-badge ay-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                                : `<span class="ay-badge ay-badge-inactive">Inactive</span>`
                            }
                        </div>
                        <div class="ay-mobile-card-body">
                            <div class="ay-mobile-row">
                                <span class="ay-mobile-label">Grade Level</span>
                                <span>${esc(s.grade_level_name || '-')}</span>
                            </div>
                            <div class="ay-mobile-row">
                                <span class="ay-mobile-label">Adviser</span>
                                <span>${esc(s.adviser_name || '-')}</span>
                            </div>
                            <div class="ay-mobile-row">
                                <span class="ay-mobile-label">Total Students</span>
                                <span>${esc(s.total_students ?? 0)}</span>
                            </div>
                        </div>
                        <div class="ay-mobile-actions">
                            <a class="btn-ay btn-ay-primary" href="sectioning_manage.php?section_id=${encodeURIComponent(s.id)}">
                                <i class="bi bi-people-fill"></i> Manage
                            </a>
                            <button class="btn-ay btn-ay-secondary" type="button" onclick="openSectionViewModal(${Number(s.id)})">
                                <i class="bi bi-eye"></i> View
                            </button>
                        </div>
                    </div>
                `;
            }).join('');
        }

        function renderPagination() {
            const totalPages = Math.ceil(filteredSections.length / rowsPerPage);
            const pagination = document.getElementById('pagination');

            if (totalPages <= 1) {
                pagination.innerHTML = '';
                return;
            }

            let html = '';

            for (let i = 1; i <= totalPages; i++) {
                html += `
                    <li class="ay-page-item ${i === currentPage ? 'active' : ''}">
                        <a href="javascript:void(0)" class="ay-page-link" onclick="goToPage(${i})">${i}</a>
                    </li>
                `;
            }

            pagination.innerHTML = html;
        }

        function goToPage(page) {
            currentPage = page;
            renderPage();
        }

        function dayLabel(d) {
            const map = {
                Monday: 'Mon',
                Tuesday: 'Tue',
                Wednesday: 'Wed',
                Thursday: 'Thu',
                Friday: 'Fri',
                Saturday: 'Sat'
            };
            return map[d] || d || '-';
        }

        function formatTimeRange(start, end) {
            const format = value => {
                if (!value) return '-';
                const d = new Date(`1970-01-01T${value}`);
                return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }).toLowerCase();
            };
            return `${format(start)} - ${format(end)}`;
        }

        function renderSectionView(data) {
            const section = data.section || {};
            const stats = data.stats || {};
            const maleStudents = data.male_students_list || [];
            const femaleStudents = data.female_students_list || [];
            const unknownStudents = data.unknown_students_list || [];
            const schedules = data.schedules || [];

            document.getElementById('modalSectionSubtitle').textContent =
                `${section.grade_level_name || '-'} • ${section.section_name || '-'} • S.Y. ${section.school_year || 'Not set'}`;

            document.getElementById('svSectionBar').textContent = section.section_name || '-';
            document.getElementById('svSchoolYearLine').textContent = `School Year ${section.school_year || 'Not set'}`;

            document.getElementById('svSummary').innerHTML = `
                <span class="male-count">Male: ${esc(stats.male_students || 0)}</span>
                <span class="female-count">Female: ${esc(stats.female_students || 0)}</span>
                ${Number(stats.unspecified_students || 0) > 0 ? `<span class="total-count">Unspecified: ${esc(stats.unspecified_students || 0)}</span>` : ''}
                <span class="total-count">Total: ${esc(stats.total_students || 0)}</span>
            `;

            document.getElementById('scheduleWrap').innerHTML = `
                <table class="sv-table">
                    <thead>
                        <tr class="sv-year-row">
                            <td colspan="6">${esc(section.grade_level_name || '')} - ${esc(section.section_name || '')}</td>
                        </tr>
                        <tr>
                            <th style="width:12%;">Code</th>
                            <th style="width:28%;">Course Description</th>
                            <th style="width:10%;">Day/s</th>
                            <th style="width:20%;">Time</th>
                            <th style="width:10%;">Room</th>
                            <th style="width:20%;">Faculty</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${
                            !schedules.length
                            ? `<tr><td colspan="6" class="sv-center">No schedule found</td></tr>`
                            : schedules.map(r => `
                                <tr>
                                    <td class="sv-center">${esc(r.subject_code || '')}</td>
                                    <td>${esc(r.subject_name || '')}</td>
                                    <td class="sv-center">${esc(dayLabel(r.day_of_week))}</td>
                                    <td class="sv-center">${esc(formatTimeRange(r.time_start, r.time_end))}</td>
                                    <td class="sv-center">${esc(r.room || '')}</td>
                                    <td>${esc(r.teacher_name || '')}</td>
                                </tr>
                            `).join('')
                        }
                    </tbody>
                </table>
            `;

            const renderStudentColumn = (title, count, list, emptyText) => `
                <div class="gender-column">
                    <div class="gender-header">${title} (${count})</div>
                    ${
                        list.length
                        ? `<div class="student-list">
                            ${list.map((r, i) => `
                                <div class="student-item">
                                    <span class="student-number">${i + 1}.</span>
                                    <span class="student-id">${esc(r.student_identifier || '')}</span>
                                    <span class="student-name">${esc(r.full_name || '')}</span>
                                </div>
                            `).join('')}
                        </div>`
                        : `<div class="sv-empty-inline">${emptyText}</div>`
                    }
                </div>
            `;

            let html = `
                <div class="students-container">
                    ${renderStudentColumn('MALE', maleStudents.length, maleStudents, 'No male students')}
                    ${renderStudentColumn('FEMALE', femaleStudents.length, femaleStudents, 'No female students')}
                </div>
            `;

            if (unknownStudents.length) {
                html += `
                    <div class="unknown-wrap">
                        <div class="gender-header">UNSPECIFIED GENDER (${unknownStudents.length})</div>
                        <div class="student-list">
                            ${unknownStudents.map((r, i) => `
                                <div class="student-item">
                                    <span class="student-number">${i + 1}.</span>
                                    <span class="student-id">${esc(r.student_identifier || '')}</span>
                                    <span class="student-name">${esc(r.full_name || '')}</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                `;
            }

            if ((stats.total_students || 0) === 0) {
                html = `<div class="sv-empty-inline">No students enrolled in this section.</div>`;
            }

            document.getElementById('studentListsWrap').innerHTML = html;
        }

        async function openSectionViewModal(sectionId) {
            try {
                document.getElementById('modalSectionSubtitle').textContent = 'Loading section details...';
                document.getElementById('svSectionBar').textContent = 'Loading...';
                document.getElementById('svSchoolYearLine').textContent = 'School Year -';
                document.getElementById('svSummary').innerHTML = '';
                document.getElementById('scheduleWrap').innerHTML = `<div class="ay-empty"><i class="bi bi-hourglass-split"></i><p>Loading schedule...</p></div>`;
                document.getElementById('studentListsWrap').innerHTML = `<div class="ay-empty"><i class="bi bi-hourglass-split"></i><p>Loading students...</p></div>`;

                sectionViewModal.show();

                const result = await fetchJson(`sectioning.php?ajax=view_section&id=${encodeURIComponent(sectionId)}`);
                renderSectionView(result.data || {});
            } catch (error) {
                console.error(error);
                sectionViewModal.hide();
                showAlert('Unable to load section view: ' + error.message, 'danger');
            }
        }

        document.getElementById('searchInput').addEventListener('input', loadSections);
        document.getElementById('gradeLevelFilter').addEventListener('change', loadSections);

        loadSections();
    </script>
</body>
</html>