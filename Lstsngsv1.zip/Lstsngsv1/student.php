<?php
require_once __DIR__ . '/api/shared/db_connect.php';
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Students</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">

    <style>
        body {
            background: #f3f7fd;
        }

        .students-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }

        .students-page-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 0.2rem;
            letter-spacing: 0.01em;
        }

        .students-page-header p {
            margin: 0;
            font-size: 0.88rem;
            opacity: 0.85;
        }

        .students-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            background: rgba(255, 255, 255, 0.15);
            border: 1.5px solid rgba(255, 255, 255, 0.3);
            border-radius: 999px;
            padding: 0.45rem 1rem;
            font-size: 0.88rem;
            font-weight: 700;
            color: #fff;
            white-space: nowrap;
        }

        .students-chip i {
            font-size: 0.9rem;
            opacity: 0.9;
        }

        .students-card {
            background: #fff;
            border: 1px solid #dce8f8;
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18, 72, 168, 0.06);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }

        .students-card-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid #e8f0fb;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
            background: #fff;
        }

        .students-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: #132f62;
            margin: 0 0 0.15rem;
        }

        .students-card-subtitle {
            font-size: 0.8rem;
            color: #7a93b8;
            margin: 0;
        }

        .students-toolbar {
            display: flex;
            flex-wrap: wrap;
            gap: 0.65rem;
            align-items: center;
        }

        .students-search {
            min-width: 230px;
            height: 40px;
            border-radius: 10px;
            border: 1.5px solid #c8daf8;
            background: #fff;
            color: #213a5e;
            font-size: 0.9rem;
            padding: 0.45rem 0.9rem;
            outline: none;
            transition: 0.15s ease;
        }

        .students-search:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.12);
        }

        .students-card-body {
            padding: 0;
        }

        .students-card-footer {
            padding: 0.75rem 1.2rem;
            border-top: 1px solid #e8f0fb;
            background: #fafcff;
        }

        .students-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
        }

        .students-table thead th {
            background: #f4f8ff;
            color: #3b5e96;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 0.85rem 1rem;
            border-bottom: 1.5px solid #dce8f8;
            white-space: nowrap;
        }

        .students-table tbody tr {
            transition: background 0.12s;
        }

        .students-table tbody tr:not(:last-child) td {
            border-bottom: 1px solid #f0f5fc;
        }

        .students-table tbody tr:hover td {
            background: #f7fbff;
        }

        .students-table tbody td {
            padding: 0.9rem 1rem;
            font-size: 0.92rem;
            color: #213a5e;
            vertical-align: middle;
        }

        .students-table .row-num {
            color: #a0b4cc;
            font-size: 0.82rem;
            font-weight: 600;
        }

        .student-name {
            font-weight: 700;
            color: #132f62;
        }

        .student-grade {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.3rem 0.7rem;
            border-radius: 999px;
            background: #eef4ff;
            color: #1248a8;
            border: 1.5px solid #cfe0ff;
            font-size: 0.78rem;
            font-weight: 700;
        }

        .students-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.32rem 0.75rem;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }

        .students-badge-active {
            background: #e6f0ff;
            color: #1248a8;
            border: 1.5px solid #b8d0fa;
        }

        .students-badge-inactive {
            background: #f3f5f8;
            color: #7a8ea8;
            border: 1.5px solid #dde4ee;
        }

        .student-contact-link {
            color: #1a6ef5;
            text-decoration: none;
            font-weight: 600;
        }

        .student-contact-link:hover {
            color: #1248a8;
            text-decoration: underline;
        }

        .btn-student {
            font-weight: 600;
            font-size: 0.82rem;
            border-radius: 8px;
            padding: 0.42rem 0.9rem;
            cursor: pointer;
            transition: background 0.15s, border-color 0.15s, color 0.15s, box-shadow 0.15s;
            border: 1.5px solid transparent;
            line-height: 1.4;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.35rem;
        }

        .btn-student-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            border-color: transparent;
            box-shadow: 0 2px 8px rgba(26, 110, 245, 0.2);
        }

        .btn-student-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
            box-shadow: 0 3px 12px rgba(26, 110, 245, 0.3);
        }

        .btn-student-edit {
            background: #fff7e6;
            color: #a46a00;
            border-color: #ffe1a8;
        }

        .btn-student-edit:hover {
            background: #ffefc8;
            color: #8a5800;
            border-color: #ffd27a;
        }

        .btn-student-activate {
            background: #1a6ef5;
            color: #fff;
            border-color: #1a6ef5;
        }

        .btn-student-activate:hover {
            background: #1560d8;
            border-color: #1560d8;
            color: #fff;
        }

        .btn-student-deactivate {
            background: #fff;
            color: #1248a8;
            border-color: #b8d0fa;
        }

        .btn-student-deactivate:hover {
            background: #eef4ff;
            border-color: #8db5f7;
            color: #0f3d90;
        }

        .students-actions {
            display: flex;
            gap: 0.45rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        .students-pagination {
            display: flex;
            gap: 0.3rem;
            list-style: none;
            margin: 0;
            padding: 0;
            justify-content: flex-end;
        }

        .students-pagination .students-page-item .students-page-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
            border-radius: 7px;
            font-size: 0.83rem;
            font-weight: 600;
            cursor: pointer;
            border: 1.5px solid #dce8f8;
            color: #1a6ef5;
            background: #fff;
            transition: all 0.13s;
            padding: 0 0.5rem;
            text-decoration: none;
        }

        .students-pagination .students-page-item .students-page-link:hover {
            background: #eef4ff;
            border-color: #9cc2fc;
        }

        .students-pagination .students-page-item.active .students-page-link {
            background: #1a6ef5;
            border-color: #1a6ef5;
            color: #fff;
        }

        .students-empty {
            text-align: center;
            padding: 2.5rem 1.5rem;
            color: #9ab0c8;
        }

        .students-empty i {
            font-size: 2.2rem;
            display: block;
            margin-bottom: 0.6rem;
            opacity: 0.5;
        }

        .students-empty p {
            margin: 0;
            font-size: 0.95rem;
        }

        .students-mobile-card {
            background: #fff;
            border: 1.5px solid #dce8f8;
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 1px 6px rgba(18, 72, 168, 0.05);
        }

        .students-mobile-card + .students-mobile-card {
            margin-top: 0.75rem;
        }

        .students-mobile-card-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 0.75rem;
            padding: 0.9rem 1rem;
            border-bottom: 1px solid #edf3fc;
            background: #f9fbff;
        }

        .students-mobile-card-title {
            font-weight: 700;
            color: #132f62;
            font-size: 0.95rem;
            margin-bottom: 0.25rem;
        }

        .students-mobile-card-subtitle {
            font-size: 0.8rem;
            color: #7a93b8;
            margin: 0;
        }

        .students-mobile-card-body {
            padding: 0.9rem 1rem;
        }

        .students-mobile-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0.65rem 0.9rem;
            margin-bottom: 0.85rem;
        }

        .students-mobile-item small {
            display: block;
            font-size: 0.72rem;
            color: #8fa8c8;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 0.2rem;
        }

        .students-mobile-item span,
        .students-mobile-item a {
            font-size: 0.88rem;
            color: #213a5e;
            font-weight: 600;
            text-decoration: none;
            word-break: break-word;
        }

        .students-mobile-actions {
            display: flex;
            gap: 0.5rem;
            flex-direction: column;
        }

        @media (max-width: 991.98px) {
            .students-table thead th,
            .students-table tbody td {
                padding-left: 0.85rem;
                padding-right: 0.85rem;
            }
        }

        @media (max-width: 767.98px) {
            .students-page-header {
                padding: 1.1rem 1.2rem;
                border-radius: 14px;
            }

            .students-toolbar {
                width: 100%;
            }

            .students-search {
                min-width: 100%;
                width: 100%;
            }
        }
    </style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <div class="app-wrapper">
        <?php require_once("includes/header.php"); ?>
        <?php require_once("includes/sidebar.php"); ?>

        <main class="app-main">
            <div class="app-content">
                <div class="container-fluid py-3">

                    <div class="students-page-header">
                        <div>
                            <h3><i class="bi bi-people-fill me-2"></i>Student Management</h3>
                            <p>Add, edit, and manage all student records.</p>
                        </div>
                        <div class="students-chip">
                            <i class="bi bi-person-vcard-fill"></i>
                            <span id="studentHeaderChip">Student Records</span>
                        </div>
                    </div>

                    <div class="students-card">
                        <div class="students-card-header">
                            <div>
                                <p class="students-card-title">Student List</p>
                                <p class="students-card-subtitle">Search, review, edit, and activate or deactivate student accounts.</p>
                            </div>

                            <div class="students-toolbar">
                                <input type="search" class="students-search" id="searchInput" placeholder="Search student, LRN, guardian, or contact">
                                <a href="student_form.php" class="btn-student btn-student-primary">
                                    <i class="bi bi-plus-circle"></i>
                                    New Student
                                </a>
                            </div>
                        </div>

                        <div class="students-card-body">
                            <div class="d-none d-md-block">
                                <table class="students-table" id="studentTable">
                                    <thead>
                                        <tr>
                                            <th style="width:60px; text-align:center;">#</th>
                                            <th>LRN</th>
                                            <th>Name</th>
                                            <th>Grade</th>
                                            <th style="width:80px; text-align:center;">Age</th>
                                            <th style="width:90px; text-align:center;">Sex</th>
                                            <th>Guardian</th>
                                            <th>Contact</th>
                                            <th style="width:130px; text-align:center;">Status</th>
                                            <th style="width:220px; text-align:center;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="studentTableBody">
                                        <tr>
                                            <td colspan="10">
                                                <div class="students-empty">
                                                    <i class="bi bi-hourglass-split"></i>
                                                    <p>Loading students...</p>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <div class="d-block d-md-none p-3" id="studentCardView"></div>
                        </div>

                        <div class="students-card-footer">
                            <ul class="students-pagination" id="pagination"></ul>
                        </div>
                    </div>

                </div>
            </div>
        </main>

        <?php require_once("includes/footer.php"); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./js/adminlte.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>

    <script>
        let currentPage = 1;
        let searchTerm = '';

        function escapeHtml(value) {
            return String(value ?? '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        function showAlert(message, type = 'success') {
            const config = {
                success: {
                    title: 'Success',
                    color: 'blue',
                    icon: 'bi bi-check-circle-fill'
                },
                danger: {
                    title: 'Error',
                    color: 'red',
                    icon: 'bi bi-exclamation-octagon-fill'
                },
                warning: {
                    title: 'Warning',
                    color: 'yellow',
                    icon: 'bi bi-exclamation-triangle-fill'
                },
                info: {
                    title: 'Info',
                    color: 'blue',
                    icon: 'bi bi-info-circle-fill'
                }
            };

            const selected = config[type] || config.success;

            iziToast.show({
                title: selected.title,
                message: message,
                color: selected.color,
                icon: selected.icon,
                iconColor: '#fff',
                theme: 'light',
                position: 'topRight',
                timeout: 4000,
                progressBar: true,
                close: true,
                pauseOnHover: true,
                drag: true,
                transitionIn: 'fadeInDown',
                transitionOut: 'fadeOutUp',
                maxWidth: 420
            });
        }

        async function fetchJson(url, options = {}) {
            const response = await fetch(url, options);
            const raw = await response.text();

            try {
                return JSON.parse(raw);
            } catch (e) {
                console.error('Non-JSON response:', raw);
                throw new Error('Server returned an invalid response.');
            }
        }

        function updateStudentHeaderChip(totalCount = null) {
            const chip = document.getElementById('studentHeaderChip');
            if (!chip) return;

            if (typeof totalCount === 'number') {
                chip.textContent = totalCount + ' Student' + (totalCount === 1 ? '' : 's');
            } else {
                chip.textContent = 'Student Records';
            }
        }

        async function loadStudents(page = 1, search = '') {
            currentPage = page;

            try {
                const data = await fetchJson(`api/student/read.php?p=${page}&s=${encodeURIComponent(search)}`);
                renderStudents(data.students || [], data.page || 1, data.pages || 1);
            } catch (error) {
                showAlert(error.message, 'danger');
            }
        }

        function renderStudents(list, page, pages) {
            const tbody = document.getElementById('studentTableBody');
            const cardView = document.getElementById('studentCardView');

            updateStudentHeaderChip(Array.isArray(list) ? list.length : null);

            if (!list.length) {
                const emptyHtml = `
                    <div class="students-empty">
                        <i class="bi bi-people"></i>
                        <p>No students found.</p>
                    </div>
                `;

                tbody.innerHTML = `<tr><td colspan="10">${emptyHtml}</td></tr>`;
                cardView.innerHTML = emptyHtml;
                document.getElementById('pagination').innerHTML = '';
                return;
            }

            const offset = (page - 1) * 10;

            tbody.innerHTML = list.map((s, i) => {
                const isActive = Number(s.is_active) === 1;
                const fullName = `${s.fname || ''} ${s.mname || ''} ${s.lname || ''}`.replace(/\s+/g, ' ').trim();
                const statusBadge = isActive
                    ? `<span class="students-badge students-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                    : `<span class="students-badge students-badge-inactive">Inactive</span>`;
                const toggleButton = isActive
                    ? `<button class="btn-student btn-student-deactivate" onclick='toggleStudent(${Number(s.id)}, 0, ${JSON.stringify(fullName)})'>Deactivate</button>`
                    : `<button class="btn-student btn-student-activate" onclick='toggleStudent(${Number(s.id)}, 1, ${JSON.stringify(fullName)})'>Activate</button>`;

                return `
                    <tr>
                        <td style="text-align:center;"><span class="row-num">${offset + i + 1}</span></td>
                        <td>${escapeHtml(s.lrn || '')}</td>
                        <td><span class="student-name">${escapeHtml(fullName)}</span></td>
                        <td><span class="student-grade">${escapeHtml(s.grade_level_name || '')}</span></td>
                        <td style="text-align:center;">${escapeHtml(s.age || '')}</td>
                        <td style="text-align:center;">${escapeHtml(s.gender || '')}</td>
                        <td>${escapeHtml(s.guardian_name || '')}</td>
                        <td>
                            <a class="student-contact-link" href="tel:${escapeHtml(s.guardian_contact_num || '')}">
                                ${escapeHtml(s.guardian_contact_num || '')}
                            </a>
                        </td>
                        <td style="text-align:center;">${statusBadge}</td>
                        <td style="text-align:center;">
                            <div class="students-actions">
                                <a href="student_form.php?id=${encodeURIComponent(s.id)}" class="btn-student btn-student-edit">
                                    <i class="bi bi-pencil-square"></i>
                                    Edit
                                </a>
                                ${toggleButton}
                            </div>
                        </td>
                    </tr>
                `;
            }).join('');

            cardView.innerHTML = list.map((s, i) => {
                const isActive = Number(s.is_active) === 1;
                const fullName = `${s.fname || ''} ${s.mname || ''} ${s.lname || ''}`.replace(/\s+/g, ' ').trim();
                const statusBadge = isActive
                    ? `<span class="students-badge students-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                    : `<span class="students-badge students-badge-inactive">Inactive</span>`;
                const toggleButton = isActive
                    ? `<button class="btn-student btn-student-deactivate w-100" onclick='toggleStudent(${Number(s.id)}, 0, ${JSON.stringify(fullName)})'>Deactivate</button>`
                    : `<button class="btn-student btn-student-activate w-100" onclick='toggleStudent(${Number(s.id)}, 1, ${JSON.stringify(fullName)})'>Activate</button>`;

                return `
                    <div class="students-mobile-card">
                        <div class="students-mobile-card-header">
                            <div>
                                <div class="students-mobile-card-title">${offset + i + 1}. ${escapeHtml(fullName)}</div>
                                <p class="students-mobile-card-subtitle">LRN: ${escapeHtml(s.lrn || '')}</p>
                            </div>
                            ${statusBadge}
                        </div>

                        <div class="students-mobile-card-body">
                            <div class="students-mobile-grid">
                                <div class="students-mobile-item">
                                    <small>Grade</small>
                                    <span>${escapeHtml(s.grade_level_name || '')}</span>
                                </div>
                                <div class="students-mobile-item">
                                    <small>Age</small>
                                    <span>${escapeHtml(s.age || '')}</span>
                                </div>
                                <div class="students-mobile-item">
                                    <small>Sex</small>
                                    <span>${escapeHtml(s.gender || '')}</span>
                                </div>
                                <div class="students-mobile-item">
                                    <small>Guardian</small>
                                    <span>${escapeHtml(s.guardian_name || '')}</span>
                                </div>
                                <div class="students-mobile-item" style="grid-column: 1 / -1;">
                                    <small>Contact</small>
                                    <a class="student-contact-link" href="tel:${escapeHtml(s.guardian_contact_num || '')}">
                                        ${escapeHtml(s.guardian_contact_num || '')}
                                    </a>
                                </div>
                            </div>

                            <div class="students-mobile-actions">
                                <a href="student_form.php?id=${encodeURIComponent(s.id)}" class="btn-student btn-student-edit w-100">
                                    <i class="bi bi-pencil-square"></i>
                                    Edit Student
                                </a>
                                ${toggleButton}
                            </div>
                        </div>
                    </div>
                `;
            }).join('');

            document.getElementById('pagination').innerHTML = Array.from({ length: pages }, (_, idx) => {
                const n = idx + 1;
                return `
                    <li class="students-page-item ${n === page ? 'active' : ''}">
                        <a class="students-page-link" href="#" onclick="loadStudents(${n}, ${JSON.stringify(searchTerm)}); return false;">${n}</a>
                    </li>
                `;
            }).join('');
        }

        function toggleStudent(id, newState, studentName = 'this student') {
            const action = newState === 1 ? 'activate' : 'deactivate';

            iziToast.question({
                timeout: 20000,
                close: false,
                overlay: true,
                displayMode: 'once',
                id: 'student-confirm',
                zindex: 9999,
                title: 'Confirm',
                message: `Are you sure you want to ${action} ${escapeHtml(studentName)}?`,
                position: 'center',
                color: 'blue',
                icon: 'bi bi-question-circle-fill',
                buttons: [
                    [
                        '<button><b>Yes</b></button>',
                        async function(instance, toast) {
                            instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');

                            try {
                                const res = await fetchJson('api/student/toggle.php?id=' + encodeURIComponent(id), {
                                    method: 'GET'
                                });

                                if (res.success) {
                                    showAlert(res.message || `Student ${action}d successfully.`, 'success');
                                    loadStudents(currentPage, searchTerm);
                                } else {
                                    showAlert(res.error || 'Toggle failed.', 'danger');
                                }
                            } catch (error) {
                                showAlert(error.message, 'danger');
                            }
                        },
                        true
                    ],
                    [
                        '<button>No</button>',
                        function(instance, toast) {
                            instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');
                            showAlert(`Student ${action} cancelled.`, 'info');
                        }
                    ]
                ]
            });
        }

        let searchDebounce;
        document.getElementById('searchInput').addEventListener('input', function(e) {
            searchTerm = e.target.value;

            clearTimeout(searchDebounce);
            searchDebounce = setTimeout(() => {
                loadStudents(1, searchTerm);
            }, 250);
        });

        loadStudents();
    </script>
</body>

</html>