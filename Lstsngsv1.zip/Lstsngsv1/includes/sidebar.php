<?php
$basePath = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? $_SERVER['PHP_SELF'] ?? '')), '/');

if ($basePath === '' || $basePath === '.' || $basePath === false) {
  $basePath = '/';
} elseif (strpos($basePath, '/') !== 0) {
  $basePath = '/' . $basePath;
}

$base = rtrim($basePath, '/') . '/';

function isActive($file)
{
  return basename($_SERVER['PHP_SELF']) === $file ? 'active' : '';
}

function isExpanded($files)
{
  return in_array(basename($_SERVER['PHP_SELF']), $files) ? 'show' : '';
}

function isAriaExpanded($files)
{
  return in_array(basename($_SERVER['PHP_SELF']), $files) ? 'true' : 'false';
}
?>

<aside class="app-sidebar bg-dark text-white border-end shadow-sm custom-sidebar">
  <div class="sidebar-brand">
    <a href="<?= $base ?>Dashboard.php" class="sidebar-brand-link text-decoration-none text-white">
      <div class="sidebar-logo">
        <i class="bi bi-person-fill-gear fs-5"></i>
      </div>
      <div class="sidebar-brand-text">
        <div class="sidebar-title">STSN ADMIN</div>
        <small class="sidebar-subtitle">Management Panel</small>
      </div>
    </a>
  </div>

  <div class="sidebar-body">
    <ul class="nav flex-column sidebar-menu">

      <li class="nav-item">
        <a href="<?= $base ?>Dashboard.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('Dashboard.php') ?>">
          <i class="bi bi-speedometer2 me-2"></i>
          <span>Dashboard</span>
        </a>
      </li>

      <li class="nav-label">
        <small class="text-uppercase text-white-50 fw-semibold">Users</small>
      </li>

      <li class="nav-item">
        <a class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center justify-content-between sidebar-link"
          data-bs-toggle="collapse" href="#teacherMenu" role="button"
          aria-expanded="<?= isAriaExpanded(['teacher.php', 'assign.php']) ?>"
          aria-controls="teacherMenu">
          <span><i class="bi bi-easel me-2"></i>Teachers</span>
          <i class="bi bi-chevron-right small arrow-icon"></i>
        </a>

        <div class="collapse submenu <?= isExpanded(['teacher.php', 'assign.php']) ?>" id="teacherMenu">
          <ul class="nav flex-column submenu-list">
            <li class="nav-item">
              <a href="<?= $base ?>teacher.php"
                class="nav-link text-white rounded-3 px-3 py-2 sidebar-sublink <?= isActive('teacher.php') ?>">
                <i class="bi bi-people me-2"></i>Manage Teachers
              </a>
            </li>
          </ul>
        </div>
      </li>

      <li class="nav-item">
        <a class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center justify-content-between sidebar-link"
          data-bs-toggle="collapse" href="#studentMenu" role="button"
          aria-expanded="<?= isAriaExpanded(['student.php']) ?>"
          aria-controls="studentMenu">
          <span><i class="bi bi-person-check me-2"></i>Students</span>
          <i class="bi bi-chevron-right small arrow-icon"></i>
        </a>

        <div class="collapse submenu <?= isExpanded(['student.php']) ?>" id="studentMenu">
          <ul class="nav flex-column submenu-list">
            <li class="nav-item">
              <a href="<?= $base ?>student.php"
                class="nav-link text-white rounded-3 px-3 py-2 sidebar-sublink <?= isActive('student.php') ?>">
                <i class="bi bi-people me-2"></i>Manage Students
              </a>
            </li>
          </ul>
        </div>
      </li>

      <!-- Manage Teacher Accounts -->
      <li class="nav-item">
        <a href="<?= $base ?>manageA.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('manageA.php') ?>">
          <i class="bi bi-diagram-3 me-2"></i>
          <span>Manage Teacher Accounts</span>
        </a>
      </li>

      <!-- Manage Student Accounts -->
      <li class="nav-item">
        <a href="<?= $base ?>manageStudentA.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('manageStudentA.php') ?>">
          <i class="bi bi-person-badge me-2"></i>
          <span>Manage Student Accounts</span>
        </a>
      </li>

      <!-- ========== MAINTENANCE SECTION ========== -->
      <li class="nav-label">
        <small class="text-uppercase text-white-50 fw-semibold">Maintenance</small>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>academic_year.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('academic_year.php') ?>">
          <i class="bi bi-calendar me-2"></i>
          <span>Academic Year</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>section.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('section.php') ?>">
          <i class="bi bi-journals me-2"></i>
          <span>Section</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>curriculum.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('curriculum.php') ?>">
          <i class="bi bi-journal-bookmark-fill me-2"></i>
          <span>Curriculum Management</span>
        </a>
      </li>
      <!-- ========== END MAINTENANCE ========== -->

      <!-- Scheduling and Sectioning -->
      <li class="nav-item">
        <a href="<?= $base ?>schedule.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('schedule.php') ?>">
          <i class="bi bi-calendar-week-fill me-2"></i>
          <span>Scheduling</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>sectioning.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('sectioning.php') ?>">
          <i class="bi bi-pin-map me-2"></i>
          <span>Sectioning</span>
        </a>
      </li>

      <!-- Reports -->
      <li class="nav-item">
        <a href="<?= $base ?>reports.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('reports.php') ?>">
          <i class="bi bi-file-text-fill me-2"></i>
          <span>Reports</span>
        </a>
      </li>

      <!-- Backup / Restore (moved above Logout) -->
      <li class="nav-item">
        <a href="<?= $base ?>backup_restore.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('backup_restore.php') ?>">
          <i class="bi bi-database me-2"></i>
          <span>Backup / Restore</span>
        </a>
      </li>

      <li class="nav-item logout-item">
        <a href="<?= $base ?>api/login/logout.php"
          class="nav-link rounded-3 px-3 py-2 d-flex align-items-center sidebar-logout">
          <i class="bi bi-box-arrow-right me-2"></i>
          <span>Logout</span>
        </a>
      </li>

    </ul>
  </div>
</aside>