<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../shared/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /Lstsngsv1/login.php');
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($username === '' || $password === '') {
    $_SESSION['login_error'] = 'Username and password are required.';
    header('Location: /Lstsngsv1/login.php');
    exit;
}

$sql = "SELECT id, username, password_hash, reference_id, role_id, status, must_change_password
        FROM tblusers
        WHERE username = ?
        LIMIT 1";

$stmt = $pdo->prepare($sql);
$stmt->execute([$username]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    $_SESSION['login_error'] = 'Invalid username or password.';
    header('Location: /Lstsngsv1/login.php');
    exit;
}

if (isset($user['status']) && strtolower((string)$user['status']) !== 'active') {
    $_SESSION['login_error'] = 'Your account is inactive.';
    header('Location: /Lstsngsv1/login.php');
    exit;
}

$storedPassword = (string)($user['password_hash'] ?? '');
$validPassword = false;

if ($storedPassword !== '') {
    $info = password_get_info($storedPassword);

    if (!empty($info['algo'])) {
        $validPassword = password_verify($password, $storedPassword);
    } else {
        $validPassword = hash_equals($storedPassword, $password);
    }
}

if (!$validPassword) {
    $_SESSION['login_error'] = 'Invalid username or password.';
    header('Location: /Lstsngsv1/login.php');
    exit;
}

session_regenerate_id(true);

$_SESSION['user_id'] = (int)$user['id'];
$_SESSION['reference_id'] = $user['reference_id'];
$_SESSION['role_id'] = isset($user['role_id']) ? (int)$user['role_id'] : null;
$_SESSION['username'] = $user['username'];
$_SESSION['must_change_password'] = isset($user['must_change_password']) ? (int)$user['must_change_password'] : 0;

if (!isset($user['reference_id']) || $user['reference_id'] === null || $user['reference_id'] === '') {
    header('Location: /Lstsngsv1/Dashboard.php');
    exit;
}

header('Location: /Lstsngsv1/teacher-dashboard.php');
exit;
?>