<?php
require_once 'includes/auth.php';
requireAdmin();
require_once 'api/shared/db_connect.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Curriculum Management</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
    <style>
        body { background: #f3f7fd; }

        .cm-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 18px; padding: 1.35rem 1.5rem; color: #fff;
            margin-bottom: 1.25rem; display: flex; flex-wrap: wrap;
            align-items: center; justify-content: space-between; gap: 1rem;
            box-shadow: 0 8px 24px rgba(18,72,168,.15);
        }
        .cm-page-header h3 { font-size: 1.35rem; font-weight: 700; margin: 0 0 .2rem; }
        .cm-page-header p  { margin: 0; font-size: .9rem; opacity: .9; }

        .cm-header-chip {
            display: inline-flex; align-items: center; gap: .45rem;
            background: rgba(255,255,255,.15); border: 1px solid rgba(255,255,255,.25);
            border-radius: 999px; padding: .55rem 1rem;
            font-size: .88rem; font-weight: 700; color: #fff; white-space: nowrap;
        }

        .cm-layout {
            display: grid; grid-template-columns: 290px 1fr;
            gap: 1.2rem; align-items: start;
        }
        @media (max-width: 991px) { .cm-layout { grid-template-columns: 1fr; } }

        .cm-card {
            background: #fff; border: 1px solid #dce8f8;
            border-radius: 18px; box-shadow: 0 3px 14px rgba(18,72,168,.06); overflow: hidden;
        }
        .cm-card-header {
            padding: 1rem 1.2rem; border-bottom: 1px solid #e8f0fb;
            display: flex; align-items: center; justify-content: space-between;
            gap: .75rem; background: #fff;
        }
        .cm-card-title    { font-size: 1rem; font-weight: 700; color: #132f62; margin: 0 0 .1rem; }
        .cm-card-subtitle { font-size: .8rem; color: #7a93b8; margin: 0; }
        .cm-card-footer   {
            padding: .75rem 1rem; border-top: 1px solid #e8f0fb;
            background: #fafcff; overflow-x: auto;
        }

        .cm-tree-wrap { padding: .6rem; }
        .cm-tree-level { margin-bottom: .35rem; }
        .cm-tree-level > summary {
            cursor: pointer; display: flex; align-items: center; gap: .45rem;
            padding: .65rem .75rem; border-radius: 10px; font-weight: 700;
            font-size: .8rem; color: #1248a8; text-transform: uppercase;
            letter-spacing: .05em; user-select: none; list-style: none;
        }
        .cm-tree-level > summary:hover { background: #eef4ff; }
        .cm-tree-level > summary::marker,
        .cm-tree-level > summary::-webkit-details-marker { display: none; }
        .cm-caret { transition: transform .18s; font-size: .75rem; color: #6b84a2; }
        .cm-tree-level[open] > summary .cm-caret { transform: rotate(90deg); }

        .cm-grade-item {
            display: flex; align-items: center; gap: .45rem;
            padding: .55rem .75rem .55rem 1.2rem; border-radius: 10px;
            cursor: pointer; font-size: .9rem; color: #3a5a82;
            transition: background .12s, color .12s, transform .12s; margin-bottom: .2rem;
        }
        .cm-grade-item:hover { background: #eef4ff; color: #1a6ef5; transform: translateX(2px); }
        .cm-grade-item.active {
            background: linear-gradient(135deg, #1a6ef5, #2a74ef);
            color: #fff; font-weight: 700;
            box-shadow: 0 8px 16px rgba(26,110,245,.18);
        }
        .cm-grade-dot { width: 6px; height: 6px; border-radius: 50%; background: #1a6ef5; flex-shrink: 0; }
        .cm-grade-item.active .cm-grade-dot { background: #fff; }

        .cm-tabs {
            border-bottom: 1px solid #e8f0fb; display: flex;
            gap: .2rem; padding: .2rem 1rem 0; background: #fff;
        }
        .cm-tab-btn {
            padding: .85rem 1rem; font-size: .88rem; font-weight: 700;
            color: #6b84a2; border: none; background: none; cursor: pointer;
            border-bottom: 3px solid transparent; transition: color .13s, border-color .13s;
        }
        .cm-tab-btn.active { color: #1a6ef5; border-bottom-color: #1a6ef5; }
        .cm-tab-btn:hover:not(.active) { color: #1248a8; }

        .cm-panel { display: none; }
        .cm-panel.active { display: block; }

        .cm-table { width: 100%; border-collapse: collapse; }
        .cm-table thead th {
            background: #f4f8ff; color: #3b5e96; font-size: .73rem;
            font-weight: 700; text-transform: uppercase; letter-spacing: .06em;
            padding: .85rem 1rem; border-bottom: 1px solid #dce8f8; white-space: nowrap;
        }
        .cm-table tbody tr:not(:last-child) td { border-bottom: 1px solid #f0f5fc; }
        .cm-table tbody tr:hover td { background: #f9fbff; }
        .cm-table tbody td { padding: .9rem 1rem; font-size: .92rem; color: #213a5e; vertical-align: middle; }

        .cm-empty { text-align: center; padding: 2.8rem 1rem; color: #9ab0c8; }
        .cm-empty i { font-size: 2.2rem; display: block; margin-bottom: .55rem; opacity: .45; }
        .cm-empty p { margin: 0; font-size: .94rem; }

        .cm-badge {
            display: inline-flex; align-items: center; gap: .3rem;
            padding: .28rem .75rem; border-radius: 999px;
            font-size: .74rem; font-weight: 700; letter-spacing: .02em;
        }
        .cm-badge-active     { background: #eaf2ff; color: #1248a8; border: 1px solid #bdd4fb; }
        .cm-badge-inactive   { background: #f4f5f7; color: #7a8ea8; border: 1px solid #dde4ee; }
        .cm-badge-core       { background: #eaf2ff; color: #1248a8; border: 1px solid #bdd4fb; }
        .cm-badge-applied    { background: #e8fbf2; color: #0a6b47; border: 1px solid #a9e2ca; }
        .cm-badge-specialized{ background: #fff4e9; color: #8a4800; border: 1px solid #f8cf98; }
        .cm-badge-elective   { background: #f5ebff; color: #5b1a96; border: 1px solid #d9b6ff; }

        .cm-pill-row { display: flex; align-items: center; gap: .35rem; flex-wrap: wrap; }
        .cm-pill {
            background: #f0f5fc; border: 1px solid #dbe6f7; border-radius: 8px;
            padding: .18rem .5rem; font-weight: 700; color: #1248a8; font-size: .75rem;
        }

        .cm-btn {
            font-weight: 600; font-size: .82rem; border-radius: 10px;
            padding: .48rem .95rem; cursor: pointer; transition: all .14s;
            border: 1px solid transparent; line-height: 1.4;
        }
        .cm-btn-primary {
            background: linear-gradient(135deg, #1a6ef5, #1248a8);
            color: #fff; box-shadow: 0 6px 14px rgba(26,110,245,.18);
        }
        .cm-btn-primary:hover { background: linear-gradient(135deg, #1560d8, #103d90); color: #fff; }
        .cm-btn-outline { background: #fff; color: #1a6ef5; border-color: #dce8f8; }
        .cm-btn-outline:hover { background: #eef4ff; border-color: #9cc2fc; }
        .cm-btn-danger  { background: #fff5f5; color: #d64545; border-color: #f3c2c2; }
        .cm-btn-danger:hover { background: #ffe8e8; color: #bb2d3b; border-color: #e9a8a8; }
        .cm-btn-sm   { padding: .3rem .65rem; font-size: .78rem; }
        .cm-btn-icon { width: 36px; height: 36px; padding: 0; border-radius: 10px;
                       display: inline-flex; align-items: center; justify-content: center; font-size: .92rem; }
        .cm-btn-group { display: inline-flex; align-items: center; gap: .35rem; justify-content: center; }

        .cm-pagination {
            display: flex; gap: .3rem; list-style: none; margin: 0; padding: 0;
            justify-content: flex-end; flex-wrap: nowrap; white-space: nowrap; min-width: max-content;
        }
        .cm-pagination .cm-page-item .cm-page-link {
            display: inline-flex; align-items: center; justify-content: center;
            min-width: 30px; height: 30px; border-radius: 8px; font-size: .8rem;
            font-weight: 600; cursor: pointer; border: 1px solid #dce8f8;
            color: #1a6ef5; background: #fff; transition: all .13s; padding: 0 .55rem;
        }
        .cm-pagination .cm-page-item .cm-page-link:hover { background: #eef4ff; }
        .cm-pagination .cm-page-item.active .cm-page-link {
            background: #1a6ef5; border-color: #1a6ef5; color: #fff;
        }

        .cm-context { display: flex; align-items: center; gap: .4rem; flex-wrap: wrap; font-size: .8rem; color: #6b84a2; }
        .cm-context-pill {
            background: #eef4ff; color: #1248a8; border-radius: 999px;
            padding: .2rem .65rem; font-weight: 700; font-size: .76rem;
        }

        .cm-modal .modal-content { border: 0; border-radius: 18px; box-shadow: 0 10px 36px rgba(18,72,168,.18); }
        .cm-modal .modal-header {
            background: #f4f8ff; border-bottom: 1px solid #dce8f8;
            border-radius: 18px 18px 0 0; padding: 1rem 1.3rem;
        }
        .cm-modal .modal-title { font-size: 1rem; font-weight: 700; color: #132f62; }
        .cm-modal .modal-body  { padding: 1.2rem; }
        .cm-modal .modal-footer {
            border-top: 1px solid #e8f0fb; padding: .9rem 1.3rem;
            background: #fafcff; border-radius: 0 0 18px 18px;
        }
        .cm-modal .form-label { font-size: .83rem; font-weight: 700; color: #3b5e96; margin-bottom: .35rem; }
        .cm-modal .form-control,
        .cm-modal .form-select {
            border-radius: 12px; border: 1px solid #c8daf8;
            font-size: .92rem; color: #213a5e; min-height: 42px; padding: .5rem .85rem;
        }
        .cm-modal .form-control:focus,
        .cm-modal .form-select:focus { border-color: #1a6ef5; box-shadow: 0 0 0 3px rgba(26,110,245,.1); }

        .cm-slider-row {
            display: grid; grid-template-columns: 130px 1fr 58px;
            align-items: center; gap: .55rem; margin-bottom: .65rem;
        }
        .cm-slider-row label { font-size: .8rem; font-weight: 700; color: #6b84a2; margin: 0; }
        .cm-slider-row input[type=range] { width: 100%; accent-color: #1a6ef5; }
        .cm-slider-value {
            background: #f0f5fc; border: 1px solid #dbe6f7; border-radius: 8px;
            padding: .15rem .45rem; font-weight: 700; color: #1248a8; font-size: .8rem; text-align: center;
        }
        .cm-total {
            text-align: center; font-size: .82rem; font-weight: 700;
            padding: .38rem .55rem; border-radius: 10px; margin-top: .5rem;
        }
        .cm-total.ok     { background: #e6f0ff; color: #1248a8; }
        .cm-total.not-ok { background: #ffe6e6; color: #c0392b; }

        @media (max-width: 767px) {
            .cm-page-header { padding: 1.1rem 1.2rem; border-radius: 14px; }
            .cm-slider-row  { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3">

                <div class="cm-page-header">
                    <div>
                        <h3><i class="bi bi-journal-bookmark-fill me-2"></i>Curriculum Management</h3>
                        <p>Manage grade subjects and curriculum weights from one module.</p>
                    </div>
                    <span class="cm-header-chip"><i class="bi bi-mortarboard-fill"></i> DepEd K–12</span>
                </div>

                <div class="cm-layout">
                    <div>
                        <div class="cm-card">
                            <div class="cm-card-header">
                                <div>
                                    <p class="cm-card-title"><i class="bi bi-diagram-3 me-1"></i>Grade Levels</p>
                                    <p class="cm-card-subtitle">Select a grade to manage its subjects and weights</p>
                                </div>
                                <span id="navSpinner" class="spinner-border spinner-border-sm text-primary" style="display:none;"></span>
                            </div>
                            <div class="cm-tree-wrap" id="gradeNavWrapper">
                                <div class="cm-empty" style="padding:1.6rem 1rem;">
                                    <span class="spinner-border spinner-border-sm me-1"></span> Loading…
                                </div>
                            </div>
                        </div>
                    </div>

                    <div>
                        <div class="cm-card">
                            <div class="cm-tabs">
                                <button class="cm-tab-btn active" onclick="switchTab('subjects', this)">
                                    <i class="bi bi-book me-1"></i>Assigned Subjects
                                </button>
                                <button class="cm-tab-btn" onclick="switchTab('weights', this)">
                                    <i class="bi bi-percent me-1"></i>Curriculum Weights
                                </button>
                            </div>

                            <div id="tab-subjects" class="cm-panel active">
                                <div class="cm-card-header">
                                    <div>
                                        <p class="cm-card-title mb-1" id="subjectsPanelTitle">Select a grade level</p>
                                        <div class="cm-context" id="subjectsCtx"></div>
                                    </div>
                                    <div id="subjectsActions"></div>
                                </div>
                                <div class="d-none d-lg-block">
                                    <table class="cm-table">
                                        <thead>
                                            <tr>
                                                <th style="width:46px;text-align:center;">#</th>
                                                <th>Subject / Learning Area</th>
                                                <th style="width:120px;">Type</th>
                                                <th style="width:110px;text-align:center;">Status</th>
                                                <th style="width:150px;text-align:center;">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody id="subjectsTableBody">
                                            <tr><td colspan="5"><div class="cm-empty"><i class="bi bi-arrow-left-circle"></i><p>Choose a grade from the left panel.</p></div></td></tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="d-block d-lg-none p-3" id="subjectsCards"></div>
                                <div class="cm-card-footer"><ul class="cm-pagination" id="subjectsPagination"></ul></div>
                            </div>

                            <div id="tab-weights" class="cm-panel">
                                <div class="cm-card-header">
                                    <div>
                                        <p class="cm-card-title mb-1" id="weightsPanelTitle">Select a grade level</p>
                                        <div class="cm-context" id="weightsCtx"></div>
                                    </div>
                                    <div id="weightsActions"></div>
                                </div>
                                <div class="d-none d-lg-block">
                                    <table class="cm-table">
                                        <thead>
                                            <tr>
                                                <th style="width:46px;text-align:center;">#</th>
                                                <th>Subject / Learning Area</th>
                                                <th style="width:120px;">Type</th>
                                                <th style="width:220px;">Weights</th>
                                                <th style="width:110px;text-align:center;">Status</th>
                                                <th style="width:150px;text-align:center;">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody id="weightsTableBody">
                                            <tr><td colspan="6"><div class="cm-empty"><i class="bi bi-arrow-left-circle"></i><p>Choose a grade from the left panel.</p></div></td></tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="d-block d-lg-none p-3" id="weightsCards"></div>
                                <div class="cm-card-footer"><ul class="cm-pagination" id="weightsPagination"></ul></div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </main>
    <?php require_once("includes/footer.php"); ?>
</div>

<div class="modal fade cm-modal" id="subjectModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <form id="subjectForm" novalidate>
                <div class="modal-header">
                    <h5 class="modal-title" id="subjectModalTitle"><i class="bi bi-plus-circle me-2"></i>Add Subject</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="sfCurriculumId">
                    <input type="hidden" id="sfGradeLevelId">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Subject Code <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="sfCode" maxlength="50" required>
                        </div>
                        <div class="col-md-8">
                            <label class="form-label">Subject Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="sfName" maxlength="150" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Type</label>
                            <select class="form-select" id="sfType">
                                <option value="CORE">Core</option>
                                <option value="APPLIED">Applied</option>
                                <option value="SPECIALIZED">Specialized</option>
                                <option value="ELECTIVE">Elective</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Status</label>
                            <select class="form-select" id="sfActive">
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" id="sfDescription" rows="3"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="cm-btn cm-btn-outline" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="cm-btn cm-btn-primary" id="btnSaveSubject">
                        <i class="bi bi-check-circle me-1"></i> Save Subject
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade cm-modal" id="weightsModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <form id="weightsForm" novalidate>
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-percent me-2"></i>Edit Curriculum Weights</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="wfCurriculumId">
                    <div class="mb-3">
                        <label class="form-label">Subject</label>
                        <input type="text" class="form-control" id="wfSubjectName" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select class="form-select" id="wfActive">
                            <option value="1">Active</option>
                            <option value="0">Inactive</option>
                        </select>
                    </div>
                    <label class="form-label d-block mb-2">
                        Component Weights <span class="text-muted fw-normal" style="font-size:.8rem;">(must total 100%)</span>
                    </label>
                    <div class="cm-slider-row">
                        <label>Written Work</label>
                        <input type="range" id="wfWW" min="0" max="100" step="5" value="30">
                        <span class="cm-slider-value" id="lblWW">30%</span>
                    </div>
                    <div class="cm-slider-row">
                        <label>Performance Task</label>
                        <input type="range" id="wfPT" min="0" max="100" step="5" value="50">
                        <span class="cm-slider-value" id="lblPT">50%</span>
                    </div>
                    <div class="cm-slider-row">
                        <label>Quarterly Assess.</label>
                        <input type="range" id="wfQA" min="0" max="100" step="5" value="20">
                        <span class="cm-slider-value" id="lblQA">20%</span>
                    </div>
                    <div class="cm-total ok" id="weightsTotal">Total: 100%</div>

                    <div style="margin-top:.75rem;font-size:.78rem;color:#6b84a2;">
                        Presets:
                        <button type="button" class="btn btn-sm btn-link p-0 ms-1" style="font-size:.78rem;" onclick="applyWeightPreset(30,50,20)">Languages/AP/EsP (30/50/20)</button> ·
                        <button type="button" class="btn btn-sm btn-link p-0" style="font-size:.78rem;" onclick="applyWeightPreset(40,40,20)">Science/Math (40/40/20)</button> ·
                        <button type="button" class="btn btn-sm btn-link p-0" style="font-size:.78rem;" onclick="applyWeightPreset(20,60,20)">MAPEH/EPP/TLE (20/60/20)</button> ·
                        <button type="button" class="btn btn-sm btn-link p-0" style="font-size:.78rem;" onclick="applyWeightPreset(25,50,25)">SHS Core (25/50/25)</button>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="cm-btn cm-btn-outline" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="cm-btn cm-btn-primary" id="btnSaveWeights">
                        <i class="bi bi-check-circle me-1"></i> Save Weights
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>
<script>
const APP_BASE = '/Lstsngsv1';

let activeGradeId = null;
let activeGrade   = null;
let currentTab    = 'subjects';
let subjectsCache = [];
let weightsCache  = [];

function toast(msg, type = 'success') {
    const map = {
        success: { title: 'Success', color: 'green',  icon: 'bi bi-check-circle-fill' },
        danger:  { title: 'Error',   color: 'red',    icon: 'bi bi-exclamation-octagon-fill' },
        warning: { title: 'Warning', color: 'yellow', icon: 'bi bi-exclamation-triangle-fill' },
        info:    { title: 'Info',    color: 'blue',   icon: 'bi bi-info-circle-fill' },
    };
    const c = map[type] || map.success;

    iziToast.show({
        title: c.title,
        message: msg,
        color: c.color,
        icon: c.icon,
        iconColor: '#fff',
        theme: 'light',
        position: 'topRight',
        timeout: 4000,
        progressBar: true,
        close: true,
        pauseOnHover: true,
        transitionIn: 'fadeInDown',
        transitionOut: 'fadeOutUp'
    });
}

function confirmAction(message, onYes) {
    iziToast.destroy();

    iziToast.question({
        timeout: 20000,
        close: false,
        overlay: true,
        displayMode: 'once',
        zindex: 99999,
        title: 'Confirm Delete',
        message: message,
        position: 'center',
        color: 'blue',
        icon: 'bi bi-question-circle-fill',
        drag: false,
        buttons: [
            [
                '<button><b>Yes, Delete</b></button>',
                function (instance, toastRef) {
                    instance.hide({ transitionOut: 'fadeOut' }, toastRef, 'button');
                    onYes();
                },
                true
            ],
            [
                '<button>Cancel</button>',
                function (instance, toastRef) {
                    instance.hide({ transitionOut: 'fadeOut' }, toastRef, 'button');
                }
            ]
        ]
    });
}

async function api(url, opts = {}) {
    console.log('API request URL:', url);
    console.log('API request opts:', opts);

    const response = await fetch(url, opts);
    const raw = await response.text();

    console.log('API raw response:', raw);

    try {
        return JSON.parse(raw);
    } catch (err) {
        throw new Error(`Invalid server response from ${url}`);
    }
}

function escapeHtml(v) {
    return String(v ?? '')
        .replaceAll('&','&amp;')
        .replaceAll('<','&lt;')
        .replaceAll('>','&gt;')
        .replaceAll('"','&quot;')
        .replaceAll("'","&#039;");
}

function typeBadge(type) {
    const m = {
        CORE:        ['cm-badge-core',        'Core'],
        APPLIED:     ['cm-badge-applied',     'Applied'],
        SPECIALIZED: ['cm-badge-specialized', 'Specialized'],
        ELECTIVE:    ['cm-badge-elective',    'Elective'],
    };
    const [cls, lbl] = m[type] || m.CORE;
    return `<span class="cm-badge ${cls}">${lbl}</span>`;
}

function deriveLevelLabel(id) {
    if (id === 1) return 'Kinder';
    if (id >= 2 && id <= 7) return 'Elementary';
    if (id >= 8 && id <= 11) return 'Junior High School';
    if (id >= 12 && id <= 13) return 'Senior High School';
    return '';
}

function switchTab(name, btn) {
    currentTab = name;
    document.querySelectorAll('.cm-panel').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.cm-tab-btn').forEach(b => b.classList.remove('active'));
    document.getElementById('tab-' + name).classList.add('active');
    btn.classList.add('active');

    if (!activeGradeId) return;

    if (name === 'subjects') {
        loadAssignedSubjects(activeGradeId);
    } else {
        loadCurriculumWeights(activeGradeId);
    }
}

async function loadTree() {
    document.getElementById('navSpinner').style.display = 'inline-block';

    try {
        const d = await api(`${APP_BASE}/api/curriculum/structure.php`);
        if (!d.success) throw new Error(d.error || 'Failed to load structure.');
        renderTree(d.data || []);
    } catch (e) {
        toast(e.message, 'danger');
        document.getElementById('gradeNavWrapper').innerHTML =
            `<div class="cm-empty"><i class="bi bi-exclamation-circle"></i><p>${escapeHtml(e.message)}</p></div>`;
    } finally {
        document.getElementById('navSpinner').style.display = 'none';
    }
}

function renderTree(tree) {
    const wrap = document.getElementById('gradeNavWrapper');
    wrap.innerHTML = '';

    const icons = {
        KINDER: 'bi-emoji-smile',
        ELEM: 'bi-123',
        JHS: 'bi-building',
        SHS: 'bi-mortarboard'
    };

    tree.forEach(level => {
        const det = document.createElement('details');
        det.className = 'cm-tree-level';
        det.open = true;

        const sum = document.createElement('summary');
        sum.innerHTML = `
            <i class="bi bi-chevron-right cm-caret"></i>
            <i class="bi ${icons[level.code] || 'bi-circle'} me-1"></i>${escapeHtml(level.label)}
        `;
        det.appendChild(sum);

        (level.grades || []).forEach(g => det.appendChild(gradeItem(g)));
        wrap.appendChild(det);
    });

    const first = document.querySelector('.cm-grade-item');
    if (first) first.click();
}

function gradeItem(g) {
    const d = document.createElement('div');
    d.className = 'cm-grade-item';
    d.dataset.gid = g.id;
    d.innerHTML = `<span class="cm-grade-dot"></span>${escapeHtml(g.grade_label)}`;
    d.addEventListener('click', () => selectGrade(g));
    return d;
}

function selectGrade(g) {
    document.querySelectorAll('.cm-grade-item').forEach(el => el.classList.remove('active'));
    document.querySelector(`.cm-grade-item[data-gid="${g.id}"]`)?.classList.add('active');

    activeGradeId = Number(g.id);
    activeGrade = {
        id: Number(g.id),
        grade_label: g.grade_label,
        level_label: deriveLevelLabel(Number(g.id))
    };

    if (currentTab === 'subjects') {
        loadAssignedSubjects(activeGradeId);
    } else {
        loadCurriculumWeights(activeGradeId);
    }
}

async function loadAssignedSubjects(gradeId) {
    document.getElementById('subjectsTableBody').innerHTML =
        `<tr><td colspan="5"><div class="cm-empty"><span class="spinner-border spinner-border-sm me-1"></span>Loading…</div></td></tr>`;

    try {
        const d = await api(`${APP_BASE}/api/curriculum/assigned_subjects.php?grade_id=${gradeId}`);
        if (!d.success) throw new Error(d.error || 'Failed to load subjects.');

        activeGrade = d.grade || activeGrade;
        subjectsCache = d.subjects || [];
        renderAssignedSubjects(subjectsCache, activeGrade);
    } catch (e) {
        toast(e.message, 'danger');
    }
}

function renderAssignedSubjects(list, grade) {
    document.getElementById('subjectsPanelTitle').textContent = `${grade.grade_label || ''} — Assigned Subjects`;
    document.getElementById('subjectsCtx').innerHTML = grade.level_label
        ? `<span class="cm-context-pill">${escapeHtml(grade.level_label)}</span>`
        : '';

    document.getElementById('subjectsActions').innerHTML = `
        <button type="button" class="cm-btn cm-btn-primary" onclick="openSubjectModal()">
            <i class="bi bi-plus-circle me-1"></i> Add Subject
        </button>
    `;

    const tbody = document.getElementById('subjectsTableBody');
    const cards = document.getElementById('subjectsCards');

    if (!list.length) {
        const emptyHtml = `<div class="cm-empty"><i class="bi bi-book"></i><p>No subjects yet. Click <strong>Add Subject</strong> to start.</p></div>`;
        tbody.innerHTML = `<tr><td colspan="5">${emptyHtml}</td></tr>`;
        cards.innerHTML = emptyHtml;
        return;
    }

    tbody.innerHTML = list.map((s, i) => `
        <tr>
            <td style="text-align:center;color:#9ab0c8;font-size:.79rem;">${i + 1}</td>
            <td>
                <div style="font-weight:700;color:#1b3558;">${escapeHtml(s.subject_name)}</div>
                <div style="font-size:.76rem;color:#6b84a2;">${escapeHtml(s.subject_code)}</div>
            </td>
            <td>${typeBadge(s.subject_type)}</td>
            <td style="text-align:center;">
                <span class="cm-badge ${Number(s.is_active) === 1 ? 'cm-badge-active' : 'cm-badge-inactive'}">
                    ${Number(s.is_active) === 1 ? '<i class="bi bi-check-circle-fill"></i> Active' : 'Inactive'}
                </span>
            </td>
            <td style="text-align:center;">
                <div class="cm-btn-group">
                    <button
                        type="button"
                        class="cm-btn cm-btn-outline cm-btn-icon js-edit-subject"
                        data-id="${Number(s.curriculum_id)}"
                        title="Edit">
                        <i class="bi bi-pencil-square"></i>
                    </button>
                    <button
                        type="button"
                        class="cm-btn cm-btn-danger cm-btn-icon js-delete-subject"
                        data-id="${Number(s.curriculum_id)}"
                        data-name="${escapeHtml(s.subject_name)}"
                        title="Delete">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');

    cards.innerHTML = list.map(s => `
        <div style="background:#fff;border:1px solid #dce8f8;border-radius:14px;margin-bottom:.75rem;overflow:hidden;">
            <div style="padding:.8rem 1rem;border-bottom:1px solid #edf3fc;background:#f9fbff;display:flex;justify-content:space-between;align-items:center;">
                <div>
                    <div style="font-weight:700;color:#1b3558;">${escapeHtml(s.subject_name)}</div>
                    <div style="font-size:.75rem;color:#6b84a2;">${escapeHtml(s.subject_code)}</div>
                </div>
                ${typeBadge(s.subject_type)}
            </div>
            <div style="padding:.85rem 1rem;">
                <div class="cm-pill-row mb-2">
                    <span class="cm-badge ${Number(s.is_active) === 1 ? 'cm-badge-active' : 'cm-badge-inactive'}">
                        ${Number(s.is_active) === 1 ? 'Active' : 'Inactive'}
                    </span>
                </div>
                <div style="display:flex;gap:.35rem;flex-wrap:wrap;">
                    <button
                        type="button"
                        class="cm-btn cm-btn-outline cm-btn-sm js-edit-subject"
                        data-id="${Number(s.curriculum_id)}">
                        <i class="bi bi-pencil-square me-1"></i>Edit
                    </button>
                    <button
                        type="button"
                        class="cm-btn cm-btn-danger cm-btn-sm js-delete-subject"
                        data-id="${Number(s.curriculum_id)}"
                        data-name="${escapeHtml(s.subject_name)}">
                        <i class="bi bi-trash me-1"></i>Delete
                    </button>
                </div>
            </div>
        </div>
    `).join('');

    document.getElementById('subjectsPagination').innerHTML = '';
}

function openSubjectModalById(id) {
    const row = subjectsCache.find(x => Number(x.curriculum_id) === Number(id));
    if (!row) {
        toast('Subject not found.', 'warning');
        return;
    }
    openSubjectModal(row);
}

function openSubjectModal(row = null) {
    if (!activeGradeId) {
        toast('Select a grade first.', 'warning');
        return;
    }

    document.getElementById('sfCurriculumId').value = row ? row.curriculum_id : '';
    document.getElementById('sfGradeLevelId').value = row ? (row.grade_level_id || activeGradeId) : activeGradeId;
    document.getElementById('sfCode').value = row ? (row.subject_code || '') : '';
    document.getElementById('sfName').value = row ? (row.subject_name || '') : '';
    document.getElementById('sfType').value = row ? (row.subject_type || 'CORE') : 'CORE';
    document.getElementById('sfDescription').value = row ? (row.description || '') : '';
    document.getElementById('sfActive').value = row ? Number(row.is_active ?? 1) : 1;

    document.getElementById('subjectModalTitle').innerHTML = row
        ? '<i class="bi bi-pencil-square me-2"></i>Edit Subject'
        : '<i class="bi bi-plus-circle me-2"></i>Add Subject';

    bootstrap.Modal.getOrCreateInstance(document.getElementById('subjectModal')).show();
}

document.getElementById('subjectForm').addEventListener('submit', async function (e) {
    e.preventDefault();

    const payload = {
        curriculum_id: document.getElementById('sfCurriculumId').value || null,
        grade_level_id: Number(document.getElementById('sfGradeLevelId').value || 0),
        subject_code: document.getElementById('sfCode').value.trim(),
        subject_name: document.getElementById('sfName').value.trim(),
        subject_type: document.getElementById('sfType').value,
        description: document.getElementById('sfDescription').value.trim(),
        is_active: Number(document.getElementById('sfActive').value || 1),
    };

    const btn = document.getElementById('btnSaveSubject');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Saving…';

    try {
        const res = await api(`${APP_BASE}/api/curriculum/save_subject.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (res.success) {
            bootstrap.Modal.getInstance(document.getElementById('subjectModal')).hide();
            toast(res.message || 'Subject saved.');
            loadAssignedSubjects(activeGradeId);
        } else {
            toast(res.error || 'Save failed.', 'danger');
        }
    } catch (err) {
        toast(err.message, 'danger');
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-check-circle me-1"></i> Save Subject';
    }
});

async function loadCurriculumWeights(gradeId) {
    document.getElementById('weightsTableBody').innerHTML =
        `<tr><td colspan="6"><div class="cm-empty"><span class="spinner-border spinner-border-sm me-1"></span>Loading…</div></td></tr>`;

    try {
        const d = await api(`${APP_BASE}/api/curriculum/curriculum_weights.php?grade_id=${gradeId}`);
        if (!d.success) throw new Error(d.error || 'Failed to load weights.');

        activeGrade = d.grade || activeGrade;
        weightsCache = d.curriculum || [];
        renderCurriculumWeights(weightsCache, activeGrade);
    } catch (e) {
        toast(e.message, 'danger');
    }
}

function renderCurriculumWeights(list, grade) {
    document.getElementById('weightsPanelTitle').textContent = `${grade.grade_label || ''} — Curriculum Weights`;
    document.getElementById('weightsCtx').innerHTML = grade.level_label
        ? `<span class="cm-context-pill">${escapeHtml(grade.level_label)}</span>`
        : '';

    document.getElementById('weightsActions').innerHTML = '';

    const tbody = document.getElementById('weightsTableBody');
    const cards = document.getElementById('weightsCards');

    if (!list.length) {
        const emptyHtml = `<div class="cm-empty"><i class="bi bi-percent"></i><p>No weights yet. Add subjects in <strong>Assigned Subjects</strong> first.</p></div>`;
        tbody.innerHTML = `<tr><td colspan="6">${emptyHtml}</td></tr>`;
        cards.innerHTML = emptyHtml;
        return;
    }

    tbody.innerHTML = list.map((row, i) => `
        <tr>
            <td style="text-align:center;color:#9ab0c8;font-size:.79rem;">${i + 1}</td>
            <td>
                <div style="font-weight:700;color:#1b3558;">${escapeHtml(row.subject_name)}</div>
                <div style="font-size:.76rem;color:#6b84a2;">${escapeHtml(row.subject_code)}</div>
            </td>
            <td>${typeBadge(row.subject_type)}</td>
            <td>
                <div class="cm-pill-row">
                    <span class="cm-pill">WW ${Number(row.ww)}%</span>
                    <span class="cm-pill">PT ${Number(row.pt)}%</span>
                    <span class="cm-pill">QA ${Number(row.qa)}%</span>
                </div>
            </td>
            <td style="text-align:center;">
                <span class="cm-badge ${Number(row.is_active) === 1 ? 'cm-badge-active' : 'cm-badge-inactive'}">
                    ${Number(row.is_active) === 1 ? '<i class="bi bi-check-circle-fill"></i> Active' : 'Inactive'}
                </span>
            </td>
            <td style="text-align:center;">
                <div class="cm-btn-group">
                    <button
                        type="button"
                        class="cm-btn cm-btn-outline cm-btn-icon js-edit-weights"
                        data-id="${Number(row.curriculum_id)}"
                        title="Edit Weights">
                        <i class="bi bi-sliders"></i>
                    </button>
                    <button
                        type="button"
                        class="cm-btn cm-btn-danger cm-btn-icon js-delete-weights"
                        data-id="${Number(row.curriculum_id)}"
                        data-name="${escapeHtml(row.subject_name)}"
                        title="Delete">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');

    cards.innerHTML = list.map(row => `
        <div style="background:#fff;border:1px solid #dce8f8;border-radius:14px;margin-bottom:.75rem;overflow:hidden;">
            <div style="padding:.8rem 1rem;border-bottom:1px solid #edf3fc;background:#f9fbff;display:flex;justify-content:space-between;align-items:center;">
                <div>
                    <div style="font-weight:700;color:#1b3558;">${escapeHtml(row.subject_name)}</div>
                    <div style="font-size:.75rem;color:#6b84a2;">${escapeHtml(row.subject_code)}</div>
                </div>
                ${typeBadge(row.subject_type)}
            </div>
            <div style="padding:.85rem 1rem;">
                <div class="cm-pill-row mb-2">
                    <span class="cm-pill">WW ${Number(row.ww)}%</span>
                    <span class="cm-pill">PT ${Number(row.pt)}%</span>
                    <span class="cm-pill">QA ${Number(row.qa)}%</span>
                    <span class="cm-badge ${Number(row.is_active) === 1 ? 'cm-badge-active' : 'cm-badge-inactive'}">
                        ${Number(row.is_active) === 1 ? 'Active' : 'Inactive'}
                    </span>
                </div>
                <div style="display:flex;gap:.35rem;flex-wrap:wrap;">
                    <button
                        type="button"
                        class="cm-btn cm-btn-outline cm-btn-sm js-edit-weights"
                        data-id="${Number(row.curriculum_id)}">
                        <i class="bi bi-sliders me-1"></i>Edit Weights
                    </button>
                    <button
                        type="button"
                        class="cm-btn cm-btn-danger cm-btn-sm js-delete-weights"
                        data-id="${Number(row.curriculum_id)}"
                        data-name="${escapeHtml(row.subject_name)}">
                        <i class="bi bi-trash me-1"></i>Delete
                    </button>
                </div>
            </div>
        </div>
    `).join('');

    document.getElementById('weightsPagination').innerHTML = '';
}

function openWeightsModalById(id) {
    const row = weightsCache.find(x => Number(x.curriculum_id) === Number(id));
    if (!row) {
        toast('Record not found.', 'warning');
        return;
    }
    openWeightsModal(row);
}

function openWeightsModal(row) {
    document.getElementById('wfCurriculumId').value = row.curriculum_id;
    document.getElementById('wfSubjectName').value = `${row.subject_name} (${row.subject_code})`;
    document.getElementById('wfActive').value = Number(row.is_active ?? 1);

    document.getElementById('wfWW').value = Number(row.ww ?? 30);
    document.getElementById('wfPT').value = Number(row.pt ?? 50);
    document.getElementById('wfQA').value = Number(row.qa ?? 20);
    syncWeightDisplay();

    bootstrap.Modal.getOrCreateInstance(document.getElementById('weightsModal')).show();
}

function syncWeightDisplay() {
    const ww = Number(document.getElementById('wfWW').value);
    const pt = Number(document.getElementById('wfPT').value);
    const qa = Number(document.getElementById('wfQA').value);

    document.getElementById('lblWW').textContent = `${ww}%`;
    document.getElementById('lblPT').textContent = `${pt}%`;
    document.getElementById('lblQA').textContent = `${qa}%`;

    const sum = ww + pt + qa;
    const total = document.getElementById('weightsTotal');
    total.textContent = `Total: ${sum}%`;
    total.className = `cm-total ${sum === 100 ? 'ok' : 'not-ok'}`;
}

function applyWeightPreset(ww, pt, qa) {
    document.getElementById('wfWW').value = ww;
    document.getElementById('wfPT').value = pt;
    document.getElementById('wfQA').value = qa;
    syncWeightDisplay();
}

['wfWW','wfPT','wfQA'].forEach(id =>
    document.getElementById(id).addEventListener('input', syncWeightDisplay)
);

document.getElementById('weightsForm').addEventListener('submit', async function (e) {
    e.preventDefault();

    const ww = Number(document.getElementById('wfWW').value);
    const pt = Number(document.getElementById('wfPT').value);
    const qa = Number(document.getElementById('wfQA').value);

    if (ww + pt + qa !== 100) {
        toast('Weights must total 100%.', 'warning');
        return;
    }

    const payload = {
        curriculum_id: Number(document.getElementById('wfCurriculumId').value),
        ww,
        pt,
        qa,
        is_active: Number(document.getElementById('wfActive').value || 1),
    };

    const btn = document.getElementById('btnSaveWeights');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Saving…';

    try {
        const res = await api(`${APP_BASE}/api/curriculum/save_weights.php`, {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify(payload)
        });

        if (res.success) {
            bootstrap.Modal.getInstance(document.getElementById('weightsModal')).hide();
            toast(res.message || 'Weights updated.');
            loadCurriculumWeights(activeGradeId);
        } else {
            toast(res.error || 'Save failed.', 'danger');
        }
    } catch (err) {
        toast(err.message, 'danger');
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-check-circle me-1"></i> Save Weights';
    }
});

document.addEventListener('click', function (e) {
    const editSubjectBtn = e.target.closest('.js-edit-subject');
    if (editSubjectBtn) {
        const id = Number(editSubjectBtn.dataset.id || 0);
        console.log('edit subject clicked:', id);
        if (id > 0) openSubjectModalById(id);
        return;
    }

    const deleteSubjectBtn = e.target.closest('.js-delete-subject');
    if (deleteSubjectBtn) {
        const id = Number(deleteSubjectBtn.dataset.id || 0);
        const name = deleteSubjectBtn.dataset.name || '';
        console.log('delete subject clicked:', { id, name });

        if (id <= 0) {
            toast('Invalid subject record.', 'danger');
            return;
        }

        confirmAction(`Delete <b>${name}</b> from this grade?`, async () => {
            try {
                const res = await api(`${APP_BASE}/api/curriculum/delete_subject.php`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ curriculum_id: id })
                });

                console.log('delete_subject response:', res);

                if (res.success) {
                    toast(res.message || 'Deleted.');
                    loadAssignedSubjects(activeGradeId);
                } else {
                    toast(res.error || 'Delete failed.', 'danger');
                }
            } catch (err) {
                console.error('delete subject error:', err);
                toast(err.message || 'Delete request failed.', 'danger');
            }
        });
        return;
    }

    const editWeightsBtn = e.target.closest('.js-edit-weights');
    if (editWeightsBtn) {
        const id = Number(editWeightsBtn.dataset.id || 0);
        console.log('edit weights clicked:', id);
        if (id > 0) openWeightsModalById(id);
        return;
    }

    const deleteWeightsBtn = e.target.closest('.js-delete-weights');
    if (deleteWeightsBtn) {
        const id = Number(deleteWeightsBtn.dataset.id || 0);
        const name = deleteWeightsBtn.dataset.name || '';
        console.log('delete weights clicked:', { id, name });

        if (id <= 0) {
            toast('Invalid curriculum record.', 'danger');
            return;
        }

        confirmAction(`Delete curriculum record for <b>${name}</b>?`, async () => {
            try {
                const res = await api(`${APP_BASE}/api/curriculum/delete_weights.php`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ curriculum_id: id })
                });

                console.log('delete_weights response:', res);

                if (res.success) {
                    toast(res.message || 'Deleted.');
                    loadCurriculumWeights(activeGradeId);
                } else {
                    toast(res.error || 'Delete failed.', 'danger');
                }
            } catch (err) {
                console.error('delete weights error:', err);
                toast(err.message || 'Delete request failed.', 'danger');
            }
        });
        return;
    }
});

loadTree();
</script>
</body>
</html>