<?php
require_once __DIR__ . '/api/shared/db_connect.php';

$id   = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$edit = ($id > 0);

if ($edit) {
    $stmt = $pdo->prepare('SELECT * FROM vwStudentInfo WHERE id = ? AND is_active = 1');
    $stmt->execute([$id]);
    $old = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$old) {
        header('Location: student.php?error=Not found');
        exit;
    }
} else {
    $old = [];
}

$grades    = $pdo->query('SELECT id, grade_level_name FROM tblGradeLevel ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
$countries = $pdo->query('SELECT id, country_name FROM tblCountry ORDER BY country_name')->fetchAll(PDO::FETCH_ASSOC);
$regions   = $pdo->query('SELECT id, region_name, country_id FROM tblRegion ORDER BY region_name')->fetchAll(PDO::FETCH_ASSOC);
$provinces = $pdo->query('SELECT id, province_name, region_id FROM tblProvince ORDER BY province_name')->fetchAll(PDO::FETCH_ASSOC);
$cities    = $pdo->query('SELECT id, city_name, province_id FROM tblCity ORDER BY city_name')->fetchAll(PDO::FETCH_ASSOC);
$barangays = $pdo->query('SELECT id, barangay_name, city_id FROM tblBarangay ORDER BY barangay_name')->fetchAll(PDO::FETCH_ASSOC);

$oldCountry  = $old['country_id'] ?? '';
$oldRegion   = $old['region_id'] ?? '';
$oldProvince = $old['province_id'] ?? '';
$oldCity     = $old['city_id'] ?? '';
$oldBarangay = $old['barangay_id'] ?? '';

$toastType = null;
$toastMessage = '';

if (isset($_GET['duplicate'])) {
    $toastType = 'danger';
    $toastMessage = 'LRN already exists!';
} elseif (isset($_GET['error'])) {
    $toastType = 'danger';
    $toastMessage = (string) $_GET['error'];
} elseif (isset($_GET['msg'])) {
    $toastType = 'success';
    $toastMessage = (string) $_GET['msg'];
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Student</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">

    <style>
        body {
            background: #f3f7fd;
        }

        .student-form-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }

        .student-form-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 0.2rem;
            letter-spacing: 0.01em;
        }

        .student-form-header p {
            margin: 0;
            font-size: 0.88rem;
            opacity: 0.85;
        }

        .student-form-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            background: rgba(255, 255, 255, 0.15);
            border: 1.5px solid rgba(255, 255, 255, 0.3);
            border-radius: 999px;
            padding: 0.45rem 1rem;
            font-size: 0.88rem;
            font-weight: 700;
            color: #fff;
            white-space: nowrap;
        }

        .student-form-chip i {
            font-size: 0.9rem;
            opacity: 0.9;
        }

        .student-form-shell {
            background: #fff;
            border: 1px solid #dce8f8;
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18, 72, 168, 0.06);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }

        .student-form-shell-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid #e8f0fb;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
            background: #fff;
        }

        .student-form-shell-title {
            font-size: 1rem;
            font-weight: 700;
            color: #132f62;
            margin: 0 0 0.15rem;
        }

        .student-form-shell-subtitle {
            font-size: 0.8rem;
            color: #7a93b8;
            margin: 0;
        }

        .student-form-shell-body {
            padding: 1.35rem;
        }

        .form-inline-alert {
            display: none;
            background: #fff8e1;
            border: 1.5px solid #ffe082;
            color: #8a6d00;
            border-radius: 14px;
            padding: 1rem 1.1rem;
            margin-bottom: 1rem;
        }

        .form-inline-alert.show {
            display: block;
        }

        .form-inline-alert .alert-title {
            font-weight: 700;
            color: #7a5a00;
            margin-bottom: 0.45rem;
            display: flex;
            align-items: center;
            gap: 0.45rem;
        }

        .form-inline-alert ul {
            margin: 0;
            padding-left: 1.2rem;
        }

        .student-section-card {
            background: #fff;
            border: 1px solid #dce8f8;
            border-radius: 16px;
            box-shadow: 0 1px 8px rgba(18, 72, 168, 0.05);
            overflow: hidden;
            height: 100%;
        }

        .student-section-header {
            padding: 1rem 1.2rem;
            border-bottom: 1px solid #e8f0fb;
            background: #f9fbff;
            display: flex;
            align-items: center;
            gap: 0.65rem;
        }

        .student-section-icon {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            background: #e8f1ff;
            color: #1248a8;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 1rem;
            flex-shrink: 0;
        }

        .student-section-title {
            margin: 0;
            font-size: 0.98rem;
            font-weight: 700;
            color: #132f62;
        }

        .student-section-subtitle {
            margin: 0.1rem 0 0;
            font-size: 0.78rem;
            color: #7a93b8;
        }

        .student-section-body {
            padding: 1.2rem;
        }

        .form-label-stsn {
            font-size: 0.85rem;
            font-weight: 700;
            color: #3b5e96;
            margin-bottom: 0.42rem;
        }

        .form-label-stsn .text-danger {
            font-weight: 700;
        }

        .form-control,
        .form-select {
            border-radius: 10px;
            border: 1.5px solid #c8daf8;
            min-height: 42px;
            font-size: 0.9rem;
            color: #213a5e;
            padding: 0.45rem 0.85rem;
            box-shadow: none;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.12);
        }

        .form-note {
            font-size: 0.78rem;
            color: #8fa8c8;
            margin-top: 0.45rem;
        }

        .student-form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 0.65rem;
            flex-wrap: wrap;
            padding-top: 1.25rem;
        }

        .btn-stsn {
            font-weight: 600;
            font-size: 0.84rem;
            border-radius: 8px;
            padding: 0.55rem 1rem;
            cursor: pointer;
            transition: background 0.15s, border-color 0.15s, color 0.15s, box-shadow 0.15s;
            border: 1.5px solid transparent;
            line-height: 1.4;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.4rem;
        }

        .btn-stsn-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            border-color: transparent;
            box-shadow: 0 2px 8px rgba(26, 110, 245, 0.2);
        }

        .btn-stsn-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
            box-shadow: 0 3px 12px rgba(26, 110, 245, 0.3);
        }

        .btn-stsn-secondary {
            background: #fff;
            color: #5a7299;
            border-color: #dce8f8;
        }

        .btn-stsn-secondary:hover {
            background: #f5f9ff;
            color: #3f5f8c;
            border-color: #bfd4f5;
        }

        .student-breadcrumb {
            font-size: 0.84rem;
            color: #7a93b8;
            margin-bottom: 1rem;
        }

        .student-breadcrumb a {
            color: #1a6ef5;
            text-decoration: none;
        }

        .student-breadcrumb a:hover {
            text-decoration: underline;
        }

        @media (max-width: 767.98px) {
            .student-form-header {
                padding: 1.1rem 1.2rem;
                border-radius: 14px;
            }

            .student-form-shell-body {
                padding: 1rem;
            }

            .student-section-body {
                padding: 1rem;
            }

            .student-form-actions {
                flex-direction: column;
            }

            .student-form-actions .btn-stsn {
                width: 100%;
            }
        }
    </style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <div class="app-wrapper">
        <?php require_once("includes/header.php"); ?>
        <?php require_once("includes/sidebar.php"); ?>

        <main class="app-main">
            <div class="app-content">
                <div class="container-fluid py-3">

                    <div class="student-breadcrumb">
                        <a href="#">Home</a> / Users / <?= $edit ? 'Edit Student' : 'Add Student' ?>
                    </div>

                    <div class="student-form-header">
                        <div>
                            <h3><i class="bi bi-person-plus-fill me-2"></i><?= $edit ? 'Edit Student' : 'Add Student' ?></h3>
                            <p>Manage student profile details, parent or guardian information, and full address records.</p>
                        </div>
                        <div class="student-form-chip">
                            <i class="bi bi-person-vcard-fill"></i>
                            <?= $edit ? 'Editing Student Record' : 'New Student Record' ?>
                        </div>
                    </div>

                    <div class="student-form-shell">
                        <div class="student-form-shell-header">
                            <div>
                                <p class="student-form-shell-title">Student Information Form</p>
                                <p class="student-form-shell-subtitle">Complete all required details before saving the student record.</p>
                            </div>
                        </div>

                        <div class="student-form-shell-body">
                            <form method="post" action="api/student/save.php" class="needs-validation" novalidate id="studentForm">
                                <input type="hidden" name="id" value="<?= (int) $id ?>">

                                <div class="form-inline-alert" id="validationAlert">
                                    <div class="alert-title">
                                        <i class="bi bi-exclamation-triangle-fill"></i>
                                        Please fill in the following fields:
                                    </div>
                                    <ul id="validationList"></ul>
                                </div>

                                <div class="row g-4">
                                    <div class="col-lg-6">
                                        <div class="student-section-card">
                                            <div class="student-section-header">
                                                <div class="student-section-icon">
                                                    <i class="bi bi-person"></i>
                                                </div>
                                                <div>
                                                    <h3 class="student-section-title">Student Info</h3>
                                                    <p class="student-section-subtitle">Basic profile and school details.</p>
                                                </div>
                                            </div>

                                            <div class="student-section-body">
                                                <div class="row g-3">
                                                    <div class="col-md-6">
                                                        <label class="form-label-stsn">LRN <span class="text-danger">*</span></label>
                                                        <input
                                                            type="text"
                                                            class="form-control"
                                                            name="lrn"
                                                            required
                                                            value="<?= htmlspecialchars($old['lrn'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                                                    </div>

                                                    <div class="col-md-6">
                                                        <label class="form-label-stsn">Grade Level <span class="text-danger">*</span></label>
                                                        <select class="form-select" name="grade_level_id" required>
                                                            <option value="">Select Grade</option>
                                                            <?php foreach ($grades as $g): ?>
                                                                <option value="<?= (int) $g['id'] ?>" <?= (($old['grade_level_id'] ?? '') == $g['id']) ? 'selected' : '' ?>>
                                                                    <?= htmlspecialchars($g['grade_level_name'], ENT_QUOTES, 'UTF-8') ?>
                                                                </option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <label class="form-label-stsn">First Name <span class="text-danger">*</span></label>
                                                        <input
                                                            type="text"
                                                            class="form-control"
                                                            name="fname"
                                                            required
                                                            value="<?= htmlspecialchars($old['fname'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                                                    </div>

                                                    <div class="col-md-4">
                                                        <label class="form-label-stsn">Middle Name</label>
                                                        <input
                                                            type="text"
                                                            class="form-control"
                                                            name="mname"
                                                            value="<?= htmlspecialchars($old['mname'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                                                    </div>

                                                    <div class="col-md-4">
                                                        <label class="form-label-stsn">Last Name <span class="text-danger">*</span></label>
                                                        <input
                                                            type="text"
                                                            class="form-control"
                                                            name="lname"
                                                            required
                                                            value="<?= htmlspecialchars($old['lname'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                                                    </div>

                                                    <div class="col-md-4">
                                                        <label class="form-label-stsn">Birthdate <span class="text-danger">*</span></label>
                                                        <input
                                                            type="date"
                                                            class="form-control"
                                                            name="birthdate"
                                                            required
                                                            value="<?= htmlspecialchars($old['birthdate'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                                                    </div>

                                                    <div class="col-md-4">
                                                        <label class="form-label-stsn">Sex <span class="text-danger">*</span></label>
                                                        <select class="form-select" name="gender" required>
                                                            <option value="">Select</option>
                                                            <option value="Male" <?= (($old['gender'] ?? '') === 'Male') ? 'selected' : '' ?>>Male</option>
                                                            <option value="Female" <?= (($old['gender'] ?? '') === 'Female') ? 'selected' : '' ?>>Female</option>
                                                        </select>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <label class="form-label-stsn">Citizenship</label>
                                                        <input
                                                            type="text"
                                                            class="form-control"
                                                            name="citizenship"
                                                            value="<?= htmlspecialchars($old['citizenship'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="student-section-card">
                                            <div class="student-section-header">
                                                <div class="student-section-icon">
                                                    <i class="bi bi-people"></i>
                                                </div>
                                                <div>
                                                    <h3 class="student-section-title">Parents / Guardian</h3>
                                                    <p class="student-section-subtitle">Primary contacts and emergency support details.</p>
                                                </div>
                                            </div>

                                            <div class="student-section-body">
                                                <div class="row g-3">
                                                    <div class="col-md-6">
                                                        <label class="form-label-stsn">Father's Name <span class="text-danger">*</span></label>
                                                        <input
                                                            type="text"
                                                            class="form-control"
                                                            name="fathers_name"
                                                            required
                                                            value="<?= htmlspecialchars($old['fathers_name'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                                                    </div>

                                                    <div class="col-md-6">
                                                        <label class="form-label-stsn">Father's Contact <span class="text-danger">*</span></label>
                                                        <input
                                                            type="text"
                                                            class="form-control"
                                                            name="fathers_contact_num"
                                                            required
                                                            value="<?= htmlspecialchars($old['fathers_contact_num'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                                                    </div>

                                                    <div class="col-md-6">
                                                        <label class="form-label-stsn">Mother's Name <span class="text-danger">*</span></label>
                                                        <input
                                                            type="text"
                                                            class="form-control"
                                                            name="mothers_name"
                                                            required
                                                            value="<?= htmlspecialchars($old['mothers_name'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                                                    </div>

                                                    <div class="col-md-6">
                                                        <label class="form-label-stsn">Mother's Contact <span class="text-danger">*</span></label>
                                                        <input
                                                            type="text"
                                                            class="form-control"
                                                            name="mothers_contact_num"
                                                            required
                                                            value="<?= htmlspecialchars($old['mothers_contact_num'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                                                    </div>

                                                    <div class="col-md-6">
                                                        <label class="form-label-stsn">Guardian Name <span class="text-danger">*</span></label>
                                                        <input
                                                            type="text"
                                                            class="form-control"
                                                            name="guardian_name"
                                                            required
                                                            value="<?= htmlspecialchars($old['guardian_name'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                                                    </div>

                                                    <div class="col-md-6">
                                                        <label class="form-label-stsn">Guardian Contact <span class="text-danger">*</span></label>
                                                        <input
                                                            type="text"
                                                            class="form-control"
                                                            name="guardian_contact_num"
                                                            required
                                                            value="<?= htmlspecialchars($old['guardian_contact_num'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-12">
                                        <div class="student-section-card">
                                            <div class="student-section-header">
                                                <div class="student-section-icon">
                                                    <i class="bi bi-geo-alt"></i>
                                                </div>
                                                <div>
                                                    <h3 class="student-section-title">Address Info</h3>
                                                    <p class="student-section-subtitle">Complete the full home location for the student record.</p>
                                                </div>
                                            </div>

                                            <div class="student-section-body">
                                                <div class="row g-3">
                                                    <div class="col-md-4">
                                                        <label class="form-label-stsn">Street / House No. <span class="text-danger">*</span></label>
                                                        <input
                                                            type="text"
                                                            class="form-control"
                                                            name="street_name"
                                                            required
                                                            value="<?= htmlspecialchars($old['street_name'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                                                    </div>

                                                    <div class="col-md-4">
                                                        <label class="form-label-stsn">Country <span class="text-danger">*</span></label>
                                                        <select class="form-select" id="country" name="country_id" required>
                                                            <option value="">Select Country</option>
                                                            <?php foreach ($countries as $c): ?>
                                                                <option value="<?= (int) $c['id'] ?>" <?= ($oldCountry == $c['id']) ? 'selected' : '' ?>>
                                                                    <?= htmlspecialchars($c['country_name'], ENT_QUOTES, 'UTF-8') ?>
                                                                </option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <label class="form-label-stsn">Region <span class="text-danger">*</span></label>
                                                        <select class="form-select" id="region" name="region_id" required>
                                                            <option value="">Select Region</option>
                                                        </select>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <label class="form-label-stsn">Province <span class="text-danger">*</span></label>
                                                        <select class="form-select" id="province" name="province_id" required>
                                                            <option value="">Select Province</option>
                                                        </select>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <label class="form-label-stsn">City / Municipality <span class="text-danger">*</span></label>
                                                        <select class="form-select" id="city" name="city_id" required>
                                                            <option value="">Select City</option>
                                                        </select>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <label class="form-label-stsn">Barangay <span class="text-danger">*</span></label>
                                                        <select class="form-select" id="barangay" name="barangay_id" required>
                                                            <option value="">Select Barangay</option>
                                                        </select>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <label class="form-label-stsn">Postal Code</label>
                                                        <input
                                                            type="text"
                                                            class="form-control"
                                                            name="postal_code"
                                                            value="<?= htmlspecialchars($old['postal_code'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                                                        <div class="form-note">Optional, but helpful for complete records.</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="student-form-actions">
                                    <a href="student.php" class="btn-stsn btn-stsn-secondary">
                                        <i class="bi bi-arrow-left"></i>
                                        Cancel
                                    </a>
                                    <button type="submit" class="btn-stsn btn-stsn-primary">
                                        <i class="bi bi-save"></i>
                                        <?= $edit ? 'Update Student' : 'Save Student' ?>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </main>

        <?php require_once("includes/footer.php"); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./js/adminlte.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>

    <script>
        const regions = <?= json_encode($regions) ?>;
        const provinces = <?= json_encode($provinces) ?>;
        const cities = <?= json_encode($cities) ?>;
        const barangays = <?= json_encode($barangays) ?>;

        const initialToastType = <?= json_encode($toastType) ?>;
        const initialToastMessage = <?= json_encode($toastMessage) ?>;

        function showAlert(message, type = 'success') {
            const config = {
                success: {
                    title: 'Success',
                    color: 'blue',
                    icon: 'bi bi-check-circle-fill'
                },
                danger: {
                    title: 'Error',
                    color: 'red',
                    icon: 'bi bi-exclamation-octagon-fill'
                },
                warning: {
                    title: 'Warning',
                    color: 'yellow',
                    icon: 'bi bi-exclamation-triangle-fill'
                },
                info: {
                    title: 'Info',
                    color: 'blue',
                    icon: 'bi bi-info-circle-fill'
                }
            };

            const selected = config[type] || config.success;

            iziToast.show({
                title: selected.title,
                message: message,
                color: selected.color,
                icon: selected.icon,
                iconColor: '#fff',
                theme: 'light',
                position: 'topRight',
                timeout: 4000,
                progressBar: true,
                close: true,
                pauseOnHover: true,
                drag: true,
                transitionIn: 'fadeInDown',
                transitionOut: 'fadeOutUp',
                maxWidth: 420
            });
        }

        function fillSelect(select, list, nameField, firstText, preSel = null) {
            const keep = select.value;
            select.innerHTML = `<option value="">${firstText}</option>`;

            list.forEach(item => {
                const opt = document.createElement('option');
                opt.value = item.id;
                opt.text = item[nameField];
                if (String(opt.value) === String(keep) || String(opt.value) === String(preSel)) {
                    opt.selected = true;
                }
                select.appendChild(opt);
            });
        }

        document.addEventListener('DOMContentLoaded', () => {
            const form = document.getElementById('studentForm');
            const alertBox = document.getElementById('validationAlert');
            const validationList = document.getElementById('validationList');

            const country = document.getElementById('country');
            const region = document.getElementById('region');
            const province = document.getElementById('province');
            const city = document.getElementById('city');
            const barangay = document.getElementById('barangay');

            if (initialToastType && initialToastMessage) {
                showAlert(initialToastMessage, initialToastType);
            }

            if (+country.value) {
                fillSelect(region, regions.filter(r => String(r.country_id) === String(country.value)), 'region_name', 'Select Region', <?= json_encode($oldRegion) ?>);

                if (region.value || <?= json_encode($oldRegion) ?>) {
                    fillSelect(province, provinces.filter(p => String(p.region_id) === String(region.value || <?= json_encode((string) $oldRegion) ?>)), 'province_name', 'Select Province', <?= json_encode($oldProvince) ?>);
                }

                if (province.value || <?= json_encode($oldProvince) ?>) {
                    fillSelect(city, cities.filter(c => String(c.province_id) === String(province.value || <?= json_encode((string) $oldProvince) ?>)), 'city_name', 'Select City', <?= json_encode($oldCity) ?>);
                }

                if (city.value || <?= json_encode($oldCity) ?>) {
                    fillSelect(barangay, barangays.filter(b => String(b.city_id) === String(city.value || <?= json_encode((string) $oldCity) ?>)), 'barangay_name', 'Select Barangay', <?= json_encode($oldBarangay) ?>);
                }
            }

            country.addEventListener('change', () => {
                fillSelect(region, regions.filter(r => String(r.country_id) === String(country.value)), 'region_name', 'Select Region');
                province.innerHTML = '<option value="">Select Province</option>';
                city.innerHTML = '<option value="">Select City</option>';
                barangay.innerHTML = '<option value="">Select Barangay</option>';
            });

            region.addEventListener('change', () => {
                fillSelect(province, provinces.filter(p => String(p.region_id) === String(region.value)), 'province_name', 'Select Province');
                city.innerHTML = '<option value="">Select City</option>';
                barangay.innerHTML = '<option value="">Select Barangay</option>';
            });

            province.addEventListener('change', () => {
                fillSelect(city, cities.filter(c => String(c.province_id) === String(province.value)), 'city_name', 'Select City');
                barangay.innerHTML = '<option value="">Select Barangay</option>';
            });

            city.addEventListener('change', () => {
                fillSelect(barangay, barangays.filter(b => String(b.city_id) === String(city.value)), 'barangay_name', 'Select Barangay');
            });

            form.addEventListener('submit', e => {
                const missing = [...form.querySelectorAll('[required]')]
                    .filter(el => !String(el.value).trim())
                    .map(el => {
                        const label = el.closest('.col-md-4, .col-md-6, .col-md-12, .col-lg-6, .col-12')?.querySelector('label');
                        return label ? label.textContent.replace('*', '').trim() : el.name;
                    });

                if (missing.length) {
                    e.preventDefault();
                    validationList.innerHTML = missing.map(item => `<li>${item}</li>`).join('');
                    alertBox.classList.add('show');
                    showAlert('Please complete the required fields first.', 'warning');
                    alertBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    return;
                }

                alertBox.classList.remove('show');
                validationList.innerHTML = '';
            });
        });
    </script>
</body>
</html>