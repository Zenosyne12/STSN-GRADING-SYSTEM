<?php
require_once __DIR__ . '/api/shared/db_connect.php';

$sectionId = isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0;

if ($sectionId <= 0) {
    die('Invalid section.');
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Manage Schedule</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">

    <style>
        body {
            background: #f3f7fd;
        }

        .ay-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }

        .ay-page-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 0.2rem;
            letter-spacing: 0.01em;
        }

        .ay-page-header p {
            margin: 0;
            font-size: 0.88rem;
            opacity: 0.85;
        }

        .ay-active-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            background: rgba(255, 255, 255, 0.15);
            border: 1.5px solid rgba(255, 255, 255, 0.3);
            border-radius: 999px;
            padding: 0.45rem 1rem;
            font-size: 0.88rem;
            font-weight: 700;
            color: #fff;
            white-space: nowrap;
        }

        .ay-card {
            background: #fff;
            border: 1px solid #dce8f8;
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18, 72, 168, 0.06);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }

        .ay-card-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid #e8f0fb;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
            background: #fff;
        }

        .ay-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: #132f62;
            margin: 0 0 0.15rem;
        }

        .ay-card-subtitle {
            font-size: 0.8rem;
            color: #7a93b8;
            margin: 0;
        }

        .ay-card-body {
            padding: 1.2rem 1.3rem;
        }

        .ay-info-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 1rem;
        }

        .ay-info-label {
            font-size: 0.83rem;
            font-weight: 700;
            color: #3b5e96;
            margin-bottom: 0.45rem;
        }

        .ay-info-value {
            min-height: 46px;
            display: flex;
            align-items: center;
            padding: 0.65rem 0.9rem;
            border: 1px solid #dce8f8;
            border-radius: 12px;
            background: #fff;
            box-shadow: 0 2px 8px rgba(18, 72, 168, 0.04);
            font-weight: 600;
            color: #213a5e;
        }

        .btn-ay {
            font-weight: 600;
            font-size: 0.82rem;
            border-radius: 8px;
            padding: 0.42rem 0.9rem;
            cursor: pointer;
            transition: background 0.15s, border-color 0.15s, color 0.15s, box-shadow 0.15s;
            border: 1.5px solid transparent;
            line-height: 1.4;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: .35rem;
        }

        .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            border-color: transparent;
            box-shadow: 0 2px 8px rgba(26, 110, 245, 0.2);
        }

        .btn-ay-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
        }

        .btn-ay-warning {
            background: #fff7e8;
            color: #9a6200;
            border-color: #f6d28b;
        }

        .btn-ay-warning:hover {
            background: #ffefc7;
            color: #845100;
            border-color: #efc361;
        }

        .btn-ay-danger {
            background: #fff0f1;
            color: #b42318;
            border-color: #f5b5ba;
        }

        .btn-ay-danger:hover {
            background: #ffe2e4;
            color: #9a1e14;
            border-color: #eb8f97;
        }

        .btn-ay-light {
            background: #fff;
            color: #1248a8;
            border-color: #b8d0fa;
        }

        .btn-ay-light:hover {
            background: #eef4ff;
            border-color: #8db5f7;
            color: #0f3d90;
        }

        .ay-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.32rem 0.75rem;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }

        .ay-badge-active {
            background: #e6f0ff;
            color: #1248a8;
            border: 1.5px solid #b8d0fa;
        }

        .ay-badge-inactive {
            background: #f3f5f8;
            color: #7a8ea8;
            border: 1.5px solid #dde4ee;
        }

        .ay-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
        }

        .ay-table thead th {
            background: #f4f8ff;
            color: #3b5e96;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 0.85rem 1rem;
            border-bottom: 1.5px solid #dce8f8;
            white-space: nowrap;
            text-align: center;
        }

        .ay-table tbody tr:not(:last-child) td {
            border-bottom: 1px solid #f0f5fc;
        }

        .ay-table tbody tr:hover td {
            background: #f7fbff;
        }

        .ay-table tbody td {
            padding: 0.95rem 1rem;
            font-size: 0.92rem;
            color: #213a5e;
            vertical-align: middle;
            text-align: center;
        }

        .ay-left {
            text-align: left !important;
        }

        .ay-mobile-card {
            background: #fff;
            border: 1.5px solid #dce8f8;
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 1px 6px rgba(18, 72, 168, 0.05);
        }

        .ay-mobile-card + .ay-mobile-card {
            margin-top: 0.75rem;
        }

        .ay-mobile-card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.85rem 1rem;
            border-bottom: 1px solid #edf3fc;
            background: #f9fbff;
            gap: .75rem;
        }

        .ay-mobile-card-title {
            font-weight: 700;
            color: #132f62;
            font-size: 0.95rem;
        }

        .ay-mobile-card-body {
            padding: 0.85rem 1rem;
        }

        .ay-mobile-row {
            display: flex;
            justify-content: space-between;
            gap: .75rem;
            padding: .2rem 0;
            font-size: .9rem;
        }

        .ay-mobile-label {
            color: #7a93b8;
            font-weight: 600;
        }

        .ay-mobile-actions {
            display: grid;
            gap: .5rem;
            padding: 0 1rem 1rem;
        }

        .ay-empty {
            text-align: center;
            padding: 2.4rem 1.5rem;
            color: #9ab0c8;
        }

        .ay-empty i {
            font-size: 2.2rem;
            display: block;
            margin-bottom: 0.6rem;
            opacity: 0.5;
        }

        .ay-empty p {
            margin: 0;
            font-size: 0.95rem;
        }

        .ay-modal .modal-content {
            border: 0;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(18, 72, 168, 0.16);
            overflow: hidden;
        }

        .ay-modal .modal-header {
            background: #f4f8ff;
            border-bottom: 1px solid #dce8f8;
            padding: 1rem 1.25rem;
        }

        .ay-modal .modal-title {
            font-size: 1rem;
            font-weight: 700;
            color: #132f62;
        }

        .ay-modal-subtitle {
            font-size: 0.82rem;
            color: #7a93b8;
        }

        .ay-modal .modal-body {
            background: #fff;
            padding: 1.2rem;
        }

        .ay-modal .modal-footer {
            padding: .95rem 1.2rem;
            border-top: 1px solid #e8f0fb;
            background: #fafcff;
        }

        .ay-modal-note {
            background: #f7fbff;
            border: 1px solid #dce8f8;
            border-radius: 12px;
            padding: 0.8rem 0.9rem;
            color: #3b5e96;
            font-size: 0.84rem;
            margin-bottom: 1rem;
        }

        @media (max-width: 991.98px) {
            .ay-info-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 767.98px) {
            .ay-page-header {
                padding: 1.1rem 1.2rem;
                border-radius: 14px;
            }

            #scheduleTable thead {
                display: none;
            }

            #scheduleTable tbody tr {
                display: block;
                border: 1px solid #dee2e6;
                margin-bottom: .75rem;
                border-radius: .9rem;
                padding: .5rem;
                background: #fff;
                box-shadow: 0 10px 25px rgba(15, 23, 42, .06);
            }

            #scheduleTable tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                border: none !important;
                padding: .35rem .5rem;
            }

            #scheduleTable tbody td::before {
                content: attr(data-label);
                font-weight: 600;
                margin-right: .5rem;
                white-space: nowrap;
                color: #475569;
            }

            #scheduleTable tbody td:last-child {
                flex-direction: column;
                gap: .25rem;
            }

            #scheduleTable tbody td:last-child .btn-ay {
                width: 100%;
            }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3">

                <div class="ay-page-header">
                    <div>
                        <h3><i class="bi bi-calendar-check me-2"></i>Manage Section Schedule</h3>
                        <p>Assign advisers and manage subject schedule records for the selected section.</p>
                    </div>
                    <div class="ay-active-chip">
                        <i class="bi bi-journal-check"></i>
                        Schedule Management
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-7 d-flex">
                        <div class="ay-card w-100">
                            <div class="ay-card-header">
                                <div>
                                    <p class="ay-card-title">Section Information</p>
                                    <p class="ay-card-subtitle">Basic information for the selected section.</p>
                                </div>
                            </div>
                            <div class="ay-card-body">
                                <div class="ay-info-grid">
                                    <div>
                                        <div class="ay-info-label">Grade Level</div>
                                        <div id="infoGradeLevel" class="ay-info-value">-</div>
                                    </div>
                                    <div>
                                        <div class="ay-info-label">Section Name</div>
                                        <div id="infoSectionName" class="ay-info-value">-</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-5 d-flex">
                        <div class="ay-card w-100">
                            <div class="ay-card-header">
                                <div>
                                    <p class="ay-card-title">Academic Setup</p>
                                    <p class="ay-card-subtitle">Assign the section adviser for the active academic year.</p>
                                </div>
                            </div>
                            <div class="ay-card-body">
                                <div class="d-none">
                                    <select id="academicYearId"></select>
                                </div>

                                <div>
                                    <label class="form-label fw-bold">Section Adviser</label>
                                    <div class="input-group">
                                        <select class="form-select" id="adviserTeacherId" style="border-radius:10px 0 0 10px; border:1.5px solid #dce8f8;"></select>
                                        <button class="btn-ay btn-ay-primary" type="button" onclick="saveAdviser()" style="border-radius:0 10px 10px 0;">
                                            <i class="bi bi-save"></i> Save Adviser
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="ay-card">
                    <div class="ay-card-header">
                        <div>
                            <p class="ay-card-title">Schedule Entries</p>
                            <p class="ay-card-subtitle">Create, edit, and delete schedule entries for this section.</p>
                        </div>

                        <button class="btn-ay btn-ay-primary" type="button" onclick="openScheduleForm()">
                            <i class="bi bi-plus-circle"></i> New Schedule
                        </button>
                    </div>

                    <div class="table-responsive d-none d-md-block">
                        <table id="scheduleTable" class="ay-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Subject</th>
                                    <th>Teacher</th>
                                    <th>Day</th>
                                    <th>Time</th>
                                    <th>Room</th>
                                    <th>Status</th>
                                    <th style="width:160px;">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="scheduleTableBody">
                                <tr>
                                    <td colspan="8">
                                        <div class="ay-empty">
                                            <i class="bi bi-hourglass-split"></i>
                                            <p>Loading schedule entries...</p>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="d-block d-md-none p-3" id="scheduleCardView"></div>
                </div>

            </div>
        </div>
    </main>

    <?php require_once("includes/footer.php"); ?>
</div>

<div class="modal fade ay-modal" id="scheduleFormModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <form id="scheduleForm">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title" id="scheduleFormTitle">Add Schedule</h5>
                        <div class="ay-modal-subtitle">Create or update a schedule entry for this section.</div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <input type="hidden" id="scheduleId">

                    <div class="row g-3">
                        <div class="col-md-12">
                            <label class="form-label">Subject <span class="text-danger">*</span></label>
                            <select class="form-select" id="subjectId" required style="border-radius:10px; border:1.5px solid #dce8f8;"></select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Day <span class="text-danger">*</span></label>
                            <select class="form-select" id="dayOfWeek" required style="border-radius:10px; border:1.5px solid #dce8f8;">
                                <option value="">Select Day</option>
                                <option>Monday</option>
                                <option>Tuesday</option>
                                <option>Wednesday</option>
                                <option>Thursday</option>
                                <option>Friday</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Start Time <span class="text-danger">*</span></label>
                            <input type="time" class="form-control" id="timeStart" required style="border-radius:10px; border:1.5px solid #dce8f8;">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">End Time <span class="text-danger">*</span></label>
                            <input type="time" class="form-control" id="timeEnd" required style="border-radius:10px; border:1.5px solid #dce8f8;">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Room</label>
                            <input type="text" class="form-control" id="room" style="border-radius:10px; border:1.5px solid #dce8f8;">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Status</label>
                            <select class="form-select" id="isActive" style="border-radius:10px; border:1.5px solid #dce8f8;">
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn-ay btn-ay-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn-ay btn-ay-primary">Save Schedule</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>

<script>
const SECTION_ID = <?php echo (int)$sectionId; ?>;
let currentSectionInfo = null;

function esc(str) {
    return (str ?? '').toString()
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function showAlert(message, type = 'success') {
    const config = {
        success: { title: 'Success', color: 'blue', icon: 'bi bi-check-circle-fill' },
        danger: { title: 'Error', color: 'red', icon: 'bi bi-exclamation-octagon-fill' },
        warning: { title: 'Warning', color: 'yellow', icon: 'bi bi-exclamation-triangle-fill' },
        info: { title: 'Info', color: 'blue', icon: 'bi bi-info-circle-fill' }
    };

    const selected = config[type] || config.success;

    iziToast.show({
        title: selected.title,
        message: message,
        color: selected.color,
        icon: selected.icon,
        iconColor: '#fff',
        theme: 'light',
        position: 'topRight',
        timeout: 4000,
        progressBar: true,
        close: true,
        pauseOnHover: true,
        drag: true,
        transitionIn: 'fadeInDown',
        transitionOut: 'fadeOutUp',
        maxWidth: 420
    });
}

async function fetchJson(url, options = {}) {
    const res = await fetch(url, options);
    const text = await res.text();

    try {
        return JSON.parse(text);
    } catch (e) {
        console.error('Invalid JSON from:', url, text);
        throw new Error('Invalid server response');
    }
}

async function loadSectionInfo() {
    try {
        const data = await fetchJson(`api/schedule/fetch_section.php?id=${SECTION_ID}`);
        currentSectionInfo = data.data || data;

        document.getElementById('infoGradeLevel').textContent = currentSectionInfo.grade_level_name || '-';
        document.getElementById('infoSectionName').textContent = currentSectionInfo.section_name || '-';

        await loadAllTeachers();
        await loadAcademicYears(currentSectionInfo.default_academic_year_id || '');

        loadAdviser();
        loadSchedules();
    } catch (err) {
        console.error(err);
        showAlert('Failed to load section information: ' + err.message, 'danger');
    }
}

function loadAllTeachers() {
    return fetchJson('api/schedule/teachers.php')
        .then(data => {
            const list = data.teachers || data.data || [];
            const options = ['<option value="">Select Teacher</option>']
                .concat(list.map(t => `<option value="${t.id}">${esc(t.full_name)}</option>`))
                .join('');
            document.getElementById('adviserTeacherId').innerHTML = options;
        });
}

function loadSubjects(selectedId = '', excludeScheduleId = '') {
    const academicYearId = document.getElementById('academicYearId').value;
    const gradeLevelId = currentSectionInfo?.grade_level_id || '';
    const subjectSelect = document.getElementById('subjectId');

    if (!academicYearId || !gradeLevelId) {
        subjectSelect.innerHTML = '<option value="">No subjects available</option>';
        return Promise.resolve();
    }

    subjectSelect.innerHTML = '<option value="">Loading subjects...</option>';
    subjectSelect.disabled = true;

    let url = `api/schedule/subjects.php?section_id=${SECTION_ID}&academic_year_id=${academicYearId}&grade_level_id=${gradeLevelId}`;
    if (excludeScheduleId) {
        url += `&exclude_schedule_id=${excludeScheduleId}`;
    }

    return fetchJson(url)
        .then(data => {
            const list = data.subjects || data.data || [];

            if (!list.length) {
                subjectSelect.innerHTML = '<option value="">No subjects available for this grade level</option>';
                return;
            }

            const options = ['<option value="">Select Subject</option>']
                .concat(list.map(s => `
                    <option value="${s.id}" ${String(selectedId) === String(s.id) ? 'selected' : ''}>
                        ${esc(s.subject_name)} (${esc(s.subject_code)})
                    </option>
                `))
                .join('');

            subjectSelect.innerHTML = options;
        })
        .catch(err => {
            console.error(err);
            subjectSelect.innerHTML = '<option value="">Failed to load subjects</option>';
            throw err;
        })
        .finally(() => {
            subjectSelect.disabled = false;
        });
}

function loadAcademicYears(selectedId = '') {
    return fetchJson('api/schedule/academic_years.php')
        .then(data => {
            const list = data.academic_years || data.data || [];
            document.getElementById('academicYearId').innerHTML = list.map(y => `
                <option value="${y.id}" ${String(selectedId) === String(y.id) ? 'selected' : ''}>
                    ${esc(y.year_label)}${y.is_active == 1 ? ' (Active)' : ''}
                </option>
            `).join('');
        });
}

function loadAdviser() {
    const academicYearId = document.getElementById('academicYearId').value;
    if (!academicYearId) return;

    fetchJson(`api/schedule/adviser_get.php?section_id=${SECTION_ID}&academic_year_id=${academicYearId}`)
        .then(data => {
            document.getElementById('adviserTeacherId').value = data.teacher_id || '';
        })
        .catch(err => {
            console.error(err);
            showAlert('Failed to load adviser: ' + err.message, 'danger');
        });
}

function saveAdviser() {
    const academicYearId = document.getElementById('academicYearId').value;
    const teacherId = document.getElementById('adviserTeacherId').value;

    fetchJson('api/schedule/adviser_save.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            section_id: SECTION_ID,
            academic_year_id: academicYearId,
            teacher_id: teacherId
        })
    })
    .then(res => {
        if (res.success !== false) {
            showAlert('Adviser saved successfully.', 'success');
        } else {
            showAlert(res.error || 'Failed to save adviser.', 'danger');
        }
    })
    .catch(err => {
        console.error(err);
        showAlert('Failed to save adviser: ' + err.message, 'danger');
    });
}

function loadSchedules() {
    const academicYearId = document.getElementById('academicYearId').value;
    if (!academicYearId) return;

    fetchJson(`api/schedule/read.php?section_id=${SECTION_ID}&academic_year_id=${academicYearId}`)
        .then(data => {
            const list = data.schedules || data.data || [];

            document.getElementById('scheduleTableBody').innerHTML = list.length ? list.map((s, i) => `
                <tr>
                    <td data-label="#">${i + 1}</td>
                    <td data-label="Subject" class="ay-left">${esc(s.subject_name || '-')}</td>
                    <td data-label="Teacher">${esc(s.teacher_name || '-')}</td>
                    <td data-label="Day">${esc(s.day_of_week || '-')}</td>
                    <td data-label="Time">${esc(s.time_start_12 || s.time_start || '-')} - ${esc(s.time_end_12 || s.time_end || '-')}</td>
                    <td data-label="Room">${esc(s.room || '-')}</td>
                    <td data-label="Status">
                        ${String(s.is_active) === '1'
                            ? `<span class="ay-badge ay-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                            : `<span class="ay-badge ay-badge-inactive">Inactive</span>`
                        }
                    </td>
                    <td data-label="Actions">
                        <div class="d-flex justify-content-center gap-2 flex-wrap">
                            <button class="btn-ay btn-ay-warning" onclick="editSchedule(${s.id})">
                                <i class="bi bi-pencil-square"></i> Edit
                            </button>
                            <button class="btn-ay btn-ay-danger" onclick="deleteSchedule(${s.id})">
                                <i class="bi bi-trash"></i> Delete
                            </button>
                        </div>
                    </td>
                </tr>
            `).join('') : `
                <tr>
                    <td colspan="8">
                        <div class="ay-empty">
                            <i class="bi bi-calendar-x"></i>
                            <p>No schedule entries found.</p>
                        </div>
                    </td>
                </tr>
            `;

            document.getElementById('scheduleCardView').innerHTML = list.length ? list.map((s, i) => `
                <div class="ay-mobile-card">
                    <div class="ay-mobile-card-header">
                        <span class="ay-mobile-card-title">${i + 1}. ${esc(s.subject_name || '-')}</span>
                        ${String(s.is_active) === '1'
                            ? `<span class="ay-badge ay-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                            : `<span class="ay-badge ay-badge-inactive">Inactive</span>`
                        }
                    </div>
                    <div class="ay-mobile-card-body">
                        <div class="ay-mobile-row"><span class="ay-mobile-label">Teacher</span><span>${esc(s.teacher_name || '-')}</span></div>
                        <div class="ay-mobile-row"><span class="ay-mobile-label">Day</span><span>${esc(s.day_of_week || '-')}</span></div>
                        <div class="ay-mobile-row"><span class="ay-mobile-label">Time</span><span>${esc(s.time_start_12 || s.time_start || '-')} - ${esc(s.time_end_12 || s.time_end || '-')}</span></div>
                        <div class="ay-mobile-row"><span class="ay-mobile-label">Room</span><span>${esc(s.room || '-')}</span></div>
                    </div>
                    <div class="ay-mobile-actions">
                        <button class="btn-ay btn-ay-warning" onclick="editSchedule(${s.id})"><i class="bi bi-pencil-square"></i> Edit</button>
                        <button class="btn-ay btn-ay-danger" onclick="deleteSchedule(${s.id})"><i class="bi bi-trash"></i> Delete</button>
                    </div>
                </div>
            `).join('') : `
                <div class="ay-empty">
                    <i class="bi bi-calendar-x"></i>
                    <p>No schedule entries found.</p>
                </div>
            `;
        })
        .catch(err => {
            console.error(err);
            showAlert('Failed to load schedules: ' + err.message, 'danger');
        });
}

function openScheduleForm() {
    const adviserTeacherId = document.getElementById('adviserTeacherId').value;

    if (!adviserTeacherId) {
        showAlert('Please assign and save a section adviser first.', 'warning');
        return;
    }

    document.getElementById('scheduleForm').reset();
    document.getElementById('scheduleId').value = '';
    document.getElementById('scheduleFormTitle').textContent = 'Add Schedule';
    document.getElementById('isActive').value = '1';

    loadSubjects()
        .then(() => {
            new bootstrap.Modal(document.getElementById('scheduleFormModal')).show();
        })
        .catch(err => {
            console.error(err);
            showAlert('Failed to open schedule form: ' + err.message, 'danger');
        });
}

function editSchedule(id) {
    const adviserTeacherId = document.getElementById('adviserTeacherId').value;

    if (!adviserTeacherId) {
        showAlert('Please assign and save a section adviser first.', 'warning');
        return;
    }

    fetchJson(`api/schedule/fetch.php?id=${id}`)
        .then(data => {
            const row = data.data || data;

            loadSubjects(row.subject_id, id).then(() => {
                document.getElementById('scheduleId').value = row.id;
                document.getElementById('subjectId').value = row.subject_id;
                document.getElementById('dayOfWeek').value = row.day_of_week;
                document.getElementById('timeStart').value = row.time_start;
                document.getElementById('timeEnd').value = row.time_end;
                document.getElementById('room').value = row.room || '';
                document.getElementById('isActive').value = row.is_active;
                document.getElementById('scheduleFormTitle').textContent = 'Edit Schedule';
                new bootstrap.Modal(document.getElementById('scheduleFormModal')).show();
            });
        })
        .catch(err => {
            console.error(err);
            showAlert('Failed to load schedule entry: ' + err.message, 'danger');
        });
}

function deleteSchedule(id) {
    if (!confirm('Delete this schedule?')) return;

    fetchJson('api/schedule/delete.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ id: id })
    })
    .then(res => {
        if (res.success !== false) {
            showAlert('Schedule deleted successfully.', 'success');
            loadSchedules();
        } else {
            showAlert(res.error || 'Delete failed.', 'danger');
        }
    })
    .catch(err => {
        console.error(err);
        showAlert('Delete failed: ' + err.message, 'danger');
    });
}

document.getElementById('scheduleForm').addEventListener('submit', e => {
    e.preventDefault();

    const adviserTeacherId = document.getElementById('adviserTeacherId').value;

    if (!adviserTeacherId) {
        showAlert('Please assign and save a section adviser first.', 'warning');
        return;
    }

    fetchJson('api/schedule/save.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            id: document.getElementById('scheduleId').value || undefined,
            academic_year_id: document.getElementById('academicYearId').value,
            section_id: SECTION_ID,
            subject_id: document.getElementById('subjectId').value,
            teacher_id: adviserTeacherId,
            day_of_week: document.getElementById('dayOfWeek').value,
            time_start: document.getElementById('timeStart').value,
            time_end: document.getElementById('timeEnd').value,
            room: document.getElementById('room').value.trim(),
            is_active: document.getElementById('isActive').value
        })
    })
    .then(res => {
        if (res.success !== false) {
            const modal = bootstrap.Modal.getInstance(document.getElementById('scheduleFormModal'));
            if (modal) modal.hide();
            showAlert('Schedule saved successfully.', 'success');
            loadSchedules();
        } else {
            showAlert(res.error || 'Save failed.', 'danger');
        }
    })
    .catch(err => {
        console.error(err);
        showAlert('Save failed: ' + err.message, 'danger');
    });
});

document.getElementById('academicYearId').addEventListener('change', () => {
    loadAdviser();
    loadSchedules();
});

loadSectionInfo();
</script>
</body>
</html>