<?php
require_once __DIR__ . '/api/shared/db_connect.php';

$sectionId = (int)($_GET['id'] ?? 0);
$academicYearId = (int)($_GET['academic_year_id'] ?? 0);

if ($sectionId <= 0) {
    die('Invalid section');
}

if ($academicYearId <= 0) {
    $ayStmt = $pdo->query("
        SELECT id, year_label
        FROM tblacademicyear
        WHERE COALESCE(is_active, 1) = 1
        ORDER BY id DESC
        LIMIT 1
    ");
    $activeAy = $ayStmt->fetch(PDO::FETCH_ASSOC);
    $academicYearId = (int)($activeAy['id'] ?? 0);
}

$stmt = $pdo->prepare("
    SELECT 
        s.id,
        s.section_name,
        g.grade_level_name
    FROM tblsection s
    LEFT JOIN tblgradelevel g ON g.id = s.grade_level_id
    WHERE s.id = ?
");
$stmt->execute([$sectionId]);
$section = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$section) {
    die('Section not found');
}

$schoolYear = '';
if ($academicYearId > 0) {
    $ay = $pdo->prepare("SELECT year_label FROM tblacademicyear WHERE id = ?");
    $ay->execute([$academicYearId]);
    $schoolYear = $ay->fetchColumn() ?: '';
}

$colsStmt = $pdo->query("SHOW COLUMNS FROM tblstudents");
$columns = $colsStmt->fetchAll(PDO::FETCH_COLUMN);

$fnameCol = in_array('fname', $columns, true) ? 'fname' : (in_array('firstname', $columns, true) ? 'firstname' : null);
$mnameCol = in_array('mname', $columns, true) ? 'mname' : (in_array('middlename', $columns, true) ? 'middlename' : null);
$lnameCol = in_array('lname', $columns, true) ? 'lname' : (in_array('lastname', $columns, true) ? 'lastname' : null);

$genderCol = null;
foreach (['gender', 'sex', 'student_gender'] as $candidate) {
    if (in_array($candidate, $columns, true)) {
        $genderCol = $candidate;
        break;
    }
}

$studentNoCol = null;
foreach (['student_no', 'lrn', 'school_id'] as $candidate) {
    if (in_array($candidate, $columns, true)) {
        $studentNoCol = $candidate;
        break;
    }
}

if (!$fnameCol || !$lnameCol) {
    die('Student name columns not found in tblstudents');
}

$studentIdentifierExpr = $studentNoCol ? "st.`$studentNoCol`" : "st.id";
$middleExpr = $mnameCol ? "
    CASE
        WHEN COALESCE(st.`$mnameCol`, '') = '' THEN ''
        ELSE CONCAT(' ', LEFT(st.`$mnameCol`, 1), '.')
    END
" : "''";

$genderSelect = $genderCol ? "st.`$genderCol`" : "NULL";

$allStudents = [];
if ($academicYearId > 0) {
    $sqlStudents = "
        SELECT
            ss.id AS section_student_id,
            st.id,
            $studentIdentifierExpr AS student_identifier,
            CONCAT(
                st.`$lnameCol`,
                ', ',
                st.`$fnameCol`,
                $middleExpr
            ) AS full_name,
            $genderSelect AS gender
        FROM tblsectionstudent ss
        INNER JOIN tblstudents st ON st.id = ss.student_id
        WHERE ss.section_id = ?
          AND ss.academic_year_id = ?
          AND ss.is_active = 1
        ORDER BY st.`$lnameCol` ASC, st.`$fnameCol` ASC
    ";
    $stmt = $pdo->prepare($sqlStudents);
    $stmt->execute([$sectionId, $academicYearId]);
    $allStudents = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$maleStudents = [];
$femaleStudents = [];
$unknownGender = [];

foreach ($allStudents as $student) {
    $gender = strtolower(trim((string)($student['gender'] ?? '')));
    if (in_array($gender, ['male', 'm', 'boy', 'boys', '1'], true)) {
        $maleStudents[] = $student;
    } elseif (in_array($gender, ['female', 'f', 'girl', 'girls', '0', '2'], true)) {
        $femaleStudents[] = $student;
    } else {
        $unknownGender[] = $student;
    }
}

$schedules = [];
if ($academicYearId > 0) {
    $sqlSchedule = "
        SELECT
            sc.id,
            sc.day_of_week,
            sc.time_start,
            sc.time_end,
            sc.room,
            sc.remarks,
            sub.subject_code,
            sub.subject_name,
            CONCAT(t.fname, ' ', t.lname) AS teacher_name
        FROM tblschedule sc
        INNER JOIN tblsubjects sub ON sub.id = sc.subject_id
        INNER JOIN tblteacher t ON t.id = sc.teacher_id
        WHERE sc.section_id = ?
          AND sc.academic_year_id = ?
          AND sc.is_active = 1
        ORDER BY
            FIELD(sc.day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'),
            sc.time_start ASC,
            sub.subject_name ASC
    ";
    $stmt = $pdo->prepare($sqlSchedule);
    $stmt->execute([$sectionId, $academicYearId]);
    $schedules = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function e(?string $text): string {
    return htmlspecialchars((string)$text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

function dayLabel(?string $d): string {
    return match($d) {
        'Monday' => 'Mon',
        'Tuesday' => 'Tue',
        'Wednesday' => 'Wed',
        'Thursday' => 'Thu',
        'Friday' => 'Fri',
        'Saturday' => 'Sat',
        default => (string)$d
    };
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Section View</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #fff;
            color: #000;
            margin: 24px 32px;
            font-size: 20px;
        }
        .header { text-align: center; margin-bottom: 20px; }
        .school-name {
            font-size: 34px;
            font-weight: 900;
            letter-spacing: .5px;
            margin: 0;
        }
        .subhead {
            font-size: 14px;
            margin: 2px 0 18px;
        }
        .section-bar {
            background: #000;
            color: #fff;
            text-align: center;
            font-size: 32px;
            font-weight: 900;
            line-height: 1.1;
            padding: 4px 0;
            margin: 6px 0 0;
        }
        .semester-line {
            text-align: center;
            font-size: 24px;
            font-weight: 800;
            margin: 0 0 24px;
        }
        .block-title {
            font-size: 24px;
            font-weight: 900;
            margin: 30px 0 15px;
            text-align: center;
            text-transform: uppercase;
            border-bottom: 3px solid #000;
            padding-bottom: 8px;
        }

        .summary {
            text-align: center;
            font-size: 20px;
            margin-bottom: 25px;
        }
        .summary span {
            margin: 0 20px;
            font-weight: bold;
        }
        .male-count { color: #0066cc; }
        .female-count { color: #cc0066; }
        .total-count { color: #333; }

        .students-container {
            display: flex;
            gap: 40px;
            margin-bottom: 30px;
        }
        .gender-column {
            flex: 1;
        }
        .gender-header {
            font-size: 15px;
            font-weight: 700;
            text-align: center;
            padding: 10px;
            margin-bottom: 15px;
            border-bottom: 4px solid;
        }

        .student-list {
            font-size: 20px;
            line-height: 1.8;
        }
        .student-item {
            margin-bottom: 12px;
            display: flex;
            align-items: baseline;
        }
        .student-number {
            font-weight: bold;
            min-width: 40px;
        }
        .student-id {
            font-family: monospace;
            font-size: 20px;
            min-width: 120px;
            color: #555;
            margin-right: 15px;
        }
        .student-name {
            font-weight: 500;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            font-size: 18px;
            margin-bottom: 30px;
        }
        th, td {
            border: 2px solid #222;
            padding: 10px;
            vertical-align: middle;
        }
        th {
            font-size: 18px;
            font-weight: 900;
            text-align: center;
        }
        .year-row td {
            font-size: 22px;
            font-weight: 900;
            text-align: center;
            padding: 10px 0;
        }
        .center { text-align: center; }

        @media print {
            body { margin: 15px; font-size: 18px; }
            .students-container { gap: 30px; }
            .student-list { font-size: 18px; line-height: 1.6; }
            .student-item { margin-bottom: 8px; }
            .gender-header { font-size: 20px; padding: 8px; }
        }
    </style>
</head>
<body>
    <div class="header">
        <p class="school-name">ST. TERESA SCHOOL OF NOVALICHES</p>
        <p class="subhead">Zabarte Subd., Novaliches, Q.C.</p>
        <div class="section-bar"><?= e($section['section_name']) ?></div>
        <p class="semester-line">
            School Year <?= e($schoolYear !== '' ? $schoolYear : 'Not set') ?>
        </p>
    </div>

    <div class="summary">
        <span class="male-count">Male: <?= count($maleStudents) ?></span>
        <span class="female-count">Female: <?= count($femaleStudents) ?></span>
        <?php if (count($unknownGender) > 0): ?>
            <span class="total-count">Unspecified: <?= count($unknownGender) ?></span>
        <?php endif; ?>
        <span class="total-count">Total: <?= count($allStudents) ?></span>
    </div>

    <div class="block-title">Class Schedule</div>
    <table>
        <thead>
            <tr class="year-row">
                <td colspan="6"><?= e($section['grade_level_name'] ?? '') ?> - <?= e($section['section_name']) ?></td>
            </tr>
            <tr>
                <th style="width:12%;">CODE</th>
                <th style="width:28%;">COURSE DESCRIPTION</th>
                <th style="width:10%;">DAY/S</th>
                <th style="width:20%;">TIME</th>
                <th style="width:10%;">ROOM</th>
                <th style="width:20%;">FACULTY</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($academicYearId <= 0): ?>
                <tr>
                    <td colspan="6" class="center">No active academic year found</td>
                </tr>
            <?php elseif (!$schedules): ?>
                <tr>
                    <td colspan="6" class="center">No schedule found</td>
                </tr>
            <?php endif; ?>

            <?php foreach ($schedules as $r): ?>
                <tr>
                    <td class="center"><?= e($r['subject_code']) ?></td>
                    <td><?= e($r['subject_name']) ?></td>
                    <td class="center"><?= e(dayLabel($r['day_of_week'])) ?></td>
                    <td class="center">
                        <?= date('g:ia', strtotime($r['time_start'])) ?> - <?= date('g:ia', strtotime($r['time_end'])) ?>
                    </td>
                    <td class="center"><?= e($r['room'] ?? '') ?></td>
                    <td><?= e($r['teacher_name']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="block-title">Class List</div>

    <div class="students-container">
        <div class="gender-column">
            <div class="gender-header male-header">
                MALE (<?= count($maleStudents) ?>)
            </div>
            <?php if (count($maleStudents) > 0): ?>
                <div class="student-list">
                    <?php foreach ($maleStudents as $i => $r): ?>
                        <div class="student-item">
                            <span class="student-number"><?= $i + 1 ?>.</span>
                            <span class="student-id"><?= e((string)$r['student_identifier']) ?></span>
                            <span class="student-name"><?= e($r['full_name']) ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div style="text-align: center; color: #999; font-style: italic; padding: 20px;">
                    No male students
                </div>
            <?php endif; ?>
        </div>

        <div class="gender-column">
            <div class="gender-header female-header">
                FEMALE (<?= count($femaleStudents) ?>)
            </div>
            <?php if (count($femaleStudents) > 0): ?>
                <div class="student-list">
                    <?php foreach ($femaleStudents as $i => $r): ?>
                        <div class="student-item">
                            <span class="student-number"><?= $i + 1 ?>.</span>
                            <span class="student-id"><?= e((string)$r['student_identifier']) ?></span>
                            <span class="student-name"><?= e($r['full_name']) ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div style="text-align: center; color: #999; font-style: italic; padding: 20px;">
                    No female students
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if (count($unknownGender) > 0): ?>
        <div class="gender-header unknown-header" style="margin-top: 30px;">
            UNSPECIFIED GENDER (<?= count($unknownGender) ?>)
        </div>
        <div class="students-container">
            <div class="gender-column" style="flex: 2;">
                <div class="student-list">
                    <?php foreach ($unknownGender as $i => $r): ?>
                        <div class="student-item">
                            <span class="student-number"><?= $i + 1 ?>.</span>
                            <span class="student-id"><?= e((string)$r['student_identifier']) ?></span>
                            <span class="student-name"><?= e($r['full_name']) ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($academicYearId > 0 && count($allStudents) === 0): ?>
        <div style="text-align: center; padding: 40px; font-style: italic; font-size: 20px;">
            No students enrolled in this section.
        </div>
    <?php endif; ?>
</body>
</html>