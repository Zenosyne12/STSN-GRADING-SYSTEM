<?php
require_once __DIR__ . '/api/shared/db_connect.php';

$sectionId = isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0;

if ($sectionId <= 0) {
    die('Invalid section.');
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Manage Sectioning</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        @media (max-width: 767.98px) {
            #masterlistTable thead { display: none; }
            #masterlistTable tbody tr {
                display: block;
                border: 1px solid #dee2e6;
                margin-bottom: .75rem;
                border-radius: .4rem;
                padding: .5rem;
            }
            #masterlistTable tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                border: none !important;
                padding: .35rem .5rem;
            }
            #masterlistTable tbody td::before {
                content: attr(data-label);
                font-weight: 600;
                margin-right: .5rem;
                white-space: nowrap;
            }
            #masterlistTable tbody td:last-child {
                flex-direction: column;
                gap: .25rem;
            }
            #masterlistTable tbody td:last-child .btn {
                width: 100%;
            }

            .section-meta .col-md-4,
            .section-meta .col-md-8 {
                margin-bottom: .75rem;
            }

            .section-actions .btn {
                width: 100%;
            }
        }

        .student-checkbox {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .bulk-actions {
            display: none;
        }

        .bulk-actions.show {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .info-value {
            min-height: 38px;
            display: flex;
            align-items: center;
            padding: .5rem .75rem;
            border: 1px solid #dee2e6;
            border-radius: .375rem;
            background: var(--bs-tertiary-bg);
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-7">
                        <h3 class="mb-0"><i class="bi bi-people-fill"></i> Manage Section Masterlist</h3>
                    </div>
                    <div class="col-sm-5">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="sectioning.php">Sectioning</a></li>
                            <li class="breadcrumb-item active">Manage</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">
            <div class="card mb-4">
                <div class="card-header">
                    <h3 class="card-title mb-0">Section Information</h3>
                </div>
                <div class="card-body">
                    <div class="row g-3 align-items-end">
                        <div class="col-lg-8">
                            <div class="row g-3 section-meta">
                                <div class="col-md-4">
                                    <label class="form-label fw-bold mb-1">Grade Level</label>
                                    <div id="infoGradeLevel" class="info-value">-</div>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-bold mb-1">Section Name</label>
                                    <div id="infoSectionName" class="info-value">-</div>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-bold mb-1">Section Adviser</label>
                                    <div id="infoAdviser" class="info-value">-</div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4">
                            <div class="d-none">
                                <select id="academicYearId"></select>
                            </div>

                            <div class="d-grid gap-2 d-md-flex justify-content-lg-end section-actions">
                                <a class="btn btn-primary" id="viewMasterlistBtn" href="#" target="_blank">
                                    <i class="bi bi-eye"></i> View List
                                </a>
                                <button class="btn btn-success" type="button" onclick="openAddStudentModal()">
                                    <i class="bi bi-person-plus"></i> Add Student
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <div>
                        <h3 class="card-title mb-0">Masterlist</h3>
                        <div class="bulk-actions mt-2" id="bulkActions">
                            <span class="text-muted" id="selectedCount">0 selected</span>
                            <button class="btn btn-warning btn-sm" onclick="openTransferModal()">
                                <i class="bi bi-arrow-left-right"></i> Transfer to Section
                            </button>
                            <button class="btn btn-danger btn-sm" onclick="removeSelectedStudents()">
                                <i class="bi bi-person-dash"></i> Remove Selected
                            </button>
                            <button class="btn btn-secondary btn-sm" onclick="clearSelection()">
                                Clear
                            </button>
                        </div>
                    </div>
                    <input class="form-control form-control-sm ms-auto" type="search" id="studentSearchInput" placeholder="Search student..." style="max-width:250px;">
                </div>

                <div class="card-body">
                    <div class="table-responsive d-none d-md-block">
                        <table id="masterlistTable" class="table table-bordered table-hover align-middle text-center mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th style="width:40px;">
                                        <input type="checkbox" class="student-checkbox" id="selectAllCheckbox" onchange="toggleSelectAll()">
                                    </th>
                                    <th>#</th>
                                    <th>Student ID</th>
                                    <th>Student Name</th>
                                    <th style="width:100px;">Sex</th>
                                    <th style="width:200px;">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="masterlistTableBody"></tbody>
                        </table>
                    </div>

                    <div class="d-block d-md-none" id="masterlistCardView"></div>
                </div>
            </div>
        </div>
    </main>

    <?php require_once("includes/footer.php"); ?>
</div>

<div class="modal fade" id="addStudentModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="false">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <form id="addStudentForm">
                <div class="modal-header">
                    <h5 class="modal-title">Add Student to Section</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Available Students</label>
                        <select class="form-select" id="studentId" required></select>
                    </div>
                </div>

                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
                    <button class="btn btn-success" type="submit">Add Student</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="transferModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="false">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <form id="transferForm">
                <div class="modal-header bg-warning">
                    <h5 class="modal-title"><i class="bi bi-arrow-left-right"></i> Transfer Students</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle"></i>
                        You are transferring <strong id="transferCount">0</strong> student(s) to another section with the same grade level.
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Current Section</label>
                        <input type="text" class="form-control" id="currentSectionDisplay" readonly>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Target Section <span class="text-danger">*</span></label>
                        <select class="form-select" id="targetSectionId" required>
                            <option value="">Select Target Section</option>
                        </select>
                        <div class="form-text text-muted">Only sections with the same grade level are shown.</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Students to Transfer</label>
                        <div id="transferStudentList" class="border rounded p-3 bg-light" style="max-height: 200px; overflow-y: auto;"></div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Cancel</button>
                    <button class="btn btn-warning" type="submit">
                        <i class="bi bi-arrow-left-right"></i> Transfer Students
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script>
const SECTION_ID = <?php echo (int)$sectionId; ?>;
let currentSectionInfo = null;
let currentStudents = [];
let selectedStudents = new Set();

function esc(str) {
    return (str ?? '').toString()
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

async function fetchJson(url, options = {}) {
    const res = await fetch(url, options);
    const text = await res.text();

    let json;
    try {
        json = JSON.parse(text);
    } catch (e) {
        console.error('Invalid JSON from:', url);
        console.error('Raw response:', text);
        throw new Error('Invalid server response');
    }

    if (!res.ok) {
        throw new Error(json.error || ('HTTP ' + res.status));
    }

    return json;
}

async function loadSectionInfo() {
    const result = await fetchJson(`api/sectioning/fetch_section.php?id=${SECTION_ID}`);
    currentSectionInfo = result.data;
    const data = result.data;

    document.getElementById('infoGradeLevel').textContent = data.grade_level_name || '-';
    document.getElementById('infoSectionName').textContent = data.section_name || '-';
    document.getElementById('currentSectionDisplay').value = `${data.section_name} (${data.grade_level_name})`;

    await loadAcademicYears(data.default_academic_year_id || '');
    await loadSectionAdviser();
    refreshViewLink();
}

async function loadAcademicYears(selectedId = '') {
    const result = await fetchJson('api/sectioning/academic_years.php');
    const list = result.academic_years || [];

    if (!list.length) {
        document.getElementById('academicYearId').innerHTML = '<option value="">No academic year found</option>';
        return;
    }

    document.getElementById('academicYearId').innerHTML = list.map(y => `
        <option value="${y.id}" ${String(selectedId) === String(y.id) ? 'selected' : ''}>
            ${esc(y.year_label)}${String(y.is_active) === '1' ? ' (Active)' : ''}
        </option>
    `).join('');
}

async function loadSectionAdviser() {
    try {
        const res = await fetchJson(`api/sectioning/adviser_get.php?section_id=${SECTION_ID}`);
        document.getElementById('infoAdviser').textContent = res.teacher_name || '-';
    } catch (err) {
        console.error('Failed to load adviser:', err);
        document.getElementById('infoAdviser').textContent = '-';
    }
}

function refreshViewLink() {
    const academicYearId = document.getElementById('academicYearId').value || '';
    document.getElementById('viewMasterlistBtn').href = `sectioning_view.php?id=${SECTION_ID}&academic_year_id=${academicYearId}`;
}

async function loadMasterlist() {
    const academicYearId = document.getElementById('academicYearId').value;
    const search = document.getElementById('studentSearchInput').value.trim();

    if (!academicYearId) {
        document.getElementById('masterlistTableBody').innerHTML = '';
        document.getElementById('masterlistCardView').innerHTML = '';
        currentStudents = [];
        updateBulkActions();
        return;
    }

    const data = await fetchJson(`api/sectioning/students_in_section.php?section_id=${SECTION_ID}&academic_year_id=${academicYearId}&s=${encodeURIComponent(search)}`);
    currentStudents = data.students || [];

    selectedStudents.clear();
    document.getElementById('selectAllCheckbox').checked = false;
    updateBulkActions();

    renderStudentList();
}

function renderStudentList() {
    const list = currentStudents;

    document.getElementById('masterlistTableBody').innerHTML = list.map((s, i) => `
        <tr>
            <td>
                <input type="checkbox" class="student-checkbox" value="${s.section_student_id}"
                    onchange="toggleStudentSelection(${s.section_student_id})"
                    ${selectedStudents.has(s.section_student_id) ? 'checked' : ''}>
            </td>
            <td data-label="#">${i + 1}</td>
            <td data-label="Student ID">${esc(s.student_identifier || s.id)}</td>
            <td data-label="Student Name" class="text-start">${esc(s.full_name || '-')}</td>
            <td data-label="Sex">${esc(s.sex || '-')}</td>
            <td data-label="Actions">
                <button class="btn btn-sm btn-warning me-1" onclick="openTransferSingleModal(${s.section_student_id})">
                    <i class="bi bi-arrow-left-right"></i> Transfer
                </button>
                <button class="btn btn-sm btn-danger" onclick="removeStudent(${s.section_student_id})">
                    <i class="bi bi-person-dash"></i> Remove
                </button>
            </td>
        </tr>
    `).join('');

    document.getElementById('masterlistCardView').innerHTML = list.map((s, i) => `
        <div class="card mb-3 shadow-sm">
            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                <div class="form-check">
                    <input class="form-check-input student-checkbox" type="checkbox" value="${s.section_student_id}"
                        onchange="toggleStudentSelection(${s.section_student_id})"
                        ${selectedStudents.has(s.section_student_id) ? 'checked' : ''}>
                    <span class="fw-bold ms-2">${i + 1}. ${esc(s.full_name || '-')}</span>
                </div>
            </div>
            <div class="card-body py-2 small">
                <div class="row mb-1">
                    <div class="col-4 text-muted">Student ID</div>
                    <div class="col-8">${esc(s.student_identifier || s.id)}</div>
                </div>
                <div class="row mb-1">
                    <div class="col-4 text-muted">Sex</div>
                    <div class="col-8">${esc(s.sex || '-')}</div>
                </div>
            </div>
            <div class="card-footer d-grid gap-2">
                <button class="btn btn-sm btn-warning" onclick="openTransferSingleModal(${s.section_student_id})">
                    <i class="bi bi-arrow-left-right"></i> Transfer
                </button>
                <button class="btn btn-sm btn-danger" onclick="removeStudent(${s.section_student_id})">
                    <i class="bi bi-person-dash"></i> Remove
                </button>
            </div>
        </div>
    `).join('');
}

function toggleStudentSelection(id) {
    if (selectedStudents.has(id)) {
        selectedStudents.delete(id);
    } else {
        selectedStudents.add(id);
    }
    updateBulkActions();
}

function toggleSelectAll() {
    const isChecked = document.getElementById('selectAllCheckbox').checked;
    if (isChecked) {
        currentStudents.forEach(s => selectedStudents.add(s.section_student_id));
    } else {
        selectedStudents.clear();
    }
    renderStudentList();
    updateBulkActions();
}

function updateBulkActions() {
    const count = selectedStudents.size;
    const bulkActions = document.getElementById('bulkActions');
    const countDisplay = document.getElementById('selectedCount');

    if (count > 0) {
        bulkActions.classList.add('show');
        countDisplay.textContent = `${count} selected`;
    } else {
        bulkActions.classList.remove('show');
    }
}

function clearSelection() {
    selectedStudents.clear();
    document.getElementById('selectAllCheckbox').checked = false;
    renderStudentList();
    updateBulkActions();
}

async function openTransferModal() {
    if (selectedStudents.size === 0) {
        alert('Please select at least one student to transfer.');
        return;
    }

    document.getElementById('transferCount').textContent = selectedStudents.size;

    const selectedStudentData = currentStudents.filter(s => selectedStudents.has(s.section_student_id));
    document.getElementById('transferStudentList').innerHTML = selectedStudentData.map(s => `
        <div class="mb-1"><i class="bi bi-person"></i> ${esc(s.full_name)} (${esc(s.student_identifier || s.id)})</div>
    `).join('');

    await loadTargetSections();

    new bootstrap.Modal(document.getElementById('transferModal')).show();
}

async function openTransferSingleModal(sectionStudentId) {
    selectedStudents.clear();
    selectedStudents.add(sectionStudentId);
    updateBulkActions();

    await openTransferModal();
}

async function loadTargetSections() {
    if (!currentSectionInfo) return;

    const gradeLevelId = currentSectionInfo.grade_level_id;

    try {
        const result = await fetchJson(`api/sectioning/sections_by_grade.php?grade_level_id=${gradeLevelId}&exclude_section_id=${SECTION_ID}`);
        const sections = result.sections || [];

        const options = ['<option value="">Select Target Section</option>']
            .concat(sections.map(s => `
                <option value="${s.id}">
                    ${esc(s.section_name)} - Adviser: ${esc(s.adviser_name || '-')} - ${esc(s.total_students || 0)} students
                </option>
            `))
            .join('');

        document.getElementById('targetSectionId').innerHTML = options;
    } catch (err) {
        console.error('Failed to load target sections:', err);
        document.getElementById('targetSectionId').innerHTML = '<option value="">Error loading sections</option>';
    }
}

document.getElementById('transferForm').addEventListener('submit', async e => {
    e.preventDefault();

    const targetSectionId = document.getElementById('targetSectionId').value;
    const academicYearId = document.getElementById('academicYearId').value;

    if (!targetSectionId) {
        alert('Please select a target section.');
        return;
    }

    if (!confirm(`Transfer ${selectedStudents.size} student(s) to the selected section?`)) {
        return;
    }

    try {
        const result = await fetchJson('api/sectioning/transfer_students.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                source_section_id: SECTION_ID,
                target_section_id: targetSectionId,
                academic_year_id: academicYearId,
                student_ids: Array.from(selectedStudents)
            })
        });

        if (result.success) {
            bootstrap.Modal.getInstance(document.getElementById('transferModal')).hide();
            alert(`Successfully transferred ${result.transferred_count || selectedStudents.size} student(s).`);
            selectedStudents.clear();
            updateBulkActions();
            await loadMasterlist();
            await loadAvailableStudents();
        } else {
            alert(result.error || 'Transfer failed.');
        }
    } catch (err) {
        console.error(err);
        alert('Transfer failed: ' + err.message);
    }
});

async function removeSelectedStudents() {
    if (selectedStudents.size === 0) return;

    if (!confirm(`Remove ${selectedStudents.size} selected student(s) from this section?`)) {
        return;
    }

    let removed = 0;
    let failed = 0;

    for (const id of selectedStudents) {
        try {
            const res = await fetchJson('api/sectioning/remove_student.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ id: id })
            });
            if (res.success) removed++;
            else failed++;
        } catch (e) {
            failed++;
        }
    }

    alert(`Removed ${removed} student(s).${failed > 0 ? ` Failed: ${failed}` : ''}`);
    selectedStudents.clear();
    updateBulkActions();
    await loadMasterlist();
    await loadAvailableStudents();
}

async function loadAvailableStudents() {
    const academicYearId = document.getElementById('academicYearId').value;
    if (!academicYearId) {
        document.getElementById('studentId').innerHTML = '<option value="">No academic year found</option>';
        return;
    }

    const data = await fetchJson(`api/sectioning/students_available.php?section_id=${SECTION_ID}&academic_year_id=${academicYearId}`);
    const list = data.students || [];

    document.getElementById('studentId').innerHTML =
        ['<option value="">Select Student</option>']
        .concat(
            list.map(s => `<option value="${s.id}">${esc(s.full_name || '-')} ${s.student_identifier ? '(' + esc(s.student_identifier) + ')' : ''} ${s.sex ? '- ' + esc(s.sex) : ''}</option>`)
        )
        .join('');

    if (!list.length) {
        document.getElementById('studentId').innerHTML = '<option value="">No available students</option>';
    }
}

async function openAddStudentModal() {
    await loadAvailableStudents();
    new bootstrap.Modal(document.getElementById('addStudentModal')).show();
}

async function removeStudent(id) {
    if (!confirm('Remove this student from section?')) return;

    const res = await fetchJson('api/sectioning/remove_student.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ id: id })
    });

    if (res.success) {
        await loadMasterlist();
        await loadAvailableStudents();
    } else {
        alert(res.error || 'Remove failed');
    }
}

document.getElementById('addStudentForm').addEventListener('submit', async e => {
    e.preventDefault();

    const res = await fetchJson('api/sectioning/add_student.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            section_id: SECTION_ID,
            academic_year_id: document.getElementById('academicYearId').value,
            student_id: document.getElementById('studentId').value
        })
    });

    if (res.success) {
        bootstrap.Modal.getInstance(document.getElementById('addStudentModal')).hide();
        await loadMasterlist();
        await loadAvailableStudents();
    } else {
        alert(res.error || 'Add failed');
    }
});

document.getElementById('studentSearchInput').addEventListener('input', loadMasterlist);

loadSectionInfo()
    .then(async () => {
        await loadSectionAdviser();
        await loadMasterlist();
    })
    .catch(err => {
        console.error(err);
        alert('Failed to load sectioning page: ' + err.message);
    });
</script>
</body>
</html>