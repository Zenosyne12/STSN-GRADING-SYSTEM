<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

function respond($success, $message = '')
{
    echo json_encode([
        'success' => $success,
        'message' => $message
    ]);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!is_array($input)) {
        throw new Exception('Invalid request payload.');
    }

    $id = isset($input['id']) && $input['id'] !== '' ? (int) $input['id'] : 0;
    $yearLabel = isset($input['year_label']) ? trim($input['year_label']) : '';

    if ($yearLabel === '') {
        throw new Exception('Academic year is required.');
    }

    if ($id > 0) {
        $check = $pdo->prepare("SELECT COUNT(*) FROM tblacademicyear WHERE year_label = ? AND id <> ?");
        $check->execute([$yearLabel, $id]);

        if ((int) $check->fetchColumn() > 0) {
            throw new Exception('Academic year already exists.');
        }

        $stmt = $pdo->prepare("UPDATE tblacademicyear SET year_label = ? WHERE id = ?");
        $stmt->execute([$yearLabel, $id]);

        respond(true, 'Academic year updated successfully.');
    }

    $check = $pdo->prepare("SELECT COUNT(*) FROM tblacademicyear WHERE year_label = ?");
    $check->execute([$yearLabel]);

    if ((int) $check->fetchColumn() > 0) {
        throw new Exception('Academic year already exists.');
    }

    $stmt = $pdo->prepare("
        INSERT INTO tblacademicyear (year_label, is_active)
        VALUES (?, 0)
    ");
    $stmt->execute([$yearLabel]);

    respond(true, 'Academic year added successfully.');
} catch (Throwable $e) {
    respond(false, $e->getMessage());
}