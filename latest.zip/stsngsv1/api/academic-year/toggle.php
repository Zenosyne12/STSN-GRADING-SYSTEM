<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

function respond($success, $message = '', $extra = [])
{
    echo json_encode(array_merge([
        'success' => $success,
        'message' => $message
    ], $extra));
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!is_array($input)) {
        throw new Exception('Invalid request payload.');
    }

    $id = isset($input['id']) ? (int) $input['id'] : 0;
    $isActive = isset($input['is_active']) ? (int) $input['is_active'] : -1;

    if ($id <= 0) {
        throw new Exception('Invalid academic year id.');
    }

    if (!in_array($isActive, [0, 1], true)) {
        throw new Exception('Invalid active state.');
    }

    $stmt = $pdo->prepare("
        SELECT id, year_label, is_active
        FROM tblacademicyear
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->execute([$id]);
    $year = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$year) {
        throw new Exception('Academic year not found.');
    }

    $pdo->beginTransaction();

    if ($isActive === 1) {
        $pdo->exec("UPDATE tblacademicyear SET is_active = 0");
        $update = $pdo->prepare("UPDATE tblacademicyear SET is_active = 1 WHERE id = ?");
        $update->execute([$id]);

        $pdo->commit();
        respond(true, 'Academic year activated successfully.');
    }

    $activeCountStmt = $pdo->query("SELECT COUNT(*) FROM tblacademicyear WHERE is_active = 1");
    $activeCount = (int) $activeCountStmt->fetchColumn();

    if ((int) $year['is_active'] === 1 && $activeCount <= 1) {
        $pdo->rollBack();
        respond(false, 'You cannot deactivate the only active academic year.');
    }

    $update = $pdo->prepare("UPDATE tblacademicyear SET is_active = 0 WHERE id = ?");
    $update->execute([$id]);

    $pdo->commit();
    respond(true, 'Academic year deactivated successfully.');
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    respond(false, $e->getMessage());
}