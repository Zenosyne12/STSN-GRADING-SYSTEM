<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $page = isset($_GET['p']) ? max(1, (int)$_GET['p']) : 1;
    $limit = 10;
    $offset = ($page - 1) * $limit;

    $countStmt = $pdo->query("SELECT COUNT(*) FROM tblacademicyear");
    $total = (int)$countStmt->fetchColumn();
    $pages = max(1, (int) ceil($total / $limit));

    $stmt = $pdo->prepare("
        SELECT id, year_label, is_active, created_at
        FROM tblacademicyear
        ORDER BY year_label DESC
        LIMIT :offset, :limit
    ");
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();

    $activeStmt = $pdo->query("
        SELECT year_label
        FROM tblacademicyear
        WHERE is_active = 1
        LIMIT 1
    ");
    $activeYear = $activeStmt ? (string) $activeStmt->fetchColumn() : '';

    echo json_encode([
        'success' => true,
        'years' => $stmt->fetchAll(PDO::FETCH_ASSOC),
        'page' => $page,
        'pages' => $pages,
        'active_year' => $activeYear
    ]);
} catch (Throwable $e) {
    echo json_encode([
        'success' => false,
        'years' => [],
        'page' => 1,
        'pages' => 1,
        'active_year' => '',
        'message' => $e->getMessage()
    ]);
}