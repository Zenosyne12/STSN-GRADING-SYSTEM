<?php
require_once __DIR__.'/../shared/db_connect.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

$id             = (int)($data['id'] ?? 0);
$grade_level_id = (int)($data['grade_level_id'] ?? 0);
$section_name   = trim($data['section_name'] ?? '');

if ($grade_level_id <= 0 || $section_name === '') {
    http_response_code(422);
    echo json_encode([
        'success' => false,
        'error' => 'Grade Level and Section Name are required'
    ]);
    exit;
}

$checkGrade = $pdo->prepare("SELECT id FROM tblgradelevel WHERE id = ?");
$checkGrade->execute([$grade_level_id]);

if (!$checkGrade->fetch()) {
    http_response_code(422);
    echo json_encode([
        'success' => false,
        'error' => 'Invalid grade level'
    ]);
    exit;
}

try {
    if ($id) {
        $check = $pdo->prepare("
            SELECT id
            FROM tblsection
            WHERE section_name = ? AND grade_level_id = ? AND id <> ?
        ");
        $check->execute([$section_name, $grade_level_id, $id]);

        if ($check->fetch()) {
            http_response_code(422);
            echo json_encode([
                'success' => false,
                'error' => 'Section name already exists for this grade level'
            ]);
            exit;
        }

        $stmt = $pdo->prepare("
            UPDATE tblsection
            SET grade_level_id = ?, section_name = ?
            WHERE id = ?
        ");
        $stmt->execute([$grade_level_id, $section_name, $id]);
    } else {
        $check = $pdo->prepare("
            SELECT id
            FROM tblsection
            WHERE section_name = ? AND grade_level_id = ?
        ");
        $check->execute([$section_name, $grade_level_id]);

        if ($check->fetch()) {
            http_response_code(422);
            echo json_encode([
                'success' => false,
                'error' => 'Section name already exists for this grade level'
            ]);
            exit;
        }

        $stmt = $pdo->prepare("
            INSERT INTO tblsection (grade_level_id, section_name)
            VALUES (?, ?)
        ");
        $stmt->execute([$grade_level_id, $section_name]);
    }

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
}
?>