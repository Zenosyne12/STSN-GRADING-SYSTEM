<?php
require_once __DIR__.'/../shared/db_connect.php';
header('Content-Type: application/json');

$search = isset($_GET['s']) ? trim($_GET['s']) : '';
$page   = max(1, (int)($_GET['p'] ?? 1));
$limit  = 10;
$offset = ($page - 1) * $limit;

$where  = '';
$params = [];

if ($search !== '') {
    $where = " WHERE (
        s.section_name LIKE :s
        OR g.grade_level_name LIKE :s
    ) ";
    $params['s'] = "%$search%";
}

$cnt = $pdo->prepare("
    SELECT COUNT(*)
    FROM tblsection s
    LEFT JOIN tblgradelevel g ON s.grade_level_id = g.id
    $where
");
$cnt->execute($params);
$total = (int)$cnt->fetchColumn();
$pages = max(1, ceil($total / $limit));

$sql = "
    SELECT
        s.id,
        s.grade_level_id,
        g.grade_level_name,
        s.section_name,
        s.is_active
    FROM tblsection s
    LEFT JOIN tblgradelevel g ON s.grade_level_id = g.id
    $where
    ORDER BY s.grade_level_id ASC, s.section_name ASC
    LIMIT $offset, $limit
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

echo json_encode([
    'sections' => $stmt->fetchAll(PDO::FETCH_ASSOC),
    'page'     => $page,
    'pages'    => $pages,
    'total'    => $total
]);
?>