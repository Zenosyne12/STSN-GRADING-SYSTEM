<?php
// api/curriculum/delete_weights.php
// POST JSON: { curriculum_id }
// Same as delete_subject — removes curriculum_grade row (and orphan subject)

require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) throw new Exception('Invalid JSON payload.');

    $curriculumId = (int) ($input['curriculum_id'] ?? 0);
    if ($curriculumId <= 0) throw new Exception('curriculum_id is required.');

    $pdo->beginTransaction();

    $stmt = $pdo->prepare("SELECT subject_id FROM tblcurriculum_grade WHERE id=? LIMIT 1");
    $stmt->execute([$curriculumId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) throw new Exception('Curriculum record not found.');

    $subjectId = (int) $row['subject_id'];

    $pdo->prepare("DELETE FROM tblcurriculum_grade WHERE id=?")->execute([$curriculumId]);

    $check = $pdo->prepare("SELECT COUNT(*) FROM tblcurriculum_grade WHERE subject_id=?");
    $check->execute([$subjectId]);
    if ((int) $check->fetchColumn() === 0) {
        $pdo->prepare("DELETE FROM tblsubjects WHERE id=?")->execute([$subjectId]);
    }

    $pdo->commit();
    echo json_encode(['success' => true, 'message' => 'Curriculum record deleted successfully.']);

} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}