<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) {
        throw new Exception('Invalid JSON payload.');
    }

    $curriculumId = (int)($input['curriculum_id'] ?? 0);
    $ww = (int)($input['ww'] ?? 0);
    $pt = (int)($input['pt'] ?? 0);
    $qa = (int)($input['qa'] ?? 0);
    $sortOrder = (int)($input['sort_order'] ?? 0);
    $isActive = isset($input['is_active']) ? (int)!!$input['is_active'] : 1;

    if ($curriculumId <= 0) {
        throw new Exception('curriculum_id is required.');
    }

    if (($ww + $pt + $qa) !== 100) {
        throw new Exception('Weights must total 100.');
    }

    $stmt = $pdo->prepare("
        UPDATE tblcurriculum_grade
        SET ww = :ww,
            pt = :pt,
            qa = :qa,
            sort_order = :sort_order,
            is_active = :is_active
        WHERE id = :id
    ");
    $stmt->execute([
        ':ww' => $ww,
        ':pt' => $pt,
        ':qa' => $qa,
        ':sort_order' => $sortOrder,
        ':is_active' => $isActive,
        ':id' => $curriculumId
    ]);

    echo json_encode([
        'success' => true,
        'message' => 'Curriculum weights updated successfully.'
    ]);
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}