<?php
// api/curriculum/save_subject.php
// POST JSON: create or update a subject + its tblcurriculum_grade row
// Body: { curriculum_id?, grade_level_id, subject_code, subject_name,
//         subject_type, description, is_active }

require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) throw new Exception('Invalid JSON payload.');

    $curriculumId = !empty($input['curriculum_id']) ? (int) $input['curriculum_id'] : null;
    $gradeLevelId = (int) ($input['grade_level_id'] ?? 0);
    $subjectCode  = trim($input['subject_code']   ?? '');
    $subjectName  = trim($input['subject_name']   ?? '');
    $subjectType  = strtoupper(trim($input['subject_type'] ?? 'CORE'));
    $description  = trim($input['description']    ?? '');
    $isActive     = isset($input['is_active']) ? (int) (bool) $input['is_active'] : 1;

    if ($gradeLevelId <= 0)   throw new Exception('grade_level_id is required.');
    if ($subjectCode === '')  throw new Exception('Subject code is required.');
    if ($subjectName === '')  throw new Exception('Subject name is required.');

    $allowed = ['CORE', 'APPLIED', 'SPECIALIZED', 'ELECTIVE'];
    if (!in_array($subjectType, $allowed, true)) throw new Exception('Invalid subject type.');

    $pdo->beginTransaction();

    if ($curriculumId) {
        // ── UPDATE existing ───────────────────────────────────
        // Get subject_id from curriculum row
        $stmt = $pdo->prepare(
            "SELECT subject_id FROM tblcurriculum_grade WHERE id = ? LIMIT 1"
        );
        $stmt->execute([$curriculumId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) throw new Exception('Curriculum record not found.');

        $subjectId = (int) $row['subject_id'];

        // Check duplicate code (exclude self)
        $dup = $pdo->prepare(
            "SELECT COUNT(*) FROM tblsubjects WHERE subject_code = ? AND id <> ?"
        );
        $dup->execute([$subjectCode, $subjectId]);
        if ((int) $dup->fetchColumn() > 0) throw new Exception('Subject code already in use.');

        $pdo->prepare(
            "UPDATE tblsubjects
             SET subject_code=?, subject_name=?, subject_type=?,
                 description=?, is_active=?
             WHERE id=?"
        )->execute([$subjectCode, $subjectName, $subjectType, $description, $isActive, $subjectId]);

        $pdo->prepare(
            "UPDATE tblcurriculum_grade SET is_active=? WHERE id=?"
        )->execute([$isActive, $curriculumId]);

        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Subject updated successfully.']);

    } else {
        // ── INSERT new ────────────────────────────────────────
        $dup = $pdo->prepare("SELECT COUNT(*) FROM tblsubjects WHERE subject_code = ?");
        $dup->execute([$subjectCode]);
        if ((int) $dup->fetchColumn() > 0) throw new Exception('Subject code already exists.');

        $pdo->prepare(
            "INSERT INTO tblsubjects (subject_code, subject_name, subject_type, description, is_active)
             VALUES (?, ?, ?, ?, ?)"
        )->execute([$subjectCode, $subjectName, $subjectType, $description, $isActive]);

        $subjectId = (int) $pdo->lastInsertId();

        // Check not already assigned to this grade
        $exists = $pdo->prepare(
            "SELECT COUNT(*) FROM tblcurriculum_grade WHERE grade_level_id=? AND subject_id=?"
        );
        $exists->execute([$gradeLevelId, $subjectId]);
        if ((int) $exists->fetchColumn() > 0) throw new Exception('Subject already assigned to this grade.');

        $pdo->prepare(
            "INSERT INTO tblcurriculum_grade (grade_level_id, subject_id, ww, pt, qa, is_active)
             VALUES (?, ?, 30, 50, 20, ?)"
        )->execute([$gradeLevelId, $subjectId, $isActive]);

        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Subject added to grade successfully.']);
    }

} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}