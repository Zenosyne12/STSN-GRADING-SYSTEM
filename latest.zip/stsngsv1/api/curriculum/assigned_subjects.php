<?php
// api/curriculum/assigned_subjects.php
// GET ?grade_id=<tblgradelevel.id>
// Returns all subjects assigned to this grade via tblcurriculum_grade

require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

$gradeId = isset($_GET['grade_id']) ? (int) $_GET['grade_id'] : 0;

if ($gradeId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'grade_id is required.']);
    exit;
}

try {
    // Grade meta
    $stmtGrade = $pdo->prepare(
        "SELECT id, grade_level_name FROM tblgradelevel WHERE id = ? LIMIT 1"
    );
    $stmtGrade->execute([$gradeId]);
    $gradeRow = $stmtGrade->fetch(PDO::FETCH_ASSOC);

    if (!$gradeRow) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Grade not found.']);
        exit;
    }

    // Derive level label from ID (matches tblgradelevel seed data)
    $id = (int) $gradeRow['id'];
    if ($id === 1)                  $levelLabel = 'Kinder';
    elseif ($id >= 2  && $id <= 7)  $levelLabel = 'Elementary';
    elseif ($id >= 8  && $id <= 11) $levelLabel = 'Junior High School';
    elseif ($id >= 12 && $id <= 13) $levelLabel = 'Senior High School';
    else                            $levelLabel = '';

    $grade = [
        'id'          => $id,
        'grade_label' => $gradeRow['grade_level_name'],
        'level_label' => $levelLabel,
    ];

    // Assigned subjects
    $stmtSubj = $pdo->prepare(
        "SELECT
            cg.id            AS curriculum_id,
            cg.grade_level_id,
            cg.is_active,
            s.id             AS subject_id,
            s.subject_code,
            s.subject_name,
            s.subject_type,
            s.description
         FROM tblcurriculum_grade cg
         JOIN tblsubjects s ON s.id = cg.subject_id
         WHERE cg.grade_level_id = ?
         ORDER BY s.subject_name ASC"
    );
    $stmtSubj->execute([$gradeId]);
    $subjects = $stmtSubj->fetchAll(PDO::FETCH_ASSOC);

    // Cast types
    foreach ($subjects as &$row) {
        $row['curriculum_id']   = (int) $row['curriculum_id'];
        $row['grade_level_id']  = (int) $row['grade_level_id'];
        $row['subject_id']      = (int) $row['subject_id'];
        $row['is_active']       = (int) $row['is_active'];
    }
    unset($row);

    echo json_encode([
        'success'  => true,
        'grade'    => $grade,
        'subjects' => $subjects,
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}