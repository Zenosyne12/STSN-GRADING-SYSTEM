<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $stmt = $pdo->query("
        SELECT id, year_label, is_active
        FROM tblacademicyear
        ORDER BY is_active DESC, id DESC
    ");

    echo json_encode([
        'success' => true,
        'academic_years' => $stmt->fetchAll(PDO::FETCH_ASSOC)
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'academic_years' => [],
        'error' => $e->getMessage()
    ]);
}