<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

$sectionId = (int)($_GET['section_id'] ?? 0);
$academicYearId = (int)($_GET['academic_year_id'] ?? 0);

if ($sectionId <= 0 || $academicYearId <= 0) {
    echo json_encode(['schedules' => []]);
    exit;
}

$stmt = $pdo->prepare("
    SELECT
        sc.id,
        sc.subject_id,
        sc.teacher_id,
        sc.day_of_week,
        sc.time_start,
        sc.time_end,
        DATE_FORMAT(sc.time_start, '%h:%i %p') AS time_start_12,
        DATE_FORMAT(sc.time_end, '%h:%i %p') AS time_end_12,
        sc.room,
        sc.remarks,
        sc.is_active,
        sub.subject_name,
        CONCAT(t.lname, ', ', t.fname) AS teacher_name
    FROM tblschedule sc
    INNER JOIN tblsubjects sub ON sc.subject_id = sub.id
    INNER JOIN tblteacher t ON sc.teacher_id = t.id
    WHERE sc.section_id = ? AND sc.academic_year_id = ?
    ORDER BY
        FIELD(sc.day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'),
        sc.time_start ASC,
        sub.subject_name ASC
");
$stmt->execute([$sectionId, $academicYearId]);

echo json_encode([
    'schedules' => $stmt->fetchAll(PDO::FETCH_ASSOC)
]);