<?php
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

try {
    $search = trim($_GET['s'] ?? '');
    $gradeLevelId = trim($_GET['grade_level_id'] ?? '');

    $sql = "
        SELECT 
            s.id,
            s.grade_level_id,
            s.section_name,
            s.is_active,
            g.grade_level_name
        FROM tblsection s
        LEFT JOIN tblgradelevel g ON g.id = s.grade_level_id
        WHERE 1=1
    ";

    $params = [];

    if ($gradeLevelId !== '') {
        $sql .= " AND s.grade_level_id = ? ";
        $params[] = $gradeLevelId;
    }

    if ($search !== '') {
        $sql .= " AND (
            s.section_name LIKE ?
            OR g.grade_level_name LIKE ?
        ) ";
        $like = "%{$search}%";
        $params[] = $like;
        $params[] = $like;
    }

    $sql .= " ORDER BY s.grade_level_id ASC, s.section_name ASC ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    $sections = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'sections' => $sections
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>