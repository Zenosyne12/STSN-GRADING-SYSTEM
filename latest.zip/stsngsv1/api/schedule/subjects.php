<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $sectionId = (int)($_GET['section_id'] ?? 0);
    $academicYearId = (int)($_GET['academic_year_id'] ?? 0);
    $excludeScheduleId = (int)($_GET['exclude_schedule_id'] ?? 0);

    $sql = "
        SELECT s.id, s.subject_code, s.subject_name
        FROM tblsubjects s
        WHERE s.is_active = 1
    ";
    $params = [];

    // Exclude subjects already scheduled for this section/academic year
    if ($sectionId > 0 && $academicYearId > 0) {
        $sql .= " AND s.id NOT IN (
            SELECT subject_id FROM tblschedule 
            WHERE section_id = ? 
            AND academic_year_id = ?
            " . ($excludeScheduleId > 0 ? "AND id != ?" : "") . "
        )";
        $params[] = $sectionId;
        $params[] = $academicYearId;
        if ($excludeScheduleId > 0) {
            $params[] = $excludeScheduleId;
        }
    }

    $sql .= " ORDER BY s.subject_name ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    echo json_encode([
        'success' => true,
        'subjects' => $stmt->fetchAll(PDO::FETCH_ASSOC)
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'subjects' => [],
        'error' => $e->getMessage()
    ]);
}