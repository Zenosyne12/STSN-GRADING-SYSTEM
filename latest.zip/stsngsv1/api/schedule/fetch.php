<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Bad ID']);
    exit;
}

$stmt = $pdo->prepare("
    SELECT
        id,
        academic_year_id,
        section_id,
        subject_id,
        teacher_id,
        day_of_week,
        time_start,
        time_end,
        room,
        remarks,
        is_active
    FROM tblschedule
    WHERE id = ?
");
$stmt->execute([$id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    http_response_code(404);
    echo json_encode(['error' => 'Schedule not found']);
    exit;
}

echo json_encode($row);