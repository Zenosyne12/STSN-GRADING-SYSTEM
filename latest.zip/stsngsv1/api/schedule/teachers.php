<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $sectionId = (int)($_GET['section_id'] ?? 0);
    $academicYearId = (int)($_GET['academic_year_id'] ?? 0);
    $excludeScheduleId = (int)($_GET['exclude_schedule_id'] ?? 0);

    $sql = "
        SELECT
            id,
            CONCAT(
                lname, ', ', fname,
                CASE
                    WHEN mname IS NULL OR mname = '' THEN ''
                    ELSE CONCAT(' ', LEFT(mname, 1), '.')
                END
            ) AS full_name
        FROM tblteacher
        WHERE is_active = 1
    ";
    $params = [];

    if ($sectionId > 0 && $academicYearId > 0) {
        $sql .= " AND id NOT IN (
            SELECT teacher_id FROM tblschedule 
            WHERE section_id = ? 
            AND academic_year_id = ?
            " . ($excludeScheduleId > 0 ? "AND id != ?" : "") . "
        )";
        $params[] = $sectionId;
        $params[] = $academicYearId;
        if ($excludeScheduleId > 0) {
            $params[] = $excludeScheduleId;
        }
    }

    $sql .= " ORDER BY lname ASC, fname ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    echo json_encode([
        'success' => true,
        'teachers' => $stmt->fetchAll(PDO::FETCH_ASSOC)
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'teachers' => [],
        'error' => $e->getMessage()
    ]);
}