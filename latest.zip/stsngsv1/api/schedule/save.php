<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

$id = (int)($data['id'] ?? 0);
$academicYearId = (int)($data['academic_year_id'] ?? 0);
$sectionId = (int)($data['section_id'] ?? 0);
$subjectId = (int)($data['subject_id'] ?? 0);
$teacherId = (int)($data['teacher_id'] ?? 0);
$dayOfWeek = trim($data['day_of_week'] ?? '');
$timeStart = trim($data['time_start'] ?? '');
$timeEnd = trim($data['time_end'] ?? '');
$room = trim($data['room'] ?? '');
$remarks = trim($data['remarks'] ?? '');
$isActive = (int)($data['is_active'] ?? 1);

$validDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

if (
    $academicYearId <= 0 ||
    $sectionId <= 0 ||
    $subjectId <= 0 ||
    $teacherId <= 0 ||
    $dayOfWeek === '' ||
    $timeStart === '' ||
    $timeEnd === ''
) {
    http_response_code(422);
    echo json_encode(['success' => false, 'error' => 'All required fields must be filled out']);
    exit;
}

if (!in_array($dayOfWeek, $validDays, true)) {
    http_response_code(422);
    echo json_encode(['success' => false, 'error' => 'Invalid day selected']);
    exit;
}

if ($timeStart >= $timeEnd) {
    http_response_code(422);
    echo json_encode(['success' => false, 'error' => 'End time must be later than start time']);
    exit;
}

// Check for subject conflict (same subject already scheduled for this section/year)
$subjectConflict = $pdo->prepare("
    SELECT id FROM tblschedule
    WHERE academic_year_id = ? AND section_id = ? AND subject_id = ?
    " . ($id > 0 ? "AND id != ?" : "") . "
    LIMIT 1
");
$params = [$academicYearId, $sectionId, $subjectId];
if ($id > 0) $params[] = $id;
$subjectConflict->execute($params);

if ($subjectConflict->fetch()) {
    http_response_code(422);
    echo json_encode(['success' => false, 'error' => 'This subject is already scheduled for this section']);
    exit;
}

// Check for teacher time conflict
$teacherConflict = $pdo->prepare("
    SELECT id FROM tblschedule
    WHERE academic_year_id = ? AND teacher_id = ? AND day_of_week = ?
    AND (? < time_end) AND (? > time_start)
    " . ($id > 0 ? "AND id != ?" : "") . "
    LIMIT 1
");
$params = [$academicYearId, $teacherId, $dayOfWeek, $timeStart, $timeEnd];
if ($id > 0) $params[] = $id;
$teacherConflict->execute($params);

if ($teacherConflict->fetch()) {
    http_response_code(422);
    echo json_encode(['success' => false, 'error' => 'Teacher has a time conflict on this day']);
    exit;
}

// Check for section time conflict
$sectionConflict = $pdo->prepare("
    SELECT id FROM tblschedule
    WHERE academic_year_id = ? AND section_id = ? AND day_of_week = ?
    AND (? < time_end) AND (? > time_start)
    " . ($id > 0 ? "AND id != ?" : "") . "
    LIMIT 1
");
$params = [$academicYearId, $sectionId, $dayOfWeek, $timeStart, $timeEnd];
if ($id > 0) $params[] = $id;
$sectionConflict->execute($params);

if ($sectionConflict->fetch()) {
    http_response_code(422);
    echo json_encode(['success' => false, 'error' => 'Time slot already occupied in this section']);
    exit;
}

if ($id > 0) {
    $stmt = $pdo->prepare("
        UPDATE tblschedule
        SET academic_year_id = ?, section_id = ?, subject_id = ?, teacher_id = ?,
            day_of_week = ?, time_start = ?, time_end = ?, room = ?, remarks = ?, is_active = ?
        WHERE id = ?
    ");
    $stmt->execute([
        $academicYearId, $sectionId, $subjectId, $teacherId,
        $dayOfWeek, $timeStart, $timeEnd, $room, $remarks, $isActive, $id
    ]);
} else {
    $stmt = $pdo->prepare("
        INSERT INTO tblschedule (academic_year_id, section_id, subject_id, teacher_id,
            day_of_week, time_start, time_end, room, remarks, is_active)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $academicYearId, $sectionId, $subjectId, $teacherId,
        $dayOfWeek, $timeStart, $timeEnd, $room, $remarks, $isActive
    ]);
}

echo json_encode(['success' => true]);