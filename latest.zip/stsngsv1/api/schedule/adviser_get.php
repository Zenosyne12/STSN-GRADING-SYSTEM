<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

$sectionId = (int)($_GET['section_id'] ?? 0);
$academicYearId = (int)($_GET['academic_year_id'] ?? 0);

if ($sectionId <= 0 || $academicYearId <= 0) {
    echo json_encode([
        'teacher_id' => null,
        'teacher_name' => null
    ]);
    exit;
}

try {
    $stmt = $pdo->prepare("
        SELECT 
            sa.teacher_id,
            COALESCE(
                t.full_name,
                CONCAT(
                    COALESCE(t.first_name, ''),
                    CASE
                        WHEN COALESCE(t.first_name, '') <> '' AND COALESCE(t.last_name, '') <> '' THEN ' '
                        ELSE ''
                    END,
                    COALESCE(t.last_name, '')
                )
            ) AS teacher_name
        FROM tblsectionadviser sa
        LEFT JOIN tblsectionteacher t ON t.id = sa.teacher_id
        WHERE sa.section_id = ?
          AND sa.academic_year_id = ?
        LIMIT 1
    ");
    $stmt->execute([$sectionId, $academicYearId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    echo json_encode([
        'teacher_id' => $row['teacher_id'] ?? null,
        'teacher_name' => $row['teacher_name'] ?? null
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'teacher_id' => null,
        'teacher_name' => null,
        'error' => $e->getMessage()
    ]);
}