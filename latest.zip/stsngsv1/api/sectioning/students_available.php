<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    error_log('students_available.php GET: ' . print_r($_GET, true));

    $sectionId = (int)($_GET['section_id'] ?? 0);
    $academicYearId = (int)($_GET['academic_year_id'] ?? 0);

    if ($sectionId <= 0 || $academicYearId <= 0) {
        http_response_code(422);
        echo json_encode([
            'success' => false,
            'students' => [],
            'error' => 'Section and academic year are required. Got: section_id=' . ($sectionId ?: 'empty') . ', academic_year_id=' . ($academicYearId ?: 'empty')
        ]);
        exit;
    }

    $colsStmt = $pdo->query("SHOW COLUMNS FROM tblstudents");
    $columns = $colsStmt->fetchAll(PDO::FETCH_COLUMN);

    $fnameCol = in_array('fname', $columns, true) ? 'fname' : (in_array('firstname', $columns, true) ? 'firstname' : null);
    $mnameCol = in_array('mname', $columns, true) ? 'mname' : (in_array('middlename', $columns, true) ? 'middlename' : null);
    $lnameCol = in_array('lname', $columns, true) ? 'lname' : (in_array('lastname', $columns, true) ? 'lastname' : null);

    $studentNoCol = null;
    foreach (['student_no', 'lrn', 'school_id'] as $candidate) {
        if (in_array($candidate, $columns, true)) {
            $studentNoCol = $candidate;
            break;
        }
    }

    $sexCol = null;
    foreach (['sex', 'gender', 'student_gender'] as $candidate) {
        if (in_array($candidate, $columns, true)) {
            $sexCol = $candidate;
            break;
        }
    }

    if (!$fnameCol || !$lnameCol) {
        throw new Exception('Could not detect student name columns in tblstudents');
    }

    $studentIdentifierExpr = $studentNoCol ? "st.`$studentNoCol`" : "st.id";
    $middleExpr = $mnameCol ? "
        CASE
            WHEN COALESCE(st.`$mnameCol`, '') = '' THEN ''
            ELSE CONCAT(' ', LEFT(st.`$mnameCol`, 1), '.')
        END
    " : "''";

    $sexExpr = $sexCol ? "st.`$sexCol`" : "NULL";

    $sql = "
        SELECT
            st.id,
            $studentIdentifierExpr AS student_identifier,
            CONCAT(
                st.`$lnameCol`,
                ', ',
                st.`$fnameCol`,
                $middleExpr
            ) AS full_name,
            $sexExpr AS sex
        FROM tblstudents st
        WHERE NOT EXISTS (
            SELECT 1
            FROM tblsectionstudent ss
            WHERE ss.student_id = st.id
              AND ss.academic_year_id = ?
              AND ss.is_active = 1
        )
        ORDER BY st.`$lnameCol` ASC, st.`$fnameCol` ASC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$academicYearId]);

    echo json_encode([
        'success' => true,
        'students' => $stmt->fetchAll(PDO::FETCH_ASSOC)
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'students' => [],
        'error' => $e->getMessage()
    ]);
}
?>