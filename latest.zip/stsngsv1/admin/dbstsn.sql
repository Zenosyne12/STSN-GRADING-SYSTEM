-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2026 at 12:01 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbstsn`
--

-- --------------------------------------------------------

--
-- Table structure for table `system_notifications`
--

CREATE TABLE `system_notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblacademicyear`
--

CREATE TABLE `tblacademicyear` (
  `id` int(11) NOT NULL,
  `year_label` varchar(9) NOT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblacademicyear`
--

INSERT INTO `tblacademicyear` (`id`, `year_label`, `is_active`, `created_at`) VALUES
(1, '2025-2026', 0, '2025-11-17 13:40:48'),
(6, '2026-2027', 1, '2026-03-30 14:29:03'),
(7, '2028-2029', 0, '2026-03-30 19:20:21');

-- --------------------------------------------------------

--
-- Table structure for table `tbladviser_submissions`
--

CREATE TABLE `tbladviser_submissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `teacher_id` bigint(20) UNSIGNED NOT NULL,
  `section_id` bigint(20) UNSIGNED NOT NULL,
  `quarter` tinyint(4) NOT NULL,
  `school_year` varchar(20) NOT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblbarangay`
--

CREATE TABLE `tblbarangay` (
  `id` int(11) NOT NULL,
  `barangay_name` varchar(100) NOT NULL,
  `city_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblbarangay`
--

INSERT INTO `tblbarangay` (`id`, `barangay_name`, `city_id`) VALUES
(1, 'Barangay 1', 1),
(2, 'Barangay 2', 2),
(3, 'Barangay 3', 3),
(4, 'Barangay 4', 4),
(5, 'Barangay 5', 5);

-- --------------------------------------------------------

--
-- Table structure for table `tblcity`
--

CREATE TABLE `tblcity` (
  `id` int(11) NOT NULL,
  `city_name` varchar(100) NOT NULL,
  `province_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblcity`
--

INSERT INTO `tblcity` (`id`, `city_name`, `province_id`) VALUES
(1, 'Manila', 1),
(2, 'Quezon City', 1),
(3, 'Makati', 1),
(4, 'Dasmariñas', 2),
(5, 'Santa Rosa', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tblcountry`
--

CREATE TABLE `tblcountry` (
  `id` int(11) NOT NULL,
  `country_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblcountry`
--

INSERT INTO `tblcountry` (`id`, `country_name`) VALUES
(1, 'Philippines');

-- --------------------------------------------------------

--
-- Table structure for table `tblcurriculum_grade`
--

CREATE TABLE `tblcurriculum_grade` (
  `id` int(11) NOT NULL,
  `grade_level_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `ww` tinyint(3) UNSIGNED NOT NULL DEFAULT 30,
  `pt` tinyint(3) UNSIGNED NOT NULL DEFAULT 50,
  `qa` tinyint(3) UNSIGNED NOT NULL DEFAULT 20,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblcurriculum_grade`
--

INSERT INTO `tblcurriculum_grade` (`id`, `grade_level_id`, `subject_id`, `ww`, `pt`, `qa`, `is_active`, `created_at`, `updated_at`) VALUES
(111, 2, 5, 30, 50, 20, 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(112, 2, 1, 30, 50, 20, 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(113, 2, 6, 30, 50, 20, 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(114, 2, 7, 30, 50, 20, 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(115, 2, 2, 30, 50, 20, 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(118, 3, 3, 30, 50, 20, 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(119, 3, 4, 30, 50, 20, 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(120, 3, 5, 30, 50, 20, 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(121, 3, 6, 30, 50, 20, 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(122, 3, 7, 30, 50, 20, 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(125, 4, 3, 30, 50, 20, 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(126, 4, 4, 30, 50, 20, 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(127, 4, 5, 30, 50, 20, 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(128, 4, 6, 30, 50, 20, 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(129, 4, 7, 30, 50, 20, 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(130, 4, 8, 30, 50, 20, 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(132, 5, 9, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(133, 5, 3, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(134, 5, 10, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(135, 5, 4, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(136, 5, 5, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(137, 5, 11, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(138, 5, 7, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(139, 5, 12, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(140, 5, 8, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(147, 6, 9, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(148, 6, 3, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(149, 6, 10, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(150, 6, 4, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(151, 6, 5, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(152, 6, 11, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(153, 6, 7, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(154, 6, 12, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(155, 6, 8, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(162, 7, 9, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(163, 7, 3, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(164, 7, 4, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(165, 7, 5, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(166, 7, 11, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(167, 7, 7, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(168, 7, 12, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(169, 7, 8, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(170, 7, 13, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(177, 8, 9, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(178, 8, 3, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(179, 8, 4, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(180, 8, 11, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(181, 8, 7, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(182, 8, 12, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(183, 8, 8, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(184, 8, 13, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(185, 8, 14, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(192, 9, 9, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(193, 9, 3, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(194, 9, 4, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(195, 9, 11, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(196, 9, 7, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(197, 9, 12, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(198, 9, 8, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(199, 9, 13, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(200, 9, 14, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(207, 10, 9, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(208, 10, 3, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(209, 10, 4, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(210, 10, 11, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(211, 10, 7, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(212, 10, 12, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(213, 10, 8, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(214, 10, 13, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(215, 10, 14, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(222, 11, 9, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(223, 11, 3, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(224, 11, 4, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(225, 11, 11, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(226, 11, 7, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(227, 11, 12, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(228, 11, 8, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(229, 11, 13, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(230, 11, 14, 30, 50, 20, 1, '2026-04-04 03:28:42', '2026-04-04 03:28:42'),
(237, 1, 15, 30, 50, 20, 1, '2026-04-04 03:35:46', '2026-04-04 03:35:46'),
(238, 12, 27, 30, 50, 20, 1, '2026-04-04 09:04:55', '2026-04-04 09:04:55'),
(239, 12, 23, 30, 50, 20, 1, '2026-04-04 09:04:55', '2026-04-04 09:04:55'),
(240, 12, 24, 30, 50, 20, 1, '2026-04-04 09:04:55', '2026-04-04 09:04:55'),
(241, 12, 26, 30, 50, 20, 1, '2026-04-04 09:04:55', '2026-04-04 09:04:55'),
(242, 12, 25, 30, 50, 20, 1, '2026-04-04 09:04:55', '2026-04-04 09:04:55'),
(243, 12, 16, 30, 50, 20, 1, '2026-04-04 09:04:55', '2026-04-04 09:04:55'),
(244, 12, 22, 30, 50, 20, 1, '2026-04-04 09:04:55', '2026-04-04 09:04:55'),
(245, 12, 20, 30, 50, 20, 1, '2026-04-04 09:04:55', '2026-04-04 09:04:55'),
(246, 12, 19, 30, 50, 20, 1, '2026-04-04 09:04:55', '2026-04-04 09:04:55'),
(247, 12, 17, 30, 50, 20, 1, '2026-04-04 09:04:55', '2026-04-04 09:04:55'),
(248, 12, 21, 30, 50, 20, 1, '2026-04-04 09:04:55', '2026-04-04 09:04:55'),
(249, 12, 18, 30, 50, 20, 1, '2026-04-04 09:04:55', '2026-04-04 09:04:55'),
(253, 13, 31, 30, 50, 20, 1, '2026-04-04 09:05:29', '2026-04-04 09:05:29'),
(254, 13, 32, 30, 50, 20, 1, '2026-04-04 09:05:29', '2026-04-04 09:05:29'),
(255, 13, 37, 30, 50, 20, 1, '2026-04-04 09:05:29', '2026-04-04 09:05:29'),
(256, 13, 38, 30, 50, 20, 1, '2026-04-04 09:05:29', '2026-04-04 09:05:29'),
(257, 13, 33, 30, 50, 20, 1, '2026-04-04 09:05:29', '2026-04-04 09:05:29'),
(258, 13, 34, 30, 50, 20, 1, '2026-04-04 09:05:29', '2026-04-04 09:05:29'),
(259, 13, 35, 30, 50, 20, 1, '2026-04-04 09:05:29', '2026-04-04 09:05:29'),
(260, 13, 36, 30, 50, 20, 1, '2026-04-04 09:05:29', '2026-04-04 09:05:29');

-- --------------------------------------------------------

--
-- Table structure for table `tbldeadlines`
--

CREATE TABLE `tbldeadlines` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `quarter` tinyint(4) NOT NULL,
  `school_year` varchar(20) NOT NULL,
  `teacher_deadline` datetime NOT NULL,
  `adviser_deadline` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblgradelevel`
--

CREATE TABLE `tblgradelevel` (
  `id` int(11) NOT NULL,
  `grade_level_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblgradelevel`
--

INSERT INTO `tblgradelevel` (`id`, `grade_level_name`) VALUES
(1, 'Kindergarten'),
(2, 'Grade 1'),
(3, 'Grade 2'),
(4, 'Grade 3'),
(5, 'Grade 4'),
(6, 'Grade 5'),
(7, 'Grade 6'),
(8, 'Grade 7'),
(9, 'Grade 8'),
(10, 'Grade 9'),
(11, 'Grade 10'),
(12, 'Grade 11'),
(13, 'Grade 12');

-- --------------------------------------------------------

--
-- Table structure for table `tblprovince`
--

CREATE TABLE `tblprovince` (
  `id` int(11) NOT NULL,
  `province_name` varchar(100) NOT NULL,
  `region_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblprovince`
--

INSERT INTO `tblprovince` (`id`, `province_name`, `region_id`) VALUES
(1, 'Metro Manila', 1),
(2, 'Cavite', 2),
(3, 'Laguna', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tblregion`
--

CREATE TABLE `tblregion` (
  `id` int(11) NOT NULL,
  `region_name` varchar(100) NOT NULL,
  `country_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblregion`
--

INSERT INTO `tblregion` (`id`, `region_name`, `country_id`) VALUES
(1, 'National Capital Region (NCR)', 1),
(2, 'Calabarzon (IV-A)', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblrole`
--

CREATE TABLE `tblrole` (
  `id` int(11) NOT NULL,
  `role_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblrole`
--

INSERT INTO `tblrole` (`id`, `role_name`) VALUES
(1, 'Admin'),
(2, 'Teacher');

-- --------------------------------------------------------

--
-- Table structure for table `tblschedule`
--

CREATE TABLE `tblschedule` (
  `id` int(11) NOT NULL,
  `academic_year_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `day_of_week` varchar(20) NOT NULL,
  `time_start` time NOT NULL,
  `time_end` time NOT NULL,
  `room` varchar(100) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblsection`
--

CREATE TABLE `tblsection` (
  `id` int(11) NOT NULL,
  `grade_level_id` int(11) DEFAULT NULL,
  `section_name` varchar(100) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblsection`
--

INSERT INTO `tblsection` (`id`, `grade_level_id`, `section_name`, `is_active`, `created_at`, `updated_at`) VALUES
(15, 5, 'Ruby', 1, '2025-11-22 14:36:10', '2026-03-18 13:08:43'),
(16, 8, 'Sapphire', 1, '2025-11-22 14:36:10', '2026-03-18 13:08:35'),
(17, 8, 'Emerald', 1, '2025-11-22 14:36:10', '2026-03-18 13:08:47'),
(18, 5, 'Diamond', 1, '2025-11-22 14:36:10', '2026-03-18 18:59:55'),
(19, 1, 'Gold', 1, '2025-11-22 14:36:10', '2026-03-18 13:08:39'),
(20, 6, 'Silver', 1, '2025-11-22 14:36:10', '2026-03-18 13:08:51'),
(21, 2, 'Pearl', 1, '2025-11-22 14:36:10', '2026-03-18 13:06:28'),
(22, 11, 'Onyx', 1, '2025-11-22 14:36:10', '2026-03-12 14:30:00'),
(23, 6, 'Amethyst', 1, '2025-11-22 14:36:10', '2026-03-12 10:41:51'),
(24, 3, 'Topaz', 1, '2025-11-22 14:36:10', '2026-03-12 10:40:44');

-- --------------------------------------------------------

--
-- Table structure for table `tblsectionadviser`
--

CREATE TABLE `tblsectionadviser` (
  `id` int(11) NOT NULL,
  `academic_year_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblsectionadviser`
--

INSERT INTO `tblsectionadviser` (`id`, `academic_year_id`, `section_id`, `teacher_id`, `created_at`, `updated_at`) VALUES
(1, 1, 24, 5, '2026-03-18 14:12:28', '2026-03-18 14:12:28'),
(2, 1, 15, 3, '2026-03-18 18:26:45', '2026-03-27 15:13:19'),
(3, 1, 19, 11, '2026-03-25 15:58:00', '2026-03-27 15:53:00');

-- --------------------------------------------------------

--
-- Table structure for table `tblsectionstudent`
--

CREATE TABLE `tblsectionstudent` (
  `id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `academic_year_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblsectionstudent`
--

INSERT INTO `tblsectionstudent` (`id`, `section_id`, `student_id`, `academic_year_id`, `is_active`, `created_at`, `updated_at`) VALUES
(2, 15, 1, 1, 0, '2026-03-18 16:47:15', '2026-03-18 19:05:24'),
(3, 19, 7, 1, 1, '2026-03-18 17:47:07', '2026-03-18 17:47:07'),
(4, 19, 3, 1, 1, '2026-03-18 17:47:40', '2026-03-18 17:47:40'),
(5, 18, 2, 1, 1, '2026-03-18 17:59:33', '2026-03-18 17:59:33'),
(6, 18, 8, 1, 1, '2026-03-18 17:59:45', '2026-03-18 17:59:45'),
(7, 19, 10, 1, 1, '2026-03-18 18:18:51', '2026-03-18 18:18:51'),
(8, 15, 4, 1, 1, '2026-03-18 18:28:34', '2026-03-18 18:28:34'),
(9, 18, 1, 1, 1, '2026-03-18 19:05:24', '2026-03-18 19:05:24'),
(10, 23, 6, 1, 1, '2026-03-25 16:22:33', '2026-03-25 16:22:33');

-- --------------------------------------------------------

--
-- Table structure for table `tblstudents`
--

CREATE TABLE `tblstudents` (
  `id` int(11) NOT NULL,
  `lrn` varchar(12) DEFAULT NULL,
  `fname` varchar(100) DEFAULT NULL,
  `mname` varchar(100) DEFAULT NULL,
  `lname` varchar(100) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `citizenship` varchar(50) DEFAULT NULL,
  `grade_level_id` int(11) DEFAULT NULL,
  `fathers_name` varchar(100) DEFAULT NULL,
  `fathers_contact_num` varchar(20) DEFAULT NULL,
  `mothers_name` varchar(100) DEFAULT NULL,
  `mothers_contact_num` varchar(100) DEFAULT NULL,
  `guardian_name` varchar(100) DEFAULT NULL,
  `guardian_contact_num` varchar(20) DEFAULT NULL,
  `street_name` varchar(100) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `barangay_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `province_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblstudents`
--

INSERT INTO `tblstudents` (`id`, `lrn`, `fname`, `mname`, `lname`, `birthdate`, `gender`, `citizenship`, `grade_level_id`, `fathers_name`, `fathers_contact_num`, `mothers_name`, `mothers_contact_num`, `guardian_name`, `guardian_contact_num`, `street_name`, `postal_code`, `barangay_id`, `city_id`, `region_id`, `province_id`, `country_id`, `is_active`) VALUES
(1, '010000000001', 'Andre', 'Delos', 'Santo', '2001-01-15', 'Male', 'Filipino', 5, 'Pedro Santos', '0917-111-1111', 'Maria Santos', '84651', 'Maria Santos', '0917-111-1111', '123 Mabini St', '1000', 1, 1, 1, 1, 1, 1),
(2, '010000000002', 'Maria', 'Isabel', 'Reyes', '2011-03-22', 'Female', 'Filipino', 4, 'Jose Reyes', '0922-222-2222', 'Ana Reyes', '7461', 'Ana Reyes', '0922-222-2222', '456 Quezon Ave', '1100', 2, 2, 1, 1, 1, 1),
(3, '010000000003', 'Carlos', 'Dim', 'Garcia', '2009-07-08', 'Male', 'Filipino', 6, 'Ramon Garcia', '0933-333-3333', 'Clara Garcia', '09944', 'Clara Garcia', '0933-333-3333', '789 Rizal Blvd', '1200', 3, 3, 1, 1, 1, 1),
(4, '010000000004', 'Sophia', 'Lane', 'Mendoza', '2012-11-30', 'Female', 'Filipino', 3, 'Miguel Mendoza', '0944-444-4444', 'Elena Mendoza', '096230', 'Elena Mendoza', '0944-444-4444', '321 Luna St', '4114', 4, 4, 2, 2, 1, 1),
(5, '010000000005', 'Andrew', 'Mark', 'Torres', '2008-05-14', 'Male', 'Filipino', 7, 'Robert Torres', '0955-555-5555', 'Liza Torres', '098555', 'Liza Torres', '0955-555-5555', '654 Del Pilar', '4026', 5, 5, 2, 3, 1, 1),
(6, '010000000006', 'Angela', 'Rose', 'Cruz', '2013-08-20', 'Female', 'Filipino', 2, 'Danilo Cruz', '0966-666-6666', 'Fe Cruz', '096555', 'Fe Cruz', '0966-666-6666', '987 Bonifacio St', '1000', 1, 1, 1, 1, 1, 1),
(7, '010000000007', 'Mark', 'Paul', 'Lim', '2007-12-03', 'Male', 'Filipino', 8, 'Arthur Lim', '0977-777-7777', 'Grace Lim', '08444', 'Grace Lim', '0977-777-7777', '147 Taft Ave', '1100', 2, 2, 1, 1, 1, 1),
(8, '010000000008', 'Jusipin', 'Kay', 'Flores', '2014-02-28', 'Female', 'Filipino', 1, 'Ryan Flores', '0988-888-8888', 'Cathy Flores', '096666', 'Cathy Flores', '0988-888-8888', '258 Shaw Blvd', '1200', 3, 3, 1, 1, 1, 1),
(9, '010000000009', 'Bryan', 'James', 'Villanueva', '2006-09-11', 'Male', 'Filipino', 9, 'Raul Villanueva', '0999-999-9999', 'Nina Villanueva', '092222', 'Nina Villanueva', '0999-999-9999', '369 Aguinaldo Hwy', '4114', 4, 4, 2, 2, 1, 1),
(10, '010000000010', 'Trisha', 'May', 'Delos', '2015-06-17', 'Female', 'Filipino', 1, 'Leo Delos', '0912-121-2121', 'Mila Delos', '093333', 'Mila Delos', '0912-121-2121', '753 Bayan St', '4026', 5, 5, 2, 3, 1, 1),
(13, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblsubjects`
--

CREATE TABLE `tblsubjects` (
  `id` int(11) NOT NULL,
  `subject_code` varchar(20) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `subject_type` enum('CORE','APPLIED','SPECIALIZED','ELECTIVE') NOT NULL DEFAULT 'CORE',
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblsubjects`
--

INSERT INTO `tblsubjects` (`id`, `subject_code`, `subject_name`, `subject_type`, `description`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'LANG1', 'Language', 'CORE', 'Language learning area for Grade 1', 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(2, 'RLIT1', 'Reading and Literacy', 'CORE', 'Reading and Literacy learning area for Grade 1', 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(3, 'ENG', 'English', 'CORE', 'English learning area', 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(4, 'FIL', 'Filipino', 'CORE', 'Filipino learning area', 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(5, 'GMRC', 'Good Manners and Right Conduct', 'CORE', 'Good Manners and Right Conduct learning area', 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(6, 'MAKAB', 'Makabansa', 'CORE', 'Makabansa learning area', 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(7, 'MATH', 'Mathematics', 'CORE', 'Mathematics learning area', 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(8, 'SCI', 'Science', 'CORE', 'Science learning area', 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(9, 'AP', 'Araling Panlipunan', 'CORE', 'Araling Panlipunan learning area', 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(10, 'EPP', 'Edukasyong Pantahanan at Pangkabuhayan', 'CORE', 'EPP learning area for Grades 4 to 6', 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(11, 'MA', 'Music and Arts', 'CORE', 'Music and Arts learning area', 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(12, 'PEH', 'Physical Education and Health', 'CORE', 'Physical Education and Health learning area', 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(13, 'TLE', 'Technology and Livelihood Education', 'CORE', 'Technology and Livelihood Education learning area', 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(14, 'VE', 'Values Education', 'CORE', 'Values Education learning area', 1, '2026-04-04 03:28:41', '2026-04-04 03:28:41'),
(15, 'KINDER', 'Kindergarten', 'CORE', 'Kindergarten integrated learning area', 1, '2026-04-04 03:35:46', '2026-04-04 03:35:46'),
(16, 'G11-COMM', 'Effective Communication', 'CORE', NULL, 1, '2026-04-04 08:58:52', '2026-04-04 08:58:52'),
(17, 'G11-MATH', 'General Mathematics', 'CORE', NULL, 1, '2026-04-04 08:58:52', '2026-04-04 08:58:52'),
(18, 'G11-SCI', 'General Science', 'CORE', NULL, 1, '2026-04-04 08:58:52', '2026-04-04 08:58:52'),
(19, 'G11-LCS', 'Life and Career Skills', 'CORE', NULL, 1, '2026-04-04 08:58:52', '2026-04-04 08:58:52'),
(20, 'G11-KLP', 'Pag-aaral ng Kasaysayan at Lipunang Pilipino', 'CORE', NULL, 1, '2026-04-04 08:58:52', '2026-04-04 08:58:52'),
(21, 'G11-PHILO', 'Introduction to Philosophy', 'APPLIED', NULL, 1, '2026-04-04 09:02:02', '2026-04-04 09:02:02'),
(22, 'G11-FIL1', 'Filipino 1', 'APPLIED', NULL, 1, '2026-04-04 09:02:02', '2026-04-04 09:02:02'),
(23, 'G11-ARTS1', 'Arts 1', 'APPLIED', NULL, 1, '2026-04-04 09:02:02', '2026-04-04 09:02:02'),
(24, 'G11-ARTS2', 'Arts 2', 'APPLIED', NULL, 1, '2026-04-04 09:02:02', '2026-04-04 09:02:02'),
(25, 'G11-CARE-CHILD', 'Caregiving Child Care', 'SPECIALIZED', NULL, 1, '2026-04-04 09:02:19', '2026-04-04 09:02:19'),
(26, 'G11-CARE-ADULT', 'Caregiving Adult Care', 'SPECIALIZED', NULL, 1, '2026-04-04 09:02:19', '2026-04-04 09:02:19'),
(27, 'G11-AGRI', 'Agricultural Crops Production', 'SPECIALIZED', NULL, 1, '2026-04-04 09:02:19', '2026-04-04 09:02:19'),
(31, 'G12-BIO3', 'Biology 3', 'SPECIALIZED', NULL, 1, '2026-04-04 09:02:46', '2026-04-04 09:02:46'),
(32, 'G12-BIO4', 'Biology 4', 'SPECIALIZED', NULL, 1, '2026-04-04 09:02:46', '2026-04-04 09:02:46'),
(33, 'G12-CHEM3', 'Chemistry 3', 'SPECIALIZED', NULL, 1, '2026-04-04 09:02:46', '2026-04-04 09:02:46'),
(34, 'G12-CHEM4', 'Chemistry 4', 'SPECIALIZED', NULL, 1, '2026-04-04 09:02:46', '2026-04-04 09:02:46'),
(35, 'G12-PRECALC1', 'Pre Calculus 1', 'SPECIALIZED', NULL, 1, '2026-04-04 09:02:46', '2026-04-04 09:02:46'),
(36, 'G12-PRECALC2', 'Pre Calculus 2', 'SPECIALIZED', NULL, 1, '2026-04-04 09:02:46', '2026-04-04 09:02:46'),
(37, 'G12-BUS2', 'Business 2', 'SPECIALIZED', NULL, 1, '2026-04-04 09:02:46', '2026-04-04 09:02:46'),
(38, 'G12-BUS3', 'Business 3', 'SPECIALIZED', NULL, 1, '2026-04-04 09:02:46', '2026-04-04 09:02:46');

-- --------------------------------------------------------

--
-- Table structure for table `tblteacher`
--

CREATE TABLE `tblteacher` (
  `id` int(11) NOT NULL,
  `teacher_id` varchar(30) NOT NULL,
  `email` varchar(255) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `mname` varchar(100) DEFAULT '',
  `lname` varchar(100) NOT NULL,
  `date_hired` date NOT NULL,
  `sex` enum('Male','Female') NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblteacher`
--

INSERT INTO `tblteacher` (`id`, `teacher_id`, `email`, `fname`, `mname`, `lname`, `date_hired`, `sex`, `contact_no`, `is_active`) VALUES
(1, 'T00001', 'maria.clara@example.com', 'Maria', '', 'Clara', '2025-11-27', 'Female', '09123456789', 1),
(2, 'T00002', 'jose.rizal@example.com', 'Jose', '', 'Rizal', '2025-11-27', 'Male', '09223456789', 1),
(3, 'T00003', 'andres.boni@example.com', 'Andres', '', 'Bonifacio', '2025-11-27', 'Male', '09333456789', 1),
(4, 'T00004', 'melchora.aquino@example.com', 'Melchora', '', 'Aquino', '2025-11-27', 'Female', '09443456789', 1),
(5, 'T00005', 'emilio.aguinaldo@example.com', 'Emilio', '', 'Aguinaldo', '2025-11-27', 'Male', '09553456789', 1),
(6, 'T00006', 'gabriela.silang@example.com', 'Gabriela', '', 'Silang', '2025-11-27', 'Female', '09663456789', 1),
(7, 'T00007', 'apol.mabini@example.com', 'Apolinario', '', 'Mabini', '2025-11-27', 'Male', '09773456789', 1),
(8, 'T00008', 'lapu.datu@example.com', 'Lapu-Lapu', '', 'Datu', '2025-11-27', 'Male', '09883456789', 1),
(9, 'T00009', 'katherine.li@example.com', 'Katherine', '', 'Li', '2025-11-27', 'Female', '09993456789', 1),
(10, 'T00010', 'riz.torres@example.com', 'Rizalino', '', 'Torres', '2025-11-27', 'Male', '09004567890', 1),
(11, 'T00023', 'hechanova919@gmail.com', 'Justin ', '', 'Hechanova', '2025-11-27', 'Male', '9771995088', 1),
(12, 'T00044', 'sanjose2020@gmail.com', 'Luke', '', 'San Jose', '2025-11-27', 'Male', '09771885768', 1),
(13, 'T00099', 'CristineGonzales123@gmail.com', 'Cristines', '', 'Gonzales', '2025-11-27', 'Female', '9886758464324', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblteacher_old`
--

CREATE TABLE `tblteacher_old` (
  `id` int(11) NOT NULL,
  `teacher_id` varchar(30) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `date_of_birth` date NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `civil_status` enum('Single','Married','Widowed','Divorced') NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `street_name` varchar(255) NOT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `barangay_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `province_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblteacher_old`
--

INSERT INTO `tblteacher_old` (`id`, `teacher_id`, `fname`, `lname`, `date_of_birth`, `gender`, `civil_status`, `contact_number`, `email`, `street_name`, `postal_code`, `barangay_id`, `city_id`, `region_id`, `province_id`, `country_id`, `is_active`) VALUES
(4, 'T00001', 'Maria', 'Clara', '1985-03-12', 'Female', 'Single', '09123456789', 'maria.clara@example.com', '123 Rizal St', '4000', NULL, NULL, NULL, NULL, NULL, 1),
(5, 'T00002', 'Jose', 'Rizal', '1980-06-19', 'Male', 'Married', '09223456789', 'jose.rizal@example.com', '456 Bonifacio St', '4001', NULL, NULL, NULL, NULL, NULL, 1),
(6, 'T00003', 'Andres', 'Bonifacio', '1979-11-30', 'Male', 'Married', '09333456789', 'andres.boni@example.com', '789 Del Pilar St', '4002', NULL, NULL, NULL, NULL, NULL, 1),
(7, 'T00004', 'Melchora', 'Aquino', '1990-01-06', 'Female', 'Widowed', '09443456789', 'melchora.aquino@example.com', '111 Tandang Sora St', '4003', NULL, NULL, NULL, NULL, NULL, 1),
(8, 'T00005', 'Emilio', 'Aguinaldo', '1987-10-14', 'Male', 'Married', '09553456789', 'emilio.aguinaldo@example.com', '30 Narra st', '', 1, 1, 1, 1, 1, 1),
(9, 'T00006', 'Gabriela', 'Silang', '1992-03-19', 'Female', 'Single', '09663456789', 'gabriela.silang@example.com', '333 Ilocos St', '4005', NULL, NULL, NULL, NULL, NULL, 1),
(10, 'T00007', 'Apolinario', 'Mabini', '1987-10-08', 'Male', 'Single', '09773456789', 'apol.mabini@example.com', 'Matrix', '', 3, 3, 1, 1, 1, 1),
(11, 'T00008', 'Lapu-Lapu', 'Datu', '1965-01-01', 'Male', 'Married', '09883456789', 'lapu.datu@example.com', '555 Mactan Ave', '4007', NULL, NULL, NULL, NULL, NULL, 1),
(12, 'T00009', 'Katherine', 'Li', '1988-05-15', 'Female', 'Single', '09993456789', 'katherine.li@example.com', '666 Chinatown St', '4008', NULL, NULL, NULL, NULL, NULL, 1),
(13, 'T00010', 'Rizalino', 'Torres', '1975-10-25', 'Male', 'Divorced', '09004567890', 'riz.torres@example.com', '777 Taft Ave', '4009', NULL, NULL, NULL, NULL, NULL, 1),
(14, '1123129837891275', 'Anndre', 'wawawa', '2002-02-20', 'Male', 'Married', '0977123812318', 'lovelove25@gmail.com', 'Waka waka', '23232', 4, 4, 2, 2, 1, 0),
(15, 'T00023', 'Justin ', 'Hechanova', '2005-02-20', 'Male', 'Single', '9771995088', 'hechanova919@gmail.com', 'Quezon city', '1400', 1, 1, 1, 1, 1, 1),
(16, 'T00044', 'Luke', 'San Jose', '2006-02-03', 'Male', 'Single', '09771885768', 'sanjose2020@gmail.com', 'Lot 12 Blk12 Phase 7 Quezon City', '1399', 3, 3, 1, 1, 1, 1),
(17, 'T00099', 'Cristine', 'Gonzales', '2003-03-20', 'Female', 'Divorced', '9886758464324', 'CristineGonzales123@gmail.com', 'Baguio City', '1600', 4, 4, 2, 2, 1, 1),
(18, 't00014', 'Luke', 'san jose', '2025-11-05', 'Male', 'Married', '4978598579568', 'lukenazaren@gmail.com', 'ssdgsd', 'adfgadf', 4, 4, 2, 2, 1, 0),
(19, 'TCH-2025009', 'Luke', 'san jose', '2025-11-27', 'Male', 'Married', '09123456789', 'lukenazaren@gmail.com', 'ssdgsd', 'adfgadf', 4, 4, 2, 2, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblteacher_submissions`
--

CREATE TABLE `tblteacher_submissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `teacher_id` bigint(20) UNSIGNED NOT NULL,
  `section_id` bigint(20) UNSIGNED NOT NULL,
  `subject_id` bigint(20) UNSIGNED NOT NULL,
  `quarter` tinyint(4) NOT NULL,
  `school_year` varchar(20) NOT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `must_change_password` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`id`, `username`, `password_hash`, `role_id`, `reference_id`, `status`, `created_at`, `updated_at`, `must_change_password`) VALUES
(4, 'admin', '$2y$10$nw7Ah4oao/TjpSxaV6o8UO/EfPT2r3k/gsIFw2RxMWSgOUXaFCDc.', 1, NULL, 'Active', '2025-11-24 16:37:53', '2025-11-24 16:54:25', 0),
(6, 'bonifaciot00003', '$2y$10$xoWBnl.LW1OgIc78ELoDyuRSbiaU6Ju.F2xf6m9VJ4BWFsDhYMJ9u', 2, 6, 'Active', '2025-11-24 17:52:13', '2025-11-26 05:50:01', 0),
(7, 'aquinot00004', '$2y$10$n24MLonVmdMu2aH3f9pTAeV3avVFSbKPyRGlJXi2Yg7pK4MnlK20m', 2, 7, 'Active', '2025-11-26 05:50:30', '2025-11-27 14:58:36', 0),
(8, 'aguinaldot00005', '$2y$10$NFKWDtXKpGeseCOTd2iAZe7I9wqbO81LI58cH1uo/w8lH4LVNEEaW', 2, 5, 'Active', '2025-11-28 16:52:22', '2025-11-28 16:53:48', 0),
(9, 'gonzalest00099', '$2y$10$Jjzw06koQ1b3xKTemgrXlOFCBtORrf2yaQAlBzGPKptps2GzFhnmy', 2, 13, 'Active', '2025-11-28 17:15:39', '2025-11-28 17:15:39', 1),
(10, 'Lukas', 'dodong', 1, NULL, 'Active', '2026-01-12 03:18:13', '2026-01-12 03:18:13', 0);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vwstudentinfo`
-- (See below for the actual view)
--
CREATE TABLE `vwstudentinfo` (
`id` int(11)
,`lrn` varchar(12)
,`fname` varchar(100)
,`mname` varchar(100)
,`lname` varchar(100)
,`birthdate` date
,`gender` varchar(10)
,`citizenship` varchar(50)
,`grade_level_id` int(11)
,`grade_level_name` varchar(50)
,`fathers_name` varchar(100)
,`fathers_contact_num` varchar(20)
,`mothers_name` varchar(100)
,`mothers_contact_num` varchar(100)
,`guardian_name` varchar(100)
,`guardian_contact_num` varchar(20)
,`street_name` varchar(100)
,`postal_code` varchar(20)
,`barangay_id` int(11)
,`barangay_name` varchar(100)
,`city_id` int(11)
,`city_name` varchar(100)
,`province_id` int(11)
,`province_name` varchar(100)
,`region_id` int(11)
,`region_name` varchar(100)
,`country_id` int(11)
,`country_name` varchar(100)
,`is_active` tinyint(1)
,`age` bigint(21)
,`full_address` text
);

-- --------------------------------------------------------

--
-- Structure for view `vwstudentinfo`
--
DROP TABLE IF EXISTS `vwstudentinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vwstudentinfo`  AS SELECT `s`.`id` AS `id`, `s`.`lrn` AS `lrn`, `s`.`fname` AS `fname`, `s`.`mname` AS `mname`, `s`.`lname` AS `lname`, `s`.`birthdate` AS `birthdate`, `s`.`gender` AS `gender`, `s`.`citizenship` AS `citizenship`, `s`.`grade_level_id` AS `grade_level_id`, `gl`.`grade_level_name` AS `grade_level_name`, `s`.`fathers_name` AS `fathers_name`, `s`.`fathers_contact_num` AS `fathers_contact_num`, `s`.`mothers_name` AS `mothers_name`, `s`.`mothers_contact_num` AS `mothers_contact_num`, `s`.`guardian_name` AS `guardian_name`, `s`.`guardian_contact_num` AS `guardian_contact_num`, `s`.`street_name` AS `street_name`, `s`.`postal_code` AS `postal_code`, `s`.`barangay_id` AS `barangay_id`, `b`.`barangay_name` AS `barangay_name`, `s`.`city_id` AS `city_id`, `c`.`city_name` AS `city_name`, `s`.`province_id` AS `province_id`, `p`.`province_name` AS `province_name`, `s`.`region_id` AS `region_id`, `r`.`region_name` AS `region_name`, `s`.`country_id` AS `country_id`, `co`.`country_name` AS `country_name`, `s`.`is_active` AS `is_active`, timestampdiff(YEAR,`s`.`birthdate`,curdate()) AS `age`, concat_ws(', ',`s`.`street_name`,`b`.`barangay_name`,`c`.`city_name`,`p`.`province_name`,`r`.`region_name`,`co`.`country_name`) AS `full_address` FROM ((((((`tblstudents` `s` join `tblgradelevel` `gl` on(`gl`.`id` = `s`.`grade_level_id`)) join `tblbarangay` `b` on(`b`.`id` = `s`.`barangay_id`)) join `tblcity` `c` on(`c`.`id` = `s`.`city_id`)) join `tblprovince` `p` on(`p`.`id` = `s`.`province_id`)) join `tblregion` `r` on(`r`.`id` = `s`.`region_id`)) join `tblcountry` `co` on(`co`.`id` = `s`.`country_id`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `system_notifications`
--
ALTER TABLE `system_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblacademicyear`
--
ALTER TABLE `tblacademicyear`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `year_label` (`year_label`);

--
-- Indexes for table `tbladviser_submissions`
--
ALTER TABLE `tbladviser_submissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbarangay`
--
ALTER TABLE `tblbarangay`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_barangay_city` (`city_id`);

--
-- Indexes for table `tblcity`
--
ALTER TABLE `tblcity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_city_province` (`province_id`);

--
-- Indexes for table `tblcountry`
--
ALTER TABLE `tblcountry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcurriculum_grade`
--
ALTER TABLE `tblcurriculum_grade`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_grade_subject` (`grade_level_id`,`subject_id`),
  ADD KEY `idx_curriculum_grade_level` (`grade_level_id`),
  ADD KEY `idx_curriculum_subject` (`subject_id`);

--
-- Indexes for table `tbldeadlines`
--
ALTER TABLE `tbldeadlines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblgradelevel`
--
ALTER TABLE `tblgradelevel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblprovince`
--
ALTER TABLE `tblprovince`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_province_region` (`region_id`);

--
-- Indexes for table `tblregion`
--
ALTER TABLE `tblregion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_region_country` (`country_id`);

--
-- Indexes for table `tblrole`
--
ALTER TABLE `tblrole`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `role_name` (`role_name`);

--
-- Indexes for table `tblschedule`
--
ALTER TABLE `tblschedule`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_schedule_academic_year` (`academic_year_id`),
  ADD KEY `fk_schedule_section` (`section_id`),
  ADD KEY `fk_schedule_subject` (`subject_id`),
  ADD KEY `fk_schedule_teacher` (`teacher_id`);

--
-- Indexes for table `tblsection`
--
ALTER TABLE `tblsection`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_tblsection_grade_level` (`grade_level_id`);

--
-- Indexes for table `tblsectionadviser`
--
ALTER TABLE `tblsectionadviser`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_section_adviser` (`academic_year_id`,`section_id`),
  ADD KEY `fk_sectionadviser_section` (`section_id`),
  ADD KEY `fk_sectionadviser_teacher` (`teacher_id`),
  ADD KEY `fk_sectionadviser_academic_year` (`academic_year_id`);

--
-- Indexes for table `tblsectionstudent`
--
ALTER TABLE `tblsectionstudent`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_section_student_year` (`section_id`,`student_id`,`academic_year_id`),
  ADD KEY `fk_sectionstudent_student` (`student_id`),
  ADD KEY `fk_sectionstudent_section` (`section_id`),
  ADD KEY `fk_sectionstudent_academic_year` (`academic_year_id`);

--
-- Indexes for table `tblstudents`
--
ALTER TABLE `tblstudents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `lrn` (`lrn`),
  ADD KEY `fk_name_grade` (`grade_level_id`),
  ADD KEY `fk_name_barangay` (`barangay_id`),
  ADD KEY `fk_name_city` (`city_id`),
  ADD KEY `fk_name_region` (`region_id`),
  ADD KEY `fk_name_province` (`province_id`),
  ADD KEY `fk_name_country` (`country_id`);

--
-- Indexes for table `tblsubjects`
--
ALTER TABLE `tblsubjects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `subject_code` (`subject_code`);

--
-- Indexes for table `tblteacher`
--
ALTER TABLE `tblteacher`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `tblteacher_old`
--
ALTER TABLE `tblteacher_old`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_teacher_bar` (`barangay_id`),
  ADD KEY `fk_teacher_city` (`city_id`),
  ADD KEY `fk_teacher_prov` (`province_id`),
  ADD KEY `fk_teacher_reg` (`region_id`),
  ADD KEY `fk_teacher_cnt` (`country_id`);

--
-- Indexes for table `tblteacher_submissions`
--
ALTER TABLE `tblteacher_submissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `idx_reference` (`reference_id`),
  ADD KEY `idx_role` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `system_notifications`
--
ALTER TABLE `system_notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblacademicyear`
--
ALTER TABLE `tblacademicyear`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbladviser_submissions`
--
ALTER TABLE `tbladviser_submissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblcurriculum_grade`
--
ALTER TABLE `tblcurriculum_grade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=268;

--
-- AUTO_INCREMENT for table `tbldeadlines`
--
ALTER TABLE `tbldeadlines`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblrole`
--
ALTER TABLE `tblrole`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblschedule`
--
ALTER TABLE `tblschedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tblsection`
--
ALTER TABLE `tblsection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `tblsectionadviser`
--
ALTER TABLE `tblsectionadviser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblsectionstudent`
--
ALTER TABLE `tblsectionstudent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tblstudents`
--
ALTER TABLE `tblstudents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tblsubjects`
--
ALTER TABLE `tblsubjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tblteacher`
--
ALTER TABLE `tblteacher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tblteacher_old`
--
ALTER TABLE `tblteacher_old`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tblteacher_submissions`
--
ALTER TABLE `tblteacher_submissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblbarangay`
--
ALTER TABLE `tblbarangay`
  ADD CONSTRAINT `fk_barangay_city` FOREIGN KEY (`city_id`) REFERENCES `tblcity` (`id`);

--
-- Constraints for table `tblcity`
--
ALTER TABLE `tblcity`
  ADD CONSTRAINT `fk_city_province` FOREIGN KEY (`province_id`) REFERENCES `tblprovince` (`id`);

--
-- Constraints for table `tblcurriculum_grade`
--
ALTER TABLE `tblcurriculum_grade`
  ADD CONSTRAINT `fk_curriculum_grade_level` FOREIGN KEY (`grade_level_id`) REFERENCES `tblgradelevel` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_curriculum_subject` FOREIGN KEY (`subject_id`) REFERENCES `tblsubjects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tblprovince`
--
ALTER TABLE `tblprovince`
  ADD CONSTRAINT `fk_province_region` FOREIGN KEY (`region_id`) REFERENCES `tblregion` (`id`);

--
-- Constraints for table `tblregion`
--
ALTER TABLE `tblregion`
  ADD CONSTRAINT `fk_region_country` FOREIGN KEY (`country_id`) REFERENCES `tblcountry` (`id`);

--
-- Constraints for table `tblschedule`
--
ALTER TABLE `tblschedule`
  ADD CONSTRAINT `fk_schedule_academic_year` FOREIGN KEY (`academic_year_id`) REFERENCES `tblacademicyear` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_schedule_section` FOREIGN KEY (`section_id`) REFERENCES `tblsection` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_schedule_subject` FOREIGN KEY (`subject_id`) REFERENCES `tblsubjects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_schedule_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `tblteacher` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tblsection`
--
ALTER TABLE `tblsection`
  ADD CONSTRAINT `fk_tblsection_grade_level` FOREIGN KEY (`grade_level_id`) REFERENCES `tblgradelevel` (`id`);

--
-- Constraints for table `tblsectionadviser`
--
ALTER TABLE `tblsectionadviser`
  ADD CONSTRAINT `fk_sectionadviser_academic_year` FOREIGN KEY (`academic_year_id`) REFERENCES `tblacademicyear` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_sectionadviser_section` FOREIGN KEY (`section_id`) REFERENCES `tblsection` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_sectionadviser_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `tblteacher` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tblsectionstudent`
--
ALTER TABLE `tblsectionstudent`
  ADD CONSTRAINT `fk_sectionstudent_academic_year` FOREIGN KEY (`academic_year_id`) REFERENCES `tblacademicyear` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_sectionstudent_section` FOREIGN KEY (`section_id`) REFERENCES `tblsection` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_sectionstudent_student` FOREIGN KEY (`student_id`) REFERENCES `tblstudents` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tblstudents`
--
ALTER TABLE `tblstudents`
  ADD CONSTRAINT `fk_name_barangay` FOREIGN KEY (`barangay_id`) REFERENCES `tblbarangay` (`id`),
  ADD CONSTRAINT `fk_name_city` FOREIGN KEY (`city_id`) REFERENCES `tblcity` (`id`),
  ADD CONSTRAINT `fk_name_country` FOREIGN KEY (`country_id`) REFERENCES `tblcountry` (`id`),
  ADD CONSTRAINT `fk_name_grade` FOREIGN KEY (`grade_level_id`) REFERENCES `tblgradelevel` (`id`),
  ADD CONSTRAINT `fk_name_province` FOREIGN KEY (`province_id`) REFERENCES `tblprovince` (`id`),
  ADD CONSTRAINT `fk_name_region` FOREIGN KEY (`region_id`) REFERENCES `tblregion` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
