<?php
require_once __DIR__ . '/api/shared/db_connect.php';

$sectionId = isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0;

if ($sectionId <= 0) {
    die('Invalid section.');
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Manage Schedule</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        @media (max-width: 767.98px) {
            #scheduleTable thead { display: none; }

            #scheduleTable tbody tr {
                display: block;
                border: 1px solid #dee2e6;
                margin-bottom: .75rem;
                border-radius: .4rem;
                padding: .5rem;
            }

            #scheduleTable tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                border: none !important;
                padding: .35rem .5rem;
            }

            #scheduleTable tbody td::before {
                content: attr(data-label);
                font-weight: 600;
                margin-right: .5rem;
                white-space: nowrap;
            }

            #scheduleTable tbody td:last-child {
                flex-direction: column;
                gap: .25rem;
            }

            #scheduleTable tbody td:last-child .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-7">
                        <h3 class="mb-0"><i class="bi bi-calendar-check"></i> Manage Section Schedule</h3>
                    </div>
                    <div class="col-sm-5">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="schedule.php">Scheduling</a></li>
                            <li class="breadcrumb-item active">Manage</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-7 d-flex">
                    <div class="card mb-4 w-100">
                        <div class="card-header">
                            <h3 class="card-title mb-0">Section Information</h3>
                        </div>
                        <div class="card-body">
                            <div class="row g-3" id="sectionInfoWrap">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Grade Level</label>
                                    <div id="infoGradeLevel">-</div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Section Name</label>
                                    <div id="infoSectionName">-</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-5 d-flex">
                    <div class="card mb-4 w-100">
                        <div class="card-header">
                            <h3 class="card-title mb-0">Academic Setup</h3>
                        </div>
                        <div class="card-body d-flex align-items-center">
                            <div class="d-none">
                                <select id="academicYearId"></select>
                            </div>

                            <div class="row g-3 w-100">
                                <div class="col-12">
                                    <label class="form-label">Section Adviser</label>
                                    <div class="input-group">
                                        <select class="form-select" id="adviserTeacherId"></select>
                                        <button class="btn btn-success" type="button" onclick="saveAdviser()">
                                            <i class="bi bi-save"></i> Save Adviser
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="card mb-4">
                <div class="card-header d-flex align-items-center flex-wrap gap-2">
                    <h3 class="card-title mb-0">Schedule Entries</h3>
                    <button class="btn btn-success btn-sm ms-auto" type="button" onclick="openScheduleForm()">
                        <i class="bi bi-plus-circle me-1"></i> New Schedule
                    </button>
                </div>
                <div class="card-body">
                    <div class="table-responsive d-none d-md-block">
                        <table id="scheduleTable" class="table table-bordered table-hover align-middle text-center mb-0">
                            <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Subject</th>
                                <th>Teacher</th>
                                <th>Day</th>
                                <th>Time</th>
                                <th>Room</th>
                                <th>Status</th>
                                <th style="width:160px;">Actions</th>
                            </tr>
                            </thead>
                            <tbody id="scheduleTableBody"></tbody>
                        </table>
                    </div>
                    <div class="d-block d-md-none" id="scheduleCardView"></div>
                </div>
            </div>
        </div>
    </main>

    <?php require_once("includes/footer.php"); ?>
</div>

<div class="modal fade" id="scheduleFormModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="false">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <form id="scheduleForm">
                <div class="modal-header">
                    <h5 class="modal-title" id="scheduleFormTitle">Add Schedule</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="scheduleId">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Subject <span class="text-danger">*</span></label>
                            <select class="form-select" id="subjectId" required></select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Teacher <span class="text-danger">*</span></label>
                            <select class="form-select" id="teacherId" required></select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Day <span class="text-danger">*</span></label>
                            <select class="form-select" id="dayOfWeek" required onchange="reloadTeachers()">
                                <option value="">Select Day</option>
                                <option>Monday</option>
                                <option>Tuesday</option>
                                <option>Wednesday</option>
                                <option>Thursday</option>
                                <option>Friday</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Start Time <span class="text-danger">*</span></label>
                            <input type="time" class="form-control" id="timeStart" required onchange="reloadTeachers()">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">End Time <span class="text-danger">*</span></label>
                            <input type="time" class="form-control" id="timeEnd" required onchange="reloadTeachers()">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Room</label>
                            <input type="text" class="form-control" id="room">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Status</label>
                            <select class="form-select" id="isActive">
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Save Schedule</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script>
const SECTION_ID = <?php echo (int)$sectionId; ?>;
let currentSectionInfo = null;

function esc(str) {
    return (str ?? '').toString()
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function loadSectionInfo() {
    fetch(`api/schedule/fetch_section.php?id=${SECTION_ID}`)
        .then(r => r.json())
        .then(async data => {
            currentSectionInfo = data.data || data;
            document.getElementById('infoGradeLevel').textContent = currentSectionInfo.grade_level_name || '-';
            document.getElementById('infoSectionName').textContent = currentSectionInfo.section_name || '-';

            await loadAllTeachers();
            await loadAcademicYears(currentSectionInfo.default_academic_year_id || '');

            loadAdviser();
            loadSchedules();
        });
}

function loadAllTeachers() {
    return fetch('api/schedule/teachers.php')
        .then(r => r.json())
        .then(data => {
            const list = data.teachers || [];
            const options = ['<option value="">Select Teacher</option>']
                .concat(list.map(t => `<option value="${t.id}">${esc(t.full_name)}</option>`))
                .join('');
            document.getElementById('adviserTeacherId').innerHTML = options;
        });
}

function loadSubjects(selectedId = '', excludeScheduleId = '') {
    const academicYearId = document.getElementById('academicYearId').value;
    if (!academicYearId) return Promise.resolve();

    let url = `api/schedule/subjects.php?section_id=${SECTION_ID}&academic_year_id=${academicYearId}`;
    if (excludeScheduleId) url += `&exclude_schedule_id=${excludeScheduleId}`;

    return fetch(url)
        .then(r => r.json())
        .then(data => {
            const list = data.subjects || [];
            const options = ['<option value="">Select Subject</option>']
                .concat(list.map(s => `<option value="${s.id}" ${String(selectedId) === String(s.id) ? 'selected' : ''}>${esc(s.subject_name)} (${esc(s.subject_code)})</option>`))
                .join('');
            document.getElementById('subjectId').innerHTML = options;
        });
}

function loadTeachers(selectedId = '', excludeScheduleId = '') {
    const academicYearId = document.getElementById('academicYearId').value;
    const dayOfWeek = document.getElementById('dayOfWeek').value;
    const timeStart = document.getElementById('timeStart').value;
    const timeEnd = document.getElementById('timeEnd').value;

    if (!academicYearId) return Promise.resolve();

    let url = `api/schedule/teachers.php?section_id=${SECTION_ID}&academic_year_id=${academicYearId}`;
    if (excludeScheduleId) url += `&exclude_schedule_id=${excludeScheduleId}`;

    if (dayOfWeek && timeStart && timeEnd) {
        url += `&day_of_week=${encodeURIComponent(dayOfWeek)}&time_start=${encodeURIComponent(timeStart)}&time_end=${encodeURIComponent(timeEnd)}`;
    }

    return fetch(url)
        .then(r => r.json())
        .then(data => {
            const list = data.teachers || [];
            const options = ['<option value="">Select Teacher</option>']
                .concat(list.map(t => `<option value="${t.id}" ${String(selectedId) === String(t.id) ? 'selected' : ''}>${esc(t.full_name)}</option>`))
                .join('');
            document.getElementById('teacherId').innerHTML = options;
        });
}

function reloadTeachers() {
    const scheduleId = document.getElementById('scheduleId').value;
    const currentTeacherId = document.getElementById('teacherId').value;
    loadTeachers(currentTeacherId, scheduleId);
}

function loadAcademicYears(selectedId = '') {
    return fetch('api/schedule/academic_years.php')
        .then(r => r.json())
        .then(data => {
            const list = data.academic_years || [];
            document.getElementById('academicYearId').innerHTML = list.map(y =>
                `<option value="${y.id}" ${String(selectedId) === String(y.id) ? 'selected' : ''}>
                    ${esc(y.year_label)}${y.is_active == 1 ? ' (Active)' : ''}
                </option>`
            ).join('');
        });
}

function loadAdviser() {
    const academicYearId = document.getElementById('academicYearId').value;
    if (!academicYearId) return;

    fetch(`api/schedule/adviser_get.php?section_id=${SECTION_ID}&academic_year_id=${academicYearId}`)
        .then(r => r.json())
        .then(data => {
            document.getElementById('adviserTeacherId').value = data.teacher_id || '';
        });
}

function saveAdviser() {
    const academicYearId = document.getElementById('academicYearId').value;
    const teacherId = document.getElementById('adviserTeacherId').value;

    fetch('api/schedule/adviser_save.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            section_id: SECTION_ID,
            academic_year_id: academicYearId,
            teacher_id: teacherId
        })
    })
    .then(r => r.json())
    .then(res => {
        if (res.success) {
            alert('Adviser saved successfully.');
        } else {
            alert(res.error || 'Failed to save adviser.');
        }
    });
}

function loadSchedules() {
    const academicYearId = document.getElementById('academicYearId').value;
    if (!academicYearId) return;

    fetch(`api/schedule/read.php?section_id=${SECTION_ID}&academic_year_id=${academicYearId}`)
        .then(r => r.json())
        .then(data => {
            const list = data.schedules || [];

            document.getElementById('scheduleTableBody').innerHTML = list.map((s, i) => `
                <tr>
                    <td data-label="#">${i + 1}</td>
                    <td data-label="Subject">${esc(s.subject_name)}</td>
                    <td data-label="Teacher">${esc(s.teacher_name)}</td>
                    <td data-label="Day">${esc(s.day_of_week)}</td>
                    <td data-label="Time">${esc(s.time_start_12)} - ${esc(s.time_end_12)}</td>
                    <td data-label="Room">${esc(s.room || '-')}</td>
                    <td data-label="Status">
                        <span class="badge bg-${s.is_active == 1 ? 'success' : 'secondary'}">
                            ${s.is_active == 1 ? 'Active' : 'Inactive'}
                        </span>
                    </td>
                    <td data-label="Actions">
                        <button class="btn btn-sm btn-warning me-1" onclick="editSchedule(${s.id})">
                            <i class="bi bi-pencil-square"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteSchedule(${s.id})">
                            <i class="bi bi-trash"></i>
                        </button>
                    </td>
                </tr>
            `).join('');

            document.getElementById('scheduleCardView').innerHTML = list.map((s, i) => `
                <div class="card mb-3 shadow-sm">
                    <div class="card-header bg-light d-flex justify-content-between">
                        <span class="fw-bold">${i + 1}. ${esc(s.subject_name)}</span>
                        <span class="badge bg-${s.is_active == 1 ? 'success' : 'secondary'}">
                            ${s.is_active == 1 ? 'Active' : 'Inactive'}
                        </span>
                    </div>
                    <div class="card-body py-2 small">
                        <div class="row mb-1"><div class="col-4 text-muted">Teacher</div><div class="col-8">${esc(s.teacher_name)}</div></div>
                        <div class="row mb-1"><div class="col-4 text-muted">Day</div><div class="col-8">${esc(s.day_of_week)}</div></div>
                        <div class="row mb-1"><div class="col-4 text-muted">Time</div><div class="col-8">${esc(s.time_start_12)} - ${esc(s.time_end_12)}</div></div>
                        <div class="row mb-1"><div class="col-4 text-muted">Room</div><div class="col-8">${esc(s.room || '-')}</div></div>
                    </div>
                    <div class="card-footer d-grid gap-2">
                        <button class="btn btn-sm btn-warning" onclick="editSchedule(${s.id})"><i class="bi bi-pencil-square"></i> Edit</button>
                        <button class="btn btn-sm btn-danger" onclick="deleteSchedule(${s.id})"><i class="bi bi-trash"></i> Delete</button>
                    </div>
                </div>
            `).join('');
        });
}

function openScheduleForm() {
    document.getElementById('scheduleForm').reset();
    document.getElementById('scheduleId').value = '';
    document.getElementById('scheduleFormTitle').textContent = 'Add Schedule';
    document.getElementById('isActive').value = '1';

    Promise.all([
        loadSubjects(),
        loadTeachers()
    ]).then(() => {
        new bootstrap.Modal(document.getElementById('scheduleFormModal')).show();
    });
}

function editSchedule(id) {
    fetch(`api/schedule/fetch.php?id=${id}`)
        .then(r => r.json())
        .then(data => {
            Promise.all([
                loadSubjects(data.subject_id, id),
                loadTeachers(data.teacher_id, id)
            ]).then(() => {
                document.getElementById('scheduleId').value = data.id;
                document.getElementById('subjectId').value = data.subject_id;
                document.getElementById('teacherId').value = data.teacher_id;
                document.getElementById('dayOfWeek').value = data.day_of_week;
                document.getElementById('timeStart').value = data.time_start;
                document.getElementById('timeEnd').value = data.time_end;
                document.getElementById('room').value = data.room || '';
                document.getElementById('isActive').value = data.is_active;
                document.getElementById('scheduleFormTitle').textContent = 'Edit Schedule';
                new bootstrap.Modal(document.getElementById('scheduleFormModal')).show();
            });
        });
}

function deleteSchedule(id) {
    if (!confirm('Delete this schedule?')) return;

    fetch('api/schedule/delete.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({id: id})
    })
    .then(r => r.json())
    .then(res => {
        if (res.success) {
            loadSchedules();
        } else {
            alert(res.error || 'Delete failed.');
        }
    });
}

document.getElementById('scheduleForm').addEventListener('submit', e => {
    e.preventDefault();

    fetch('api/schedule/save.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            id: document.getElementById('scheduleId').value || undefined,
            academic_year_id: document.getElementById('academicYearId').value,
            section_id: SECTION_ID,
            subject_id: document.getElementById('subjectId').value,
            teacher_id: document.getElementById('teacherId').value,
            day_of_week: document.getElementById('dayOfWeek').value,
            time_start: document.getElementById('timeStart').value,
            time_end: document.getElementById('timeEnd').value,
            room: document.getElementById('room').value.trim(),
            is_active: document.getElementById('isActive').value
        })
    })
    .then(r => r.json())
    .then(res => {
        if (res.success) {
            bootstrap.Modal.getInstance(document.getElementById('scheduleFormModal')).hide();
            loadSchedules();
        } else {
            alert(res.error || 'Save failed.');
        }
    });
});

document.getElementById('academicYearId').addEventListener('change', () => {
    loadAdviser();
    loadSchedules();
});

loadSectionInfo();
</script>
</body>
</html>