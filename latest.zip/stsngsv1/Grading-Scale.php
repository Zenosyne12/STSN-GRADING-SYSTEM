<?php
$subjects = [
    [
        'id' => 1,
        'code' => 'ENG-4',
        'subject' => 'English',
        'level' => 'Grade 4',
        'track' => 'Basic Education',
        'status' => 'Active',
        'ww' => 30,
        'pt' => 50,
        'qa' => 20,
    ],
    [
        'id' => 2,
        'code' => 'MATH-4',
        'subject' => 'Mathematics',
        'level' => 'Grade 4',
        'track' => 'Basic Education',
        'status' => 'Active',
        'ww' => 40,
        'pt' => 40,
        'qa' => 20,
    ],
    [
        'id' => 3,
        'code' => 'MAPEH-4',
        'subject' => 'MAPEH',
        'level' => 'Grade 4',
        'track' => 'Basic Education',
        'status' => 'Draft',
        'ww' => 20,
        'pt' => 60,
        'qa' => 20,
    ],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Curriculum Setup</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast@1.4.0/dist/css/iziToast.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <style>
        body {
            background: #f4f7fb;
            font-family: Arial, sans-serif;
        }

        .hero-card {
            background: linear-gradient(135deg, #0f172a, #1e293b, #334155);
            color: #fff;
            border: 0;
            border-radius: 24px;
            overflow: hidden;
            box-shadow: 0 18px 40px rgba(15, 23, 42, 0.18);
        }

        .stat-card {
            border: 0;
            border-radius: 20px;
            box-shadow: 0 10px 24px rgba(15, 23, 42, 0.06);
            transition: 0.25s ease;
        }

        .stat-card:hover {
            transform: translateY(-3px);
        }

        .stat-icon {
            width: 52px;
            height: 52px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 16px;
            font-size: 1.2rem;
        }

        .toolbar-box,
        .table-box,
        .form-box {
            background: #fff;
            border-radius: 22px;
            box-shadow: 0 10px 30px rgba(15, 23, 42, 0.06);
        }

        .table thead th {
            background: #f8fafc;
            border-bottom: 0;
            color: #475569;
            font-size: 0.84rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }

        .table tbody tr {
            vertical-align: middle;
        }

        .table tbody tr:hover {
            background: #f8fbff;
        }

        .badge-soft-success {
            background: rgba(25, 135, 84, 0.12);
            color: #198754;
        }

        .badge-soft-warning {
            background: rgba(255, 193, 7, 0.18);
            color: #9a6700;
        }

        .badge-soft-secondary {
            background: rgba(108, 117, 125, 0.14);
            color: #495057;
        }

        .section-title {
            font-weight: 700;
            color: #0f172a;
        }

        .weight-pill {
            padding: 8px 12px;
            border-radius: 999px;
            background: #f1f5f9;
            font-size: 0.85rem;
            font-weight: 600;
            color: #334155;
        }

        .preset-btn {
            border-radius: 999px;
        }

        .btn-rounded {
            border-radius: 14px;
        }

        .modal-content {
            border: 0;
            border-radius: 24px;
            overflow: hidden;
        }

        .modal-header,
        .modal-footer {
            border: 0;
        }

        .form-control,
        .form-select {
            border-radius: 14px;
            min-height: 46px;
        }

        .summary-box {
            border-radius: 18px;
            background: #f8fafc;
            border: 1px dashed #cbd5e1;
        }
    </style>
</head>
<body>
<div class="container-fluid py-4 px-3 px-lg-4">
    <div class="card hero-card mb-4">
        <div class="card-body p-4 p-lg-5">
            <div class="d-flex flex-column flex-lg-row justify-content-between align-items-start gap-4">
                <div>
                    <div class="small text-light opacity-75 mb-2">
                        <i class="fa-solid fa-graduation-cap me-2"></i>Admin Panel / Academic Management
                    </div>
                    <h1 class="fw-bold mb-2">Curriculum Setup</h1>
                    <p class="mb-0 text-light opacity-75" style="max-width: 760px;">
                        Set up grade level subjects, curriculum structure, grading components, and assessment weights with a clean maintenance style admin interface.
                    </p>
                </div>
                <div class="d-flex flex-wrap gap-2">
                    <button class="btn btn-light btn-rounded px-4" onclick="previewAlert()">
                        <i class="fa-regular fa-bell me-2"></i>Preview Alerts
                    </button>
                    <button class="btn btn-primary btn-rounded px-4" data-bs-toggle="modal" data-bs-target="#curriculumModal" onclick="openCreateModal()">
                        <i class="fa-solid fa-plus me-2"></i>New Curriculum
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-6 col-xl-3">
            <div class="card stat-card h-100">
                <div class="card-body d-flex align-items-center justify-content-between p-4">
                    <div>
                        <div class="text-muted small mb-1">Total Subjects</div>
                        <h3 class="mb-0 fw-bold"><?php echo count($subjects); ?></h3>
                    </div>
                    <div class="stat-icon bg-primary-subtle text-primary">
                        <i class="fa-solid fa-layer-group"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3">
            <div class="card stat-card h-100">
                <div class="card-body d-flex align-items-center justify-content-between p-4">
                    <div>
                        <div class="text-muted small mb-1">Active</div>
                        <h3 class="mb-0 fw-bold"><?php echo count(array_filter($subjects, fn($item) => $item['status'] === 'Active')); ?></h3>
                    </div>
                    <div class="stat-icon bg-success-subtle text-success">
                        <i class="fa-solid fa-circle-check"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3">
            <div class="card stat-card h-100">
                <div class="card-body d-flex align-items-center justify-content-between p-4">
                    <div>
                        <div class="text-muted small mb-1">Draft</div>
                        <h3 class="mb-0 fw-bold"><?php echo count(array_filter($subjects, fn($item) => $item['status'] === 'Draft')); ?></h3>
                    </div>
                    <div class="stat-icon bg-warning-subtle text-warning">
                        <i class="fa-solid fa-pen"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3">
            <div class="card stat-card h-100">
                <div class="card-body d-flex align-items-center justify-content-between p-4">
                    <div>
                        <div class="text-muted small mb-1">Tracks</div>
                        <h3 class="mb-0 fw-bold">3</h3>
                    </div>
                    <div class="stat-icon bg-info-subtle text-info">
                        <i class="fa-solid fa-book-open"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="toolbar-box p-3 p-lg-4 mb-4">
        <div class="row g-3 align-items-end">
            <div class="col-lg-4">
                <label class="form-label fw-semibold">Search</label>
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0"><i class="fa-solid fa-magnifying-glass text-muted"></i></span>
                    <input type="text" class="form-control border-start-0" placeholder="Search subject, code, level..." id="searchInput">
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <label class="form-label fw-semibold">Grade Level</label>
                <select class="form-select" id="levelFilter">
                    <option value="">All Levels</option>
                    <option>Grade 1</option>
                    <option>Grade 2</option>
                    <option>Grade 3</option>
                    <option>Grade 4</option>
                    <option>Grade 5</option>
                    <option>Grade 6</option>
                    <option>Grade 7</option>
                    <option>Grade 8</option>
                    <option>Grade 9</option>
                    <option>Grade 10</option>
                    <option>Grade 11</option>
                    <option>Grade 12</option>
                </select>
            </div>
            <div class="col-md-6 col-lg-3">
                <label class="form-label fw-semibold">Status</label>
                <select class="form-select" id="statusFilter">
                    <option value="">All Status</option>
                    <option>Active</option>
                    <option>Draft</option>
                    <option>Archived</option>
                </select>
            </div>
            <div class="col-lg-2 d-grid">
                <button class="btn btn-dark btn-rounded" onclick="filterTable()">
                    <i class="fa-solid fa-filter me-2"></i>Apply Filter
                </button>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-xl-8">
            <div class="table-box p-3 p-lg-4 h-100">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
                    <div>
                        <h5 class="section-title mb-1">Curriculum List</h5>
                        <p class="text-muted mb-0 small">Manage curriculum entries and subject grading components.</p>
                    </div>
                    <button class="btn btn-outline-primary btn-rounded" data-bs-toggle="modal" data-bs-target="#curriculumModal" onclick="openCreateModal()">
                        <i class="fa-solid fa-plus me-2"></i>Add Record
                    </button>
                </div>

                <div class="table-responsive">
                    <table class="table align-middle" id="curriculumTable">
                        <thead>
                            <tr>
                                <th>Code</th>
                                <th>Subject</th>
                                <th>Level</th>
                                <th>Track</th>
                                <th>Weights</th>
                                <th>Status</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($subjects as $subject): ?>
                                <tr>
                                    <td class="fw-semibold"><?php echo htmlspecialchars($subject['code']); ?></td>
                                    <td><?php echo htmlspecialchars($subject['subject']); ?></td>
                                    <td><?php echo htmlspecialchars($subject['level']); ?></td>
                                    <td><?php echo htmlspecialchars($subject['track']); ?></td>
                                    <td>
                                        <div class="d-flex flex-wrap gap-2">
                                            <span class="weight-pill">WW <?php echo $subject['ww']; ?>%</span>
                                            <span class="weight-pill">PT <?php echo $subject['pt']; ?>%</span>
                                            <span class="weight-pill">QA <?php echo $subject['qa']; ?>%</span>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if ($subject['status'] === 'Active'): ?>
                                            <span class="badge rounded-pill badge-soft-success px-3 py-2">Active</span>
                                        <?php elseif ($subject['status'] === 'Draft'): ?>
                                            <span class="badge rounded-pill badge-soft-warning px-3 py-2">Draft</span>
                                        <?php else: ?>
                                            <span class="badge rounded-pill badge-soft-secondary px-3 py-2">Archived</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <div class="btn-group">
                                            <button class="btn btn-sm btn-outline-secondary" onclick="editCurriculum('<?php echo $subject['code']; ?>','<?php echo $subject['subject']; ?>','<?php echo $subject['level']; ?>','<?php echo $subject['track']; ?>','<?php echo $subject['status']; ?>',<?php echo $subject['ww']; ?>,<?php echo $subject['pt']; ?>,<?php echo $subject['qa']; ?>)">
                                                <i class="fa-solid fa-pen"></i>
                                            </button>
                                            <button class="btn btn-sm btn-outline-danger" onclick="confirmDelete('<?php echo $subject['subject']; ?>')">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-xl-4">
            <div class="form-box p-3 p-lg-4 h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>
                        <h5 class="section-title mb-1">Quick Setup Guide</h5>
                        <p class="text-muted mb-0 small">Use recommended grading weights and smart validations.</p>
                    </div>
                    <i class="fa-solid fa-sliders text-primary"></i>
                </div>

                <div class="summary-box p-3 mb-3">
                    <div class="fw-semibold mb-2">Recommended Presets</div>
                    <div class="d-flex flex-wrap gap-2">
                        <button class="btn btn-outline-primary btn-sm preset-btn" onclick="applyPreset(30,50,20,'Language/AP/EsP preset applied')">Language / AP / EsP</button>
                        <button class="btn btn-outline-success btn-sm preset-btn" onclick="applyPreset(40,40,20,'Science/Math preset applied')">Science / Math</button>
                        <button class="btn btn-outline-warning btn-sm preset-btn" onclick="applyPreset(20,60,20,'MAPEH/EPP-TLE preset applied')">MAPEH / EPP-TLE</button>
                    </div>
                </div>

                <div class="summary-box p-3 mb-3">
                    <div class="fw-semibold mb-2">Validation Rules</div>
                    <ul class="mb-0 text-muted small ps-3">
                        <li>Written Work + Performance Task + Quarterly Assessment must equal 100%</li>
                        <li>Subject code and subject name are required</li>
                        <li>Status can be Active, Draft, or Archived</li>
                        <li>Use toast alerts for save, update, and delete events</li>
                    </ul>
                </div>

                <div class="summary-box p-3">
                    <div class="fw-semibold mb-2">Alert Samples</div>
                    <div class="d-grid gap-2">
                        <button class="btn btn-success btn-rounded" onclick="showToast('success','Saved successfully','Curriculum setup has been saved.')">Success Toast</button>
                        <button class="btn btn-warning btn-rounded" onclick="showToast('warning','Validation warning','Weights must equal 100 percent.')">Warning Toast</button>
                        <button class="btn btn-danger btn-rounded" onclick="showToast('error','Delete warning','This record is about to be removed.')">Error Toast</button>
                        <button class="btn btn-info text-white btn-rounded" onclick="showToast('info','Information','Preset settings were loaded.')">Info Toast</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="curriculumModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header px-4 pt-4">
                <div>
                    <h4 class="modal-title fw-bold" id="modalTitle">New Curriculum</h4>
                    <p class="text-muted mb-0 small">Create or update a curriculum configuration.</p>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body px-4 pb-2">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Subject Code</label>
                        <input type="text" class="form-control" id="subjectCode" placeholder="Ex. ENG-4">
                    </div>
                    <div class="col-md-8">
                        <label class="form-label fw-semibold">Subject Name</label>
                        <input type="text" class="form-control" id="subjectName" placeholder="Enter subject name">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Grade Level</label>
                        <select class="form-select" id="subjectLevel">
                            <option>Grade 1</option>
                            <option>Grade 2</option>
                            <option>Grade 3</option>
                            <option selected>Grade 4</option>
                            <option>Grade 5</option>
                            <option>Grade 6</option>
                            <option>Grade 7</option>
                            <option>Grade 8</option>
                            <option>Grade 9</option>
                            <option>Grade 10</option>
                            <option>Grade 11</option>
                            <option>Grade 12</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Track</label>
                        <select class="form-select" id="subjectTrack">
                            <option>Basic Education</option>
                            <option>Junior High School</option>
                            <option>Senior High School</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Status</label>
                        <select class="form-select" id="subjectStatus">
                            <option>Active</option>
                            <option>Draft</option>
                            <option>Archived</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Written Work (%)</label>
                        <input type="number" class="form-control weight-input" id="ww" value="30">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Performance Task (%)</label>
                        <input type="number" class="form-control weight-input" id="pt" value="50">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Quarterly Assessment (%)</label>
                        <input type="number" class="form-control weight-input" id="qa" value="20">
                    </div>
                    <div class="col-12">
                        <div class="summary-box p-3 d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
                            <div>
                                <div class="fw-semibold">Weight Summary</div>
                                <div class="text-muted small">Make sure the total distribution equals 100%</div>
                            </div>
                            <div>
                                <span class="badge text-bg-dark fs-6 px-3 py-2" id="weightTotal">Total: 100%</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer px-4 pb-4">
                <button type="button" class="btn btn-outline-secondary btn-rounded px-4" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary btn-rounded px-4" onclick="saveCurriculum()">
                    <i class="fa-solid fa-floppy-disk me-2"></i>Save Curriculum
                </button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/izitoast@1.4.0/dist/js/iziToast.min.js"></script>
<script>
    const weightInputs = document.querySelectorAll('.weight-input');

    function updateWeightTotal() {
        const ww = parseInt(document.getElementById('ww').value || 0);
        const pt = parseInt(document.getElementById('pt').value || 0);
        const qa = parseInt(document.getElementById('qa').value || 0);
        const total = ww + pt + qa;
        const totalBadge = document.getElementById('weightTotal');

        totalBadge.textContent = 'Total: ' + total + '%';
        totalBadge.className = total === 100
            ? 'badge text-bg-success fs-6 px-3 py-2'
            : 'badge text-bg-danger fs-6 px-3 py-2';
    }

    weightInputs.forEach(function(input) {
        input.addEventListener('input', updateWeightTotal);
    });

    function showToast(type, title, message) {
        iziToast.show({
            id: null,
            class: '',
            title: title,
            titleColor: '',
            titleSize: '',
            titleLineHeight: '',
            message: message,
            messageColor: '',
            messageSize: '',
            messageLineHeight: '',
            backgroundColor: '',
            theme: 'light',
            color: type === 'success' ? 'green' : type === 'warning' ? 'yellow' : type === 'error' ? 'red' : 'blue',
            icon: type === 'success' ? 'fas fa-check-circle' : type === 'warning' ? 'fas fa-triangle-exclamation' : type === 'error' ? 'fas fa-circle-xmark' : 'fas fa-circle-info',
            iconText: '',
            iconColor: '',
            iconUrl: null,
            image: '',
            imageWidth: 50,
            maxWidth: null,
            zindex: null,
            layout: 1,
            balloon: false,
            close: true,
            closeOnEscape: false,
            closeOnClick: false,
            displayMode: 0,
            position: 'bottomRight',
            target: '',
            targetFirst: true,
            timeout: 5000,
            rtl: false,
            animateInside: true,
            drag: true,
            pauseOnHover: true,
            resetOnHover: false,
            progressBar: true,
            progressBarColor: '',
            progressBarEasing: 'linear',
            overlay: false,
            overlayClose: false,
            overlayColor: 'rgba(0, 0, 0, 0.6)',
            transitionIn: 'fadeInUp',
            transitionOut: 'fadeOut',
            transitionInMobile: 'fadeInUp',
            transitionOutMobile: 'fadeOutDown',
            buttons: {},
            inputs: {},
            onOpening: function () {},
            onOpened: function () {},
            onClosing: function () {},
            onClosed: function () {}
        });
    }

    function previewAlert() {
        showToast('info', 'Preview ready', 'Curriculum module alerts are active and working.');
    }

    function applyPreset(ww, pt, qa, message) {
        document.getElementById('ww').value = ww;
        document.getElementById('pt').value = pt;
        document.getElementById('qa').value = qa;
        updateWeightTotal();
        showToast('info', 'Preset applied', message);
    }

    function openCreateModal() {
        document.getElementById('modalTitle').textContent = 'New Curriculum';
        document.getElementById('subjectCode').value = '';
        document.getElementById('subjectName').value = '';
        document.getElementById('subjectLevel').value = 'Grade 4';
        document.getElementById('subjectTrack').value = 'Basic Education';
        document.getElementById('subjectStatus').value = 'Active';
        document.getElementById('ww').value = 30;
        document.getElementById('pt').value = 50;
        document.getElementById('qa').value = 20;
        updateWeightTotal();
    }

    function editCurriculum(code, subject, level, track, status, ww, pt, qa) {
        document.getElementById('modalTitle').textContent = 'Edit Curriculum';
        document.getElementById('subjectCode').value = code;
        document.getElementById('subjectName').value = subject;
        document.getElementById('subjectLevel').value = level;
        document.getElementById('subjectTrack').value = track;
        document.getElementById('subjectStatus').value = status;
        document.getElementById('ww').value = ww;
        document.getElementById('pt').value = pt;
        document.getElementById('qa').value = qa;
        updateWeightTotal();

        const modal = new bootstrap.Modal(document.getElementById('curriculumModal'));
        modal.show();
    }

    function saveCurriculum() {
        const code = document.getElementById('subjectCode').value.trim();
        const subject = document.getElementById('subjectName').value.trim();
        const ww = parseInt(document.getElementById('ww').value || 0);
        const pt = parseInt(document.getElementById('pt').value || 0);
        const qa = parseInt(document.getElementById('qa').value || 0);
        const total = ww + pt + qa;

        if (!code || !subject) {
            showToast('error', 'Missing fields', 'Please enter the subject code and subject name.');
            return;
        }

        if (total !== 100) {
            showToast('warning', 'Invalid weights', 'Written Work, Performance Task, and Quarterly Assessment must total 100%.');
            return;
        }

        showToast('success', 'Saved successfully', subject + ' curriculum setup has been saved.');

        const modalEl = document.getElementById('curriculumModal');
        const modal = bootstrap.Modal.getInstance(modalEl);
        if (modal) {
            modal.hide();
        }
    }

    function confirmDelete(subject) {
        showToast('error', 'Delete confirmation', subject + ' is marked for deletion. Add your delete modal or backend action here.');
    }

    function filterTable() {
        const search = document.getElementById('searchInput').value.toLowerCase();
        const level = document.getElementById('levelFilter').value.toLowerCase();
        const status = document.getElementById('statusFilter').value.toLowerCase();
        const rows = document.querySelectorAll('#curriculumTable tbody tr');

        rows.forEach(function(row) {
            const text = row.innerText.toLowerCase();
            const rowLevel = row.cells[2].innerText.toLowerCase();
            const rowStatus = row.cells[5].innerText.toLowerCase();

            const matchSearch = !search || text.includes(search);
            const matchLevel = !level || rowLevel === level;
            const matchStatus = !status || rowStatus === status;

            row.style.display = matchSearch && matchLevel && matchStatus ? '' : 'none';
        });

        showToast('info', 'Filter applied', 'Curriculum records have been filtered.');
    }

    updateWeightTotal();
</script>
</body>
</html>
