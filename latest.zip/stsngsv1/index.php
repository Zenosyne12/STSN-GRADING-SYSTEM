<?php
header('Location: /stsngsv1/login.php');
exit;