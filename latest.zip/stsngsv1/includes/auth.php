<?php
if (session_status() === PHP_SESSION_NONE) {
    // Ensure the session cookie is available across the whole site.
    session_set_cookie_params([
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
    session_start();
}

function redirectTo(string $path): void
{
    header('Location: ' . $path);
    exit;
}

function requireLogin(): void
{
    if (!isset($_SESSION['user_id']) || (int)$_SESSION['user_id'] <= 0) {
        redirectTo('/stsngsv1/stsngsv1/login.php');
    }
}

function isAdminSession(): bool
{
    requireLogin();

    return !isset($_SESSION['reference_id'])
        || $_SESSION['reference_id'] === null
        || $_SESSION['reference_id'] === '';
}

function requireAdmin(): void
{
    requireLogin();

    if (!isAdminSession()) {
        redirectTo('/stsngsv1/stsngsv1/teacher-dashboard.php');
    }
}

function requireTeacher(): void
{
    requireLogin();

    if (isAdminSession()) {
        redirectTo('/stsngsv1/stsngsv1/Dashboard.php');
    }
}