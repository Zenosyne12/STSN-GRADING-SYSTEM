<?php
require_once __DIR__ . '/api/shared/db_connect.php';

// Fetch grade levels for filter
$gradeLevels = [];
try {
    $stmt = $pdo->query("SELECT id, grade_level_name FROM tblgradelevel ORDER BY id ASC");
    $gradeLevels = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Silently fail if table doesn't exist
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Scheduling</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        @media (max-width: 767.98px) {
            #sectionTable thead { display: none; }

            #sectionTable tbody tr {
                display: block;
                border: 1px solid #dee2e6;
                margin-bottom: .75rem;
                border-radius: .4rem;
                padding: .5rem;
            }

            #sectionTable tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                border: none !important;
                padding: .35rem .5rem;
            }

            #sectionTable tbody td::before {
                content: attr(data-label);
                font-weight: 600;
                margin-right: .5rem;
                white-space: nowrap;
            }

            #sectionTable tbody td:last-child {
                flex-direction: column;
                gap: .25rem;
            }

            #sectionTable tbody td:last-child .btn,
            #sectionTable tbody td:last-child a {
                width: 100%;
            }

            .card-header .row {
                text-align: center;
            }

            .card-header .d-flex.gap-2 {
                flex-direction: column;
            }

            .card-header select,
            .card-header .input-group {
                width: 100% !important;
                max-width: none !important;
            }
        }

        .card-header .form-select,
        .card-header .input-group {
            margin-bottom: 0;
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6">
                        <h3 class="mb-0"><i class="bi bi-calendar-week"></i> Section Scheduling</h3>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item">Academic</li>
                            <li class="breadcrumb-item active">Scheduling</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-4 m-3">
            <div class="card-header">
                <div class="row align-items-center g-3">
                    <div class="col-lg-3 col-md-4 col-sm-12">
                        <h3 class="card-title mb-0">
                            <i class="bi bi-list-ul"></i> Section List
                        </h3>
                    </div>

                    <div class="col-lg-5 col-md-3 d-none d-md-block"></div>

                    <div class="col-lg-4 col-md-5 col-sm-12">
                        <div class="d-flex gap-2 justify-content-md-end flex-wrap">
                            <select class="form-select form-select-sm" id="gradeLevelFilter" style="max-width: 180px;">
                                <option value="">All Grade Levels</option>
                                <?php foreach ($gradeLevels as $gl): ?>
                                    <option value="<?= htmlspecialchars($gl['id']) ?>">
                                        <?= htmlspecialchars($gl['grade_level_name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                            <div class="input-group input-group-sm" style="max-width: 220px;">
                                <span class="input-group-text bg-light"><i class="bi bi-search"></i></span>
                                <input class="form-control" type="search" id="searchInput" placeholder="Search section...">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card-body">
                <div class="table-responsive d-none d-md-block">
                    <table id="sectionTable" class="table table-bordered table-hover align-middle text-center mb-0">
                        <thead class="table-light">
                            <tr>
                                <th style="width:50px;">#</th>
                                <th>Grade Level</th>
                                <th>Section Name</th>
                                <th style="width:120px;">Status</th>
                                <th style="width:170px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="sectionTableBody"></tbody>
                    </table>
                </div>

                <div class="d-block d-md-none" id="sectionCardView"></div>
            </div>
        </div>
    </main>

    <?php require_once("includes/footer.php"); ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script>
function esc(str) {
    return (str ?? '').toString()
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

async function fetchJson(url, options = {}) {
    const res = await fetch(url, options);
    const text = await res.text();

    let json;
    try {
        json = JSON.parse(text);
    } catch (e) {
        console.error('Invalid JSON:', url, text);
        throw new Error('Invalid server response');
    }

    if (!res.ok) {
        throw new Error(json.error || ('HTTP ' + res.status));
    }

    return json;
}

async function loadSections() {
    try {
        const search = document.getElementById('searchInput').value.trim();
        const gradeLevelId = document.getElementById('gradeLevelFilter').value;

        let url = `api/schedule/sections.php?s=${encodeURIComponent(search)}`;
        if (gradeLevelId) {
            url += `&grade_level_id=${encodeURIComponent(gradeLevelId)}`;
        }

        const data = await fetchJson(url);
        const list = data.sections || [];

        document.getElementById('sectionTableBody').innerHTML = list.map((s, i) => `
            <tr>
                <td data-label="#">${i + 1}</td>
                <td data-label="Grade Level">${esc(s.grade_level_name || '-')}</td>
                <td data-label="Section Name" class="text-start">${esc(s.section_name || '-')}</td>
                <td data-label="Status">
                    <span class="badge bg-${String(s.is_active) === '1' ? 'success' : 'secondary'}">
                        ${String(s.is_active) === '1' ? 'Active' : 'Inactive'}
                    </span>
                </td>
                <td data-label="Actions">
                    <a href="schedule_manage.php?section_id=${s.id}" class="btn btn-sm btn-primary">
                        <i class="bi bi-calendar3"></i> Manage
                    </a>
                </td>
            </tr>
        `).join('');

        document.getElementById('sectionCardView').innerHTML = list.map((s, i) => `
            <div class="card mb-3 shadow-sm">
                <div class="card-header bg-light d-flex justify-content-between">
                    <span class="fw-bold">${i + 1}. ${esc(s.section_name || '-')}</span>
                    <span class="badge bg-${String(s.is_active) === '1' ? 'success' : 'secondary'}">
                        ${String(s.is_active) === '1' ? 'Active' : 'Inactive'}
                    </span>
                </div>
                <div class="card-body py-2 small">
                    <div class="row mb-1">
                        <div class="col-4 text-muted">Grade</div>
                        <div class="col-8">${esc(s.grade_level_name || '-')}</div>
                    </div>
                </div>
                <div class="card-footer d-grid">
                    <a href="schedule_manage.php?section_id=${s.id}" class="btn btn-sm btn-primary">
                        <i class="bi bi-calendar3"></i> Manage
                    </a>
                </div>
            </div>
        `).join('');
    } catch (err) {
        console.error(err);
        alert('Failed to load sections: ' + err.message);
    }
}

document.getElementById('searchInput').addEventListener('input', loadSections);
document.getElementById('gradeLevelFilter').addEventListener('change', loadSections);

loadSections();
</script>
</body>
</html>