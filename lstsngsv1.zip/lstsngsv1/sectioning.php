<?php
require_once __DIR__ . '/includes/auth.php';    

require_once __DIR__ . '/api/shared/db_connect.php';

$sectionId = isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0;

function h($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

function getStudentColumns(PDO $pdo): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }

    $colsStmt = $pdo->query('SHOW COLUMNS FROM tblstudents');
    $columns = $colsStmt->fetchAll(PDO::FETCH_COLUMN);

    $fnameCol = in_array('fname', $columns, true) ? 'fname' : (in_array('firstname', $columns, true) ? 'firstname' : null);
    $mnameCol = in_array('mname', $columns, true) ? 'mname' : (in_array('middlename', $columns, true) ? 'middlename' : null);
    $lnameCol = in_array('lname', $columns, true) ? 'lname' : (in_array('lastname', $columns, true) ? 'lastname' : null);

    $genderCol = null;
    foreach (['gender', 'sex', 'student_gender'] as $candidate) {
        if (in_array($candidate, $columns, true)) {
            $genderCol = $candidate;
            break;
        }
    }

    $studentNoCol = null;
    foreach (['student_no', 'lrn', 'school_id'] as $candidate) {
        if (in_array($candidate, $columns, true)) {
            $studentNoCol = $candidate;
            break;
        }
    }

    $cache = compact('fnameCol', 'mnameCol', 'lnameCol', 'genderCol', 'studentNoCol');
    return $cache;
}

function fetchSectionViewData(PDO $pdo, int $sectionId, int $academicYearId = 0): array
{
    if ($sectionId <= 0) {
        throw new RuntimeException('Invalid section.');
    }

    if ($academicYearId <= 0) {
        $ayStmt = $pdo->query("
            SELECT id, year_label
            FROM tblacademicyear
            WHERE COALESCE(is_active, 1) = 1
            ORDER BY id DESC
            LIMIT 1
        ");
        $activeAy = $ayStmt->fetch(PDO::FETCH_ASSOC);
        $academicYearId = (int)($activeAy['id'] ?? 0);
    }

    
    $stmt = $pdo->prepare("
        SELECT s.id, s.section_name, s.grade_level_id, g.grade_level_name
        FROM tblsection s
        LEFT JOIN tblgradelevel g ON g.id = s.grade_level_id
        WHERE s.id = ?
    ");
    $stmt->execute([$sectionId]);
    $section = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$section) {
        throw new RuntimeException('Section not found.');
    }

    
    $schoolYear = '';
    if ($academicYearId > 0) {
        $ay = $pdo->prepare("SELECT year_label FROM tblacademicyear WHERE id = ?");
        $ay->execute([$academicYearId]);
        $schoolYear = (string)($ay->fetchColumn() ?: '');
    }

    $cols = getStudentColumns($pdo);
    if (!$cols['fnameCol'] || !$cols['lnameCol']) {
        throw new RuntimeException('Student name columns not found in tblstudents.');
    }

    $studentIdentifierExpr = $cols['studentNoCol'] ? "st.`{$cols['studentNoCol']}`" : "st.id";
    $middleExpr = $cols['mnameCol']
        ? "CASE WHEN COALESCE(st.`{$cols['mnameCol']}`, '') = '' THEN '' ELSE CONCAT(' ', LEFT(st.`{$cols['mnameCol']}`, 1), '.') END"
        : "''";
    $genderSelect = $cols['genderCol'] ? "st.`{$cols['genderCol']}`" : "NULL";

    
    $allStudents = [];
    if ($academicYearId > 0) {
        $sqlStudents = "
            SELECT
                ss.id AS section_student_id,
                st.id,
                {$studentIdentifierExpr} AS student_identifier,
                CONCAT(
                    st.`{$cols['lnameCol']}`,
                    ', ',
                    st.`{$cols['fnameCol']}`,
                    {$middleExpr}
                ) AS full_name,
                {$genderSelect} AS gender
            FROM tblsectionstudent ss
            INNER JOIN tblstudents st ON st.id = ss.student_id
            WHERE ss.section_id = ?
              AND ss.academic_year_id = ?
              AND ss.is_active = 1
            ORDER BY st.`{$cols['lnameCol']}` ASC, st.`{$cols['fnameCol']}` ASC
        ";
        $stmt = $pdo->prepare($sqlStudents);
        $stmt->execute([$sectionId, $academicYearId]);
        $allStudents = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    
    $maleStudents = [];
    $femaleStudents = [];
    $unknownGender = [];

    foreach ($allStudents as $student) {
        $gender = strtolower(trim((string)($student['gender'] ?? '')));
        if (in_array($gender, ['male', 'm', 'boy', 'boys', '1'], true)) {
            $student['gender_label'] = 'Male';
            $maleStudents[] = $student;
        } elseif (in_array($gender, ['female', 'f', 'girl', 'girls', '0', '2'], true)) {
            $student['gender_label'] = 'Female';
            $femaleStudents[] = $student;
        } else {
            $student['gender_label'] = 'Unspecified';
            $unknownGender[] = $student;
        }
    }

    
    $schedules = [];
    $sqlSchedule = "
        SELECT
            sc.id, sc.day_name AS day_of_week, sc.time_start, sc.time_end,
            sc.room, sc.semester, sc.school_year,
            sub.subject_code, sub.subject_name,
            CONCAT(t.fname, ' ', t.lname) AS teacher_name
        FROM tblschedule sc
        INNER JOIN tblsubjects sub ON sub.id = sc.subject_id
        INNER JOIN tblteacher t ON t.id = sc.teacher_id
        WHERE sc.section_id = ?
          AND COALESCE(sc.is_active, 1) = 1
    ";
    $scheduleParams = [$sectionId];
    if ($schoolYear !== '') {
        $sqlSchedule .= " AND sc.school_year = ? ";
        $scheduleParams[] = $schoolYear;
    }
    $sqlSchedule .= "
        ORDER BY
            FIELD(sc.day_name, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'),
            sc.time_start ASC,
            sub.subject_name ASC
    ";

    $stmt = $pdo->prepare($sqlSchedule);
    $stmt->execute($scheduleParams);
    $schedules = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return [
        'section' => [
            'id'                => (int)$section['id'],
            'section_name'      => $section['section_name'] ?? '',
            'grade_level_name'  => $section['grade_level_name'] ?? '',
            'school_year'       => $schoolYear !== '' ? $schoolYear : 'Not set',
            'academic_year_id'  => $academicYearId,
        ],
        'stats' => [
            'total_students'        => count($allStudents),
            'male_students'         => count($maleStudents),
            'female_students'       => count($femaleStudents),
            'unspecified_students'  => count($unknownGender),
            'total_schedules'       => count($schedules),
        ],
        'students'              => $allStudents,
        'male_students_list'    => $maleStudents,
        'female_students_list'  => $femaleStudents,
        'unknown_students_list' => $unknownGender,
        'schedules'             => $schedules,
    ];
}


$gradeLevels = [];
try {
    $glStmt = $pdo->query("
        SELECT id, grade_level_name
        FROM tblgradelevel
        ORDER BY sort_order ASC, grade_level_name ASC
    ");
    $gradeLevels = $glStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log('Failed to load grade levels: ' . $e->getMessage());
}

if (isset($_GET['ajax']) && $_GET['ajax'] === 'view_section') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $requestedSectionId = (int)($_GET['id'] ?? 0);
        if ($requestedSectionId <= 0) {
            throw new RuntimeException('Invalid section ID.');
        }
        $academicYearId = (int)($_GET['academic_year_id'] ?? 0);
        echo json_encode([
            'success' => true,
            'data'    => fetchSectionViewData($pdo, $requestedSectionId, $academicYearId)
        ]);
    } catch (Throwable $e) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error'   => $e->getMessage()
        ]);
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
    <meta charset="utf-8">
    <title>STSN Grading System | Sectioning</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        /* ============================================================
           THEME VARIABLES (Light & Dark)
           ============================================================ */
        :root,
        [data-bs-theme="light"] {
            --ay-bg: #f3f7fd;
            --ay-card: #ffffff;
            --ay-card-soft: #fafcff;
            --ay-border: #dce8f8;
            --ay-border-soft: #e8f0fb;
            --ay-text: #213a5e;
            --ay-text-strong: #132f62;
            --ay-text-muted: #7a93b8;
            --ay-head-bg: #f4f8ff;
            --ay-head-text: #3b5e96;
            --ay-row-hover: #f7fbff;
            --ay-row-border: #f0f5fc;
            --ay-section-name: #132f62; /* Section name color */
            
            /* Secondary Button (View) */
            --ay-btn-secondary-bg: #ffffff;
            --ay-btn-secondary-text: #1248a8;
            --ay-btn-secondary-border: #b8d0fa;
            --ay-btn-secondary-hover-bg: #eef4ff;
            --ay-btn-secondary-hover-border: #8db5f7;
            
            /* Modal Specific */
            --ay-sv-bar: #132f62;
            --ay-sv-bar-text: #ffffff;
        }

        [data-bs-theme="dark"] {
            --ay-bg: #1a1a1a;
            --ay-card: #2D2D2D;
            --ay-card-soft: #262626;
            --ay-border: #3a3a3a;
            --ay-border-soft: #3a3a3a;
            --ay-text: #e4e6e8;
            --ay-text-strong: #ffffff;
            --ay-text-muted: #adb5bd;
            --ay-head-bg: #2D2D2D;
            --ay-head-text: #ffffff;
            --ay-row-hover: #343434;
            --ay-row-border: #3a3a3a;
            --ay-section-name: #ffffff; /* White in dark mode */
            
            /* Secondary Button (View) - Dark Mode */
            --ay-btn-secondary-bg: #3a3a3a;
            --ay-btn-secondary-text: #8ab4f8;
            --ay-btn-secondary-border: #4a5a6e;
            --ay-btn-secondary-hover-bg: #4a4a4a;
            --ay-btn-secondary-hover-border: #6a7a8e;
            
            /* Modal Specific Dark Mode */
            --ay-sv-bar: #132f62;
            --ay-sv-bar-text: #ffffff;
        }

        /* ============================================================
           BASE & LAYOUT
           ============================================================ */
        body {
            background: var(--ay-bg);
        }

        .ay-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }
        .ay-page-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 0.2rem;
            letter-spacing: 0.01em;
        }
        .ay-page-header p {
            margin: 0;
            font-size: 0.88rem;
            opacity: 0.85;
        }

        .ay-card {
            background: var(--ay-card);
            border: 1px solid var(--ay-border);
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18, 72, 168, 0.06);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }
        .ay-card-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid var(--ay-border-soft);
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
            background: var(--ay-card);
        }
        .ay-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: var(--ay-text-strong);
            margin: 0 0 0.15rem;
        }
        .ay-card-subtitle {
            font-size: 0.8rem;
            color: var(--ay-text-muted);
            margin: 0;
        }
        .ay-toolbar {
            display: flex;
            gap: .6rem;
            flex-wrap: wrap;
            align-items: center;
        }
        .ay-card-body {
            padding: 0;
        }
        .ay-card-footer {
            padding: 0.75rem 1.2rem;
            border-top: 1px solid var(--ay-border-soft);
            background: var(--ay-card-soft);
            display: flex;
            justify-content: flex-end;
        }

        /* ============================================================
           TABLE
           ============================================================ */
        .ay-table-wrap {
            padding: 0;
        }
        .ay-table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            margin: 0;
        }
        .ay-table thead th {
            background: var(--ay-head-bg);
            color: var(--ay-head-text);
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 0.85rem 1rem;
            border-bottom: 1.5px solid var(--ay-border);
            white-space: nowrap;
            text-align: center;
        }
        .ay-table tbody tr {
            transition: background 0.12s;
        }
        .ay-table tbody tr:not(:last-child) td {
            border-bottom: 1px solid var(--ay-row-border);
        }
        .ay-table tbody tr:hover td {
            background: var(--ay-row-hover);
        }
        .ay-table tbody td {
            padding: 0.95rem 1rem;
            font-size: 0.92rem;
            color: var(--ay-text);
            vertical-align: middle;
            text-align: center;
        }
        .ay-left {
            text-align: left !important;
        }
        .ay-center {
            text-align: center !important;
        }
        .section-table .col-row { width: 64px; }
        .section-table .col-grade { width: 18%; }
        .section-table .col-section { width: 22%; }
        .section-table .col-adviser { width: 22%; }
        .section-table .col-students { width: 130px; }
        .section-table .col-status { width: 130px; }
        .section-table .col-actions { width: 220px; }

        .row-num {
            color: var(--ay-text-muted);
            font-size: 0.82rem;
            font-weight: 600;
        }
        
        /* SECTION NAME TEXT COLOR */
        .year-label {
            font-weight: 700;
            color: var(--ay-section-name);
        }

        /* ============================================================
           BADGES
           ============================================================ */
        .ay-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.32rem 0.75rem;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }
        .ay-badge-active {
            background: #e6f0ff;
            color: #1248a8;
            border: 1.5px solid #b8d0fa;
        }
        .ay-badge-inactive {
            background: #f3f5f8;
            color: #7a8ea8;
            border: 1.5px solid #dde4ee;
        }
        [data-bs-theme="dark"] .ay-badge-active {
            background: #1e2a3d;
            color: #8ab4f8;
            border-color: #2d4366;
        }
        [data-bs-theme="dark"] .ay-badge-inactive {
            background: #3a3a3a;
            color: #a9b8cd;
            border-color: #4a5a6e;
        }

        /* ============================================================
           BUTTONS
           ============================================================ */
        .btn-ay {
            font-weight: 600;
            font-size: 0.82rem;
            border-radius: 8px;
            padding: 0.42rem 0.9rem;
            cursor: pointer;
            transition: background 0.15s, border-color 0.15s, color 0.15s, box-shadow 0.15s;
            border: 1.5px solid transparent;
            line-height: 1.4;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: .35rem;
        }
        .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            border-color: transparent;
            box-shadow: 0 2px 8px rgba(26, 110, 245, 0.2);
        }
        .btn-ay-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
        }
        
        /* VIEW BUTTON - FIXED FOR DARK MODE */
        .btn-ay-secondary {
            background: var(--ay-btn-secondary-bg);
            color: var(--ay-btn-secondary-text);
            border-color: var(--ay-btn-secondary-border);
        }
        .btn-ay-secondary:hover {
            background: var(--ay-btn-secondary-hover-bg);
            border-color: var(--ay-btn-secondary-hover-border);
            color: var(--ay-btn-secondary-text);
        }

        /* ============================================================
           PAGINATION
           ============================================================ */
        .ay-pagination {
            display: flex;
            gap: 0.3rem;
            list-style: none;
            margin: 0;
            padding: 0;
            justify-content: flex-end;
            flex-wrap: wrap;
        }
        .ay-pagination .ay-page-item .ay-page-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
            border-radius: 7px;
            font-size: 0.83rem;
            font-weight: 600;
            cursor: pointer;
            border: 1.5px solid var(--ay-border);
            color: #1a6ef5;
            background: var(--ay-card);
            transition: all 0.13s;
            padding: 0 0.5rem;
            text-decoration: none;
        }
        .ay-pagination .ay-page-item .ay-page-link:hover {
            background: var(--ay-row-hover);
            border-color: #9cc2fc;
        }
        .ay-pagination .ay-page-item.active .ay-page-link {
            background: #1a6ef5;
            border-color: #1a6ef5;
            color: #fff;
        }
        .ay-pagination .ay-page-item.disabled .ay-page-link {
            background: var(--ay-card-soft);
            border-color: var(--ay-border);
            color: var(--ay-text-muted);
            cursor: not-allowed;
            pointer-events: none;
        }

        /* ============================================================
           EMPTY STATES & MOBILE CARDS
           ============================================================ */
        .ay-empty {
            text-align: center;
            padding: 2.5rem 1.5rem;
            color: var(--ay-text-muted);
        }
        .ay-empty i {
            font-size: 2.2rem;
            display: block;
            margin-bottom: 0.6rem;
            opacity: 0.5;
        }
        .ay-empty p {
            margin: 0;
            font-size: 0.95rem;
        }
        .ay-mobile-card {
            background: var(--ay-card);
            border: 1.5px solid var(--ay-border);
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 1px 6px rgba(18, 72, 168, 0.05);
        }
        .ay-mobile-card + .ay-mobile-card {
            margin-top: 0.75rem;
        }
        .ay-mobile-card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.85rem 1rem;
            border-bottom: 1px solid var(--ay-border-soft);
            background: var(--ay-card-soft);
            gap: .75rem;
        }
        .ay-mobile-card-title {
            font-weight: 700;
            color: var(--ay-section-name);
            font-size: 0.95rem;
        }
        .ay-mobile-card-body {
            padding: 0.85rem 1rem;
        }
        .ay-mobile-row {
            display: flex;
            justify-content: space-between;
            gap: .75rem;
            padding: .2rem 0;
            font-size: .9rem;
            color: var(--ay-text);
        }
        .ay-mobile-label {
            color: var(--ay-text-muted);
            font-weight: 600;
        }
        .ay-mobile-actions {
            display: grid;
            gap: .5rem;
            padding: 0 1rem 1rem;
        }

        /* ============================================================
           SECTION VIEW MODAL
           ============================================================ */
        .section-view-modal .modal-dialog {
            max-width: 1180px;
        }
        .section-view-modal .modal-content {
            border: 0;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 10px 34px rgba(18, 72, 168, 0.18);
            background: var(--ay-card);
        }

        /* ---- Section View Modal — Header (Pseudo-element gradient, bulletproof) ---- */
        .section-view-modal .modal-header {
            position: relative;
            z-index: 0;
            color: #fff !important;
            border-bottom: 0 !important;
            padding: 1rem 1.25rem !important;
            border-top-left-radius: 18px;
            border-top-right-radius: 18px;
            /* Solid fallback in case even the pseudo-element is stripped */
            background-color: #0b3d91 !important;
            overflow: hidden;
        }

        /* The actual gradient — drawn by a pseudo-element that no external
           theme rule is likely to target. Matches the schedule form modal. */
        .section-view-modal .modal-header::before {
            content: "";
            position: absolute;
            inset: 0;
            z-index: -1;
            background: linear-gradient(135deg, #0b3d91 0%, #1457b8 52%, #1d75e8 100%);
            pointer-events: none;
        }

        /* Ensure all header children sit above the pseudo-element and are white */
        .section-view-modal .modal-header > * {
            position: relative;
            z-index: 1;
        }
        .section-view-modal .modal-header .modal-title,
        .section-view-modal .modal-header .small,
        .section-view-modal .modal-header i,
        .section-view-modal .modal-header div {
            color: #fff !important;
        }

        /* Keep the ✕ button bright/white on the blue gradient */
        .section-view-modal .modal-header .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%) !important;
            opacity: 1 !important;
        }

        .section-view-modal .modal-body {
            background: var(--ay-card);
            padding: 1.2rem;
        }
        .sv-school-name {
            font-size: 1.25rem;
            font-weight: 900;
            letter-spacing: .02em;
            text-align: center;
            margin: 0;
            color: var(--ay-text-strong);
        }
        .sv-subhead {
            font-size: .85rem;
            text-align: center;
            color: var(--ay-text-muted);
            margin: .2rem 0 1rem;
        }
        .sv-section-bar {
            background: var(--ay-sv-bar);
            color: var(--ay-sv-bar-text);
            text-align: center;
            font-size: 1.35rem;
            font-weight: 900;
            line-height: 1.1;
            padding: .55rem .75rem;
            border-radius: 12px 12px 0 0;
        }
        .sv-semester-line {
            text-align: center;
            font-size: 1rem;
            font-weight: 800;
            margin: 0 0 1rem;
            padding: .6rem .75rem;
            background: var(--ay-head-bg);
            border: 1px solid var(--ay-border);
            border-top: 0;
            border-radius: 0 0 12px 12px;
            color: var(--ay-text-strong);
        }
        .sv-summary {
            text-align: center;
            font-size: .95rem;
            margin-bottom: 1rem;
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 1rem;
        }
        .sv-summary span {
            font-weight: 700;
            background: var(--ay-card-soft);
            border: 1px solid var(--ay-border);
            border-radius: 999px;
            padding: .35rem .85rem;
        }
        .male-count { color: #1248a8; }
        .female-count { color: #c2185b; }
        .total-count { color: #355177; }
        
        [data-bs-theme="dark"] .male-count { color: #8ab4f8; }
        [data-bs-theme="dark"] .female-count { color: #ff8bb5; }
        [data-bs-theme="dark"] .total-count { color: #cfd8e3; }

        .sv-block-title {
            font-size: 1rem;
            font-weight: 900;
            margin: 1.2rem 0 .8rem;
            text-align: center;
            text-transform: uppercase;
            border-bottom: 2px solid var(--ay-border);
            padding-bottom: 0.45rem;
            color: var(--ay-text-strong);
        }
        .sv-table-wrap {
            border: 1px solid var(--ay-border);
            border-radius: 12px;
            overflow: hidden;
        }
        .sv-table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            font-size: 0.9rem;
            margin: 0;
        }
        .sv-table th,
        .sv-table td {
            border: 1px solid var(--ay-border);
            padding: 0.7rem;
            vertical-align: middle;
            color: var(--ay-text);
        }
        .sv-table th {
            background: var(--ay-head-bg);
            font-size: 0.8rem;
            font-weight: 900;
            text-align: center;
            color: var(--ay-head-text);
        }
        .sv-year-row td {
            font-size: 1rem;
            font-weight: 900;
            text-align: center;
            padding: 0.8rem 0;
            background: var(--ay-head-bg);
            color: var(--ay-text-strong);
        }
        .sv-center {
            text-align: center;
        }
        .students-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
            margin-bottom: 1rem;
        }
        .gender-column {
            border: 1px solid var(--ay-border);
            border-radius: 12px;
            overflow: hidden;
            background: var(--ay-card);
        }
        .gender-header {
            font-size: 0.88rem;
            font-weight: 800;
            text-align: center;
            padding: 0.75rem;
            border-bottom: 1px solid var(--ay-border);
            background: var(--ay-head-bg);
            color: var(--ay-head-text);
        }
        .student-list {
            font-size: 0.92rem;
            line-height: 1.65;
            max-height: 360px;
            overflow: auto;
            padding: .4rem 0;
        }
        .student-item {
            margin: 0;
            display: flex;
            align-items: baseline;
            gap: .55rem;
            padding: .55rem .85rem;
            border-bottom: 1px solid var(--ay-border-soft);
        }
        .student-item:last-child {
            border-bottom: 0;
        }
        .student-number {
            font-weight: bold;
            min-width: 26px;
            color: var(--ay-text-muted);
        }
        .student-id {
            font-family: monospace;
            font-size: 0.9rem;
            min-width: 105px;
            color: var(--ay-text-muted);
        }
        .student-name {
            font-weight: 600;
            color: var(--ay-text-strong);
        }
        .sv-empty-inline {
            text-align: center;
            color: var(--ay-text-muted);
            font-style: italic;
            padding: 1.25rem;
        }
        .unknown-wrap {
            border: 1px solid var(--ay-border);
            border-radius: 12px;
            overflow: hidden;
            background: var(--ay-card);
            margin-top: 1rem;
        }

        /* ============================================================
           FORMS (Dark Mode Support)
           ============================================================ */
        .form-select, .form-control {
            color: var(--ay-text);
            background-color: var(--ay-card);
            border-color: var(--ay-border);
        }
        .input-group-text {
            background-color: var(--ay-card);
            border-color: var(--ay-border);
            color: var(--ay-text-muted);
        }
        [data-bs-theme="dark"] .form-select,
        [data-bs-theme="dark"] .form-control,
        [data-bs-theme="dark"] .input-group-text {
            background-color: #3a3a3a;
            border-color: #4a5a6e;
            color: #e4e6e8;
        }

        /* ============================================================
           RESPONSIVE
           ============================================================ */
        @media (max-width: 991.98px) {
            .students-container {
                grid-template-columns: 1fr;
            }
        }
        @media (max-width: 767.98px) {
            .ay-page-header {
                padding: 1.1rem 1.2rem;
                border-radius: 14px;
            }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <div class="app-wrapper">
        <?php require_once("includes/header.php"); ?>
        <?php require_once("includes/sidebar.php"); ?>

        <main class="app-main">
            <div class="app-content">
                <div class="container-fluid py-3">
                    
                    <div class="page-header">
                        <div>
                            <h3><i class="bi bi-diagram-3 me-2"></i>Sectioning</h3>
                            <p>Create Sections for a Grade Level.</p>
                        </div>
                    </div>

                    
                    <?php require_once __DIR__ . '/includes/breadcrumb.php'; renderBreadcrumb([['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'], ['label' => 'Maintenance', 'href' => 'sectioning.php', 'icon' => 'bi bi-tools'], ['label' => 'Sectioning', 'icon' => 'bi bi-pin-map']]); ?>
                    <div class="ay-card">
                        <div class="ay-card-header">
                            <div>
                                <p class="ay-card-title">Section List</p>
                                <p class="ay-card-subtitle">
                                    Filter sections, open the masterlist page, or view the full class record in a modal.
                                </p>
                            </div>
                            <div class="ay-toolbar">
                                <select class="form-select form-select-sm" id="gradeLevelFilter" style="min-width:180px; border-radius:10px;">
                                    <option value="">All Grade Levels</option>
                                    <?php foreach ($gradeLevels as $gl): ?>
                                        <option value="<?= h($gl['id']) ?>"><?= h($gl['grade_level_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="input-group input-group-sm" style="min-width:220px;">
                                    <span class="input-group-text">
                                        <i class="bi bi-search"></i>
                                    </span>
                                    <input class="form-control" type="search" id="searchInput" placeholder="Search section...">
                                </div>
                            </div>
                        </div>

                        <div class="ay-card-body">
                            
                            <div class="d-none d-md-block ay-table-wrap">
                                <table class="ay-table section-table" id="sectionTable">
                                    <colgroup>
                                        <col class="col-row">
                                        <col class="col-grade">
                                        <col class="col-section">
                                        <col class="col-adviser">
                                        <col class="col-students">
                                        <col class="col-status">
                                        <col class="col-actions">
                                    </colgroup>
                                    <thead>
                                        <tr>
                                            <th class="ay-center">#</th>
                                            <th class="ay-left">Grade Level</th>
                                            <th class="ay-left">Section Name</th>
                                            <th class="ay-left">Adviser</th>
                                            <th class="ay-center">Total Students</th>
                                            <th class="ay-center">Status</th>
                                            <th class="ay-center">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="sectionTableBody">
                                        <tr>
                                            <td colspan="7">
                                                <div class="ay-empty">
                                                    <i class="bi bi-hourglass-split"></i>
                                                    <p>Loading sections...</p>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            
                            <div class="d-block d-md-none p-3" id="sectionCardView"></div>
                        </div>

                        <div class="ay-card-footer">
                            <ul class="ay-pagination" id="pagination"></ul>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <?php require_once("includes/footer.php"); ?>
    </div>

    
    <div class="modal fade section-view-modal" id="sectionViewModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="false">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title mb-1"><i class="bi bi-eye-fill me-2"></i>Section View</h5>
                        <div class="small opacity-75" id="modalSectionSubtitle">Loading section details...</div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p class="sv-school-name">ST. TERESA SCHOOL OF NOVALICHES</p>
                    <p class="sv-subhead">Zabarte Subd., Novaliches, Q.C.</p>
                    <div class="sv-section-bar" id="svSectionBar">-</div>
                    <p class="sv-semester-line" id="svSchoolYearLine">School Year -</p>
                    <div class="sv-summary" id="svSummary"></div>
                    <div class="sv-block-title">Class Schedule</div>
                    <div class="sv-table-wrap" id="scheduleWrap"></div>
                    <div class="sv-block-title">Class List</div>
                    <div id="studentListsWrap"></div>
                </div>
            </div>
        </div>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./js/adminlte.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>

    <script>
        
        const sectionViewModal = new bootstrap.Modal(document.getElementById('sectionViewModal'));
        let allSections = [];
        let filteredSections = [];
        let currentPage = 1;
        const rowsPerPage = 5;

        
        function esc(str) {
            return (str ?? '').toString()
                .replaceAll('&', '&amp;')
                .replaceAll('<', '&lt;')
                .replaceAll('>', '&gt;')
                .replaceAll('"', '&quot;')
                .replaceAll("'", '&#039;');
        }

        function showAlert(message, type = 'success') {
            const config = {
                success: { title: 'Success', color: 'blue', icon: 'bi bi-check-circle-fill' },
                danger:  { title: 'Error',   color: 'red',  icon: 'bi bi-exclamation-octagon-fill' },
                warning: { title: 'Warning', color: 'yellow', icon: 'bi bi-exclamation-triangle-fill' },
                info:    { title: 'Info',    color: 'blue', icon: 'bi bi-info-circle-fill' }
            };
            const selected = config[type] || config.success;
            iziToast.show({
                title: selected.title,
                message: message,
                color: selected.color,
                icon: selected.icon,
                iconColor: '#fff',
                theme: 'light',
                position: 'topRight',
                timeout: 4000,
                progressBar: true,
                close: true,
                pauseOnHover: true,
                drag: true,
                transitionIn: 'fadeInDown',
                transitionOut: 'fadeOutUp',
                maxWidth: 420
            });
        }

        async function fetchJson(url, options = {}) {
            const res = await fetch(url, options);
            const text = await res.text();
            let json;
            try {
                json = JSON.parse(text);
            } catch (e) {
                console.error('Invalid JSON from:', url, text);
                throw new Error('Invalid server response');
            }
            if (!res.ok || json.success === false) {
                throw new Error(json.error || ('HTTP ' + res.status));
            }
            return json;
        }

        
        async function loadSections() {
            try {
                const search = document.getElementById('searchInput').value.trim();
                const gradeLevelId = document.getElementById('gradeLevelFilter').value;
                let url = `api/sectioning/sections.php?s=${encodeURIComponent(search)}`;
                if (gradeLevelId) {
                    url += `&grade_level_id=${encodeURIComponent(gradeLevelId)}`;
                }
                const data = await fetchJson(url);
                allSections = data.sections || [];
                filteredSections = [...allSections];
                currentPage = 1;
                renderPage();
            } catch (error) {
                console.error(error);
                showAlert(error.message || 'Failed to load sections.', 'danger');
                document.getElementById('sectionTableBody').innerHTML = `
                    <tr><td colspan="7">
                        <div class="ay-empty">
                            <i class="bi bi-exclamation-circle"></i>
                            <p>Failed to load sections.</p>
                        </div>
                    </td></tr>
                `;
                document.getElementById('sectionCardView').innerHTML = `
                    <div class="ay-empty">
                        <i class="bi bi-exclamation-circle"></i>
                        <p>Failed to load sections.</p>
                    </div>
                `;
                document.getElementById('pagination').innerHTML = '';
            }
        }

        function renderPage() {
            const totalPages = Math.max(1, Math.ceil(filteredSections.length / rowsPerPage));
            if (currentPage > totalPages) currentPage = totalPages;
            if (currentPage < 1) currentPage = 1;

            const start = (currentPage - 1) * rowsPerPage;
            const pageRows = filteredSections.slice(start, start + rowsPerPage);
            renderTable(pageRows, start);
            renderCards(pageRows, start);
            renderPagination(totalPages);
        }

        function renderTable(list, startIndex) {
            const tableBody = document.getElementById('sectionTableBody');
            if (!list.length) {
                tableBody.innerHTML = `
                    <tr><td colspan="7">
                        <div class="ay-empty">
                            <i class="bi bi-folder2-open"></i>
                            <p>No sections found.</p>
                        </div>
                    </td></tr>
                `;
                return;
            }

            tableBody.innerHTML = list.map((s, i) => {
                const isActive = String(s.is_active) === '1';
                return `
                    <tr>
                        <td class="ay-center"><span class="row-num">${startIndex + i + 1}</span></td>
                        <td class="ay-left">${esc(s.grade_level_name || '-')}</td>
                        <td class="ay-left"><span class="year-label">${esc(s.section_name || '-')}</span></td>
                        <td class="ay-left">${esc(s.adviser_name || 'No adviser assigned')}</td>
                        <td class="ay-center">${esc(s.total_students ?? 0)}</td>
                        <td class="ay-center">
                            ${isActive
                                ? '<span class="ay-badge ay-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>'
                                : '<span class="ay-badge ay-badge-inactive">Inactive</span>'
                            }
                        </td>
                        <td class="ay-center">
                            <div class="d-flex justify-content-center gap-2 flex-wrap">
                                <a class="btn-ay btn-ay-primary" href="sectioning_manage.php?section_id=${encodeURIComponent(s.id)}">
                                    <i class="bi bi-people-fill"></i> Manage
                                </a>
                                <button class="btn-ay btn-ay-secondary" type="button" onclick="openSectionViewModal(${Number(s.id)})">
                                    <i class="bi bi-eye"></i> View
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            }).join('');
        }

        function renderCards(list, startIndex) {
            const cardView = document.getElementById('sectionCardView');
            if (!list.length) {
                cardView.innerHTML = `
                    <div class="ay-empty">
                        <i class="bi bi-folder2-open"></i>
                        <p>No sections found.</p>
                    </div>
                `;
                return;
            }

            cardView.innerHTML = list.map((s, i) => {
                const isActive = String(s.is_active) === '1';
                return `
                    <div class="ay-mobile-card">
                        <div class="ay-mobile-card-header">
                            <span class="ay-mobile-card-title">${startIndex + i + 1}. ${esc(s.section_name || '-')}</span>
                            ${isActive
                                ? '<span class="ay-badge ay-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>'
                                : '<span class="ay-badge ay-badge-inactive">Inactive</span>'
                            }
                        </div>
                        <div class="ay-mobile-card-body">
                            <div class="ay-mobile-row">
                                <span class="ay-mobile-label">Grade Level</span>
                                <span>${esc(s.grade_level_name || '-')}</span>
                            </div>
                            <div class="ay-mobile-row">
                                <span class="ay-mobile-label">Adviser</span>
                                <span>${esc(s.adviser_name || 'No adviser assigned')}</span>
                            </div>
                            <div class="ay-mobile-row">
                                <span class="ay-mobile-label">Total Students</span>
                                <span>${esc(s.total_students ?? 0)}</span>
                            </div>
                        </div>
                        <div class="ay-mobile-actions">
                            <a class="btn-ay btn-ay-primary" href="sectioning_manage.php?section_id=${encodeURIComponent(s.id)}">
                                <i class="bi bi-people-fill"></i> Manage
                            </a>
                            <button class="btn-ay btn-ay-secondary" type="button" onclick="openSectionViewModal(${Number(s.id)})">
                                <i class="bi bi-eye"></i> View
                            </button>
                        </div>
                    </div>
                `;
            }).join('');
        }

        
        function renderPagination(totalPages) {
            const pagination = document.getElementById('pagination');
            if (filteredSections.length === 0 || totalPages <= 1) {
                pagination.innerHTML = '';
                return;
            }

            let html = '';

            
            const prevDisabled = currentPage <= 1 ? 'disabled' : '';
            html += `
                <li class="ay-page-item ${prevDisabled}">
                    <a class="ay-page-link" href="#" onclick="goToPage(${currentPage - 1}); return false;">Previous</a>
                </li>
            `;

            
            for (let n = 1; n <= totalPages; n++) {
                html += `
                    <li class="ay-page-item ${n === currentPage ? 'active' : ''}">
                        <a class="ay-page-link" href="#" onclick="goToPage(${n}); return false;">${n}</a>
                    </li>
                `;
            }

            
            const nextDisabled = currentPage >= totalPages ? 'disabled' : '';
            html += `
                <li class="ay-page-item ${nextDisabled}">
                    <a class="ay-page-link" href="#" onclick="goToPage(${currentPage + 1}); return false;">Next</a>
                </li>
            `;

            pagination.innerHTML = html;
        }

        function goToPage(page) {
            const totalPages = Math.max(1, Math.ceil(filteredSections.length / rowsPerPage));
            if (page < 1 || page > totalPages) return;
            if (page === currentPage) return;
            currentPage = page;
            renderPage();
        }

        
        function dayLabel(d) {
            const map = {
                Monday: 'Mon', Tuesday: 'Tue', Wednesday: 'Wed',
                Thursday: 'Thu', Friday: 'Fri', Saturday: 'Sat'
            };
            return map[d] || d || '-';
        }

        function formatTimeRange(start, end) {
            const format = value => {
                if (!value) return '-';
                const d = new Date(`1970-01-01T${value}`);
                return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }).toLowerCase();
            };
            return `${format(start)} - ${format(end)}`;
        }

        function renderSectionView(data) {
            const section = data.section || {};
            const stats = data.stats || {};
            const maleStudents = data.male_students_list || [];
            const femaleStudents = data.female_students_list || [];
            const unknownStudents = data.unknown_students_list || [];
            const schedules = data.schedules || [];

            document.getElementById('modalSectionSubtitle').textContent =
                `${section.grade_level_name || '-'} • ${section.section_name || '-'} • S.Y. ${section.school_year || 'Not set'}`;
            document.getElementById('svSectionBar').textContent = section.section_name || '-';
            document.getElementById('svSchoolYearLine').textContent = `School Year ${section.school_year || 'Not set'}`;
            document.getElementById('svSummary').innerHTML = `
                <span class="male-count">Male: ${esc(stats.male_students || 0)}</span>
                <span class="female-count">Female: ${esc(stats.female_students || 0)}</span>
                ${Number(stats.unspecified_students || 0) > 0
                    ? `<span class="total-count">Unspecified: ${esc(stats.unspecified_students || 0)}</span>`
                    : ''
                }
                <span class="total-count">Total: ${esc(stats.total_students || 0)}</span>
            `;

            
            document.getElementById('scheduleWrap').innerHTML = `
                <table class="sv-table">
                    <thead>
                        <tr class="sv-year-row">
                            <td colspan="6">${esc(section.grade_level_name || '')} - ${esc(section.section_name || '')}</td>
                        </tr>
                        <tr>
                            <th style="width:12%;">Code</th>
                            <th style="width:28%;">Course Description</th>
                            <th style="width:10%;">Day/s</th>
                            <th style="width:20%;">Time</th>
                            <th style="width:10%;">Room</th>
                            <th style="width:20%;">Faculty</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${!schedules.length
                            ? '<tr><td colspan="6" class="sv-center">No schedule found</td></tr>'
                            : schedules.map(r => `
                                <tr>
                                    <td class="sv-center">${esc(r.subject_code || '')}</td>
                                    <td>${esc(r.subject_name || '')}</td>
                                    <td class="sv-center">${esc(dayLabel(r.day_of_week))}</td>
                                    <td class="sv-center">${esc(formatTimeRange(r.time_start, r.time_end))}</td>
                                    <td class="sv-center">${esc(r.room || '')}</td>
                                    <td>${esc(r.teacher_name || '')}</td>
                                </tr>
                            `).join('')
                        }
                    </tbody>
                </table>
            `;

            
            const renderStudentColumn = (title, count, list, emptyText) => `
                <div class="gender-column">
                    <div class="gender-header">${title} (${count})</div>
                    ${list.length
                        ? `<div class="student-list">
                            ${list.map((r, i) => `
                                <div class="student-item">
                                    <span class="student-number">${i + 1}.</span>
                                    <span class="student-id">${esc(r.student_identifier || '')}</span>
                                    <span class="student-name">${esc(r.full_name || '')}</span>
                                </div>
                            `).join('')}
                        </div>`
                        : `<div class="sv-empty-inline">${emptyText}</div>`
                    }
                </div>
            `;

            let html = `
                <div class="students-container">
                    ${renderStudentColumn('MALE', maleStudents.length, maleStudents, 'No male students')}
                    ${renderStudentColumn('FEMALE', femaleStudents.length, femaleStudents, 'No female students')}
                </div>
            `;
            if (unknownStudents.length) {
                html += `
                    <div class="unknown-wrap">
                        <div class="gender-header">UNSPECIFIED GENDER (${unknownStudents.length})</div>
                        <div class="student-list">
                            ${unknownStudents.map((r, i) => `
                                <div class="student-item">
                                    <span class="student-number">${i + 1}.</span>
                                    <span class="student-id">${esc(r.student_identifier || '')}</span>
                                    <span class="student-name">${esc(r.full_name || '')}</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                `;
            }
            if ((stats.total_students || 0) === 0) {
                html = `<div class="sv-empty-inline">No students enrolled in this section.</div>`;
            }
            document.getElementById('studentListsWrap').innerHTML = html;
        }

        async function openSectionViewModal(sectionId) {
            try {
                document.getElementById('modalSectionSubtitle').textContent = 'Loading section details...';
                document.getElementById('svSectionBar').textContent = 'Loading...';
                document.getElementById('svSchoolYearLine').textContent = 'School Year -';
                document.getElementById('svSummary').innerHTML = '';
                document.getElementById('scheduleWrap').innerHTML = `<div class="ay-empty"><i class="bi bi-hourglass-split"></i><p>Loading schedule...</p></div>`;
                document.getElementById('studentListsWrap').innerHTML = `<div class="ay-empty"><i class="bi bi-hourglass-split"></i><p>Loading students...</p></div>`;
                sectionViewModal.show();

                const result = await fetchJson(`sectioning.php?ajax=view_section&id=${encodeURIComponent(sectionId)}`);
                renderSectionView(result.data || {});
            } catch (error) {
                console.error(error);
                sectionViewModal.hide();
                showAlert('Unable to load section view: ' + error.message, 'danger');
            }
        }

        
        document.getElementById('searchInput').addEventListener('input', () => {
            clearTimeout(window.searchTimeout);
            window.searchTimeout = setTimeout(loadSections, 300);
        });
        document.getElementById('gradeLevelFilter').addEventListener('change', loadSections);

        
        loadSections();
    </script>
</body>
</html>