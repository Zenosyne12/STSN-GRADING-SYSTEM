<?php
require_once 'includes/auth.php';
requireAdmin();
require_once 'api/shared/db_connect.php';
?>
<!doctype html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
    <meta charset="utf-8">
    <title>STSN Grading System | Section Directory</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="./css/academic_year.css">
    <style>
        body {
            background: #f3f7fd;
        }

        .ay-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }

        .ay-page-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 0.2rem;
            letter-spacing: 0.01em;
        }

        .ay-page-header p {
            margin: 0;
            font-size: 0.88rem;
            opacity: 0.85;
        }

        .ay-active-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            background: rgba(255, 255, 255, 0.15);
            border: 1.5px solid rgba(255, 255, 255, 0.3);
            border-radius: 999px;
            padding: 0.45rem 1rem;
            font-size: 0.88rem;
            font-weight: 700;
            color: #fff;
            white-space: nowrap;
        }

        .ay-card {
            background: #fff;
            border: 1px solid #dce8f8;
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18, 72, 168, .06);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }

        .ay-card-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid #e8f0fb;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: .75rem;
            background: #fff;
        }

        .ay-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: #132f62;
            margin: 0 0 .15rem;
        }

        .ay-card-subtitle {
            font-size: .8rem;
            color: #7a93b8;
            margin: 0;
        }

        .ay-card-footer {
            padding: .75rem 1.2rem;
            border-top: 1px solid #e8f0fb;
            background: #fafcff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 0.75rem;
            flex-wrap: wrap;
        }

        .ay-footer-note {
            font-size: 0.82rem;
            color: #7a93b8;
        }

        .ay-table {
            width: 100%;
            border-collapse: collapse;
        }

        .ay-table thead th {
            background: #f4f8ff;
            color: #3b5e96;
            font-size: .75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .06em;
            padding: .85rem 1.2rem;
            border-bottom: 1.5px solid #dce8f8;
            white-space: nowrap;
        }

        .ay-table tbody tr:not(:last-child) td {
            border-bottom: 1px solid #f0f5fc;
        }

        .ay-table tbody tr:hover td {
            background: #f7fbff;
        }

        .ay-table tbody td {
            padding: .9rem 1.2rem;
            font-size: .93rem;
            color: #213a5e;
            vertical-align: middle;
        }

        .ay-badge {
            display: inline-flex;
            align-items: center;
            gap: .3rem;
            padding: .32rem .75rem;
            border-radius: 999px;
            font-size: .78rem;
            font-weight: 700;
            letter-spacing: .03em;
        }

        .ay-badge-active {
            background: #e6f0ff;
            color: #1248a8;
            border: 1.5px solid #b8d0fa;
        }

        .ay-badge-inactive {
            background: #f3f5f8;
            color: #7a8ea8;
            border: 1.5px solid #dde4ee;
        }

        .ay-badge-strand {
            background: linear-gradient(130deg, #e8f4ff, #d4e8ff);
            color: #1a5fd1;
            border: 1.5px solid #a8c8f5;
        }

        .btn-ay {
            font-weight: 600;
            font-size: .82rem;
            border-radius: 8px;
            padding: .42rem .9rem;
            cursor: pointer;
            transition: all .14s;
            border: 1.5px solid transparent;
            line-height: 1.4;
        }

        .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            box-shadow: 0 2px 8px rgba(26, 110, 245, .2);
        }

        .btn-ay-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
        }

        .btn-ay-outline {
            background: #fff;
            color: #1a6ef5;
            border-color: #dce8f8;
        }

        .btn-ay-outline:hover {
            background: #eef4ff;
            border-color: #9cc2fc;
        }

        .btn-ay-activate {
            background: #1a6ef5;
            color: #fff;
            border-color: #1a6ef5;
        }

        .btn-ay-activate:hover {
            background: #1560d8;
            color: #fff;
        }

        /* ★★★ Deactivate — dark navy (matches academic_year.php) ★★★ */
        .btn-ay-deactivate {
            background: #1e2a3d;
            color: #8ab4f8;
            border-color: #2d4366;
        }

        .btn-ay-deactivate i {
            color: #8ab4f8;
        }

        .btn-ay-deactivate:hover {
            background: #2a3a54;
            border-color: #3d5a80;
            color: #8ab4f8;
        }

        .btn-ay-deactivate:hover i {
            color: #8ab4f8;
        }

        .btn-ay-warning {
            background: #fff8e6;
            color: #8a5c00;
            border-color: #f5d98a;
        }

        .btn-ay-warning:hover {
            background: #fff0c0;
            border-color: #f0c832;
        }

        .btn-ay-sm {
            padding: .28rem .65rem;
            font-size: .78rem;
        }

        .ay-search {
            border: 1.5px solid #c8daf8;
            border-radius: 10px;
            padding: .42rem .85rem;
            font-size: .88rem;
            color: #213a5e;
            min-width: 220px;
        }

        .ay-search:focus {
            border-color: #1a6ef5;
            outline: none;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, .1);
        }

        .ay-pagination {
            display: flex;
            gap: .3rem;
            list-style: none;
            margin: 0;
            padding: 0;
            justify-content: flex-end;
            align-items: center;
            flex-wrap: wrap;
        }

        .ay-pagination .ay-page-item .ay-page-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
            border-radius: 7px;
            font-size: .83rem;
            font-weight: 600;
            cursor: pointer;
            border: 1.5px solid #dce8f8;
            color: #1a6ef5;
            background: #fff;
            transition: all .13s;
            padding: 0 .65rem;
        }

        .ay-pagination .ay-page-item .ay-page-link:hover {
            background: #eef4ff;
            border-color: #9cc2fc;
        }

        .ay-pagination .ay-page-item.active .ay-page-link {
            background: #1a6ef5;
            border-color: #1a6ef5;
            color: #fff;
        }

        .ay-pagination .ay-page-item.disabled .ay-page-link {
            background: #f8fbff;
            border-color: #e2ebf8;
            color: #9ab0c8;
            cursor: not-allowed;
            pointer-events: none;
        }

        .ay-empty {
            text-align: center;
            padding: 2.5rem 1.5rem;
            color: #9ab0c8;
        }

        .ay-empty i {
            font-size: 2.2rem;
            display: block;
            margin-bottom: .6rem;
            opacity: .5;
        }

        .ay-empty p {
            margin: 0;
            font-size: .95rem;
        }

        .ay-modal .modal-content {
            border: 0;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(18, 72, 168, .16);
        }

        .ay-modal .modal-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-bottom: 0;
            border-radius: 16px 16px 0 0;
            padding: 1.15rem 1.3rem;
        }

        .ay-modal .modal-title {
            font-size: 1rem;
            font-weight: 700;
            color: #fff;
        }

        .ay-modal .modal-header .btn-close {
            filter: brightness(0) invert(1);
            opacity: .9;
        }

        .ay-modal .modal-header .btn-close:hover {
            opacity: 1;
        }

        .ay-modal .modal-body {
            padding: 1.3rem;
        }

        .ay-modal .modal-footer {
            border-top: 1px solid #e8f0fb;
            padding: .9rem 1.3rem;
            background: #fafcff;
            border-radius: 0 0 16px 16px;
        }

        .ay-modal .form-label {
            font-size: .85rem;
            font-weight: 700;
            color: #3b5e96;
            margin-bottom: .4rem;
        }

        .ay-modal .form-control,
        .ay-modal .form-select {
            border-radius: 10px;
            border: 1.5px solid #c8daf8;
            min-height: 42px;
            font-size: .9rem;
            color: #213a5e;
            padding: .45rem .85rem;
        }

        .ay-modal .form-control:focus,
        .ay-modal .form-select:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, .12);
        }

        .ay-mobile-card {
            background: #fff;
            border: 1.5px solid #dce8f8;
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 1px 6px rgba(18, 72, 168, .05);
        }

        .ay-mobile-card+.ay-mobile-card {
            margin-top: .75rem;
        }

        .ay-mobile-card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: .85rem 1rem;
            border-bottom: 1px solid #edf3fc;
            background: #f9fbff;
        }

        .ay-mobile-card-title {
            font-weight: 700;
            color: #132f62;
            font-size: .95rem;
        }

        .ay-mobile-card-body {
            padding: .85rem 1rem;
        }

        .ay-mobile-card-body .grade-label {
            font-size: .82rem;
            color: #6b84a2;
            margin-bottom: .65rem;
        }

        @media (max-width: 767.98px) {
            .ay-page-header {
                padding: 1.1rem 1.2rem;
                border-radius: 14px;
            }

            .ay-card-footer {
                justify-content: center;
            }

            .ay-pagination {
                justify-content: center;
            }
        }

        /* ============================================================
           DARK MODE SUPPORT
           ============================================================ */

        [data-bs-theme="dark"],
        [data-theme="dark"],
        html.dark,
        html.dark-mode,
        body.dark-mode,
        body.dark {
            color-scheme: dark;
        }

        [data-bs-theme="dark"] body,
        [data-theme="dark"] body,
        html.dark body,
        html.dark-mode body,
        body.dark,
        body.dark-mode {
            background: #0e1622 !important;
            color: #c8d4e0;
        }

        /* Page header shadow */
        [data-bs-theme="dark"] .ay-page-header,
        [data-theme="dark"] .ay-page-header,
        html.dark .ay-page-header,
        html.dark-mode .ay-page-header,
        body.dark .ay-page-header,
        body.dark-mode .ay-page-header {
            box-shadow: 0 8px 24px rgba(0, 0, 0, .55);
        }

        /* Cards */
        [data-bs-theme="dark"] .ay-card,
        [data-theme="dark"] .ay-card,
        html.dark .ay-card,
        html.dark-mode .ay-card,
        body.dark .ay-card,
        body.dark-mode .ay-card {
            background: #1a2230 !important;
            border-color: #2a3444 !important;
            box-shadow: 0 2px 12px rgba(0, 0, 0, .45) !important;
        }

        [data-bs-theme="dark"] .ay-card-header,
        [data-theme="dark"] .ay-card-header,
        html.dark .ay-card-header,
        html.dark-mode .ay-card-header,
        body.dark .ay-card-header,
        body.dark-mode .ay-card-header {
            background: #1a2230 !important;
            border-bottom-color: #2a3444 !important;
        }

        [data-bs-theme="dark"] .ay-card-title,
        [data-theme="dark"] .ay-card-title,
        html.dark .ay-card-title,
        html.dark-mode .ay-card-title,
        body.dark .ay-card-title,
        body.dark-mode .ay-card-title {
            color: #e8eef7 !important;
        }

        [data-bs-theme="dark"] .ay-card-subtitle,
        [data-theme="dark"] .ay-card-subtitle,
        html.dark .ay-card-subtitle,
        html.dark-mode .ay-card-subtitle,
        body.dark .ay-card-subtitle,
        body.dark-mode .ay-card-subtitle {
            color: #94a7bf !important;
        }

        [data-bs-theme="dark"] .ay-card-footer,
        [data-theme="dark"] .ay-card-footer,
        html.dark .ay-card-footer,
        html.dark-mode .ay-card-footer,
        body.dark .ay-card-footer,
        body.dark-mode .ay-card-footer {
            background: #1c2634 !important;
            border-top-color: #2a3444 !important;
        }

        [data-bs-theme="dark"] .ay-footer-note,
        [data-theme="dark"] .ay-footer-note,
        html.dark .ay-footer-note,
        html.dark-mode .ay-footer-note,
        body.dark .ay-footer-note,
        body.dark-mode .ay-footer-note {
            color: #94a7bf !important;
        }

        /* Search input */
        [data-bs-theme="dark"] .ay-search,
        [data-theme="dark"] .ay-search,
        html.dark .ay-search,
        html.dark-mode .ay-search,
        body.dark .ay-search,
        body.dark-mode .ay-search {
            background: #232d3d !important;
            border-color: #3a4757 !important;
            color: #e8eef7 !important;
        }

        [data-bs-theme="dark"] .ay-search::placeholder,
        [data-theme="dark"] .ay-search::placeholder,
        html.dark .ay-search::placeholder,
        html.dark-mode .ay-search::placeholder,
        body.dark .ay-search::placeholder,
        body.dark-mode .ay-search::placeholder {
            color: #7a8fa5 !important;
        }

        /* TABLE */
        [data-bs-theme="dark"] .ay-table,
        [data-theme="dark"] .ay-table,
        html.dark .ay-table,
        html.dark-mode .ay-table,
        body.dark .ay-table,
        body.dark-mode .ay-table {
            background: #1a2230 !important;
        }

        [data-bs-theme="dark"] .ay-table thead th,
        [data-theme="dark"] .ay-table thead th,
        html.dark .ay-table thead th,
        html.dark-mode .ay-table thead th,
        body.dark .ay-table thead th,
        body.dark-mode .ay-table thead th {
            background: #232d3d !important;
            color: #a9b8cd !important;
            border-bottom-color: #2a3444 !important;
        }

        [data-bs-theme="dark"] .ay-table tbody td,
        [data-theme="dark"] .ay-table tbody td,
        html.dark .ay-table tbody td,
        html.dark-mode .ay-table tbody td,
        body.dark .ay-table tbody td,
        body.dark-mode .ay-table tbody td {
            background: #1a2230 !important;
            color: #c8d4e0 !important;
            border-bottom-color: #232d3d !important;
        }

        [data-bs-theme="dark"] .ay-table tbody td[style],
        [data-theme="dark"] .ay-table tbody td[style],
        html.dark .ay-table tbody td[style],
        html.dark-mode .ay-table tbody td[style],
        body.dark .ay-table tbody td[style],
        body.dark-mode .ay-table tbody td[style] {
            color: #c8d4e0 !important;
        }

        [data-bs-theme="dark"] .ay-table tbody td strong,
        [data-theme="dark"] .ay-table tbody td strong,
        html.dark .ay-table tbody td strong,
        html.dark-mode .ay-table tbody td strong,
        body.dark .ay-table tbody td strong,
        body.dark-mode .ay-table tbody td strong {
            color: #e8eef7 !important;
        }

        [data-bs-theme="dark"] .ay-table tbody td strong[style],
        [data-theme="dark"] .ay-table tbody td strong[style],
        html.dark .ay-table tbody td strong[style],
        html.dark-mode .ay-table tbody td strong[style],
        body.dark .ay-table tbody td strong[style],
        body.dark-mode .ay-table tbody td strong[style] {
            color: #e8eef7 !important;
        }

        [data-bs-theme="dark"] .ay-table tbody tr:hover td,
        [data-theme="dark"] .ay-table tbody tr:hover td,
        html.dark .ay-table tbody tr:hover td,
        html.dark-mode .ay-table tbody tr:hover td,
        body.dark .ay-table tbody tr:hover td,
        body.dark-mode .ay-table tbody tr:hover td {
            background: #232d3d !important;
        }

        /* Badges */
        [data-bs-theme="dark"] .ay-badge-active,
        [data-theme="dark"] .ay-badge-active,
        html.dark .ay-badge-active,
        html.dark-mode .ay-badge-active,
        body.dark .ay-badge-active,
        body.dark-mode .ay-badge-active {
            background: #17351f !important;
            color: #6ee7a0 !important;
            border-color: #2b5c38 !important;
        }

        [data-bs-theme="dark"] .ay-badge-inactive,
        [data-theme="dark"] .ay-badge-inactive,
        html.dark .ay-badge-inactive,
        html.dark-mode .ay-badge-inactive,
        body.dark .ay-badge-inactive,
        body.dark-mode .ay-badge-inactive {
            background: #232d3d !important;
            color: #a9b8cd !important;
            border-color: #3a4757 !important;
        }

        [data-bs-theme="dark"] .ay-badge-strand,
        [data-theme="dark"] .ay-badge-strand,
        html.dark .ay-badge-strand,
        html.dark-mode .ay-badge-strand,
        body.dark .ay-badge-strand,
        body.dark-mode .ay-badge-strand {
            background: linear-gradient(130deg, #22304a, #2a3c5c) !important;
            color: #7ab7ff !important;
            border-color: #3a5075 !important;
        }

        /* Buttons */
        [data-bs-theme="dark"] .btn-ay-outline,
        [data-theme="dark"] .btn-ay-outline,
        html.dark .btn-ay-outline,
        html.dark-mode .btn-ay-outline,
        body.dark .btn-ay-outline,
        body.dark-mode .btn-ay-outline {
            background: #232d3d !important;
            color: #7ab7ff !important;
            border-color: #3a4757 !important;
        }

        [data-bs-theme="dark"] .btn-ay-outline:hover,
        [data-theme="dark"] .btn-ay-outline:hover,
        html.dark .btn-ay-outline:hover,
        html.dark-mode .btn-ay-outline:hover,
        body.dark .btn-ay-outline:hover,
        body.dark-mode .btn-ay-outline:hover {
            background: #2a3444 !important;
            border-color: #4a5a6e !important;
            color: #a5ccff !important;
        }

        /* ★★★ Deactivate — dark navy (matches academic_year.php) ★★★ */
        [data-bs-theme="dark"] .btn-ay-deactivate,
        [data-theme="dark"] .btn-ay-deactivate,
        html.dark .btn-ay-deactivate,
        html.dark-mode .btn-ay-deactivate,
        body.dark .btn-ay-deactivate,
        body.dark-mode .btn-ay-deactivate {
            background: #1e2a3d !important;
            color: #8ab4f8 !important;
            border-color: #2d4366 !important;
        }

        [data-bs-theme="dark"] .btn-ay-deactivate i,
        [data-theme="dark"] .btn-ay-deactivate i,
        html.dark .btn-ay-deactivate i,
        html.dark-mode .btn-ay-deactivate i,
        body.dark .btn-ay-deactivate i,
        body.dark-mode .btn-ay-deactivate i {
            color: #8ab4f8 !important;
        }

        [data-bs-theme="dark"] .btn-ay-deactivate:hover,
        [data-theme="dark"] .btn-ay-deactivate:hover,
        html.dark .btn-ay-deactivate:hover,
        html.dark-mode .btn-ay-deactivate:hover,
        body.dark .btn-ay-deactivate:hover,
        body.dark-mode .btn-ay-deactivate:hover {
            background: #2a3a54 !important;
            border-color: #3d5a80 !important;
            color: #8ab4f8 !important;
        }

        [data-bs-theme="dark"] .btn-ay-deactivate:hover i,
        [data-theme="dark"] .btn-ay-deactivate:hover i,
        html.dark .btn-ay-deactivate:hover i,
        html.dark-mode .btn-ay-deactivate:hover i,
        body.dark .btn-ay-deactivate:hover i,
        body.dark-mode .btn-ay-deactivate:hover i {
            color: #8ab4f8 !important;
        }

        [data-bs-theme="dark"] .btn-ay-warning,
        [data-theme="dark"] .btn-ay-warning,
        html.dark .btn-ay-warning,
        html.dark-mode .btn-ay-warning,
        body.dark .btn-ay-warning,
        body.dark-mode .btn-ay-warning {
            background: #3a2f14 !important;
            color: #ffcc66 !important;
            border-color: #5c4820 !important;
        }

        [data-bs-theme="dark"] .btn-ay-warning:hover,
        [data-theme="dark"] .btn-ay-warning:hover,
        html.dark .btn-ay-warning:hover,
        html.dark-mode .btn-ay-warning:hover,
        body.dark .btn-ay-warning:hover,
        body.dark-mode .btn-ay-warning:hover {
            background: #4a3c1a !important;
            border-color: #6e5628 !important;
            color: #ffdd88 !important;
        }

        /* Pagination */
        [data-bs-theme="dark"] .ay-pagination .ay-page-item .ay-page-link,
        [data-theme="dark"] .ay-pagination .ay-page-item .ay-page-link,
        html.dark .ay-pagination .ay-page-item .ay-page-link,
        html.dark-mode .ay-pagination .ay-page-item .ay-page-link,
        body.dark .ay-pagination .ay-page-item .ay-page-link,
        body.dark-mode .ay-pagination .ay-page-item .ay-page-link {
            background: #232d3d !important;
            border-color: #3a4757 !important;
            color: #7ab7ff !important;
        }

        [data-bs-theme="dark"] .ay-pagination .ay-page-item .ay-page-link:hover,
        [data-theme="dark"] .ay-pagination .ay-page-item .ay-page-link:hover,
        html.dark .ay-pagination .ay-page-item .ay-page-link:hover,
        html.dark-mode .ay-pagination .ay-page-item .ay-page-link:hover,
        body.dark .ay-pagination .ay-page-item .ay-page-link:hover,
        body.dark-mode .ay-pagination .ay-page-item .ay-page-link:hover {
            background: #2a3444 !important;
            border-color: #4a5a6e !important;
        }

        [data-bs-theme="dark"] .ay-pagination .ay-page-item.active .ay-page-link,
        [data-theme="dark"] .ay-pagination .ay-page-item.active .ay-page-link,
        html.dark .ay-pagination .ay-page-item.active .ay-page-link,
        html.dark-mode .ay-pagination .ay-page-item.active .ay-page-link,
        body.dark .ay-pagination .ay-page-item.active .ay-page-link,
        body.dark-mode .ay-pagination .ay-page-item.active .ay-page-link {
            background: #1a6ef5 !important;
            border-color: #1a6ef5 !important;
            color: #fff !important;
        }

        [data-bs-theme="dark"] .ay-pagination .ay-page-item.disabled .ay-page-link,
        [data-theme="dark"] .ay-pagination .ay-page-item.disabled .ay-page-link,
        html.dark .ay-pagination .ay-page-item.disabled .ay-page-link,
        html.dark-mode .ay-pagination .ay-page-item.disabled .ay-page-link,
        body.dark .ay-pagination .ay-page-item.disabled .ay-page-link,
        body.dark-mode .ay-pagination .ay-page-item.disabled .ay-page-link {
            background: #1a2230 !important;
            border-color: #2a3444 !important;
            color: #5d6b7d !important;
        }

        /* Empty state */
        [data-bs-theme="dark"] .ay-empty,
        [data-theme="dark"] .ay-empty,
        html.dark .ay-empty,
        html.dark-mode .ay-empty,
        body.dark .ay-empty,
        body.dark-mode .ay-empty {
            color: #7a8fa5 !important;
        }

        /* Mobile cards */
        [data-bs-theme="dark"] .ay-mobile-card,
        [data-theme="dark"] .ay-mobile-card,
        html.dark .ay-mobile-card,
        html.dark-mode .ay-mobile-card,
        body.dark .ay-mobile-card,
        body.dark-mode .ay-mobile-card {
            background: #1a2230 !important;
            border-color: #2a3444 !important;
            box-shadow: 0 1px 6px rgba(0, 0, 0, .35) !important;
        }

        [data-bs-theme="dark"] .ay-mobile-card-header,
        [data-theme="dark"] .ay-mobile-card-header,
        html.dark .ay-mobile-card-header,
        html.dark-mode .ay-mobile-card-header,
        body.dark .ay-mobile-card-header,
        body.dark-mode .ay-mobile-card-header {
            background: #1c2634 !important;
            border-bottom-color: #2a3444 !important;
        }

        [data-bs-theme="dark"] .ay-mobile-card-title,
        [data-theme="dark"] .ay-mobile-card-title,
        html.dark .ay-mobile-card-title,
        html.dark-mode .ay-mobile-card-title,
        body.dark .ay-mobile-card-title,
        body.dark-mode .ay-mobile-card-title {
            color: #e8eef7 !important;
        }

        [data-bs-theme="dark"] .ay-mobile-card-body .grade-label,
        [data-theme="dark"] .ay-mobile-card-body .grade-label,
        html.dark .ay-mobile-card-body .grade-label,
        html.dark-mode .ay-mobile-card-body .grade-label,
        body.dark .ay-mobile-card-body .grade-label,
        body.dark-mode .ay-mobile-card-body .grade-label {
            color: #94a7bf !important;
        }

        /* ============================================================
           MODAL — DARK MODE
           ============================================================ */
        [data-bs-theme="dark"] .ay-modal .modal-content,
        [data-theme="dark"] .ay-modal .modal-content,
        html.dark .ay-modal .modal-content,
        html.dark-mode .ay-modal .modal-content,
        body.dark .ay-modal .modal-content,
        body.dark-mode .ay-modal .modal-content {
            background: #2D2D2D !important;
            border: 1px solid #3a3a3a !important;
            box-shadow: 0 8px 32px rgba(0, 0, 0, .75) !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-header,
        [data-theme="dark"] .ay-modal .modal-header,
        html.dark .ay-modal .modal-header,
        html.dark-mode .ay-modal .modal-header,
        body.dark .ay-modal .modal-header,
        body.dark-mode .ay-modal .modal-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%) !important;
            border-bottom: 0 !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-title,
        [data-theme="dark"] .ay-modal .modal-title,
        html.dark .ay-modal .modal-title,
        html.dark-mode .ay-modal .modal-title,
        body.dark .ay-modal .modal-title,
        body.dark-mode .ay-modal .modal-title {
            color: #ffffff !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-body,
        [data-theme="dark"] .ay-modal .modal-body,
        html.dark .ay-modal .modal-body,
        html.dark-mode .ay-modal .modal-body,
        body.dark .ay-modal .modal-body,
        body.dark-mode .ay-modal .modal-body {
            background: #2D2D2D !important;
            color: #e4e6e8 !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-footer,
        [data-theme="dark"] .ay-modal .modal-footer,
        html.dark .ay-modal .modal-footer,
        html.dark-mode .ay-modal .modal-footer,
        body.dark .ay-modal .modal-footer,
        body.dark-mode .ay-modal .modal-footer {
            background: #262626 !important;
            border-top: 1px solid #3a3a3a !important;
            border-radius: 0 0 16px 16px !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-label,
        [data-theme="dark"] .ay-modal .form-label,
        html.dark .ay-modal .form-label,
        html.dark-mode .ay-modal .form-label,
        body.dark .ay-modal .form-label,
        body.dark-mode .ay-modal .form-label {
            color: #e4e6e8 !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-control,
        [data-bs-theme="dark"] .ay-modal .form-select,
        [data-theme="dark"] .ay-modal .form-control,
        [data-theme="dark"] .ay-modal .form-select,
        html.dark .ay-modal .form-control,
        html.dark .ay-modal .form-select,
        html.dark-mode .ay-modal .form-control,
        html.dark-mode .ay-modal .form-select,
        body.dark .ay-modal .form-control,
        body.dark .ay-modal .form-select,
        body.dark-mode .ay-modal .form-control,
        body.dark-mode .ay-modal .form-select {
            background: #1f1f1f !important;
            border-color: #3a3a3a !important;
            color: #e4e6e8 !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-control::placeholder,
        [data-theme="dark"] .ay-modal .form-control::placeholder,
        html.dark .ay-modal .form-control::placeholder,
        html.dark-mode .ay-modal .form-control::placeholder,
        body.dark .ay-modal .form-control::placeholder,
        body.dark-mode .ay-modal .form-control::placeholder {
            color: #8b939a !important;
            opacity: 1 !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-select option,
        [data-theme="dark"] .ay-modal .form-select option,
        html.dark .ay-modal .form-select option,
        html.dark-mode .ay-modal .form-select option,
        body.dark .ay-modal .form-select option,
        body.dark-mode .ay-modal .form-select option {
            background: #1f1f1f !important;
            color: #e4e6e8 !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-control:focus,
        [data-bs-theme="dark"] .ay-modal .form-select:focus,
        [data-theme="dark"] .ay-modal .form-control:focus,
        [data-theme="dark"] .ay-modal .form-select:focus,
        html.dark .ay-modal .form-control:focus,
        html.dark .ay-modal .form-select:focus,
        html.dark-mode .ay-modal .form-control:focus,
        html.dark-mode .ay-modal .form-select:focus,
        body.dark .ay-modal .form-control:focus,
        body.dark .ay-modal .form-select:focus,
        body.dark-mode .ay-modal .form-control:focus,
        body.dark-mode .ay-modal .form-select:focus {
            background: #1f1f1f !important;
            border-color: #1a6ef5 !important;
            color: #ffffff !important;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.35) !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-text,
        [data-theme="dark"] .ay-modal .form-text,
        html.dark .ay-modal .form-text,
        html.dark-mode .ay-modal .form-text,
        body.dark .ay-modal .form-text,
        body.dark-mode .ay-modal .form-text {
            color: #adb5bd !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-text[style],
        [data-theme="dark"] .ay-modal .form-text[style],
        html.dark .ay-modal .form-text[style],
        html.dark-mode .ay-modal .form-text[style],
        body.dark .ay-modal .form-text[style],
        body.dark-mode .ay-modal .form-text[style] {
            color: #adb5bd !important;
        }

        [data-bs-theme="dark"] .ay-modal .text-danger,
        [data-theme="dark"] .ay-modal .text-danger,
        html.dark .ay-modal .text-danger,
        html.dark-mode .ay-modal .text-danger,
        body.dark .ay-modal .text-danger,
        body.dark-mode .ay-modal .text-danger {
            color: #ff6b81 !important;
        }

        [data-bs-theme="dark"] .ay-modal .btn-ay-outline,
        [data-theme="dark"] .ay-modal .btn-ay-outline,
        html.dark .ay-modal .btn-ay-outline,
        html.dark-mode .ay-modal .btn-ay-outline,
        body.dark .ay-modal .btn-ay-outline,
        body.dark-mode .ay-modal .btn-ay-outline {
            background: #3a3a3a !important;
            color: #e4e6e8 !important;
            border-color: #4a4a4a !important;
        }

        [data-bs-theme="dark"] .ay-modal .btn-ay-outline:hover,
        [data-theme="dark"] .ay-modal .btn-ay-outline:hover,
        html.dark .ay-modal .btn-ay-outline:hover,
        html.dark-mode .ay-modal .btn-ay-outline:hover,
        body.dark .ay-modal .btn-ay-outline:hover,
        body.dark-mode .ay-modal .btn-ay-outline:hover {
            background: #4a4a4a !important;
            border-color: #5a5a5a !important;
            color: #ffffff !important;
        }

        [data-bs-theme="dark"] .modal-backdrop,
        [data-theme="dark"] .modal-backdrop,
        html.dark .modal-backdrop,
        html.dark-mode .modal-backdrop,
        body.dark .modal-backdrop,
        body.dark-mode .modal-backdrop {
            background-color: #000 !important;
        }

        @media (prefers-color-scheme: dark) {
            html:not([data-bs-theme="light"]):not([data-theme="light"]):not(.light) body:not(.light) {
                background: #0e1622;
                color: #c8d4e0;
            }
        }
    /* (Deactivate button now uses academic_year.css → .btn-am .btn-am-deactivate) */

/* ============================================================
   Compact Track Badge — prevents overflow
   ============================================================ */
.track-badge {
    display: inline-block;
    padding: 0.28rem 0.75rem;
    border-radius: 999px;
    font-size: 0.75rem;
    font-weight: 600;
    line-height: 1.2;
    white-space: nowrap;
    letter-spacing: 0.02em;
    max-width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    vertical-align: middle;
}
.track-badge.track-academic {
    background: #E7F0FF;
    color: #1248a8;
    border: 1px solid #B8D0FA;
}
.track-badge.track-techpro {
    background: #FFF4E5;
    color: #9A6200;
    border: 1px solid #F6D28B;
}
.track-badge.track-none {
    background: transparent;
    color: #9ab0c8;
    border: none;
    font-weight: 400;
    padding: 0;
}
</style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <div class="app-wrapper">
        <?php require_once("includes/header.php"); ?>
        <?php require_once("includes/sidebar.php"); ?>

        <main class="app-main">
            <div class="app-content">
                <div class="container-fluid py-3">

                    <div class="page-header">
                        <div>
                            <h3><i class="bi bi-diagram-3 me-2"></i>Section Directory</h3>
                            <p>Review sections, open full section records, and manage class masterlists.</p>
                        </div>
                    </div>

                    <?php require_once __DIR__ . '/includes/breadcrumb.php';
                    renderBreadcrumb([['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'], ['label' => 'Maintenance', 'href' => 'section.php', 'icon' => 'bi bi-tools'], ['label' => 'Section', 'icon' => 'bi bi-diagram-3']]); ?>
                    <div class="ay-card">
                        <div class="ay-card-header">
                            <div>
                                <p class="ay-card-title">Section List</p>
                                <p class="ay-card-subtitle">Manage active and inactive sections per grade level.</p>
                            </div>
                            <div style="display:flex;gap:.5rem;align-items:center;flex-wrap:wrap;">
                                <input class="ay-search" type="search" id="searchInput" placeholder="Search sections…">
                                <button class="btn btn-ay btn-ay-primary" data-bs-toggle="modal"
                                    data-bs-target="#sectionModal">
                                    <i class="bi bi-plus-circle me-1"></i> New Section
                                </button>
                            </div>
                        </div>

                        <div class="d-none d-md-block">
                            <table class="ay-table" id="sectionTable">
                                <thead>
                                    <tr>
                                        <th style="width:56px;text-align:center;">#</th>
                                        <th>Grade Level</th>
                                        <th>Section Name</th>
                                        <th style="width:140px;text-align:center;">Track</th>
                                        <th style="width:120px;text-align:center;">Status</th>
                                        <th style="width:200px;text-align:center;">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="sectionTableBody">
                                    <tr>
                                        <td colspan="6">
                                            <div class="ay-empty">
                                                <span class="spinner-border spinner-border-sm me-1"></span> Loading…
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="d-block d-md-none p-3" id="cardView"></div>

                        <div class="ay-card-footer">
                            <div class="ay-footer-note" id="sectionCountText"></div>
                            <ul class="ay-pagination" id="pagination"></ul>
                        </div>
                    </div>

                </div>
            </div>
        </main>
        <?php require_once("includes/footer.php"); ?>
    </div>


    <div class="modal fade ay-modal" id="sectionModal" tabindex="-1" data-bs-backdrop="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form id="sectionForm">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalTitle"><i class="bi bi-plus-circle me-2"></i>Add Section</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="sectionId">
                        <div class="mb-3">
                            <label class="form-label">Grade Level <span class="text-danger">*</span></label>
                            <select class="form-select" id="gradeLevelId" required>
                                <option value="">— Select Grade Level —</option>
                                <?php
                                $stmt = $pdo->query("SELECT id, grade_level_name FROM tblgradelevel ORDER BY id ASC");
                                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                    echo '<option value="' . (int) $row['id'] . '" data-code="' . (int) $row['id'] . '">' . htmlspecialchars($row['grade_level_name']) . '</option>';
                                }
                                ?>
                            </select>
                        </div>

                        <div class="mb-3" id="strandField">
                            <label class="form-label">Track <span class="text-danger"
                                    id="trackRequiredMark">*</span></label>
                            <select class="form-select" id="strand">
                                <option value="">— Select Track —</option>
                                <option value="Academic">Academic</option>
                                <option value="Technical-Professional (Tech-Pro)">Technical-Professional (Tech-Pro)
                                </option>
                            </select>
                            <div class="form-text" style="font-size:.78rem;color:#7a93b8;">
                                Available for Senior High School (Grade 11 & 12)
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Section Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="sectionName" placeholder="e.g. Rose, Sampaguita"
                                required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-ay btn-ay-outline" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-ay btn-ay-primary" id="btnSaveSection">
                            <i class="bi bi-check-circle me-1"></i> Save Section
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./js/adminlte.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>
    <script>
        let currentPage = 1;
        let searchTerm = '';
        let totalSections = 0;
        const rowsPerPage = 5;
        const SHS_GRADE_CODES = [11, 12];

        /* Compact Track badge — shortens long track names (e.g. "Technical-Professional (Tech-Pro)" → "Tech-Pro"), escapes output */
function trackBadgeHtml(strand) {
    const value   = String(strand || '').trim();
    const escAttr = t => String(t)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;')
        .replace(/>/g, '&gt;').replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    if (!value) return '<span class="track-badge track-none">—</span>';
    if (/tech|professional/i.test(value)) {
        return `<span class="track-badge track-techpro" title="${escAttr(value)}">Tech-Pro</span>`;
    }
    if (/academic/i.test(value)) {
        return `<span class="track-badge track-academic" title="${escAttr(value)}">Academic</span>`;
    }
    return `<span class="track-badge" title="${escAttr(value)}">${escAttr(value)}</span>`;
}

function toast(msg, type = 'success') {
            const map = {
                success: { title: 'Success', color: 'green', icon: 'bi bi-check-circle-fill' },
                danger: { title: 'Error', color: 'red', icon: 'bi bi-exclamation-octagon-fill' },
                warning: { title: 'Warning', color: 'yellow', icon: 'bi bi-exclamation-triangle-fill' },
                info: { title: 'Info', color: 'blue', icon: 'bi bi-info-circle-fill' },
            };
            const c = map[type] || map.success;

            iziToast.show({
                title: c.title, message: msg, color: c.color, icon: c.icon,
                iconColor: '#fff', theme: 'light', position: 'topRight', timeout: 4000,
                progressBar: true, close: true, pauseOnHover: true,
                transitionIn: 'fadeInDown', transitionOut: 'fadeOutUp'
            });
        }

        function confirmAction(msg, onYes) {
            iziToast.question({
                timeout: 20000, close: false, overlay: true, displayMode: 'once',
                zindex: 9999, title: 'Confirm', message: msg, position: 'center',
                color: 'blue', icon: 'bi bi-question-circle-fill',
                buttons: [
                    ['<button><b>Yes</b></button>', (inst, t) => {
                        inst.hide({ transitionOut: 'fadeOut' }, t); onYes();
                    }, true],
                    ['<button>No</button>', (inst, t) => inst.hide({ transitionOut: 'fadeOut' }, t)]
                ]
            });
        }

        function updateSectionCount(page, listLength) {
            const countEl = document.getElementById('sectionCountText');
            if (!countEl) return;
            if (totalSections === 0) { countEl.textContent = 'No sections to display.'; return; }
            const start = ((page - 1) * rowsPerPage) + 1;
            const end = start + listLength - 1;
            countEl.textContent = `Showing ${start}-${end} of ${totalSections} sections`;
        }


        function toggleStrandField() {
            const gradeSelect = document.getElementById('gradeLevelId');
            const gradeCode = parseInt(gradeSelect.selectedOptions[0]?.dataset.code, 10) || 0;
            const strandSelect = document.getElementById('strand');
            const strandField = document.getElementById('strandField');
            const isTrackRequired = SHS_GRADE_CODES.includes(gradeCode);

            strandField.style.display = 'block';
            strandSelect.disabled = !isTrackRequired;
            strandSelect.required = isTrackRequired;
            document.getElementById('trackRequiredMark').hidden = !isTrackRequired;
        }

        document.getElementById('gradeLevelId').addEventListener('change', toggleStrandField);
        toggleStrandField();

        function loadSections(page = 1, search = '') {
            currentPage = page; searchTerm = search;
            fetch(`api/section/read.php?p=${page}&s=${encodeURIComponent(search)}`)
                .then(r => r.json())
                .then(data => {
                    totalSections = Number(data.total || 0);
                    renderTable(data.sections || [], data.page || 1, data.pages || 1);
                })
                .catch(() => toast('Failed to load sections.', 'danger'));
        }

        function renderTable(list, page, pages) {
            const tbody = document.getElementById('sectionTableBody');
            const cards = document.getElementById('cardView');
            const pagination = document.getElementById('pagination');
            const offset = (page - 1) * rowsPerPage;

            updateSectionCount(page, list.length);

            if (!list.length) {
                const empty = `<div class="ay-empty"><i class="bi bi-building-x"></i><p>No sections found.</p></div>`;
                tbody.innerHTML = `<tr><td colspan="6">${empty}</td></tr>`;
                cards.innerHTML = empty;
                pagination.innerHTML = '';
                return;
            }

            tbody.innerHTML = list.map((s, i) => `
                <tr>
                    <td style="text-align:center;color:#9ab0c8;font-size:.82rem;">${offset + i + 1}</td>
                    <td style="color:#6b84a2;font-size:.88rem;">${s.grade_level_name || '—'}</td>
                    <td><strong style="color:#132f62;">${s.section_name}</strong></td>
                    <td style="text-align:center;">
                        ${trackBadgeHtml(s.strand)}
                    </td>
                    <td style="text-align:center;">
                        <span class="ay-badge ${Number(s.is_active) === 1 ? 'ay-badge-active' : 'ay-badge-inactive'}">
                            ${Number(s.is_active) === 1 ? '<i class="bi bi-check-circle-fill"></i> Active' : 'Inactive'}
                        </span>
                    </td>
                    <td style="text-align:center;">
                        <div style="display:inline-flex;gap:.35rem;flex-wrap:wrap;">
                            <button class="btn btn-ay btn-ay-warning btn-ay-sm" onclick="editSection(${s.id})" title="Edit" aria-label="Edit">
                                <i class="bi bi-pencil-square"></i>
                            </button>
                            <button class="btn-am ${Number(s.is_active) === 1 ? 'btn-am-deactivate' : 'btn-am-activate'}"
                                    onclick="toggleSection(${s.id}, ${s.is_active})">
                                ${Number(s.is_active) === 1 ? '<i class="bi bi-power"></i>' : '<i class="bi bi-play-circle"></i>'}
                                ${Number(s.is_active) === 1 ? 'Deactivate' : 'Activate'}
                            </button>
                        </div>
                    </td>
                </tr>
            `).join('');

            cards.innerHTML = list.map((s, i) => `
                <div class="ay-mobile-card">
                    <div class="ay-mobile-card-header">
                        <span class="ay-mobile-card-title">${offset + i + 1}. ${s.section_name}</span>
                        <span class="ay-badge ${Number(s.is_active) === 1 ? 'ay-badge-active' : 'ay-badge-inactive'}">
                            ${Number(s.is_active) === 1 ? '<i class="bi bi-check-circle-fill"></i> Active' : 'Inactive'}
                        </span>
                    </div>
                    <div class="ay-mobile-card-body">
                        <div class="grade-label"><i class="bi bi-mortarboard me-1"></i>${s.grade_level_name || '—'}</div>
                        <div class="grade-label"><i class="bi bi-bookmark me-1"></i>Track: ${trackBadgeHtml(s.strand)}</div>
                        <div style="display:flex;gap:.4rem;flex-wrap:wrap;">
                            <button class="btn btn-ay btn-ay-warning btn-ay-sm" onclick="editSection(${s.id})" title="Edit" aria-label="Edit">
                                <i class="bi bi-pencil-square"></i>
                            </button>
                            <button class="btn-am ${Number(s.is_active) === 1 ? 'btn-am-deactivate' : 'btn-am-activate'}"
                                    onclick="toggleSection(${s.id}, ${s.is_active})">
                                ${Number(s.is_active) === 1 ? '<i class="bi bi-power me-1"></i>' : '<i class="bi bi-play-circle me-1"></i>'}
                                ${Number(s.is_active) === 1 ? 'Deactivate' : 'Activate'}
                            </button>
                        </div>
                    </div>
                </div>
            `).join('');

            let html = '';
            html += `<li class="ay-page-item ${page <= 1 ? 'disabled' : ''}">
                <a class="ay-page-link" onclick="${page > 1 ? `loadSections(${page - 1}, searchTerm)` : 'return false;'}">Previous</a>
            </li>`;
            for (let n = 1; n <= pages; n++) {
                html += `<li class="ay-page-item ${n === page ? 'active' : ''}">
                    <a class="ay-page-link" onclick="loadSections(${n}, searchTerm)">${n}</a>
                </li>`;
            }
            html += `<li class="ay-page-item ${page >= pages ? 'disabled' : ''}">
                <a class="ay-page-link" onclick="${page < pages ? `loadSections(${page + 1}, searchTerm)` : 'return false;'}">Next</a>
            </li>`;
            pagination.innerHTML = html;
        }

        document.getElementById('sectionForm').addEventListener('submit', async function (e) {
            e.preventDefault();

            const gradeId = parseInt(document.getElementById('gradeLevelId').value) || 0;
            const strand = document.getElementById('strand').value;
            const isTrackRequired = SHS_GRADE_CODES.includes(gradeId);

            if (isTrackRequired && !strand) {
                toast('Please select a Track for Grade 11 and Grade 12 sections.', 'warning');
                document.getElementById('strand').focus();
                return;
            }

            const payload = {
                id: document.getElementById('sectionId').value || undefined,
                grade_level_id: gradeId,
                strand: strand || null,
                section_name: document.getElementById('sectionName').value.trim(),
            };

            const btn = document.getElementById('btnSaveSection');
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Saving…';

            try {
                const res = await fetch('api/section/save.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                }).then(r => r.json());

                if (res.success) {
                    bootstrap.Modal.getInstance(document.getElementById('sectionModal')).hide();
                    toast(res.message || 'Section saved successfully.');
                    loadSections(1, searchTerm);
                } else {
                    toast(res.error || 'Save failed.', 'danger');
                }
            } catch {
                toast('An error occurred.', 'danger');
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="bi bi-check-circle me-1"></i> Save Section';
            }
        });

        function editSection(id) {
            fetch(`api/section/fetch.php?id=${id}`)
                .then(r => r.json())
                .then(data => {
                    document.getElementById('sectionId').value = data.id;
                    document.getElementById('gradeLevelId').value = data.grade_level_id || '';
                    document.getElementById('sectionName').value = data.section_name;


                    document.getElementById('strand').value = data.strand || '';
                    toggleStrandField();

                    document.getElementById('modalTitle').innerHTML = '<i class="bi bi-pencil-square me-2"></i>Edit Section';
                    bootstrap.Modal.getOrCreateInstance(document.getElementById('sectionModal')).show();
                })
                .catch(() => toast('Could not load section.', 'danger'));
        }

        function toggleSection(id, currentState) {
            const action = Number(currentState) === 1 ? 'deactivate' : 'activate';
            confirmAction(`Are you sure you want to <strong>${action}</strong> this section?`, async () => {
                try {
                    const res = await fetch('api/section/toggle.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id })
                    }).then(r => r.json());

                    if (res.success) {
                        toast(res.message || `Section ${action}d successfully.`);
                        loadSections(currentPage, searchTerm);
                    } else {
                        toast(res.error || 'Toggle failed.', 'danger');
                    }
                } catch (err) {
                    toast('Could not change status: ' + err.message, 'danger');
                }
            });
        }

        let searchDebounce;
        document.getElementById('searchInput').addEventListener('input', e => {
            clearTimeout(searchDebounce);
            searchDebounce = setTimeout(() => {
                searchTerm = e.target.value.trim();
                currentPage = 1;
                loadSections(1, searchTerm);
            }, 300);
        });

        document.getElementById('sectionModal').addEventListener('hidden.bs.modal', () => {
            document.getElementById('sectionForm').reset();
            document.getElementById('sectionId').value = '';
            document.getElementById('strandField').classList.remove('visible');
            document.getElementById('modalTitle').innerHTML = '<i class="bi bi-plus-circle me-2"></i>Add Section';
        });

        loadSections(1, '');
    </script>
</body>

</html>