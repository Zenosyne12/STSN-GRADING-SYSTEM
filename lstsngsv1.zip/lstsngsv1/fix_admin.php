<?php
// FIX: Path points to api/shared/db_connect.php
require_once 'api/shared/db_connect.php';

$username = 'admin';
$password = 'admin123';

// 1. Generate the hash using YOUR server's specific settings
$hash = password_hash($password, PASSWORD_DEFAULT);

try {
    // 2. Delete the old broken admin account if it exists
    $pdo->prepare("DELETE FROM tblusers WHERE username = ?")->execute([$username]);

    // 3. Insert the fresh Admin account
    // reference_id is NULL (for Admin), must_change_password is 0
    $stmt = $pdo->prepare("INSERT INTO tblusers (username, password_hash, status, reference_id, must_change_password) VALUES (?, ?, 'Active', NULL, 0)");
    
    if ($stmt->execute([$username, $hash])) {
        echo "<h1 style='color:green'>Success!</h1>";
        echo "Admin account has been reset.<br>";
        echo "Username: <b>admin</b><br>";
        echo "Password: <b>admin123</b><br><br>";
        echo "<a href='login.php'>Go to Login Page</a>";
    } else {
        echo "Insert failed.";
    }

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>