<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/api/shared/db_connect.php';

$activeYearLabel = '';
$activeYearId = null;
try {
    $stmtActive = $pdo->query("SELECT id, year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
    $activeYear = $stmtActive ? $stmtActive->fetch(PDO::FETCH_ASSOC) : null;
    $activeYearLabel = $activeYear ? $activeYear['year_label'] : '';
    $activeYearId = $activeYear ? (int) $activeYear['id'] : null;
} catch (Throwable $e) {
    $activeYearLabel = '';
    $activeYearId = null;
}

$activeClusters = $pdo->query("SELECT id, cluster_name FROM tblclusters WHERE is_active = 1 ORDER BY cluster_name")->fetchAll(PDO::FETCH_ASSOC) ?: [];

$toastType = null;
$toastMessage = '';
if (isset($_GET['msg'])) {
    $toastType = 'success';
    $toastMessage = (string) $_GET['msg'];
} elseif (isset($_GET['warning'])) {
    $toastType = 'warning';
    $toastMessage = (string) $_GET['warning'];
} elseif (isset($_GET['error'])) {
    $toastType = 'danger';
    $toastMessage = (string) $_GET['error'];
}
?>
<!doctype html>
<html lang="en">

<head>
    <?php require_once __DIR__ . '/includes/theme_head.php'; ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
    <meta charset="utf-8">
    <title>STSN Grading System | Student Management</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="./css/students.css">
    <style>
        .page-header {
            display: none;
        }

        /* ============================================================
           THEME TOKENS — Light & Dark
           ============================================================ */
        :root,
        [data-bs-theme="light"] {
            --ay-bg: #ffffff;
            --ay-bg-soft: #f7fafe;
            --ay-bg-alt: #eef4ff;
            --ay-bg-hover: #f9fbff;
            --ay-border: #e8f0fb;
            --ay-border-soft: #dce8f8;
            --ay-border-input: #c8daf8;
            --ay-text: #213a5e;
            --ay-text-strong: #132f62;
            --ay-text-muted: #7a93b8;
            --ay-text-dim: #9ab0c8;
            --ay-head-bg: #f7fafe;
            --ay-head-text: #5a7ab0;
            --ay-input-bg: #ffffff;
            --ay-input-text: #213a5e;
            --ay-row-hover: #f7fafe;
            --ay-shadow: rgba(18, 72, 168, .05);
            --ay-card-border: #e8f0fb;
        }

        [data-bs-theme="dark"] {
            --ay-bg: #2D2D2D;
            --ay-bg-soft: #262626;
            --ay-bg-alt: #343434;
            --ay-bg-hover: #343434;
            --ay-border: #3a3a3a;
            --ay-border-soft: #4a5a6e;
            --ay-border-input: #4a5a6e;
            --ay-text: #c8d4e0;
            --ay-text-strong: #e8eef7;
            --ay-text-muted: #94a7bf;
            --ay-text-dim: #6d7f94;
            --ay-head-bg: #2D2D2D;
            --ay-head-text: #e8eef7;
            --ay-input-bg: #3a3a3a;
            --ay-input-text: #e8eef7;
            --ay-row-hover: #343434;
            --ay-shadow: rgba(0, 0, 0, .35);
            --ay-card-border: #3a3a3a;
        }

        body,
        .students-card,
        .ay-card,
        .ay-card-header,
        .ay-card-footer,
        .ay-table,
        .ay-table thead th,
        .ay-table tbody td,
        .ay-search,
        .ay-year-select,
        .ay-mobile-card {
            transition: background-color .18s ease, color .18s ease, border-color .18s ease;
        }

        /* ============================================================
           PAGE HEADER
           ============================================================ */
        .ay-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            box-shadow: 0 4px 16px rgba(18, 72, 168, .18);
        }

        .ay-page-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 0.2rem;
            letter-spacing: 0.01em;
            color: #fff;
        }

        .ay-page-header p {
            margin: 0;
            font-size: 0.88rem;
            opacity: 0.88;
            color: #fff;
        }

        /* ============================================================
           CARDS
           ============================================================ */
        .students-card,
        .ay-card {
            background: var(--ay-bg);
            border: 1px solid var(--ay-card-border);
            border-radius: 14px;
            box-shadow: 0 1px 6px var(--ay-shadow);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }

        .ay-card-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid var(--ay-border);
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
            background: var(--ay-bg);
        }

        .ay-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: var(--ay-text-strong);
            margin: 0 0 0.15rem;
        }

        .ay-card-subtitle {
            font-size: 0.8rem;
            color: var(--ay-text-muted);
            margin: 0;
        }

        .ay-toolbar {
            display: flex;
            gap: 0.6rem;
            flex-wrap: wrap;
            align-items: center;
        }

        .ay-search-wrap {
            position: relative;
            min-width: 260px;
        }

        .ay-search-wrap i {
            position: absolute;
            left: 0.95rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--ay-text-muted);
            font-size: 0.9rem;
            pointer-events: none;
        }

        .ay-search {
            width: 100%;
            border-radius: 10px;
            border: 1.5px solid var(--ay-border-input);
            min-height: 42px;
            font-size: 0.9rem;
            color: var(--ay-input-text);
            padding: 0.45rem 0.85rem 0.45rem 2.45rem;
            background: var(--ay-input-bg);
        }

        .ay-search::placeholder {
            color: var(--ay-text-dim);
        }

        .ay-search:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.12);
            outline: none;
            background: var(--ay-input-bg);
            color: var(--ay-input-text);
        }

        .ay-year-select {
            border-radius: 10px;
            border: 1.5px solid var(--ay-border-input);
            min-height: 42px;
            font-size: 0.88rem;
            color: var(--ay-input-text);
            padding: 0.45rem 0.85rem;
            background: var(--ay-input-bg);
            cursor: pointer;
        }

        .ay-year-select:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.12);
            outline: none;
        }

        .ay-card-body {
            padding: 0;
            overflow-x: auto;
            background: var(--ay-bg);
        }

        #studentTable {
            min-width: 1180px;
        }

        /* ============================================================
           CARD FOOTER
           ============================================================ */
        .ay-card-footer {
            padding: 0.75rem 1.2rem;
            border-top: 1px solid var(--ay-border);
            background: var(--ay-bg);
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 0.75rem;
            flex-wrap: wrap;
        }

        .ay-footer-note {
            font-size: 0.82rem;
            color: var(--ay-text-muted);
        }

        /* ============================================================
           TABLE
           ============================================================ */
        .ay-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
            background: var(--ay-bg);
        }

        .ay-table thead th {
            background: var(--ay-head-bg) !important;
            color: var(--ay-head-text) !important;
            font-size: 0.72rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 0.85rem 1.2rem;
            border-bottom: 1.5px solid var(--ay-border) !important;
            white-space: nowrap;
            text-align: center;
        }

        .ay-table tbody tr {
            transition: background 0.12s;
        }

        .ay-table tbody tr:not(:last-child) td {
            border-bottom: 1px solid var(--ay-border) !important;
        }

        .ay-table tbody tr:hover td {
            background: var(--ay-row-hover) !important;
        }

        .ay-table tbody td {
            padding: 0.95rem 1.2rem;
            font-size: 0.93rem;
            color: var(--ay-text) !important;
            vertical-align: middle;
            background: var(--ay-bg);
        }

        .ay-table tbody td .row-num {
            color: var(--ay-text-muted);
            font-size: 0.82rem;
            font-weight: 600;
        }

        .ay-table tbody td a {
            color: #1a6ef5 !important;
            text-decoration: none;
        }

        [data-bs-theme="dark"] .ay-table tbody td a {
            color: #7ab7ff !important;
        }

        .ay-table tbody td a:hover {
            color: #1248a8 !important;
        }

        [data-bs-theme="dark"] .ay-table tbody td a:hover {
            color: #a5ccff !important;
        }

        .student-name {
            font-weight: 700;
            color: var(--ay-text-strong);
            line-height: 1.25;
        }

        /* ============================================================
           BADGES
           ============================================================ */
        .ay-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.34rem 0.78rem;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0.03em;
            white-space: nowrap;
        }

        .ay-badge-active {
            background: #e6f9ee;
            color: #178a4c;
            border: 1.5px solid #b6e9cd;
        }

        [data-bs-theme="dark"] .ay-badge-active {
            background: #17351f;
            color: #6ee7a0;
            border-color: #2b5c38;
        }

        .ay-badge-inactive {
            background: #f3f5f8;
            color: #7a8ea8;
            border: 1.5px solid #dde4ee;
        }

        [data-bs-theme="dark"] .ay-badge-inactive {
            background: #3a3a3a;
            color: #a9b8cd;
            border-color: #4a5a6e;
        }

        .ay-badge-promoted {
            background: #e6f0ff;
            color: #1a6ef5;
            border: 1.5px solid #b8d4f8;
        }

        [data-bs-theme="dark"] .ay-badge-promoted {
            background: #1e2a3d;
            color: #8ab4f8;
            border-color: #2d4366;
        }

        .ay-badge-retained {
            background: #fff8e6;
            color: #8a5c00;
            border: 1.5px solid #f5d98a;
        }

        [data-bs-theme="dark"] .ay-badge-retained {
            background: #3a2f14;
            color: #ffcc66;
            border-color: #5c4820;
        }

        .ay-badge-dropped,
        .ay-badge-transferred {
            background: #fdecee;
            color: #b3283f;
            border: 1.5px solid #f5c2cb;
        }

        [data-bs-theme="dark"] .ay-badge-dropped,
        [data-bs-theme="dark"] .ay-badge-transferred {
            background: #3a1f24;
            color: #ff8b9e;
            border-color: #5c2d35;
        }

        .ay-badge-graduated {
            background: #f3e8ff;
            color: #7c3aed;
            border: 1.5px solid #ddd0f5;
        }

        [data-bs-theme="dark"] .ay-badge-graduated {
            background: #2d1e42;
            color: #c4b5fd;
            border-color: #4c3670;
        }

        /* ============================================================
           BUTTONS
           ============================================================ */
        .btn-ay {
            font-weight: 600;
            font-size: 0.82rem;
            border-radius: 8px;
            padding: 0.44rem 0.9rem;
            cursor: pointer;
            transition: background 0.15s, border-color 0.15s, color 0.15s, box-shadow 0.15s, transform 0.15s;
            border: 1.5px solid transparent;
            line-height: 1.4;
        }

        .btn-ay:hover {
            transform: translateY(-1px);
        }

        .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            border-color: transparent;
            box-shadow: 0 2px 8px rgba(26, 110, 245, 0.2);
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
        }

        .btn-ay-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
            box-shadow: 0 3px 12px rgba(26, 110, 245, 0.3);
        }

        .btn-ay-import {
            background: linear-gradient(130deg, #1d6f42, #27ae60);
            color: #fff;
            border-color: transparent;
            box-shadow: 0 2px 8px rgba(29, 111, 66, 0.2);
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
        }

        .btn-ay-import:hover {
            background: linear-gradient(130deg, #175c36, #1e9450);
            color: #fff;
            box-shadow: 0 3px 12px rgba(29, 111, 66, 0.3);
        }

        .btn-ay-edit {
            background: #fff8e6;
            color: #8a5c00;
            border-color: #f5d98a;
        }

        .btn-ay-edit:hover {
            background: #fff0c0;
            border-color: #f0c832;
            color: #6e4900;
        }

        [data-bs-theme="dark"] .btn-ay-edit {
            background: #3a2f14;
            color: #ffcc66;
            border-color: #5c4820;
        }

        [data-bs-theme="dark"] .btn-ay-edit:hover {
            background: #4a3c1a;
            border-color: #6e5628;
            color: #ffdd88;
        }

        .btn-ay-activate {
            background: #1a6ef5;
            color: #fff;
            border-color: #1a6ef5;
        }

        .btn-ay-activate:hover {
            background: #1560d8;
            border-color: #1560d8;
            color: #fff;
        }

        .btn-ay-deactivate {
            background: var(--ay-bg);
            color: #1248a8;
            border-color: #b8d0fa;
        }

        .btn-ay-deactivate:hover {
            background: var(--ay-bg-alt);
            border-color: #8db5f7;
            color: #0f3d90;
        }

        [data-bs-theme="dark"] .btn-ay-deactivate {
            background: #3a3a3a;
            color: #7ab7ff;
            border-color: #4a5a6e;
        }

        [data-bs-theme="dark"] .btn-ay-deactivate:hover {
            background: #454545;
            border-color: #5a6a7e;
            color: #a5ccff;
        }

        .btn-ay-archive {
            background: #fdecee;
            color: #b3283f;
            border-color: #f5c2cb;
        }

        .btn-ay-archive:hover {
            background: #fbdbe0;
            border-color: #eda4b1;
            color: #931f31;
        }

        [data-bs-theme="dark"] .btn-ay-archive {
            background: #3a1f24;
            color: #ff8b9e;
            border-color: #5c2d35;
        }

        [data-bs-theme="dark"] .btn-ay-archive:hover {
            background: #4a262c;
            border-color: #6e3640;
            color: #ffb0be;
        }

        .ay-action-group {
            display: flex;
            justify-content: center;
            flex-wrap: nowrap;
            gap: 0.4rem;
            min-width: 116px;
            white-space: nowrap;
        }

        .ay-action-group .btn-ay {
            flex: 0 0 36px;
            width: 36px;
            height: 36px;
            padding: 0;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .ay-action-group .btn-ay i {
            margin: 0 !important;
        }

        .ay-table th:last-child,
        .ay-table td:last-child {
            min-width: 150px;
            white-space: nowrap;
        }

        .ay-mobile-actions {
            display: flex;
            flex-wrap: nowrap;
            gap: 0.4rem;
        }

        .ay-mobile-actions .btn-ay {
            flex: 0 0 36px;
            width: 36px;
            height: 36px;
            padding: 0;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .ay-mobile-actions .btn-ay i {
            margin: 0 !important;
        }

        /* ============================================================
           TOASTS
           ============================================================ */
        .iziToast-wrapper {
            z-index: 10000 !important;
        }

        .iziToast {
            background: var(--ay-bg) !important;
            background-color: var(--ay-bg) !important;
            border: 1px solid var(--ay-border) !important;
            border-radius: 10px !important;
            box-shadow: 0 8px 24px rgba(18, 72, 168, 0.14) !important;
            opacity: 1 !important;
            z-index: 10000 !important;
        }

        .iziToast .iziToast-body,
        .iziToast .iziToast-texts {
            background: var(--ay-bg) !important;
        }

        .iziToast .iziToast-title,
        .iziToast .iziToast-message {
            color: var(--ay-text) !important;
        }

        [data-bs-theme="dark"] .iziToast {
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.55) !important;
        }

        /* ============================================================
           PAGINATION
           ============================================================ */
        .ay-pagination {
            display: flex;
            gap: 0.3rem;
            list-style: none;
            margin: 0;
            padding: 0;
            justify-content: flex-end;
            align-items: center;
            flex-wrap: wrap;
        }

        .ay-pagination .ay-page-item .ay-page-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
            border-radius: 7px;
            font-size: 0.83rem;
            font-weight: 600;
            cursor: pointer;
            border: 1.5px solid var(--ay-border-soft);
            color: #1a6ef5;
            background: var(--ay-bg);
            transition: all 0.13s;
            padding: 0 0.65rem;
            text-decoration: none;
        }

        .ay-pagination .ay-page-item .ay-page-link:hover {
            background: var(--ay-bg-alt);
            border-color: #9cc2fc;
        }

        .ay-pagination .ay-page-item.active .ay-page-link {
            background: #1a6ef5;
            border-color: #1a6ef5;
            color: #fff;
        }

        .ay-pagination .ay-page-item.disabled .ay-page-link {
            background: var(--ay-bg-soft);
            border-color: var(--ay-border);
            color: var(--ay-text-dim);
            cursor: not-allowed;
            pointer-events: none;
        }

        [data-bs-theme="dark"] .ay-pagination .ay-page-item .ay-page-link {
            color: #7ab7ff;
        }

        [data-bs-theme="dark"] .ay-pagination .ay-page-item.disabled .ay-page-link {
            color: #5d6b7d;
        }

        /* ============================================================
           EMPTY STATE
           ============================================================ */
        .ay-empty {
            text-align: center;
            padding: 2.8rem 1.5rem;
            color: var(--ay-text-dim);
        }

        .ay-empty i {
            font-size: 2.35rem;
            display: block;
            margin-bottom: 0.7rem;
            opacity: 0.55;
        }

        .ay-empty p {
            margin: 0;
            font-size: 0.95rem;
        }

        /* ============================================================
           MOBILE CARDS
           ============================================================ */
        .ay-mobile-card {
            background: var(--ay-bg);
            border: 1.5px solid var(--ay-border-soft);
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 1px 6px var(--ay-shadow);
        }

        .ay-mobile-card + .ay-mobile-card {
            margin-top: 0.75rem;
        }

        .ay-mobile-card-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            padding: 0.95rem 1rem;
            border-bottom: 1px solid var(--ay-border);
            background: var(--ay-bg-soft);
            gap: 0.75rem;
        }

        .ay-mobile-card-title {
            font-weight: 700;
            color: var(--ay-text-strong);
            font-size: 0.96rem;
            line-height: 1.25;
        }

        .ay-mobile-card-subtitle {
            font-size: 0.82rem;
            color: var(--ay-text-muted);
            margin-top: 0.16rem;
        }

        .ay-mobile-card-body {
            padding: 0.9rem 1rem 0.35rem;
        }

        .ay-mobile-row {
            display: flex;
            justify-content: space-between;
            gap: 0.75rem;
            padding: 0.3rem 0;
            font-size: 0.9rem;
            color: var(--ay-text);
        }

        .ay-mobile-label {
            color: var(--ay-text-muted);
            font-weight: 600;
        }

        .ay-mobile-actions {
            display: flex;
            gap: 0.5rem;
            padding: 0.8rem 1rem 1rem;
        }

        @media (max-width: 767.98px) {
            .ay-page-header {
                padding: 1.1rem 1.2rem;
                border-radius: 14px;
            }
            .ay-search-wrap {
                min-width: 100%;
            }
            .ay-card-footer {
                justify-content: center;
            }
            .ay-pagination {
                justify-content: center;
            }
        }

        /* ============================================================
           BREADCRUMB
           ============================================================ */
        .breadcrumb {
            background: var(--ay-bg) !important;
            border-color: var(--ay-border) !important;
        }

        /* ============================================================
           SF1 IMPORT MODAL
           ============================================================ */
        .sf1-modal-content { border:none; border-radius:18px; overflow:hidden; box-shadow:0 8px 40px rgba(18,72,168,.18); }
        #importModal.sf1-modal--transition.fade .modal-dialog {
            transition:
                transform var(--stsn-anim-duration) var(--stsn-anim-easing),
                opacity var(--stsn-anim-duration-fast) ease-out !important;
            transform: translateY(var(--stsn-anim-distance)) scale(var(--stsn-anim-scale-from)) !important;
            opacity: 0;
        }
        #importModal.sf1-modal--transition.show .modal-dialog {
            transform: translateY(0) scale(1) !important;
            opacity: 1 !important;
        }
        @media (prefers-reduced-motion: reduce) {
            #importModal.sf1-modal--transition.fade .modal-dialog {
                transition: none !important;
            }
        }
        .sf1-modal-header { background:linear-gradient(130deg,#1248a8,#1a6ef5); color:#fff; padding:1rem 1.25rem; display:flex; align-items:center; gap:.85rem; }
        .sf1-modal-icon { width:44px; height:44px; border-radius:12px; background:rgba(255,255,255,.18); display:flex; align-items:center; justify-content:center; font-size:1.3rem; flex-shrink:0; }
        .sf1-modal-title { font-size:1rem; font-weight:700; margin:0 0 .1rem; }
        .sf1-modal-subtitle { font-size:.78rem; opacity:.88; margin:0; }
        .sf1-close-btn { margin-left:auto; background:rgba(255,255,255,.15); border:1.5px solid rgba(255,255,255,.3); color:#fff; border-radius:8px; width:32px; height:32px; display:flex; align-items:center; justify-content:center; cursor:pointer; font-size:.85rem; flex-shrink:0; transition:.14s; }
        .sf1-close-btn:hover { background:rgba(255,255,255,.28); }
        .sf1-modal-body { padding:1.1rem 1.25rem; background:var(--ay-bg); color:var(--ay-text); }
        .sf1-info-banner { background:#eef4ff; border:1.5px solid #c0d8fc; border-radius:10px; padding:.65rem .9rem; display:flex; gap:.65rem; align-items:flex-start; font-size:.76rem; color:#1248a8; margin-bottom:.95rem; }
        .sf1-info-banner i { font-size:1rem; flex-shrink:0; margin-top:.05rem; }
        .sf1-info-banner strong { display:block; margin-bottom:.1rem; font-size:.78rem; }
        .sf1-dropzone { border:2.5px dashed #a8c8f8; border-radius:14px; padding:1.5rem 1rem; text-align:center; background:#f7fbff; cursor:pointer; transition:.18s; margin-bottom:.65rem; }
        .sf1-dropzone:hover,.sf1-dropzone.drag-over { border-color:#1a6ef5; background:#eef4ff; }
        .sf1-drop-icon { font-size:2.2rem; color:#5b9bf8; display:block; margin-bottom:.55rem; }
        .sf1-drop-title { font-size:.92rem; font-weight:700; color:#213a5e; margin:0 0 .2rem; }
        .sf1-drop-sub { font-size:.78rem; color:#7a93b8; margin:0; }
        .sf1-file-chosen { display:flex; align-items:center; gap:.55rem; background:#e8fbf1; border:1.5px solid #7ecba8; border-radius:10px; padding:.5rem .85rem; font-size:.82rem; color:#0a6b47; margin-bottom:.65rem; }
        .sf1-clear-btn { margin-left:auto; background:none; border:none; color:#c0392b; cursor:pointer; font-size:1rem; padding:0; }
        .sf1-detected-card { background:#f0f7ff; border:1.5px solid #b8d4f8; border-radius:12px; padding:.8rem 1rem; margin-bottom:.75rem; }
        .sf1-detected-title { font-size:.8rem; font-weight:700; color:#1248a8; margin-bottom:.55rem; }
        .sf1-detected-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:.5rem; }
        .sf1-detected-item { background:#fff; border:1px solid #dce8f8; border-radius:8px; padding:.45rem .65rem; }
        .sf1-detected-label { display:block; font-size:.68rem; font-weight:700; color:#7a93b8; margin-bottom:.15rem; }
        .sf1-detected-val { display:block; font-size:.85rem; font-weight:700; color:#132f62; }
        .sf1-detected-warn { margin-top:.55rem; background:#fff8e6; border:1px solid #f5c842; border-radius:8px; padding:.4rem .7rem; font-size:.76rem; color:#7a5800; display:flex; align-items:center; }
        .sf1-hr { border:0; border-top:1px solid var(--ay-border); margin:.8rem 0; }
        .sf1-override-row {
            display:flex;
            flex-wrap:wrap;
            gap:1rem 1.25rem;
            align-items:flex-end;
        }
        .sf1-field {
            display:flex;
            flex-direction:column;
            gap:.25rem;
            flex:0 0 220px;
            max-width:220px;
            min-width:0;
        }
        .sf1-label { font-size:.73rem; font-weight:700; color:var(--ay-text-muted); }
        .sf1-field .sf1-label { min-height:2.6em; line-height:1.3; }
        .sf1-field--collapsible {
            transition:
                opacity var(--stsn-anim-duration-fast) ease-out,
                transform var(--stsn-anim-duration-fast) var(--stsn-anim-easing);
            opacity:1;
            transform:translateY(0);
        }
        .sf1-field--collapsible.sf1-field--hidden {
            opacity:0;
            transform:translateY(-4px);
            pointer-events:none;
        }
        @media (prefers-reduced-motion: reduce) {
            .sf1-field--collapsible { transition:none !important; }
        }
        .sf1-hint-inline { font-size:.65rem; color:var(--ay-text-dim); font-weight:400; }
        .sf1-select,.sf1-input { border-radius:9px; border:1.5px solid var(--ay-border-input); padding:.38rem .72rem; font-size:.84rem; color:var(--ay-input-text); background:var(--ay-input-bg); transition:.15s; min-height:36px; width:100%; }
        .sf1-select:focus,.sf1-input:focus { border-color:#1a6ef5; outline:none; box-shadow:0 0 0 3px rgba(26,110,245,.1); }
        .sf1-confirm-bar { background:#e8fbf1; border:1.5px solid #7ecba8; border-radius:10px; padding:.55rem 1rem; margin-bottom:.65rem; font-size:.82rem; color:#0a6b47; font-weight:600; display:flex; flex-wrap:wrap; gap:.5rem 1.25rem; align-items:center; }
        .sf1-confirm-bar i { font-size:.95rem; }
        .sf1-confirm-chip { background:#fff; border:1px solid #a0dfc8; border-radius:6px; padding:.18rem .55rem; font-size:.76rem; color:#0a6b47; font-weight:700; }
        .sf1-preview-bar { display:flex; align-items:center; justify-content:space-between; gap:.75rem; margin-bottom:.55rem; flex-wrap:wrap; }
        .sf1-preview-meta { font-size:.82rem; font-weight:600; color:var(--ay-text); }
        .sf1-preview-scroll { overflow-x:auto; border-radius:10px; border:1.5px solid var(--ay-border); margin-bottom:.65rem; max-height:320px; overflow-y:auto; }
        .sf1-preview-table { width:100%; border-collapse:collapse; font-size:.76rem; white-space:nowrap; }
        .sf1-preview-table thead th { position:sticky; top:0; background:var(--ay-head-bg); color:var(--ay-head-text); font-weight:700; padding:.42rem .65rem; border-bottom:2px solid var(--ay-border-soft); text-align:left; }
        .sf1-preview-table tbody td { padding:.36rem .65rem; border-bottom:1px solid var(--ay-border); color:var(--ay-text); }
        .sf1-preview-table tbody tr:hover td { background:var(--ay-row-hover); }
        .sf1-lrn-dup { color:#c0392b !important; font-weight:700; }
        .sf1-lrn-dup::after { content:" ⚠"; font-size:.7rem; }
        .sf1-preview-note { font-size:.76rem; color:var(--ay-text-muted); margin:0; }
        .sf1-progress-wrap { text-align:center; padding:2.5rem 1rem; }
        .sf1-spinner { width:48px; height:48px; border:4px solid var(--ay-border-soft); border-top-color:#1a6ef5; border-radius:50%; animation:sf1spin .75s linear infinite; margin:0 auto 1.1rem; }
        @keyframes sf1spin { to { transform:rotate(360deg); } }
        .sf1-progress-title { font-size:1rem; font-weight:700; color:var(--ay-text-strong); margin-bottom:.3rem; }
        .sf1-progress-sub { font-size:.82rem; color:var(--ay-text-muted); }
        .sf1-result-summary { border-radius:12px; padding:.85rem 1rem; font-size:.88rem; margin-bottom:.75rem; }
        .sf1-result-summary.ok { background:#e6f7ed; border:1.5px solid #7ecba8; color:#0a6b47; }
        .sf1-result-summary.warn { background:#fff8e6; border:1.5px solid #f5c842; color:#7a5800; }
        .sf1-result-summary h6 { font-size:.92rem; font-weight:700; margin:0 0 .35rem; }
        .sf1-result-summary ul { margin:0; padding-left:1.1rem; }
        .sf1-result-summary li { margin-bottom:.18rem; }
        .sf1-issue-list { border-radius:10px; padding:.7rem .95rem; margin-bottom:.6rem; }
        .sf1-issue-dup { background:#fff8e6; border:1.5px solid #f5c842; }
        .sf1-issue-err { background:#fff0f0; border:1.5px solid #f7b8b8; }
        .sf1-issue-list h6 { font-size:.82rem; font-weight:700; margin:0 0 .4rem; }
        .sf1-issue-dup h6 { color:#7a5800; }
        .sf1-issue-err h6 { color:#c0392b; }
        .sf1-issue-list table { width:100%; font-size:.78rem; border-collapse:collapse; }
        .sf1-issue-list th,.sf1-issue-list td { padding:.22rem .5rem; text-align:left; border-bottom:1px solid rgba(0,0,0,.06); }
        .sf1-issue-list th { font-weight:700; color:var(--ay-text-muted); }
        .sf1-modal-footer { padding:.75rem 1.25rem; border-top:1px solid var(--ay-border); background:var(--ay-bg-soft); display:flex; justify-content:flex-end; gap:.5rem; flex-wrap:wrap; }
        .sf1-btn { font-weight:600; font-size:.8rem; border-radius:8px; padding:.42rem .9rem; cursor:pointer; border:1.5px solid transparent; line-height:1.35; display:inline-flex; align-items:center; gap:.28rem; text-decoration:none; transition:all .14s; }
        .sf1-btn-outline { background:var(--ay-bg); color:#1a6ef5; border-color:var(--ay-border); }
        .sf1-btn-outline:hover { background:var(--ay-bg-alt); border-color:#9cc2fc; color:#1a6ef5; }
        .sf1-btn-blue { background:linear-gradient(130deg,#1a6ef5,#1248a8); color:#fff; }
        .sf1-btn-blue:hover { background:linear-gradient(130deg,#1560d8,#103d90); color:#fff; }
        .sf1-btn-green { background:linear-gradient(130deg,#1d6f42,#27ae60); color:#fff; }
        .sf1-btn-green:hover { background:linear-gradient(130deg,#175c36,#1e9450); color:#fff; }
        .w-100 { width:100%; }

        [data-bs-theme="dark"] .sf1-info-banner { background:#1e2a3d; border-color:#2d4366; color:#8ab4f8; }
        [data-bs-theme="dark"] .sf1-dropzone { background:#232a31; border-color:#3a4a63; }
        [data-bs-theme="dark"] .sf1-dropzone:hover,
        [data-bs-theme="dark"] .sf1-dropzone.drag-over { background:#1e2a3d; border-color:#1a6ef5; }
        [data-bs-theme="dark"] .sf1-drop-title { color:#e4e6e8; }
        [data-bs-theme="dark"] .sf1-drop-sub { color:#8b939a; }
        [data-bs-theme="dark"] .sf1-detected-card { background:#1e2a3d; border-color:#2d4366; }
        [data-bs-theme="dark"] .sf1-detected-title { color:#8ab4f8; }
        [data-bs-theme="dark"] .sf1-detected-item { background:#232a31; border-color:#2d343b; }
        [data-bs-theme="dark"] .sf1-detected-val { color:#f1f3f5; }
        [data-bs-theme="dark"] .sf1-confirm-chip { background:#232a31; }

        @media(max-width:700px) { .sf1-detected-grid { grid-template-columns:1fr 1fr; } }
        @media(max-width:480px) { .sf1-detected-grid { grid-template-columns:1fr; } }
    /* ============================================================
   Standardized Deactivate Button (pill design)
   ============================================================ */
.btn-deactivate {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.42rem 1rem;
    background: #ffffff;
    color: #1248a8;
    border: 1.5px solid #b8d0fa;
    border-radius: 999px;
    font-size: 0.88rem;
    font-weight: 600;
    line-height: 1.4;
    cursor: pointer;
    transition: all 0.15s ease;
    text-decoration: none;
}
.btn-deactivate:hover {
    background: #eef4ff;
    border-color: #8db5f7;
    color: #1248a8;
}
.btn-deactivate:active {
    background: #dde8ff;
    border-color: #6ba3f0;
}
.btn-deactivate i {
    font-size: 1rem;
    line-height: 1;
}
/* Active state (currently active — to deactivate) */
.btn-deactivate.is-active-state {
    color: #1248a8;
    border-color: #b8d0fa;
}
/* Inactive state (currently inactive — to activate) */
.btn-deactivate.is-inactive-state {
    color: #0F6E56;
    border-color: #a8e6c8;
}
.btn-deactivate.is-inactive-state:hover {
    background: #e8f9f2;
    border-color: #6bd49b;
}
</style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <div class="app-wrapper">
        <?php require_once("includes/header.php"); ?>
        <?php require_once("includes/sidebar.php"); ?>

        <main class="app-main">
            <div class="app-content">
                <div class="container-fluid py-3">

                    <div class="ay-page-header">
                        <div>
                            <h3><i class="bi bi-people-fill me-2"></i>Student Management</h3>
                            <p>Add, edit, and manage all student records</p>
                        </div>
                    </div>

                    <?php require_once __DIR__ . '/includes/breadcrumb.php'; renderBreadcrumb([['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'], ['label' => 'Users', 'href' => 'Student.php', 'icon' => 'bi bi-people'], ['label' => 'Students', 'icon' => 'bi bi-people-fill']]); ?>

                    <?php if ($toastMessage !== ''): ?>
                        <div class="alert alert-<?= htmlspecialchars($toastType === 'danger' ? 'danger' : $toastType, ENT_QUOTES, 'UTF-8') ?> alert-dismissible fade show" role="alert">
                            <?= htmlspecialchars($toastMessage, ENT_QUOTES, 'UTF-8') ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <div class="students-card">
                        <div class="ay-card-header">
                            <div>
                                <p class="ay-card-title">Student List</p>
                                <p class="ay-card-subtitle">Search, review, edit, and manage student accounts.</p>
                            </div>
                            <div class="ay-toolbar">
                                <div id="yearFilterContainer">
                                    <select class="ay-year-select" id="yearFilter"
                                        onchange="filterByYear(this.value)" style="display:none;">
                                        <option value="">Current Year (Active)</option>
                                    </select>
                                </div>
                                <div class="ay-search-wrap">
                                    <i class="bi bi-search"></i>
                                    <input type="search" class="ay-search" id="searchInput"
                                        placeholder="Search student, LRN, guardian, or contact">
                                </div>
                                <a href="assets/templates/School_form_blank.xlsx"
                                   download="School_form_blank.xlsx"
                                   class="btn"
                                   style="background: #f0f6ff; color: #1248a8; border: 1.5px solid #b8d0fa; font-weight: 600; padding: 0.42rem 0.9rem; border-radius: 8px; display: inline-flex; align-items: center; gap: 0.35rem; text-decoration: none; transition: all 0.15s ease;"
                                   onmouseover="this.style.background='#e6f0ff'; this.style.borderColor='#8db5f7';"
                                   onmouseout="this.style.background='#f0f6ff'; this.style.borderColor='#b8d0fa';"
                                   title="Download blank SF1 template">
                                    <i class="bi bi-download"></i> Download Template
                                </a>
                                <button type="button" class="btn btn-ay btn-ay-import" onclick="openImportModal()">
                                    <i class="bi bi-file-earmark-arrow-up"></i> Import SF1
                                </button>
                                <a href="student_form.php" class="btn btn-ay btn-ay-primary">
                                    <i class="bi bi-plus-circle"></i> New Student
                                </a>
                            </div>
                        </div>

                        <div class="ay-card-body">
                            <div class="d-none d-md-block">
                                <table class="ay-table" id="studentTable">
                                    <thead>
                                        <tr>
                                            <th style="width:60px;">#</th>
                                            <th>LRN</th>
                                            <th>Name</th>
                                            <th>Grade</th>
                                            <th style="width:80px;">Age</th>
                                            <th style="width:100px;">Sex</th>
                                            <th>Guardian</th>
                                            <th>Contact</th>
                                            <th style="width:140px;">Status</th>
                                            <th style="width:150px;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="studentTableBody">
                                        <tr>
                                            <td colspan="10">
                                                <div class="ay-empty">
                                                    <i class="bi bi-hourglass-split"></i>
                                                    <p>Loading students...</p>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="d-block d-md-none p-3" id="studentCardView"></div>
                        </div>

                        <div class="ay-card-footer">
                            <div class="ay-footer-note" id="studentCountText"></div>
                            <ul class="ay-pagination" id="pagination"></ul>
                        </div>
                    </div>

                </div>
            </div>
        </main>
        <?php require_once("includes/footer.php"); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./js/adminlte.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>
    <script>
        const PHP_ACTIVE_YEAR_ID    = <?= $activeYearId ? json_encode($activeYearId) : 'null' ?>;
        const PHP_ACTIVE_YEAR_LABEL = <?= json_encode($activeYearLabel) ?>;
        const initialToastMessage   = <?= json_encode($toastMessage) ?>;

        let currentPage    = 1;
        let searchTerm     = '';
        let totalStudents  = 0;
        const rowsPerPage  = 10;
        let searchDebounce = null;
        let currentViewYear = '';
        let yearsLoaded    = false;

        function escapeHtml(v) {
            return String(v ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
        }

        function showAlert(message, type = 'success') {
            const cfg = {
                success : { title:'Success', color:'blue',   icon:'bi bi-check-circle-fill' },
                danger  : { title:'Error',   color:'red',    icon:'bi bi-exclamation-octagon-fill' },
                warning : { title:'Warning', color:'yellow', icon:'bi bi-exclamation-triangle-fill' },
                info    : { title:'Info',    color:'blue',   icon:'bi bi-info-circle-fill' }
            };
            const s = cfg[type] || cfg.success;
            iziToast.show({
                title:s.title, message, color:s.color, icon:s.icon, iconColor:'#fff', theme:'light',
                position:'topRight', timeout:4000, progressBar:true, close:true, pauseOnHover:true,
                drag:true, transitionIn:'fadeInDown', transitionOut:'fadeOutUp', maxWidth:420, zindex:10000
            });
        }

        async function fetchJson(url, options = {}) {
            const res = await fetch(url, options);
            const raw = await res.text();
            if (raw.trim().startsWith('<')) {
                window.location.href = 'login.php';
                throw new Error('Session expired. Redirecting to login...');
            }
            try { return JSON.parse(raw); }
            catch (e) { console.error('Non-JSON response:', raw); throw new Error('Server returned an invalid response.'); }
        }

        function getStatusBadge(status) {
            const key = String(status || '').trim().toUpperCase();
            const map = {
                'ENROLLED'   : { cls:'ay-badge-active',      label:'Enrolled' },
                'PROMOTED'   : { cls:'ay-badge-promoted',    label:'Promoted' },
                'RETAINED'   : { cls:'ay-badge-retained',    label:'Retained' },
                'DROPPED'    : { cls:'ay-badge-dropped',     label:'Dropped' },
                'TRANSFERRED': { cls:'ay-badge-transferred', label:'Transferred' },
                'GRADUATED'  : { cls:'ay-badge-graduated',   label:'Graduated' },
            };
            const s = map[key];
            if (!s) {
                if (!key) return `<span class="ay-badge ay-badge-inactive">Not Enrolled</span>`;
                const label = key.charAt(0) + key.slice(1).toLowerCase();
                return `<span class="ay-badge ay-badge-inactive">${escapeHtml(label)}</span>`;
            }
            return `<span class="ay-badge ${s.cls}">${s.label}</span>`;
        }

        function updateYearFilterDisplay() {
            const select = document.getElementById('yearFilter');
            if (!currentViewYear || String(currentViewYear) === String(PHP_ACTIVE_YEAR_ID)) {
                select.style.display = 'none';
            } else {
                select.style.display = '';
            }
        }

        function populateYearDropdown(allYears, viewingYear) {
            if (yearsLoaded) return;
            yearsLoaded = true;
            const select = document.getElementById('yearFilter');
            let html = '<option value="">Current Year (Active)</option>';
            (allYears || []).forEach(y => {
                if (Number(y.is_active) === 1) return;
                const selected = currentViewYear && String(y.id) === String(currentViewYear) ? 'selected' : '';
                html += `<option value="${y.id}" ${selected}>S.Y. ${escapeHtml(y.year_label)}</option>`;
            });
            select.innerHTML = html;
            updateYearFilterDisplay();
        }

        function filterByYear(yearId) {
            currentViewYear = yearId;
            updateYearFilterDisplay();
            loadStudents(1, searchTerm);
        }

        async function loadStudents(page = 1, search = '') {
            currentPage = page;
            searchTerm  = search;

            document.getElementById('studentTableBody').innerHTML =
                `<tr><td colspan="10"><div class="ay-empty"><i class="bi bi-hourglass-split"></i><p>Loading students...</p></div></td></tr>`;
            document.getElementById('studentCardView').innerHTML = '';

            try {
                let url = `api/student/read.php?p=${page}&s=${encodeURIComponent(search)}`;
                if (currentViewYear) url += `&year_id=${encodeURIComponent(currentViewYear)}`;

                const data = await fetchJson(url);

                if (!data.success) {
                    showAlert(data.error || 'Failed to load students.', 'danger');
                    document.getElementById('studentTableBody').innerHTML =
                        `<tr><td colspan="10"><div class="ay-empty"><i class="bi bi-exclamation-triangle"></i><p>${escapeHtml(data.error||'Failed to load students.')}</p></div></td></tr>`;
                    return;
                }

                totalStudents = Number(data.total || 0);
                populateYearDropdown(data.all_years, data.viewing_year);
                renderStudents(data.students || [], data.page || 1, data.pages || 1);
            } catch (e) {
                showAlert(e.message, 'danger');
                document.getElementById('studentTableBody').innerHTML =
                    `<tr><td colspan="10"><div class="ay-empty"><i class="bi bi-exclamation-triangle"></i><p>${escapeHtml(e.message)}</p></div></td></tr>`;
            }
        }

        function renderStudents(list, page, pages) {
            const tbody      = document.getElementById('studentTableBody');
            const cardView   = document.getElementById('studentCardView');
            const pagination = document.getElementById('pagination');
            const countEl    = document.getElementById('studentCountText');

            if (!list.length) {
                const empty = `<div class="ay-empty"><i class="bi bi-people"></i><p>${searchTerm.trim()?'No students matched your search.':'No students found.'}</p></div>`;
                tbody.innerHTML = `<tr><td colspan="10">${empty}</td></tr>`;
                cardView.innerHTML = empty;
                pagination.innerHTML = '';
                if (countEl) countEl.textContent = 'No students to display.';
                return;
            }

            const offset = (page - 1) * rowsPerPage;
            if (countEl) countEl.textContent =
                `Showing ${offset+1}-${offset+list.length} of ${totalStudents} student${totalStudents===1?'':'s'}`;

            tbody.innerHTML = list.map((s, i) => {
                const isActive  = Number(s.is_active) === 1;
                const fullName  = [s.fname, s.mname, s.lname].filter(Boolean).join(' ');
                const status    = s.enrollment_status || (isActive ? 'ENROLLED' : null);
                const toggleBtn = isActive
                    ? `<button class="btn-deactivate is-active-state" onclick='toggleStudent(${s.id},0,${JSON.stringify(fullName)})' title="Archive" aria-label="Archive"><i class="bi bi-archive"></i></button>`
                    : `<button class="btn-deactivate is-inactive-state" onclick='toggleStudent(${s.id},1,${JSON.stringify(fullName)})' title="Restore" aria-label="Restore"><i class="bi bi-arrow-counterclockwise"></i></button>`;
                return `<tr>
                    <td style="text-align:center;"><span class="row-num">${offset+i+1}</span></td>
                    <td style="text-align:center;">${escapeHtml(s.lrn||'-')}</td>
                    <td><div class="student-name">${escapeHtml(fullName||'-')}</div></td>
                    <td style="text-align:center;">${s.grade_level_name ? escapeHtml(s.grade_level_name) : '<span style="color:var(--ay-text-dim);">-</span>'}</td>
                    <td style="text-align:center;">${escapeHtml(s.age||'-')}</td>
                    <td style="text-align:center;">${escapeHtml(s.gender||'-')}</td>
                    <td>${escapeHtml(s.guardian_name||'-')}</td>
                    <td style="text-align:center;">${s.guardian_contact_num
                        ? `<a href="tel:${escapeHtml(s.guardian_contact_num)}">${escapeHtml(s.guardian_contact_num)}</a>`
                        : '<span style="color:var(--ay-text-dim);">-</span>'}</td>
                    <td style="text-align:center;">${getStatusBadge(status)}</td>
                    <td style="text-align:center;">
                        <div class="ay-action-group">
                            <a href="student_form.php?id=${encodeURIComponent(s.id)}" class="btn btn-ay btn-ay-edit" title="Edit" aria-label="Edit">
                                <i class="bi bi-pencil-square"></i>
                            </a>
                            ${toggleBtn}
                        </div>
                    </td>
                </tr>`;
            }).join('');

            cardView.innerHTML = list.map((s, i) => {
                const isActive  = Number(s.is_active) === 1;
                const fullName  = [s.fname, s.mname, s.lname].filter(Boolean).join(' ');
                const status    = s.enrollment_status || (isActive ? 'ENROLLED' : null);
                const toggleBtn = isActive
                    ? `<button class="btn-deactivate is-active-state" onclick='toggleStudent(${s.id},0,${JSON.stringify(fullName)})' title="Archive" aria-label="Archive"><i class="bi bi-archive"></i></button>`
                    : `<button class="btn-deactivate is-inactive-state" onclick='toggleStudent(${s.id},1,${JSON.stringify(fullName)})' title="Restore" aria-label="Restore"><i class="bi bi-arrow-counterclockwise"></i></button>`;
                return `<div class="ay-mobile-card">
                    <div class="ay-mobile-card-header">
                        <div>
                            <div class="ay-mobile-card-title">${offset+i+1}. ${escapeHtml(fullName||'-')}</div>
                            <div class="ay-mobile-card-subtitle">LRN: ${escapeHtml(s.lrn||'-')}</div>
                        </div>
                        ${getStatusBadge(status)}
                    </div>
                    <div class="ay-mobile-card-body">
                        <div class="ay-mobile-row"><span class="ay-mobile-label">Grade</span><span>${escapeHtml(s.grade_level_name||'-')}</span></div>
                        <div class="ay-mobile-row"><span class="ay-mobile-label">Age / Sex</span><span>${escapeHtml(s.age||'-')} · ${escapeHtml(s.gender||'-')}</span></div>
                        <div class="ay-mobile-row"><span class="ay-mobile-label">Guardian</span><span>${escapeHtml(s.guardian_name||'-')}</span></div>
                        <div class="ay-mobile-row"><span class="ay-mobile-label">Contact</span><span>${s.guardian_contact_num
                            ? `<a href="tel:${escapeHtml(s.guardian_contact_num)}">${escapeHtml(s.guardian_contact_num)}</a>` : '-'}</span></div>
                    </div>
                    <div class="ay-mobile-actions">
                        <a href="student_form.php?id=${encodeURIComponent(s.id)}" class="btn btn-ay btn-ay-edit" title="Edit" aria-label="Edit" style="flex:0 0 36px;width:36px;height:36px;padding:0;display:inline-flex;align-items:center;justify-content:center;">
                            <i class="bi bi-pencil-square"></i>
                        </a>
                        ${toggleBtn}
                    </div>
                </div>`;
            }).join('');

            // Pagination
            const maxPages = 7;
            const half = Math.floor(maxPages / 2);
            let startPage = Math.max(1, page - half);
            let endPage = Math.min(pages, startPage + maxPages - 1);
            if (endPage - startPage < maxPages - 1) startPage = Math.max(1, endPage - maxPages + 1);

            let html = `<li class="ay-page-item ${page<=1?'disabled':''}">
                <a class="ay-page-link" onclick="${page>1?`loadStudents(${page-1},searchTerm)`:'return false;'}">Previous</a></li>`;

            if (startPage > 1) {
                html += `<li class="ay-page-item"><a class="ay-page-link" onclick="loadStudents(1,searchTerm)">1</a></li>`;
                if (startPage > 2) html += `<li class="ay-page-item disabled"><a class="ay-page-link">…</a></li>`;
            }
            for (let n = startPage; n <= endPage; n++) {
                html += `<li class="ay-page-item ${n===page?'active':''}">
                    <a class="ay-page-link" onclick="loadStudents(${n},searchTerm)">${n}</a></li>`;
            }
            if (endPage < pages) {
                if (endPage < pages - 1) html += `<li class="ay-page-item disabled"><a class="ay-page-link">…</a></li>`;
                html += `<li class="ay-page-item"><a class="ay-page-link" onclick="loadStudents(${pages},searchTerm)">${pages}</a></li>`;
            }
            html += `<li class="ay-page-item ${page>=pages?'disabled':''}">
                <a class="ay-page-link" onclick="${page<pages?`loadStudents(${page+1},searchTerm)`:'return false;'}">Next</a></li>`;

            pagination.innerHTML = html;
        }

        function toggleStudent(id, newState, studentName = 'this student') {
            const action = newState === 1 ? 'restore' : 'archive';
            iziToast.question({
                timeout:20000, close:false, overlay:true, displayMode:'once',
                id:'student-confirm', zindex:9999, title:'Confirm Action',
                message:`Are you sure you want to ${action} ${escapeHtml(studentName)}?`,
                position:'center', color:'blue', icon:'bi bi-question-circle-fill',
                buttons:[
                    ['<button><b>Yes</b></button>', async function(instance, toast) {
                        instance.hide({transitionOut:'fadeOut'}, toast, 'button');
                        try {
                            const res = await fetchJson('api/student/toggle.php?id='+encodeURIComponent(id));
                            if (res.success) {
                                showAlert(res.message||`Student ${action}d successfully.`, 'success');
                                loadStudents(currentPage, searchTerm);
                            } else {
                                showAlert(res.message||res.error||'Toggle failed.', 'danger');
                            }
                        } catch(e) { showAlert(e.message,'danger'); }
                    }, true],
                    ['<button>No</button>', function(instance, toast) {
                        instance.hide({transitionOut:'fadeOut'}, toast, 'button');
                    }]
                ]
            });
        }

        document.getElementById('searchInput').addEventListener('input', function(e) {
            clearTimeout(searchDebounce);
            searchDebounce = setTimeout(() => loadStudents(1, e.target.value.trim()), 350);
        });

        if (initialToastMessage) {
            if (window.history && window.history.replaceState) {
                const cleanUrl = window.location.pathname + window.location.hash;
                window.history.replaceState({}, document.title, cleanUrl);
            }
        }

        loadStudents(1, '');
    </script>

    <script src="https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js"></script>

    <div class="modal fade sf1-modal--transition" id="importModal" tabindex="-1" aria-labelledby="importModalLabel" aria-hidden="true" data-bs-backdrop="false">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable w-100" style="max-width: 1140px;">
            <div class="modal-content sf1-modal-content">

                <div class="sf1-modal-header">
                    <div class="sf1-modal-icon"><i class="bi bi-file-earmark-spreadsheet-fill"></i></div>
                    <div>
                        <h5 class="sf1-modal-title" id="importModalLabel">Import Students — DepEd SF1 Excel</h5>
                        <p class="sf1-modal-subtitle">Upload your SF1 file. Grade, Track &amp; Section are auto-detected from the file.</p>
                    </div>
                    <button type="button" class="sf1-close-btn" data-bs-dismiss="modal"><i class="bi bi-x-lg"></i></button>
                </div>

                <div class="modal-body sf1-modal-body">

                    <div id="sf1Step1">
                        <div class="sf1-info-banner">
                            <i class="bi bi-info-circle-fill"></i>
                            <div>
                                <strong>What gets auto-detected from the SF1 header</strong>
                                <span>School Year (cell P6) &nbsp;·&nbsp; Grade Level (cell U6) &nbsp;·&nbsp; Section (cell X6) &nbsp;·&nbsp;
                                    Track for SHS (detected from Grade Level text, e.g. "Grade 11 - Academic") &nbsp;·&nbsp;
                                    If no track is found in the file, you can pick it manually below.</span>
                            </div>
                        </div>

                        <div class="sf1-dropzone" id="sf1Dropzone">
                            <i class="bi bi-cloud-upload sf1-drop-icon"></i>
                            <p class="sf1-drop-title">Drag &amp; drop your SF1 Excel file here</p>
                            <p class="sf1-drop-sub">or click to browse &nbsp;·&nbsp; .xlsx or .xls accepted</p>
                            <input type="file" id="sf1FileInput" accept=".xlsx,.xls,.ods" hidden>
                        </div>
                        <div class="sf1-file-chosen d-none" id="sf1FileChosen">
                            <i class="bi bi-file-earmark-excel-fill" style="color:#1d6f42;font-size:1.1rem;"></i>
                            <span id="sf1FileChosenName" style="font-weight:600;"></span>
                            <button type="button" class="sf1-clear-btn" onclick="sf1ClearFile()"><i class="bi bi-x"></i></button>
                        </div>

                        <div class="sf1-detected-card d-none" id="sf1DetectedCard">
                            <div class="sf1-detected-title"><i class="bi bi-magic me-1"></i>Auto-detected from SF1 Header</div>
                            <div class="sf1-detected-grid">
                                <div class="sf1-detected-item">
                                    <span class="sf1-detected-label">School Year</span>
                                    <span class="sf1-detected-val" id="sf1DetectedYear">—</span>
                                </div>
                                <div class="sf1-detected-item">
                                    <span class="sf1-detected-label">Grade Level</span>
                                    <span class="sf1-detected-val" id="sf1DetectedGrade">—</span>
                                </div>
                                <div class="sf1-detected-item" id="sf1DetectedStrandItem">
                                    <span class="sf1-detected-label">Track</span>
                                    <span class="sf1-detected-val" id="sf1DetectedStrand">—</span>
                                </div>
                                <div class="sf1-detected-item">
                                    <span class="sf1-detected-label">Section</span>
                                    <span class="sf1-detected-val" id="sf1DetectedSection">—</span>
                                </div>
                            </div>
                            <div class="sf1-detected-warn d-none" id="sf1DetectedWarn">
                                <i class="bi bi-exclamation-triangle-fill me-1"></i>
                                <span id="sf1DetectedWarnMsg"></span>
                            </div>
                        </div>

                        <hr class="sf1-hr">

                        <div class="sf1-override-row">
                            <div class="sf1-field">
                                <label class="sf1-label">
                                    Grade Level Override
                                    <span class="sf1-hint-inline">(only if auto-detect is wrong)</span>
                                </label>
                                <select id="sf1GradeLevel" class="sf1-select">
                                    <option value="">— Use auto-detected —</option>
                                </select>
                            </div>
                            <div class="sf1-field sf1-field--collapsible sf1-field--hidden" id="sf1StrandWrap" style="display:none;">
                                <label class="sf1-label">
                                    Track Override
                                    <span class="sf1-hint-inline">(only if auto-detect is wrong)</span>
                                </label>
                                <select id="sf1Strand" class="sf1-select">
                                    <option value="">— Use auto-detected —</option>
                                    <option value="Academic">Academic Track</option>
                                    <option value="Technical-Professional (Tech-Pro)">Technical-Professional (Tech-Pro)</option>
                                </select>
                            </div>
                            <div class="sf1-field sf1-field--collapsible sf1-field--hidden" id="sf1ClusterWrap" style="display:none;">
                                <label class="sf1-label">
                                    Cluster Override
                                    <span class="sf1-hint-inline">(only if auto-detect is wrong)</span>
                                </label>
                                <select id="sf1Cluster" class="sf1-select">
                                    <option value="">— Use auto-detected —</option>
                                    <?php foreach ($activeClusters as $cl): ?>
                                        <option value="<?= (int) $cl['id'] ?>"><?= htmlspecialchars($cl['cluster_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="sf1-field">
                                <label class="sf1-label">
                                    Data starts on row
                                    <span class="sf1-hint-inline">(default 10 for this template)</span>
                                </label>
                                <input type="number" id="sf1HeaderRow" class="sf1-input" value="10" min="1" max="100">
                            </div>
                            <div class="sf1-field" style="align-self:flex-end;">
                                <button class="sf1-btn sf1-btn-green w-100" onclick="sf1Preview()" id="sf1PreviewBtn" disabled>
                                    <i class="bi bi-eye me-1"></i> Preview Data
                                </button>
                            </div>
                        </div>
                    </div>

                    <div id="sf1Step2" class="d-none">
                        <div class="sf1-preview-bar">
                            <div id="sf1PreviewMeta" class="sf1-preview-meta"></div>
                            <button class="sf1-btn sf1-btn-outline" onclick="sf1BackToStep1()">
                                <i class="bi bi-arrow-left me-1"></i> Change File
                            </button>
                        </div>
                        <div class="sf1-confirm-bar" id="sf1ConfirmBar"></div>
                        <div class="sf1-preview-scroll">
                            <table class="sf1-preview-table">
                                <thead id="sf1PreviewHead"></thead>
                                <tbody id="sf1PreviewBody"></tbody>
                            </table>
                        </div>
                        <p class="sf1-preview-note">
                            <i class="bi bi-exclamation-circle me-1"></i>
                            Rows with a <strong style="color:#c0392b;">red LRN</strong> already exist in the database and will be skipped.
                            Click <strong>Import Now</strong> to save all valid rows.
                        </p>
                    </div>

                    <div id="sf1Step3" class="d-none">
                        <div class="sf1-progress-wrap">
                            <div class="sf1-spinner"></div>
                            <p class="sf1-progress-title">Importing students…</p>
                            <p class="sf1-progress-sub">Sending data to server, please wait.</p>
                        </div>
                    </div>

                    <div id="sf1Step4" class="d-none">
                        <div id="sf1ResultSummary" class="sf1-result-summary"></div>
                        <div id="sf1DupList" class="sf1-issue-list sf1-issue-dup d-none"></div>
                        <div id="sf1ErrList" class="sf1-issue-list sf1-issue-err d-none"></div>
                    </div>

                </div>

                <div class="sf1-modal-footer">
                    <button type="button" class="sf1-btn sf1-btn-outline" data-bs-dismiss="modal" id="sf1CancelBtn">Cancel</button>
                    <button type="button" class="sf1-btn sf1-btn-blue d-none" id="sf1ImportBtn" onclick="sf1DoImport()">
                        <i class="bi bi-upload me-1"></i> Import Now
                    </button>
                    <button type="button" class="sf1-btn sf1-btn-green d-none" id="sf1DoneBtn" onclick="sf1Finish()">
                        <i class="bi bi-check2 me-1"></i> Done
                    </button>
                </div>

            </div>
        </div>
    </div>

    <script>
        /* ── SF1 IMPORT state ──────────────────────────────────────────── */
        let sf1File       = null;
        let sf1ParsedRows = [];
        let sf1ExistingLRN = new Set();
        let sf1GradeList  = [];
        let sf1Detected   = { gradeText:'', gradeId:0, gradeName:'', strand:'', section:'', schoolYear:'' };

        const STRANDS = ['TECHNICAL-PROFESSIONAL (TECH-PRO)', 'TECHNICAL-PROFESSIONAL', 'ACADEMIC', 'STEM','ABM','HUMSS','GAS','TVL-ICT','TVL','HE','IA','AFA'];

        (function sf1LoadGrades() {
            fetch('api/student/grades-list.php')
                .then(r => r.json())
                .then(d => {
                    if (!d.success) return;
                    sf1GradeList = d.grades || [];
                    const sel = document.getElementById('sf1GradeLevel');
                    sf1GradeList.forEach(g => {
                        const o = document.createElement('option');
                        o.value = g.id;
                        o.textContent = g.grade_level_name;
                        sel.appendChild(o);
                    });
                    if (sf1Detected && !sf1Detected.gradeId && sf1Detected.gradeText) {
                        const norm = t => t.toLowerCase().replace(/\s+/g, '');
                        const detectedGradeText = sf1Detected.gradeName && sf1Detected.gradeName !== '(not found)'
                            ? sf1Detected.gradeName
                            : sf1Detected.gradeText;
                        const detectedGrade = sf1GradeList.find(g =>
                            norm(g.grade_level_name) === norm(detectedGradeText)
                        ) || sf1GradeList.find(g =>
                            norm(g.grade_level_name).includes(norm(detectedGradeText)) ||
                            norm(detectedGradeText).includes(norm(g.grade_level_name))
                        );
                        if (detectedGrade) {
                            sf1Detected.gradeId = detectedGrade.id;
                            sf1Detected.gradeName = detectedGrade.grade_level_name;
                            sf1ShowDetected();
                        }
                    }
                    if (sf1Detected && sf1Detected.gradeId > 0) {
                        const gradeSelect = document.getElementById('sf1GradeLevel');
                        if (gradeSelect && gradeSelect.querySelector('option[value="' + sf1Detected.gradeId + '"]')) {
                            gradeSelect.value = String(sf1Detected.gradeId);
                            gradeSelect.dispatchEvent(new Event('change'));
                        }
                    }
                }).catch(() => {});
        })();

        document.getElementById('sf1GradeLevel').addEventListener('change', function() {
            const isSHS = ['11','12'].includes(this.value);
            sf1SetWrapperVisible(document.getElementById('sf1StrandWrap'), isSHS);
            sf1SetWrapperVisible(document.getElementById('sf1ClusterWrap'), isSHS);
            if (!isSHS) {
                document.getElementById('sf1Strand').value = '';
                document.getElementById('sf1Cluster').value = '';
            }
        });

        const sf1Dz = document.getElementById('sf1Dropzone');
        const sf1Fi = document.getElementById('sf1FileInput');

        function sf1SetWrapperVisible(el, visible) {
            if (!el) return;
            if (visible) {
                el.style.display = '';
                requestAnimationFrame(() => {
                    el.classList.remove('sf1-field--hidden');
                });
            } else {
                el.classList.add('sf1-field--hidden');
                window.setTimeout(() => {
                    if (el.classList.contains('sf1-field--hidden')) {
                        el.style.display = 'none';
                    }
                }, 180);
            }
        }

        sf1Dz.addEventListener('click',     () => sf1Fi.click());
        sf1Dz.addEventListener('dragover',  e  => { e.preventDefault(); sf1Dz.classList.add('drag-over'); });
        sf1Dz.addEventListener('dragleave', () => sf1Dz.classList.remove('drag-over'));
        sf1Dz.addEventListener('drop',      e  => {
            e.preventDefault();
            sf1Dz.classList.remove('drag-over');
            if (e.dataTransfer.files[0]) sf1HandleFile(e.dataTransfer.files[0]);
        });
        sf1Fi.addEventListener('change', () => { if (sf1Fi.files[0]) sf1HandleFile(sf1Fi.files[0]); });

        function sf1HandleFile(file) {
            const ext = file.name.split('.').pop().toLowerCase();
            if (!['xlsx','xls','ods'].includes(ext)) {
                showAlert('Only .xlsx, .xls, or .ods files are accepted.', 'danger');
                return;
            }
            sf1File = file;
            document.getElementById('sf1FileChosenName').textContent = file.name;
            document.getElementById('sf1FileChosen').classList.remove('d-none');
            sf1Dz.classList.add('d-none');
            sf1ReadHeader(file);
        }

        function sf1ReadHeader(file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    const wb = XLSX.read(e.target.result, { type:'array', cellDates:true });
                    const ws = wb.Sheets[wb.SheetNames[0]];

                    const getCellVal = (r, c) => {
                        const cell = ws[XLSX.utils.encode_cell({ r, c })];
                        if (!cell) return '';
                        return String(cell.w !== undefined ? cell.w : (cell.v ?? '')).trim();
                    };

                    const gradeRaw   = getCellVal(5, 20);
                    const sectionRaw = getCellVal(5, 23);
                    const yearRaw    = getCellVal(5, 15);

                    const gradeNormalized = gradeRaw === ''
                        ? ''
                        : /^grade\s/i.test(gradeRaw)
                            ? gradeRaw.replace(/^grade\s*/i, 'Grade ').trim()
                            : 'Grade ' + gradeRaw.trim();

                    let detectedStrand = '';
                    let cleanGradeText = gradeNormalized;

                    for (const s of STRANDS) {
                        const re = new RegExp('[\\-–\\s]+' + s + '(\\s|$)', 'i');
                        if (re.test(gradeNormalized)) {
                            detectedStrand = s.toUpperCase();
                            cleanGradeText = gradeNormalized.replace(re, '').trim();
                            break;
                        }
                    }

                    let matchedGradeId = 0;
                    let matchedGradeName = '';
                    if (cleanGradeText && sf1GradeList.length) {
                        const norm = t => t.toLowerCase().replace(/\s+/g, '');
                        for (const g of sf1GradeList) {
                            if (norm(g.grade_level_name) === norm(cleanGradeText)) {
                                matchedGradeId = g.id;
                                matchedGradeName = g.grade_level_name;
                                break;
                            }
                        }
                        if (!matchedGradeId) {
                            for (const g of sf1GradeList) {
                                if (norm(g.grade_level_name).includes(norm(cleanGradeText)) ||
                                    norm(cleanGradeText).includes(norm(g.grade_level_name))) {
                                    matchedGradeId = g.id;
                                    matchedGradeName = g.grade_level_name;
                                    break;
                                }
                            }
                        }
                    }

                    sf1Detected = {
                        gradeText  : gradeNormalized,
                        gradeId    : matchedGradeId,
                        gradeName  : matchedGradeName || cleanGradeText || '(not found)',
                        strand     : detectedStrand,
                        section    : sectionRaw,
                        schoolYear : yearRaw,
                    };

                    sf1ShowDetected();
                    if (sf1Detected.gradeId > 0) {
                        const gradeSelect = document.getElementById('sf1GradeLevel');
                        if (gradeSelect && gradeSelect.querySelector('option[value="' + sf1Detected.gradeId + '"]')) {
                            gradeSelect.value = String(sf1Detected.gradeId);
                            gradeSelect.dispatchEvent(new Event('change'));
                        }
                    }
                } catch(err) {
                    showAlert('Could not read SF1 header: ' + err.message, 'danger');
                }
            };
            reader.readAsArrayBuffer(file);
        }

        function sf1ShowDetected() {
            const card = document.getElementById('sf1DetectedCard');
            card.classList.remove('d-none');

            document.getElementById('sf1DetectedYear').textContent  = sf1Detected.schoolYear || '—';
            document.getElementById('sf1DetectedGrade').textContent = sf1Detected.gradeName  || sf1Detected.gradeText || '—';
            document.getElementById('sf1DetectedStrand').textContent = sf1Detected.strand || '(none — not SHS or not found)';
            document.getElementById('sf1DetectedSection').textContent = sf1Detected.section || '—';

            const isSHS = sf1Detected.strand !== '' || [11, 12].includes(sf1Detected.gradeId);
            document.getElementById('sf1DetectedStrandItem').style.display = isSHS ? '' : 'none';
            document.querySelector('.sf1-detected-grid').style.gridTemplateColumns =
                isSHS ? 'repeat(4,1fr)' : 'repeat(3,1fr)';
            sf1SetWrapperVisible(document.getElementById('sf1StrandWrap'), isSHS);
            sf1SetWrapperVisible(document.getElementById('sf1ClusterWrap'), isSHS);

            const warnEl  = document.getElementById('sf1DetectedWarn');
            const warnMsg = document.getElementById('sf1DetectedWarnMsg');
            if (!sf1Detected.gradeId && sf1Detected.gradeText) {
                warnEl.classList.remove('d-none');
                warnMsg.textContent = `Grade "${sf1Detected.gradeText}" was not found in your database. Please use the Grade Level Override dropdown below.`;
            } else if (!sf1Detected.gradeText) {
                warnEl.classList.remove('d-none');
                warnMsg.textContent = 'No Grade Level found in SF1 header (cell U6 is empty). Please select one manually below.';
            } else {
                warnEl.classList.add('d-none');
            }

            document.getElementById('sf1PreviewBtn').disabled = false;
        }

        function sf1ResolveFinal() {
            const overrideGrade  = document.getElementById('sf1GradeLevel').value;
            const overrideStrand = document.getElementById('sf1Strand').value;
            return {
                gradeId : overrideGrade  ? parseInt(overrideGrade)  : sf1Detected.gradeId,
                strand  : overrideStrand ? overrideStrand           : sf1Detected.strand,
                section : sf1Detected.section,
            };
        }

        function sf1Preview() {
            if (!sf1File) { showAlert('Please select a file first.', 'warning'); return; }

            const { gradeId } = sf1ResolveFinal();
            if (!gradeId) {
                showAlert('Grade Level could not be detected or selected. Use the override dropdown.', 'warning');
                return;
            }

            const startRow = Math.max(1, parseInt(document.getElementById('sf1HeaderRow').value, 10) || 10);

            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    const wb = XLSX.read(e.target.result, { type:'array', cellDates:true });
                    const ws = wb.Sheets[wb.SheetNames[0]];

                    const range = XLSX.utils.decode_range(ws['!ref'] || 'A1');
                    sf1ParsedRows = [];

                    const getCell = (r, c) => {
                        const cell = ws[XLSX.utils.encode_cell({ r, c })];
                        if (!cell) return '';
                        if (cell.t === 'd' || cell.v instanceof Date) {
                            const d = cell.v instanceof Date ? cell.v : new Date(cell.v);
                            if (isNaN(d)) return '';
                            return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
                        }
                        if (cell.t === 'n' && c === 7) {
                            try {
                                const jd = XLSX.SSF.parse_date_code(cell.v);
                                if (jd) return `${jd.y}-${String(jd.m).padStart(2,'0')}-${String(jd.d).padStart(2,'0')}`;
                            } catch(_) {}
                        }
                        return String(cell.w !== undefined ? cell.w : (cell.v ?? '')).trim();
                    };

                    const splitName = raw => {
                        if (!raw) return { lname:'', fname:'', mname:'' };
                        const parts = raw.split(',');
                        const lname = (parts[0]||'').trim();
                        const rest  = (parts[1]||'').trim().split(/\s+/);
                        return { lname, fname:rest[0]||'', mname:rest.slice(1).join(' ') };
                    };

                    // --- Metadata-adjacent detection: Track/Cluster labels on metadata rows ---
                    // Fallback only: existing header-column scan below will still win because we
                    // only set the dropdown when it is currently empty.
                    const findLabelValue = (labelRegex) => {
                        for (let r = range.s.r; r < startRow - 1 && r <= range.e.r; r++) {
                            for (let c = range.s.c; c <= range.e.c; c++) {
                                const label = String(getCell(r, c)).trim().toLowerCase();
                                if (!labelRegex.test(label)) continue;
                                for (let cc = c + 1; cc <= range.e.c; cc++) {
                                    const v = getCell(r, cc);
                                    if (v !== '') return String(v).trim();
                                }
                            }
                        }
                        return '';
                    };
                    const normalizeMeta = value => String(value).trim().toLowerCase().replace(/\s+/g, ' ');

                    const metaTrack   = findLabelValue(/^track$|^strand$/);
                    const metaCluster = findLabelValue(/^cluster$/);

                    if (metaTrack && !document.getElementById('sf1Strand').value) {
                        const trackOption = Array.from(document.getElementById('sf1Strand').options)
                            .slice(1)
                            .find(option => [option.value, option.textContent]
                                .some(v => normalizeMeta(v) === normalizeMeta(metaTrack)));
                        if (trackOption) document.getElementById('sf1Strand').value = trackOption.value;
                    }
                    if (metaCluster && !document.getElementById('sf1Cluster').value) {
                        const clusterOption = Array.from(document.getElementById('sf1Cluster').options)
                            .slice(1)
                            .find(option => normalizeMeta(option.textContent) === normalizeMeta(metaCluster));
                        if (clusterOption) document.getElementById('sf1Cluster').value = clusterOption.value;
                    }

                    const detectedColumns = { track: -1, cluster: -1 };
                    const normalizeHeader = value => String(value).trim().toLowerCase().replace(/[^a-z]+/g, ' ');
                    for (let headerRow = range.s.r; headerRow < startRow - 1 && headerRow <= range.e.r; headerRow++) {
                        for (let c = range.s.c; c <= range.e.c; c++) {
                            const label = normalizeHeader(getCell(headerRow, c));
                            if (/\b(track|strand|curriculum)\b/.test(label)) detectedColumns.track = c;
                            if (/\bcluster\b/.test(label)) detectedColumns.cluster = c;
                        }
                    }

                    const detectedValues = { track: new Set(), cluster: new Set() };
                    for (let r = startRow - 1; r <= range.e.r; r++) {
                        if (getCell(r, 1).replace(/\D/g, '').length < 10) continue;
                        if (detectedColumns.track >= 0) {
                            const value = getCell(r, detectedColumns.track);
                            if (value) detectedValues.track.add(value.trim());
                        }
                        if (detectedColumns.cluster >= 0) {
                            const value = getCell(r, detectedColumns.cluster);
                            if (value) detectedValues.cluster.add(value.trim());
                        }
                    }

                    const normalizeOverride = value => String(value).trim().toLowerCase().replace(/\s+/g, ' ');
                    if (detectedValues.track.size === 1) {
                        const detectedTrack = Array.from(detectedValues.track)[0];
                        const trackOption = Array.from(document.getElementById('sf1Strand').options)
                            .slice(1)
                            .find(option => [option.value, option.textContent]
                                .some(value => normalizeOverride(value) === normalizeOverride(detectedTrack)));
                        if (trackOption) document.getElementById('sf1Strand').value = trackOption.value;
                    }
                    if (detectedValues.cluster.size === 1) {
                        const detectedCluster = normalizeOverride(Array.from(detectedValues.cluster)[0]);
                        const clusterOption = Array.from(document.getElementById('sf1Cluster').options)
                            .slice(1)
                            .find(option => normalizeOverride(option.textContent) === detectedCluster);
                        if (clusterOption) document.getElementById('sf1Cluster').value = clusterOption.value;
                    }

                    for (let r = startRow - 1; r <= range.e.r; r++) {
                        const lrn = getCell(r, 1).replace(/\D/g, '');
                        if (lrn.length < 10) continue;

                        const { lname, fname, mname } = splitName(getCell(r, 2));

                        sf1ParsedRows.push({
                            lrn      : lrn.padStart(12, '0'),
                            lname, fname, mname,
                            sex      : getCell(r, 6),
                            birthdate: getCell(r, 7),
                            street   : getCell(r, 14),
                            barangay : getCell(r, 15),
                            city     : getCell(r, 16),
                            province : getCell(r, 17),
                            father   : getCell(r, 19),
                            mother   : getCell(r, 21),
                            guardian : getCell(r, 23),
                            contact  : getCell(r, 25),
                        });
                    }

                    const seenLRNs = new Map();
                    const dupes = [];
                    sf1ParsedRows.forEach((row, idx) => {
                        const key = row.lrn;
                        if (seenLRNs.has(key)) {
                            dupes.push({ lrn: key, firstRow: seenLRNs.get(key) + 1, againRow: idx + 1 });
                        } else {
                            seenLRNs.set(key, idx);
                        }
                    });
                    if (dupes.length) {
                        const list = dupes
                            .map(d => '• LRN ' + d.lrn + ' — rows ' + d.firstRow + ' and ' + d.againRow)
                            .join('\n');
                        showAlert(
                            'Duplicate LRNs found inside the file:\n\n' + list +
                            '\n\nFix the file and re-upload. Import cancelled.',
                            'danger'
                        );
                        return;
                    }

                    if (!sf1ParsedRows.length) {
                        showAlert('No valid student rows found. Check the "Data starts on row" setting.', 'warning');
                        return;
                    }

                    sf1RenderPreview();
                } catch(err) {
                    showAlert('Could not read the Excel file: ' + err.message, 'danger');
                }
            };
            reader.readAsArrayBuffer(sf1File);
        }

        function sf1RenderPreview() {
            const { gradeId, strand, section } = sf1ResolveFinal();
            const gradeLabel = sf1GradeList.find(g => g.id == gradeId)?.grade_level_name ||
                               sf1Detected.gradeName || `Grade ID ${gradeId}`;

            document.getElementById('sf1ConfirmBar').innerHTML = `
                <i class="bi bi-check-circle-fill"></i>
                <strong>Importing as:</strong>
                <span class="sf1-confirm-chip"><i class="bi bi-calendar3 me-1"></i>${esc(sf1Detected.schoolYear||'(active year)')}</span>
                <span class="sf1-confirm-chip">${esc(gradeLabel)}</span>
                ${strand  ? `<span class="sf1-confirm-chip">${esc(strand)}</span>` : ''}
                ${section ? `<span class="sf1-confirm-chip">Section: ${esc(section)}</span>` : ''}`;

            const cols = ['#','LRN','Last Name','First Name','Middle Name',
                          'Sex','Birthdate','Street','Barangay','City',
                          'Province','Father','Mother','Guardian','Contact'];
            document.getElementById('sf1PreviewHead').innerHTML =
                '<tr>'+cols.map(c=>`<th>${c}</th>`).join('')+'</tr>';

            let dupCount = 0;
            document.getElementById('sf1PreviewBody').innerHTML = sf1ParsedRows.map((row, i) => {
                const isDup = sf1ExistingLRN.has(row.lrn);
                if (isDup) dupCount++;
                return `<tr>
                    <td style="color:var(--ay-text-dim);font-weight:600;">${i+1}</td>
                    <td class="${isDup?'sf1-lrn-dup':''}">${esc(row.lrn)}</td>
                    <td>${esc(row.lname)}</td><td>${esc(row.fname)}</td><td>${esc(row.mname)}</td>
                    <td>${esc(row.sex)}</td><td>${esc(row.birthdate)}</td>
                    <td>${esc(row.street)}</td><td>${esc(row.barangay)}</td>
                    <td>${esc(row.city)}</td><td>${esc(row.province)}</td>
                    <td>${esc(row.father)}</td><td>${esc(row.mother)}</td>
                    <td>${esc(row.guardian)}</td><td>${esc(row.contact)}</td>
                </tr>`;
            }).join('');

            const newCount = sf1ParsedRows.length - dupCount;
            document.getElementById('sf1PreviewMeta').innerHTML =
                `<span style="color:#1d6f42;font-weight:700;">${sf1ParsedRows.length}</span> rows found
                &nbsp;·&nbsp; <span style="color:#1d6f42;font-weight:700;">${newCount}</span> new
                &nbsp;·&nbsp; <span style="color:#c0392b;font-weight:700;">${dupCount}</span> duplicate${dupCount!==1?'s':''} (will be skipped)`;

            document.getElementById('sf1Step1').classList.add('d-none');
            document.getElementById('sf1Step2').classList.remove('d-none');
            document.getElementById('sf1ImportBtn').classList.remove('d-none');
        }

        async function sf1DoImport() {
            const { gradeId, strand, section } = sf1ResolveFinal();
            if (!gradeId || !sf1ParsedRows.length) return;

            document.getElementById('sf1Step2').classList.add('d-none');
            document.getElementById('sf1Step3').classList.remove('d-none');
            document.getElementById('sf1ImportBtn').classList.add('d-none');
            document.getElementById('sf1CancelBtn').disabled = true;

            try {
                const res = await fetch('api/student/import.php', {
                    method : 'POST',
                    headers: { 'Content-Type':'application/json' },
                    body   : JSON.stringify({
                        grade_level_id : gradeId,
                        strand,
                        cluster_id     : parseInt(document.getElementById('sf1Cluster').value, 10) || null,
                        section_name   : section,
                        school_year    : sf1Detected.schoolYear,
                        rows           : sf1ParsedRows,
                    }),
                });
                const text = await res.text();
                let data;
                try { data = JSON.parse(text); } catch(_) {
                    throw new Error('Server returned an unexpected response. Check your PHP error log.');
                }

                document.getElementById('sf1Step3').classList.add('d-none');
                document.getElementById('sf1Step4').classList.remove('d-none');
                document.getElementById('sf1DoneBtn').classList.remove('d-none');
                document.getElementById('sf1CancelBtn').textContent = 'Close';
                document.getElementById('sf1CancelBtn').disabled = false;
                sf1RenderResults(data);

            } catch(err) {
                document.getElementById('sf1Step3').classList.add('d-none');
                document.getElementById('sf1Step2').classList.remove('d-none');
                document.getElementById('sf1ImportBtn').classList.remove('d-none');
                document.getElementById('sf1CancelBtn').disabled = false;
                showAlert('Import failed: ' + err.message, 'danger');
            }
        }

        function sf1RenderResults(data) {
            const hasDups = data.duplicates?.length > 0;
            const hasErrs = data.errors?.length > 0;
            const ins = Number(data.inserted || 0);
            const tot = Number(data.total    || 0);

            const sumEl = document.getElementById('sf1ResultSummary');
            sumEl.className = 'sf1-result-summary ' + (!hasDups && !hasErrs ? 'ok' : 'warn');
            sumEl.innerHTML = `
                <h6><i class="bi bi-${!hasDups&&!hasErrs?'check-circle-fill':'exclamation-triangle-fill'} me-2"></i>
                    Import ${!hasDups&&!hasErrs?'Completed Successfully':'Completed with Issues'}
                </h6>
                <ul>
                    <li><strong>${tot}</strong> student row${tot!==1?'s':''} processed</li>
                    <li><strong>${ins}</strong> student${ins!==1?'s':''} successfully saved to the database</li>
                    ${hasDups?`<li><strong>${data.duplicates.length}</strong> duplicate LRN${data.duplicates.length!==1?'s':''} skipped</li>`:''}
                    ${hasErrs?`<li><strong>${data.errors.length}</strong> row${data.errors.length!==1?'s':''} had errors</li>`:''}
                    ${data.section_assigned?`<li>Students assigned to section: <strong>${esc(data.section_assigned)}</strong></li>`:''}
                </ul>`;

            const dupEl = document.getElementById('sf1DupList');
            if (hasDups) {
                dupEl.classList.remove('d-none');
                dupEl.innerHTML =
                    `<h6><i class="bi bi-exclamation-circle me-1"></i>Duplicate LRNs — already in database (skipped)</h6>
                    <table><thead><tr><th>Row</th><th>LRN</th><th>Name</th></tr></thead>
                    <tbody>${data.duplicates.map(d=>`<tr><td>${d.row}</td><td>${esc(d.lrn)}</td><td>${esc(d.name)}</td></tr>`).join('')}</tbody></table>`;
            } else dupEl.classList.add('d-none');

            const errEl = document.getElementById('sf1ErrList');
            if (hasErrs) {
                errEl.classList.remove('d-none');
                errEl.innerHTML =
                    `<h6><i class="bi bi-x-circle me-1"></i>Rows with Errors (not imported)</h6>
                    <table><thead><tr><th>Row</th><th>LRN</th><th>Reason</th></tr></thead>
                    <tbody>${data.errors.map(e=>`<tr><td>${e.row}</td><td>${esc(e.lrn||'—')}</td><td>${esc(e.msg)}</td></tr>`).join('')}</tbody></table>`;
            } else errEl.classList.add('d-none');

            if (ins > 0) showAlert(`${ins} student${ins!==1?'s':''} imported successfully!`, 'success');
            if (hasDups) showAlert(`${data.duplicates.length} duplicate LRN${data.duplicates.length!==1?'s were':' was'} skipped.`, 'warning');
            if (hasErrs) showAlert(`${data.errors.length} row error${data.errors.length!==1?'s':''}.`, 'danger');
        }

        function sf1ClearFile() {
            sf1File = null;
            sf1ParsedRows = [];
            sf1Fi.value = '';
            document.getElementById('sf1FileChosen').classList.add('d-none');
            document.getElementById('sf1DetectedCard').classList.add('d-none');
            sf1Dz.classList.remove('d-none');
            document.getElementById('sf1PreviewBtn').disabled = true;
        }

        function sf1BackToStep1() {
            document.getElementById('sf1Step2').classList.add('d-none');
            document.getElementById('sf1Step1').classList.remove('d-none');
            document.getElementById('sf1ImportBtn').classList.add('d-none');
        }

        function openImportModal() {
            sf1Reset();
            fetch('api/student/existing-lrns.php')
                .then(r => r.json())
                .then(d => { sf1ExistingLRN = new Set(d.lrns || []); })
                .catch(() => { sf1ExistingLRN = new Set(); });
            bootstrap.Modal.getOrCreateInstance(document.getElementById('importModal'), { backdrop: false }).show();
        }

        function sf1Reset() {
            sf1File = null;
            sf1ParsedRows = [];
            sf1Fi.value = '';
            sf1Detected = { gradeText:'', gradeId:0, gradeName:'', strand:'', section:'', schoolYear:'' };
            ['sf1Step1','sf1Step2','sf1Step3','sf1Step4'].forEach((id, i) =>
                document.getElementById(id).classList.toggle('d-none', i !== 0));
            document.getElementById('sf1FileChosen').classList.add('d-none');
            document.getElementById('sf1DetectedCard').classList.add('d-none');
            sf1Dz.classList.remove('d-none');
            document.getElementById('sf1GradeLevel').value = '';
            document.getElementById('sf1Strand').value = '';
            sf1SetWrapperVisible(document.getElementById('sf1StrandWrap'), false);
            document.getElementById('sf1Cluster').value = '';
            sf1SetWrapperVisible(document.getElementById('sf1ClusterWrap'), false);
            document.getElementById('sf1HeaderRow').value = '10';
            document.getElementById('sf1PreviewBtn').disabled = true;
            document.getElementById('sf1ImportBtn').classList.add('d-none');
            document.getElementById('sf1DoneBtn').classList.add('d-none');
            document.getElementById('sf1CancelBtn').textContent = 'Cancel';
            document.getElementById('sf1CancelBtn').disabled = false;
        }

        function sf1Finish() {
            bootstrap.Modal.getInstance(document.getElementById('importModal')).hide();
            if (typeof loadStudents === 'function') loadStudents(1, '');
        }

        function esc(v) {
            return String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
        }
    </script>
</body>

</html>