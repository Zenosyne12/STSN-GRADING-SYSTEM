<?php
require_once __DIR__ . '/includes/auth.php';     
require_once __DIR__ . '/api/shared/db_connect.php';

$sectionId = isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0;
if ($sectionId <= 0) {
    die('Invalid section.');
}

function h($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

function getStudentColumns(PDO $pdo): array {
    static $cache = null;
    if ($cache !== null) return $cache;

    $colsStmt = $pdo->query('SHOW COLUMNS FROM tblstudents');
    $columns = $colsStmt->fetchAll(PDO::FETCH_COLUMN);

    $fnameCol = in_array('fname', $columns, true) ? 'fname' : (in_array('firstname', $columns, true) ? 'firstname' : null);
    $mnameCol = in_array('mname', $columns, true) ? 'mname' : (in_array('middlename', $columns, true) ? 'middlename' : null);
    $lnameCol = in_array('lname', $columns, true) ? 'lname' : (in_array('lastname', $columns, true) ? 'lastname' : null);

    $genderCol = null;
    foreach (['gender', 'sex', 'student_gender'] as $candidate) {
        if (in_array($candidate, $columns, true)) {
            $genderCol = $candidate;
            break;
        }
    }

    $studentNoCol = null;
    foreach (['student_no', 'lrn', 'school_id'] as $candidate) {
        if (in_array($candidate, $columns, true)) {
            $studentNoCol = $candidate;
            break;
        }
    }

    $cache = compact('fnameCol', 'mnameCol', 'lnameCol', 'genderCol', 'studentNoCol');
    return $cache;
}

function fetchSectionViewData(PDO $pdo, int $sectionId, int $academicYearId = 0): array {
    if ($sectionId <= 0) {
        throw new RuntimeException('Invalid section.');
    }

    if ($academicYearId <= 0) {
        $ayStmt = $pdo->query("
            SELECT id, year_label
            FROM tblacademicyear
            WHERE COALESCE(is_active, 1) = 1
            ORDER BY id DESC
            LIMIT 1
        ");
        $activeAy = $ayStmt->fetch(PDO::FETCH_ASSOC);
        $academicYearId = (int)($activeAy['id'] ?? 0);
    }

    $stmt = $pdo->prepare("
        SELECT s.id, s.section_name, s.grade_level_id, g.grade_level_name
        FROM tblsection s
        LEFT JOIN tblgradelevel g ON g.id = s.grade_level_id
        WHERE s.id = ?
    ");
    $stmt->execute([$sectionId]);
    $section = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$section) {
        throw new RuntimeException('Section not found.');
    }

    $schoolYear = '';
    if ($academicYearId > 0) {
        $ay = $pdo->prepare("SELECT year_label FROM tblacademicyear WHERE id = ?");
        $ay->execute([$academicYearId]);
        $schoolYear = (string)($ay->fetchColumn() ?: '');
    }

    $cols = getStudentColumns($pdo);
    if (!$cols['fnameCol'] || !$cols['lnameCol']) {
        throw new RuntimeException('Student name columns not found in tblstudents.');
    }

    $studentIdentifierExpr = $cols['studentNoCol'] ? "st.`{$cols['studentNoCol']}`" : "st.id";
    $middleExpr = $cols['mnameCol']
        ? "CASE WHEN COALESCE(st.`{$cols['mnameCol']}`, '') = '' THEN '' ELSE CONCAT(' ', LEFT(st.`{$cols['mnameCol']}`, 1), '.') END"
        : "''";
    $genderSelect = $cols['genderCol'] ? "st.`{$cols['genderCol']}`" : "NULL";

    $allStudents = [];
    if ($academicYearId > 0) {
        $sqlStudents = "
            SELECT
                ss.id AS section_student_id,
                st.id,
                {$studentIdentifierExpr} AS student_identifier,
                CONCAT(
                    st.`{$cols['lnameCol']}`,
                    ', ',
                    st.`{$cols['fnameCol']}`,
                    {$middleExpr}
                ) AS full_name,
                {$genderSelect} AS gender
            FROM tblsectionstudent ss
            INNER JOIN tblstudents st ON st.id = ss.student_id
            WHERE ss.section_id = ?
              AND ss.academic_year_id = ?
              AND ss.is_active = 1
            ORDER BY st.`{$cols['lnameCol']}` ASC, st.`{$cols['fnameCol']}` ASC
        ";
        $stmt = $pdo->prepare($sqlStudents);
        $stmt->execute([$sectionId, $academicYearId]);
        $allStudents = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    $maleStudents = [];
    $femaleStudents = [];
    $unknownGender = [];

    foreach ($allStudents as $student) {
        $gender = strtolower(trim((string)($student['gender'] ?? '')));
        if (in_array($gender, ['male', 'm', 'boy', 'boys', '1'], true)) {
            $student['gender_label'] = 'Male';
            $maleStudents[] = $student;
        } elseif (in_array($gender, ['female', 'f', 'girl', 'girls', '0', '2'], true)) {
            $student['gender_label'] = 'Female';
            $femaleStudents[] = $student;
        } else {
            $student['gender_label'] = 'Unspecified';
            $unknownGender[] = $student;
        }
    }

    $schedules = [];
    $sqlSchedule = "
        SELECT
            sc.id,
            sc.day_name AS day_of_week,
            sc.time_start,
            sc.time_end,
            sc.room,
            sc.semester,
            sc.school_year,
            sub.subject_code,
            sub.subject_name,
            CONCAT(t.fname, ' ', t.lname) AS teacher_name
        FROM tblschedule sc
        INNER JOIN tblsubjects sub ON sub.id = sc.subject_id
        INNER JOIN tblteacher t ON t.id = sc.teacher_id
        WHERE sc.section_id = ?
          AND COALESCE(sc.is_active, 1) = 1
    ";

    $scheduleParams = [$sectionId];

    if ($schoolYear !== '') {
        $sqlSchedule .= " AND sc.school_year = ? ";
        $scheduleParams[] = $schoolYear;
    }

    $sqlSchedule .= "
        ORDER BY
            FIELD(sc.day_name, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'),
            sc.time_start ASC,
            sub.subject_name ASC
    ";

    $stmt = $pdo->prepare($sqlSchedule);
    $stmt->execute($scheduleParams);
    $schedules = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return [
        'section' => [
            'id' => (int)$section['id'],
            'section_name' => $section['section_name'] ?? '',
            'grade_level_name' => $section['grade_level_name'] ?? '',
            'school_year' => $schoolYear !== '' ? $schoolYear : 'Not set',
            'academic_year_id' => $academicYearId,
        ],
        'stats' => [
            'total_students' => count($allStudents),
            'male_students' => count($maleStudents),
            'female_students' => count($femaleStudents),
            'unspecified_students' => count($unknownGender),
            'total_schedules' => count($schedules),
        ],
        'students' => $allStudents,
        'male_students_list' => $maleStudents,
        'female_students_list' => $femaleStudents,
        'unknown_students_list' => $unknownGender,
        'schedules' => $schedules,
    ];
}

if (isset($_GET['ajax']) && $_GET['ajax'] === 'view_section') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $requestedSectionId = (int)($_GET['id'] ?? $sectionId);
        $academicYearId = (int)($_GET['academic_year_id'] ?? 0);
        echo json_encode([
            'success' => true,
            'data' => fetchSectionViewData($pdo, $requestedSectionId, $academicYearId)
        ]);
    } catch (Throwable $e) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
    exit;
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Manage Sectioning</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        body {
            background: #f3f7fd;
        }

        .ay-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }

        .ay-page-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 0.2rem;
            letter-spacing: 0.01em;
        }

        .ay-page-header p {
            margin: 0;
            font-size: 0.88rem;
            opacity: 0.85;
        }

        .ay-active-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            background: rgba(255, 255, 255, 0.15);
            border: 1.5px solid rgba(255, 255, 255, 0.3);
            border-radius: 999px;
            padding: 0.45rem 1rem;
            font-size: 0.88rem;
            font-weight: 700;
            color: #fff;
            white-space: nowrap;
        }

        .ay-card {
            background: #fff;
            border: 1px solid #dce8f8;
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18, 72, 168, 0.06);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }

        .ay-card-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid #e8f0fb;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
            background: #fff;
        }

        .ay-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: #132f62;
            margin: 0 0 0.15rem;
        }

        .ay-card-subtitle {
            font-size: 0.8rem;
            color: #7a93b8;
            margin: 0;
        }

        .ay-card-body {
            padding: 1.2rem 1.3rem;
        }

        .ay-info-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 1rem;
        }

        .ay-info-label {
            font-size: 0.83rem;
            font-weight: 700;
            color: #3b5e96;
            margin-bottom: 0.45rem;
        }

        .ay-info-value {
            min-height: 46px;
            display: flex;
            align-items: center;
            padding: 0.65rem 0.9rem;
            border: 1px solid #dce8f8;
            border-radius: 12px;
            background: #fff;
            box-shadow: 0 2px 8px rgba(18, 72, 168, 0.04);
            font-weight: 600;
            color: #213a5e;
        }

        .ay-action-wrap {
            display: flex;
            gap: .6rem;
            flex-wrap: wrap;
            justify-content: flex-end;
        }

        .btn-ay {
            font-weight: 600;
            font-size: 0.82rem;
            border-radius: 8px;
            padding: 0.42rem 0.9rem;
            cursor: pointer;
            transition: background 0.15s, border-color 0.15s, color 0.15s, box-shadow 0.15s;
            border: 1.5px solid transparent;
            line-height: 1.4;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: .35rem;
        }

        .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            border-color: transparent;
            box-shadow: 0 2px 8px rgba(26, 110, 245, 0.2);
        }

        .btn-ay-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
        }

        .btn-ay-light {
            background: #fff;
            color: #1248a8;
            border-color: #b8d0fa;
        }

        .btn-ay-light:hover {
            background: #eef4ff;
            border-color: #8db5f7;
            color: #0f3d90;
        }

        .btn-ay-warning {
            background: #fff7e8;
            color: #9a6200;
            border-color: #f6d28b;
        }

        .btn-ay-warning:hover {
            background: #ffefc7;
            color: #845100;
            border-color: #efc361;
        }

        .btn-ay-danger {
            background: #fff0f1;
            color: #b42318;
            border-color: #f5b5ba;
        }

        .btn-ay-danger:hover {
            background: #ffe2e4;
            color: #9a1e14;
            border-color: #eb8f97;
        }

        .ay-chip {
            background: #eef4ff;
            border: 1px solid #cfe0fb;
            color: #1248a8;
            border-radius: 999px;
            padding: 0.34rem 0.8rem;
            font-size: 0.77rem;
            font-weight: 700;
        }

        .ay-bulk-actions {
            display: none;
            gap: 0.55rem;
            align-items: center;
            flex-wrap: wrap;
            margin-top: 0.7rem;
        }

        .ay-bulk-actions.show {
            display: flex;
        }

        .ay-table-wrap {
            padding: 0;
        }

        .ay-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
        }

        .ay-table thead th {
            background: #f4f8ff;
            color: #3b5e96;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 0.85rem 1rem;
            border-bottom: 1.5px solid #dce8f8;
            white-space: nowrap;
            text-align: center;
        }

        .ay-table tbody td {
            padding: 0.95rem 1rem;
            font-size: 0.92rem;
            color: #213a5e;
            vertical-align: middle;
            text-align: center;
        }

        .ay-table tbody tr:not(:last-child) td {
            border-bottom: 1px solid #f0f5fc;
        }

        .ay-table tbody tr:hover td {
            background: #f7fbff;
        }

        .ay-left {
            text-align: left !important;
        }

        .ay-mobile-card {
            background: #fff;
            border: 1.5px solid #dce8f8;
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 1px 6px rgba(18, 72, 168, 0.05);
        }

        .ay-mobile-card + .ay-mobile-card {
            margin-top: 0.75rem;
        }

        .ay-mobile-card-header {
            padding: 0.85rem 1rem;
            border-bottom: 1px solid #edf3fc;
            background: #f9fbff;
        }

        .ay-mobile-card-title {
            font-weight: 700;
            color: #132f62;
            font-size: 0.95rem;
        }

        .ay-mobile-card-body {
            padding: 0.85rem 1rem;
        }

        .ay-mobile-row {
            display: flex;
            justify-content: space-between;
            gap: .75rem;
            padding: .2rem 0;
            font-size: .9rem;
        }

        .ay-mobile-label {
            color: #7a93b8;
            font-weight: 600;
        }

        .ay-mobile-actions {
            display: grid;
            gap: .5rem;
            padding: 0 1rem 1rem;
        }

        .ay-empty {
            text-align: center;
            padding: 2.4rem 1.5rem;
            color: #9ab0c8;
        }

        .ay-empty i {
            font-size: 2.2rem;
            display: block;
            margin-bottom: 0.6rem;
            opacity: 0.5;
        }

        .ay-empty p {
            margin: 0;
            font-size: 0.95rem;
        }

        .ay-modal .modal-content {
            border: 0;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(18, 72, 168, 0.16);
            overflow: hidden;
        }

        .ay-modal .modal-header {
            background: #f4f8ff;
            border-bottom: 1px solid #dce8f8;
            padding: 1rem 1.25rem;
        }

        .ay-modal .modal-title {
            font-size: 1rem;
            font-weight: 700;
            color: #132f62;
        }

        .ay-modal-subtitle {
            font-size: 0.82rem;
            color: #7a93b8;
        }

        .ay-modal .modal-body {
            background: #fff;
            padding: 1.2rem;
        }

        .select-table-wrap {
            max-height: 430px;
            overflow: auto;
            border: 1px solid #dce8f8;
            border-radius: 14px;
            background: #fff;
        }

        .select-table {
            width: 100%;
            border-collapse: collapse;
        }

        .select-table thead th {
            position: sticky;
            top: 0;
            z-index: 1;
            background: #f4f8ff;
            color: #3b5e96;
            font-size: 0.74rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            padding: 0.8rem 0.9rem;
            border-bottom: 1px solid #dce8f8;
        }

        .select-table tbody td {
            padding: 0.8rem 0.9rem;
            border-bottom: 1px solid #eef3fb;
            font-size: 0.88rem;
            color: #213a5e;
            vertical-align: middle;
        }

        .student-checkbox {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .section-view-modal .modal-dialog {
            max-width: 1180px;
        }

        .section-view-modal .modal-content {
            border: 0;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 10px 34px rgba(18, 72, 168, 0.18);
        }

        .section-view-modal .modal-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            color: #fff;
            border-bottom: 0;
            padding: 1rem 1.25rem;
        }

        .section-view-modal .modal-header .btn-close {
            filter: invert(1);
        }

        .section-view-modal .modal-body {
            background: #fff;
            padding: 1.2rem;
        }

        .sv-school-name {
            font-size: 1.25rem;
            font-weight: 900;
            letter-spacing: .02em;
            text-align: center;
            margin: 0;
            color: #132f62;
        }

        .sv-subhead {
            font-size: .85rem;
            text-align: center;
            color: #6f84a6;
            margin: .2rem 0 1rem;
        }

        .sv-section-bar {
            background: #132f62;
            color: #fff;
            text-align: center;
            font-size: 1.35rem;
            font-weight: 900;
            line-height: 1.1;
            padding: .55rem .75rem;
            border-radius: 12px 12px 0 0;
        }

        .sv-semester-line {
            text-align: center;
            font-size: 1rem;
            font-weight: 800;
            margin: 0 0 1rem;
            padding: .6rem .75rem;
            background: #f4f8ff;
            border: 1px solid #dce8f8;
            border-top: 0;
            border-radius: 0 0 12px 12px;
            color: #132f62;
        }

        .sv-summary {
            text-align: center;
            font-size: .95rem;
            margin-bottom: 1rem;
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .sv-summary span {
            font-weight: 700;
            background: #f8fbff;
            border: 1px solid #dce8f8;
            border-radius: 999px;
            padding: .35rem .85rem;
        }

        .male-count { color: #1248a8; }
        .female-count { color: #c2185b; }
        .total-count { color: #355177; }

        .sv-block-title {
            font-size: 1rem;
            font-weight: 900;
            margin: 1.2rem 0 .8rem;
            text-align: center;
            text-transform: uppercase;
            border-bottom: 2px solid #132f62;
            padding-bottom: 0.45rem;
            color: #132f62;
        }

        .sv-table-wrap {
            border: 1px solid #dce8f8;
            border-radius: 12px;
            overflow: hidden;
        }

        .sv-table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            font-size: 0.9rem;
            margin: 0;
        }

        .sv-table th, .sv-table td {
            border: 1px solid #dce8f8;
            padding: 0.7rem;
            vertical-align: middle;
        }

        .sv-table th {
            background: #f4f8ff;
            font-size: 0.8rem;
            font-weight: 900;
            text-align: center;
            color: #132f62;
        }

        .sv-year-row td {
            font-size: 1rem;
            font-weight: 900;
            text-align: center;
            padding: 0.8rem 0;
            background: #eef4ff;
            color: #132f62;
        }

        .sv-center {
            text-align: center;
        }

        .students-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .gender-column {
            border: 1px solid #dce8f8;
            border-radius: 12px;
            overflow: hidden;
            background: #fff;
        }

        .gender-header {
            font-size: 0.88rem;
            font-weight: 800;
            text-align: center;
            padding: 0.75rem;
            border-bottom: 1px solid #dce8f8;
            background: #f4f8ff;
            color: #132f62;
        }

        .student-list {
            font-size: 0.92rem;
            line-height: 1.65;
            max-height: 360px;
            overflow: auto;
            padding: .4rem 0;
        }

        .student-item {
            margin: 0;
            display: flex;
            align-items: baseline;
            gap: .55rem;
            padding: .55rem .85rem;
            border-bottom: 1px solid #eef4ff;
        }

        .student-item:last-child {
            border-bottom: 0;
        }

        .student-number {
            font-weight: bold;
            min-width: 26px;
            color: #7a93b8;
        }

        .student-id {
            font-family: monospace;
            font-size: 0.9rem;
            min-width: 105px;
            color: #555;
        }

        .student-name {
            font-weight: 600;
            color: #132f62;
        }

        .sv-empty-inline {
            text-align: center;
            color: #7a93b8;
            font-style: italic;
            padding: 1.25rem;
        }

        .unknown-wrap {
            border: 1px solid #dce8f8;
            border-radius: 12px;
            overflow: hidden;
            background: #fff;
            margin-top: 1rem;
        }

        .confirm-modal .modal-content {
            border: 0;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(18, 72, 168, 0.16);
        }

        @media (max-width: 991.98px) {
            .ay-info-grid,
            .students-container {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 767.98px) {
            .ay-page-header {
                padding: 1.1rem 1.2rem;
                border-radius: 14px;
            }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3">

                <div class="ay-page-header">
                    <div>
                        <h3><i class="bi bi-people-fill me-2"></i>Manage Section Masterlist</h3>
                        <p>Review enrolled students, open the full class record, and add or transfer students in bulk.</p>
                    </div>
                    <div class="ay-active-chip">
                        <i class="bi bi-card-checklist"></i>
                        Section Management
                    </div>
                </div>

                <div class="ay-card">
                    <div class="ay-card-header">
                        <div>
                            <p class="ay-card-title">Section Information</p>
                            <p class="ay-card-subtitle">Current section details and quick actions.</p>
                        </div>

                        <div class="ay-action-wrap">
                            <button class="btn-ay btn-ay-light" type="button" onclick="openSectionViewModal()">
                                <i class="bi bi-eye"></i> View Details
                            </button>
                            <button class="btn-ay btn-ay-primary" type="button" onclick="openAddStudentModal()">
                                <i class="bi bi-person-plus"></i> Add Students
                            </button>
                        </div>
                    </div>

                    <div class="ay-card-body">
                        <div class="d-none">
                            <select id="academicYearId"></select>
                        </div>

                        <div class="ay-info-grid">
                            <div>
                                <div class="ay-info-label">Grade Level</div>
                                <div id="infoGradeLevel" class="ay-info-value">-</div>
                            </div>
                            <div>
                                <div class="ay-info-label">Section Name</div>
                                <div id="infoSectionName" class="ay-info-value">-</div>
                            </div>
                            <div>
                                <div class="ay-info-label">Section Adviser</div>
                                <div id="infoAdviser" class="ay-info-value">-</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="ay-card">
                    <div class="ay-card-header">
                        <div>
                            <p class="ay-card-title">Masterlist</p>
                            <p class="ay-card-subtitle">Select multiple students for transfer or removal.</p>

                            <div class="ay-bulk-actions" id="bulkActions">
                                <span class="ay-chip" id="selectedCount">0 selected</span>
                                <button class="btn-ay btn-ay-warning" type="button" onclick="openTransferModal()">
                                    <i class="bi bi-arrow-left-right"></i> Transfer to Section
                                </button>
                                <button class="btn-ay btn-ay-danger" type="button" onclick="removeSelectedStudents()">
                                    <i class="bi bi-person-dash"></i> Remove Selected
                                </button>
                                <button class="btn-ay btn-ay-light" type="button" onclick="clearSelection()">
                                    Clear
                                </button>
                            </div>
                        </div>

                        <input class="form-control form-control-sm" type="search" id="studentSearchInput" placeholder="Search student..." style="max-width:260px; border-radius:10px; border:1.5px solid #dce8f8;">
                    </div>

                    <div class="ay-table-wrap">
                        <div class="table-responsive d-none d-md-block">
                            <table class="ay-table" id="masterlistTable">
                                <thead>
                                    <tr>
                                        <th style="width:50px;">
                                            <input type="checkbox" class="student-checkbox" id="selectAllCheckbox" onchange="toggleSelectAll()">
                                        </th>
                                        <th style="width:56px;">#</th>
                                        <th>Student ID</th>
                                        <th>Student Name</th>
                                        <th style="width:110px;">Sex</th>
                                        <th style="width: 250px;">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="masterlistTableBody">
                                    <tr>
                                        <td colspan="6">
                                            <div class="ay-empty">
                                                <i class="bi bi-hourglass-split"></i>
                                                <p>Loading students...</p>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="d-block d-md-none p-3" id="masterlistCardView"></div>
                    </div>
                </div>

            </div>
        </div>
    </main>

    <?php require_once("includes/footer.php"); ?>
</div>

<div class="modal fade ay-modal" id="addStudentModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="false">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <form id="addStudentForm">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title"><i class="bi bi-person-plus-fill me-2"></i>Add Students to Section</h5>
                        <div class="ay-modal-subtitle">Select multiple students from the list below.</div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <div class="d-flex flex-column flex-lg-row gap-2 justify-content-between align-items-lg-center mb-3">
                        <div class="d-flex gap-2 flex-wrap align-items-center">
                            <span class="ay-chip" id="availableSelectedCount">0 selected</span>
                            <button type="button" class="btn-ay btn-ay-light" onclick="toggleSelectAllAvailable(true)">Select All</button>
                            <button type="button" class="btn-ay btn-ay-light" onclick="toggleSelectAllAvailable(false)">Clear</button>
                        </div>

                        <input type="search" class="form-control" id="availableStudentSearch" placeholder="Search available students..." style="max-width:300px; border-radius:10px; border:1.5px solid #dce8f8;">
                    </div>

                    <div class="select-table-wrap" id="availableStudentsWrap">
                        <table class="select-table">
                            <thead>
                                <tr>
                                    <th style="width:44px;">
                                        <input type="checkbox" class="student-checkbox" id="selectAllAvailableCheckbox">
                                    </th>
                                    <th>Student ID</th>
                                    <th>Student Name</th>
                                    <th style="width:120px;">Sex</th>
                                </tr>
                            </thead>
                            <tbody id="availableStudentsTableBody"></tbody>
                        </table>
                    </div>

                    <div id="availableStudentsEmpty" class="ay-empty d-none">
                        <i class="bi bi-person-x"></i>
                        <p>No available students found.</p>
                    </div>
                </div>

                <div class="modal-footer" style="padding: .95rem 1.2rem; border-top:1px solid #e8f0fb; background:#fafcff;">
                    <button class="btn-ay btn-ay-light" type="button" data-bs-dismiss="modal">Close</button>
                    <button class="btn-ay btn-ay-primary" type="submit">
                        <i class="bi bi-check2-circle"></i> Add Selected Students
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade ay-modal" id="transferModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="false">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <form id="transferForm">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title"><i class="bi bi-arrow-left-right me-2"></i>Transfer Students</h5>
                        <div class="ay-modal-subtitle">Move selected students to another section within the same grade level.</div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <div class="mb-3">
                        <span class="ay-chip">Students to transfer: <span id="transferCount">0</span></span>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Current Section</label>
                        <input type="text" class="form-control" id="currentSectionDisplay" readonly style="border-radius:12px;">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Target Section <span class="text-danger">*</span></label>
                        <select class="form-select" id="targetSectionId" required style="border-radius:12px;">
                            <option value="">Select Target Section</option>
                        </select>
                        <div class="form-text">Only sections with the same grade level are shown.</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Selected Students</label>
                        <div id="transferStudentList" class="border rounded-4 p-3 bg-white" style="max-height:220px; overflow-y:auto;"></div>
                    </div>
                </div>

                <div class="modal-footer" style="padding: .95rem 1.2rem; border-top:1px solid #e8f0fb; background:#fafcff;">
                    <button class="btn-ay btn-ay-light" type="button" data-bs-dismiss="modal">Cancel</button>
                    <button class="btn-ay btn-ay-warning" type="submit">
                        <i class="bi bi-arrow-left-right"></i> Transfer Students
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade section-view-modal" id="sectionViewModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="false">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <h5 class="modal-title mb-1"><i class="bi bi-eye-fill me-2"></i>Section View</h5>
                    <div class="small opacity-75" id="modalSectionSubtitle">Loading section details...</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <p class="sv-school-name">ST. TERESA SCHOOL OF NOVALICHES</p>
                <p class="sv-subhead">Zabarte Subd., Novaliches, Q.C.</p>

                <div class="sv-section-bar" id="svSectionBar">-</div>
                <p class="sv-semester-line" id="svSchoolYearLine">School Year -</p>

                <div class="sv-summary" id="svSummary"></div>

                <div class="sv-block-title">Class Schedule</div>
                <div class="sv-table-wrap" id="scheduleWrap"></div>

                <div class="sv-block-title">Class List</div>
                <div id="studentListsWrap"></div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade confirm-modal" id="confirmModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title" id="confirmModalTitle">Confirm Action</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body pt-2" id="confirmModalMessage">Are you sure?</div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn-ay btn-ay-light" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn-ay btn-ay-danger" id="confirmModalOkBtn">Confirm</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="./js/sweet-alerts.js"></script>
<script>
const SECTION_ID = <?php echo (int)$sectionId; ?>;
const addStudentModal = new bootstrap.Modal(document.getElementById('addStudentModal'));
const transferModal = new bootstrap.Modal(document.getElementById('transferModal'));
const sectionViewModal = new bootstrap.Modal(document.getElementById('sectionViewModal'));
const confirmModalEl = document.getElementById('confirmModal');
const confirmModal = new bootstrap.Modal(confirmModalEl);

let confirmCallback = null;
let currentSectionInfo = null;
let currentStudents = [];
let selectedStudents = new Set();
let availableStudents = [];
let filteredAvailableStudents = [];
let selectedAvailableStudents = new Set();

function esc(str) {
    return (str ?? '').toString()
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function showAlert(message, type = 'success') {
    const config = {
        success: { title: 'Success', color: 'blue', icon: 'bi bi-check-circle-fill' },
        danger: { title: 'Error', color: 'red', icon: 'bi bi-exclamation-octagon-fill' },
        warning: { title: 'Warning', color: 'yellow', icon: 'bi bi-exclamation-triangle-fill' },
        info: { title: 'Info', color: 'blue', icon: 'bi bi-info-circle-fill' }
    };

    const selected = config[type] || config.success;

    iziToast.show({
        title: selected.title,
        message,
        color: selected.color,
        icon: selected.icon,
        iconColor: '#fff',
        theme: 'light',
        position: 'topRight',
        timeout: 4000,
        progressBar: true,
        close: true,
        pauseOnHover: true,
        drag: true,
        transitionIn: 'fadeInDown',
        transitionOut: 'fadeOutUp',
        maxWidth: 420
    });
}

function askConfirm(message, onConfirm, options = {}) {
    document.getElementById('confirmModalTitle').textContent = options.title || 'Confirm Action';
    document.getElementById('confirmModalMessage').textContent = message;
    const okBtn = document.getElementById('confirmModalOkBtn');
    okBtn.textContent = options.okText || 'Confirm';
    okBtn.className = `btn-ay btn-ay-${options.okClass || 'danger'}`;
    confirmCallback = onConfirm;
    confirmModal.show();
}

document.getElementById('confirmModalOkBtn').addEventListener('click', async () => {
    if (typeof confirmCallback === 'function') {
        const callback = confirmCallback;
        confirmCallback = null;
        confirmModal.hide();
        await callback();
    }
});

confirmModalEl.addEventListener('hidden.bs.modal', () => {
    confirmCallback = null;
});

async function fetchJson(url, options = {}) {
    const res = await fetch(url, options);
    const text = await res.text();

    let json;
    try {
        json = JSON.parse(text);
    } catch (e) {
        console.error('Invalid JSON from:', url, text);
        throw new Error('Invalid server response');
    }

    if (!res.ok || json.success === false) {
        throw new Error(json.error || ('HTTP ' + res.status));
    }

    return json;
}

function dayLabel(d) {
    const map = {
        Monday: 'Mon',
        Tuesday: 'Tue',
        Wednesday: 'Wed',
        Thursday: 'Thu',
        Friday: 'Fri',
        Saturday: 'Sat'
    };
    return map[d] || d || '-';
}

function formatTimeRange(start, end) {
    const format = value => {
        if (!value) return '-';
        const d = new Date(`1970-01-01T${value}`);
        return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }).toLowerCase();
    };
    return `${format(start)} - ${format(end)}`;
}

async function loadSectionInfo() {
    const result = await fetchJson(`api/sectioning/fetch_section.php?id=${SECTION_ID}`);
    currentSectionInfo = result.data;
    const data = result.data;

    document.getElementById('infoGradeLevel').textContent = data.grade_level_name || '-';
    document.getElementById('infoSectionName').textContent = data.section_name || '-';
    document.getElementById('currentSectionDisplay').value = `${data.section_name} (${data.grade_level_name})`;

    await loadAcademicYears(data.default_academic_year_id || '');
    await loadSectionAdviser();
}

async function loadAcademicYears(selectedId = '') {
    const result = await fetchJson('api/sectioning/academic_years.php');
    const list = result.academic_years || [];
    const select = document.getElementById('academicYearId');

    if (!list.length) {
        select.innerHTML = '<option value="">No academic year found</option>';
        return;
    }

    select.innerHTML = list.map(y => `
        <option value="${y.id}" ${String(selectedId) === String(y.id) ? 'selected' : ''}>
            ${esc(y.year_label)}${String(y.is_active) === '1' ? ' (Active)' : ''}
        </option>
    `).join('');
}

async function loadSectionAdviser() {
    try {
        const res = await fetchJson(`api/sectioning/adviser_get.php?section_id=${SECTION_ID}`);
        document.getElementById('infoAdviser').textContent = res.teacher_name || '-';
    } catch (error) {
        console.error('Failed to load adviser:', error);
        document.getElementById('infoAdviser').textContent = '-';
    }
}

async function loadMasterlist() {
    const academicYearId = document.getElementById('academicYearId').value;
    const search = document.getElementById('studentSearchInput').value.trim();

    if (!academicYearId) {
        document.getElementById('masterlistTableBody').innerHTML = '';
        document.getElementById('masterlistCardView').innerHTML = '';
        currentStudents = [];
        updateBulkActions();
        return;
    }

    const data = await fetchJson(`api/sectioning/students_in_section.php?section_id=${SECTION_ID}&academic_year_id=${academicYearId}&s=${encodeURIComponent(search)}`);
    currentStudents = data.students || [];
    selectedStudents.clear();
    document.getElementById('selectAllCheckbox').checked = false;
    updateBulkActions();
    renderStudentList();
}

function renderStudentList() {
    const list = currentStudents;
    const tbody = document.getElementById('masterlistTableBody');
    const cardView = document.getElementById('masterlistCardView');

    if (!list.length) {
        const emptyHtml = `
            <div class="ay-empty">
                <i class="bi bi-people"></i>
                <p>No students found in this section.</p>
            </div>
        `;
        tbody.innerHTML = `<tr><td colspan="6">${emptyHtml}</td></tr>`;
        cardView.innerHTML = emptyHtml;
        return;
    }

    tbody.innerHTML = list.map((s, i) => `
        <tr>
            <td>
                <input type="checkbox"
                    class="student-checkbox"
                    value="${s.section_student_id}"
                    onchange="toggleStudentSelection(${s.section_student_id})"
                    ${selectedStudents.has(s.section_student_id) ? 'checked' : ''}>
            </td>
            <td>${i + 1}</td>
            <td>${esc(s.student_identifier || s.id)}</td>
            <td class="ay-left">${esc(s.full_name || '-')}</td>
            <td>${esc(s.sex || '-')}</td>
            <td>
                <div class="d-flex justify-content-center gap-2 flex-wrap">
                    <button class="btn-ay btn-ay-warning" type="button" onclick="openTransferSingleModal(${s.section_student_id})">
                        <i class="bi bi-arrow-left-right"></i> Transfer
                    </button>
                    <button class="btn-ay btn-ay-danger" type="button" onclick="removeStudent(${s.section_student_id})">
                        <i class="bi bi-person-dash"></i> Remove
                    </button>
                </div>
            </td>
        </tr>
    `).join('');

    cardView.innerHTML = list.map((s, i) => `
        <div class="ay-mobile-card">
            <div class="ay-mobile-card-header">
                <label class="d-flex align-items-center gap-2 mb-0">
                    <input class="student-checkbox" type="checkbox"
                        value="${s.section_student_id}"
                        onchange="toggleStudentSelection(${s.section_student_id})"
                        ${selectedStudents.has(s.section_student_id) ? 'checked' : ''}>
                    <span class="ay-mobile-card-title">${i + 1}. ${esc(s.full_name || '-')}</span>
                </label>
            </div>
            <div class="ay-mobile-card-body">
                <div class="ay-mobile-row">
                    <span class="ay-mobile-label">Student ID</span>
                    <span>${esc(s.student_identifier || s.id)}</span>
                </div>
                <div class="ay-mobile-row">
                    <span class="ay-mobile-label">Sex</span>
                    <span>${esc(s.sex || '-')}</span>
                </div>
            </div>
            <div class="ay-mobile-actions">
                <button class="btn-ay btn-ay-warning" type="button" onclick="openTransferSingleModal(${s.section_student_id})">
                    <i class="bi bi-arrow-left-right"></i> Transfer
                </button>
                <button class="btn-ay btn-ay-danger" type="button" onclick="removeStudent(${s.section_student_id})">
                    <i class="bi bi-person-dash"></i> Remove
                </button>
            </div>
        </div>
    `).join('');
}

function toggleStudentSelection(id) {
    if (selectedStudents.has(id)) selectedStudents.delete(id);
    else selectedStudents.add(id);
    updateBulkActions();
}

function toggleSelectAll() {
    const isChecked = document.getElementById('selectAllCheckbox').checked;
    if (isChecked) {
        currentStudents.forEach(s => selectedStudents.add(s.section_student_id));
    } else {
        selectedStudents.clear();
    }
    renderStudentList();
    updateBulkActions();
}

function updateBulkActions() {
    const count = selectedStudents.size;
    const bulkActions = document.getElementById('bulkActions');
    const countDisplay = document.getElementById('selectedCount');

    if (count > 0) {
        bulkActions.classList.add('show');
        countDisplay.textContent = `${count} selected`;
    } else {
        bulkActions.classList.remove('show');
    }
}

function clearSelection() {
    selectedStudents.clear();
    document.getElementById('selectAllCheckbox').checked = false;
    renderStudentList();
    updateBulkActions();
}

async function openTransferModal() {
    if (selectedStudents.size === 0) {
        showAlert('Please select at least one student to transfer.', 'warning');
        return;
    }

    document.getElementById('transferCount').textContent = selectedStudents.size;

    const selectedStudentData = currentStudents.filter(s => selectedStudents.has(s.section_student_id));
    document.getElementById('transferStudentList').innerHTML = selectedStudentData.map(s => `
        <div class="mb-2">
            <i class="bi bi-person me-1"></i>
            ${esc(s.full_name)} (${esc(s.student_identifier || s.id)})
        </div>
    `).join('');

    await loadTargetSections();
    transferModal.show();
}

async function openTransferSingleModal(sectionStudentId) {
    selectedStudents.clear();
    selectedStudents.add(sectionStudentId);
    updateBulkActions();
    await openTransferModal();
}

async function loadTargetSections() {
    if (!currentSectionInfo) return;

    const gradeLevelId = currentSectionInfo.grade_level_id;
    try {
        const result = await fetchJson(`api/sectioning/sections_by_grade.php?grade_level_id=${gradeLevelId}&exclude_section_id=${SECTION_ID}`);
        const sections = result.sections || [];

        document.getElementById('targetSectionId').innerHTML = ['<option value="">Select Target Section</option>']
            .concat(sections.map(s => `
                <option value="${s.id}">
                    ${esc(s.section_name)} - Adviser: ${esc(s.adviser_name || '-')} - ${esc(s.total_students || 0)} students
                </option>
            `))
            .join('');
    } catch (error) {
        console.error('Failed to load target sections:', error);
        document.getElementById('targetSectionId').innerHTML = '<option value="">Error loading sections</option>';
    }
}

document.getElementById('transferForm').addEventListener('submit', async e => {
    e.preventDefault();

    const targetSectionId = document.getElementById('targetSectionId').value;
    const academicYearId = document.getElementById('academicYearId').value;

    if (!targetSectionId) {
        showAlert('Please select a target section.', 'warning');
        return;
    }

    askConfirm(`Transfer ${selectedStudents.size} student(s) to the selected section?`, async () => {
        try {
            const result = await fetchJson('api/sectioning/transfer_students.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    source_section_id: SECTION_ID,
                    target_section_id: targetSectionId,
                    academic_year_id: academicYearId,
                    student_ids: Array.from(selectedStudents)
                })
            });

            transferModal.hide();
            showAlert(`Successfully transferred ${result.transferred_count || selectedStudents.size} student(s).`, 'success');
            selectedStudents.clear();
            updateBulkActions();
            await loadMasterlist();
            await loadAvailableStudents();
        } catch (error) {
            console.error(error);
            showAlert('Transfer failed: ' + error.message, 'danger');
        }
    }, {
        title: 'Transfer Students',
        okText: 'Transfer',
        okClass: 'warning'
    });
});

async function removeSelectedStudents() {
    if (selectedStudents.size === 0) return;

    askConfirm(`Remove ${selectedStudents.size} selected student(s) from this section?`, async () => {
        let removed = 0;
        let failed = 0;

        for (const id of selectedStudents) {
            try {
                const res = await fetchJson('api/sectioning/remove_student.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id })
                });
                if (res.success) removed++;
                else failed++;
            } catch (e) {
                failed++;
            }
        }

        selectedStudents.clear();
        updateBulkActions();
        await loadMasterlist();
        await loadAvailableStudents();

        showAlert(`Removed ${removed} student(s).${failed > 0 ? ` Failed: ${failed}` : ''}`, failed > 0 ? 'warning' : 'success');
    }, {
        title: 'Remove Students',
        okText: 'Remove',
        okClass: 'danger'
    });
}

async function loadAvailableStudents() {
    const academicYearId = document.getElementById('academicYearId').value;
    if (!academicYearId) {
        availableStudents = [];
        filteredAvailableStudents = [];
        renderAvailableStudents();
        return;
    }

    const data = await fetchJson(`api/sectioning/students_available.php?section_id=${SECTION_ID}&academic_year_id=${academicYearId}`);
    availableStudents = (data.students || []).map(s => ({
        id: s.id,
        full_name: s.full_name || '-',
        student_identifier: s.student_identifier || '',
        sex: s.sex || '-'
    }));

    selectedAvailableStudents.clear();
    applyAvailableStudentFilter();
}

function applyAvailableStudentFilter() {
    const query = document.getElementById('availableStudentSearch').value.trim().toLowerCase();
    filteredAvailableStudents = availableStudents.filter(student => {
        return !query || [student.full_name, student.student_identifier, student.sex].join(' ').toLowerCase().includes(query);
    });
    renderAvailableStudents();
}

function renderAvailableStudents() {
    const body = document.getElementById('availableStudentsTableBody');
    const emptyState = document.getElementById('availableStudentsEmpty');
    const wrap = document.getElementById('availableStudentsWrap');

    const rows = filteredAvailableStudents.map(student => `
        <tr>
            <td>
                <input type="checkbox"
                    class="student-checkbox"
                    value="${student.id}"
                    ${selectedAvailableStudents.has(student.id) ? 'checked' : ''}
                    onchange="toggleAvailableStudent(${student.id})">
            </td>
            <td>${esc(student.student_identifier || student.id)}</td>
            <td>${esc(student.full_name)}</td>
            <td>${esc(student.sex || '-')}</td>
        </tr>
    `).join('');

    body.innerHTML = rows;
    emptyState.classList.toggle('d-none', filteredAvailableStudents.length !== 0);
    wrap.classList.toggle('d-none', filteredAvailableStudents.length === 0);
    updateAvailableSelectionState();
}

function toggleAvailableStudent(id) {
    if (selectedAvailableStudents.has(id)) selectedAvailableStudents.delete(id);
    else selectedAvailableStudents.add(id);
    updateAvailableSelectionState();
}

function toggleSelectAllAvailable(shouldSelect) {
    if (shouldSelect) {
        filteredAvailableStudents.forEach(student => selectedAvailableStudents.add(student.id));
    } else {
        filteredAvailableStudents.forEach(student => selectedAvailableStudents.delete(student.id));
    }
    renderAvailableStudents();
}

function updateAvailableSelectionState() {
    document.getElementById('availableSelectedCount').textContent = `${selectedAvailableStudents.size} selected`;
    const allVisibleSelected = filteredAvailableStudents.length > 0 &&
        filteredAvailableStudents.every(student => selectedAvailableStudents.has(student.id));
    document.getElementById('selectAllAvailableCheckbox').checked = allVisibleSelected;
}

async function openAddStudentModal() {
    document.getElementById('availableStudentSearch').value = '';
    await loadAvailableStudents();
    addStudentModal.show();
}

async function removeStudent(id) {
    askConfirm('Remove this student from section?', async () => {
        try {
            const res = await fetchJson('api/sectioning/remove_student.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id })
            });

            if (res.success) {
                showAlert('Student removed from section.', 'success');
                await loadMasterlist();
                await loadAvailableStudents();
            } else {
                showAlert(res.error || 'Remove failed.', 'danger');
            }
        } catch (error) {
            console.error(error);
            showAlert('Remove failed: ' + error.message, 'danger');
        }
    }, {
        title: 'Remove Student',
        okText: 'Remove',
        okClass: 'danger'
    });
}

document.getElementById('addStudentForm').addEventListener('submit', async e => {
    e.preventDefault();

    const academicYearId = document.getElementById('academicYearId').value;
    const ids = Array.from(selectedAvailableStudents);

    if (!academicYearId) {
        showAlert('No academic year found.', 'warning');
        return;
    }

    if (!ids.length) {
        showAlert('Please select at least one student.', 'warning');
        return;
    }

    let added = 0;
    let failed = 0;

    for (const studentId of ids) {
        try {
            const res = await fetchJson('api/sectioning/add_student.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    section_id: SECTION_ID,
                    academic_year_id: academicYearId,
                    student_id: studentId
                })
            });
            if (res.success) added++;
            else failed++;
        } catch (e) {
            failed++;
        }
    }

    addStudentModal.hide();
    selectedAvailableStudents.clear();
    await loadMasterlist();
    await loadAvailableStudents();

    showAlert(`Added ${added} student(s).${failed > 0 ? ` Failed: ${failed}` : ''}`, failed > 0 ? 'warning' : 'success');
});

function renderSectionView(data) {
    const section = data.section || {};
    const stats = data.stats || {};
    const maleStudents = data.male_students_list || [];
    const femaleStudents = data.female_students_list || [];
    const unknownStudents = data.unknown_students_list || [];
    const schedules = data.schedules || [];

    document.getElementById('modalSectionSubtitle').textContent =
        `${section.grade_level_name || '-'} â€¢ ${section.section_name || '-'} â€¢ S.Y. ${section.school_year || 'Not set'}`;

    document.getElementById('svSectionBar').textContent = section.section_name || '-';
    document.getElementById('svSchoolYearLine').textContent = `School Year ${section.school_year || 'Not set'}`;

    document.getElementById('svSummary').innerHTML = `
        <span class="male-count">Male: ${esc(stats.male_students || 0)}</span>
        <span class="female-count">Female: ${esc(stats.female_students || 0)}</span>
        ${Number(stats.unspecified_students || 0) > 0 ? `<span class="total-count">Unspecified: ${esc(stats.unspecified_students || 0)}</span>` : ''}
        <span class="total-count">Total: ${esc(stats.total_students || 0)}</span>
    `;

    document.getElementById('scheduleWrap').innerHTML = `
        <table class="sv-table">
            <thead>
                <tr class="sv-year-row">
                    <td colspan="6">${esc(section.grade_level_name || '')} - ${esc(section.section_name || '')}</td>
                </tr>
                <tr>
                    <th style="width:12%;">Code</th>
                    <th style="width:28%;">Course Description</th>
                    <th style="width:10%;">Day/s</th>
                    <th style="width:20%;">Time</th>
                    <th style="width:10%;">Room</th>
                    <th style="width:20%;">Faculty</th>
                </tr>
            </thead>
            <tbody>
                ${
                    !schedules.length
                    ? `<tr><td colspan="6" class="sv-center">No schedule found</td></tr>`
                    : schedules.map(r => `
                        <tr>
                            <td class="sv-center">${esc(r.subject_code || '')}</td>
                            <td>${esc(r.subject_name || '')}</td>
                            <td class="sv-center">${esc(dayLabel(r.day_of_week))}</td>
                            <td class="sv-center">${esc(formatTimeRange(r.time_start, r.time_end))}</td>
                            <td class="sv-center">${esc(r.room || '')}</td>
                            <td>${esc(r.teacher_name || '')}</td>
                        </tr>
                    `).join('')
                }
            </tbody>
        </table>
    `;

    const renderStudentColumn = (title, count, list, emptyText) => `
        <div class="gender-column">
            <div class="gender-header">${title} (${count})</div>
            ${
                list.length
                ? `<div class="student-list">
                    ${list.map((r, i) => `
                        <div class="student-item">
                            <span class="student-number">${i + 1}.</span>
                            <span class="student-id">${esc(r.student_identifier || '')}</span>
                            <span class="student-name">${esc(r.full_name || '')}</span>
                        </div>
                    `).join('')}
                </div>`
                : `<div class="sv-empty-inline">${emptyText}</div>`
            }
        </div>
    `;

    let html = `
        <div class="students-container">
            ${renderStudentColumn('MALE', maleStudents.length, maleStudents, 'No male students')}
            ${renderStudentColumn('FEMALE', femaleStudents.length, femaleStudents, 'No female students')}
        </div>
    `;

    if (unknownStudents.length) {
        html += `
            <div class="unknown-wrap">
                <div class="gender-header">UNSPECIFIED GENDER (${unknownStudents.length})</div>
                <div class="student-list">
                    ${unknownStudents.map((r, i) => `
                        <div class="student-item">
                            <span class="student-number">${i + 1}.</span>
                            <span class="student-id">${esc(r.student_identifier || '')}</span>
                            <span class="student-name">${esc(r.full_name || '')}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    if ((stats.total_students || 0) === 0) {
        html = `<div class="sv-empty-inline">No students enrolled in this section.</div>`;
    }

    document.getElementById('studentListsWrap').innerHTML = html;
}

async function openSectionViewModal() {
    try {
        const academicYearId = document.getElementById('academicYearId').value || '';

        document.getElementById('modalSectionSubtitle').textContent = 'Loading section details...';
        document.getElementById('svSectionBar').textContent = 'Loading...';
        document.getElementById('svSchoolYearLine').textContent = 'School Year -';
        document.getElementById('svSummary').innerHTML = '';
        document.getElementById('scheduleWrap').innerHTML = `<div class="ay-empty"><i class="bi bi-hourglass-split"></i><p>Loading schedule...</p></div>`;
        document.getElementById('studentListsWrap').innerHTML = `<div class="ay-empty"><i class="bi bi-hourglass-split"></i><p>Loading students...</p></div>`;

        sectionViewModal.show();

        const result = await fetchJson(`sectioning_manage.php?section_id=${SECTION_ID}&ajax=view_section&id=${SECTION_ID}&academic_year_id=${encodeURIComponent(academicYearId)}`);
        renderSectionView(result.data || {});
    } catch (error) {
        console.error(error);
        sectionViewModal.hide();
        showAlert('Unable to load section view: ' + error.message, 'danger');
    }
}

document.getElementById('studentSearchInput').addEventListener('input', loadMasterlist);
document.getElementById('availableStudentSearch').addEventListener('input', applyAvailableStudentFilter);
document.getElementById('selectAllAvailableCheckbox').addEventListener('change', e => toggleSelectAllAvailable(e.target.checked));

loadSectionInfo()
    .then(async () => {
        await loadSectionAdviser();
        await loadMasterlist();
    })
    .catch(error => {
        console.error(error);
        showAlert('Failed to load sectioning page: ' + error.message, 'danger');
    });
</script>
</body>
</html>`
