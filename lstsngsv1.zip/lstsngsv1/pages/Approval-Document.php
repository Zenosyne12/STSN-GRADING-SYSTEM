<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin();
require_once __DIR__ . '/../api/shared/db_connect.php';

$instanceId = (int)($_GET['instance_id'] ?? 0);
$documentId = trim((string)($_GET['document_id'] ?? ''));

if ($instanceId <= 0 && $documentId === '') {
    die('Missing instance or document ID.');
}

// Fetch instance + related data
$sql = "
    SELECT i.*, 
           s.section_name, s.id AS sec_id,
           gl.grade_level_name, gl.grade_level_code,
           sub.subject_name, sub.id AS sub_id,
           ay.year_label, ay.id AS year_id,
           t.term_label, t.id AS term_id
    FROM tblworkflow_instance i
    JOIN tblsection s ON s.id = i.section_id
    LEFT JOIN tblgradelevel gl ON gl.id = s.grade_level_id
    JOIN tblsubjects sub ON sub.id = i.subject_id
    JOIN tblacademicyear ay ON ay.id = i.academic_year_id
    LEFT JOIN tblconfig_terms t ON t.id = i.term_id
    WHERE " . ($instanceId > 0 ? "i.id = ?" : "i.id = (SELECT instance_id FROM tblapproval_documents WHERE document_id = ? AND is_revoked = 0 LIMIT 1)") . "
    LIMIT 1
";
$stmt = $pdo->prepare($sql);
$stmt->execute([$instanceId > 0 ? $instanceId : $documentId]);
$instance = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$instance) {
    die('Submission not found.');
}

// Fetch document record
$docStmt = $pdo->prepare("
    SELECT * FROM tblapproval_documents 
    WHERE instance_id = ? AND is_revoked = 0 
    ORDER BY id DESC LIMIT 1
");
$docStmt->execute([(int)$instance['id']]);
$document = $docStmt->fetch(PDO::FETCH_ASSOC);

// Fetch all approval actions (who approved at each step)
$logStmt = $pdo->prepare("
    SELECT l.step_order, l.actor_user_id, l.actor_position, 
           l.action, l.remarks, l.acted_at,
           t.fname AS teacher_fname, t.lname AS teacher_lname,
           ws.step_label
    FROM tblworkflow_action_log l
    LEFT JOIN tblteacher t ON t.id = l.actor_user_id
    LEFT JOIN tblworkflow_step ws ON ws.template_id = ? AND ws.step_order = l.step_order
    WHERE l.instance_id = ?
    ORDER BY l.step_order ASC, l.acted_at ASC
");
$logStmt->execute([(int)$instance['template_id'], (int)$instance['id']]);
$logs = $logStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch grades summary
$gradeStmt = $pdo->prepare("
    SELECT g.student_id, g.final_grade, g.rating_code, g.remarks,
           s.lname, s.fname, s.lrn
    FROM tblgrades g
    JOIN tblstudents s ON s.id = g.student_id
    WHERE g.section_id = ? AND g.subject_id = ? AND g.quarter = ?
      AND g.academic_year_id = ?
    ORDER BY s.lname, s.fname
");
$gradeStmt->execute([
    (int)$instance['section_id'],
    (int)$instance['subject_id'],
    (int)($instance['term_id'] ?? 0),
    (int)$instance['academic_year_id']
]);
$grades = $gradeStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Approval Document — <?= htmlspecialchars($document['document_id'] ?? 'Pending') ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        /* Print-optimized CSS */
        body {
            font-family: 'Times New Roman', serif;
            background: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        
        .no-print {
            text-align: center;
            margin-bottom: 20px;
        }
        .no-print button {
            background: #1248a8;
            color: white;
            border: none;
            padding: 10px 24px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
        }
        .no-print button:hover { background: #0d3b8a; }
        
        .document {
            background: white;
            width: 210mm;
            min-height: 297mm;
            padding: 20mm;
            margin: 0 auto;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            box-sizing: border-box;
            position: relative;
        }
        
        /* Header */
        .doc-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 3px double #1248a8;
            padding-bottom: 15px;
            margin-bottom: 25px;
        }
        .doc-header img {
            width: 70px;
            height: 70px;
            object-fit: contain;
        }
        .doc-header-center {
            text-align: center;
            flex: 1;
        }
        .doc-header-center .country { font-size: 11pt; }
        .doc-header-center .dept { font-size: 12pt; font-weight: bold; }
        .doc-header-center .school { 
            font-size: 14pt; 
            font-weight: bold; 
            text-transform: uppercase;
            color: #1248a8;
            margin-top: 4px;
        }
        .doc-header-center .address {
            font-size: 10pt;
            color: #555;
            margin-top: 2px;
        }
        
        /* Title */
        .doc-title {
            text-align: center;
            margin: 30px 0;
        }
        .doc-title h1 {
            font-size: 20pt;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin: 0;
            color: #1248a8;
            border-bottom: 2px solid #1248a8;
            display: inline-block;
            padding-bottom: 6px;
        }
        .doc-title p {
            font-size: 11pt;
            margin-top: 8px;
            color: #666;
            font-style: italic;
        }
        
        /* Info block */
        .info-block {
            background: #f9fbff;
            border: 1px solid #dce8f8;
            border-left: 4px solid #1248a8;
            padding: 15px 20px;
            margin: 25px 0;
            border-radius: 6px;
        }
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px 24px;
            font-size: 11pt;
        }
        .info-grid dt {
            font-weight: bold;
            color: #555;
            display: inline-block;
        }
        .info-grid dd {
            display: inline;
            margin-left: 6px;
            color: #1248a8;
            font-weight: 600;
        }
        /* Grades table */
        .grades-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 10pt;
            margin-top: 15px;
        }
        .grades-table th {
            background: #1248a8;
            color: white;
            padding: 8px 10px;
            text-align: left;
            font-weight: bold;
            font-size: 9.5pt;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .grades-table td {
            padding: 6px 10px;
            border-bottom: 1px solid #eee;
        }
        .grades-table tr:nth-child(even) td {
            background: #fafcff;
        }
        .grades-table .text-center { text-align: center; }
        .grade-passed { color: #0F6E56; font-weight: bold; }
        .grade-failed { color: #B42318; font-weight: bold; }
        
        /* Approvals section */
        .approvals-section {
            margin-top: 35px;
            page-break-inside: avoid;
        }
        .approvals-title {
            font-size: 12pt;
            font-weight: bold;
            color: #1248a8;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-bottom: 2px solid #1248a8;
            padding-bottom: 4px;
            margin-bottom: 20px;
        }
        
        .approval-row {
            display: grid;
            grid-template-columns: 40px 1fr 180px 120px;
            align-items: center;
            padding: 12px 15px;
            border: 1px solid #dce8f8;
            border-radius: 6px;
            margin-bottom: 10px;
            background: #fafcff;
        }
        .approval-step-num {
            font-weight: bold;
            color: #1248a8;
            font-size: 14pt;
        }
        .approval-step-info { font-size: 10pt; }
        .approval-step-info strong { display: block; font-size: 11pt; color: #132f62; }
        .approval-step-info small { color: #777; }
        .approval-signature {
            border-bottom: 1px solid #333;
            text-align: center;
            padding-bottom: 2px;
            font-style: italic;
            font-size: 10pt;
        }
        .approval-date {
            font-size: 9pt;
            color: #666;
            text-align: right;
        }
        
        /* Document ID footer */
        .doc-footer {
            position: absolute;
            bottom: 20mm;
            left: 20mm;
            right: 20mm;
            border-top: 1px solid #ccc;
            padding-top: 10px;
            display: flex;
            justify-content: space-between;
            font-size: 9pt;
            color: #777;
        }
        .doc-id {
            font-family: 'Courier New', monospace;
            font-weight: bold;
            color: #1248a8;
        }
        
        /* Official stamp */
        .official-stamp {
            position: absolute;
            right: 20mm;
            bottom: 60mm;
            border: 3px double #1248a8;
            border-radius: 50%;
            width: 100px;
            height: 100px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            font-size: 8pt;
            color: #1248a8;
            font-weight: bold;
            text-transform: uppercase;
            transform: rotate(-15deg);
            opacity: 0.85;
            line-height: 1.2;
        }
        
        /* Print */
        @media print {
            body { background: white; padding: 0; }
            .no-print { display: none; }
            .document { 
                box-shadow: none; 
                margin: 0;
                width: 100%;
                min-height: auto;
            }
            @page { size: A4 portrait; margin: 0; }
        }
    </style>
</head>
<body>
<div class="no-print">
    <button onclick="window.print()">
        <i class="bi bi-printer"></i> Print Document
    </button>
    <button onclick="window.close()" style="background:#6c757d;margin-left:10px;">
        <i class="bi bi-x-lg"></i> Close
    </button>
</div>

<div class="document">
    <!-- Header -->
    <div class="doc-header">
        <img src="../assets/img/deped.png" alt="DepEd">
        <div class="doc-header-center">
            <div class="country">Republic of the Philippines</div>
            <div class="dept">Department of Education</div>
            <div class="school">St. Theresa's School of Novaliches</div>
            <div class="address">Novaliches, Quezon City</div>
        </div>
        <img src="../assets/img/stsn logo.png" alt="STSN">
    </div>
    
    <!-- Title -->
    <div class="doc-title">
        <h1>Certificate of Grade Approval</h1>
        <p>Official document certifying that the following grades have been reviewed and approved</p>
    </div>
    
    <!-- Info block -->
    <div class="info-block">
        <div class="info-grid">
            <div><dt>Section:</dt> <dd><?= htmlspecialchars($instance['section_name']) ?></dd></div>
            <div><dt>Subject:</dt> <dd><?= htmlspecialchars($instance['subject_name']) ?></dd></div>
            <div><dt>Grade Level:</dt> <dd><?= htmlspecialchars($instance['grade_level_name'] ?? '—') ?></dd></div>
            <div><dt>Term:</dt> <dd><?= htmlspecialchars($instance['term_label'] ?? '—') ?></dd></div>
            <div><dt>School Year:</dt> <dd><?= htmlspecialchars($instance['year_label']) ?></dd></div>
            <div><dt>Status:</dt> <dd><?= htmlspecialchars($instance['status']) ?></dd></div>
        </div>
    </div>
    
    <!-- Grades table -->
    <?php if (!empty($grades)): ?>
    <div style="font-size:11pt;font-weight:bold;color:#1248a8;text-transform:uppercase;letter-spacing:1px;margin-top:20px;border-bottom:1px solid #1248a8;padding-bottom:4px;">
        Student Grades Summary
    </div>
    <table class="grades-table">
        <thead>
            <tr>
                <th style="width:50px;">#</th>
                <th>Student Name</th>
                <th style="width:140px;">LRN</th>
                <th class="text-center" style="width:90px;">Final Grade</th>
                <th class="text-center" style="width:100px;">Remarks</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($grades as $i => $g): ?>
            <tr>
                <td><?= $i + 1 ?></td>
                <td><?= htmlspecialchars($g['lname'] . ', ' . $g['fname']) ?></td>
                <td><?= htmlspecialchars($g['lrn'] ?? '') ?></td>
                <td class="text-center <?= ($g['remarks'] ?? '') === 'Passed' ? 'grade-passed' : 'grade-failed' ?>">
                    <?= $g['final_grade'] !== null ? number_format((float)$g['final_grade'], 0) : '—' ?>
                </td>
                <td class="text-center <?= ($g['remarks'] ?? '') === 'Passed' ? 'grade-passed' : 'grade-failed' ?>">
                    <?= htmlspecialchars($g['remarks'] ?? '—') ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
    <!-- Approvals -->
    <div class="approvals-section">
        <div class="approvals-title">Approval Chain</div>
        <?php foreach ($logs as $log): 
            $isApproved = in_array(strtoupper($log['action']), ['APPROVED', 'FINALIZED', 'PUBLISHED'], true);
            if (!$isApproved) continue;
        ?>
        <div class="approval-row">
            <div class="approval-step-num"><?= (int)$log['step_order'] ?></div>
            <div class="approval-step-info">
                <strong><?= htmlspecialchars($log['step_label'] ?? 'Step ' . $log['step_order']) ?></strong>
                <small><?= htmlspecialchars($log['actor_position'] ?? '') ?></small>
            </div>
            <div class="approval-signature">
                <?= htmlspecialchars(trim(($log['teacher_fname'] ?? '') . ' ' . ($log['teacher_lname'] ?? ''))) ?>
            </div>
            <div class="approval-date">
                <?= !empty($log['acted_at']) ? date('M j, Y', strtotime($log['acted_at'])) : '—' ?>
            </div>
        </div>
        <?php endforeach; ?>
        
        <?php if (empty($logs)): ?>
        <div style="padding:20px;text-align:center;color:#999;font-style:italic;">
            No approval actions recorded yet.
        </div>
        <?php endif; ?>
    </div>
    
    <!-- Official stamp -->
    <?php if ($document): ?>
    <div class="official-stamp">
        OFFICIALLY<br>APPROVED<br><br><?= date('Y', strtotime($document['generated_at'])) ?>
    </div>
    <?php endif; ?>
    
    <!-- Footer -->
    <div class="doc-footer">
        <div>
            <strong>Document ID:</strong>
            <span class="doc-id"><?= htmlspecialchars($document['document_id'] ?? 'NOT GENERATED') ?></span>
        </div>
        <div>
            Generated: <?= $document ? date('M j, Y g:i A', strtotime($document['generated_at'])) : '—' ?>
        </div>
    </div>
</div>

</body>
</html>

