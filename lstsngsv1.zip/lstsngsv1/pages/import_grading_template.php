<?php

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../api/login/teacher_auth.php';
require_once __DIR__ . '/../includes/grading_engine.php';
require_once __DIR__ . '/../includes/grading_xlsx.php';
require_once __DIR__ . '/../includes/archive_engine.php';
require_once __DIR__ . '/../api/deadline/check_submission_lock.php';

$templateConfigs = require __DIR__ . '/../includes/grading_templates_config.php';

function gradingTemplateImportResponse(array $payload, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    gradingTemplateImportResponse(['status' => 'error', 'error' => 'Upload the template using POST.'], 405);
}

$sectionId = (int)($_POST['section_id'] ?? 0);
$subjectId = (int)($_POST['subject_id'] ?? 0);
$teacherId = (int)($_SESSION['teacher_id'] ?? 0);
if ($sectionId <= 0 || $subjectId <= 0 || $teacherId <= 0) {
    gradingTemplateImportResponse(['status' => 'error', 'error' => 'A valid section and subject are required.'], 400);
}

if (!isset($_FILES['template_file']) || !is_array($_FILES['template_file'])) {
    gradingTemplateImportResponse(['status' => 'error', 'error' => 'Choose an .xlsx template to upload.'], 400);
}
$file = $_FILES['template_file'];
if ((int)($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
    gradingTemplateImportResponse(['status' => 'error', 'error' => 'The workbook upload did not complete. Please try again.'], 400);
}
if (strtolower(pathinfo((string)($file['name'] ?? ''), PATHINFO_EXTENSION)) !== 'xlsx') {
    gradingTemplateImportResponse(['status' => 'error', 'error' => 'Only .xlsx files are accepted. .xls and .csv files are not supported.'], 415);
}
if ((int)($file['size'] ?? 0) > 20 * 1024 * 1024 || !is_uploaded_file((string)($file['tmp_name'] ?? ''))) {
    gradingTemplateImportResponse(['status' => 'error', 'error' => 'The upload is invalid or exceeds the 20 MB limit.'], 400);
}

try {
    $rows = stsnXlsxRead((string)$file['tmp_name']);
    $termHeader = trim((string)($rows[2][0] ?? ''));
    $termLabel = trim(explode('|', $termHeader, 2)[0]);
    if ($termLabel === '') {
        gradingTemplateImportResponse([
            'status' => 'error',
            'error' => 'The workbook is missing its term label in Row 2.',
        ], 422);
    }

    $expectedHeaders = [
        0 => '#',
        1 => 'LRN',
        2 => "LEARNER'S NAME",
        20 => 'INITIAL GRADE',
        21 => 'TERM GRADE',
        22 => 'DESCRIPTOR',
    ];
    foreach ($expectedHeaders as $column => $expectedHeader) {
        if (strtoupper(trim((string)($rows[5][$column] ?? ''))) !== $expectedHeader) {
            gradingTemplateImportResponse([
                'status' => 'error',
                'error' => 'This workbook does not match the Grades 4–10 grading template. Download a fresh template and try again.',
            ], 422);
        }
    }
    if (
        stripos((string)($rows[4][3] ?? ''), 'WRITTEN / ORAL WORKS') !== 0
        || stripos((string)($rows[4][11] ?? ''), 'PRODUCT / PERFORMANCE TASKS') !== 0
        || stripos((string)($rows[4][17] ?? ''), 'EXAMINATIONS') !== 0
        || strtoupper(trim((string)($rows[7][2] ?? ''))) !== 'HIGHEST POSSIBLE SCORE'
    ) {
        gradingTemplateImportResponse([
            'status' => 'error',
            'error' => 'This workbook does not match the Grades 4–10 grading template. Download a fresh template and try again.',
        ], 422);
    }

    $wwWeight = is_numeric($rows[7][10] ?? null) ? (float)$rows[7][10] : null;
    $ptWeight = is_numeric($rows[7][16] ?? null) ? (float)$rows[7][16] : null;
    $weights = null;
    foreach ($templateConfigs as $templateConfig) {
        if (
            $wwWeight === (float)$templateConfig['ww']
            && $ptWeight === (float)$templateConfig['pt']
        ) {
            $weights = [
                'ww' => (float)$templateConfig['ww'],
                'pt' => (float)$templateConfig['pt'],
                'qa' => (float)$templateConfig['qa'],
            ];
            break;
        }
    }
    if ($weights === null) {
        gradingTemplateImportResponse([
            'status' => 'error',
            'error' => 'Invalid weight configuration in file header.',
        ], 422);
    }

    $termStmt = $pdo->prepare("
        SELECT t.id, t.term_number, t.term_label, ay.id AS academic_year_id, ay.year_label
        FROM tblconfig_terms t
        JOIN tblacademicyear ay ON ay.id = t.academic_year_id
        WHERE ay.is_active = 1 AND t.is_active = 1 AND t.is_closed = 0
          AND t.term_label = :term_label
        ORDER BY t.term_number ASC
        LIMIT 1
    ");
    $termStmt->execute(['term_label' => $termLabel]);
    $term = $termStmt->fetch(PDO::FETCH_ASSOC);
    if (!$term) {
        gradingTemplateImportResponse([
            'status' => 'error',
            'error' => 'Term label in file does not match any active term.',
        ], 409);
    }

    $contextStmt = $pdo->prepare("
        SELECT s.id AS section_id, s.grade_level_id, gl.grade_level_code,
               sub.id AS subject_id, ay.id AS academic_year_id, ay.year_label
        FROM tblsection s
        JOIN tblgradelevel gl ON gl.id = s.grade_level_id
        JOIN tblsubjects sub
          ON sub.id = :subject_id
         AND sub.grade_level_id = s.grade_level_id
         AND CAST(sub.strand AS CHAR) <=> CAST(s.strand AS CHAR)
         AND sub.academic_year_id = :subject_year_id
        JOIN tblacademicyear ay ON ay.id = :year_id AND ay.is_active = 1
        WHERE s.id = :section_id AND s.is_active = 1
        LIMIT 1
    ");
    $contextStmt->execute([
        'subject_id' => $subjectId,
        'subject_year_id' => (int)$term['academic_year_id'],
        'year_id' => (int)$term['academic_year_id'],
        'section_id' => $sectionId,
    ]);
    $context = $contextStmt->fetch(PDO::FETCH_ASSOC);
    if (!$context) {
        gradingTemplateImportResponse(['status' => 'error', 'error' => 'The selected section and subject do not match the active school year.'], 404);
    }

    $gradeCode = (int)$context['grade_level_code'];
    if ($gradeCode < 4 || $gradeCode > 10) {
        gradingTemplateImportResponse(['status' => 'error', 'error' => 'Grade imports from this template are limited to Grades 4–10.'], 403);
    }

    $scheduleStmt = $pdo->prepare("
        SELECT 1
        FROM tblschedule
        WHERE section_id = ? AND subject_id = ? AND teacher_id = ?
          AND is_active = 1 AND school_year = ?
        LIMIT 1
    ");
    $scheduleStmt->execute([$sectionId, $subjectId, $teacherId, $term['year_label']]);
    if (!$scheduleStmt->fetchColumn()) {
        gradingTemplateImportResponse(['status' => 'error', 'error' => 'You are not assigned to this section and subject.'], 403);
    }

    if (isTermLocked($pdo, $sectionId, $subjectId, (int)$term['term_number'])) {
        gradingTemplateImportResponse(['status' => 'error', 'error' => 'This term is locked and cannot be overwritten.'], 409);
    }
    checkSubmissionLock(
        $pdo,
        $teacherId,
        $sectionId,
        $subjectId,
        (int)$term['term_number'],
        (string)$term['year_label'],
        'teacher'
    );

    $candidateRows = [];
    $invalidStudents = [];
    foreach ($rows as $rowNumber => $row) {
        if ((int)$rowNumber < 8) {
            continue;
        }
        $lrn = trim((string)($row[1] ?? ''));
        $name = trim((string)($row[2] ?? ''));
        if ($name === '') {
            continue;
        }
        $candidateRows[] = [
            'row' => (int)$rowNumber,
            'lrn' => $lrn,
            'name' => $name,
            'ww_items' => [$row[3] ?? '', $row[4] ?? '', $row[5] ?? '', $row[6] ?? '', $row[7] ?? ''],
            'pt_items' => [$row[11] ?? '', $row[12] ?? '', $row[13] ?? ''],
            'exam_items' => [$row[17] ?? '', $row[18] ?? '', $row[19] ?? ''],
        ];
    }
    if (!$candidateRows) {
        gradingTemplateImportResponse(['status' => 'error', 'error' => 'No student rows were found in the workbook.'], 422);
    }

    $pdo->beginTransaction();
    $enrollmentStmt = $pdo->prepare("
        SELECT s.id, s.lrn, CONCAT(s.lname, ', ', s.fname, ' ', COALESCE(s.mname, '')) AS student_name
        FROM tblstudents s
        INNER JOIN tblsectionstudent ss ON ss.student_id = s.id
        WHERE ss.section_id = ? AND ss.is_active = 1 AND ss.academic_year_id = ?
        FOR UPDATE
    ");
    $enrollmentStmt->execute([$sectionId, (int)$term['academic_year_id']]);
    $enrolled = $enrollmentStmt->fetchAll(PDO::FETCH_ASSOC);
    $byLrn = [];
    $byName = [];
    $lrnByStudentId = [];
    foreach ($enrolled as $student) {
        $studentId = (int)$student['id'];
        if ((string)($student['lrn'] ?? '') !== '') {
            $byLrn[(string)$student['lrn']][] = $studentId;
            $lrnByStudentId[$studentId] = (string)$student['lrn'];
        }
        $normalizedName = preg_replace('/\s+/u', ' ', trim((string)$student['student_name']));
        $normalizedName = function_exists('mb_strtolower')
            ? mb_strtolower($normalizedName, 'UTF-8')
            : strtolower($normalizedName);
        $byName[$normalizedName][] = $studentId;
    }

    $masterlistStmt = $pdo->prepare('SELECT id FROM tblstudents WHERE lrn = ? LIMIT 1');
    $scoreErrors = [];
    $records = [];
    $usedStudentIds = [];
    foreach ($candidateRows as $candidate) {
        $studentId = 0;
        if ($candidate['lrn'] !== '') {
            if (isset($byLrn[$candidate['lrn']]) && count($byLrn[$candidate['lrn']]) === 1) {
                $studentId = $byLrn[$candidate['lrn']][0];
            } else {
                $masterlistStmt->execute([$candidate['lrn']]);
                $masterlistStudentId = $masterlistStmt->fetchColumn();
                $invalidStudents[] = [
                    'row' => $candidate['row'],
                    'student_name' => $candidate['name'],
                    'lrn' => $candidate['lrn'],
                    'message' => isset($byLrn[$candidate['lrn']])
                        ? 'LRN matches multiple enrolled students; correct the section masterlist.'
                        : ($masterlistStudentId === false
                        ? 'LRN is not in the student masterlist.'
                        : 'Student is not enrolled in this section for the active school year.'),
                ];
                continue;
            }
        } else {
            $normalizedName = preg_replace('/\s+/u', ' ', trim($candidate['name']));
            $normalizedName = function_exists('mb_strtolower')
                ? mb_strtolower($normalizedName, 'UTF-8')
                : strtolower($normalizedName);
            $matches = $byName[$normalizedName] ?? [];
            if (count($matches) === 1) {
                $studentId = $matches[0];
            } else {
                $invalidStudents[] = [
                    'row' => $candidate['row'],
                    'student_name' => $candidate['name'],
                    'lrn' => '',
                    'message' => count($matches) > 1
                        ? 'Student name matches more than one enrolled student; provide an LRN.'
                        : 'Student name does not exactly match an enrolled student in this section.',
                ];
                continue;
            }
        }

        if (isset($usedStudentIds[$studentId])) {
            $duplicateLrn = $candidate['lrn'] !== ''
                ? $candidate['lrn']
                : (string)($lrnByStudentId[$studentId] ?? '');
            $duplicateMessage = $duplicateLrn !== ''
                ? 'Duplicate LRN detected: ' . $duplicateLrn . ' appears in row '
                    . $usedStudentIds[$studentId] . ' and row ' . $candidate['row']
                    . '. Each student must appear only once.'
                : 'Student appears more than once in the workbook, in row '
                    . $usedStudentIds[$studentId] . ' and row ' . $candidate['row'] . '.';
            $invalidStudents[] = [
                'row' => $candidate['row'],
                'student_name' => $candidate['name'],
                'lrn' => $duplicateLrn,
                'message' => $duplicateMessage,
            ];
            continue;
        }
        $usedStudentIds[$studentId] = (int)$candidate['row'];

        $scores = [];
        foreach (['ww_items' => 'ww_total', 'pt_items' => 'pt_total', 'exam_items' => 'qa_total'] as $itemField => $totalField) {
            $total = 0.0;
            foreach ($candidate[$itemField] as $itemIndex => $rawItemScore) {
                $rawScore = trim((string)$rawItemScore);
                if ($rawScore === '') {
                    $rawScore = '0';
                }
                if (!is_numeric($rawScore)) {
                    $scoreErrors[] = 'Row ' . $candidate['row'] . ': ' . strtoupper(str_replace('_', ' ', $totalField)) . ' item ' . ($itemIndex + 1) . ' must be a number.';
                    continue 3;
                }
                $score = (float)$rawScore;
                if (!is_finite($score) || $score < 0 || $score > 100) {
                    $scoreErrors[] = 'Row ' . $candidate['row'] . ': ' . strtoupper(str_replace('_', ' ', $totalField)) . ' item ' . ($itemIndex + 1) . ' must be between 0 and 100.';
                    continue 3;
                }
                $total += $score;
            }
            if ($total > 100) {
                $scoreErrors[] = 'Row ' . $candidate['row'] . ': total ' . strtoupper(str_replace('_', ' ', $totalField)) . ' cannot exceed 100.';
                continue 2;
            }
            $scores[$totalField] = $total;
        }
        $records[] = ['student_id' => $studentId, 'scores' => $scores];
    }

    if ($invalidStudents) {
        $pdo->rollBack();
        gradingTemplateImportResponse([
            'status' => 'error',
            'error' => 'Import rejected. Every student must be enrolled in this section; no grades were changed.',
            'invalid_students' => $invalidStudents,
        ], 422);
    }
    if ($scoreErrors) {
        $pdo->rollBack();
        gradingTemplateImportResponse([
            'status' => 'error',
            'error' => 'Import rejected because one or more scores are invalid; no grades were changed.',
            'errors' => $scoreErrors,
        ], 422);
    }

    $programId = function_exists('geResolveProgramId') ? geResolveProgramId($pdo, $sectionId) : null;
    $template = getActiveGradingTemplate($pdo, (int)$context['grade_level_id'], $programId);
    if ($template === null) {
        $pdo->rollBack();
        gradingTemplateImportResponse(['status' => 'error', 'error' => 'No active grading template is configured for this grade level.'], 409);
    }

    $insertStmt = $pdo->prepare("
        INSERT INTO tblgrades (
            student_id, section_id, subject_id, teacher_id, quarter, academic_year_id,
            ww_total, pt_total, qa_total, ww_ps, pt_ps, qa_ps, ww_ws, pt_ws, qa_ws,
            initial_grade, final_grade, remarks, status, rating_code, grading_mode,
            created_at, updated_at
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', NULL, 'NUMERICAL', NOW(), NOW()
        )
    ");
    $deleteStmt = $pdo->prepare("
        DELETE FROM tblgrades
        WHERE section_id = ? AND subject_id = ? AND quarter = ? AND academic_year_id = ?
    ");
    $deleteStmt->execute([
        $sectionId,
        $subjectId,
        (int)$term['term_number'],
        (int)$term['academic_year_id'],
    ]);

    foreach ($records as $record) {
        $scores = $record['scores'];
        $computed = computeFinalGrade($pdo, [
            'ww_total' => $scores['ww_total'],
            'pt_total' => $scores['pt_total'],
            'qa_total' => $scores['qa_total'],
            'hps_ww' => 100,
            'hps_pt' => 100,
            'hps_qa' => 100,
            'grade_level_id' => (int)$context['grade_level_id'],
            'program_id' => $programId,
            'weights' => $weights,
        ]);
        $remarks = (string)($computed['remarks'] ?? '');
        if ($remarks === '') {
            $remarks = (int)$computed['final_grade'] >= (int)$template['passing_threshold'] ? 'Passed' : 'Failed';
        }
        $insertStmt->execute([
            $record['student_id'],
            $sectionId,
            $subjectId,
            $teacherId,
            (int)$term['term_number'],
            (int)$term['academic_year_id'],
            $scores['ww_total'],
            $scores['pt_total'],
            $scores['qa_total'],
            $computed['ww_ps'],
            $computed['pt_ps'],
            $computed['qa_ps'],
            $computed['ww_ws'],
            $computed['pt_ws'],
            $computed['qa_ws'],
            $computed['initial_grade'],
            $computed['final_grade'],
            $remarks,
        ]);
    }

    $pdo->commit();
    gradingTemplateImportResponse(['status' => 'success', 'count' => count($records)]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('GRADING IMPORT ERROR: ' . $e->getMessage() . ' at ' . $e->getFile() . ':' . $e->getLine());
    gradingTemplateImportResponse([
        'status' => 'error',
        'error' => 'Import failed: ' . $e->getMessage(),
        'message' => 'Import failed: ' . $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine(),
    ], 500);
}
