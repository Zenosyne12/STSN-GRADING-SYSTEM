<?php
require_once __DIR__ . '/../api/login/teacher_auth.php';

$teacherName = $_SESSION['teacher_name'] ?? 'Teacher';
$teacherId = $_SESSION['teacher_id'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard | STSN Grading System</title>

    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/dashboard.css">
</head>

<body class="stsn-layout">
    <button id="stsn-toggle" aria-label="Toggle sidebar">
        <i class="bi bi-list"></i>
    </button>

    <div id="stsn-overlay"></div>

    <?php include __DIR__ . '/../includes/teacher-sidebar.php'; ?>

    <div class="dashboard-shell">
        <main class="dashboard-main">
            <section class="dashboard-header">
                <div class="dashboard-header-left">
                    <p class="page-kicker">Teacher Workspace</p>
                    <h1>Welcome back, <?php echo htmlspecialchars($teacherName); ?></h1>
                    <p class="page-subtitle">
                        View pending grade work, managed classes, student alerts, and school reminders in one place.
                    </p>
                </div>

                <div class="dashboard-header-right">
                    <div class="meta-chip"><i class="bi bi-calendar3"></i> 3rd Quarter</div>
                    <div class="meta-chip"><i class="bi bi-mortarboard"></i> SY 2025–2026</div>
                    <div class="meta-chip"><i class="bi bi-clock-history"></i> Last login: Today, 8:12 AM</div>
                </div>
            </section>

            <section class="priority-strip">
                <div class="priority-card danger">
                    <div class="priority-icon"><i class="bi bi-pencil-square"></i></div>
                    <div class="priority-content">
                        <div class="priority-label">Urgent</div>
                        <div class="priority-title">18 pending grade entries</div>
                        <div class="priority-sub">Finalize incomplete grading sheets before submission deadline.</div>
                    </div>
                    <button class="priority-btn" type="button">Open Grading Sheet</button>
                </div>

                <div class="priority-card warning">
                    <div class="priority-icon"><i class="bi bi-exclamation-triangle"></i></div>
                    <div class="priority-content">
                        <div class="priority-label">Attention Needed</div>
                        <div class="priority-title">7 students flagged as at-risk</div>
                        <div class="priority-sub">Prediction results suggest intervention may be needed this quarter.
                        </div>
                    </div>
                    <button class="priority-btn" type="button">View Predictions</button>
                </div>
            </section>

            <section class="stats-grid">
                <article class="stat-card">
                    <div class="stat-top">
                        <span class="stat-title">My Advisory</span>
                        <span class="stat-icon"><i class="bi bi-person-badge"></i></span>
                    </div>
                    <h3>Grade 10</h3>
                    <p>St. John • 42 students</p>
                </article>

                <article class="stat-card">
                    <div class="stat-top">
                        <span class="stat-title">Handled Classes</span>
                        <span class="stat-icon"><i class="bi bi-journal-bookmark-fill"></i></span>
                    </div>
                    <h3>5</h3>
                    <p>Across Mathematics, Science, and English</p>
                </article>

                <article class="stat-card">
                    <div class="stat-top">
                        <span class="stat-title">Total Students</span>
                        <span class="stat-icon"><i class="bi bi-people"></i></span>
                    </div>
                    <h3>142</h3>
                    <p>Across all subject loads</p>
                </article>

                <article class="stat-card">
                    <div class="stat-top">
                        <span class="stat-title">Honors Review</span>
                        <span class="stat-icon"><i class="bi bi-trophy"></i></span>
                    </div>
                    <h3>4</h3>
                    <p>Students near honors validation threshold</p>
                </article>
            </section>

            <section class="dashboard-grid">
                <div class="main-column">
                    <article class="panel">
                        <div class="panel-header">
                            <div>
                                <h2><i class="bi bi-lightning-charge-fill"></i> Quick Actions</h2>
                                <p>Go directly to the tasks teachers use most.</p>
                            </div>
                        </div>

                        <div class="quick-actions-grid">
                            <button class="quick-action primary" type="button">
                                <span class="quick-action-icon"><i class="bi bi-pencil-square"></i></span>
                                <span class="quick-action-text">
                                    <strong>Encode Grades</strong>
                                    <small>Open digital grading sheet and submit scores</small>
                                </span>
                            </button>

                            <button class="quick-action" type="button">
                                <span class="quick-action-icon"><i class="bi bi-people"></i></span>
                                <span class="quick-action-text">
                                    <strong>Class Lists</strong>
                                    <small>View students by subject and section</small>
                                </span>
                            </button>

                            <button class="quick-action" type="button">
                                <span class="quick-action-icon"><i class="bi bi-star"></i></span>
                                <span class="quick-action-text">
                                    <strong>Character Evaluation</strong>
                                    <small>Complete behavior and values assessment</small>
                                </span>
                            </button>

                            <button class="quick-action" type="button">
                                <span class="quick-action-icon"><i class="bi bi-graph-up-arrow"></i></span>
                                <span class="quick-action-text">
                                    <strong>Performance Prediction</strong>
                                    <small>Review student risk and academic trends</small>
                                </span>
                            </button>

                            <button class="quick-action" type="button">
                                <span class="quick-action-icon"><i class="bi bi-trophy"></i></span>
                                <span class="quick-action-text">
                                    <strong>Honors Detection</strong>
                                    <small>Check qualified and near-qualified students</small>
                                </span>
                            </button>

                            <button class="quick-action" type="button">
                                <span class="quick-action-icon"><i class="bi bi-file-earmark-bar-graph"></i></span>
                                <span class="quick-action-text">
                                    <strong>Generate Reports</strong>
                                    <small>Create summaries, lists, and report outputs</small>
                                </span>
                            </button>
                        </div>
                    </article>

                    <article class="panel">
                        <div class="panel-header split">
                            <div>
                                <h2><i class="bi bi-journal-text"></i> My Subject Classes</h2>
                                <p>Current teaching loads and grading progress.</p>
                            </div>
                            <a href="My-Subjects.php" class="panel-link">Open My Subjects</a>
                        </div>

                        <div class="table-wrap">
                            <table class="subject-table">
                                <thead>
                                    <tr>
                                        <th>Subject</th>
                                        <th>Section</th>
                                        <th class="center">Students</th>
                                        <th class="center">Pending</th>
                                        <th class="center">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <strong>Mathematics</strong>
                                            <span>WW, PT, QA encoding ongoing</span>
                                        </td>
                                        <td>Grade 10 - St. John</td>
                                        <td class="center">42</td>
                                        <td class="center"><span class="pill warning">5</span></td>
                                        <td class="center"><span class="pill danger">Not Submitted</span></td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <strong>Mathematics</strong>
                                            <span>Quarter records in progress</span>
                                        </td>
                                        <td>Grade 9 - St. Luke</td>
                                        <td class="center">38</td>
                                        <td class="center"><span class="pill warning">3</span></td>
                                        <td class="center"><span class="pill danger">Not Submitted</span></td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <strong>Science</strong>
                                            <span>Scores validated and reviewed</span>
                                        </td>
                                        <td>Grade 10 - St. John</td>
                                        <td class="center">42</td>
                                        <td class="center"><span class="pill success">2</span></td>
                                        <td class="center"><span class="pill success">Submitted</span></td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <strong>Science</strong>
                                            <span>Needs completion before deadline</span>
                                        </td>
                                        <td>Grade 8 - St. Mark</td>
                                        <td class="center">35</td>
                                        <td class="center"><span class="pill warning">4</span></td>
                                        <td class="center"><span class="pill danger">Not Submitted</span></td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <strong>English</strong>
                                            <span>Ready for report generation</span>
                                        </td>
                                        <td>Grade 9 - St. Luke</td>
                                        <td class="center">38</td>
                                        <td class="center"><span class="pill success">1</span></td>
                                        <td class="center"><span class="pill success">Submitted</span></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </article>

                    <article class="panel">
                        <div class="panel-header split">
                            <div>
                                <h2><i class="bi bi-person-lines-fill"></i> Advisory Overview</h2>
                                <p>Quick view of your advisory class status.</p>
                            </div>
                            <a href="My-Advisory.php" class="panel-link">Open Advisory</a>
                        </div>

                        <div class="advisory-grid">
                            <div class="advisory-box">
                                <span class="label">Section</span>
                                <strong>Grade 10 - St. John</strong>
                            </div>
                            <div class="advisory-box">
                                <span class="label">Students</span>
                                <strong>42</strong>
                            </div>
                            <div class="advisory-box">
                                <span class="label">Attendance Concern</span>
                                <strong>3 students</strong>
                            </div>
                            <div class="advisory-box">
                                <span class="label">Pending Eval</span>
                                <strong>5 items</strong>
                            </div>
                        </div>
                    </article>
                </div>

                <aside class="side-column">
                    <article class="panel side-panel">
                        <div class="panel-header split">
                            <div>
                                <h2><i class="bi bi-list-task"></i> Pending Tasks</h2>
                                <p>What needs attention today.</p>
                            </div>
                        </div>

                        <div class="stack-list">
                            <div class="stack-item">
                                <div>
                                    <strong>Grade 10 - St. John grading sheet</strong>
                                    <p>5 student grade entries still incomplete</p>
                                </div>
                                <span class="pill warning">Due Mar 30</span>
                            </div>

                            <div class="stack-item">
                                <div>
                                    <strong>Character Evaluation</strong>
                                    <p>One handled section still pending submission</p>
                                </div>
                                <span class="pill warning">Due Apr 5</span>
                            </div>

                            <div class="stack-item">
                                <div>
                                    <strong>Honors validation</strong>
                                    <p>Review 4 students near honors threshold</p>
                                </div>
                                <span class="pill success">Review</span>
                            </div>
                        </div>
                    </article>

                    <article class="panel side-panel">
                        <div class="panel-header split">
                            <div>
                                <h2><i class="bi bi-exclamation-triangle-fill"></i> At-Risk Students</h2>
                                <p>Prediction and trend alerts.</p>
                            </div>
                        </div>

                        <div class="stack-list">
                            <div class="stack-item">
                                <div>
                                    <strong>Juan Dela Cruz</strong>
                                    <p>Math average dropped to 72% this quarter</p>
                                </div>
                                <span class="pill danger">High Risk</span>
                            </div>

                            <div class="stack-item">
                                <div>
                                    <strong>Maria Santos</strong>
                                    <p>Science trend is now below passing threshold</p>
                                </div>
                                <span class="pill warning">Moderate</span>
                            </div>

                            <div class="stack-item">
                                <div>
                                    <strong>Carlos Reyes</strong>
                                    <p>English outputs show inconsistent performance</p>
                                </div>
                                <span class="pill warning">Moderate</span>
                            </div>
                        </div>
                    </article>

                    <article class="panel side-panel">
                        <div class="panel-header split">
                            <div>
                                <h2><i class="bi bi-bell-fill"></i> Notifications</h2>
                                <p>Recent reminders and updates.</p>
                            </div>
                        </div>

                        <div class="notice-list">
                            <div class="notice-item">
                                <span class="notice-icon"><i class="bi bi-megaphone"></i></span>
                                <div>
                                    <strong>Grade submission reminder</strong>
                                    <p>All subject teachers must finalize quarter grades by March 30.</p>
                                </div>
                            </div>

                            <div class="notice-item">
                                <span class="notice-icon"><i class="bi bi-file-earmark-text"></i></span>
                                <div>
                                    <strong>Report generation is now available</strong>
                                    <p>You may now generate class summaries and performance reports.</p>
                                </div>
                            </div>

                            <div class="notice-item">
                                <span class="notice-icon"><i class="bi bi-stars"></i></span>
                                <div>
                                    <strong>Honors list updated</strong>
                                    <p>Eligibility and ranking data were refreshed today.</p>
                                </div>
                            </div>
                        </div>
                    </article>
                </aside>
            </section>
        </main>
    </div>

    <script>
        const sidebar = document.getElementById('stsn-sidebar');
        const toggleBtn = document.getElementById('stsn-toggle');
        const overlay = document.getElementById('stsn-overlay');
        const collapseBtn = document.getElementById('stsn-collapse-btn');

        const savedState = localStorage.getItem('stsn-sidebar-collapsed');

        if (sidebar && savedState === 'true' && window.innerWidth >= 992) {
            sidebar.classList.add('collapsed');
            document.body.classList.add('sidebar-collapsed');
        }

        if (collapseBtn && sidebar) {
            collapseBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                sidebar.classList.toggle('collapsed');

                const isCollapsed = sidebar.classList.contains('collapsed');
                document.body.classList.toggle('sidebar-collapsed', isCollapsed);
                localStorage.setItem('stsn-sidebar-collapsed', isCollapsed);
            });
        }

        if (toggleBtn && sidebar) {
            toggleBtn.addEventListener('click', function () {
                sidebar.classList.toggle('mobile-open');
                overlay.classList.toggle('visible');
            });
        }

        if (overlay && sidebar) {
            overlay.addEventListener('click', function () {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('visible');
            });
        }

        window.addEventListener('resize', function () {
            if (!sidebar) return;

            if (window.innerWidth >= 992) {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('visible');
            } else {
                document.body.classList.remove('sidebar-collapsed');
            }
        });
    </script>
</body>

</html>