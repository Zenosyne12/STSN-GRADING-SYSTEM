<?php
require_once __DIR__ . '/../api/login/teacher_auth.php';

$teacherName = $_SESSION['teacher_name'] ?? 'Teacher';
$teacherId = $_SESSION['teacher_id'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard | STSN Grading System</title>

    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/dashboard.css">
</head>

<body class="stsn-layout no-scroll">
    <button id="stsn-toggle" aria-label="Toggle sidebar">
        <i class="bi bi-list"></i>
    </button>

    <div id="stsn-overlay"></div>

    <?php include __DIR__ . '/../includes/teacher-sidebar.php'; ?>

    <div class="dashboard-shell compact">
        <main class="dashboard-main compact">

            <!-- HEADER -->
            <section class="dashboard-header compact">
                <div class="dashboard-header-left">
                    <p class="page-kicker">Teacher Workspace</p>
                    <h1>Welcome back, <?php echo htmlspecialchars($teacherName); ?></h1>
                    <p class="page-subtitle">
                        Track grading progress, monitor at-risk students, and stay on top of school reminders.
                    </p>
                </div>

                <div class="dashboard-header-right">
                    <div class="meta-chip"><i class="bi bi-calendar3"></i> 3rd Quarter</div>
                    <div class="meta-chip"><i class="bi bi-mortarboard"></i> SY 2025–2026</div>
                    <div class="meta-chip danger"><i class="bi bi-hourglass-split"></i> Closes in 4 days</div>
                </div>
            </section>

            <!-- STATS -->
            <section class="stats-grid">
                <article class="stat-card">
                    <div class="stat-top">
                        <span class="stat-title">My Advisory</span>
                        <span class="stat-icon"><i class="bi bi-person-badge"></i></span>
                    </div>
                    <h3>Grade 10</h3>
                    <p>St. John • 42 students</p>
                </article>

                <article class="stat-card">
                    <div class="stat-top">
                        <span class="stat-title">Handled Classes</span>
                        <span class="stat-icon"><i class="bi bi-journal-bookmark-fill"></i></span>
                    </div>
                    <h3>5</h3>
                    <p>Mathematics, Science, English</p>
                </article>

                <article class="stat-card">
                    <div class="stat-top">
                        <span class="stat-title">Total Students</span>
                        <span class="stat-icon"><i class="bi bi-people"></i></span>
                    </div>
                    <h3>142</h3>
                    <p>Across all subject loads</p>
                </article>

                <article class="stat-card">
                    <div class="stat-top">
                        <span class="stat-title">Grading Progress</span>
                        <span class="stat-icon"><i class="bi bi-clipboard-check"></i></span>
                    </div>
                    <h3>78%</h3>
                    <p>124 of 142 students encoded</p>
                </article>
            </section>

            <!-- TWO COLUMN GRID -->
            <section class="dashboard-grid compact">

                <!-- LEFT COLUMN -->
                <div class="main-column">
                    <article class="panel">
                        <div class="panel-header split">
                            <div>
                                <h2><i class="bi bi-journal-text"></i> My Subject Classes</h2>
                                <p>Encoding progress per section.</p>
                            </div>
                            <a href="My-Subjects.php" class="panel-link">Open My Subjects</a>
                        </div>

                        <div class="table-wrap">
                            <table class="subject-table">
                                <thead>
                                    <tr>
                                        <th>Subject</th>
                                        <th>Section</th>
                                        <th class="center">Students</th>
                                        <th>Encoding Progress</th>
                                        <th class="center">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><strong>Mathematics</strong></td>
                                        <td>Grade 10 - St. John</td>
                                        <td class="center">42</td>
                                        <td>
                                            <div class="progress-row">
                                                <div class="progress-track">
                                                    <div class="progress-fill" style="width:88%"></div>
                                                </div>
                                                <span class="progress-label">37 / 42</span>
                                            </div>
                                        </td>
                                        <td class="center"><span class="pill warning">In Progress</span></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Mathematics</strong></td>
                                        <td>Grade 9 - St. Luke</td>
                                        <td class="center">38</td>
                                        <td>
                                            <div class="progress-row">
                                                <div class="progress-track">
                                                    <div class="progress-fill" style="width:92%"></div>
                                                </div>
                                                <span class="progress-label">35 / 38</span>
                                            </div>
                                        </td>
                                        <td class="center"><span class="pill warning">In Progress</span></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Science</strong></td>
                                        <td>Grade 10 - St. John</td>
                                        <td class="center">42</td>
                                        <td>
                                            <div class="progress-row">
                                                <div class="progress-track">
                                                    <div class="progress-fill success" style="width:100%"></div>
                                                </div>
                                                <span class="progress-label">42 / 42</span>
                                            </div>
                                        </td>
                                        <td class="center"><span class="pill success">Submitted</span></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Science</strong></td>
                                        <td>Grade 8 - St. Mark</td>
                                        <td class="center">35</td>
                                        <td>
                                            <div class="progress-row">
                                                <div class="progress-track">
                                                    <div class="progress-fill danger" style="width:60%"></div>
                                                </div>
                                                <span class="progress-label">21 / 35</span>
                                            </div>
                                        </td>
                                        <td class="center"><span class="pill danger">Not Submitted</span></td>
                                    </tr>
                                    <tr>
                                        <td><strong>English</strong></td>
                                        <td>Grade 9 - St. Luke</td>
                                        <td class="center">38</td>
                                        <td>
                                            <div class="progress-row">
                                                <div class="progress-track">
                                                    <div class="progress-fill success" style="width:100%"></div>
                                                </div>
                                                <span class="progress-label">38 / 38</span>
                                            </div>
                                        </td>
                                        <td class="center"><span class="pill success">Ready</span></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </article>

                    <article class="panel">
                        <div class="panel-header split">
                            <div>
                                <h2><i class="bi bi-exclamation-triangle-fill"></i> At-Risk Students</h2>
                                <p>From linear regression performance prediction.</p>
                            </div>
                            <a href="Performance-Prediction.php" class="panel-link">View All</a>
                        </div>

                        <div class="table-wrap">
                            <table class="subject-table">
                                <thead>
                                    <tr>
                                        <th>Student</th>
                                        <th>Section</th>
                                        <th>Subject at Risk</th>
                                        <th class="center">Current Avg</th>
                                        <th class="center">Predicted Final</th>
                                        <th class="center">Trend</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><strong>Juan Dela Cruz</strong></td>
                                        <td>Grade 10 - St. John</td>
                                        <td>Mathematics</td>
                                        <td class="center">76</td>
                                        <td class="center"><span class="pill danger">72</span></td>
                                        <td class="center"><i class="bi bi-arrow-down-right text-danger"></i></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Maria Santos</strong></td>
                                        <td>Grade 9 - St. Luke</td>
                                        <td>Science</td>
                                        <td class="center">78</td>
                                        <td class="center"><span class="pill warning">74</span></td>
                                        <td class="center"><i class="bi bi-arrow-down-right text-danger"></i></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Pedro Reyes</strong></td>
                                        <td>Grade 8 - St. Mark</td>
                                        <td>English</td>
                                        <td class="center">79</td>
                                        <td class="center"><span class="pill warning">75</span></td>
                                        <td class="center"><i class="bi bi-arrow-right text-warning"></i></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Anna Lim</strong></td>
                                        <td>Grade 10 - St. John</td>
                                        <td>Mathematics</td>
                                        <td class="center">77</td>
                                        <td class="center"><span class="pill warning">74</span></td>
                                        <td class="center"><i class="bi bi-arrow-down-right text-danger"></i></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </article>
                </div>

                <!-- RIGHT COLUMN -->
                <div class="side-column">

                    <article class="panel">
                        <div class="panel-header split">
                            <div>
                                <h2><i class="bi bi-trophy-fill"></i> Honors Watchlist</h2>
                                <p>Qualifying and near-qualifying students.</p>
                            </div>
                            <a href="Honors.php" class="panel-link">Open</a>
                        </div>

                        <ul class="simple-list">
                            <li>
                                <div>
                                    <strong>Sofia Mendoza</strong>
                                    <small>Grade 10 - St. John • GA 95.4</small>
                                </div>
                                <span class="pill success">Qualified</span>
                            </li>
                            <li>
                                <div>
                                    <strong>Mark Villanueva</strong>
                                    <small>Grade 10 - St. John • GA 92.1</small>
                                </div>
                                <span class="pill success">Qualified</span>
                            </li>
                            <li>
                                <div>
                                    <strong>Rachel Tan</strong>
                                    <small>Grade 10 - St. John • GA 89.8</small>
                                </div>
                                <span class="pill warning">Near (−0.2)</span>
                            </li>
                            <li>
                                <div>
                                    <strong>Daniel Cruz</strong>
                                    <small>Grade 10 - St. John • GA 89.5</small>
                                </div>
                                <span class="pill warning">Near (−0.5)</span>
                            </li>
                        </ul>
                    </article>

                    <article class="panel">
                        <div class="panel-header">
                            <div>
                                <h2><i class="bi bi-people-fill"></i> Advisory Summary</h2>
                                <p>Grade 10 - St. John (your advisees).</p>
                            </div>
                        </div>

                        <ul class="summary-list">
                            <li><span>Total advisees</span><strong>42</strong></li>
                            <li><span>Complete from subject teachers</span><strong>29</strong></li>
                            <li><span>Pending grades</span><strong class="text-warning">11</strong></li>
                            <li><span>Flagged behavioral concerns</span><strong class="text-danger">2</strong></li>
                        </ul>
                    </article>

                    <article class="panel">
                        <div class="panel-header split">
                            <div>
                                <h2><i class="bi bi-megaphone"></i> Announcements</h2>
                                <p>From the registrar and admin.</p>
                            </div>
                            <a href="Announcements.php" class="panel-link">All</a>
                        </div>

                        <ul class="simple-list">
                            <li>
                                <div>
                                    <strong>Grade submission deadline</strong>
                                    <small>April 27, 2026 • 5:00 PM</small>
                                </div>
                            </li>
                            <li>
                                <div>
                                    <strong>Faculty meeting</strong>
                                    <small>April 25, 2026 • 1:00 PM at AVR</small>
                                </div>
                            </li>
                            <li>
                                <div>
                                    <strong>Card distribution day</strong>
                                    <small>May 3, 2026</small>
                                </div>
                            </li>
                        </ul>
                    </article>
                </div>
            </section>
        </main>
    </div>
</body>
<script>
    (function () {
        const sidebar = document.getElementById('stsn-sidebar');
        const toggleBtn = document.getElementById('stsn-toggle');
        const collapseBtn = document.getElementById('stsn-collapse-btn');
        const overlay = document.getElementById('stsn-overlay');
        const body = document.body;
        const html = document.documentElement;

        if (!sidebar) return;

        const COOKIE_NAME = 'stsn_sidebar_collapsed';
        const mqDesktop = window.matchMedia('(min-width: 992px)');
        const mqMobile = window.matchMedia('(max-width: 991px)');

        // Re-enable transitions on the next frame (PHP already applied collapsed state)
        requestAnimationFrame(function () {
            html.classList.remove('stsn-pre-collapsed');
        });

        // Mobile: hamburger opens drawer
        if (toggleBtn) {
            toggleBtn.addEventListener('click', function () {
                sidebar.classList.add('mobile-open');
                if (overlay) overlay.classList.add('visible');
            });
        }

        // Mobile: tap overlay to close
        if (overlay) {
            overlay.addEventListener('click', closeMobileDrawer);
        }

        // Desktop: chevron collapses; Mobile: chevron closes drawer
        if (collapseBtn) {
            collapseBtn.addEventListener('click', function () {
                if (mqMobile.matches) {
                    closeMobileDrawer();
                    return;
                }
                const collapsed = sidebar.classList.toggle('collapsed');
                body.classList.toggle('sidebar-collapsed', collapsed);
                rotateChevron(collapsed);
                setCookie(COOKIE_NAME, collapsed ? '1' : '0', 365);
            });
        }

        // Mobile: clicking any link closes the drawer
        sidebar.querySelectorAll('.stsn-link').forEach(function (link) {
            link.addEventListener('click', function () {
                if (mqMobile.matches) closeMobileDrawer();
            });
        });

        // ESC closes mobile drawer
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && sidebar.classList.contains('mobile-open')) {
                closeMobileDrawer();
            }
        });

        // Reset mobile drawer state when resized to desktop
        window.addEventListener('resize', function () {
            if (mqDesktop.matches) closeMobileDrawer();
        });

        function closeMobileDrawer() {
            sidebar.classList.remove('mobile-open');
            if (overlay) overlay.classList.remove('visible');
        }

        function rotateChevron(collapsed) {
            const icon = collapseBtn ? collapseBtn.querySelector('i') : null;
            if (!icon) return;
            icon.classList.toggle('bi-chevron-left', !collapsed);
            icon.classList.toggle('bi-chevron-right', collapsed);
        }

        function setCookie(name, value, days) {
            const maxAge = days * 24 * 60 * 60;
            document.cookie = name + '=' + value + '; path=/; max-age=' + maxAge + '; SameSite=Lax';
        }
    })();
</script>

</html>