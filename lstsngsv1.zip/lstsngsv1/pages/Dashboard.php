<?php
require_once __DIR__ . '/../api/login/teacher_auth.php';

$teacherName = $_SESSION['teacher_name'] ?? 'Teacher';
$teacherId = (int) ($_SESSION['teacher_id'] ?? 0);

function pct(int $part, int $whole): int
{
    return $whole > 0 ? (int) round(($part / $whole) * 100) : 0;
}

function fmtAvg($value): string
{
    return $value === null || $value === '' ? '--' : number_format((float) $value, 2);
}

function statusPill(array $class): array
{
    $total = (int) $class['total_students'];
    $encoded = (int) $class['encoded_students'];

    if (!empty($class['published'])) {
        return ['Published', 'success'];
    }
    if (!empty($class['submitted_at'])) {
        return ['Processing', 'warning'];
    }
    if ($total > 0 && $encoded >= $total) {
        return ['Ready', 'success'];
    }
    if ($encoded > 0) {
        return ['In Progress', 'warning'];
    }
    return ['No Grades', 'danger'];
}

$activeYear = $pdo->query("
    SELECT id, year_label
    FROM tblacademicyear
    WHERE is_active = 1
    LIMIT 1
")->fetch(PDO::FETCH_ASSOC) ?: null;

$activeYearId = $activeYear ? (int) $activeYear['id'] : null;
$activeYearLabel = $activeYear['year_label'] ?? 'All school years';

$quarter = null;
if ($activeYearId) {
    // Use tblconfig_terms (trimester system)
    try {
        $quarterStmt = $pdo->prepare("
            SELECT t.id, t.academic_year_id, t.term_number, t.term_label,
                   t.term_type,
                   t.is_active, t.is_closed,
                   ay.year_label
            FROM tblconfig_terms t
            JOIN tblacademicyear ay ON t.academic_year_id = ay.id
            WHERE t.academic_year_id = ?
              AND t.is_active = 1
              AND t.is_closed = 0
            ORDER BY t.term_number ASC
            LIMIT 1
        ");
        $quarterStmt->execute([$activeYearId]);
        $quarter = $quarterStmt->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) {
        $quarter = null;
    }
}

$quarterNumber = $quarter ? (int) $quarter['term_number'] : null;
$quarterLabel = $quarter['term_label'] ?? 'No active term';

$scheduleYearFilter = $activeYear ? 'AND school_year = :schedule_year' : '';
$sectionYearFilter = $activeYearId ? 'AND ss.academic_year_id = :section_year' : '';
$gradeYearFilter = $activeYearId ? 'AND g.academic_year_id = :grade_year' : '';
$gradeQuarterFilter = $quarterNumber ? 'AND g.quarter = :grade_quarter' : '';
$submissionYearFilter = $activeYear ? 'AND ts.school_year = :submission_year' : '';
$submissionQuarterFilter = $quarterNumber ? 'AND ts.quarter = :submission_quarter' : '';

$classSql = "
    SELECT
        c.section_id,
        c.subject_id,
        sub.subject_name,
        gl.grade_level_name,
        sec.section_name,
        COUNT(DISTINCT ss.student_id) AS total_students,
        COUNT(DISTINCT CASE WHEN g.final_grade > 0 THEN g.student_id END) AS encoded_students,
        ROUND(AVG(CASE WHEN g.final_grade > 0 THEN g.final_grade END), 2) AS average_grade,
        MAX(ts.submitted_at) AS submitted_at,
        MAX(CASE WHEN wfi.status = 'COMPLETED' THEN 1 ELSE 0 END) AS published
    FROM (
        SELECT DISTINCT section_id, subject_id
        FROM tblschedule
        WHERE teacher_id = :schedule_teacher
          AND is_active = 1
          {$scheduleYearFilter}
    ) c
    INNER JOIN tblsubjects sub ON sub.id = c.subject_id
    INNER JOIN tblsection sec ON sec.id = c.section_id
    LEFT JOIN tblgradelevel gl ON gl.id = sec.grade_level_id
    LEFT JOIN tblsectionstudent ss
        ON ss.section_id = c.section_id
       AND ss.is_active = 1
       {$sectionYearFilter}
    LEFT JOIN tblgrades g
        ON g.section_id = c.section_id
       AND g.subject_id = c.subject_id
       AND g.teacher_id = :grade_teacher
       {$gradeYearFilter}
       {$gradeQuarterFilter}
    LEFT JOIN tblteacher_submissions ts
        ON ts.teacher_id = :submission_teacher
       AND ts.section_id = c.section_id
       AND ts.subject_id = c.subject_id
       {$submissionYearFilter}
       {$submissionQuarterFilter}
    LEFT JOIN tblworkflow_instance wfi
        ON wfi.teacher_id = :workflow_teacher
       AND wfi.section_id = c.section_id
       AND wfi.subject_id = c.subject_id
       AND wfi.term_id = :workflow_term
       AND wfi.academic_year_id = :workflow_year
       AND wfi.id = (
           SELECT MAX(wfi_latest.id)
           FROM tblworkflow_instance wfi_latest
           WHERE wfi_latest.teacher_id = :workflow_latest_teacher
             AND wfi_latest.section_id = c.section_id
             AND wfi_latest.subject_id = c.subject_id
             AND wfi_latest.term_id = :workflow_latest_term
             AND wfi_latest.academic_year_id = :workflow_latest_year
       )
    GROUP BY c.section_id, c.subject_id, sub.subject_name, gl.grade_level_name, sec.section_name
    ORDER BY gl.sort_order ASC, sec.section_name ASC, sub.subject_name ASC
";

$classParams = [
    ':schedule_teacher' => $teacherId,
    ':grade_teacher' => $teacherId,
    ':submission_teacher' => $teacherId,
    ':workflow_teacher' => $teacherId,
    ':workflow_term' => (int)($quarter['id'] ?? 0),
    ':workflow_year' => (int)($activeYearId ?? 0),
    ':workflow_latest_teacher' => $teacherId,
    ':workflow_latest_term' => (int)($quarter['id'] ?? 0),
    ':workflow_latest_year' => (int)($activeYearId ?? 0),
];
if ($activeYear) {
    $classParams[':schedule_year'] = $activeYearLabel;
    $classParams[':submission_year'] = $activeYearLabel;
}
if ($activeYearId) {
    $classParams[':section_year'] = $activeYearId;
    $classParams[':grade_year'] = $activeYearId;
}
if ($quarterNumber) {
    $classParams[':grade_quarter'] = $quarterNumber;
    $classParams[':submission_quarter'] = $quarterNumber;
}

$classStmt = $pdo->prepare($classSql);
$classStmt->execute($classParams);
$classes = $classStmt->fetchAll(PDO::FETCH_ASSOC);

$handledClasses = count($classes);
$totalExpected = array_sum(array_map(static fn($row) => (int) $row['total_students'], $classes));
$totalEncoded = array_sum(array_map(static fn($row) => (int) $row['encoded_students'], $classes));
$submittedClasses = count(array_filter($classes, static fn($row) => !empty($row['submitted_at'])));
$gradingProgress = pct($totalEncoded, $totalExpected);

$teacherAverage = null;
if ($classes) {
    $avgValues = array_values(array_filter(array_map(
        static fn($row) => $row['average_grade'] !== null ? (float) $row['average_grade'] : null,
        $classes
    ), static fn($value) => $value !== null));
    $teacherAverage = $avgValues ? array_sum($avgValues) / count($avgValues) : null;
}

$advisorySql = "
    SELECT
        sa.section_id,
        gl.grade_level_name,
        sec.section_name,
        COUNT(DISTINCT ss.student_id) AS total_students
    FROM tblsectionadviser sa
    INNER JOIN tblsection sec ON sec.id = sa.section_id
    LEFT JOIN tblgradelevel gl ON gl.id = sec.grade_level_id
    LEFT JOIN tblsectionstudent ss
        ON ss.section_id = sa.section_id
       AND ss.is_active = 1
       " . ($activeYearId ? "AND ss.academic_year_id = :adv_ss_year" : "") . "
    WHERE sa.teacher_id = :adv_teacher
      " . ($activeYearId ? "AND sa.academic_year_id = :adv_year" : "") . "
    GROUP BY sa.section_id, gl.grade_level_name, sec.section_name
    ORDER BY gl.sort_order ASC, sec.section_name ASC
";
$advisoryParams = [':adv_teacher' => $teacherId];
if ($activeYearId) {
    $advisoryParams[':adv_year'] = $activeYearId;
    $advisoryParams[':adv_ss_year'] = $activeYearId;
}
$advisoryStmt = $pdo->prepare($advisorySql);
$advisoryStmt->execute($advisoryParams);
$advisories = $advisoryStmt->fetchAll(PDO::FETCH_ASSOC);
$primaryAdvisory = $advisories[0] ?? null;

$gradeLevelSql = "
    SELECT
        gl.grade_level_name,
        ROUND(AVG(g.final_grade), 2) AS average_grade,
        COUNT(DISTINCT g.student_id) AS student_count
    FROM tblgrades g
    INNER JOIN tblsection sec ON sec.id = g.section_id
    LEFT JOIN tblgradelevel gl ON gl.id = sec.grade_level_id
    WHERE g.teacher_id = :gl_teacher
      AND g.final_grade > 0
      " . ($activeYearId ? "AND g.academic_year_id = :gl_year" : "") . "
      " . ($quarterNumber ? "AND g.quarter = :gl_quarter" : "") . "
    GROUP BY gl.id, gl.grade_level_name, gl.sort_order
    ORDER BY gl.sort_order ASC
";
$gradeLevelParams = [':gl_teacher' => $teacherId];
if ($activeYearId) {
    $gradeLevelParams[':gl_year'] = $activeYearId;
}
if ($quarterNumber) {
    $gradeLevelParams[':gl_quarter'] = $quarterNumber;
}
$gradeLevelStmt = $pdo->prepare($gradeLevelSql);
$gradeLevelStmt->execute($gradeLevelParams);
$gradeLevels = $gradeLevelStmt->fetchAll(PDO::FETCH_ASSOC);

$riskSql = "
    SELECT
        CONCAT(st.lname, ', ', st.fname) AS student_name,
        CONCAT(gl.grade_level_name, ' - ', sec.section_name) AS section_label,
        sub.subject_name,
        ROUND(AVG(g.final_grade), 2) AS average_grade
    FROM tblgrades g
    INNER JOIN tblstudents st ON st.id = g.student_id
    INNER JOIN tblsection sec ON sec.id = g.section_id
    LEFT JOIN tblgradelevel gl ON gl.id = sec.grade_level_id
    INNER JOIN tblsubjects sub ON sub.id = g.subject_id
    WHERE g.teacher_id = :risk_teacher
      AND g.final_grade > 0
      " . ($activeYearId ? "AND g.academic_year_id = :risk_year" : "") . "
      " . ($quarterNumber ? "AND g.quarter = :risk_quarter" : "") . "
    GROUP BY g.student_id, g.section_id, g.subject_id, st.lname, st.fname, gl.grade_level_name, sec.section_name, sub.subject_name
    HAVING average_grade < 80
    ORDER BY average_grade ASC, student_name ASC
    LIMIT 4
";
$riskParams = [':risk_teacher' => $teacherId];
if ($activeYearId) {
    $riskParams[':risk_year'] = $activeYearId;
}
if ($quarterNumber) {
    $riskParams[':risk_quarter'] = $quarterNumber;
}
$riskStmt = $pdo->prepare($riskSql);
$riskStmt->execute($riskParams);
$atRiskStudents = $riskStmt->fetchAll(PDO::FETCH_ASSOC);

$topSql = str_replace('HAVING average_grade < 80', 'HAVING average_grade >= 90', $riskSql);
$topSql = str_replace('ORDER BY average_grade ASC, student_name ASC', 'ORDER BY average_grade DESC, student_name ASC', $topSql);
$topStmt = $pdo->prepare($topSql);
$topStmt->execute($riskParams);
$topStudents = $topStmt->fetchAll(PDO::FETCH_ASSOC);

$noticeStmt = $pdo->prepare("
    SELECT title, message, created_at
    FROM system_notifications
    WHERE type IN (:teacher_type, :adviser_type, 'teacher', 'all')
    ORDER BY created_at DESC, id DESC
    LIMIT 4
");
$noticeStmt->execute([
    ':teacher_type' => 'teacher:' . $teacherId,
    ':adviser_type' => 'adviser:' . $teacherId,
]);
$notices = $noticeStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard | STSN Grading System</title>

    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/dashboard.css">
    <style>
        
        *, *::before, *::after { box-sizing: border-box; }
        html, body { overflow-x: hidden; }
        body.no-scroll { overflow-y: auto; }

        
        .dashboard-shell.compact {
            height: auto;
            min-height: 100vh;
            overflow: visible;
        }

        .dashboard-main.compact {
            height: auto;
            min-height: 100vh;
            overflow: visible;
            gap: .85rem;
            padding: 1rem 1.5rem 1.5rem;
        }

        
        .top-bar {
            background: var(--surface, #fff);
            border-bottom: 1px solid var(--border, #E9ECEF);
            padding: .85rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            flex-wrap: wrap;
            position: sticky;
            top: 0;
            z-index: 40;
        }

        .top-bar-left h1 {
            margin: 0;
            font-size: 1.25rem;
            font-weight: 800;
            color: var(--primary, #0A2F44);
            display: flex;
            align-items: center;
            gap: .5rem;
        }

        .top-bar-left p {
            margin: .2rem 0 0;
            color: var(--muted, #6C757D);
            font-size: .82rem;
        }

        .top-bar-right {
            display: flex;
            align-items: center;
            gap: .55rem;
            flex-wrap: wrap;
        }

        .meta-chip {
            background: #fff;
            border: 1px solid var(--border, #E9ECEF);
            border-radius: 999px;
            padding: .45rem .8rem;
            font-size: .78rem;
            color: var(--muted, #6C757D);
            display: inline-flex;
            align-items: center;
            gap: 5px;
            white-space: nowrap;
        }

        .meta-chip.danger {
            background: #fee2e2;
            border-color: #fecaca;
            color: #b91c1c;
        }

        .meta-chip.warning {
            background: #fff8e1;
            border-color: #fde68a;
            color: #92400e;
        }

        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: .75rem;
            margin-bottom: 0;
        }

        @media (max-width: 900px) { .stats-grid { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 480px) { .stats-grid { grid-template-columns: 1fr; } }

        .stat-card {
            border-radius: 12px;
            padding: .8rem .9rem;
        }

        .stat-card h3 {
            font-size: clamp(1.1rem, 2.5vw, 1.35rem);
        }

        
        .dashboard-grid.compact {
            display: grid;
            grid-template-columns: minmax(0, 1.55fr) minmax(0, .9fr);
            gap: .85rem;
            align-items: start;
        }

        @media (max-width: 1100px) {
            .dashboard-grid.compact { grid-template-columns: 1fr; }
            .side-column {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
                gap: .85rem;
            }
        }

        @media (max-width: 600px) {
            .side-column { grid-template-columns: 1fr; }
        }

        
        .panel {
            border-radius: 12px;
            overflow: visible;
        }

        .panel-header {
            padding: .8rem .9rem .7rem;
        }

        .panel-header h2 {
            font-size: clamp(.9rem, 2vw, 1rem);
            margin: 0 0 .15rem;
            display: flex;
            align-items: center;
            gap: .4rem;
        }

        .panel-header p {
            margin: 0;
            font-size: .8rem;
        }

        .panel-header.split {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: .5rem;
        }

        .panel-link {
            white-space: nowrap;
            font-size: .8rem;
            flex-shrink: 0;
        }

        
        .table-wrap {
            padding: 0 .9rem .8rem;
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .subject-table {
            width: 100%;
            min-width: 620px;
            border-collapse: collapse;
        }

        .subject-table th {
            padding: .7rem 0 .55rem;
            font-size: .78rem;
            text-align: left;
            white-space: nowrap;
        }

        .subject-table td {
            padding: .62rem 0;
            font-size: .83rem;
            vertical-align: middle;
        }

        .subject-table th.center,
        .subject-table td.center { text-align: center; }

        
        .progress-row {
            display: flex;
            align-items: center;
            gap: .5rem;
            min-width: 120px;
        }

        .progress-track {
            flex: 1;
            height: 7px;
            border-radius: 99px;
            background: var(--border, #e5e7eb);
            overflow: hidden;
        }

        .progress-fill {
            height: 100%;
            border-radius: 99px;
            transition: width .4s ease;
        }

        .progress-fill.success { background: var(--success, #22c55e); }
        .progress-fill.warning { background: var(--warning, #f59e0b); }
        .progress-fill.danger  { background: var(--danger,  #ef4444); }

        .progress-label {
            font-size: .75rem;
            white-space: nowrap;
            flex-shrink: 0;
        }

        
        .mini-bars {
            display: grid;
            gap: .75rem;
            padding: .85rem .9rem 1rem;
        }

        .mini-bar-item { width: 100%; }

        .mini-bar-head {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: .5rem;
            font-size: .82rem;
            margin-bottom: .38rem;
            flex-wrap: wrap;
        }

        .mini-bar-head strong { font-size: .84rem; }
        .mini-bar-head small { color: var(--muted, #6b7280); font-size: .78rem; white-space: nowrap; }

        
        .pill {
            display: inline-block;
            padding: .2em .65em;
            border-radius: 99px;
            font-size: .74rem;
            font-weight: 600;
            white-space: nowrap;
        }

        .pill.success { background: #dcfce7; color: #166534; }
        .pill.warning { background: #fef9c3; color: #92400e; }
        .pill.danger  { background: #fee2e2; color: #991b1b; }

        
        .summary-list {
            list-style: none;
            padding: 0 .9rem .8rem;
            margin: 0;
        }

        .summary-list li {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: .52rem 0;
            font-size: .83rem;
            border-bottom: 1px solid var(--border, #f3f4f6);
        }

        .summary-list li:last-child { border-bottom: none; }

        
        .simple-list {
            list-style: none;
            padding: 0 .9rem .8rem;
            margin: 0;
        }

        .simple-list li {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: .75rem;
            padding: .55rem 0;
            border-bottom: 1px solid var(--border, #f3f4f6);
            font-size: .83rem;
        }

        .simple-list li:last-child { border-bottom: none; }

        .simple-list li div {
            display: flex;
            flex-direction: column;
            gap: .15rem;
            min-width: 0;
        }

        .simple-list li strong {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .simple-list li small {
            color: var(--muted, #6b7280);
            font-size: .75rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        
        .empty-state {
            padding: 1.2rem 1rem;
            color: var(--muted, #6b7280);
            font-size: .86rem;
            text-align: center;
        }

        
        @media (max-width: 991.98px) {
            #stsn-toggle { display: flex; }
            .top-bar { padding: 4.5rem 1rem 1rem; }
            .top-bar .top-bar-right { justify-content: flex-end !important; }
            .dashboard-main.compact { padding-left: 1rem; padding-right: 1rem; }
        }

        @media (max-width: 600px) {
            .dashboard-main.compact { padding: .75rem; gap: .7rem; }
            .top-bar-right { display: none; } 
            .panel-header.split { flex-direction: column; align-items: flex-start; }
        }
    </style>
</head>

<body class="stsn-layout no-scroll">
    <button id="stsn-toggle" aria-label="Toggle sidebar">
        <i class="bi bi-list"></i>
    </button>

    <div id="stsn-overlay"></div>

    <?php include __DIR__ . '/../includes/teacher-sidebar.php'; ?>

    <div class="dashboard-shell compact">

        
        <header class="top-bar">
            <div class="top-bar-left">
                <h1><i class="bi bi-speedometer2" style="color:var(--accent,#C5A028);"></i> Teacher Dashboard</h1>
                <p>Welcome back, <?= htmlspecialchars($teacherName) ?> — live overview of your classes and grades.</p>
            </div>
            <div class="top-bar-right" style="width: auto !important; flex: 0 1 auto !important;">
                <span class="meta-chip"><i class="bi bi-person-badge"></i> <?= htmlspecialchars($teacherName) ?></span>
                <span class="meta-chip"><i class="bi bi-mortarboard"></i> SY <?= htmlspecialchars($activeYearLabel) ?></span>
                <span class="meta-chip"><i class="bi bi-calendar3"></i>
                    <?= htmlspecialchars($quarter ? $quarterLabel . ' · Active' : $quarterLabel) ?></span>
            </div>
        </header>

        <main class="dashboard-main compact">

            
            <?php require_once __DIR__ . '/../includes/breadcrumb.php'; renderBreadcrumb([['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'], ['label' => 'Dashboard', 'icon' => 'bi bi-speedometer2']], 'teacher'); ?>

            <?php if (empty($classes) && empty($advisories)): ?>
            <div style="background:#fff;border:1.5px dashed #f5bcbc;border-radius:18px;padding:2.5rem 1.5rem;text-align:center;margin-bottom:1.5rem;">
                <div style="width:72px;height:72px;border-radius:50%;background:#fdf2f2;display:inline-flex;align-items:center;justify-content:center;font-size:2rem;color:#8B1A1A;margin-bottom:1rem;">
                    <i class="bi bi-inbox"></i>
                </div>
                <h3 style="font-size:1.1rem;color:#8B1A1A;margin:0 0 .35rem;">No classes assigned yet</h3>
                <p style="color:#a97b7b;font-size:.9rem;margin:0;">Contact your administrator to assign you to a section or subject.</p>
            </div>
            <?php endif; ?>

            <section class="stats-grid">
                <article class="stat-card">
                    <div class="stat-top">
                        <span class="stat-title">Handled Classes</span>
                        <span class="stat-icon"><i class="bi bi-journal-bookmark-fill"></i></span>
                    </div>
                    <h3><?= number_format($handledClasses) ?></h3>
                    <p><?= number_format($submittedClasses) ?> submitted this term</p>
                </article>

                <article class="stat-card">
                    <div class="stat-top">
                        <span class="stat-title">Total Students</span>
                        <span class="stat-icon"><i class="bi bi-people"></i></span>
                    </div>
                    <h3><?= number_format($totalExpected) ?></h3>
                    <p>Across current class loads</p>
                </article>

                <article class="stat-card">
                    <div class="stat-top">
                        <span class="stat-title">Grading Progress</span>
                        <span class="stat-icon"><i class="bi bi-clipboard-check"></i></span>
                    </div>
                    <h3><?= $gradingProgress ?>%</h3>
                    <p><?= number_format($totalEncoded) ?> of <?= number_format($totalExpected) ?> encoded</p>
                </article>

                <article class="stat-card">
                    <div class="stat-top">
                        <span class="stat-title">Average Grade</span>
                        <span class="stat-icon"><i class="bi bi-bar-chart-line"></i></span>
                    </div>
                    <h3><?= fmtAvg($teacherAverage) ?></h3>
                    <p>Based on recorded final grades</p>
                </article>
            </section>

            
            <section class="dashboard-grid compact">

                
                <div class="main-column">

                    
                    <article class="panel">
                        <div class="panel-header split">
                            <div>
                                <h2><i class="bi bi-journal-text"></i> My Subject Classes</h2>
                                <p>Live encoding progress per assigned section and subject.</p>
                            </div>
                            <a href="Grading-Sheet.php" class="panel-link">Open Grading Sheet</a>
                        </div>

                        <div class="table-wrap">
                            <table class="subject-table">
                                <thead>
                                    <tr>
                                        <th>Subject</th>
                                        <th>Section</th>
                                        <th class="center">Students</th>
                                        <th>Encoding</th>
                                        <th class="center">Average</th>
                                        <th class="center">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($classes): ?>
                                        <?php foreach ($classes as $class): ?>
                                            <?php
                                            $total = (int) $class['total_students'];
                                            $encoded = (int) $class['encoded_students'];
                                            $progress = pct($encoded, $total);
                                            [$statusText, $statusClass] = statusPill($class);
                                            $sectionLabel = trim(($class['grade_level_name'] ?? '') . ' - ' . ($class['section_name'] ?? ''), ' -');
                                            ?>
                                            <tr>
                                                <td><strong><?= htmlspecialchars($class['subject_name']) ?></strong></td>
                                                <td><?= htmlspecialchars($sectionLabel ?: 'Unassigned section') ?></td>
                                                <td class="center"><?= number_format($total) ?></td>
                                                <td>
                                                    <div class="progress-row">
                                                        <div class="progress-track">
                                                            <div class="progress-fill <?= $progress >= 100 ? 'success' : ($progress === 0 ? 'danger' : 'warning') ?>"
                                                                style="width:<?= $progress ?>%"></div>
                                                        </div>
                                                        <span class="progress-label"><?= $encoded ?> / <?= $total ?></span>
                                                    </div>
                                                </td>
                                                <td class="center"><?= fmtAvg($class['average_grade']) ?></td>
                                                <td class="center"><span class="pill <?= $statusClass ?>"><?= $statusText ?></span></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="6" class="empty-state">No handled classes found for this school year.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </article>

                    
                    <article class="panel">
                        <div class="panel-header split">
                            <div>
                                <h2><i class="bi bi-graph-up"></i> Average by Grade Level</h2>
                                <p>Computed from your recorded final grades.</p>
                            </div>
                        </div>

                        <div class="mini-bars">
                            <?php if ($gradeLevels): ?>
                                <?php foreach ($gradeLevels as $level): ?>
                                    <?php $avg = (float) $level['average_grade']; ?>
                                    <div class="mini-bar-item">
                                        <div class="mini-bar-head">
                                            <strong><?= htmlspecialchars($level['grade_level_name'] ?? 'Unlisted') ?></strong>
                                            <small>
                                                <?= number_format($avg, 2) ?> avg
                                                &middot;
                                                <?= number_format((int) $level['student_count']) ?> students
                                            </small>
                                        </div>
                                        <div class="progress-track">
                                            <div class="progress-fill <?= $avg >= 85 ? 'success' : ($avg >= 75 ? 'warning' : 'danger') ?>"
                                                style="width:<?= max(0, min(100, (int) round($avg))) ?>%"></div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="empty-state">No grade averages available yet.</div>
                            <?php endif; ?>
                        </div>
                    </article>

                    
                    <article class="panel">
                        <div class="panel-header split">
                            <div>
                                <h2><i class="bi bi-exclamation-triangle-fill"></i> Students Needing Attention</h2>
                                <p>Students below 80 based on your encoded grades.</p>
                            </div>
                        </div>

                        <div class="table-wrap">
                            <table class="subject-table">
                                <thead>
                                    <tr>
                                        <th>Student</th>
                                        <th>Section</th>
                                        <th>Subject</th>
                                        <th class="center">Average</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($atRiskStudents): ?>
                                        <?php foreach ($atRiskStudents as $student): ?>
                                            <tr>
                                                <td><strong><?= htmlspecialchars($student['student_name']) ?></strong></td>
                                                <td><?= htmlspecialchars($student['section_label']) ?></td>
                                                <td><?= htmlspecialchars($student['subject_name']) ?></td>
                                                <td class="center">
                                                    <span class="pill <?= (float) $student['average_grade'] < 75 ? 'danger' : 'warning' ?>">
                                                        <?= fmtAvg($student['average_grade']) ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="4" class="empty-state">No students below 80 in your encoded grades.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </article>
                </div>

                
                <div class="side-column">

                    
                    <article class="panel">
                        <div class="panel-header">
                            <div>
                                <h2><i class="bi bi-person-badge"></i> Advisory Summary</h2>
                                <p>
                                    <?= $primaryAdvisory
                                        ? htmlspecialchars(trim(($primaryAdvisory['grade_level_name'] ?? '') . ' - ' . ($primaryAdvisory['section_name'] ?? ''), ' -'))
                                        : 'No advisory assigned' ?>
                                </p>
                            </div>
                        </div>

                        <ul class="summary-list">
                            <li>
                                <span>Advisory sections</span>
                                <strong><?= number_format(count($advisories)) ?></strong>
                            </li>
                            <li>
                                <span>Total advisees</span>
                                <strong><?= number_format(array_sum(array_map(static fn($row) => (int) $row['total_students'], $advisories))) ?></strong>
                            </li>
                            <li>
                                <span>Handled classes</span>
                                <strong><?= number_format($handledClasses) ?></strong>
                            </li>
                            <li>
                                <span>Current term</span>
                                <strong><?= htmlspecialchars($quarterLabel) ?></strong>
                            </li>
                        </ul>
                    </article>

                    
                    <article class="panel">
                        <div class="panel-header split">
                            <div>
                                <h2><i class="bi bi-trophy-fill"></i> Top Performers</h2>
                                <p>Students averaging 90 and above.</p>
                            </div>
                        </div>

                        <ul class="simple-list">
                            <?php if ($topStudents): ?>
                                <?php foreach ($topStudents as $student): ?>
                                    <li>
                                        <div>
                                            <strong><?= htmlspecialchars($student['student_name']) ?></strong>
                                            <small><?= htmlspecialchars($student['section_label']) ?> · <?= htmlspecialchars($student['subject_name']) ?></small>
                                        </div>
                                        <span class="pill success"><?= fmtAvg($student['average_grade']) ?></span>
                                    </li>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <li class="empty-state">No 90+ averages recorded yet.</li>
                            <?php endif; ?>
                        </ul>
                    </article>

                    
                    <article class="panel">
                        <div class="panel-header split">
                            <div>
                                <h2><i class="bi bi-megaphone"></i> Recent Notices</h2>
                                <p>Reminders addressed to you.</p>
                            </div>
                        </div>

                        <ul class="simple-list">
                            <?php if ($notices): ?>
                                <?php foreach ($notices as $notice): ?>
                                    <li>
                                        <div>
                                            <strong><?= htmlspecialchars($notice['title']) ?></strong>
                                            <small><?= htmlspecialchars(date('M d, Y h:i A', strtotime($notice['created_at']))) ?></small>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <li class="empty-state">No recent notices.</li>
                            <?php endif; ?>
                        </ul>
                    </article>

                </div>
            </section>
        </main>
    </div>

    <script>
        (function () {
            const sidebar = document.getElementById('stsn-sidebar');
            const toggleBtn = document.getElementById('stsn-toggle');
            const collapseBtn = document.getElementById('stsn-collapse-btn');
            const overlay = document.getElementById('stsn-overlay');
            const body = document.body;
            const html = document.documentElement;

            if (!sidebar) return;

            const COOKIE_NAME = 'stsn_sidebar_collapsed';
            const mqDesktop = window.matchMedia('(min-width: 992px)');
            const mqMobile = window.matchMedia('(max-width: 991px)');

            requestAnimationFrame(function () {
                html.classList.remove('stsn-pre-collapsed');
            });

            if (toggleBtn) {
                toggleBtn.addEventListener('click', function () {
                    sidebar.classList.add('mobile-open');
                    if (overlay) overlay.classList.add('visible');
                });
            }

            if (overlay) overlay.addEventListener('click', closeMobileDrawer);

            if (collapseBtn) {
                collapseBtn.addEventListener('click', function () {
                    if (mqMobile.matches) { closeMobileDrawer(); return; }
                    const collapsed = sidebar.classList.toggle('collapsed');
                    body.classList.toggle('sidebar-collapsed', collapsed);
                    rotateChevron(collapsed);
                    setCookie(COOKIE_NAME, collapsed ? '1' : '0', 365);
                });
            }

            sidebar.querySelectorAll('.stsn-link').forEach(function (link) {
                link.addEventListener('click', function () {
                    if (mqMobile.matches) closeMobileDrawer();
                });
            });

            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape' && sidebar.classList.contains('mobile-open')) closeMobileDrawer();
            });

            window.addEventListener('resize', function () {
                if (mqDesktop.matches) closeMobileDrawer();
            });

            function closeMobileDrawer() {
                sidebar.classList.remove('mobile-open');
                if (overlay) overlay.classList.remove('visible');
            }

            function rotateChevron(collapsed) {
                const icon = collapseBtn ? collapseBtn.querySelector('i') : null;
                if (!icon) return;
                icon.classList.toggle('bi-chevron-left', !collapsed);
                icon.classList.toggle('bi-chevron-right', collapsed);
            }

            function setCookie(name, value, days) {
                const maxAge = days * 24 * 60 * 60;
                document.cookie = name + '=' + value + '; path=/; max-age=' + maxAge + '; SameSite=Lax';
            }
        })();
    </script>
    <script>
        (function () {
            var retryScheduled = false;
            var retryAttempted = false;

            function fixTopBarRight() {
                var topBar = document.querySelector('.top-bar');
                var topBarRight = document.querySelector('.top-bar-right');
                if (topBar) {
                    // Force row layout so title + badges stay on the same line below 992px.
                    if (topBar.style.getPropertyValue('flex-direction') !== 'row'
                        || topBar.style.getPropertyPriority('flex-direction') !== 'important') {
                        topBar.style.setProperty('flex-direction', 'row', 'important');
                    }
                    if (topBar.style.getPropertyValue('flex-wrap') !== 'wrap'
                        || topBar.style.getPropertyPriority('flex-wrap') !== 'important') {
                        topBar.style.setProperty('flex-wrap', 'wrap', 'important');
                    }
                    if (topBar.style.getPropertyValue('align-items') !== 'center'
                        || topBar.style.getPropertyPriority('align-items') !== 'important') {
                        topBar.style.setProperty('align-items', 'center', 'important');
                    }
                    if (topBar.style.getPropertyValue('justify-content') !== 'space-between'
                        || topBar.style.getPropertyPriority('justify-content') !== 'important') {
                        topBar.style.setProperty('justify-content', 'space-between', 'important');
                    }
                }
                if (!topBarRight) {
                    if (!retryScheduled && !retryAttempted) {
                        retryScheduled = true;
                        window.setTimeout(function () {
                            retryScheduled = false;
                            retryAttempted = true;
                            fixTopBarRight();
                        }, 0);
                    }
                    return;
                }

                retryAttempted = false;
                if (topBarRight.style.getPropertyValue('justify-content') !== 'flex-end'
                    || topBarRight.style.getPropertyPriority('justify-content') !== 'important') {
                    topBarRight.style.setProperty('justify-content', 'flex-end', 'important');
                }
                if (topBarRight.style.getPropertyValue('width') !== 'auto'
                    || topBarRight.style.getPropertyPriority('width') !== 'important') {
                    topBarRight.style.setProperty('width', 'auto', 'important');
                }
                if (topBarRight.style.getPropertyValue('flex') !== '0 1 auto'
                    || topBarRight.style.getPropertyPriority('flex') !== 'important') {
                    topBarRight.style.setProperty('flex', '0 1 auto', 'important');
                }
            }

            document.addEventListener('DOMContentLoaded', fixTopBarRight);
            window.addEventListener('load', fixTopBarRight);
            window.setTimeout(fixTopBarRight, 100);
            window.setTimeout(fixTopBarRight, 500);
            window.setTimeout(fixTopBarRight, 1500);
            window.addEventListener('resize', fixTopBarRight);

            var observationTarget = document.querySelector('.top-bar') || document.body;
            if (observationTarget) {
                var observer = new MutationObserver(fixTopBarRight);
                observer.observe(observationTarget, {
                    childList: true,
                    subtree: true,
                    attributes: true,
                    attributeFilter: ['class', 'style']
                });
            }

            fixTopBarRight();
        })();
    </script>
</body>
</html>