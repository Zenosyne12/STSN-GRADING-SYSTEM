<?php
// Ensure session is started before auth check
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Debug: log session state on refresh
error_log("Profile page loaded. Session teacher_id: " . var_export($_SESSION['teacher_id'] ?? 'NOT SET', true));

require_once __DIR__ . '/../api/login/teacher_auth.php';

// Database connection
require_once __DIR__ . '/../api/shared/db_connect.php';

$teacherId = $_SESSION['teacher_id'] ?? null;
$teacherName = 'Teacher';
$teacherData = [];

if (isset($pdo)) {
    try {
        // Try 1: Look up by teacher_id (e.g., 'T00005')
        if (!empty($teacherId)) {
            $stmt = $pdo->prepare("
                SELECT t.*, u.id as user_id, u.username, u.status as user_status, u.must_change_password
                FROM tblteacher t
                LEFT JOIN tblusers u ON u.reference_id = t.id AND u.role_id = 2
                WHERE t.teacher_id = ?
                LIMIT 1
            ");
            $stmt->execute([$teacherId]);
            $teacherData = $stmt->fetch(PDO::FETCH_ASSOC);
        }

        // Try 2: If not found, look up by username in tblusers -> reference_id
        if (empty($teacherData) && !empty($_SESSION['username'])) {
            $stmt2 = $pdo->prepare("
                SELECT t.*, u.id as user_id, u.username, u.status as user_status, u.must_change_password
                FROM tblusers u
                JOIN tblteacher t ON t.id = u.reference_id
                WHERE u.username = ? AND u.role_id = 2
                LIMIT 1
            ");
            $stmt2->execute([$_SESSION['username']]);
            $teacherData = $stmt2->fetch(PDO::FETCH_ASSOC);
        }

        // Try 3: If user_id is in session
        if (empty($teacherData) && !empty($_SESSION['user_id'])) {
            $stmt3 = $pdo->prepare("
                SELECT t.*, u.id as user_id, u.username, u.status as user_status, u.must_change_password
                FROM tblusers u
                JOIN tblteacher t ON t.id = u.reference_id
                WHERE u.id = ? AND u.role_id = 2
                LIMIT 1
            ");
            $stmt3->execute([$_SESSION['user_id']]);
            $teacherData = $stmt3->fetch(PDO::FETCH_ASSOC);
        }

        if ($teacherData) {
            $teacherName = trim($teacherData['fname'] . ' ' . $teacherData['mname'] . ' ' . $teacherData['lname']);
            // Keep integer teacher_id in session (teacher_auth.php expects int id)
            // DO NOT overwrite with string teacher_id code
        }
    } catch (PDOException $e) {
        error_log("Profile DB Error: " . $e->getMessage());
    }
}

// Helper function to safely output
function e($str) {
    return htmlspecialchars($str ?? '-');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile | STSN Grading System</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css/index.css">
    <style>
        /* ═══════════════════════════════════════════════════════════════
           LIGHT THEME — Matches My-Advisory.php Design System
           ═══════════════════════════════════════════════════════════════ */
        :root {
            --primary: #0A2F44;
            --primary-soft: rgba(10, 47, 68, 0.08);
            --accent: #C5A028;
            --bg: #F5F7FA;
            --surface: #FFFFFF;
            --surface-2: #F8F9FA;
            --text: #1E2A3E;
            --muted: #6C757D;
            --border: #E9ECEF;
            --border-2: #DEE2E6;
            --danger: #DC3545;
            --warning: #F59E0B;
            --success: #198754;
            --info: #3b82f6;
            --shadow: 0 10px 30px rgba(10, 47, 68, 0.08);
            --radius: 18px;
            --sidebar-width: 264px;
            --sidebar-collapsed-width: 72px;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body.stsn-layout {
            font-family: "Plus Jakarta Sans", sans-serif;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
            font-size: 14px;
        }

        a { color: var(--primary); text-decoration: none; }
        a:hover { text-decoration: underline; }

        /* ─── LAYOUT ────────────────────────────────────────────── */
        .page-shell {
            margin-left: var(--sidebar-width);
            min-height: 100vh;
            transition: margin-left 0.28s ease;
        }
        body.sidebar-collapsed .page-shell {
            margin-left: var(--sidebar-collapsed-width);
        }

        .page-main {
            padding: 1.5rem 2rem 2rem;
        }

        #stsn-toggle {
            position: fixed;
            top: 1rem;
            left: 1rem;
            z-index: 1100;
            width: 44px;
            height: 44px;
            border: 1px solid var(--border);
            border-radius: 12px;
            background: #fff;
            color: var(--primary);
            display: none;
            align-items: center;
            justify-content: center;
            box-shadow: var(--shadow);
            cursor: pointer;
        }
        #stsn-toggle i { font-size: 1.3rem; }

        #stsn-overlay {
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.35);
            opacity: 0;
            visibility: hidden;
            transition: 0.25s ease;
            z-index: 1035;
        }
        #stsn-overlay.visible { opacity: 1; visibility: visible; }

        /* ─── PAGE HEADER ───────────────────────────────────────── */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 1rem;
            flex-wrap: wrap;
            margin-bottom: 1.25rem;
        }

        .page-title h1 {
            margin: 0;
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--primary);
        }
        .page-title p {
            margin: 0.4rem 0 0;
            color: var(--muted);
            font-size: 0.94rem;
        }

        .header-meta {
            display: flex;
            gap: 0.7rem;
            flex-wrap: wrap;
        }

        .meta-chip {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 999px;
            padding: 0.6rem 0.9rem;
            font-size: 0.82rem;
            color: var(--muted);
            white-space: nowrap;
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
        }
        .meta-chip i { color: var(--accent); }
        .meta-chip.success { color: var(--success); border-color: rgba(25,135,84,.2); background: rgba(25,135,84,.06); }
        .meta-chip.success i { color: var(--success); }

        /* ─── PANEL ─────────────────────────────────────────────── */
        .panel {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            overflow: hidden;
        }

        .panel-header {
            padding: 1rem 1.4rem 0.9rem;
            border-bottom: 1px solid var(--border);
        }
        .panel-header h2 {
            font-size: 1rem;
            font-weight: 700;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 0.55rem;
        }
        .panel-header h2 i { color: var(--accent); font-size: 15px; }
        .panel-header p {
            font-size: 0.82rem;
            color: var(--muted);
            margin-top: 0.2rem;
        }
        .panel-header.split {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .panel-link {
            font-size: 0.82rem;
            font-weight: 600;
            color: var(--primary);
            white-space: nowrap;
        }

        .panel-body { padding: 1.25rem 1.4rem; }

        /* ─── PROFILE HERO CARD ─────────────────────────────────── */
        .profile-hero {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 1.75rem 1.75rem 1.5rem;
            display: flex;
            gap: 1.5rem;
            align-items: flex-start;
            position: relative;
            overflow: hidden;
        }

        .profile-hero::before {
            content: '';
            position: absolute;
            top: 0; right: 0;
            width: 220px; height: 100%;
            background: linear-gradient(135deg, transparent 40%, rgba(10,47,68,.04) 100%);
            pointer-events: none;
        }

        .avatar-wrap {
            position: relative;
            flex-shrink: 0;
        }
        .avatar {
            width: 88px;
            height: 88px;
            border-radius: 50%;
            background: var(--surface-2);
            border: 2px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            font-weight: 800;
            color: var(--primary);
            letter-spacing: -.5px;
            user-select: none;
        }
        .avatar-badge {
            position: absolute;
            bottom: 2px; right: 2px;
            width: 20px; height: 20px;
            background: var(--success);
            border-radius: 50%;
            border: 2px solid var(--surface);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .avatar-badge i { font-size: 9px; color: #fff; }

        .hero-info { flex: 1; min-width: 0; }
        .hero-info .name {
            font-size: 20px;
            font-weight: 800;
            color: var(--text);
            line-height: 1.2;
        }
        .hero-info .role {
            font-size: 13px;
            color: var(--muted);
            margin-top: 0.25rem;
            display: flex;
            align-items: center;
            gap: 0.4rem;
            flex-wrap: wrap;
        }
        .hero-info .role i { color: var(--accent); }

        .hero-chips {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            margin-top: 0.85rem;
        }

        .hero-actions {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            flex-shrink: 0;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            padding: 0.55rem 1rem;
            border-radius: 12px;
            font-size: 0.87rem;
            font-weight: 600;
            cursor: pointer;
            border: none;
            transition: 0.2s ease;
            font-family: inherit;
        }
        .btn:hover { opacity: 0.88; transform: translateY(-1px); }
        .btn:active { transform: translateY(0); }
        .btn-primary {
            background: var(--primary);
            color: #fff;
        }
        .btn-ghost {
            background: var(--surface-2);
            color: var(--muted);
            border: 1px solid var(--border);
        }

        /* ─── TWO-COLUMN GRID ───────────────────────────────────── */
        .profile-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.25rem;
        }

        /* ─── FIELD LIST ────────────────────────────────────────── */
        .field-list {
            display: flex;
            flex-direction: column;
            gap: 0.05rem;
        }
        .field-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.7rem 0;
            border-bottom: 1px solid var(--border);
            gap: 1rem;
        }
        .field-item:last-child { border-bottom: none; }
        .field-label {
            font-size: 11.5px;
            color: var(--muted);
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            flex-shrink: 0;
        }
        .field-value {
            font-size: 13.5px;
            color: var(--text);
            font-weight: 500;
            text-align: right;
        }
        .field-value.muted { color: var(--muted); }

        /* ─── PILL ──────────────────────────────────────────────── */
        .pill {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.2rem 0.65rem;
            border-radius: 999px;
            font-size: 11.5px;
            font-weight: 700;
        }
        .pill-success { background: rgba(25,135,84,.1); color: var(--success); }
        .pill-warning { background: rgba(245,158,11,.12); color: #b96f00; }
        .pill-danger  { background: rgba(220,53,69,.1); color: var(--danger); }
        .pill-accent  { background: rgba(59,130,246,.1); color: var(--info); }
        .pill-primary { background: var(--primary-soft); color: var(--primary); }

        /* ─── STATS ROW ─────────────────────────────────────────── */
        .mini-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            border-top: 1px solid var(--border);
        }
        .mini-stat {
            padding: 1rem 1.2rem;
            border-right: 1px solid var(--border);
            text-align: center;
        }
        .mini-stat:last-child { border-right: none; }
        .mini-stat h4 { font-size: 22px; font-weight: 800; color: var(--primary); }
        .mini-stat p  { font-size: 11.5px; color: var(--muted); margin-top: 0.2rem; }

        /* ─── EDIT FORM ─────────────────────────────────────────── */
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
            padding: 1.25rem 1.4rem;
        }
        .form-group { display: flex; flex-direction: column; gap: 0.35rem; }
        .form-group.full { grid-column: 1 / -1; }
        label {
            font-size: 11.5px;
            font-weight: 700;
            color: var(--muted);
            text-transform: uppercase;
            letter-spacing: 0.06em;
        }
        input, select, textarea {
            background: var(--surface-2);
            border: 1px solid var(--border);
            border-radius: 12px;
            color: var(--text);
            font-family: inherit;
            font-size: 13.5px;
            padding: 0.65rem 0.85rem;
            transition: border-color 0.15s, box-shadow 0.15s;
            outline: none;
            width: 100%;
        }
        input:focus, select:focus, textarea:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(10,47,68,.08);
        }
        textarea { resize: vertical; min-height: 70px; }
        select { appearance: none; cursor: pointer; }
        .form-footer {
            display: flex;
            justify-content: flex-end;
            gap: 0.6rem;
            padding: 0.9rem 1.4rem;
            border-top: 1px solid var(--border);
        }

        /* ─── PASSWORD TOGGLE ───────────────────────────────────── */
        .pw-wrap {
            position: relative;
        }
        .pw-wrap input {
            padding-right: 2.5rem;
        }
        .toggle-pw {
            position: absolute;
            right: 0.5rem;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--muted);
            cursor: pointer;
            padding: 0.3rem;
            font-size: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .toggle-pw:hover { color: var(--primary); }

        /* ─── SEPARATOR / DIVIDER ───────────────────────────────── */
        .section-divider {
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.12em;
            color: var(--muted);
            display: flex;
            align-items: center;
            gap: 0.65rem;
        }
        .section-divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: var(--border);
        }

        /* ─── ALERT ─────────────────────────────────────────────── */
        .alert {
            padding: 0.85rem 1.2rem;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .alert-success {
            background: rgba(25,135,84,.1);
            color: var(--success);
            border: 1px solid rgba(25,135,84,.2);
        }
        .alert-danger {
            background: rgba(220,53,69,.1);
            color: var(--danger);
            border: 1px solid rgba(220,53,69,.2);
        }

        /* ─── RESPONSIVE ────────────────────────────────────────── */
        @media (max-width: 991.98px) {
            #stsn-toggle { display: inline-flex; }
            .page-shell,
            body.sidebar-collapsed .page-shell { margin-left: 0; }
            .page-main { padding: 5rem 1rem 1.5rem; }
        }

        @media (max-width: 700px) {
            .profile-hero { flex-direction: column; gap: 1rem; }
            .hero-actions { flex-direction: row; }
            .profile-grid { grid-template-columns: 1fr; }
            .form-grid { grid-template-columns: 1fr; }
            .form-group.full { grid-column: 1; }
            .mini-stats { grid-template-columns: repeat(3, 1fr); }
        }
    </style>
</head>
<body class="stsn-layout">
    <button id="stsn-toggle" aria-label="Toggle sidebar">
        <i class="bi bi-list"></i>
    </button>

    <div id="stsn-overlay"></div>

    <?php include __DIR__ . '/../includes/teacher-sidebar.php'; ?>

    <div class="page-shell">
        <main class="page-main">

            <!-- PAGE HEADER -->
            <div class="page-header">
                <div class="page-title">
                    <h1>My Profile</h1>
                    <p>Manage your personal information, credentials, and account settings.</p>
                </div>

                <div class="header-meta">
                    <div class="meta-chip"><i class="bi bi-person-badge"></i> <?php echo e($teacherData['teacher_id'] ?? $teacherId); ?></div>
                    <div class="meta-chip <?php echo ($teacherData['is_active'] ?? 1) ? 'success' : ''; ?>">
                        <i class="bi bi-circle-fill" style="font-size:7px"></i> 
                        <?php echo ($teacherData['is_active'] ?? 1) ? 'Active' : 'Inactive'; ?>
                    </div>
                </div>
            </div>

            <!-- SUCCESS / ERROR MESSAGES -->
            <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success">
                <i class="bi bi-check-circle-fill"></i> <?php echo e($_GET['success']); ?>
            </div>
            <?php endif; ?>
            <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-danger">
                <i class="bi bi-exclamation-triangle-fill"></i> <?php echo e($_GET['error']); ?>
            </div>
            <?php endif; ?>

            <!-- ── HERO CARD ── -->
            <div class="profile-hero" style="margin-bottom:1.25rem;">
                <div class="avatar-wrap">
                    <div class="avatar">
                        <?php 
                        $initials = '';
                        if (!empty($teacherData['fname'])) $initials .= strtoupper(substr($teacherData['fname'], 0, 1));
                        if (!empty($teacherData['lname'])) $initials .= strtoupper(substr($teacherData['lname'], 0, 1));
                        echo $initials ?: 'T';
                        ?>
                    </div>
                    <div class="avatar-badge"><i class="bi bi-check-lg"></i></div>
                </div>

                <div class="hero-info">
                    <div class="name"><?php echo !empty($teacherName) && $teacherName !== 'Teacher' ? e($teacherName) : e($teacherData['fname'] . ' ' . $teacherData['lname']); ?></div>
                    <div class="role">
                        <i class="bi bi-patch-check-fill"></i>
                        Subject Teacher &amp; Adviser
                    </div>
                    <div class="hero-chips">
                        <span class="meta-chip"><i class="bi bi-person-badge"></i> <?php echo e($teacherData['teacher_id'] ?? $teacherId); ?></span>
                        <span class="meta-chip"><i class="bi bi-envelope"></i> <?php echo e($teacherData['email'] ?? '-'); ?></span>
                        <span class="meta-chip"><i class="bi bi-telephone"></i> <?php echo e($teacherData['contact_no'] ?? '-'); ?></span>
                    </div>
                </div>

                <div class="hero-actions">
                    <button class="btn btn-primary" onclick="document.getElementById('edit-section').scrollIntoView({behavior:'smooth'})">
                        <i class="bi bi-pencil-fill"></i> Edit Profile
                    </button>
                </div>
            </div>

            <!-- ── MINI STATS ── -->
            <div class="panel" style="padding:0;overflow:hidden;margin-bottom:1.25rem;">
                <div class="mini-stats">
                    <div class="mini-stat">
                        <h4>—</h4>
                        <p>Handled Classes</p>
                    </div>
                    <div class="mini-stat">
                        <h4>—</h4>
                        <p>Total Students</p>
                    </div>
                    <div class="mini-stat">
                        <h4>
                            <?php 
                            if (!empty($teacherData['date_hired'])) {
                                $hired = new DateTime($teacherData['date_hired']);
                                $now = new DateTime();
                                echo $hired->diff($now)->y;
                            } else { echo '—'; }
                            ?>
                        </h4>
                        <p>Years of Service</p>
                    </div>
                </div>
            </div>

            <!-- ── TWO COLUMN ── -->
            <div class="profile-grid" style="margin-bottom:1.25rem;">

                <!-- Personal Information -->
                <div class="panel">
                    <div class="panel-header">
                        <h2><i class="bi bi-person-lines-fill"></i> Personal Information</h2>
                        <p>Basic details on file with the registrar.</p>
                    </div>
                    <div class="panel-body">
                        <div class="field-list">
                            <div class="field-item">
                                <span class="field-label">First Name</span>
                                <span class="field-value"><?php echo e($teacherData['fname'] ?? ''); ?></span>
                            </div>
                            <div class="field-item">
                                <span class="field-label">Middle Name</span>
                                <span class="field-value"><?php echo !empty($teacherData['mname']) ? e($teacherData['mname']) : '-'; ?></span>
                            </div>
                            <div class="field-item">
                                <span class="field-label">Last Name</span>
                                <span class="field-value"><?php echo e($teacherData['lname'] ?? ''); ?></span>
                            </div>
                            <div class="field-item">
                                <span class="field-label">Gender</span>
                                <span class="field-value"><?php echo e($teacherData['sex'] ?? '-'); ?></span>
                            </div>
                            <div class="field-item">
                                <span class="field-label">Contact No.</span>
                                <span class="field-value"><?php echo e($teacherData['contact_no'] ?? '-'); ?></span>
                            </div>
                            <div class="field-item">
                                <span class="field-label">Email</span>
                                <span class="field-value muted"><?php echo e($teacherData['email'] ?? '-'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Professional Information -->
                <div class="panel">
                    <div class="panel-header">
                        <h2><i class="bi bi-briefcase-fill"></i> Professional Information</h2>
                        <p>School records and employment details.</p>
                    </div>
                    <div class="panel-body">
                        <div class="field-list">
                            <div class="field-item">
                                <span class="field-label">Employee ID</span>
                                <span class="field-value"><?php echo e($teacherData['teacher_id'] ?? $teacherId); ?></span>
                            </div>
                            <div class="field-item">
                                <span class="field-label">Date Hired</span>
                                <span class="field-value">
                                    <?php 
                                    echo !empty($teacherData['date_hired']) 
                                        ? date('F j, Y', strtotime($teacherData['date_hired'])) 
                                        : '-'; 
                                    ?>
                                </span>
                            </div>
                            <div class="field-item">
                                <span class="field-label">Status</span>
                                <span class="field-value">
                                    <span class="pill <?php echo ($teacherData['is_active'] ?? 1) ? 'pill-success' : 'pill-danger'; ?>">
                                        <?php echo ($teacherData['is_active'] ?? 1) ? 'Active' : 'Inactive'; ?>
                                    </span>
                                </span>
                            </div>
                            <div class="field-item">
                                <span class="field-label">Account Status</span>
                                <span class="field-value">
                                    <span class="pill <?php echo ($teacherData['user_status'] ?? 'Active') === 'Active' ? 'pill-success' : 'pill-danger'; ?>">
                                        <?php echo e($teacherData['user_status'] ?? 'Active'); ?>
                                    </span>
                                </span>
                            </div>
                            <div class="field-item">
                                <span class="field-label">Username</span>
                                <span class="field-value muted"><?php echo e($teacherData['username'] ?? '-'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ── EDIT PROFILE FORM ── -->
            <div id="edit-section" class="panel">
                <div class="panel-header">
                    <h2><i class="bi bi-pencil-square"></i> Edit Profile</h2>
                    <p>Update your contact information and account settings.</p>
                </div>

                <form action="../api/profile/update_teacher.php" method="POST">
                    <input type="hidden" name="teacher_id" value="<?php echo e($teacherData['teacher_id'] ?? ''); ?>">

                    <div class="form-grid">
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" name="fname" value="<?php echo e($teacherData['fname'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" name="lname" value="<?php echo e($teacherData['lname'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Middle Name</label>
                            <input type="text" name="mname" value="<?php echo e($teacherData['mname'] ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label>Contact Number</label>
                            <input type="tel" name="contact_no" value="<?php echo e($teacherData['contact_no'] ?? ''); ?>">
                        </div>
                        <div class="form-group full">
                            <label>Email Address</label>
                            <input type="email" name="email" value="<?php echo e($teacherData['email'] ?? ''); ?>">
                        </div>
                    </div>

                    <div class="section-divider" style="padding:0 1.4rem .75rem;">Account &amp; Security</div>

                    <div class="form-grid" style="padding-top:0">
                        <div class="form-group">
                            <label>Current Password</label>
                            <div class="pw-wrap">
                                <input type="password" id="currentPassword" name="current_password" placeholder="Enter current password">
                                <button type="button" class="toggle-pw" onclick="togglePassword('currentPassword', this)">
                                    <i class="bi bi-eye"></i>
                                </button>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>New Password</label>
                            <div class="pw-wrap">
                                <input type="password" id="newPassword" name="new_password" placeholder="Enter new password">
                                <button type="button" class="toggle-pw" onclick="togglePassword('newPassword', this)">
                                    <i class="bi bi-eye"></i>
                                </button>
                            </div>
                        </div>
                        <div class="form-group full">
                            <label>Confirm New Password</label>
                            <div class="pw-wrap">
                                <input type="password" id="confirmPassword" name="confirm_password" placeholder="Confirm new password">
                                <button type="button" class="toggle-pw" onclick="togglePassword('confirmPassword', this)">
                                    <i class="bi bi-eye"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="form-footer">
                        <button type="button" class="btn btn-ghost" onclick="location.reload()">Cancel</button>
                        <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Save Changes</button>
                    </div>
                </form>
            </div>

        </main>
    </div>

    <script>
        function togglePassword(inputId, btn) {
            const input = document.getElementById(inputId);
            const icon = btn.querySelector('i');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('bi-eye');
                icon.classList.add('bi-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('bi-eye-slash');
                icon.classList.add('bi-eye');
            }
        }

        // Sidebar
        const sidebar = document.getElementById('stsn-sidebar');
        const toggleBtn = document.getElementById('stsn-toggle');
        const overlay = document.getElementById('stsn-overlay');
        const collapseBtn = document.getElementById('stsn-collapse-btn');

        const savedState = localStorage.getItem('stsn-sidebar-collapsed');

        if (sidebar && savedState === 'true' && window.innerWidth >= 992) {
            sidebar.classList.add('collapsed');
            document.body.classList.add('sidebar-collapsed');
        }

        if (collapseBtn && sidebar) {
            collapseBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                sidebar.classList.toggle('collapsed');
                const isCollapsed = sidebar.classList.contains('collapsed');
                document.body.classList.toggle('sidebar-collapsed', isCollapsed);
                localStorage.setItem('stsn-sidebar-collapsed', isCollapsed);
            });
        }

        if (toggleBtn && sidebar) {
            toggleBtn.addEventListener('click', function () {
                sidebar.classList.toggle('mobile-open');
                overlay.classList.toggle('visible');
            });
        }

        if (overlay && sidebar) {
            overlay.addEventListener('click', function () {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('visible');
            });
        }

        window.addEventListener('resize', function () {
            if (!sidebar) return;
            if (window.innerWidth >= 992) {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('visible');
            } else {
                document.body.classList.remove('sidebar-collapsed');
            }
        });
    </script>
</body>
</html>