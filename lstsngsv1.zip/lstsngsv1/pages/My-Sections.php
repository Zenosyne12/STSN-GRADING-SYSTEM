<?php
require_once __DIR__ . '/../api/login/teacher_auth.php';

$teacherName = $_SESSION['teacher_name'] ?? 'Teacher';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Sections | STSN Grading System</title>

    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css/index.css">

    <style>
        :root {
            --primary: #0A2F44;
            --primary-soft: rgba(10, 47, 68, 0.08);
            --accent: #C5A028;
            --bg: #F5F7FA;
            --surface: #FFFFFF;
            --surface-2: #F8F9FA;
            --text: #1E2A3E;
            --muted: #6C757D;
            --border: #E9ECEF;
            --danger: #DC3545;
            --warning: #F59E0B;
            --success: #198754;
            --shadow: 0 10px 30px rgba(10, 47, 68, 0.08);
            --radius: 18px;
            --sidebar-width: 264px;
            --sidebar-collapsed-width: 72px;
        }

        * { box-sizing: border-box; }

        body.stsn-layout {
            margin: 0;
            font-family: "Plus Jakarta Sans", sans-serif;
            background: var(--bg);
            color: var(--text);
        }

        #stsn-toggle {
            position: fixed;
            top: 1rem;
            left: 1rem;
            z-index: 1100;
            width: 44px;
            height: 44px;
            border: 1px solid var(--border);
            border-radius: 12px;
            background: #fff;
            color: var(--primary);
            display: none;
            align-items: center;
            justify-content: center;
            box-shadow: var(--shadow);
            cursor: pointer;
        }

        #stsn-toggle i { font-size: 1.3rem; }

        #stsn-overlay {
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.35);
            opacity: 0;
            visibility: hidden;
            transition: 0.25s ease;
            z-index: 1035;
        }

        #stsn-overlay.visible {
            opacity: 1;
            visibility: visible;
        }

        .page-shell {
            margin-left: var(--sidebar-width);
            min-height: 100vh;
            transition: margin-left 0.28s ease;
            display: flex;
            flex-direction: column;
        }

        body.sidebar-collapsed .page-shell {
            margin-left: var(--sidebar-collapsed-width);
        }

        
        .top-bar {
            background: var(--surface);
            border-bottom: 1px solid var(--border);
            padding: .85rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            flex-wrap: wrap;
            position: sticky;
            top: 0;
            z-index: 40;
        }

        .top-bar-left h1 {
            margin: 0;
            font-size: 1.25rem;
            font-weight: 800;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: .5rem;
        }

        .top-bar-left p {
            margin: .2rem 0 0;
            color: var(--muted);
            font-size: .82rem;
        }

        .top-bar-right {
            display: flex;
            align-items: center;
            gap: .55rem;
            flex-wrap: wrap;
        }

        .meta-chip {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 999px;
            padding: .45rem .8rem;
            font-size: .78rem;
            color: var(--muted);
            display: inline-flex;
            align-items: center;
            gap: 5px;
            white-space: nowrap;
        }

        
        .page-main {
            padding: 1rem 1.5rem 1.5rem;
            display: grid;
            gap: 1rem;
        }

        .content-grid {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 320px;
            gap: 1rem;
        }

        .panel {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            overflow: hidden;
        }

        
        .panel-header {
            padding: 1rem 1.25rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .panel-title {
            margin: 0;
            display: flex;
            align-items: center;
            gap: 0.55rem;
            font-size: 1rem;
            font-weight: 800;
            color: var(--primary);
        }

        .panel-title i { color: var(--accent); }

        .panel-sub {
            font-size: 0.82rem;
            color: var(--muted);
            margin-top: 0.2rem;
        }

        .panel-header .btn {
            border: 1px solid var(--border);
            border-radius: 12px;
            background: #fff;
            color: var(--primary);
            font-family: inherit;
            font-weight: 800;
            font-size: .8rem;
            padding: .5rem .8rem;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            cursor: pointer;
            text-decoration: none;
        }

        .panel-header .btn:hover { background: var(--surface-2); }
        .panel-header .btn-primary {
            background: var(--primary);
            border-color: var(--primary);
            color: #fff;
        }
        .panel-header .btn-primary:hover { background: #0d3b56; }
        .panel-header .btn:disabled { opacity: .55; cursor: not-allowed; }

        .panel-header select.btn {
            appearance: none;
            -webkit-appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='%236C757D' viewBox='0 0 16 16'%3E%3Cpath d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right .6rem center;
            padding-right: 1.6rem;
        }

        .panel-header input[type="text"] {
            border: 1px solid var(--border);
            background: #fff;
            border-radius: 12px;
            padding: .52rem .75rem;
            font-family: inherit;
            font-size: .84rem;
            color: var(--text);
            width: 200px;
        }

        .table-wrap {
            overflow-x: auto;
            padding: 0 1rem 1rem;
        }

        .section-table {
            width: 100%;
            min-width: 900px;
            border-collapse: collapse;
        }

        .section-table th {
            text-align: left;
            font-size: 0.77rem;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            color: var(--muted);
            padding: 0.95rem 0 0.75rem;
            border-bottom: 1px solid var(--border);
        }

        .section-table td {
            padding: 0.95rem 0;
            border-bottom: 1px solid #f0f2f5;
            font-size: 0.9rem;
            vertical-align: middle;
        }

        .section-table tr:last-child td { border-bottom: none; }

        .section-main {
            font-weight: 700;
            color: var(--text);
        }

        .section-sub {
            display: block;
            font-size: 0.8rem;
            color: var(--muted);
            margin-top: 0.15rem;
        }

        .td-center { text-align: center; }

        .pill {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 999px;
            padding: 0.35rem 0.65rem;
            font-size: 0.74rem;
            font-weight: 700;
            white-space: nowrap;
        }

        .pill-danger {
            background: rgba(220, 53, 69, 0.1);
            color: var(--danger);
        }

        .pill-warning {
            background: rgba(245, 158, 11, 0.12);
            color: #b96f00;
        }

        .pill-success {
            background: rgba(25, 135, 84, 0.12);
            color: var(--success);
        }

        .pill-muted {
            background: #eef1f4;
            color: #5f6b76;
        }

        .row-actions {
            display: flex;
            gap: 0.45rem;
            flex-wrap: wrap;
        }

        .mini-btn {
            border: 1px solid var(--border);
            background: #fff;
            color: var(--text);
            border-radius: 10px;
            padding: 0.5rem 0.7rem;
            font-size: 0.78rem;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .mini-btn-maroon {
            border-color: #8B1A1A;
            background: #8B1A1A;
            color: #fff;
        }

        .mini-btn-maroon:hover {
            border-color: #6B1414;
            background: #6B1414;
            color: #fff;
        }

        .side-stack {
            display: grid;
            gap: 1rem;
        }

        .side-panel { padding: 1rem; }

        .compact-list {
            display: grid;
            gap: 0.8rem;
            margin-top: 1rem;
        }

        .compact-item {
            display: flex;
            gap: 0.75rem;
            align-items: flex-start;
        }

        .compact-icon {
            width: 38px;
            height: 38px;
            border-radius: 12px;
            background: var(--primary-soft);
            color: var(--primary);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .compact-title {
            font-size: 0.9rem;
            font-weight: 700;
            margin-bottom: 0.15rem;
        }

        .compact-sub {
            font-size: 0.82rem;
            color: var(--muted);
            line-height: 1.45;
        }

        .load-list {
            display: grid;
            gap: 0.75rem;
            margin-top: 1rem;
        }

        .load-item {
            padding: 0.9rem;
            border-radius: 14px;
            background: var(--surface-2);
        }

        .load-item-title {
            font-size: 0.9rem;
            font-weight: 700;
            color: var(--text);
            margin-bottom: 0.2rem;
        }

        .load-item-sub {
            font-size: 0.8rem;
            color: var(--muted);
            margin-bottom: 0.5rem;
        }

        .load-meta {
            display: flex;
            gap: 0.45rem;
            flex-wrap: wrap;
        }

        .empty-state,
        .loading-state {
            padding: 1rem 0;
            color: var(--muted);
            font-size: 0.92rem;
        }

        
        .notif-wrap {
            position: relative;
        }
        .notif-btn {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            border: 1px solid var(--border);
            background: #fff;
            color: var(--primary);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: var(--shadow);
        }
        .notif-btn i { font-size: 1.15rem; }
        .notif-count {
            position: absolute;
            top: -2px;
            right: -2px;
            min-width: 18px;
            height: 18px;
            border-radius: 999px;
            border: 2px solid #fff;
            background: #ef4444;
            color: #fff;
            font-size: 0.68rem;
            font-weight: 700;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 0 4px;
            line-height: 1;
        }
        .notif-panel {
            position: absolute;
            top: calc(100% + 12px);
            right: 0;
            width: min(420px, calc(100vw - 2rem));
            max-height: 460px;
            overflow: auto;
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 16px;
            box-shadow: 0 18px 42px rgba(10, 47, 68, 0.18);
            padding: 0.85rem;
            z-index: 1200;
            display: none;
        }
        .notif-panel.open { display: block; }
        .notif-panel-title {
            font-size: 0.95rem;
            font-weight: 800;
            color: var(--primary);
            padding: 0.35rem 0.35rem 0.65rem;
        }
        .notif-item {
            border: 1px solid #eef1f4;
            border-radius: 12px;
            padding: 0.72rem 0.8rem;
            background: #fafcff;
            margin-bottom: 0.6rem;
        }
        .notif-item:last-child { margin-bottom: 0; }
        .notif-item-title { font-size: 0.9rem; font-weight: 800; color: var(--text); line-height: 1.35; }
        .notif-item-sub { font-size: 0.84rem; color: var(--muted); margin-top: 0.25rem; line-height: 1.5; }

        @media (max-width: 1199px) {
            .content-grid { grid-template-columns: 1fr; }
        }

        @media (max-width: 991.98px) {
            #stsn-toggle { display: inline-flex; }
            .page-shell,
            body.sidebar-collapsed .page-shell { margin-left: 0; }
            .page-main { padding: 5rem 1rem 1.5rem; }
            .top-bar { padding: 4.5rem 1rem 1rem; }
        }

        @media (max-width: 767px) {
            .top-bar-left h1 { font-size: 1.05rem; }
            .panel-header input[type="text"] { width: 100%; }
        }
    </style>
</head>
<body class="stsn-layout">
    <button id="stsn-toggle" aria-label="Toggle sidebar">
        <i class="bi bi-list"></i>
    </button>

    <div id="stsn-overlay"></div>

    <?php include __DIR__ . '/../includes/teacher-sidebar.php'; ?>

    <div class="page-shell">
        
        <header class="top-bar">
            <div class="top-bar-left">
                <h1><i class="bi bi-journal-bookmark" style="color:var(--accent);"></i> My Sections</h1>
                <p>View teaching loads, grading progress, handled sections, and class actions.</p>
            </div>
            <div class="top-bar-right">
                <span class="meta-chip"><i class="bi bi-person-badge"></i> <?= htmlspecialchars($teacherName) ?></span>
                <span class="meta-chip"><i class="bi bi-journal-bookmark"></i> Section Loads</span>
                <div class="notif-wrap">
                    <button type="button" class="notif-btn" id="notifBellBtn" aria-label="Notifications">
                        <i class="bi bi-bell-fill"></i>
                    </button>
                    <span class="notif-count" id="notifBellCount">0</span>
                    <div class="notif-panel" id="notifPanel">
                        <div class="notif-panel-title">Notifications</div>
                        <div id="notifPanelList">
                            <div class="notif-item"><div class="notif-item-sub">Loading due date...</div></div>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <main class="page-main">
            <?php require_once __DIR__ . '/../includes/breadcrumb.php'; renderBreadcrumb([['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'], ['label' => 'Schedule', 'href' => 'My-Sections.php', 'icon' => 'bi bi-calendar-week'], ['label' => 'My Sections', 'icon' => 'bi bi-journal-bookmark']], 'teacher'); ?>
            <section class="content-grid">
                
                <div class="panel">
                    <div class="panel-header" style="flex-wrap:wrap;gap:.75rem;">
                        <div>
                            <h2 class="panel-title"><i class="bi bi-journal-text"></i> Section Loads</h2>
                            <div class="panel-sub">Teacher handled classes with grading, class list, and reporting shortcuts.</div>
                        </div>
                        <div style="display:flex;align-items:center;gap:.55rem;flex-wrap:wrap;margin-left:auto;">
                            <input type="text" id="searchInput" placeholder="Search sections">
                            <select id="sectionFilter" class="btn">
                                <option value="">All Sections</option>
                            </select>
                            <select id="statusFilter" class="btn">
                                <option value="">All Status</option>
                                <option value="Yes">Submitted</option>
                                <option value="No">Not Submitted</option>
                            </select>
                            <button class="btn" type="button" onclick="loadSections()" title="Refresh">
                                <i class="bi bi-arrow-clockwise"></i>
                            </button>
                        </div>
                    </div>

                    <div class="table-wrap">
                        <div id="loadingState" class="loading-state">Loading sections...</div>

                        <table class="section-table" id="sectionTable" style="display:none;">
                            <thead>
                                <tr>
                                    <th>Section Name</th>
                                    <th class="td-center">Students</th>
                                    <th class="td-center">Pending</th>
                                    <th class="td-center">Submitted</th>
                                    <th class="td-center">Average</th>
                                    <th class="td-center">At-Risk</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="sectionTableBody"></tbody>
                        </table>

                        <div id="emptyState" class="empty-state" style="display:none;">
                            <div style="text-align:center;padding:2rem 1rem;">
                                <div style="width:64px;height:64px;border-radius:50%;background:#fdf2f2;display:inline-flex;align-items:center;justify-content:center;font-size:1.7rem;color:#8B1A1A;margin-bottom:.85rem;">
                                    <i class="bi bi-inbox"></i>
                                </div>
                                <h3 style="font-size:1rem;color:#8B1A1A;margin:0 0 .3rem;">No sections assigned yet</h3>
                                <p style="color:#a97b7b;font-size:.88rem;margin:0;">Contact your administrator to assign you to a section or subject.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="side-stack">
                    <div class="panel side-panel">
                        <h3 class="panel-title"><i class="bi bi-lightning-charge-fill"></i> Quick Actions</h3>
                        <div class="compact-list">
                            <div class="compact-item">
                                <div class="compact-icon"><i class="bi bi-pencil-square"></i></div>
                                <div>
                                    <div class="compact-title">Encode grades</div>
                                    <div class="compact-sub">Go directly to the grading sheet for each handled section.</div>
                                </div>
                            </div>
                            <div class="compact-item">
                                <div class="compact-icon"><i class="bi bi-people-fill"></i></div>
                                <div>
                                    <div class="compact-title">Open class list</div>
                                    <div class="compact-sub">Check students assigned to each section quickly.</div>
                                </div>
                            </div>
                            <div class="compact-item">
                                <div class="compact-icon"><i class="bi bi-file-earmark-bar-graph"></i></div>
                                <div>
                                    <div class="compact-title">Generate reports</div>
                                    <div class="compact-sub">Prepare class-based report outputs when available.</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="panel side-panel">
                        <h3 class="panel-title"><i class="bi bi-exclamation-circle-fill"></i> Priority Loads</h3>
                        <div class="load-list" id="priorityLoads">
                            <div class="compact-sub">No priority loads yet.</div>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <script>
        const sidebar = document.getElementById('stsn-sidebar');
        const toggleBtn = document.getElementById('stsn-toggle');
        const overlay = document.getElementById('stsn-overlay');
        const collapseBtn = document.getElementById('stsn-collapse-btn');

        const savedState = localStorage.getItem('stsn-sidebar-collapsed');

        if (sidebar && savedState === 'true' && window.innerWidth >= 992) {
            sidebar.classList.add('collapsed');
            document.body.classList.add('sidebar-collapsed');
        }

        if (collapseBtn && sidebar) {
            collapseBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                sidebar.classList.toggle('collapsed');
                const isCollapsed = sidebar.classList.contains('collapsed');
                document.body.classList.toggle('sidebar-collapsed', isCollapsed);
                localStorage.setItem('stsn-sidebar-collapsed', isCollapsed);
            });
        }

        if (toggleBtn && sidebar) {
            toggleBtn.addEventListener('click', function () {
                sidebar.classList.toggle('mobile-open');
                overlay.classList.toggle('visible');
            });
        }

        if (overlay && sidebar) {
            overlay.addEventListener('click', function () {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('visible');
            });
        }

        window.addEventListener('resize', function () {
            if (!sidebar) return;
            if (window.innerWidth >= 992) {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('visible');
            } else {
                document.body.classList.remove('sidebar-collapsed');
            }
        });

        const table = document.getElementById('sectionTable');
        const tbody = document.getElementById('sectionTableBody');
        const loadingState = document.getElementById('loadingState');
        const emptyState = document.getElementById('emptyState');
        const sectionFilter = document.getElementById('sectionFilter');
        const statusFilter = document.getElementById('statusFilter');
        const searchInput = document.getElementById('searchInput');
        const priorityLoads = document.getElementById('priorityLoads');
        const notifBellBtn = document.getElementById('notifBellBtn');
        const notifBellCount = document.getElementById('notifBellCount');
        const notifPanel = document.getElementById('notifPanel');
        const notifPanelList = document.getElementById('notifPanelList');
        const LAST_SEEN_KEY = 'teacher-notif-last-seen-id';
        let lastNotifications = [];
        let latestDeadlineInfo = null;

        let allRows = [];

        function pendingPillClass(value) {
            value = parseInt(value || 0, 10);
            if (value >= 4) return 'pill-danger';
            if (value >= 1) return 'pill-warning';
            return 'pill-success';
        }

        function statusPillClass(value) {
            return value === 'Yes' ? 'pill-success' : 'pill-warning';
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text ?? '';
            return div.innerHTML;
        }

        async function loadDeadlineFeed() {
            try {
                const res = await fetch('../api/deadline/get_teacher_deadline_feed.php', { headers: { 'Accept': 'application/json' } });
                const out = await res.json();
                if (!out.success || !out.data) {
                    renderNotifPanel([]);
                    return;
                }
                const data = out.data;
                latestDeadlineInfo = data;
                const reminders = Array.isArray(data.reminders) ? data.reminders : [];
                renderNotifPanel(reminders);
            } catch (e) {
                latestDeadlineInfo = null;
                renderNotifPanel([]);
            }
        }
        function renderNotifPanel(reminders) {
            lastNotifications = reminders;
            const seenId = Number(localStorage.getItem(LAST_SEEN_KEY) || 0);
            const unread = reminders.filter(r => Number(r.id || 0) > seenId);
            const count = unread.length;
            notifBellCount.style.display = count > 0 ? 'inline-flex' : 'none';
            notifBellCount.textContent = count > 9 ? '9+' : String(count);
            const dueItems = [];
            if (latestDeadlineInfo?.teacher_deadline_display) {
                dueItems.push(`
                    <div class="notif-item">
                        <div class="notif-item-title">Teacher Due Date</div>
                        <div class="notif-item-sub">${escapeHtml(latestDeadlineInfo.teacher_deadline_display)}</div>
                    </div>
                `);
            }
            if (latestDeadlineInfo?.is_adviser && latestDeadlineInfo?.adviser_deadline_display) {
                dueItems.push(`
                    <div class="notif-item">
                        <div class="notif-item-title">Adviser Due Date</div>
                        <div class="notif-item-sub">${escapeHtml(latestDeadlineInfo.adviser_deadline_display)}</div>
                    </div>
                `);
            }
            const reminderItems = reminders.map(r => `
                <div class="notif-item">
                    <div class="notif-item-title">${escapeHtml(r.title || 'Reminder')}</div>
                    <div class="notif-item-sub">${escapeHtml(r.message || '')}</div>
                    <div class="notif-item-sub">${escapeHtml(r.created_at_display || '')}</div>
                </div>
            `);
            const merged = [...dueItems, ...reminderItems];
            notifPanelList.innerHTML = merged.length
                ? merged.join('')
                : '<div class="notif-item"><div class="notif-item-sub">No active due date.</div></div>';
        }

        async function loadSections() {
            loadingState.style.display = 'block';
            table.style.display = 'none';
            emptyState.style.display = 'none';
            tbody.innerHTML = '';
            priorityLoads.innerHTML = '<div class="compact-sub">Loading...</div>';

            try {
                const response = await fetch('../api/section-handle/get_subject_handles.php', {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json'
                    }
                });

                const result = await response.json();

                if (!result.success) {
                    throw new Error(result.message || 'Failed to load data');
                }

                allRows = result.data || [];

                populateSectionFilter(allRows);
                renderTable();
                renderPriorityLoads();
            } catch (error) {
                loadingState.style.display = 'none';
                emptyState.style.display = 'block';
                emptyState.textContent = 'Failed to load sections. ' + error.message;
                priorityLoads.innerHTML = '<div class="compact-sub">Unable to load priority loads.</div>';
            }
        }

        function populateSectionFilter(rows) {
            const currentValue = sectionFilter.value;
            const sections = [...new Set(rows.map(row => row.section).filter(Boolean))].sort();

            sectionFilter.innerHTML = '<option value="">All Sections</option>';
            sections.forEach(section => {
                const option = document.createElement('option');
                option.value = section;
                option.textContent = section;
                sectionFilter.appendChild(option);
            });

            sectionFilter.value = currentValue;
        }

        function getFilteredRows() {
            const search = searchInput.value.trim().toLowerCase();
            const section = sectionFilter.value;
            const status = statusFilter.value;

            return allRows.filter(row => {
                const matchesSearch =
                    !search ||
                    (row.section || '').toLowerCase().includes(search) ||
                    (row.schedule || '').toLowerCase().includes(search);

                const matchesSection = !section || row.section === section;
                const matchesStatus = !status || row.submitted === status;

                return matchesSearch && matchesSection && matchesStatus;
            });
        }

        function renderTable() {
            const rows = getFilteredRows();

            loadingState.style.display = 'none';

            if (!rows.length) {
                table.style.display = 'none';
                emptyState.style.display = 'block';
                return;
            }

            emptyState.style.display = 'none';
            table.style.display = 'table';

            tbody.innerHTML = rows.map(row => `
                <tr>
                    <td>
                        <div class="section-main">${escapeHtml(row.section)}</div>
                        <span class="section-sub">${escapeHtml(row.subject)}</span>
                    </td>
                    <td class="td-center">${escapeHtml(String(row.students))}</td>
                    <td class="td-center">
                        <span class="pill ${pendingPillClass(row.pending)}">${escapeHtml(String(row.pending))}</span>
                    </td>
                    <td class="td-center">
                        <span class="pill ${statusPillClass(row.submitted)}">${escapeHtml(row.submitted)}</span>
                    </td>
                    <td class="td-center">${escapeHtml(row.average)}</td>
                    <td class="td-center">
                        <span class="pill ${pendingPillClass(row.at_risk)}">${escapeHtml(String(row.at_risk))}</span>
                    </td>
                    <td>
                        <div class="row-actions">
                            <a class="mini-btn mini-btn-maroon" href="../pages/Grading-Sheet.php?section_id=${encodeURIComponent(row.section_id)}&subject_id=${encodeURIComponent(row.subject_id)}">Encode</a>
                            <a class="mini-btn mini-btn-maroon" href="../pages/Class-List.php?section_id=${encodeURIComponent(row.section_id)}">Class List</a>
                            <a class="mini-btn mini-btn-maroon" href="../pages/Schedule.php?section_id=${encodeURIComponent(row.section_id)}&subject_id=${encodeURIComponent(row.subject_id)}">Schedule</a>
                        </div>
                    </td>
                </tr>
            `).join('');
        }

        function renderPriorityLoads() {
            const priorityRows = allRows.filter(row => Number(row.pending) >= 3 || Number(row.at_risk) >= 3);

            if (!priorityRows.length) {
                priorityLoads.innerHTML = '<div class="compact-sub">No priority loads yet.</div>';
                return;
            }

            priorityLoads.innerHTML = priorityRows.map(row => `
                <div class="load-item">
                    <div class="load-item-title">${escapeHtml(row.section)} • ${escapeHtml(row.subject)}</div>
                    <div class="load-item-sub">${escapeHtml(row.schedule)}</div>
                    <div class="load-meta">
                        <span class="pill ${pendingPillClass(row.pending)}">${escapeHtml(String(row.pending))} Pending</span>
                        <span class="pill ${pendingPillClass(row.at_risk)}">${escapeHtml(String(row.at_risk))} At-Risk</span>
                    </div>
                </div>
            `).join('');
        }

        searchInput.addEventListener('input', renderTable);
        sectionFilter.addEventListener('change', renderTable);
        statusFilter.addEventListener('change', renderTable);
        notifBellBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            notifPanel.classList.toggle('open');
            if (notifPanel.classList.contains('open') && lastNotifications.length) {
                const maxId = Math.max(...lastNotifications.map(r => Number(r.id || 0)));
                localStorage.setItem(LAST_SEEN_KEY, String(maxId));
                renderNotifPanel(lastNotifications);
            }
        });
        document.addEventListener('click', function (e) {
            if (!notifPanel.contains(e.target) && !notifBellBtn.contains(e.target)) {
                notifPanel.classList.remove('open');
            }
        });

        loadDeadlineFeed();
        loadSections();
    </script>
</body>
</html>
