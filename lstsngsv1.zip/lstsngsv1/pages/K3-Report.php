<?php
require_once __DIR__ . '/../api/login/teacher_auth.php';

// Server-side guard: K-3 assignment required (blocks direct URL access).
requireK3();

$teacherName = $_SESSION['teacher_name'] ?? 'Teacher';
$teacherId   = (int) ($_SESSION['teacher_id'] ?? 0);

/* 1. Active academic year */
$activeYear = $pdo->query("
    SELECT id, year_label
    FROM tblacademicyear
    WHERE is_active = 1
    LIMIT 1
")->fetch(PDO::FETCH_ASSOC) ?: null;

$activeYearId = $activeYear ? (int) $activeYear['id'] : 0;
$schoolYear   = $activeYear['year_label'] ?? (date('Y') . '-' . (date('Y') + 1));

/* Teacher's K-3 sections (adviser OR actively scheduled; grade_level_code 0-3) */
$teacherSections = [];
if ($teacherId > 0) {
    $secStmt = $pdo->prepare("
        SELECT s.id, s.section_name, gl.grade_level_name, gl.grade_level_code
        FROM (
            SELECT section_id FROM tblsectionadviser WHERE teacher_id = :t1
            UNION
            SELECT section_id FROM tblschedule WHERE teacher_id = :t2 AND is_active = 1
        ) tsecs
        JOIN tblsection s ON s.id = tsecs.section_id
        JOIN tblgradelevel gl ON gl.id = s.grade_level_id
        WHERE gl.grade_level_code IN (0, 1, 2, 3)
        ORDER BY gl.grade_level_code ASC, s.section_name ASC
    ");
    $secStmt->execute(['t1' => $teacherId, 't2' => $teacherId]);
    $teacherSections = $secStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

/* Terms (trimester/quarter config for the active year) */
$terms = [];
try {
    $termStmt = $pdo->prepare("
        SELECT id, term_number, term_label, term_type, is_active, is_closed
        FROM tblconfig_terms
        WHERE academic_year_id = ?
        ORDER BY term_number ASC
    ");
    $termStmt->execute([$activeYearId]);
    $terms = $termStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
    $terms = [];
}

/* Map term_number -> term_id (drives the Term 1 / Term 2 / Term 3 columns) */
$termIdByNumber = [];
foreach ($terms as $t) {
    $termIdByNumber[(int) $t['term_number']] = (int) $t['id'];
}
$termNumbers = [1, 2, 3];

/* URL params: ?section_id=X&term_id=Y&student_id=Z */
$sectionId = isset($_GET['section_id']) ? (int) $_GET['section_id'] : 0;
$termId    = isset($_GET['term_id']) ? (int) $_GET['term_id'] : 0;
$studentId = isset($_GET['student_id']) ? (int) $_GET['student_id'] : 0;
$printMode = ($sectionId > 0 && $termId > 0 && $studentId > 0);

/* ---------- Report helpers ---------- */

/** Display age from birthdate ("5 yrs" / "9 mos" / em-dash) */
function k3ReportAge(?string $birthdate): string
{
    if ($birthdate === null || $birthdate === '') return '&mdash;';
    try {
        $birth = new DateTime($birthdate);
        $diff  = $birth->diff(new DateTime('today'));
        return $diff->y >= 1 ? $diff->y . ' yrs' : $diff->m . ' mos';
    } catch (Throwable $e) {
        return '&mdash;';
    }
}

/** Final rating rule: Term 3 if available; else latest term with a rating; else null. */
function k3FinalRating(array $byTerm, array $termNumbers): ?string
{
    for ($i = count($termNumbers) - 1; $i >= 0; $i--) {
        $num = (int) $termNumbers[$i];
        if (isset($byTerm[$num]) && $byTerm[$num] !== '' && $byTerm[$num] !== null) {
            return (string) $byTerm[$num];
        }
    }
    return null;
}

/** Core value name for a deportment statement_index (1-4). */
function k3CoreValue(int $index): ?string
{
    $map = [
        1 => 'Maka-Diyos',
        2 => 'Makatao',
        3 => 'Makakalikasan',
        4 => 'Makabansa',
    ];
    return $map[$index] ?? null;
}

/** Format an attendance decimal without trailing zeros. */
function k3Num($value): string
{
    $f = (float) $value;
    return $f == (int) $f ? (string) (int) $f : rtrim(rtrim(number_format($f, 2, '.', ''), '0'), '.');
}

/** Final rating -> Remarks text (A,S -> Passed; R,N -> Failed; none -> em-dash). */
if (!function_exists('k3RatingRemark')) {
    function k3RatingRemark(?string $rating): string
    {
        $r = strtoupper(trim((string) $rating));
        if ($r === 'A' || $r === 'S') return 'Passed';
        if ($r === 'R' || $r === 'N') return 'Failed';
        return '&mdash;';
    }
}

/* ---------- Report data (print view) ---------- */
$reportError = '';
$report      = null;

if ($printMode) {
    /* Section must be one of the teacher's own K-3 sections */
    $selectedSection = null;
    foreach ($teacherSections as $sec) {
        if ((int) $sec['id'] === $sectionId) {
            $selectedSection = $sec;
            break;
        }
    }

    /* Term must belong to the active school year */
    $selectedTerm = null;
    foreach ($terms as $t) {
        if ((int) $t['id'] === $termId) {
            $selectedTerm = $t;
            break;
        }
    }

    /* Student */
    $student = null;
    if ($studentId > 0) {
        $stStmt = $pdo->prepare("
            SELECT st.id, st.lname, st.fname, st.mname, st.lrn, st.gender, st.birthdate
            FROM tblstudents st
            WHERE st.id = ?
            LIMIT 1
        ");
        $stStmt->execute([$studentId]);
        $student = $stStmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /* Student must be enrolled in the selected section for the active year */
    $enrolled = false;
    if ($student && $selectedSection && $activeYearId > 0) {
        $enrStmt = $pdo->prepare("
            SELECT 1
            FROM tblsectionstudent ss
            WHERE ss.section_id = ?
              AND ss.student_id = ?
              AND ss.academic_year_id = ?
              AND ss.is_active = 1
            LIMIT 1
        ");
        $enrStmt->execute([$sectionId, $studentId, $activeYearId]);
        $enrolled = (bool) $enrStmt->fetchColumn();
    }

    if (!$selectedSection)  $reportError = 'Section not found or not assigned to you.';
    elseif (!$selectedTerm) $reportError = 'Term not found for the active school year.';
    elseif (!$student)      $reportError = 'Student not found.';
    elseif (!$enrolled)     $reportError = 'Student is not enrolled in the selected section.';

    if ($reportError === '') {
        $gradeLevelCode = (int) $selectedSection['grade_level_code'];
        $reportTitle = $gradeLevelCode === 0
            ? 'Kindergarten Progress Report'
            : 'K-3 Progress Report';

        /* Domains + active skills (ordered) */
        $domainStmt = $pdo->prepare("
            SELECT d.id AS domain_id, d.domain_code, d.domain_name,
                   sk.id AS skill_id, sk.skill_code, sk.skill_description
            FROM tblkinder_domains d
            LEFT JOIN tblkinder_skills sk ON sk.domain_id = d.id AND sk.is_active = 1
            WHERE d.is_active = 1
            ORDER BY d.sort_order, sk.sort_order
        ");
        $domainStmt->execute();
        $domainRows = $domainStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        /* Assessments -> $ratings[skill_id][term_id] = rating (A/S/R/N) */
        $ratings = [];
        $asStmt = $pdo->prepare("
            SELECT skill_id, term_id, rating
            FROM tblkinder_assessments
            WHERE student_id = ? AND section_id = ? AND academic_year_id = ?
        ");
        $asStmt->execute([$studentId, $sectionId, $activeYearId]);
        foreach ($asStmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $a) {
            $ratings[(int) $a['skill_id']][(int) $a['term_id']] = (string) $a['rating'];
        }

        /* Attendance summary */
        $attStmt = $pdo->prepare("
            SELECT month_number, month_name, school_days, days_present, days_absent
            FROM tblattendance_records
            WHERE student_id = ? AND section_id = ? AND academic_year_id = ?
            ORDER BY month_number ASC
        ");
        $attStmt->execute([$studentId, $sectionId, $activeYearId]);
        $attendance = $attStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        $attTotals = ['school_days' => 0.0, 'days_present' => 0.0, 'days_absent' => 0.0];
        foreach ($attendance as $ar) {
            $attTotals['school_days']  += (float) $ar['school_days'];
            $attTotals['days_present'] += (float) $ar['days_present'];
            $attTotals['days_absent']  += (float) $ar['days_absent'];
        }

        /* Observed values (deportment) -> $deportment[statement_index][quarter] */
        $depStmt = $pdo->prepare("
            SELECT statement_index, quarter, rating
            FROM tbldeportment_records
            WHERE student_id = ? AND section_id = ? AND academic_year_id = ?
        ");
        $depStmt->execute([$studentId, $sectionId, $activeYearId]);
        $deportment = [];
        foreach ($depStmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $dp) {
            $deportment[(int) $dp['statement_index']][(int) $dp['quarter']] = (string) $dp['rating'];
        }

        /* Narratives per term -> keyed by term_id */
        $narStmt = $pdo->prepare("
            SELECT term_id, narrative
            FROM tblkinder_narratives
            WHERE student_id = ? AND section_id = ? AND academic_year_id = ?
        ");
        $narStmt->execute([$studentId, $sectionId, $activeYearId]);
        $narrativesByTerm = [];
        foreach ($narStmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $nr) {
            $narrativesByTerm[(int) $nr['term_id']] = trim((string) $nr['narrative']);
        }

/* Group domains -> skills with per-term + final ratings */
        $domains = [];
        foreach ($domainRows as $row) {
            $domId = (int) $row['domain_id'];
            if (!isset($domains[$domId])) {
                $domains[$domId] = [
                    'domain_name' => (string) $row['domain_name'],
                    'skills'      => [],
                ];
            }
            if ($row['skill_id'] !== null) {
                $skid   = (int) $row['skill_id'];
                $byTerm = [];
                foreach ($termNumbers as $num) {
                    $tid = $termIdByNumber[$num] ?? 0;
                    $byTerm[$num] = ($tid > 0 && isset($ratings[$skid][$tid]))
                        ? $ratings[$skid][$tid] : null;
                }
                $domains[$domId]['skills'][] = [
                    'skill_code'        => (string) $row['skill_code'],
                    'skill_description' => (string) $row['skill_description'],
                    'by_term'           => $byTerm,
                    'final'             => k3FinalRating($byTerm, $termNumbers),
                ];
            }
        }
        $domains = array_values($domains);

        /* Observed values rows (Core Value 1-4) */
        $observedValues = [];
        for ($idx = 1; $idx <= 4; $idx++) {
            $observedValues[] = [
                'core_value' => k3CoreValue($idx),
                'terms'      => [
                    1 => $deportment[$idx][1] ?? null,
                    2 => $deportment[$idx][2] ?? null,
                    3 => $deportment[$idx][3] ?? null,
                ],
            ];
        }

        /* Narratives keyed by term_number + has-narrative flag */
        $narratives   = [];
        $hasNarrative = false;
        foreach ($termNumbers as $num) {
            $tid = $termIdByNumber[$num] ?? 0;
            $txt = ($tid > 0 && isset($narrativesByTerm[$tid])) ? $narrativesByTerm[$tid] : '';
            $narratives[$num] = $txt;
            if ($txt !== '') $hasNarrative = true;
        }

        /* Student display fields (name format matches the checklist page) */
        $mid      = trim((string) ($student['mname'] ?? ''));
        $midInit  = $mid !== '' ? strtoupper(substr($mid, 0, 1)) . '.' : '';
        $fullName = trim(($student['lname'] ?? '') . ', ' . ($student['fname'] ?? '') . ' ' . $midInit);

        $report = [
            'full_name'       => $fullName,
            'lrn'             => trim((string) ($student['lrn'] ?? '')),
            'grade_level'     => (string) ($selectedSection['grade_level_name'] ?? ''),
            'section_name'    => (string) ($selectedSection['section_name'] ?? ''),
            'sex'             => strtoupper(trim((string) ($student['gender'] ?? ''))),
            'age_html'        => k3ReportAge($student['birthdate'] ?? null),
            'term_label'      => $selectedTerm['term_label'] ?? 'Term',
            'report_title'    => $reportTitle,
            'domains'         => $domains,
            'attendance'      => $attendance,
            'att_totals'      => $attTotals,
            'observed_values' => $observedValues,
            'narratives'      => $narratives,
            'hasData'         => (count($ratings) > 0 || count($attendance) > 0 || count($deportment) > 0 || $hasNarrative),
        ];
    } else {
        /* Invalid selection -> fall back to the selection form */
        $printMode = false;
    }
}

/* ---------- Form data (selection view) ---------- */
$formStudents = [];
if (!$printMode) {
    /* Default section = first K-3 section */
    if ($sectionId <= 0) {
        $sectionId = (int) ($teacherSections[0]['id'] ?? 0);
    }

    /* Default term = active term */
    if ($termId <= 0) {
        foreach ($terms as $t) {
            if ((int) $t['is_active'] === 1) {
                $termId = (int) $t['id'];
                break;
            }
        }
        if ($termId <= 0 && $terms) {
            $termId = (int) $terms[0]['id'];
        }
    }

    /* Students enrolled in the preselected section */
    if ($sectionId > 0 && $activeYearId > 0) {
        $fsStmt = $pdo->prepare("
            SELECT st.id, st.lname, st.fname, st.mname
            FROM tblsectionstudent ss
            INNER JOIN tblstudents st ON st.id = ss.student_id
            WHERE ss.section_id = ?
              AND ss.academic_year_id = ?
              AND ss.is_active = 1
              AND COALESCE(st.is_active, 1) = 1
            ORDER BY st.lname ASC, st.fname ASC, st.mname ASC
        ");
        $fsStmt->execute([$sectionId, $activeYearId]);
        $formStudents = $fsStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>K-3 Progress Report | STSN</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css/index.css">
    <style>
        :root {
            --primary: #0A2F44; --primary-soft: rgba(10,47,68,0.08); --accent: #C5A028;
            --maroon: #8B1A1A; --bg: #F5F7FA; --surface: #FFFFFF; --surface-2: #F8F9FA;
            --text: #1E2A3E; --muted: #6C757D; --border: #E9ECEF;
            --shadow: 0 10px 30px rgba(10,47,68,0.08); --radius: 18px;
            --sidebar-width: 260px; --sidebar-collapsed-width: 72px;
        }

        /* Dark mode — adapt page tokens (surfaces / text) without a redesign.
           NOTE: .print-card stays white/black (it mirrors a printed sheet). */
        html.dark-mode,
        [data-bs-theme="dark"] {
            --bg: #0f0f0f;
            --surface: #1e1e1e;
            --surface-2: #262626;
            --text: #e4e6e8;
            --muted: #9aa3ad;
            --border: #34393f;
            --primary-soft: rgba(120, 170, 255, 0.12);
            --shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        }
        /* Hardcoded light surfaces that bypass the tokens */
        html.dark-mode #stsn-toggle,
        [data-bs-theme="dark"] #stsn-toggle { background: var(--surface); color: #cfe0ff; }
        html.dark-mode .btn-secondary,
        [data-bs-theme="dark"] .btn-secondary { background: var(--surface-2); color: #cfe0ff; border-color: var(--border); }
        html.dark-mode .form-field select,
        html.dark-mode .toolbar select,
        html.dark-mode .toolbar input[type="text"],
        [data-bs-theme="dark"] .form-field select,
        [data-bs-theme="dark"] .toolbar select,
        [data-bs-theme="dark"] .toolbar input[type="text"] { background: var(--surface-2); color: var(--text); border-color: var(--border); }

        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html, body { height: 100%; }
        body.stsn-layout { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); color: var(--text); }

        #stsn-toggle { position: fixed; top: 1rem; left: 1rem; z-index: 1100; width: 44px; height: 44px; border: 1px solid var(--border); border-radius: 12px; background: #fff; color: var(--primary); display: none; align-items: center; justify-content: center; box-shadow: var(--shadow); cursor: pointer; }
        #stsn-overlay { position: fixed; inset: 0; background: rgba(15,23,42,0.35); opacity: 0; visibility: hidden; transition: 0.25s ease; z-index: 1035; }
        #stsn-overlay.visible { opacity: 1; visibility: visible; }
        .page-shell { margin-left: var(--sidebar-width); min-height: 100vh; transition: margin-left 0.28s ease; display: flex; flex-direction: column; }
        body.sidebar-collapsed .page-shell { margin-left: var(--sidebar-collapsed-width); }

        .top-bar { background: var(--surface); border-bottom: 1px solid var(--border); border-top: 4px solid var(--maroon); padding: 0.85rem 1.5rem; display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap; }
        .top-bar-left h1 { font-size: 1.25rem; font-weight: 800; color: var(--primary); display: flex; align-items: center; gap: 0.5rem; }
        .top-bar-left p { font-size: 0.82rem; color: var(--muted); margin-top: 2px; }
        .top-bar-right { display: flex; gap: 0.55rem; align-items: center; flex-wrap: wrap; }
        .btn { display: inline-flex; align-items: center; gap: 0.4rem; padding: 0.6rem 1.1rem; border-radius: 10px; font-size: 0.85rem; font-weight: 700; border: none; cursor: pointer; text-decoration: none; transition: 0.2s ease; font-family: inherit; }
        .btn-primary { background: var(--maroon); color: #fff; }
        .btn-primary:hover { background: #731515; }
        .btn-secondary { background: #fff; color: var(--primary); border: 1.5px solid var(--border); }
        .btn-secondary:hover { background: var(--surface-2); }

        .page-main { flex: 1; padding: 1.5rem; }

        .report-form-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); box-shadow: var(--shadow); padding: 1.5rem; max-width: 720px; margin: 0 auto; }
        .report-form-card h2 { font-size: 1.1rem; font-weight: 800; color: var(--primary); display: flex; align-items: center; gap: 0.5rem; }
        .report-form-card .form-sub { font-size: 0.82rem; color: var(--muted); margin: 0.35rem 0 1.1rem; }
        .form-field { margin-bottom: 1rem; }
        .form-field label { display: block; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: var(--muted); margin-bottom: 6px; }
        .form-field select { width: 100%; padding: 0.65rem 0.9rem; border: 1.5px solid var(--border); border-radius: 10px; font-family: inherit; font-size: 0.88rem; background: #fff; color: var(--text); }
        .form-field select:focus { outline: none; border-color: var(--maroon); box-shadow: 0 0 0 3px rgba(139,26,26,0.10); }
        .form-actions { display: flex; justify-content: flex-end; gap: 0.55rem; margin-top: 1.25rem; }
        .form-error { background: #FDECEC; border: 1px solid #F5C2C2; color: #B42318; border-radius: 10px; padding: 0.65rem 0.9rem; font-size: 0.82rem; margin-bottom: 1rem; display: flex; align-items: center; gap: 6px; }
        .form-empty { font-size: 0.85rem; color: var(--muted); background: var(--surface-2); border: 1px dashed var(--border); border-radius: 10px; padding: 0.9rem 1rem; }
        /* ---------- Print card (A4 portrait) ---------- */
        .print-card { background: #fff; color: #000; max-width: 840px; margin: 0 auto 2.5rem; padding: 34px 44px; border: 1px solid #000; border-top: 8px solid var(--maroon); box-shadow: 0 12px 40px rgba(10,47,68,0.10); }
        .report-head { display: flex; align-items: center; justify-content: space-between; gap: 16px; text-align: center; }
        .report-head img { height: 92px; width: auto; object-fit: contain; }
        .report-head-center { font-size: 12.5px; line-height: 1.55; letter-spacing: 0.2px; }
        .report-head-center .school-name { font-weight: 800; font-size: 14px; margin-top: 2px; display: block; }
        .report-head-center .school-address { font-size: 11.5px; display: block; }
        .report-title { text-align: center; margin: 18px 0 20px; }
        .report-title h2 { font-size: 21px; font-weight: 800; letter-spacing: 1.2px; color: var(--maroon); text-transform: uppercase; }
        .report-title p { font-size: 13px; margin-top: 4px; font-weight: 700; }

        .report-info { width: 100%; border-collapse: collapse; margin-bottom: 18px; }
        .report-info td { border: 1px solid #000; padding: 6px 10px; font-size: 13px; }
        .report-info .lbl { font-weight: 800; width: 110px; background: #f5f5f5; text-transform: uppercase; font-size: 11px; letter-spacing: 0.4px; }
        .report-info .val-wide { font-weight: 700; }

        .dear-parents { background: #fdf8f8; border-left: 4px solid #8B1A1A; padding: 0.75rem 1rem; margin: 1rem 0; border-radius: 6px; font-size: 0.9rem; line-height: 1.5; }
        .dear-parents p { margin: 0 0 0.5rem; }
        .dear-parents p:last-child { margin-bottom: 0; }
        .dear-parents .salut { font-weight: 800; }

        .section-title { font-weight: 800; text-transform: uppercase; font-size: 12.5px; letter-spacing: 0.5px; margin: 20px 0 8px; padding-bottom: 4px; border-bottom: 2px solid #000; }

        .report-table { width: 100%; border-collapse: collapse; }
        .report-table th, .report-table td { border: 1px solid #000; padding: 6px 10px; font-size: 13px; vertical-align: middle; }
        .report-table thead th { background: #f5f5f5; font-size: 12px; text-transform: uppercase; letter-spacing: 0.4px; text-align: center; }
        .report-table .col-skill { text-align: left; }
        .report-table .col-domain { width: 180px; text-align: left; }
        .report-table .col-term, .report-table .col-final { width: 74px; text-align: center; }
        .report-table .col-remarks { width: 96px; text-align: center; }
        .report-table tr.domain-row td { background: #f5f5f5; font-weight: 800; font-size: 12.5px; letter-spacing: 0.3px; }
        .report-table td.center { text-align: center; font-weight: 700; }
        .report-table .col-num { width: 120px; text-align: center; }
        .report-table tr.att-total td { font-weight: 800; background: #f5f5f5; }
        .report-table .col-value { width: 260px; text-align: left; font-weight: 700; }

        .rating-scale { border: 1px solid #000; padding: 12px 16px; margin-top: 16px; font-size: 12.5px; }
        .rating-scale .scale-title { font-weight: 800; text-transform: uppercase; font-size: 12px; letter-spacing: 0.4px; margin-bottom: 6px; }
        .rating-scale ul { list-style: none; display: flex; flex-wrap: wrap; gap: 4px 26px; }
        .rating-scale li { padding: 1px 0; }

        .report-comments { border: 1px solid #000; padding: 12px 16px; margin-top: 18px; font-size: 13px; }
        .report-comments .comments-title { font-weight: 800; text-transform: uppercase; font-size: 12px; letter-spacing: 0.4px; margin-bottom: 8px; }
        .report-comments .narrative-row { margin-bottom: 8px; line-height: 1.65; white-space: pre-wrap; }
        .report-comments .narrative-row:last-child { margin-bottom: 0; }
        .report-comments .narrative-label { font-weight: 800; }
        .report-comments .narrative-blank { display: inline-block; min-height: 16px; }

        .signatures { margin-top: 42px; }
        .sig-row { display: flex; justify-content: space-between; gap: 30px; margin-bottom: 26px; }
        .sig-box { width: 31%; text-align: center; font-size: 12.5px; }
        .sig-box .sig-cap { font-weight: 800; text-transform: uppercase; font-size: 11px; letter-spacing: 0.4px; margin-bottom: 4px; }
        .sig-line { border-bottom: 1px solid #000; height: 34px; margin-bottom: 6px; }

        .no-data-banner { background: #FFF6E5; border: 1px solid #F2D48A; color: #7A5A00; border-radius: 10px; padding: 0.75rem 1rem; font-size: 0.85rem; max-width: 840px; margin: 0 auto 1rem; display: flex; align-items: center; gap: 8px; }

        @media (max-width: 991.98px) {
            #stsn-toggle { display: inline-flex; }
            .page-shell, body.sidebar-collapsed .page-shell { margin-left: 0; }
            .page-main { padding: 1rem; }
            .print-card { padding: 20px 22px; }
            .report-head img { height: 64px; }
            .sig-box { width: 100%; }
            .sig-row { flex-direction: column; }
        }

        @media print {
            body * { visibility: hidden; }
            .print-card, .print-card * { visibility: visible; }
            .print-card { position: absolute; left: 0; top: 0; width: 100%; }
            .no-print { display: none !important; }
            @page { size: A4 portrait; margin: 1cm; }
            html, body { height: auto !important; overflow: visible !important; background: #fff !important; }
            .page-shell { margin-left: 0 !important; }
            .print-card { box-shadow: none; max-width: none; }
        }
    </style>
</head>
<body class="stsn-layout">
<button id="stsn-toggle" aria-label="Toggle sidebar"><i class="bi bi-list"></i></button>
<div id="stsn-overlay"></div>

<?php include __DIR__ . '/../includes/teacher-sidebar.php'; ?>

<div class="page-shell">
    <header class="top-bar no-print">
        <div class="top-bar-left">
            <h1><i class="bi bi-clipboard2-pulse-fill" style="color: var(--maroon);"></i> K-3 Progress Report</h1>
            <p>Printable developmental progress report (Kindergarten &ndash; Grade 3), per student.</p>
        </div>
        <div class="top-bar-right">
            <?php if ($printMode): ?>
                <a class="btn btn-secondary" href="K3-Report.php?section_id=<?= (int) $sectionId ?>&amp;term_id=<?= (int) $termId ?>">
                    <i class="bi bi-arrow-left"></i> Back
                </a>
                <button type="button" class="btn btn-primary" onclick="window.print()">
                    <i class="bi bi-printer-fill"></i> Print
                </button>
            <?php else: ?>
                <a class="btn btn-secondary" href="Kinder-Assessment.php">
                    <i class="bi bi-journal-check"></i> Go to Assessment
                </a>
            <?php endif; ?>
        </div>
    </header>

    <main class="page-main">
        <?php if ($printMode && $report !== null): ?>
            <?php if (!$report['hasData']): ?>
                <div class="no-data-banner no-print">
                    <i class="bi bi-exclamation-circle-fill"></i>
                    No data &mdash; no assessment ratings, attendance, observed values, or narrative recorded for this student.
                </div>
            <?php endif; ?>

            <div class="print-card">
                <div class="report-head">
                    <img src="../assets/img/deped.png" alt="Department of Education">
                    <div class="report-head-center">
                        Republic of the Philippines<br>
                        Department of Education<br>
                        Region <span class="region-line">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><br>
                        SCHOOLS DIVISION OF <span class="division-line">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                        <span class="school-name">St. Theresa's School of Novaliches</span>
                        <span class="school-address">Novaliches, Quezon City, Metro Manila</span>
                    </div>
                    <img src="../assets/img/stsn logo.png" alt="St. Theresa's School of Novaliches">
                </div>

                <div class="report-title">
                    <h2><?= htmlspecialchars($report['report_title']) ?></h2>
                    <p>School Year <?= htmlspecialchars($schoolYear) ?> &bull; <?= htmlspecialchars($report['term_label']) ?></p>
                </div>
<table class="report-info">
                    <tr>
                        <td class="lbl">Name</td>
                        <td class="val-wide" colspan="3"><?= htmlspecialchars($report['full_name']) ?></td>
                    </tr>
                    <tr>
                        <td class="lbl">LRN</td>
                        <td><?= $report['lrn'] !== '' ? htmlspecialchars($report['lrn']) : '&mdash;' ?></td>
                        <td class="lbl">Grade Level</td>
                        <td><?= htmlspecialchars($report['grade_level']) ?></td>
                    </tr>
                    <tr>
                        <td class="lbl">Section</td>
                        <td><?= htmlspecialchars($report['section_name']) ?></td>
                        <td class="lbl">Sex</td>
                        <td><?= $report['sex'] !== '' ? htmlspecialchars($report['sex']) : '&mdash;' ?></td>
                    </tr>
                    <tr>
                        <td class="lbl">Age</td>
                        <td><?= $report['age_html'] ?></td>
                        <td class="lbl">School Year</td>
                        <td><?= htmlspecialchars($schoolYear) ?></td>
                    </tr>
                    <tr>
                        <td class="lbl">Teacher</td>
                        <td class="val-wide" colspan="3"><?= htmlspecialchars($teacherName) ?></td>
                    </tr>
                </table>

                <div class="dear-parents">
                    <p class="salut">Dear Parents,</p>
                    <p>This progress report shows the development of your child across the different learning domains. We encourage you to review this with your child and discuss their progress with the teacher.</p>
                </div>

                <div class="section-title">Developmental Domains</div>
                <table class="report-table">
                    <thead>
                        <tr>
                            <th class="col-domain">Domain</th>
                            <th class="col-skill">Skill</th>
                            <th class="col-term">Term 1</th>
                            <th class="col-term">Term 2</th>
                            <th class="col-term">Term 3</th>
                            <th class="col-final">Final</th>
                            <th class="col-remarks">Remarks</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($report['domains']) === 0): ?>
                            <tr>
                                <td colspan="7" class="center">No developmental domains configured.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($report['domains'] as $dom): $skills = $dom['skills']; $dn = count($skills); ?>
                                <?php if ($dn === 0): ?>
                                    <tr>
                                        <td style="background:#f5f5f5;font-weight:800;text-align:left;"><?= htmlspecialchars($dom['domain_name']) ?></td>
                                        <td class="col-skill">&mdash; No skills configured</td>
                                        <td class="center">&mdash;</td>
                                        <td class="center">&mdash;</td>
                                        <td class="center">&mdash;</td>
                                        <td class="center">&mdash;</td>
                                        <td class="center">&mdash;</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($skills as $i => $sk): ?>
                                        <tr>
                                            <?php if ($i === 0): ?>
                                                <td rowspan="<?= (int) $dn ?>" style="background:#f5f5f5;font-weight:800;text-align:left;vertical-align:top;"><?= htmlspecialchars($dom['domain_name']) ?></td>
                                            <?php endif; ?>
                                            <td class="col-skill">&bull; <?= htmlspecialchars($sk['skill_description'] !== '' ? $sk['skill_description'] : $sk['skill_code']) ?></td>
                                            <?php foreach ($termNumbers as $num): $r = $sk['by_term'][$num] ?? null; ?>
                                                <td class="center"><?= ($r !== null && $r !== '') ? htmlspecialchars((string) $r) : '&mdash;' ?></td>
                                            <?php endforeach; ?>
                                            <td class="center"><?= ($sk['final'] !== null && $sk['final'] !== '') ? htmlspecialchars((string) $sk['final']) : '&mdash;' ?></td>
                                            <td class="center"><?= k3RatingRemark($sk['final']) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>

                <div class="rating-scale">
                    <div class="scale-title">Legend &ndash; Developmental Domains</div>
                    <ul>
                        <li><strong>A</strong> &mdash; Always Observed</li>
                        <li><strong>S</strong> &mdash; Sometimes Observed</li>
                        <li><strong>R</strong> &mdash; Rarely Observed</li>
                        <li><strong>N</strong> &mdash; Not Yet Observed</li>
                    </ul>
                </div>
<div class="section-title">Attendance Summary</div>
                <table class="report-table">
                    <thead>
                        <tr>
                            <th class="col-value">Month</th>
                            <th class="col-num">School Days</th>
                            <th class="col-num">Present</th>
                            <th class="col-num">Absent</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($report['attendance']) === 0): ?>
                            <tr>
                                <td colspan="4" class="center">&mdash; No attendance records &mdash;</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($report['attendance'] as $ar): ?>
                                <tr>
                                    <td class="col-value"><?= htmlspecialchars((string) $ar['month_name']) ?></td>
                                    <td class="center"><?= htmlspecialchars(k3Num($ar['school_days'])) ?></td>
                                    <td class="center"><?= htmlspecialchars(k3Num($ar['days_present'])) ?></td>
                                    <td class="center"><?= htmlspecialchars(k3Num($ar['days_absent'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                            <tr class="att-total">
                                <td class="col-value">TOTAL</td>
                                <td class="center"><?= htmlspecialchars(k3Num($report['att_totals']['school_days'])) ?></td>
                                <td class="center"><?= htmlspecialchars(k3Num($report['att_totals']['days_present'])) ?></td>
                                <td class="center"><?= htmlspecialchars(k3Num($report['att_totals']['days_absent'])) ?></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <div class="section-title">Learner's Observed Values</div>
                <table class="report-table">
                    <thead>
                        <tr>
                            <th class="col-value">Core Value</th>
                            <th class="col-term">Term 1</th>
                            <th class="col-term">Term 2</th>
                            <th class="col-term">Term 3</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($report['observed_values'] as $ov): ?>
                            <tr>
                                <td class="col-value"><?= htmlspecialchars((string) $ov['core_value']) ?></td>
                                <?php foreach ($termNumbers as $num): $v = $ov['terms'][$num] ?? null; ?>
                                    <td class="center"><?= ($v !== null && $v !== '') ? htmlspecialchars((string) $v) : '&mdash;' ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <div class="rating-scale">
                    <div class="scale-title">Legend &ndash; Observed Values</div>
                    <ul>
                        <li><strong>AO</strong> &mdash; Always Observed</li>
                        <li><strong>SO</strong> &mdash; Sometimes Observed</li>
                        <li><strong>RO</strong> &mdash; Rarely Observed</li>
                        <li><strong>NO</strong> &mdash; Not Yet Observed</li>
                    </ul>
                </div>
<div class="section-title">Teacher's Narrative</div>
                <div class="report-comments">
                    <div class="comments-title">Per-Term Narrative</div>
                    <?php foreach ($termNumbers as $num): $txt = $report['narratives'][$num] ?? ''; ?>
                        <div class="narrative-row">
                            <span class="narrative-label">Term <?= (int) $num ?>:</span>
                            <?php if ($txt !== ''): ?> <?= htmlspecialchars($txt) ?><?php else: ?><span class="narrative-blank">&nbsp;</span><?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="signatures">
                    <div class="sig-row">
                        <div class="sig-box">
                            <div class="sig-line"></div>
                            <div class="sig-cap">Teacher</div>
                            <?= htmlspecialchars($teacherName) ?>
                        </div>
                        <div class="sig-box">
                            <div class="sig-line"></div>
                            <div class="sig-cap">Parent / Guardian</div>
                        </div>
                        <div class="sig-box">
                            <div class="sig-line"></div>
                            <div class="sig-cap">School Head</div>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
<div class="report-form-card no-print">
                <h2><i class="bi bi-printer-fill" style="color: var(--maroon);"></i> Generate Progress Report</h2>
                <p class="form-sub">Select a section, term, and student to open the printable report card.</p>

                <?php if ($reportError !== ''): ?>
                    <div class="form-error">
                        <i class="bi bi-exclamation-circle-fill"></i> <?= htmlspecialchars($reportError) ?>
                    </div>
                <?php endif; ?>

                <?php if (count($teacherSections) === 0): ?>
                    <div class="form-empty">
                        <i class="bi bi-info-circle"></i>
                        You are not assigned to any Kindergarten &ndash; Grade 3 section.
                    </div>
                <?php else: ?>
                    <form method="get" action="K3-Report.php">
                        <div class="form-field">
                            <label for="sectionSelect">Section</label>
                            <select name="section_id" id="sectionSelect" onchange="reloadStudents()">
                                <?php foreach ($teacherSections as $sec): ?>
                                    <option value="<?= (int) $sec['id'] ?>" <?= $sectionId === (int) $sec['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars(trim(($sec['grade_level_name'] ?? '') . ' - ' . ($sec['section_name'] ?? ''), ' -')) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-field">
                            <label for="termSelect">Term</label>
                            <select name="term_id" id="termSelect" onchange="reloadStudents()">
                                <?php foreach ($terms as $t): ?>
                                    <option value="<?= (int) $t['id'] ?>" <?= $termId === (int) $t['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($t['term_label']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-field">
                            <label for="studentSelect">Student</label>
                            <select name="student_id" id="studentSelect">
                                <?php if (count($formStudents) === 0): ?>
                                    <option value="">&mdash; No students enrolled &mdash;</option>
                                <?php else: ?>
                                    <option value="">&mdash; Select Student &mdash;</option>
                                    <?php foreach ($formStudents as $fs): $fmid = trim((string) ($fs['mname'] ?? '')); $finit = $fmid !== '' ? strtoupper(substr($fmid, 0, 1)) . '.' : ''; ?>
                                        <option value="<?= (int) $fs['id'] ?>">
                                            <?= htmlspecialchars(trim(($fs['lname'] ?? '') . ', ' . ($fs['fname'] ?? '') . ' ' . $finit)) ?>
                                        </option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary" <?= count($formStudents) === 0 ? 'disabled' : '' ?>>
                                <i class="bi bi-file-earmark-text"></i> Generate Report
                            </button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </main>
</div>
<script>
    const sidebar = document.getElementById('stsn-sidebar');
    const toggleBtn = document.getElementById('stsn-toggle');
    const overlay = document.getElementById('stsn-overlay');
    const collapseBtn = document.getElementById('stsn-collapse-btn');

    const savedState = localStorage.getItem('stsn-sidebar-collapsed');
    if (sidebar && savedState === 'true' && window.innerWidth >= 992) {
        sidebar.classList.add('collapsed');
        document.body.classList.add('sidebar-collapsed');
    }

    if (collapseBtn && sidebar) {
        collapseBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            sidebar.classList.toggle('collapsed');
            const isCollapsed = sidebar.classList.contains('collapsed');
            document.body.classList.toggle('sidebar-collapsed', isCollapsed);
            localStorage.setItem('stsn-sidebar-collapsed', isCollapsed);
        });
    }

    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', function () {
            sidebar.classList.toggle('mobile-open');
            overlay.classList.toggle('visible');
        });
    }

    if (overlay && sidebar) {
        overlay.addEventListener('click', function () {
            sidebar.classList.remove('mobile-open');
            overlay.classList.remove('visible');
        });
    }

    window.addEventListener('resize', function () {
        if (!sidebar) return;
        if (window.innerWidth >= 992) {
            sidebar.classList.remove('mobile-open');
            overlay.classList.remove('visible');
        } else {
            document.body.classList.remove('sidebar-collapsed');
        }
    });

    /* Reload the form with the chosen section + term so the student list matches */
    function reloadStudents() {
        const sec = document.getElementById('sectionSelect').value;
        const term = document.getElementById('termSelect').value;
        window.location.href = 'K3-Report.php?section_id=' + encodeURIComponent(sec)
            + '&term_id=' + encodeURIComponent(term);
    }
</script>
</body>
</html>