<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$teacherName = $_SESSION['teacher_name'] ?? 'Teacher';
$sectionId = $_GET['section_id'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Class List | STSN Grading System</title>

    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css/index.css">

    <style>
        :root {
            --primary: #0A2F44;
            --primary-soft: rgba(10, 47, 68, 0.08);
            --accent: #C5A028;
            --bg: #F5F7FA;
            --surface: #FFFFFF;
            --surface-2: #F8F9FA;
            --text: #1E2A3E;
            --muted: #6C757D;
            --border: #E9ECEF;
            --success: #198754;
            --shadow: 0 10px 30px rgba(10, 47, 68, 0.08);
            --radius: 18px;
            --sidebar-width: 264px;
            --sidebar-collapsed-width: 72px;
        }

        * { box-sizing: border-box; }

        body.stsn-layout {
            margin: 0;
            font-family: "Plus Jakarta Sans", sans-serif;
            background: var(--bg);
            color: var(--text);
        }

        #stsn-toggle {
            position: fixed;
            top: 1rem;
            left: 1rem;
            z-index: 1100;
            width: 44px;
            height: 44px;
            border: 1px solid var(--border);
            border-radius: 12px;
            background: #fff;
            color: var(--primary);
            display: none;
            align-items: center;
            justify-content: center;
            box-shadow: var(--shadow);
            cursor: pointer;
        }

        #stsn-toggle i { font-size: 1.3rem; }

        #stsn-overlay {
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.35);
            opacity: 0;
            visibility: hidden;
            transition: 0.25s ease;
            z-index: 1035;
        }

        #stsn-overlay.visible {
            opacity: 1;
            visibility: visible;
        }

        .page-shell {
            margin-left: var(--sidebar-width);
            min-height: 100vh;
            transition: margin-left 0.28s ease;
        }

        body.sidebar-collapsed .page-shell {
            margin-left: var(--sidebar-collapsed-width);
        }

        .page-main {
            padding: 1.5rem 2rem 2rem;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 1rem;
            flex-wrap: wrap;
            margin-bottom: 1.25rem;
        }

        .page-title h1 {
            margin: 0;
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--primary);
        }

        .page-title p {
            margin: 0.4rem 0 0;
            color: var(--muted);
            font-size: 0.94rem;
        }

        .header-meta {
            display: flex;
            gap: 0.7rem;
            flex-wrap: wrap;
        }

        .meta-chip {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 999px;
            padding: 0.6rem 0.9rem;
            font-size: 0.82rem;
            color: var(--muted);
            white-space: nowrap;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            color: var(--muted);
            text-decoration: none;
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
        }

        .back-link:hover {
            color: var(--primary);
        }

        .toolbar {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 1rem;
            display: flex;
            gap: 0.75rem;
            align-items: center;
            margin-bottom: 1rem;
            flex-wrap: wrap;
        }

        .toolbar input,
        .toolbar select {
            border: 1px solid var(--border);
            background: #fff;
            border-radius: 12px;
            padding: 0.8rem 0.9rem;
            font-family: inherit;
            font-size: 0.9rem;
            color: var(--text);
            min-width: 200px;
        }

        .toolbar-actions {
            display: flex;
            gap: 0.65rem;
            flex-wrap: wrap;
            margin-left: auto;
        }

        .action-btn {
            border: 1px solid var(--border);
            background: #fff;
            color: var(--text);
            border-radius: 12px;
            padding: 0.78rem 0.95rem;
            cursor: pointer;
            font-family: inherit;
            font-weight: 600;
            font-size: 0.87rem;
            transition: 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
        }

        .action-btn:hover {
            background: var(--surface-2);
            transform: translateY(-1px);
        }

        .content-grid {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 360px;
            gap: 1rem;
        }

        .panel {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
        }

        .panel-header {
            padding: 1rem 1rem 0.9rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .panel-title {
            margin: 0;
            display: flex;
            align-items: center;
            gap: 0.55rem;
            font-size: 1rem;
            font-weight: 700;
            color: var(--primary);
        }

        .panel-title i { color: var(--accent); }

        .panel-sub {
            font-size: 0.82rem;
            color: var(--muted);
            margin-top: 0.2rem;
        }

        .table-wrap {
            overflow-x: auto;
            padding: 0 1rem 1rem;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th {
            text-align: left;
            font-size: 0.77rem;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            color: var(--muted);
            padding: 0.95rem 0.75rem;
            border-bottom: 1px solid var(--border);
            background: var(--surface-2);
        }

        .data-table td {
            padding: 0.85rem 0.75rem;
            border-bottom: 1px solid #f0f2f5;
            font-size: 0.9rem;
            vertical-align: middle;
        }

        .data-table tr:hover td {
            background: var(--surface-2);
        }

        .data-table tr:last-child td {
            border-bottom: none;
        }

        .td-center { text-align: center; }

        .student-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .student-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: var(--primary-soft);
            color: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.85rem;
        }

        .student-name {
            font-weight: 600;
            color: var(--text);
        }

        .student-no {
            font-size: 0.8rem;
            color: var(--muted);
        }

        .pill {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 999px;
            padding: 0.35rem 0.65rem;
            font-size: 0.74rem;
            font-weight: 700;
            white-space: nowrap;
        }

        .pill-success {
            background: rgba(25, 135, 84, 0.12);
            color: var(--success);
        }

        .side-stack {
            display: grid;
            gap: 1rem;
        }

        .side-panel {
            padding: 1rem;
        }

        .info-list {
            display: grid;
            gap: 0.75rem;
        }

        .info-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.75rem;
            background: var(--surface-2);
            border-radius: 12px;
        }

        .info-label {
            font-size: 0.82rem;
            color: var(--muted);
        }

        .info-value {
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--text);
        }

        .empty-state,
        .loading-state {
            padding: 2rem;
            text-align: center;
            color: var(--muted);
            font-size: 0.92rem;
        }

        @media (max-width: 1199px) {
            .content-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 991.98px) {
            #stsn-toggle { display: inline-flex; }
            .page-shell,
            body.sidebar-collapsed .page-shell { margin-left: 0; }
            .page-main { padding: 5rem 1rem 1.5rem; }
            .toolbar { flex-direction: column; align-items: stretch; }
            .toolbar-actions { margin-left: 0; }
        }

        @media (max-width: 767px) {
            .page-header { flex-direction: column; align-items: flex-start; }
            .page-title h1 { font-size: 1.45rem; }
        }
    </style>
</head>
<body class="stsn-layout">
    <button id="stsn-toggle" aria-label="Toggle sidebar">
        <i class="bi bi-list"></i>
    </button>

    <div id="stsn-overlay"></div>

    <?php include __DIR__ . '/../includes/teacher-sidebar.php'; ?>

    <div class="page-shell">
        <main class="page-main">
            <a href="My-Sections.php" class="back-link">
                <i class="bi bi-arrow-left"></i> Back to Sections
            </a>

            <div class="page-header">
                <div class="page-title">
                    <h1>Class List</h1>
                    <p>View students enrolled in this section.</p>
                </div>

                <div class="header-meta">
                    <div class="meta-chip"><i class="bi bi-person-badge"></i> <?php echo htmlspecialchars($teacherName); ?></div>
                    <div class="meta-chip"><i class="bi bi-people"></i> Students</div>
                </div>
            </div>

            <section class="toolbar">
                <input type="text" id="searchInput" placeholder="Search students...">
                <select id="genderFilter">
                    <option value="">All Genders</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
                <div class="toolbar-actions">
                    <button class="action-btn" type="button" onclick="loadStudents()">
                        <i class="bi bi-arrow-clockwise"></i> Refresh
                    </button>
                </div>
            </section>

            <section class="content-grid">
                <div class="panel">
                    <div class="panel-header">
                        <div>
                            <h2 class="panel-title"><i class="bi bi-people"></i> Enrolled Students</h2>
                            <div class="panel-sub">List of students in this section.</div>
                        </div>
                    </div>

                    <div class="table-wrap">
                        <div id="loadingState" class="loading-state">Loading students...</div>

                        <table class="data-table" id="studentTable" style="display:none;">
                            <thead>
                                <tr>
                                    <th>Student</th>
                                    <th>LRN</th>
                                    <th>Gender</th>
                                    <th>Contact</th>
                                    <th class="td-center">Status</th>
                                </tr>
                            </thead>
                            <tbody id="studentTableBody"></tbody>
                        </table>

                        <div id="emptyState" class="empty-state" style="display:none;">
                            No students found.
                        </div>
                    </div>
                </div>

                <div class="side-stack">
                    <div class="panel side-panel">
                        <h3 class="panel-title"><i class="bi bi-info-circle"></i> Section Info</h3>
                        <div class="info-list" id="sectionInfo">
                            <div class="info-item">
                                <span class="info-label">Section</span>
                                <span class="info-value" id="infoSection">Loading...</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total Students</span>
                                <span class="info-value" id="infoCount">0</span>
                            </div>
                        </div>
                    </div>

                    <div class="panel side-panel">
                        <h3 class="panel-title"><i class="bi bi-lightning-charge-fill"></i> Gender Distribution</h3>
                        <div class="info-list" id="genderStats">
                            <div class="info-item">
                                <span class="info-label">Male</span>
                                <span class="info-value" id="maleCount">0</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Female</span>
                                <span class="info-value" id="femaleCount">0</span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <script>
        const sectionId = '<?php echo htmlspecialchars($sectionId); ?>';
        
        const sidebar = document.getElementById('stsn-sidebar');
        const toggleBtn = document.getElementById('stsn-toggle');
        const overlay = document.getElementById('stsn-overlay');
        const collapseBtn = document.getElementById('stsn-collapse-btn');

        const savedState = localStorage.getItem('stsn-sidebar-collapsed');

        if (sidebar && savedState === 'true' && window.innerWidth >= 992) {
            sidebar.classList.add('collapsed');
            document.body.classList.add('sidebar-collapsed');
        }

        if (collapseBtn && sidebar) {
            collapseBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                sidebar.classList.toggle('collapsed');
                const isCollapsed = sidebar.classList.contains('collapsed');
                document.body.classList.toggle('sidebar-collapsed', isCollapsed);
                localStorage.setItem('stsn-sidebar-collapsed', isCollapsed);
            });
        }

        if (toggleBtn && sidebar) {
            toggleBtn.addEventListener('click', function () {
                sidebar.classList.toggle('mobile-open');
                overlay.classList.toggle('visible');
            });
        }

        if (overlay && sidebar) {
            overlay.addEventListener('click', function () {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('visible');
            });
        }

        window.addEventListener('resize', function () {
            if (!sidebar) return;
            if (window.innerWidth >= 992) {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('visible');
            } else {
                document.body.classList.remove('sidebar-collapsed');
            }
        });

        const table = document.getElementById('studentTable');
        const tbody = document.getElementById('studentTableBody');
        const loadingState = document.getElementById('loadingState');
        const emptyState = document.getElementById('emptyState');
        const searchInput = document.getElementById('searchInput');
        const genderFilter = document.getElementById('genderFilter');

        let allStudents = [];

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text ?? '';
            return div.innerHTML;
        }

        function getInitials(name) {
            if (!name) return '?';
            return name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
        }

        async function loadStudents() {
            loadingState.style.display = 'block';
            table.style.display = 'none';
            emptyState.style.display = 'none';
            tbody.innerHTML = '';

            try {
                const response = await fetch(`../api/student-handled/get_students.php?section_id=${encodeURIComponent(sectionId)}`);
                const result = await response.json();

                if (!result.success) {
                    throw new Error(result.message || 'Failed to load students');
                }

                allStudents = result.data || [];
                updateSectionInfo(result.section);
                renderTable();
                updateGenderStats();
            } catch (error) {
                loadingState.style.display = 'none';
                emptyState.style.display = 'block';
                emptyState.textContent = 'Failed to load students. ' + error.message;
            }
        }

        function updateSectionInfo(section) {
            document.getElementById('infoSection').textContent = section?.section_name || 'N/A';
            document.getElementById('infoCount').textContent = allStudents.length;
        }

        function updateGenderStats() {
            const male = allStudents.filter(s => s.gender === 'Male').length;
            const female = allStudents.filter(s => s.gender === 'Female').length;
            document.getElementById('maleCount').textContent = male;
            document.getElementById('femaleCount').textContent = female;
        }

        function getFilteredStudents() {
            const search = searchInput.value.trim().toLowerCase();
            const gender = genderFilter.value;

            return allStudents.filter(student => {
                const matchesSearch = !search || 
                    (student.student_name || '').toLowerCase().includes(search) ||
                    (student.student_no || '').toLowerCase().includes(search);
                const matchesGender = !gender || student.gender === gender;
                return matchesSearch && matchesGender;
            });
        }

        function renderTable() {
            const students = getFilteredStudents();

            loadingState.style.display = 'none';

            if (!students.length) {
                table.style.display = 'none';
                emptyState.style.display = 'block';
                return;
            }

            emptyState.style.display = 'none';
            table.style.display = 'table';

            tbody.innerHTML = students.map(student => `
                <tr>
                    <td>
                        <div class="student-info">
                            <div class="student-avatar">${getInitials(student.student_name)}</div>
                            <div>
                                <div class="student-name">${escapeHtml(student.student_name)}</div>
                            </div>
                        </div>
                    </td>
                    <td>${escapeHtml(student.student_no || '-')}</td>
                    <td>${escapeHtml(student.gender || '-')}</td>
                    <td>${escapeHtml(student.contact_no || '-')}</td>
                    <td class="td-center">
                        <span class="pill ${student.is_active ? 'pill-success' : ''}">
                            ${student.is_active ? 'Active' : 'Inactive'}
                        </span>
                    </td>
                </tr>
            `).join('');
        }

        searchInput.addEventListener('input', renderTable);
        genderFilter.addEventListener('change', renderTable);

        loadStudents();
    </script>
</body>
</html>