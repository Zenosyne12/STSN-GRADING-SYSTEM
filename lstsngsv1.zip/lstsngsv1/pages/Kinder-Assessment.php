<?php
require_once __DIR__ . '/../api/login/teacher_auth.php';

// Server-side guard: K-3 assignment required (blocks direct URL access).
requireK3();

$teacherName = $_SESSION['teacher_name'] ?? 'Teacher';
$teacherId   = (int) ($_SESSION['teacher_id'] ?? 0);

/* Active academic year */
$activeYear = $pdo->query("
    SELECT id, year_label
    FROM tblacademicyear
    WHERE is_active = 1
    LIMIT 1
")->fetch(PDO::FETCH_ASSOC) ?: null;

$activeYearId = $activeYear ? (int) $activeYear['id'] : 0;
$schoolYear   = $activeYear['year_label'] ?? date('Y') . '-' . (date('Y') + 1);

/* Terms (trimester/quarter config for the active year) */
$terms = [];
try {
    $termStmt = $pdo->prepare("
        SELECT id, term_number, term_label, term_type, is_active, is_closed
        FROM tblconfig_terms
        WHERE academic_year_id = ?
        ORDER BY term_number ASC
    ");
    $termStmt->execute([$activeYearId]);
    $terms = $termStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
    $terms = [];
}

/* Teacher's Kindergarten sections (adviser, grade_level_code = 0) */
$kinderSections = [];
if ($teacherId > 0) {
    $secStmt = $pdo->prepare("
        SELECT s.id, s.section_name, gl.grade_level_name, gl.grade_level_code
        FROM tblsection s
        JOIN tblgradelevel gl ON gl.id = s.grade_level_id
        JOIN tblsectionadviser sa ON sa.section_id = s.id
        WHERE sa.teacher_id = ?
          AND gl.grade_level_code = 0
        ORDER BY gl.sort_order ASC, s.section_name ASC
    ");
    $secStmt->execute([$teacherId]);
    $kinderSections = $secStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

/* URL params */
$sectionId = isset($_GET['section_id']) ? (int) $_GET['section_id'] : 0;
$termId    = isset($_GET['term_id']) ? (int) $_GET['term_id'] : 0;

/* Defaults: first kinder section + active term */
if ($sectionId <= 0) {
    $sectionId = (int) ($kinderSections[0]['id'] ?? 0);
}
if ($termId <= 0) {
    foreach ($terms as $t) {
        if ((int) $t['is_active'] === 1) {
            $termId = (int) $t['id'];
            break;
        }
    }
    if ($termId <= 0 && $terms) {
        $termId = (int) $terms[0]['id'];
    }
}

$selectedSection = null;
foreach ($kinderSections as $sec) {
    if ((int) $sec['id'] === $sectionId) {
        $selectedSection = $sec;
        break;
    }
}
/* Only allow the teacher's own kinder sections */
if ($selectedSection === null) {
    $sectionId = 0;
}

$selectedTerm = null;
foreach ($terms as $t) {
    if ((int) $t['id'] === $termId) {
        $selectedTerm = $t;
        break;
    }
}
$termNumber   = $selectedTerm ? (int) $selectedTerm['term_number'] : 1;
$termLabel    = $selectedTerm['term_label'] ?? '1st Term';
$isTermLocked = $selectedTerm ? ((int) $selectedTerm['is_closed'] === 1) : false;

/* Archive-engine lock check (guarded, mirrors Grading-Sheet.php) */
if ($sectionId > 0 && $termId > 0 && !$isTermLocked) {
    try {
        require_once __DIR__ . '/../includes/archive_engine.php';
        if (function_exists('isTermLocked')) {
            $isTermLocked = isTermLocked($pdo, $sectionId, 0, $termNumber) || $isTermLocked;
        }
    } catch (Throwable $e) {}
}

$isSelectionValid = ($sectionId > 0 && $termId > 0 && $activeYearId > 0);

/* Checklist data (students, domains/skills, saved data) */
$students = [];
$existingRatings    = [];   // [student_id][skill_id] => rating
$existingNarratives = [];   // [student_id] => narrative
$groupedDomains     = [];

if ($isSelectionValid) {
    /* Students enrolled in the section */
    $studentStmt = $pdo->prepare("
        SELECT st.id, st.lrn, st.fname, st.mname, st.lname, st.gender
        FROM tblsectionstudent ss
        INNER JOIN tblstudents st ON st.id = ss.student_id
        WHERE ss.section_id = ?
          AND ss.academic_year_id = ?
          AND ss.is_active = 1
          AND COALESCE(st.is_active, 1) = 1
        ORDER BY st.lname ASC, st.fname ASC, st.mname ASC
    ");
    $studentStmt->execute([$sectionId, $activeYearId]);
    $students = $studentStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

    /* Domains + active skills */
    $domainRows = $pdo->query("
        SELECT d.id AS domain_id, d.domain_code, d.domain_name,
               sk.id AS skill_id, sk.skill_code
        FROM tblkinder_domains d
        LEFT JOIN tblkinder_skills sk ON sk.domain_id = d.id AND sk.is_active = 1
        WHERE d.is_active = 1
        ORDER BY d.sort_order ASC, d.domain_code ASC, sk.sort_order ASC, sk.skill_code ASC
    ")->fetchAll(PDO::FETCH_ASSOC) ?: [];

    foreach ($domainRows as $row) {
        $domId = (int) $row['domain_id'];
        if (!isset($groupedDomains[$domId])) {
            $groupedDomains[$domId] = [
                'domain_id'   => $domId,
                'domain_code' => $row['domain_code'],
                'domain_name' => $row['domain_name'],
                'skills'      => [],
            ];
        }
        if ($row['skill_id'] !== null) {
            $groupedDomains[$domId]['skills'][] = [
                'skill_id'   => (int) $row['skill_id'],
                'skill_code' => $row['skill_code'],
            ];
        }
    }
    $groupedDomains = array_values($groupedDomains);

    /* Existing assessments for this section + term */
    $ratingStmt = $pdo->prepare("
        SELECT student_id, skill_id, rating
        FROM tblkinder_assessments
        WHERE section_id = ? AND term_id = ?
    ");
    $ratingStmt->execute([$sectionId, $termId]);
    foreach ($ratingStmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $r) {
        $existingRatings[(int) $r['student_id']][(int) $r['skill_id']] = (string) $r['rating'];
    }

    /* Existing narratives for this section + term */
    $narrStmt = $pdo->prepare("
        SELECT student_id, narrative
        FROM tblkinder_narratives
        WHERE section_id = ? AND term_id = ?
    ");
    $narrStmt->execute([$sectionId, $termId]);
    foreach ($narrStmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $n) {
        $existingNarratives[(int) $n['student_id']] = (string) $n['narrative'];
    }
}

$sectionDisplayName = $selectedSection
    ? trim(($selectedSection['grade_level_name'] ?? '') . ' - ' . ($selectedSection['section_name'] ?? ''), ' -')
    : '';
$subtitle = $isSelectionValid
    ? "$sectionDisplayName - $termLabel"
    : 'Select a section and term to load the checklist';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kindergarten Assessment<?= $sectionDisplayName ? ' - ' . htmlspecialchars($sectionDisplayName) : '' ?> | STSN</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/system-alerts.css">
    <style>
        :root {
            --primary: #0A2F44; --primary-soft: rgba(10,47,68,0.08); --accent: #C5A028;
            --bg: #F5F7FA; --surface: #FFFFFF; --surface-2: #F8F9FA;
            --text: #1E2A3E; --muted: #6C757D; --border: #E9ECEF;
            --shadow: 0 10px 30px rgba(10,47,68,0.08); --radius: 18px;
            --sidebar-width: 260px; --sidebar-collapsed-width: 72px;
            --ww-bg: #EBF4FF; --ww-text: #185FA5; --ww-border: #B8D8F8;
            --pt-bg: #F4EEFF; --pt-text: #534AB7; --pt-border: #D4C8F8;
            --qa-bg: #EAFAF3; --qa-text: #0F6E56; --qa-border: #A8E6D1;
            --gr-bg: #FFF8E1; --gr-text: #855E00; --gr-border: #F5D87A;
        }
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html, body { height: 100%; }
        body.stsn-layout { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); color: var(--text); overflow: hidden; }

        #stsn-toggle { position: fixed; top: 1rem; left: 1rem; z-index: 1100; width: 44px; height: 44px; border: 1px solid var(--border); border-radius: 12px; background: #fff; color: var(--primary); display: none; align-items: center; justify-content: center; box-shadow: var(--shadow); cursor: pointer; }
        #stsn-overlay { position: fixed; inset: 0; background: rgba(15,23,42,0.35); opacity: 0; visibility: hidden; transition: 0.25s ease; z-index: 1035; }
        #stsn-overlay.visible { opacity: 1; visibility: visible; }
        .page-shell { margin-left: var(--sidebar-width); height: 100vh; transition: margin-left 0.28s ease; display: flex; flex-direction: column; overflow: hidden; }
        body.sidebar-collapsed .page-shell { margin-left: var(--sidebar-collapsed-width); }

        .top-bar { background: var(--surface); border-bottom: 1px solid var(--border); padding: 0.85rem 1.5rem; display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap; flex-shrink: 0; position: sticky; top: 0; z-index: 50; }
        .top-bar-left h1 { font-size: 1.25rem; font-weight: 800; color: var(--primary); display: flex; align-items: center; gap: 0.5rem; }
        .top-bar-left p { font-size: 0.82rem; color: var(--muted); margin-top: 3px; }
        .top-bar-right { display: flex; gap: 0.55rem; align-items: center; flex-wrap: wrap; }
        .meta-chip { background: #fff; border: 1px solid var(--border); border-radius: 999px; padding: 0.45rem 0.8rem; font-size: 0.78rem; color: var(--muted); display: inline-flex; align-items: center; gap: 5px; white-space: nowrap; }
        .meta-chip.danger { background: #fee2e2; border-color: #fecaca; color: #b91c1c; }

        .btn { display: inline-flex; align-items: center; gap: 6px; padding: 0.6rem 1.1rem; border-radius: 12px; font-family: inherit; font-size: 0.85rem; font-weight: 700; cursor: pointer; border: 1px solid var(--border); transition: background 0.18s, border-color 0.18s, transform 0.1s; }
        .btn:active:not(:disabled) { transform: scale(0.97); }
        .btn-primary { background: var(--primary); color: #fff; border-color: var(--primary); }
        .btn-primary:hover:not(:disabled) { background: #0d3b56; border-color: #0d3b56; }
        .btn-secondary { background: #fff; color: var(--primary); }
        .btn-secondary:hover { background: var(--surface-2); }
        .btn-success { background: #0F6E56; color: #fff; border-color: #0F6E56; }
        .btn-success:hover:not(:disabled) { background: #0d5c48; }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; }

        .toolbar { background: var(--surface); border-bottom: 1px solid var(--border); padding: 0.75rem 1.5rem; display: flex; gap: 0.65rem; align-items: center; flex-wrap: wrap; flex-shrink: 0; }
        .toolbar-group { display: flex; align-items: center; gap: 6px; }
        .toolbar-label { font-size: 0.78rem; font-weight: 700; color: var(--muted); white-space: nowrap; }
        .toolbar select { border: 1px solid var(--border); background: #fff; border-radius: 12px; padding: 0.6rem 0.85rem; font-family: inherit; font-size: 0.85rem; color: var(--text); transition: border-color 0.18s; }
        .toolbar select:focus { outline: none; border-color: var(--primary); }

        .page-main { flex: 1; min-height: 0; padding: 1.25rem 1.5rem 1.5rem; display: flex; flex-direction: column; gap: 1rem; overflow: hidden; }

        .status-banner { border: 1px solid #fde68a; background: #fff8e1; color: #92400e; border-radius: 14px; padding: .85rem 1rem; display: flex; align-items: flex-start; gap: .65rem; font-size: .86rem; line-height: 1.45; flex-shrink: 0; }
        .status-banner.success { border-color: #a7f3d0; background: #ecfdf5; color: #065f46; }
        .status-banner.danger { border-color: #fecaca; background: #fee2e2; color: #991b1b; }

        .panel { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); box-shadow: var(--shadow); }
        .main-panel { overflow: hidden; display: flex; flex-direction: column; min-height: 0; }
        .action-bar { background: linear-gradient(135deg, var(--ww-bg) 0%, #FFFFFF 65%); border-bottom: 1px solid var(--border); padding: 0.85rem 1.25rem; display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap; flex-shrink: 0; }
        .action-bar-left { display: flex; align-items: center; gap: 0.65rem; flex-wrap: wrap; }
        .action-bar-right { display: flex; align-items: center; gap: 0.55rem; flex-wrap: wrap; }
        .panel-title { display: flex; align-items: center; gap: 0.5rem; font-size: 1rem; font-weight: 700; color: var(--primary); }
        .panel-title i { color: var(--accent); font-size: 15px; }
        .panel-sub { font-size: 0.8rem; color: var(--muted); margin-top: 0.2rem; }
        .pill { display: inline-flex; align-items: center; gap: 4px; padding: 0.35rem 0.65rem; border-radius: 999px; font-size: 0.75rem; font-weight: 700; }
        .pill-neu { background: var(--surface-2); color: var(--muted); }

        .table-wrap { flex: 1; min-height: 0; overflow: auto; }
        .grading-table { width: 100%; border-collapse: collapse; font-size: 13px; }
        .grading-table thead th { position: sticky; top: 0; z-index: 3; border: 1px solid var(--border); padding: 0.65rem 0.5rem; font-family: inherit; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; text-align: center; }
        .grading-table thead tr:nth-child(2) th { top: 34px; }
        .th-def { background: var(--surface-2); color: var(--muted); }
        .th-dom-1 { background: var(--ww-bg); color: var(--ww-text); border-bottom: 2px solid var(--ww-border); }
        .th-dom-2 { background: var(--pt-bg); color: var(--pt-text); border-bottom: 2px solid var(--pt-border); }
        .th-dom-3 { background: var(--qa-bg); color: var(--qa-text); border-bottom: 2px solid var(--qa-border); }
        .th-dom-4 { background: var(--gr-bg); color: var(--gr-text); border-bottom: 2px solid var(--gr-border); }
        .th-dom-5 { background: var(--ww-bg); color: var(--ww-text); border-bottom: 2px solid var(--ww-border); }
        .th-skill { font-size: 10px; letter-spacing: 0.02em; white-space: nowrap; }
        .grading-table tbody td { border: 1px solid #f0f2f5; padding: 0.6rem 0.5rem; text-align: center; vertical-align: middle; }
        .grading-table tbody tr:hover td { background: #fafbff; }
        .col-num { width: 44px; background: var(--surface-2); font-weight: 700; color: var(--muted); font-size: 12px; }
        .col-name { text-align: left !important; padding-left: 1rem !important; min-width: 200px; background: var(--surface-2); white-space: nowrap; }
        .student-name { font-weight: 700; color: var(--text); font-size: 13px; }
        .student-sub { display: block; font-size: 11px; color: var(--muted); margin-top: 2px; }
        .col-narrative { min-width: 120px; background: var(--surface-2); }

        .kinder-rating { padding: 5px 6px; border: 1.5px solid var(--border); border-radius: 8px; font-family: inherit; font-size: .8rem; background: #fff; min-width: 118px; text-align: center; color: var(--text); transition: border-color 0.15s, box-shadow 0.15s; }
        .kinder-rating:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(10,47,68,0.08); }
        .kinder-rating:disabled { background: var(--surface-2); color: var(--muted); cursor: not-allowed; }
        .kinder-rating.sel-A { border-color: var(--qa-text); background: var(--qa-bg); color: var(--qa-text); font-weight: 700; }
        .kinder-rating.sel-S { border-color: var(--ww-text); background: var(--ww-bg); color: var(--ww-text); font-weight: 700; }
        .kinder-rating.sel-R { border-color: var(--gr-text); background: var(--gr-bg); color: var(--gr-text); font-weight: 700; }
        .kinder-rating.sel-N { border-color: #A32D2D; background: #FFF5F5; color: #A32D2D; font-weight: 700; }

        .narrative-btn { display: inline-flex; align-items: center; gap: 5px; padding: 0.4rem 0.75rem; border-radius: 10px; border: 1.5px solid var(--border); background: #fff; color: var(--primary); font-family: inherit; font-size: 0.75rem; font-weight: 700; cursor: pointer; transition: background 0.15s, border-color 0.15s; white-space: nowrap; }
        .narrative-btn:hover { background: var(--primary-soft); border-color: var(--primary); }
        .narrative-btn.has-narrative { background: var(--qa-bg); border-color: var(--qa-border); color: var(--qa-text); }
        .narrative-btn:disabled { opacity: 0.5; cursor: not-allowed; }

        /* Print Progress Report (Kinder-Report.php) */
        .btn.btn-sm.btn-outline-primary { display: inline-flex; align-items: center; gap: 5px; padding: 0.4rem 0.75rem; border-radius: 999px; border: 1px solid #8B1A1A; background: #fff; color: #8B1A1A; font-size: 0.78rem; font-weight: 700; text-decoration: none; margin-bottom: 4px; }
        .btn.btn-sm.btn-outline-primary:hover { background: #8B1A1A; color: #fff; }

        .empty-state { padding: 3rem 1rem; text-align: center; color: var(--muted); font-size: 0.9rem; }
        .empty-state i { font-size: 2.2rem; display: block; margin-bottom: 0.75rem; color: #C8CFD8; }

        .toast { position: fixed; bottom: 1.25rem; right: 1.25rem; z-index: 9999; background: var(--primary); color: #fff; padding: 0.85rem 1.25rem; border-radius: 14px; display: flex; align-items: center; gap: 8px; font-size: 0.88rem; font-weight: 600; opacity: 0; transform: translateY(12px); transition: opacity 0.28s, transform 0.28s; pointer-events: none; max-width: 380px; }
        .toast.show { opacity: 1; transform: translateY(0); pointer-events: auto; }
        .toast.error { background: #A32D2D; }
        .toast.success { background: #0F6E56; }
        .spinner { width: 15px; height: 15px; border: 2px solid rgba(255,255,255,0.4); border-top-color: #fff; border-radius: 50%; animation: spin 0.7s linear infinite; display: inline-block; flex-shrink: 0; }
        @keyframes spin { to { transform: rotate(360deg); } }

        .modal-backdrop { position: fixed; inset: 0; background: rgba(15,23,42,0.55); z-index: 2000; display: flex; align-items: center; justify-content: center; opacity: 0; visibility: hidden; transition: opacity 0.25s, visibility 0.25s; padding: 1rem; }
        .modal-backdrop.open { opacity: 1; visibility: visible; }
        .modal-box { background: #fff; border-radius: 20px; box-shadow: 0 24px 80px rgba(10,47,68,0.22); width: 100%; max-width: 640px; max-height: 90vh; display: flex; flex-direction: column; transform: translateY(20px); transition: transform 0.25s; }
        .modal-backdrop.open .modal-box { transform: translateY(0); }
        .modal-head { padding: 1.25rem 1.5rem; border-bottom: 1px solid var(--border); display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem; flex-shrink: 0; }
        .modal-head-title { font-size: 1.1rem; font-weight: 800; color: var(--primary); display: flex; align-items: center; gap: 8px; }
        .modal-head-title i { color: var(--accent); }
        .modal-head-sub { font-size: 0.8rem; color: var(--muted); margin-top: 4px; }
        .modal-close { width: 36px; height: 36px; border: 1px solid var(--border); border-radius: 10px; background: #fff; cursor: pointer; display: flex; align-items: center; justify-content: center; color: var(--muted); font-size: 18px; flex-shrink: 0; transition: background 0.15s; }
        .modal-close:hover { background: #fee2e2; color: #A32D2D; border-color: #fca5a5; }
        .modal-body { flex: 1; overflow-y: auto; padding: 1rem 1.5rem; }
        .modal-foot { padding: 1rem 1.5rem; border-top: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-shrink: 0; flex-wrap: wrap; }
        .modal-foot-info { font-size: 0.82rem; color: var(--muted); }
        .modal-foot-btns { display: flex; gap: 0.55rem; }

        .narrative-textarea { width: 100%; min-height: 180px; border: 1.5px solid var(--border); border-radius: 12px; padding: 0.85rem 1rem; font-family: inherit; font-size: 0.9rem; line-height: 1.6; color: var(--text); resize: vertical; }
        .narrative-textarea:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(10,47,68,0.08); }
        .narrative-textarea:disabled { background: var(--surface-2); color: var(--muted); cursor: not-allowed; }

        @media (max-width: 991.98px) {
            body.stsn-layout { overflow: auto; }
            #stsn-toggle { display: inline-flex; }
            .page-shell, body.sidebar-collapsed .page-shell { margin-left: 0; height: auto; min-height: 100vh; }
            .page-main { overflow: visible; height: auto; padding-top: 0.75rem; }
            .main-panel, .table-wrap { overflow: visible; }
        }
        @media (max-width: 700px) {
            .top-bar, .toolbar, .page-main { padding-left: 1rem; padding-right: 1rem; }
            .table-wrap { overflow-x: auto; -webkit-overflow-scrolling: touch; }
            .grading-table { min-width: 1100px; }
        }
    </style>
    <link rel="stylesheet" href="../css/teacher-alerts.css">
</head>
<body class="stsn-layout">
<button id="stsn-toggle" aria-label="Toggle sidebar"><i class="bi bi-list"></i></button>
<div id="stsn-overlay"></div>

<?php include __DIR__ . '/../includes/teacher-sidebar.php'; ?>

<div class="page-shell">

    <header class="top-bar">
        <div class="top-bar-left">
            <h1><i class="bi bi-clipboard-check" style="color: var(--accent);"></i> Kindergarten Assessment</h1>
            <p id="topBarSub"><?= htmlspecialchars($subtitle) ?></p>
        </div>
        <div class="top-bar-right">
            <?php if ($isSelectionValid): ?>
                <?php $skillTotal = 0; foreach ($groupedDomains as $gd) { $skillTotal += count($gd['skills']); } ?>
                <div class="meta-chip"><i class="bi bi-people-fill"></i> <?= count($students) ?> Students</div>
                <div class="meta-chip"><i class="bi bi-grid-3x3"></i> <?= (int) $skillTotal ?> Skills &middot; <?= count($groupedDomains) ?> Domains</div>
                <div class="meta-chip"><i class="bi bi-calendar3"></i> S.Y. <?= htmlspecialchars($schoolYear) ?></div>
            <?php endif; ?>
            <?php if ($isSelectionValid && $isTermLocked): ?>
                <div class="meta-chip danger"><i class="bi bi-lock-fill"></i> Term Locked</div>
            <?php endif; ?>
            <div class="meta-chip"><i class="bi bi-person-badge"></i> <?= htmlspecialchars($teacherName) ?></div>
        </div>
    </header>

    <?php require_once __DIR__ . '/../includes/breadcrumb.php'; renderBreadcrumb([['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'], ['label' => 'Academics', 'href' => 'My-Sections.php', 'icon' => 'bi bi-journal-bookmark-fill'], ['label' => 'Kindergarten Assessment', 'icon' => 'bi bi-clipboard-check']], 'teacher'); ?>

    <div class="toolbar">
        <div class="toolbar-group">
            <span class="toolbar-label"><i class="bi bi-diagram-3"></i> Section</span>
            <select id="sectionSelect" onchange="changeSelection()">
                <option value="">&mdash; Select Section &mdash;</option>
                <?php foreach ($kinderSections as $sec): ?>
                    <option value="<?= (int) $sec['id'] ?>" <?= $sectionId === (int) $sec['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($sec['grade_level_name'] . ' - ' . $sec['section_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="toolbar-group">
            <span class="toolbar-label"><i class="bi bi-calendar-week"></i> Term</span>
            <select id="termSelect" onchange="changeSelection()" <?= !$sectionId ? 'disabled' : '' ?>>
                <option value="">&mdash; Select Term &mdash;</option>
                <?php foreach ($terms as $t): ?>
                    <option value="<?= (int) $t['id'] ?>" <?= $termId === (int) $t['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($t['term_label']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php if ($isSelectionValid && $isTermLocked): ?>
            <div class="toolbar-group" style="margin-left:auto;">
                <span class="meta-chip danger"><i class="bi bi-lock-fill"></i> Read-only</span>
            </div>
        <?php endif; ?>
    </div>

    <main class="page-main">
        <?php if ($isSelectionValid): ?>
            <?php if ($isTermLocked): ?>
                <div class="status-banner danger">
                    <i class="bi bi-lock-fill"></i>
                    <div>
                        <strong>Term locked.</strong>
                        This term's assessments have been archived and are read-only.
                        Contact admin for override.
                    </div>
                </div>
            <?php else: ?>
                <div class="status-banner success">
                    <i class="bi bi-clock"></i>
                    <div>
                        <strong>Encoding window open.</strong>
                        Select a rating (A/S/R/N) for each skill, then click Save.
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <?php
            $totalSkillCols = 0;
            foreach ($groupedDomains as $gd) {
                $totalSkillCols += max(1, count($gd['skills']));
            }
            $emptyColspan = 3 + $totalSkillCols;
        ?>

        <div class="panel main-panel">
            <div class="action-bar">
                <div class="action-bar-left">
                    <div class="panel-title" style="margin:0;">
                        <i class="bi bi-ui-checks"></i>
                        <span><?= $isSelectionValid ? htmlspecialchars($sectionDisplayName . ' - ' . $termLabel) : 'No Section Selected' ?></span>
                    </div>
                    <div class="panel-sub" style="margin-top:2px;">
                        A = Always Observed &middot; S = Sometimes Observed &middot; R = Rarely Observed &middot; N = Not Yet Observed
                    </div>
                </div>
                <div class="action-bar-right">
                    <span class="pill pill-neu"><i class="bi bi-people-fill"></i> <?= count($students) ?> Students</span>
                    <?php /* Print All Reports moved to grades-report.php (unified print center) */ ?>
                    <button class="btn btn-success" id="saveKinderBtn"
                            onclick="saveKinderAssessments()"
                            <?= ($isSelectionValid && !$isTermLocked) ? '' : 'disabled' ?>>
                        <i class="bi bi-save"></i> Save Assessments
                    </button>
                </div>
            </div>
            <div class="table-wrap">
                <table class="grading-table" id="kinderTable">
                    <thead>
                        <tr>
                            <th rowspan="2" class="th-def">#</th>
                            <th rowspan="2" class="th-def" style="text-align:left;padding-left:1rem;">Student Name</th>
                            <?php foreach ($groupedDomains as $domIdx => $gd): $domClass = 'th-dom-' . min(5, $domIdx + 1); ?>
                                <th colspan="<?= max(1, count($gd['skills'])) ?>" class="<?= $domClass ?>">
                                    <?= htmlspecialchars($gd['domain_code'] . ' - ' . $gd['domain_name']) ?>
                                </th>
                            <?php endforeach; ?>
                            <th rowspan="2" class="th-def">Narrative</th>
                        </tr>
                        <tr>
                            <?php foreach ($groupedDomains as $domIdx => $gd): $domClass = 'th-dom-' . min(5, $domIdx + 1); ?>
                                <?php if (count($gd['skills']) === 0): ?>
                                    <th class="th-def th-skill">&mdash;</th>
                                <?php else: ?>
                                    <?php foreach ($gd['skills'] as $sk): ?>
                                        <th class="<?= $domClass ?> th-skill" title="<?= htmlspecialchars($sk['skill_code']) ?>">
                                            <?= htmlspecialchars($sk['skill_code']) ?>
                                        </th>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody id="kinderBody">
                        <?php if (!$isSelectionValid): ?>
                            <tr>
                                <td colspan="<?= $emptyColspan ?>">
                                    <div class="empty-state">
                                        <i class="bi bi-arrow-up-circle"></i>
                                        Please select a section and term to load the checklist.
                                    </div>
                                </td>
                            </tr>
                        <?php elseif (count($students) === 0): ?>
                            <tr>
                                <td colspan="<?= $emptyColspan ?>">
                                    <div class="empty-state">
                                        <i class="bi bi-people"></i>
                                        No students enrolled in this section.
                                    </div>
                                </td>
                            </tr>
                        <?php elseif (count($groupedDomains) === 0): ?>
                            <tr>
                                <td colspan="<?= $emptyColspan ?>">
                                    <div class="empty-state">
                                        <i class="bi bi-grid"></i>
                                        No Kindergarten domains/skills configured yet.
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php $rowNum = 0; foreach ($students as $st): $rowNum++; $sid = (int) $st['id']; $mid = trim((string) ($st['mname'] ?? '')); $midInit = $mid !== '' ? strtoupper(substr($mid, 0, 1)) . '.' : ''; $fullName = trim(($st['lname'] ?? '') . ', ' . ($st['fname'] ?? '') . ' ' . $midInit); $hasNarrative = isset($existingNarratives[$sid]) && trim($existingNarratives[$sid]) !== ''; ?>
                                <tr>
                                    <td class="col-num"><?= $rowNum ?></td>
                                    <td class="col-name">
                                        <span class="student-name"><?= htmlspecialchars($fullName) ?></span>
                                        <span class="student-sub">LRN: <?= htmlspecialchars((string) ($st['lrn'] ?? '-')) ?></span>
                                    </td>
                                    <?php foreach ($groupedDomains as $gd): ?>
                                        <?php if (count($gd['skills']) === 0): ?>
                                            <td>&mdash;</td>
                                        <?php else: ?>
                                            <?php foreach ($gd['skills'] as $sk): $skid = (int) $sk['skill_id']; $cur = $existingRatings[$sid][$skid] ?? ''; ?>
                                                <td>
                                                    <select class="kinder-rating<?= $cur !== '' ? ' sel-' . htmlspecialchars($cur) : '' ?>"
                                                            data-student-id="<?= $sid ?>"
                                                            data-skill-id="<?= $skid ?>"
                                                            <?= $isTermLocked ? 'disabled' : '' ?>>
                                                        <option value="">&mdash;</option>
                                                        <option value="A" <?= $cur === 'A' ? 'selected' : '' ?>>A (Always)</option>
                                                        <option value="S" <?= $cur === 'S' ? 'selected' : '' ?>>S (Sometimes)</option>
                                                        <option value="R" <?= $cur === 'R' ? 'selected' : '' ?>>R (Rarely)</option>
                                                        <option value="N" <?= $cur === 'N' ? 'selected' : '' ?>>N (Not Yet)</option>
                                                    </select>
                                                </td>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                    <td class="col-narrative">
                                        <a href="K3-Report.php?section_id=<?= (int) $sectionId ?>&amp;term_id=<?= (int) $termId ?>&amp;student_id=<?= (int) $sid ?>"
                                           target="_blank"
                                           class="btn btn-sm btn-outline-primary"
                                           title="Print Progress Report">
                                            <i class="bi bi-printer"></i> Print
                                        </a>
                                        <button type="button"
                                                class="narrative-btn<?= $hasNarrative ? ' has-narrative' : '' ?>"
                                                data-narrative-student="<?= $sid ?>"
                                                data-narrative-name="<?= htmlspecialchars($fullName) ?>"
                                                onclick="openNarrativeModal(this)"
                                                <?= $isTermLocked ? 'disabled' : '' ?>>
                                            <i class="bi <?= $hasNarrative ? 'bi-chat-square-quote-fill' : 'bi-chat-square-quote' ?>"></i>
                                            <?= $hasNarrative ? 'Edit' : 'Narrative' ?>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>
<!-- Narrative Modal -->
<div class="modal-backdrop" id="narrativeModal">
    <div class="modal-box">
        <div class="modal-head">
            <div>
                <div class="modal-head-title">
                    <i class="bi bi-chat-square-quote-fill"></i>
                    Teacher's Narrative
                </div>
                <div class="modal-head-sub" id="narrativeModalSub">
                    Overall remarks for this student for <?= htmlspecialchars($termLabel) ?>.
                </div>
            </div>
            <button class="modal-close" onclick="closeNarrativeModal()" title="Cancel">&times;</button>
        </div>
        <div class="modal-body">
            <textarea class="narrative-textarea" id="narrativeTextarea"
                      placeholder="Write the developmental narrative for this student..."
                      <?= $isTermLocked ? 'disabled' : '' ?>></textarea>
        </div>
        <div class="modal-foot">
            <div class="modal-foot-info">
                Saved together when you click <strong>Save Assessments</strong>.
            </div>
            <div class="modal-foot-btns">
                <button type="button" class="btn btn-secondary" onclick="closeNarrativeModal()">Cancel</button>
                <button type="button" class="btn btn-primary" onclick="storeNarrative()">
                    <i class="bi bi-check2"></i> OK
                </button>
            </div>
        </div>
    </div>
</div>

<div class="toast" id="kinderToast"></div>

<script src="../js/teacher-alerts.js"></script>
<script src="../js/system-alerts.js"></script>
<script>
    const KINDER_CONFIG = {
        sectionId: <?= (int) $sectionId ?>,
        termId: <?= (int) $termId ?>,
        academicYearId: <?= (int) $activeYearId ?>,
        termLocked: <?= $isTermLocked ? 'true' : 'false' ?>,
        saveUrl: 'api/grading/save_kinder_assessment.php'
    };

    /* Existing narratives preloaded from the server */
    const narrativeStore = {
        <?= implode(",\n        ", array_map(
            static function (int $sid, string $text): string { return $sid . ': ' . json_encode($text, JSON_UNESCAPED_UNICODE); },
            array_map('intval', array_keys($existingNarratives)),
            array_values($existingNarratives)
        )) ?>
    };
    let narrativeStudentId = 0;

    function changeSelection() {
        const sec = document.getElementById('sectionSelect').value;
        const term = document.getElementById('termSelect').value;
        if (!sec || !term) return;
        window.location.href = 'Kinder-Assessment.php?section_id=' + encodeURIComponent(sec)
            + '&term_id=' + encodeURIComponent(term);
    }

    /* Toast helper (mirrors Grading-Sheet) */
    let toastTimer = null;
    function showKinderToast(message, type) {
        const t = document.getElementById('kinderToast');
        t.innerHTML = (type === 'error' ? '<i class="bi bi-exclamation-circle"></i> ' : '<i class="bi bi-check-circle"></i> ')
            + message;
        t.className = 'toast show' + (type === 'error' ? ' error' : ' success');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(function () { t.className = 'toast'; }, 3500);
    }

    /* Narrative modal */
    function openNarrativeModal(btn) {
        narrativeStudentId = parseInt(btn.getAttribute('data-narrative-student'), 10);
        const studentName = btn.getAttribute('data-narrative-name') || 'this student';
        document.getElementById('narrativeModalSub').textContent =
            'Overall remarks for ' + studentName + ' - <?= htmlspecialchars($termLabel) ?>.';
        document.getElementById('narrativeTextarea').value = narrativeStore[narrativeStudentId] || '';
        document.getElementById('narrativeModal').classList.add('open');
    }

    function closeNarrativeModal() {
        document.getElementById('narrativeModal').classList.remove('open');
        narrativeStudentId = 0;
    }

    function storeNarrative() {
        const text = document.getElementById('narrativeTextarea').value.trim();
        if (narrativeStudentId > 0) {
            narrativeStore[narrativeStudentId] = text;
            const btn = document.querySelector('.narrative-btn[data-narrative-student="' + narrativeStudentId + '"]');
            if (btn) {
                btn.classList.toggle('has-narrative', text !== '');
                btn.innerHTML = text !== ''
                    ? '<i class="bi bi-chat-square-quote-fill"></i> Edit'
                    : '<i class="bi bi-chat-square-quote"></i> Narrative';
            }
        }
        closeNarrativeModal();
    }

    document.getElementById('narrativeModal').addEventListener('click', function (e) {
        if (e.target === this) closeNarrativeModal();
    });

    /* Rating select coloring */
    document.querySelectorAll('.kinder-rating').forEach(function (sel) {
        sel.addEventListener('change', function () {
            sel.classList.remove('sel-A', 'sel-S', 'sel-R', 'sel-N');
            if (sel.value) sel.classList.add('sel-' + sel.value);
        });
    });

    /* Save to the Kinder assessment API (api/grading/save_kinder_assessment.php) */
    async function saveKinderAssessments() {
        if (KINDER_CONFIG.termLocked) {
            showKinderToast('Term is locked - assessments are read-only.', 'error');
            return;
        }

        const ratings = [];
        document.querySelectorAll('.kinder-rating').forEach(function (sel) {
            if (sel.value !== '') {
                ratings.push({
                    student_id: parseInt(sel.getAttribute('data-student-id'), 10),
                    skill_id: parseInt(sel.getAttribute('data-skill-id'), 10),
                    rating: sel.value
                });
            }
        });

        const narratives = [];
        Object.keys(narrativeStore).forEach(function (sid) {
            narratives.push({
                student_id: parseInt(sid, 10),
                narrative: (narrativeStore[sid] || '').trim()
            });
        });

        const payload = {
            section_id: KINDER_CONFIG.sectionId,
            term_id: KINDER_CONFIG.termId,
            academic_year_id: KINDER_CONFIG.academicYearId,
            ratings: ratings,
            narratives: narratives
        };

        const btn = document.getElementById('saveKinderBtn');
        const originalHtml = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner"></span> Saving...';

        try {
            const resp = await fetch(KINDER_CONFIG.saveUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'same-origin',
                body: JSON.stringify(payload)
            });
            const data = await resp.json().catch(function () { return null; });

            if (!resp.ok || !data || data.success !== true) {
                showKinderToast((data && data.message) ? data.message : 'Save failed. Please try again.', 'error');
            } else {
                showKinderToast(data.message || 'Kindergarten assessments saved successfully.', 'success');
                if (data.reload) {
                    setTimeout(function () { window.location.reload(); }, 900);
                }
            }
        } catch (err) {
            showKinderToast('Network error while saving. Please try again.', 'error');
        } finally {
            btn.disabled = false;
            btn.innerHTML = originalHtml;
        }
    }
</script>
</body>
</html>