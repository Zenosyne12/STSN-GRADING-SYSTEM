<?php
require_once __DIR__ . '/../api/login/teacher_auth.php';

$teacherName = $_SESSION['teacher_name'] ?? 'Teacher';
$sectionId = $_GET['section_id'] ?? '';
$subjectId = $_GET['subject_id'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Schedule | STSN Grading System</title>

    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css/index.css">

    <style>
        :root {
            --primary: #0A2F44;
            --primary-soft: rgba(10, 47, 68, 0.08);
            --accent: #C5A028;
            --bg: #F5F7FA;
            --surface: #FFFFFF;
            --surface-2: #F8F9FA;
            --text: #1E2A3E;
            --muted: #6C757D;
            --border: #E9ECEF;
            --success: #198754;
            --shadow: 0 10px 30px rgba(10, 47, 68, 0.08);
            --radius: 18px;
            --sidebar-width: 264px;
            --sidebar-collapsed-width: 72px;
        }

        * { box-sizing: border-box; }

        body.stsn-layout {
            margin: 0;
            font-family: "Plus Jakarta Sans", sans-serif;
            background: var(--bg);
            color: var(--text);
        }

        #stsn-toggle {
            position: fixed;
            top: 1rem;
            left: 1rem;
            z-index: 1100;
            width: 44px;
            height: 44px;
            border: 1px solid var(--border);
            border-radius: 12px;
            background: #fff;
            color: var(--primary);
            display: none;
            align-items: center;
            justify-content: center;
            box-shadow: var(--shadow);
            cursor: pointer;
        }

        #stsn-toggle i { font-size: 1.3rem; }

        #stsn-overlay {
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.35);
            opacity: 0;
            visibility: hidden;
            transition: 0.25s ease;
            z-index: 1035;
        }

        #stsn-overlay.visible {
            opacity: 1;
            visibility: visible;
        }

        .page-shell {
            margin-left: var(--sidebar-width);
            min-height: 100vh;
            transition: margin-left 0.28s ease;
        }

        body.sidebar-collapsed .page-shell {
            margin-left: var(--sidebar-collapsed-width);
        }

        .page-main {
            padding: 1.5rem 2rem 2rem;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 1rem;
            flex-wrap: wrap;
            margin-bottom: 1.25rem;
        }

        .page-title h1 {
            margin: 0;
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--primary);
        }

        .page-title p {
            margin: 0.4rem 0 0;
            color: var(--muted);
            font-size: 0.94rem;
        }

        .header-meta {
            display: flex;
            gap: 0.7rem;
            flex-wrap: wrap;
        }

        .meta-chip {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 999px;
            padding: 0.6rem 0.9rem;
            font-size: 0.82rem;
            color: var(--muted);
            white-space: nowrap;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            color: var(--muted);
            text-decoration: none;
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
        }

        .back-link:hover {
            color: var(--primary);
        }

        .content-grid {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 360px;
            gap: 1rem;
        }

        .panel {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
        }

        .panel-header {
            padding: 1rem 1.25rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .panel-title {
            margin: 0;
            display: flex;
            align-items: center;
            gap: 0.55rem;
            font-size: 1rem;
            font-weight: 700;
            color: var(--primary);
        }

        .panel-title i { color: var(--accent); }

        .panel-sub {
            font-size: 0.82rem;
            color: var(--muted);
            margin-top: 0.2rem;
        }

        .table-wrap {
            overflow-x: auto;
            padding: 0 1rem 1rem;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th {
            text-align: left;
            font-size: 0.77rem;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            color: var(--muted);
            padding: 0.95rem 0.75rem;
            border-bottom: 1px solid var(--border);
            background: var(--surface-2);
        }

        .data-table td {
            padding: 0.85rem 0.75rem;
            border-bottom: 1px solid #f0f2f5;
            font-size: 0.9rem;
            vertical-align: middle;
        }

        .data-table tr:hover td {
            background: var(--surface-2);
        }

        .data-table tr:last-child td {
            border-bottom: none;
        }

        .td-center { text-align: center; }

        .pill {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 999px;
            padding: 0.35rem 0.65rem;
            font-size: 0.74rem;
            font-weight: 700;
            white-space: nowrap;
        }

        .pill-primary {
            background: var(--primary-soft);
            color: var(--primary);
        }

        .pill-success {
            background: rgba(25, 135, 84, 0.12);
            color: var(--success);
        }

        .side-stack {
            display: grid;
            gap: 1rem;
        }

        .side-panel {
            padding: 1rem;
        }

        .info-list {
            display: grid;
            gap: 0.75rem;
        }

        .info-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.75rem;
            background: var(--surface-2);
            border-radius: 12px;
        }

        .info-label {
            font-size: 0.82rem;
            color: var(--muted);
        }

        .info-value {
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--text);
        }

        .empty-state,
        .loading-state {
            padding: 2rem;
            text-align: center;
            color: var(--muted);
            font-size: 0.92rem;
        }

        .day-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            padding: 0.4rem 0.7rem;
            background: var(--primary-soft);
            color: var(--primary);
            border-radius: 8px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .time-display {
            font-family: 'SF Mono', monospace;
            font-size: 0.85rem;
            color: var(--muted);
        }

        
        .panel-header select,
        .panel-header input[type="text"] {
            border: 1px solid var(--border);
            background: #fff;
            border-radius: 12px;
            padding: 0.52rem 0.75rem;
            font-family: inherit;
            font-size: 0.84rem;
            color: var(--text);
        }

        .action-btn {
            border: 1px solid var(--border);
            background: #fff;
            color: var(--text);
            border-radius: 12px;
            padding: 0.62rem 0.95rem;
            cursor: pointer;
            font-family: inherit;
            font-weight: 800;
            font-size: 0.84rem;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: 0.18s ease;
        }

        .action-btn:hover { background: var(--surface-2); }
        .action-btn.primary { background: var(--primary); border-color: var(--primary); color: #fff; }
        .action-btn.primary:hover:not(:disabled) { background: #0d3b56; }
        .action-btn:disabled { opacity: 0.55; cursor: not-allowed; }

        @media (max-width: 1199px) {
            .content-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 991.98px) {
            #stsn-toggle { display: inline-flex; }
            .page-shell,
            body.sidebar-collapsed .page-shell { margin-left: 0; }
            .page-main { padding: 5rem 1rem 1.5rem; }
        }

        @media (max-width: 767px) {
            .page-header { flex-direction: column; align-items: flex-start; }
            .page-title h1 { font-size: 1.45rem; }
        }
    </style>
</head>
<body class="stsn-layout">
    <button id="stsn-toggle" aria-label="Toggle sidebar">
        <i class="bi bi-list"></i>
    </button>

    <div id="stsn-overlay"></div>

    <?php include __DIR__ . '/../includes/teacher-sidebar.php'; ?>

    <div class="page-shell">
        <main class="page-main">
            <a href="My-Sections.php" class="back-link">
                <i class="bi bi-arrow-left"></i> Back to Sections
            </a>

            <div class="page-header">
                <div class="page-title">
                    <h1>Class Schedule</h1>
                    <p>View schedule for this section and subject.</p>
                </div>

                <div class="header-meta">
                    <div class="meta-chip"><i class="bi bi-person-badge"></i> <?php echo htmlspecialchars($teacherName); ?></div>
                    <div class="meta-chip"><i class="bi bi-calendar-week"></i> Schedule</div>
                </div>
            </div>

            <?php require_once __DIR__ . '/../includes/breadcrumb.php'; renderBreadcrumb([['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'], ['label' => 'My Sections', 'href' => 'My-Sections.php', 'icon' => 'bi bi-journal-bookmark'], ['label' => 'Schedule', 'icon' => 'bi bi-calendar-week']], 'teacher'); ?>
            <section class="content-grid">
                <div class="panel">
                    <div class="panel-header" style="flex-wrap:wrap;gap:.75rem;">
                        <div>
                            <h2 class="panel-title"><i class="bi bi-calendar-week"></i> Schedule Entries</h2>
                            <div class="panel-sub">View class schedules for this section.</div>
                        </div>
                        <div style="display:flex;align-items:center;gap:.55rem;flex-wrap:wrap;margin-left:auto;">
                            <input type="text" id="searchInput" placeholder="Search schedules...">
                            <select id="dayFilter">
                                <option value="">All Days</option>
                                <option value="Monday">Monday</option>
                                <option value="Tuesday">Tuesday</option>
                                <option value="Wednesday">Wednesday</option>
                                <option value="Thursday">Thursday</option>
                                <option value="Friday">Friday</option>
                                <option value="Saturday">Saturday</option>
                            </select>
                            <button class="action-btn" type="button" onclick="loadSchedules()">
                                <i class="bi bi-arrow-clockwise"></i> Refresh
                            </button>
                        </div>
                    </div>

                    <div class="table-wrap">
                        <div id="loadingState" class="loading-state">Loading schedules...</div>

                        <table class="data-table" id="scheduleTable" style="display:none;">
                            <thead>
                                <tr>
                                    <th>Day</th>
                                    <th>Time</th>
                                    <th>Room</th>
                                    <th>Semester</th>
                                    <th>School Year</th>
                                    <th class="td-center">Status</th>
                                </tr>
                            </thead>
                            <tbody id="scheduleTableBody"></tbody>
                        </table>

                        <div id="emptyState" class="empty-state" style="display:none;">
                            No schedules found.
                        </div>
                    </div>
                </div>

                <div class="side-stack">
                    <div class="panel side-panel">
                        <h3 class="panel-title"><i class="bi bi-info-circle"></i> Section Info</h3>
                        <div class="info-list" id="sectionInfo">
                            <div class="info-item">
                                <span class="info-label">Section</span>
                                <span class="info-value" id="infoSection">Loading...</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Subject</span>
                                <span class="info-value" id="infoSubject">Loading...</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total Schedules</span>
                                <span class="info-value" id="infoCount">0</span>
                            </div>
                        </div>
                    </div>

                    <div class="panel side-panel">
                        <h3 class="panel-title"><i class="bi bi-lightning-charge-fill"></i> Quick Stats</h3>
                        <div class="info-list" id="quickStats">
                            <div class="info-item">
                                <span class="info-label">Active Days</span>
                                <span class="info-value" id="activeDays">0</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Weekly Hours</span>
                                <span class="info-value" id="weeklyHours">0</span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <script>
        const sectionId = '<?php echo htmlspecialchars($sectionId); ?>';
        const subjectId = '<?php echo htmlspecialchars($subjectId); ?>';
        
        const sidebar = document.getElementById('stsn-sidebar');
        const toggleBtn = document.getElementById('stsn-toggle');
        const overlay = document.getElementById('stsn-overlay');
        const collapseBtn = document.getElementById('stsn-collapse-btn');

        const savedState = localStorage.getItem('stsn-sidebar-collapsed');

        if (sidebar && savedState === 'true' && window.innerWidth >= 992) {
            sidebar.classList.add('collapsed');
            document.body.classList.add('sidebar-collapsed');
        }

        if (collapseBtn && sidebar) {
            collapseBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                sidebar.classList.toggle('collapsed');
                const isCollapsed = sidebar.classList.contains('collapsed');
                document.body.classList.toggle('sidebar-collapsed', isCollapsed);
                localStorage.setItem('stsn-sidebar-collapsed', isCollapsed);
            });
        }

        if (toggleBtn && sidebar) {
            toggleBtn.addEventListener('click', function () {
                sidebar.classList.toggle('mobile-open');
                overlay.classList.toggle('visible');
            });
        }

        if (overlay && sidebar) {
            overlay.addEventListener('click', function () {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('visible');
            });
        }

        window.addEventListener('resize', function () {
            if (!sidebar) return;
            if (window.innerWidth >= 992) {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('visible');
            } else {
                document.body.classList.remove('sidebar-collapsed');
            }
        });

        const table = document.getElementById('scheduleTable');
        const tbody = document.getElementById('scheduleTableBody');
        const loadingState = document.getElementById('loadingState');
        const emptyState = document.getElementById('emptyState');
        const searchInput = document.getElementById('searchInput');
        const dayFilter = document.getElementById('dayFilter');

        let allSchedules = [];

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text ?? '';
            return div.innerHTML;
        }

        function formatTime(timeStr) {
            if (!timeStr) return '-';
            const [hours, minutes] = timeStr.split(':');
            const date = new Date();
            date.setHours(parseInt(hours), parseInt(minutes));
            return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
        }

        function calculateDuration(start, end) {
            const [startH, startM] = start.split(':').map(Number);
            const [endH, endM] = end.split(':').map(Number);
            return ((endH * 60 + endM) - (startH * 60 + startM)) / 60;
        }

        async function loadSchedules() {
            loadingState.style.display = 'block';
            table.style.display = 'none';
            emptyState.style.display = 'none';
            tbody.innerHTML = '';

            try {
                const response = await fetch(`../api/teacher-schedule/get_schedules.php?section_id=${encodeURIComponent(sectionId)}&subject_id=${encodeURIComponent(subjectId)}`);
                const result = await response.json();

                if (!result.success) {
                    throw new Error(result.message || 'Failed to load schedules');
                }

                allSchedules = result.data || [];
                updateSectionInfo(result.section, result.subject);
                renderTable();
                updateStats();
            } catch (error) {
                loadingState.style.display = 'none';
                emptyState.style.display = 'block';
                emptyState.textContent = 'Failed to load schedules. ' + error.message;
            }
        }

        function updateSectionInfo(section, subject) {
            document.getElementById('infoSection').textContent = section || 'N/A';
            document.getElementById('infoSubject').textContent = subject || 'N/A';
            document.getElementById('infoCount').textContent = allSchedules.length;
        }

        function updateStats() {
            const activeDays = new Set(allSchedules.filter(s => s.is_active).map(s => s.day_name)).size;
            const weeklyHours = allSchedules
                .filter(s => s.is_active)
                .reduce((total, s) => total + calculateDuration(s.time_start, s.time_end), 0);
            
            document.getElementById('activeDays').textContent = activeDays;
            document.getElementById('weeklyHours').textContent = weeklyHours.toFixed(1) + ' hrs';
        }

        function getFilteredSchedules() {
            const search = searchInput.value.trim().toLowerCase();
            const day = dayFilter.value;

            return allSchedules.filter(schedule => {
                const matchesSearch = !search || 
                    (schedule.day_name || '').toLowerCase().includes(search) ||
                    (schedule.room || '').toLowerCase().includes(search);
                const matchesDay = !day || schedule.day_name === day;
                return matchesSearch && matchesDay;
            });
        }

        function renderTable() {
            const schedules = getFilteredSchedules();

            loadingState.style.display = 'none';

            if (!schedules.length) {
                table.style.display = 'none';
                emptyState.style.display = 'block';
                return;
            }

            emptyState.style.display = 'none';
            table.style.display = 'table';

            tbody.innerHTML = schedules.map(schedule => `
                <tr>
                    <td>
                        <span class="day-badge">
                            <i class="bi bi-calendar-day"></i>
                            ${escapeHtml(schedule.day_name)}
                        </span>
                    </td>
                    <td>
                        <div class="time-display">
                            ${formatTime(schedule.time_start)} - ${formatTime(schedule.time_end)}
                        </div>
                    </td>
                    <td>${escapeHtml(schedule.room || '-')}</td>
                    <td>${escapeHtml(schedule.semester || '-')}</td>
                    <td>${escapeHtml(schedule.school_year || '-')}</td>
                    <td class="td-center">
                        <span class="pill ${schedule.is_active ? 'pill-success' : 'pill-primary'}">
                            ${schedule.is_active ? 'Active' : 'Inactive'}
                        </span>
                    </td>
                </tr>
            `).join('');
        }

        searchInput.addEventListener('input', renderTable);
        dayFilter.addEventListener('change', renderTable);

        loadSchedules();
    </script>
</body>
</html>