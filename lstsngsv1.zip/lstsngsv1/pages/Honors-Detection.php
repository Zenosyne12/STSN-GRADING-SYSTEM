<?php
require_once __DIR__ . '/../api/login/teacher_auth.php';
require_once __DIR__ . '/../api/shared/grade_workflow.php';

$teacherName = $_SESSION['teacher_name'] ?? 'Teacher';
ensureGradeWorkflowSchema($pdo);

function h($value): string { return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8'); }
function fetchAllRows(PDO $pdo, string $sql, array $params = []): array { $stmt = $pdo->prepare($sql); $stmt->execute($params); return $stmt->fetchAll(PDO::FETCH_ASSOC); }

function fetchVisibleSectionIds(PDO $pdo, int $teacherId, int $academicYearId = 0): array {
    $params = ['teacher_id' => $teacherId, 'teacher_id2' => $teacherId];
    $yearFilter = '';
    if ($academicYearId > 0) { $yearFilter = ' AND academic_year_id = :academic_year_id'; $params['academic_year_id'] = $academicYearId; }
    $rows = fetchAllRows($pdo, "SELECT DISTINCT section_id FROM (SELECT section_id FROM tblsectionadviser WHERE teacher_id = :teacher_id {$yearFilter} UNION SELECT section_id FROM tblschedule WHERE teacher_id = :teacher_id2 AND is_active = 1 AND school_year = (SELECT year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1)) visible_sections", $params);
    return array_map('intval', array_column($rows, 'section_id'));
}

function getHonorStatus(float $average, ?float $lowest, bool $hasFailing, bool $hasIncomplete, int $subjectCount): array {
    if ($subjectCount <= 0 || $hasIncomplete || $lowest === null) return ['status' => 'No Excellence', 'class' => 'none', 'remarks' => 'Incomplete subject grades'];
    if ($hasFailing) return ['status' => 'No Excellence', 'class' => 'none', 'remarks' => 'Has failing grade'];
    if ($lowest !== null && $lowest < 80) return ['status' => 'No Excellence', 'class' => 'none', 'remarks' => 'Lowest subject below 80'];
    if ($average >= 98) return ['status' => 'With Highest Honors', 'class' => 'highest', 'remarks' => 'Qualified'];
    if ($average >= 95) return ['status' => 'With High Honors', 'class' => 'high', 'remarks' => 'Qualified'];
    if ($average >= 90) return ['status' => 'With Honors', 'class' => 'honors', 'remarks' => 'Qualified'];
    return ['status' => 'No Excellence', 'class' => 'none', 'remarks' => 'Average below 90'];
}

function jsonResponse(array $payload): void { header('Content-Type: application/json; charset=utf-8'); echo json_encode($payload); exit; }

function getFilters(PDO $pdo, int $teacherId): array {
    $defaultQuarters = static function (bool $markFirstActive = true): array {
        return [
            ['quarter_number' => 1, 'quarter_label' => '1st', 'is_active' => $markFirstActive ? 1 : 0],
            ['quarter_number' => 2, 'quarter_label' => '2nd', 'is_active' => 0],
            ['quarter_number' => 3, 'quarter_label' => '3rd', 'is_active' => 0],
        ];
    };
    $years = fetchAllRows($pdo, "SELECT id, year_label, is_active FROM tblacademicyear ORDER BY is_active DESC, year_label DESC");
    $activeYearId = 0;
    foreach ($years as $year) { if ((int) $year['is_active'] === 1) { $activeYearId = (int) $year['id']; break; } }
    if ($activeYearId === 0 && $years) $activeYearId = (int) $years[0]['id'];
    $visibleIds = fetchVisibleSectionIds($pdo, $teacherId, $activeYearId);
    $sectionFilter = $visibleIds ? 'WHERE s.id IN (' . implode(',', array_fill(0, count($visibleIds), '?')) . ')' : 'WHERE 1 = 0';
    $gradeLevels = fetchAllRows($pdo, "SELECT DISTINCT gl.id, gl.grade_level_name, gl.sort_order FROM tblgradelevel gl JOIN tblsection s ON s.grade_level_id = gl.id {$sectionFilter} ORDER BY gl.sort_order, gl.grade_level_name", $visibleIds);
    $sections = fetchAllRows($pdo, "SELECT s.id, s.section_name, s.grade_level_id, gl.grade_level_name FROM tblsection s JOIN tblgradelevel gl ON gl.id = s.grade_level_id {$sectionFilter} ORDER BY gl.sort_order, s.section_name", $visibleIds);
    // Use tblconfig_terms for 3-term calendar
    $quarterRows = [];
    try {
        $quarterRows = fetchAllRows($pdo, "
            SELECT academic_year_id, 
                   term_number AS quarter_number, 
                   term_label AS quarter_label, 
                   is_active 
            FROM tblconfig_terms 
            ORDER BY academic_year_id, term_number
        ");
    } catch (Throwable $e) {
        // fallback to legacy
        $quarterRows = fetchAllRows($pdo, "SELECT academic_year_id, quarter_number, quarter_label, is_active FROM tblquarters ORDER BY academic_year_id, quarter_number");
    }
    $quartersByYear = [];
    foreach ($quarterRows as $quarter) {
        $yearId = (int) $quarter['academic_year_id'];
        $quartersByYear[$yearId][] = [
            'quarter_number' => (int) $quarter['quarter_number'],
            'quarter_label' => (string) $quarter['quarter_label'],
            'is_active' => (int) $quarter['is_active'],
        ];
    }
    foreach ($years as $year) {
        $yearId = (int) $year['id'];
        if (empty($quartersByYear[$yearId])) $quartersByYear[$yearId] = $defaultQuarters($yearId === $activeYearId);
    }
    $quarters = $quartersByYear[$activeYearId] ?? $defaultQuarters(true);
    $activeQuarter = (int) ($quarters[0]['quarter_number'] ?? 1);
    foreach ($quarters as $quarter) {
        if ((int) ($quarter['is_active'] ?? 0) === 1) {
            $activeQuarter = (int) $quarter['quarter_number'];
            break;
        }
    }
    return ['years' => $years, 'gradeLevels' => $gradeLevels, 'sections' => $sections, 'quarters' => $quarters, 'quartersByYear' => $quartersByYear, 'activeYearId' => $activeYearId, 'activeQuarter' => $activeQuarter];
}

function getHonorData(PDO $pdo, int $teacherId, array $filters): array {
    $academicYearId = (int) ($filters['academic_year_id'] ?? 0);
    $gradeLevelId = (int) ($filters['grade_level_id'] ?? 0);
    $sectionId = (int) ($filters['section_id'] ?? 0);
    $quarter = (int) ($filters['quarter'] ?? 0);
    if ($academicYearId <= 0) { $active = fetchAllRows($pdo, "SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1"); $academicYearId = $active ? (int) $active[0]['id'] : 0; }
    $visibleIds = fetchVisibleSectionIds($pdo, $teacherId, $academicYearId);
    if (!$visibleIds) return buildHonorPayload([]);
    $where = ['ss.academic_year_id = :academic_year_id', 'ss.is_active = 1', 'st.is_active = 1'];
    $params = ['academic_year_id' => $academicYearId];
    $where[] = 's.id IN (' . implode(',', array_map('intval', $visibleIds)) . ')';
    if ($gradeLevelId > 0) { $where[] = 's.grade_level_id = :grade_level_id'; $params['grade_level_id'] = $gradeLevelId; }
    if ($sectionId > 0 && in_array($sectionId, $visibleIds, true)) { $where[] = 's.id = :section_id'; $params['section_id'] = $sectionId; }
    $gradeJoin = 'g.student_id = st.id AND g.section_id = s.id AND g.academic_year_id = :academic_year_id_for_grades AND ' . officialGradeExistsSql('g');
    $params['academic_year_id_for_grades'] = $academicYearId;
    if ($quarter > 0) { $gradeJoin .= ' AND g.quarter = :quarter'; $params['quarter'] = $quarter; }
    $subjectWhere = ['sub.is_active = 1'];
    $rows = fetchAllRows($pdo, "SELECT st.id AS student_id, COALESCE(NULLIF(st.lrn, ''), st.id) AS student_number, CONCAT_WS(' ', st.fname, NULLIF(st.mname, ''), st.lname) AS full_name, s.id AS section_id, s.section_name, gl.id AS grade_level_id, gl.grade_level_name, sub.id AS subject_id, sub.subject_name, g.final_grade, g.remarks AS grade_remarks, g.status AS grade_status FROM tblsectionstudent ss JOIN tblstudents st ON st.id = ss.student_id JOIN tblsection s ON s.id = ss.section_id JOIN tblgradelevel gl ON gl.id = s.grade_level_id JOIN tblsubjects sub ON sub.grade_level_id = s.grade_level_id AND (sub.strand IS NULL OR sub.strand = '' OR sub.strand COLLATE utf8mb4_general_ci = s.strand) AND " . implode(' AND ', $subjectWhere) . " LEFT JOIN tblgrades g ON {$gradeJoin} AND g.subject_id = sub.id WHERE " . implode(' AND ', $where) . " ORDER BY gl.sort_order, s.section_name, st.lname, st.fname, sub.subject_name", $params);
    $students = [];
    foreach ($rows as $row) {
        $id = (int) $row['student_id'];
        if (!isset($students[$id])) $students[$id] = ['student_id' => $id, 'student_number' => (string) $row['student_number'], 'full_name' => trim((string) $row['full_name']), 'section_id' => (int) $row['section_id'], 'section' => (string) $row['section_name'], 'grade_level_id' => (int) $row['grade_level_id'], 'grade_level' => (string) $row['grade_level_name'], 'grades' => [], 'expected_subjects' => 0, 'encoded_subjects' => 0, 'has_failing' => false, 'has_incomplete' => false, 'lowest_subject_grade' => null];
        $students[$id]['expected_subjects']++;
        $grade = $row['final_grade'];
        $isIncomplete = $grade === null || $grade === '' || (float) $grade <= 0;
        if ($isIncomplete) { $students[$id]['has_incomplete'] = true; continue; }
        $gradeValue = (float) $grade;
        $students[$id]['encoded_subjects']++;
        $students[$id]['grades'][] = $gradeValue;
        if ($students[$id]['lowest_subject_grade'] === null || $gradeValue < $students[$id]['lowest_subject_grade']) $students[$id]['lowest_subject_grade'] = $gradeValue;
        if ($gradeValue < 75 || str_contains(strtolower((string) ($row['grade_remarks'] ?? '')), 'fail')) $students[$id]['has_failing'] = true;
    }
    $computed = [];
    foreach ($students as $student) {
        $average = $student['grades'] ? array_sum($student['grades']) / count($student['grades']) : 0;
        if ($student['encoded_subjects'] < $student['expected_subjects']) $student['has_incomplete'] = true;
        $honor = getHonorStatus(round($average, 2), $student['lowest_subject_grade'], $student['has_failing'], $student['has_incomplete'], (int) $student['expected_subjects']);
        $computed[] = ['student_id' => $student['student_id'], 'student_number' => $student['student_number'], 'full_name' => $student['full_name'], 'section_id' => $student['section_id'], 'section' => $student['section'], 'grade_level_id' => $student['grade_level_id'], 'grade_level' => $student['grade_level'], 'average' => round($average, 2), 'lowest_subject_grade' => $student['lowest_subject_grade'] === null ? null : round((float) $student['lowest_subject_grade'], 2), 'honor_status' => $honor['status'], 'honor_class' => $honor['class'], 'remarks' => $honor['remarks'], 'expected_subjects' => (int) $student['expected_subjects'], 'encoded_subjects' => (int) $student['encoded_subjects']];
    }
    usort($computed, static fn($a, $b) => [$a['grade_level'], $a['section'], -$a['average'], $a['full_name']] <=> [$b['grade_level'], $b['section'], -$b['average'], $b['full_name']]);
    return buildHonorPayload($computed);
}

function buildHonorPayload(array $students): array {
    $summary = ['total' => count($students), 'honor_students' => 0, 'highest' => 0, 'high' => 0, 'honors' => 0, 'none' => 0];
    $gradeDistribution = []; $sectionRanks = []; $gradeLevelRanks = [];
    foreach ($students as $student) {
        $class = $student['honor_class'];
        if ($class !== 'none') $summary['honor_students']++;
        if (isset($summary[$class])) $summary[$class]++;
        $grade = $student['grade_level'];
        if (!isset($gradeDistribution[$grade])) $gradeDistribution[$grade] = ['grade_level' => $grade, 'highest' => 0, 'high' => 0, 'honors' => 0, 'none' => 0];
        $gradeDistribution[$grade][$class]++;
        $sectionRanks[$student['section']][] = $student;
        $gradeLevelRanks[$grade][] = $student;
    }
    $rankBuilder = static function (array $groups): array {
        $result = []; ksort($groups);
        foreach ($groups as $label => $rows) {
            usort($rows, static fn($a, $b) => [$b['average'], $a['full_name']] <=> [$a['average'], $b['full_name']]);
            $rank = 1;
            $result[] = ['label' => $label, 'students' => array_map(static fn($s) => ['rank' => $rank++, 'full_name' => $s['full_name'], 'average' => $s['average'], 'honor_status' => $s['honor_status']], array_slice($rows, 0, 5))];
        }
        return $result;
    };
    return ['students' => $students, 'summary' => $summary, 'gradeDistribution' => array_values($gradeDistribution), 'sectionRanks' => $rankBuilder($sectionRanks), 'gradeLevelRanks' => $rankBuilder($gradeLevelRanks), 'generatedAt' => date('M d, Y h:i A')];
}

$filters = getFilters($pdo, $teacherId);

if (isset($_GET['ajax'])) {
    if ($_GET['ajax'] === 'sections') {
        $gradeLevelId = (int) ($_GET['grade_level_id'] ?? 0);
        $sections = array_values(array_filter($filters['sections'], static fn($s) => $gradeLevelId <= 0 || (int) $s['grade_level_id'] === $gradeLevelId));
        jsonResponse(['sections' => $sections]);
    }
    if ($_GET['ajax'] === 'honors') jsonResponse(getHonorData($pdo, $teacherId, $_GET));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Honors Detection | STSN Grading System</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css/index.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary:#0A2F44; --primary-soft:rgba(10,47,68,.08); --accent:#C5A028;
            --bg:#F5F7FA; --surface:#FFFFFF; --surface-2:#F8F9FA; --text:#1E2A3E;
            --muted:#6C757D; --border:#E9ECEF; --success:#198754; --danger:#DC3545;
            --shadow:0 10px 30px rgba(10,47,68,.08); --radius:18px;
            --sidebar-width:264px; --sidebar-collapsed-width:72px;
        }
        * { box-sizing:border-box; }
        body.stsn-layout { margin:0; font-family:"Plus Jakarta Sans",sans-serif; background:var(--bg); color:var(--text); }
        #stsn-toggle { position:fixed; top:1rem; left:1rem; z-index:1100; width:44px; height:44px; border:1px solid var(--border); border-radius:12px; background:#fff; color:var(--primary); display:none; align-items:center; justify-content:center; box-shadow:var(--shadow); cursor:pointer; }
        #stsn-overlay { position:fixed; inset:0; background:rgba(15,23,42,.35); opacity:0; visibility:hidden; transition:.25s ease; z-index:1035; }
        #stsn-overlay.visible { opacity:1; visibility:visible; }
        .page-shell { margin-left:var(--sidebar-width); min-height:100vh; transition:margin-left .28s ease; }
        body.sidebar-collapsed .page-shell { margin-left:var(--sidebar-collapsed-width); }

        .top-bar { background:var(--surface); border-bottom:1px solid var(--border); padding:.85rem 1.5rem; display:flex; align-items:center; justify-content:space-between; gap:1rem; flex-wrap:wrap; position:sticky; top:0; z-index:40; }
        .top-bar-left h1 { margin:0; font-size:1.25rem; font-weight:800; color:var(--primary); display:flex; align-items:center; gap:.5rem; }
        .top-bar-left p { margin:.2rem 0 0; color:var(--muted); font-size:.82rem; }
        .top-bar-right { display:flex; align-items:center; gap:.55rem; flex-wrap:wrap; }
        .meta-chip { background:#fff; border:1px solid var(--border); border-radius:999px; padding:.45rem .8rem; font-size:.78rem; color:var(--muted); white-space:nowrap; display:inline-flex; align-items:center; gap:5px; }

        .page-main { padding:1rem 1.5rem 1.5rem; }

        .action-btn { border:1px solid var(--border); background:#fff; color:var(--text); border-radius:12px; padding:.5rem .8rem; cursor:pointer; font:inherit; font-weight:700; font-size:.8rem; display:inline-flex; align-items:center; gap:.45rem; transition:.18s ease; }
        .action-btn:hover { background:var(--surface-2); }
        .action-btn.primary { background:var(--primary); border-color:var(--primary); color:#fff; }
        .action-btn.danger { background:#dc2626; border-color:#dc2626; color:#fff; }
        .action-btn.danger:hover { background:#b91c1c; border-color:#b91c1c; }

        
        .summary-section { margin-bottom:1rem; }
        .summary-grid { display:grid; grid-template-columns:repeat(6,minmax(140px,1fr)); gap:.75rem; }
        .summary-card { background:var(--surface); border:1px solid var(--border); border-radius:16px; padding:1.1rem 1.2rem; display:flex; align-items:center; gap:.9rem; box-shadow:0 2px 8px rgba(10,47,68,.06); transition:box-shadow .18s ease, transform .18s ease; }
        .summary-card:hover { box-shadow:0 6px 20px rgba(10,47,68,.1); transform:translateY(-1px); }
        .summary-card-icon { width:44px; height:44px; border-radius:12px; display:flex; align-items:center; justify-content:center; flex-shrink:0; font-size:1.15rem; }
        .summary-card-icon.total  { background:rgba(10,47,68,.08); color:var(--primary); }
        .summary-card-icon.honor  { background:rgba(197,160,40,.12); color:var(--accent); }
        .summary-card-icon.highest{ background:#fff5cc; color:#8A6200; }
        .summary-card-icon.high   { background:#dbeafe; color:#1d4ed8; }
        .summary-card-icon.honors { background:#dcfce7; color:#15803d; }
        .summary-card-icon.none   { background:#f1f5f9; color:#64748b; }
        .summary-card-body { min-width:0; }
        .summary-label { color:var(--muted); font-size:.7rem; font-weight:700; text-transform:uppercase; letter-spacing:.05em; white-space:nowrap; }
        .summary-value { font-size:1.65rem; font-weight:800; color:var(--primary); line-height:1.1; margin-top:.15rem; }

        .dashboard-grid { display:grid; grid-template-columns:minmax(0,1.65fr) minmax(300px,.65fr); gap:1rem; align-items:stretch; }
        .panel { background:#fff; border:1px solid var(--border); border-radius:var(--radius); box-shadow:var(--shadow); overflow:hidden; min-width:0; }
        .student-panel, .analytics-panel, .rank-panel { height:100%; display:flex; flex-direction:column; }

        .panel-header { padding:.9rem 1.1rem; border-bottom:1px solid var(--border); display:flex; align-items:center; justify-content:space-between; gap:.75rem; flex-wrap:wrap; }
        .panel-header-left { display:flex; flex-direction:column; gap:.15rem; }
        .panel-header-right { display:flex; align-items:center; gap:.5rem; flex-wrap:wrap; flex-shrink:0; }
        .student-actions { margin-left:auto; justify-content:flex-end; max-width:760px; }

        
        .panel-header { position: relative; }
        .panel-header-right { 
            display:flex; 
            align-items:flex-start; 
            gap:.5rem; 
            flex-wrap:nowrap; 
            flex-shrink:0; 
        }
        .student-actions { 
            margin-left:auto; 
            justify-content:flex-end; 
            max-width:none; 
        }
        .filter-group { display:flex; align-items:center; gap:.5rem; flex-wrap:wrap; }
        .filter-group.main-filters { 
            flex:1 1 auto; 
            justify-content:flex-start; 
            min-width: 0;
        }
        .filter-group.action-group { 
            flex:0 0 auto; 
            justify-content:flex-end; 
            margin-left:.5rem;
            background: var(--surface-2);
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: .35rem .5rem;
            white-space: nowrap;
        }
        .filter-group.action-group select.quarter-select {
            background: #fff;
            border-color: var(--accent);
            color: var(--primary);
            font-weight: 700;
            min-width: 130px;
        }
        .filter-group.action-group .action-btn {
            white-space: nowrap;
        }

        @media (max-width: 1100px) {
            .panel-header-right {
                flex-wrap: wrap;
                width: 100%;
            }
            .filter-group.main-filters {
                width: 100%;
                order: 2;
            }
            .filter-group.action-group {
                margin-left: auto;
                order: 1;
            }
        }

        @media (max-width: 768px) {
            .panel-header-right {
                flex-direction: column;
                align-items: stretch;
                width: 100%;
            }
            .filter-group.main-filters,
            .filter-group.action-group {
                width: 100%;
                margin-left: 0;
                order: unset;
            }
            .filter-group.action-group {
                justify-content: flex-start;
            }
        }
        .panel-title { margin:0; color:var(--primary); font-size:1rem; font-weight:800; display:flex; align-items:center; gap:.5rem; }
        .panel-title i { color:var(--accent); }
        .panel-sub { color:var(--muted); font-size:.8rem; margin-top:.2rem; }

        
        .panel-header select { border:1px solid var(--border); background:#fff; border-radius:12px; padding:.45rem .7rem; font:inherit; font-size:.8rem; color:var(--text); min-height:36px; }
        .student-actions select { max-width:170px; }
        .student-actions #section { max-width:220px; }

        .student-panel .table-wrap { flex:1; min-height:0; }
        .table-wrap { overflow-y:auto; overflow-x:clip; max-height:560px; }
        .honor-table { width:100%; min-width:0; border-collapse:collapse; table-layout:fixed; }
        .honor-table th { position:sticky; top:0; z-index:5; background:#f8fafc; text-align:left; color:var(--muted); font-size:.66rem; letter-spacing:.03em; text-transform:uppercase; padding:.62rem .42rem; border-bottom:1px solid var(--border); line-height:1.2; }
        .honor-table td { height:56px; padding:.55rem .42rem; border-bottom:1px solid var(--border); font-size:.8rem; line-height:1.28; vertical-align:middle; overflow-wrap:anywhere; word-break:normal; }
        .honor-table th:nth-child(1), .honor-table td:nth-child(1) { width:13%; }
        .honor-table th:nth-child(2), .honor-table td:nth-child(2) { width:20%; }
        .honor-table th:nth-child(3), .honor-table td:nth-child(3) { width:13%; }
        .honor-table th:nth-child(4), .honor-table td:nth-child(4) { width:9%; }
        .honor-table th:nth-child(5), .honor-table td:nth-child(5) { width:10%; }
        .honor-table th:nth-child(6), .honor-table td:nth-child(6) { width:10%; }
        .honor-table th:nth-child(7), .honor-table td:nth-child(7) { width:15%; }
        .honor-table th:nth-child(8), .honor-table td:nth-child(8) { width:10%; }
        .honor-table tr:hover td { background:#fbfcff; }
        .student-main { font-weight:800; color:var(--text); line-height:1.2; }
        .student-sub { color:var(--muted); font-size:.68rem; margin-top:.08rem; line-height:1.18; }
        .num { text-align:right; font-variant-numeric:tabular-nums; font-weight:800; }
        .badge { display:inline-flex; align-items:center; justify-content:center; gap:.24rem; border-radius:999px; padding:.28rem .44rem; font-size:.68rem; font-weight:800; white-space:normal; line-height:1.12; max-width:100%; text-align:center; }
        .badge.highest { background:#fff5cc; color:#8A6200; border:1px solid #f2cf61; }
        .badge.high    { background:#dbeafe; color:#1d4ed8; border:1px solid #93c5fd; }
        .badge.honors  { background:#dcfce7; color:#15803d; border:1px solid #86efac; }
        .badge.none    { background:#f1f5f9; color:#64748b; border:1px solid #cbd5e1; }

        .analytics-panel .panel-header { flex-shrink:0; }
        .charts-grid { flex:1; min-height:0; display:grid; grid-template-columns:1fr; gap:1rem; padding:1rem; align-content:start; }
        .chart-card { min-height:250px; border:1px solid #eef1f4; border-radius:14px; background:#fafcff; padding:1rem; display:flex; flex-direction:column; }
        .chart-card .panel-title { font-size:.9rem; margin-bottom:.75rem; flex-shrink:0; }
        .chart-canvas-wrap { flex:1; min-height:240px; position:relative; }
        .rank-grid { grid-column:1 / -1; display:grid; grid-template-columns:minmax(0,1fr) minmax(0,1fr); gap:1rem; align-items:stretch; }
        .rank-list { padding:.8rem 1rem 1rem; display:grid; gap:.75rem; }
        .rank-group { border:1px solid #eef1f4; border-radius:14px; padding:.75rem; background:#fafcff; }
        .rank-title { font-size:.86rem; font-weight:800; color:var(--primary); margin-bottom:.45rem; }
        .rank-row { display:grid; grid-template-columns:36px minmax(0,1fr) 70px; gap:.5rem; align-items:center; padding:.42rem 0; border-top:1px dashed #e5eaf0; font-size:.83rem; }
        .rank-row:first-of-type { border-top:0; }
        .rank-name { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-weight:700; }
        .state { padding:2.5rem 1rem; text-align:center; color:var(--muted); }
        .loader { width:44px; height:44px; border:4px solid #e5e7eb; border-top-color:var(--accent); border-radius:50%; animation:spin .8s linear infinite; margin:0 auto 1rem; }
        @keyframes spin { to { transform:rotate(360deg); } }
        .hidden { display:none !important; }

        @media (max-width:1180px) { .summary-grid { grid-template-columns:repeat(3,1fr); } .dashboard-grid, .rank-grid { grid-template-columns:1fr; } .honor-table td { height:58px; padding:.62rem .55rem; font-size:.82rem; } .honor-table th { padding:.68rem .55rem; } }
        @media (max-width:900px) { .chart-card { min-height:280px; } }
        @media (max-width:768px) { #stsn-toggle { display:flex; } .page-shell, body.sidebar-collapsed .page-shell { margin-left:0; } .top-bar { padding:4.5rem 1rem 1rem; } .page-main { padding-left:1rem; padding-right:1rem; } .summary-grid { grid-template-columns:repeat(2,1fr); } .panel-header-right { width:100%; } .panel-header-right select, .panel-header-right .action-btn, .panel-header-right .meta-chip { flex:1 1 150px; } }
        @media (max-width:520px) { .summary-grid { grid-template-columns:repeat(2,1fr); } }
        @media print { #stsn-sidebar, #stsn-toggle, #stsn-overlay, .top-bar, .rank-panel { display:none !important; } .page-shell { margin-left:0 !important; } .page-main { padding:0; } .panel { box-shadow:none; border:0; } .table-wrap { max-height:none; overflow:visible; } .honor-table { min-width:0; font-size:11px; } }
    </style>
</head>
<body class="stsn-layout">
    <button id="stsn-toggle" aria-label="Open menu"><i class="bi bi-list"></i></button>
    <div id="stsn-overlay"></div>
    <?php include __DIR__ . '/../includes/teacher-sidebar.php'; ?>

    <div class="page-shell">
        <header class="top-bar">
            <div class="top-bar-left">
                <h1><i class="bi bi-trophy" style="color:var(--accent);"></i> Honors Detection</h1>
                <p>Automatic honor roll computation from encoded subject grades.</p>
            </div>
            <div class="top-bar-right">
                <span class="meta-chip"><i class="bi bi-person-badge"></i> <?= h($teacherName) ?></span>
                <span class="meta-chip" id="generatedAt"><i class="bi bi-clock"></i> Ready</span>
            </div>
        </header>

        <main class="page-main">

            
            <?php require_once __DIR__ . '/../includes/breadcrumb.php'; renderBreadcrumb([['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'], ['label' => 'Honor Detection', 'href' => 'Honors-Detection.php', 'icon' => 'bi bi-trophy'], ['label' => 'Candidates', 'icon' => 'bi bi-award']], 'teacher'); ?>
            <div class="summary-section">
                <section class="summary-grid" id="summaryGrid"></section>
            </div>

            <section class="dashboard-grid">
                <div class="panel student-panel">
                    
                    <div class="panel-header">
                        <div class="panel-header-left">
                            <h2 class="panel-title"><i class="bi bi-trophy"></i> Student Honor Roll</h2>
                            <div class="panel-sub">Average, lowest subject grade, academic excellence status, and ranking computed from the database.</div>
                        </div>
                        <div class="panel-header-right student-actions">
                            
                            <div class="filter-group main-filters">
                                <select id="academicYear">
                                    <?php foreach ($filters['years'] as $year): ?>
                                        <option value="<?= (int) $year['id'] ?>" <?= (int) $year['id'] === $filters['activeYearId'] ? 'selected' : '' ?>><?= h($year['year_label']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <select id="gradeLevel">
                                    <option value="">All grade levels</option>
                                    <?php foreach ($filters['gradeLevels'] as $level): ?>
                                        <option value="<?= (int) $level['id'] ?>"><?= h($level['grade_level_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <select id="section">
                                    <option value="">All sections</option>
                                    <?php foreach ($filters['sections'] as $section): ?>
                                        <option value="<?= (int) $section['id'] ?>" data-grade="<?= (int) $section['grade_level_id'] ?>"><?= h($section['grade_level_name'] . ' - ' . $section['section_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="filter-group action-group">
                                <select id="quarter" class="quarter-select">
                                    <?php foreach ($filters['quarters'] as $quarter): ?>
                                        <?php
                                            $quarterNumber = (int) $quarter['quarter_number'];
                                            $quarterLabel = trim((string) ($quarter['quarter_label'] ?? $quarterNumber));
                                        ?>
                                        <option value="<?= $quarterNumber ?>" <?= $quarterNumber === (int) $filters['activeQuarter'] ? 'selected' : '' ?>>
                                            <?= h($quarterLabel) ?><?= (int) ($quarter['is_active'] ?? 0) === 1 ? ' (Active)' : '' ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <button class="action-btn danger" id="pdfBtn"><i class="bi bi-file-earmark-pdf"></i> PDF</button>
                            </div>
                        </div>
                    </div>

                    <div id="loadingState" class="state"><div class="loader"></div>Computing honors from grades...</div>
                    <div id="emptyState" class="state hidden"><i class="bi bi-inbox" style="font-size:2rem;color:#cbd5e1;"></i><br>No students or grades found for the selected filters.</div>
                    <div class="table-wrap hidden" id="tableWrap">
                        <table class="honor-table" id="honorTable">
                            <thead>
                                <tr>
                                    <th>LRN</th>
                                    <th>Full Name</th>
                                    <th>Section</th>
                                    <th>Average</th>
                                    <th>Lowest Grade</th>
                                    <th>Academic Excellence</th>
                                    <th>Excellence Status</th>
                                    <th>Remarks</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>

                <div class="panel analytics-panel">
                    <div class="panel-header">
                        <div class="panel-header-left">
                            <h2 class="panel-title"><i class="bi bi-graph-up-arrow"></i> Academic Excellence</h2>
                            <div class="panel-sub">Grade-level distribution and overall academic excellence classification.</div>
                        </div>
                    </div>
                    <div style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:10px;padding:.65rem .9rem;margin-bottom:.75rem;font-size:.78rem;color:#0369a1;">
                        <i class="bi bi-info-circle-fill"></i>
                        <strong>DepEd DO 15, s. 2026 Criteria:</strong>
                        With Honors: GA ≥ 90, no grade below 80 ·
                        High Honors: GA ≥ 95 ·
                        Highest Honors: GA ≥ 98
                    </div>
                    <div class="charts-grid">
                        <div class="chart-card">
                            <h2 class="panel-title"><i class="bi bi-bar-chart"></i> Per Grade Level</h2>
                            <div class="chart-canvas-wrap"><canvas id="gradeChart"></canvas></div>
                        </div>
                        <div class="chart-card">
                            <h2 class="panel-title"><i class="bi bi-pie-chart"></i> Academic Excellence vs Without Academic Excellence</h2>
                            <div class="chart-canvas-wrap"><canvas id="honorChart"></canvas></div>
                        </div>
                    </div>
                </div>

                <div class="rank-grid">
                    <div class="panel rank-panel">
                        <div class="panel-header"><h2 class="panel-title"><i class="bi bi-award"></i> Top Per Section</h2></div>
                        <div class="rank-list" id="sectionRanks"></div>
                    </div>
                    <div class="panel rank-panel">
                        <div class="panel-header"><h2 class="panel-title"><i class="bi bi-mortarboard"></i> Top Per Grade Level</h2></div>
                        <div class="rank-list" id="gradeRanks"></div>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <script>
        const filterEls = {
            academicYear: document.getElementById('academicYear'),
            gradeLevel: document.getElementById('gradeLevel'),
            section: document.getElementById('section'),
            quarter: document.getElementById('quarter')
        };
        const quartersByYear = <?= json_encode($filters['quartersByYear'], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>;
        const allSections = Array.from(filterEls.section.options).map(o => ({ value: o.value, text: o.textContent, grade: o.dataset.grade || '' }));
        let currentRows = [], gradeChart = null, honorChart = null, refreshTimer = null;
        const badgeIcon = { highest:'bi-gem', high:'bi-stars', honors:'bi-award', none:'bi-dash-circle' };

        function moneyNumber(value) { return Number(value||0).toLocaleString(undefined, { minimumFractionDigits:2, maximumFractionDigits:2 }); }
        function filters() { return new URLSearchParams({ ajax:'honors', academic_year_id:filterEls.academicYear.value, grade_level_id:filterEls.gradeLevel.value, section_id:filterEls.section.value, quarter:filterEls.quarter.value }); }

        function renderQuarterOptions(preferredValue = null) {
            const quarters = quartersByYear[filterEls.academicYear.value] || quartersByYear[Number(filterEls.academicYear.value)] || [];
            const currentValue = preferredValue === null ? '' : preferredValue;
            filterEls.quarter.innerHTML = '';
            quarters.forEach(q => {
                const quarterNumber = String(q.quarter_number);
                const quarterLabel = String(q.quarter_label || q.quarter_number).trim();
                const activeText = Number(q.is_active) === 1 ? ' (Active)' : '';
                filterEls.quarter.add(new Option(`${quarterLabel}${activeText}`, quarterNumber));
            });
            const activeQuarter = quarters.find(q => Number(q.is_active) === 1);
            const nextValue = currentValue || (activeQuarter ? String(activeQuarter.quarter_number) : '');
            if ([...filterEls.quarter.options].some(o => o.value === nextValue)) filterEls.quarter.value = nextValue;
            else if (activeQuarter) filterEls.quarter.value = String(activeQuarter.quarter_number);
        }

        function setLoading(isLoading) {
            document.getElementById('loadingState').classList.toggle('hidden', !isLoading);
            document.getElementById('tableWrap').classList.toggle('hidden', isLoading || currentRows.length === 0);
            document.getElementById('emptyState').classList.toggle('hidden', isLoading || currentRows.length > 0);
        }

        function renderSummary(summary) {
            const cards = [
                ['bi-people',     'total',   'Total Students',   summary.total],
                ['bi-dash-circle','none',    'Without Academic Excellence',   summary.none]
            ];
            document.getElementById('summaryGrid').innerHTML = cards.map(c => `<article class="summary-card">
                <div class="summary-card-icon ${c[1]}"><i class="bi ${c[0]}"></i></div>
                <div class="summary-card-body">
                    <div class="summary-label">${c[2]}</div>
                    <div class="summary-value">${c[3]}</div>
                </div>
            </article>`).join('');
        }

        function renderTable(rows) {
            const tbody = document.querySelector('#honorTable tbody');
            tbody.innerHTML = rows.map(row => `<tr>
                <td><div class="student-main">${escapeHtml(row.student_number)}</div><div class="student-sub">${row.encoded_subjects}/${row.expected_subjects} subjects encoded</div></td>
                <td><div class="student-main">${escapeHtml(row.full_name)}</div><div class="student-sub">${escapeHtml(row.grade_level)}</div></td>
                <td>${escapeHtml(row.section)}</td>
                <td class="num">${moneyNumber(row.average)}</td>
                <td class="num">${row.lowest_subject_grade === null ? 'Incomplete' : moneyNumber(row.lowest_subject_grade)}</td>
                <td><span class="badge ${row.honor_class === 'none' ? 'none' : 'honors'}">${row.honor_class === 'none' ? 'No' : 'Yes'}</span></td>
                <td><span class="badge ${row.honor_class}"><i class="bi ${badgeIcon[row.honor_class]}"></i>${escapeHtml(row.honor_status)}</span></td>
                <td>${escapeHtml(row.remarks)}</td>
            </tr>`).join('');
        }

        function renderCharts(payload) {
            const gradeLabels = payload.gradeDistribution.map(i => i.grade_level);
            const gradeData = ['highest','high','honors','none'].map(k => payload.gradeDistribution.map(i => i[k]));
            if (gradeChart) gradeChart.destroy();
            gradeChart = new Chart(document.getElementById('gradeChart'), { type:'bar', data:{ labels:gradeLabels, datasets:[{label:'Highest',data:gradeData[0],backgroundColor:'#C5A028'},{label:'High',data:gradeData[1],backgroundColor:'#2563EB'},{label:'Honors',data:gradeData[2],backgroundColor:'#16A34A'},{label:'No Excellence',data:gradeData[3],backgroundColor:'#94A3B8'}]}, options:{ responsive:true, maintainAspectRatio:false, scales:{ x:{stacked:true}, y:{stacked:true,beginAtZero:true,ticks:{precision:0}} }} });
            if (honorChart) honorChart.destroy();
            honorChart = new Chart(document.getElementById('honorChart'), { type:'doughnut', data:{ labels:['Academic Excellence','Without Academic Excellence'], datasets:[{data:[payload.summary.honor_students,payload.summary.none],backgroundColor:['#16A34A','#94A3B8'],borderWidth:0}]}, options:{ responsive:true, maintainAspectRatio:false, cutout:'68%' } });
        }

        function renderRanks(targetId, groups) {
            const target = document.getElementById(targetId);
            if (!groups.length) { target.innerHTML = '<div class="state" style="padding:1rem;">No ranking yet.</div>'; return; }
            target.innerHTML = groups.map(g => `<div class="rank-group"><div class="rank-title">${escapeHtml(g.label)}</div>${g.students.map(s => `<div class="rank-row"><strong>#${s.rank}</strong><span class="rank-name">${escapeHtml(s.full_name)}</span><strong class="num">${moneyNumber(s.average)}</strong></div>`).join('')}</div>`).join('');
        }

        async function loadHonors() {
            setLoading(true);
            try {
                const response = await fetch(`Honors-Detection.php?${filters().toString()}`, { headers:{'Accept':'application/json'} });
                if (!response.ok) throw new Error('Unable to load honor data.');
                const payload = await response.json();
                currentRows = payload.students || [];
                renderSummary(payload.summary);
                renderTable(currentRows);
                renderCharts(payload);
                renderRanks('sectionRanks', payload.sectionRanks || []);
                renderRanks('gradeRanks', payload.gradeLevelRanks || []);
                document.getElementById('generatedAt').innerHTML = `<i class="bi bi-clock"></i> ${escapeHtml(payload.generatedAt)}`;
            } catch (error) {
                currentRows = [];
                renderSummary({ total:0, honor_students:0, highest:0, high:0, honors:0, none:0 });
            } finally { setLoading(false); }
        }

        function filterSections() {
            const grade = filterEls.gradeLevel.value, currentValue = filterEls.section.value;
            filterEls.section.innerHTML = '';
            allSections.filter(o => o.value === '' || !grade || o.grade === grade).forEach(o => {
                const node = new Option(o.text, o.value);
                if (o.grade) node.dataset.grade = o.grade;
                filterEls.section.add(node);
            });
            if ([...filterEls.section.options].some(o => o.value === currentValue)) filterEls.section.value = currentValue;
        }

        function escapeHtml(value) { return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }

        function exportPdf() {
            const printWindow = window.open('', '_blank');
            const rows = document.querySelector('#honorTable tbody').innerHTML;
            const quarterLabel = filterEls.quarter.options[filterEls.quarter.selectedIndex]?.textContent || '';
            printWindow.document.write(`<html><head><title>Honor Roll PDF</title><style>body{font-family:Arial,sans-serif;padding:24px;color:#1E2A3E}h1{color:#0A2F44}table{width:100%;border-collapse:collapse;font-size:12px}th,td{border:1px solid #d9dee5;padding:8px;text-align:left}th{background:#f4f7fa}</style></head><body><h1>STSN Honor Roll</h1><p>${escapeHtml(quarterLabel)} | Generated ${escapeHtml(document.getElementById('generatedAt').textContent)}</p><table><thead>${document.querySelector('#honorTable thead').innerHTML}</thead><tbody>${rows}</tbody></table></body></html>`);
            printWindow.document.close(); printWindow.focus(); printWindow.print();
        }

        Object.values(filterEls).forEach(el => el.addEventListener('change', () => {
            if (el === filterEls.academicYear) renderQuarterOptions();
            if (el === filterEls.gradeLevel) filterSections();
            loadHonors();
        }));
        document.getElementById('pdfBtn').addEventListener('click', exportPdf);

        // Sidebar
        const sidebar = document.getElementById('stsn-sidebar'), toggleBtn = document.getElementById('stsn-toggle');
        const overlay = document.getElementById('stsn-overlay'), collapseBtn = document.getElementById('stsn-collapse-btn');
        if (sidebar && localStorage.getItem('stsn-sidebar-collapsed') === 'true' && window.innerWidth >= 992) { sidebar.classList.add('collapsed'); document.body.classList.add('sidebar-collapsed'); }
        collapseBtn?.addEventListener('click', e => { e.stopPropagation(); sidebar.classList.toggle('collapsed'); const c = sidebar.classList.contains('collapsed'); document.body.classList.toggle('sidebar-collapsed', c); localStorage.setItem('stsn-sidebar-collapsed', c); });
        toggleBtn?.addEventListener('click', () => { sidebar.classList.toggle('mobile-open'); overlay.classList.toggle('visible'); });
        overlay?.addEventListener('click', () => { sidebar.classList.remove('mobile-open'); overlay.classList.remove('visible'); });
        window.addEventListener('resize', () => { if (!sidebar) return; if (window.innerWidth >= 992) { sidebar.classList.remove('mobile-open'); overlay.classList.remove('visible'); } else document.body.classList.remove('sidebar-collapsed'); });

        filterSections();
        loadHonors();
        refreshTimer = window.setInterval(loadHonors, 30000);
        window.addEventListener('beforeunload', () => window.clearInterval(refreshTimer));
    </script>
</body>
</html>
