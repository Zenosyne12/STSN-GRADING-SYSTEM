<?php
require_once __DIR__ . '/../api/login/teacher_auth.php';

$studentId = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
$teacherName = $_SESSION['teacher_name'] ?? 'Teacher';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Grades | STSN Grading System</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: "Plus Jakarta Sans", sans-serif;
            background: #F5F7FA;
            color: #1E2A3E;
            padding: 24px;
        }
        .card {
            max-width: 900px;
            margin: 0 auto;
            background: #fff;
            border-radius: 18px;
            padding: 24px;
            box-shadow: 0 10px 30px rgba(10, 47, 68, 0.08);
        }
        .back-link {
            display: inline-block;
            margin-bottom: 16px;
            text-decoration: none;
            color: #0A2F44;
            font-weight: 700;
        }
        h1 {
            margin: 0 0 8px;
            color: #0A2F44;
        }
        p {
            color: #6C757D;
        }
        .meta {
            margin-top: 18px;
            padding: 14px 16px;
            border-radius: 12px;
            background: #F8F9FA;
        }
    </style>
</head>
<body>
    <div class="card">
        <a class="back-link" href="My-Advisory.php">← Back to My Advisory</a>
        <h1>Student Grades</h1>
        <p>This page is ready to receive the selected student.</p>

        <div class="meta">
            <strong>Logged in Teacher:</strong> <?php echo htmlspecialchars($teacherName); ?><br>
            <strong>Student ID:</strong> <?php echo htmlspecialchars((string)$studentId); ?>
        </div>

        <p style="margin-top: 18px;">
            Next step is to connect this page to your grades table and show the student’s subjects and quarterly grades.
        </p>
    </div>
</body>
</html>