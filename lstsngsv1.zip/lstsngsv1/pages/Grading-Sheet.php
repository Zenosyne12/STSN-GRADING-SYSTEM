<?php
// pages/Grading-Sheet.php
session_start();
require_once '../api/shared/db_connect.php';

// -------------------------------------------------------------------
// Helper functions
// -------------------------------------------------------------------
function getTeacherSections(PDO $pdo, int $teacherId): array {
    $sql = "SELECT DISTINCT s.id, s.section_name, gl.grade_level_name
            FROM (
                SELECT section_id FROM tblsectionadviser WHERE teacher_id = :teacher_id
                UNION
                SELECT section_id FROM tblschedule WHERE teacher_id = :teacher_id2 AND is_active = 1
            ) AS teacher_sections
            JOIN tblsection s ON teacher_sections.section_id = s.id
            JOIN tblgradelevel gl ON s.grade_level_id = gl.id
            ORDER BY gl.grade_level_name, s.section_name";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['teacher_id' => $teacherId, 'teacher_id2' => $teacherId]);
    return $stmt->fetchAll();
}

function getSubjectsForSection(PDO $pdo, int $teacherId, int $sectionId): array {
    $sql = "SELECT DISTINCT sub.id, sub.subject_name
            FROM tblschedule sch
            JOIN tblsubjects sub ON sch.subject_id = sub.id
            WHERE sch.teacher_id = :teacher_id AND sch.section_id = :section_id AND sch.is_active = 1
            ORDER BY sub.subject_name";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['teacher_id' => $teacherId, 'section_id' => $sectionId]);
    return $stmt->fetchAll();
}

function getSectionSubjectInfo(PDO $pdo, int $sectionId, int $subjectId): array {
    $sql = "SELECT s.section_name, gl.grade_level_name, sub.subject_name, ay.year_label as year
            FROM tblsection s
            JOIN tblgradelevel gl ON s.grade_level_id = gl.id
            JOIN tblsubjects sub ON sub.id = :subject_id
            LEFT JOIN tblacademicyear ay ON ay.is_active = 1
            WHERE s.id = :section_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['subject_id' => $subjectId, 'section_id' => $sectionId]);
    $row = $stmt->fetch();
    if ($row) {
        return [
            'section_name' => $row['grade_level_name'] . ' - ' . $row['section_name'],
            'subject_name' => $row['subject_name'],
            'school_year'  => $row['year'] ?? date('Y') . '-' . (date('Y') + 1)
        ];
    }
    return ['section_name' => '', 'subject_name' => '', 'school_year' => date('Y') . '-' . (date('Y') + 1)];
}

// -------------------------------------------------------------------
// Initialise variables
// -------------------------------------------------------------------
$teacherId   = $_SESSION['teacher_id'] ?? 1;
$teacherName = $_SESSION['teacher_name'] ?? 'Teacher';

$sectionId  = isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0;
$subjectId  = isset($_GET['subject_id']) ? (int)$_GET['subject_id'] : 0;
$quarter    = isset($_GET['quarter']) ? (int)$_GET['quarter'] : 1;

$teacherSections = getTeacherSections($pdo, $teacherId);
$subjects        = ($sectionId) ? getSubjectsForSection($pdo, $teacherId, $sectionId) : [];

$sectionName   = '';
$subjectName   = '';
$schoolYear    = date('Y') . '-' . (date('Y') + 1);
if ($sectionId && $subjectId) {
    $info = getSectionSubjectInfo($pdo, $sectionId, $subjectId);
    $sectionName = $info['section_name'];
    $subjectName = $info['subject_name'];
    $schoolYear  = $info['school_year'];
}

$quarterNames = [1 => '1st', 2 => '2nd', 3 => '3rd', 4 => '4th'];
$quarterName  = $quarterNames[$quarter] ?? '1st';

// Determine if controls should be disabled
$isSelectionValid = ($sectionId && $subjectId);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grading Sheet<?= $subjectId ? ' — ' . htmlspecialchars($subjectName) : '' ?> | STSN</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css/index.css">
    <style>
        /* All original CSS remains exactly the same – omitted for brevity */
        :root { --primary: #0A2F44; --primary-soft: rgba(10,47,68,0.08); --accent: #C5A028; --bg: #F5F7FA; --surface: #FFFFFF; --surface-2: #F8F9FA; --text: #1E2A3E; --muted: #6C757D; --border: #E9ECEF; --shadow: 0 10px 30px rgba(10,47,68,0.08); --radius: 18px; --sidebar-width: 260px; --sidebar-collapsed-width: 72px; --ww-bg: #EBF4FF; --ww-text: #185FA5; --pt-bg: #F4EEFF; --pt-text: #534AB7; --qa-bg: #EAFAF3; --qa-text: #0F6E56; --gr-bg: #FFF8E1; --gr-text: #855E00; }
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html, body { height: 100%; }
        body.stsn-layout { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); color: var(--text); overflow: hidden; }
        #stsn-toggle { position: fixed; top: 1rem; left: 1rem; z-index: 1100; width: 44px; height: 44px; border: 1px solid var(--border); border-radius: 12px; background: #fff; color: var(--primary); display: none; align-items: center; justify-content: center; box-shadow: var(--shadow); cursor: pointer; }
        #stsn-overlay { position: fixed; inset: 0; background: rgba(15,23,42,0.35); opacity: 0; visibility: hidden; transition: 0.25s ease; z-index: 1035; }
        #stsn-overlay.visible { opacity: 1; visibility: visible; }
        .page-shell { margin-left: var(--sidebar-width); height: 100vh; transition: margin-left 0.28s ease; display: flex; flex-direction: column; overflow: hidden; }
        body.sidebar-collapsed .page-shell { margin-left: var(--sidebar-collapsed-width); }
        .top-bar { background: var(--surface); border-bottom: 1px solid var(--border); padding: 0.85rem 1.5rem; display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap; flex-shrink: 0; position: sticky; top: 0; z-index: 50; }
        .top-bar-left h1 { font-size: 1.25rem; font-weight: 800; color: var(--primary); display: flex; align-items: center; gap: 0.5rem; }
        .top-bar-left p { font-size: 0.82rem; color: var(--muted); margin-top: 3px; }
        .top-bar-right { display: flex; gap: 0.55rem; align-items: center; flex-wrap: wrap; }
        .meta-chip { background: #fff; border: 1px solid var(--border); border-radius: 999px; padding: 0.45rem 0.8rem; font-size: 0.78rem; color: var(--muted); display: inline-flex; align-items: center; gap: 5px; white-space: nowrap; }
        .btn { display: inline-flex; align-items: center; gap: 6px; padding: 0.6rem 1.1rem; border-radius: 12px; font-family: inherit; font-size: 0.85rem; font-weight: 700; cursor: pointer; border: 1px solid var(--border); transition: background 0.18s, border-color 0.18s; }
        .btn-primary { background: var(--primary); color: #fff; border-color: var(--primary); }
        .btn-primary:hover:not(:disabled) { background: #0d3b56; border-color: #0d3b56; }
        .btn-secondary { background: #fff; color: var(--primary); }
        .btn-secondary:hover { background: var(--surface-2); }
        .btn:disabled { opacity: 0.55; cursor: not-allowed; }
        .toolbar { background: var(--surface); border-bottom: 1px solid var(--border); padding: 0.75rem 1.5rem; display: flex; gap: 0.65rem; align-items: center; flex-wrap: wrap; flex-shrink: 0; }
        .toolbar-group { display: flex; align-items: center; gap: 6px; }
        .toolbar-label { font-size: 0.78rem; font-weight: 700; color: var(--muted); white-space: nowrap; }
        .toolbar select, .toolbar input[type="text"] { border: 1px solid var(--border); background: #fff; border-radius: 12px; padding: 0.6rem 0.85rem; font-family: inherit; font-size: 0.85rem; color: var(--text); transition: border-color 0.18s; }
        .toolbar select:focus, .toolbar input[type="text"]:focus { outline: none; border-color: var(--primary); }
        .toolbar .search-wrap { margin-left: auto; }
        .page-main { flex: 1; min-height: 0; padding: 1.25rem 1.5rem 1.5rem; display: flex; flex-direction: column; gap: 1rem; overflow: hidden; }
        .workspace { flex: 1; min-height: 0; display: grid; grid-template-columns: minmax(0, 1fr) 290px; gap: 1rem; }
        .panel { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); box-shadow: var(--shadow); }
        .main-panel { overflow: hidden; display: flex; flex-direction: column; }
        .panel-header { padding: 1rem 1.25rem; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap; flex-shrink: 0; }
        .panel-title { display: flex; align-items: center; gap: 0.5rem; font-size: 1rem; font-weight: 700; color: var(--primary); }
        .panel-title i { color: var(--accent); font-size: 15px; }
        .panel-sub { font-size: 0.8rem; color: var(--muted); margin-top: 0.2rem; }
        .summary-pills { display: flex; gap: 0.45rem; flex-wrap: wrap; }
        .pill { display: inline-flex; align-items: center; gap: 4px; padding: 0.35rem 0.65rem; border-radius: 999px; font-size: 0.75rem; font-weight: 700; }
        .pill-ww { background: var(--ww-bg); color: var(--ww-text); }
        .pill-pt { background: var(--pt-bg); color: var(--pt-text); }
        .pill-qa { background: var(--qa-bg); color: var(--qa-text); }
        .pill-neu { background: var(--surface-2); color: var(--muted); }
        .table-wrap { flex: 1; min-height: 0; overflow: auto; }
        .grading-table { width: 100%; border-collapse: collapse; min-width: 1600px; font-size: 12px; }
        .grading-table thead th { position: sticky; top: 0; z-index: 3; border: 1px solid var(--border); padding: 0; font-family: inherit; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; }
        .th-inner { display: block; padding: 0.65rem 0.5rem; }
        .th-def { background: var(--surface-2); color: var(--muted); }
        .th-ww { background: var(--ww-bg); color: var(--ww-text); }
        .th-pt { background: var(--pt-bg); color: var(--pt-text); }
        .th-qa { background: var(--qa-bg); color: var(--qa-text); }
        .th-gr { background: var(--gr-bg); color: var(--gr-text); }
        .max-row th { position: sticky; top: 42px; z-index: 3; border: 1px solid var(--border); padding: 4px 3px; }
        .max-input { width: 48px; padding: 3px 4px; border: 1px solid var(--accent); border-radius: 6px; text-align: center; font-weight: 700; font-size: 11px; color: var(--gr-text); background: #FFFBEF; font-family: inherit; }
        .max-input:focus { outline: none; border-color: var(--primary); }
        .grading-table tbody td { border: 1px solid #f0f2f5; padding: 0.7rem 0.4rem; text-align: center; vertical-align: middle; }
        .grading-table tbody tr:hover td { background: #fafbff; }
        .col-num { width: 42px; background: var(--surface-2); font-weight: 700; color: var(--muted); font-size: 12px; }
        .col-name { text-align: left !important; padding-left: 1rem !important; min-width: 210px; background: var(--surface-2); }
        .student-name { font-weight: 700; color: var(--text); font-size: 13px; }
        .student-sub { display: block; font-size: 11px; color: var(--muted); margin-top: 2px; }
        .score-input { width: 50px; border: none; background: transparent; text-align: center; font-size: 13px; font-weight: 600; padding: 7px 2px; font-family: inherit; color: var(--text); }
        .score-input:focus { outline: 2px solid var(--primary); border-radius: 6px; background: var(--primary-soft); }
        .cell-total { background: var(--surface-2); font-weight: 700; font-size: 12px; }
        .cell-ps { background: var(--qa-bg); font-weight: 700; color: var(--qa-text); font-size: 12px; }
        .cell-ws { background: var(--gr-bg); font-weight: 700; color: var(--gr-text); font-size: 12px; }
        .cell-initial { background: var(--ww-bg); font-weight: 800; color: var(--ww-text); font-size: 14px; }
        .cell-final { background: var(--primary-soft); font-weight: 800; color: var(--primary); font-size: 15px; }
        .badge { display: inline-block; padding: 3px 10px; border-radius: 999px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
        .badge-passed { background: var(--qa-bg); color: var(--qa-text); }
        .badge-failed { background: #FCEBEB; color: #A32D2D; }
        .summary-row td { background: var(--primary-soft); font-weight: 700; color: var(--primary); border-top: 2px solid var(--primary) !important; padding: 0.85rem 0.4rem; font-size: 13px; }
        .side-stack { display: flex; flex-direction: column; gap: 1rem; overflow-y: auto; }
        .side-panel { padding: 1.1rem 1.15rem 1.2rem; }
        .info-grid { display: grid; gap: 0.65rem; margin-top: 0.85rem; }
        .info-box { padding: 0.8rem; border-radius: 14px; background: var(--surface-2); }
        .info-label { font-size: 0.75rem; color: var(--muted); font-weight: 600; margin-bottom: 0.2rem; }
        .info-value { font-size: 1rem; color: var(--text); font-weight: 700; }
        .info-value.passed { color: var(--qa-text); }
        .info-value.failed { color: #A32D2D; }
        .legend-list { display: grid; gap: 0.5rem; margin-top: 0.85rem; }
        .legend-item { display: flex; align-items: center; gap: 8px; font-size: 0.81rem; color: var(--muted); }
        .legend-dot { width: 12px; height: 12px; border-radius: 3px; flex-shrink: 0; }
        .empty-state { padding: 3.5rem 1rem; text-align: center; color: var(--muted); font-size: 0.93rem; }
        .empty-state i { font-size: 2.5rem; display: block; margin-bottom: 0.75rem; color: #C8CFD8; }
        .toast { position: fixed; bottom: 1.25rem; right: 1.25rem; z-index: 9999; background: var(--primary); color: #fff; padding: 0.85rem 1.25rem; border-radius: 14px; display: flex; align-items: center; gap: 8px; font-size: 0.88rem; font-weight: 600; opacity: 0; transform: translateY(12px); transition: opacity 0.28s, transform 0.28s; pointer-events: none; }
        .toast.show { opacity: 1; transform: translateY(0); pointer-events: auto; }
        .toast.error { background: #A32D2D; }
        .toast.success { background: #0F6E56; }
        .spinner { width: 15px; height: 15px; border: 2px solid rgba(255,255,255,0.4); border-top-color: #fff; border-radius: 50%; animation: spin 0.7s linear infinite; display: inline-block; }
        @keyframes spin { to { transform: rotate(360deg); } }
        @media (max-width: 1200px) { .workspace { grid-template-columns: 1fr; } .side-stack { flex-direction: row; overflow-x: auto; } .side-panel { min-width: 240px; } }
        @media (max-width: 991.98px) { body.stsn-layout { overflow: auto; } #stsn-toggle { display: inline-flex; } .page-shell, body.sidebar-collapsed .page-shell { margin-left: 0; height: auto; min-height: 100vh; } .page-main { overflow: visible; height: auto; padding-top: 0.75rem; } .workspace { grid-template-columns: 1fr; } .main-panel, .table-wrap { overflow: visible; } }
    </style>
</head>
<body class="stsn-layout">
<button id="stsn-toggle" aria-label="Toggle sidebar"><i class="bi bi-list"></i></button>
<div id="stsn-overlay"></div>

<?php include __DIR__ . '/../includes/teacher-sidebar.php'; ?>

<div class="page-shell">
    <header class="top-bar">
        <div class="top-bar-left">
            <h1><i class="bi bi-journal-text" style="color: var(--accent);"></i> Grading Sheet</h1>
            <p id="topBarSub">
                <?php if ($isSelectionValid): ?>
                    <?= htmlspecialchars("$subjectName · $sectionName · {$quarterName} Quarter") ?>
                <?php else: ?>
                    Select a section and subject to start grading
                <?php endif; ?>
            </p>
        </div>
        <div class="top-bar-right">
            <div class="meta-chip"><i class="bi bi-person-badge"></i> <?= htmlspecialchars($teacherName) ?></div>
            <div class="meta-chip"><i class="bi bi-calendar3"></i> <?= htmlspecialchars($schoolYear) ?></div>
            <button class="btn btn-secondary" onclick="goBack()"><i class="bi bi-arrow-left"></i> Back</button>
            <button class="btn btn-primary" id="saveBtn" onclick="saveSheet()" <?= $isSelectionValid ? '' : 'disabled' ?>>
                <i class="bi bi-save2"></i> Save Grades
            </button>
        </div>
    </header>

    <div class="toolbar">
        <div class="toolbar-group">
            <span class="toolbar-label"><i class="bi bi-grid-3x3-gap-fill"></i> Section</span>
            <select id="sectionSelect" onchange="changeSection()">
                <option value="">— Select Section —</option>
                <?php foreach ($teacherSections as $sec): ?>
                    <option value="<?= $sec['id'] ?>" <?= $sectionId == $sec['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($sec['grade_level_name'] . ' - ' . $sec['section_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="toolbar-group">
            <span class="toolbar-label"><i class="bi bi-book-half"></i> Subject</span>
            <select id="subjectSelect" onchange="changeSubject()" <?= !$sectionId ? 'disabled' : '' ?>>
                <option value="">— Select Subject —</option>
                <?php foreach ($subjects as $subj): ?>
                    <option value="<?= $subj['id'] ?>" <?= $subjectId == $subj['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($subj['subject_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="toolbar-group">
            <span class="toolbar-label"><i class="bi bi-calendar-week"></i> Quarter</span>
            <select id="quarterSelect" onchange="changeQuarter()">
                <option value="1" <?= $quarter == 1 ? 'selected' : '' ?>>1st Quarter</option>
                <option value="2" <?= $quarter == 2 ? 'selected' : '' ?>>2nd Quarter</option>
                <option value="3" <?= $quarter == 3 ? 'selected' : '' ?>>3rd Quarter</option>
                <option value="4" <?= $quarter == 4 ? 'selected' : '' ?>>4th Quarter</option>
            </select>
        </div>
        <div class="toolbar-group" style="margin-left: auto; gap: 8px;">
            <select id="filterStatus" onchange="applyFilter()">
                <option value="">All Students</option>
                <option value="Passed">Passed Only</option>
                <option value="Failed">Failed Only</option>
            </select>
            <input type="text" id="searchStudent" placeholder="🔍 Search student…" oninput="applyFilter()" style="width: 210px;">
        </div>
    </div>

    <main class="page-main">
        <div class="workspace">
            <div class="panel main-panel">
                <div class="panel-header">
                    <div>
                        <div class="panel-title"><i class="bi bi-table"></i> <span id="panelTitle"><?= $isSelectionValid ? htmlspecialchars("$subjectName — $sectionName") : 'No Section Selected' ?></span></div>
                        <div class="panel-sub"><span id="panelQuarter"><?= $quarterName ?></span> Quarter grading sheet &nbsp;·&nbsp; S.Y. <?= htmlspecialchars($schoolYear) ?></div>
                    </div>
                    <div class="summary-pills">
                        <span class="pill pill-ww" id="pillWW">WW 40%</span>
                        <span class="pill pill-pt" id="pillPT">PT 40%</span>
                        <span class="pill pill-qa" id="pillQA">QA 20%</span>
                        <span class="pill pill-neu"><i class="bi bi-people-fill"></i> <span id="studentCountPill">0</span> Students</span>
                    </div>
                </div>
                <div class="table-wrap">
                    <table class="grading-table" id="gradingTable">
                        <thead>
                            <tr><th rowspan="3" class="th-def"><span class="th-inner">#</span></th>
                                <th rowspan="3" class="th-def" style="text-align:left;"><span class="th-inner">Student Name</span></th>
                                <th colspan="13" class="th-ww"><span class="th-inner" id="wwLabel">Written Works (40%)</span></th>
                                <th colspan="13" class="th-pt"><span class="th-inner" id="ptLabel">Performance Tasks (40%)</span></th>
                                <th colspan="4" class="th-qa"><span class="th-inner" id="qaLabel">Quarterly Assessment (20%)</span></th>
                                <th rowspan="3" class="th-gr"><span class="th-inner">Initial<br>Grade</span></th>
                                <th rowspan="3" class="th-gr"><span class="th-inner">Final<br>Grade</span></th>
                                <th rowspan="3" class="th-gr"><span class="th-inner">Remarks</span></th>
                            </tr>
                            <tr class="max-row">
                                <th colspan="13" class="th-ww" style="font-size:10px; font-style:italic;">Highest Possible Score</th>
                                <th colspan="13" class="th-pt" style="font-size:10px; font-style:italic;">Highest Possible Score</th>
                                <th colspan="4" class="th-qa" style="font-size:10px; font-style:italic;">Highest Possible Score</th>
                            </tr>
                            <tr id="colHeaderRow"></tr>
                        </thead>
                        <tbody id="tableBody">
                            <?php if (!$isSelectionValid): ?>
                                <tr><td colspan="32"><div class="empty-state"><i class="bi bi-arrow-up-circle"></i> Please select a section and subject to load the grading sheet.</div></td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="side-stack">
                <div class="panel side-panel">
                    <div class="panel-title"><i class="bi bi-info-circle-fill"></i> Section Info</div>
                    <div class="info-grid">
                        <div class="info-box"><div class="info-label">Section</div><div class="info-value" id="infoSection"><?= htmlspecialchars($sectionName ?: '—') ?></div></div>
                        <div class="info-box"><div class="info-label">Subject</div><div class="info-value" id="infoSubject"><?= htmlspecialchars($subjectName ?: '—') ?></div></div>
                        <div class="info-box"><div class="info-label">Quarter</div><div class="info-value" id="infoQuarter"><?= $quarterName ?> Quarter</div></div>
                        <div class="info-box"><div class="info-label">Total Students</div><div class="info-value" id="infoTotal">0</div></div>
                    </div>
                </div>
                <div class="panel side-panel">
                    <div class="panel-title"><i class="bi bi-bar-chart-fill"></i> Class Summary</div>
                    <div class="info-grid">
                        <div class="info-box"><div class="info-label">Class Average (Final)</div><div class="info-value" id="infoClassAve">—</div></div>
                        <div class="info-box"><div class="info-label">Mean Percentage Score</div><div class="info-value" id="infoMPS">—</div></div>
                        <div class="info-box"><div class="info-label">Passed</div><div class="info-value passed" id="infoPassed">—</div></div>
                        <div class="info-box"><div class="info-label">Failed</div><div class="info-value failed" id="infoFailed">—</div></div>
                    </div>
                </div>
                <div class="panel side-panel">
                    <div class="panel-title"><i class="bi bi-bookmarks-fill"></i> Legend</div>
                    <div class="legend-list">
                        <div class="legend-item"><div class="legend-dot" style="background:var(--ww-bg); border:1px solid var(--ww-text);"></div><span><strong>WW</strong> = Written Works</span></div>
                        <div class="legend-item"><div class="legend-dot" style="background:var(--pt-bg); border:1px solid var(--pt-text);"></div><span><strong>PT</strong> = Performance Tasks</span></div>
                        <div class="legend-item"><div class="legend-dot" style="background:var(--qa-bg); border:1px solid var(--qa-text);"></div><span><strong>QA</strong> = Quarterly Assessment</span></div>
                        <div class="legend-item" style="margin-top:6px;"><span style="font-size:0.78rem;"><strong>PS</strong> = Percentage Score</span></div>
                        <div class="legend-item"><span style="font-size:0.78rem;"><strong>WS</strong> = Weighted Score</span></div>
                        <div class="legend-item"><span style="font-size:0.78rem;"><strong>MPS</strong> = Mean Percentage Score</span></div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<div class="toast" id="toast"><i class="bi bi-check-circle-fill" id="toastIcon"></i> <span id="toastMsg">Saved</span></div>

<script>
    // Pass PHP variables to JavaScript
    const teacherId = <?= $teacherId ?>;
    let sectionId = <?= $sectionId ?>;
    let subjectId = <?= $subjectId ?>;
    let currentQuarter = <?= $quarter ?>;
    let maxScores = { ww: [10,10,20,20,50,50,100,100,100,100], pt: [50,50,50,50,100,100,100,100,100,100], qa: [100] };
    let weights = { ww: 40, pt: 40, qa: 20 };
    let studentsData = [];

    document.addEventListener('DOMContentLoaded', () => {
        initSidebar();
        if (sectionId && subjectId) loadStudents();
    });

    function changeSection() {
        const val = document.getElementById('sectionSelect').value;
        window.location.href = val ? `Grading-Sheet.php?section_id=${val}&quarter=${currentQuarter}` : `Grading-Sheet.php?quarter=${currentQuarter}`;
    }
    function changeSubject() {
        const val = document.getElementById('subjectSelect').value;
        if (val && sectionId) window.location.href = `Grading-Sheet.php?section_id=${sectionId}&subject_id=${val}&quarter=${currentQuarter}`;
    }
    function changeQuarter() {
        currentQuarter = document.getElementById('quarterSelect').value;
        let url = `Grading-Sheet.php?quarter=${currentQuarter}`;
        if (sectionId) url += `&section_id=${sectionId}`;
        if (subjectId) url += `&subject_id=${subjectId}`;
        window.location.href = url;
    }
    function goBack() { window.location.href = 'My-Subjects.php'; }

    async function loadStudents() {
        try {
            const res = await fetch(`../api/grading/get_students.php?section_id=${sectionId}&subject_id=${subjectId}&quarter=${currentQuarter}`);
            const data = await res.json();
            if (data.success) {
                studentsData = data.students;
                if (data.max_scores) maxScores = data.max_scores;
                if (data.weights) { weights = data.weights; updateWeightLabels(); }
                renderTable();
                updateSidePanelInfo();
                document.getElementById('saveBtn').disabled = false;
            } else showToast(data.error || 'Failed to load students', 'error');
        } catch (e) { console.error(e); showToast('Failed to load students', 'error'); }
    }

    function updateWeightLabels() {
        document.getElementById('wwLabel').textContent = `Written Works (${weights.ww}%)`;
        document.getElementById('ptLabel').textContent = `Performance Tasks (${weights.pt}%)`;
        document.getElementById('qaLabel').textContent = `Quarterly Assessment (${weights.qa}%)`;
        document.getElementById('pillWW').textContent = `WW ${weights.ww}%`;
        document.getElementById('pillPT').textContent = `PT ${weights.pt}%`;
        document.getElementById('pillQA').textContent = `QA ${weights.qa}%`;
    }

    function renderTable() {
        buildColumnHeaders();
        const tbody = document.getElementById('tableBody');
        if (!studentsData.length) {
            tbody.innerHTML = `<tr><td colspan="32"><div class="empty-state"><i class="bi bi-inbox"></i>No students found in this section.</div></td></tr>`;
            return;
        }
        let html = '';
        studentsData.forEach((student, idx) => {
            const s = student.scores, t = student.totals, p = student.ps, w = student.ws;
            const passed = student.remarks === 'Passed';
            html += `<tr data-status="${student.remarks}" data-student-id="${student.student_id}">
                <td class="col-num">${idx+1}</td>
                <td class="col-name"><div class="student-name">${escapeHtml(student.name)}</div><span class="student-sub">ID: ${student.student_id}</span></td>`;
            for (let i = 0; i < 10; i++) html += `<td><input type="number" class="score-input ww-score" value="${s.ww[i]}" min="0" onchange="calculateRow(this)" data-type="ww" data-index="${i}"></td>`;
            html += `<td class="cell-total ww-total">${t.ww}</td><td class="cell-ps ww-ps">${p.ww}</td><td class="cell-ws ww-ws">${w.ww}</td>`;
            for (let i = 0; i < 10; i++) html += `<td><input type="number" class="score-input pt-score" value="${s.pt[i]}" min="0" onchange="calculateRow(this)" data-type="pt" data-index="${i}"></td>`;
            html += `<td class="cell-total pt-total">${t.pt}</td><td class="cell-ps pt-ps">${p.pt}</td><td class="cell-ws pt-ws">${w.pt}</td>`;
            html += `<td><input type="number" class="score-input qa-score" value="${s.qa[0]}" min="0" onchange="calculateRow(this)" data-type="qa" data-index="0"></td>
                <td class="cell-total qa-total">${t.qa}</td><td class="cell-ps qa-ps">${p.qa}</td><td class="cell-ws qa-ws">${w.qa}</td>
                <td class="cell-initial">${student.initial_grade}</td><td class="cell-final">${student.final_grade}</td>
                <td><span class="badge ${passed ? 'badge-passed' : 'badge-failed'}">${student.remarks}</span></td>
            </tr>`;
        });
        html += `<tr class="summary-row"><td colspan="2" style="text-align:left; padding-left:1rem;">Class Summary</td>
            <td colspan="10" style="text-align:center;">Written Works</td><td colspan="3"></td>
            <td colspan="10" style="text-align:center;">Performance Tasks</td><td colspan="3"></td>
            <td colspan="1" style="text-align:center;">QA</td><td colspan="3"></td>
            <td colspan="2" id="summaryAve" style="text-align:center;">—</td><td id="summaryMPS" style="text-align:center;">—</td>
        </tr>`;
        tbody.innerHTML = html;
        updateClassSummary();
        document.getElementById('studentCountPill').textContent = studentsData.length;
        document.getElementById('infoTotal').textContent = studentsData.length;
    }

    function buildColumnHeaders() {
        const row = document.getElementById('colHeaderRow');
        let html = '';
        for (let i = 0; i < 10; i++) html += `<th class="th-ww"><span class="th-inner">WW${i+1}<br><input type="number" class="max-input" id="maxWW${i}" value="${maxScores.ww[i]}" onchange="updateMaxScore('ww',${i},this.value)"></span></th>`;
        html += `<th class="th-ww"><span class="th-inner">Total</span></th><th class="th-ww"><span class="th-inner">PS</span></th><th class="th-ww"><span class="th-inner">WS</span></th>`;
        for (let i = 0; i < 10; i++) html += `<th class="th-pt"><span class="th-inner">PT${i+1}<br><input type="number" class="max-input" id="maxPT${i}" value="${maxScores.pt[i]}" onchange="updateMaxScore('pt',${i},this.value)"></span></th>`;
        html += `<th class="th-pt"><span class="th-inner">Total</span></th><th class="th-pt"><span class="th-inner">PS</span></th><th class="th-pt"><span class="th-inner">WS</span></th>`;
        html += `<th class="th-qa"><span class="th-inner">QA<br><input type="number" class="max-input" id="maxQA0" value="${maxScores.qa[0]}" onchange="updateMaxScore('qa',0,this.value)"></span></th>
                <th class="th-qa"><span class="th-inner">Total</span></th><th class="th-qa"><span class="th-inner">PS</span></th><th class="th-qa"><span class="th-inner">WS</span></th>`;
        row.innerHTML = html;
    }

    function updateMaxScore(type, index, value) {
        maxScores[type][index] = parseInt(value) || 1;
        recalculateAll();
        showToast('Max score updated — all grades recalculated');
    }
    function recalculateAll() {
        document.querySelectorAll('#tableBody tr:not(.summary-row)').forEach(row => { if (row.querySelector('.score-input')) calculateRow(row.querySelector('.score-input')); });
    }

    function calculateRow(input) {
        const row = input.closest('tr');
        const sid = row.dataset.studentId;
        const wwInputs = row.querySelectorAll('.ww-score');
        let wwTotal = 0, wwMax = 0;
        wwInputs.forEach((el,i) => { wwTotal += +el.value||0; wwMax += maxScores.ww[i]||100; });
        const wwPS = wwMax ? ((wwTotal/wwMax)*100).toFixed(2) : 0;
        const wwWS = (wwPS * weights.ww / 100).toFixed(2);
        const ptInputs = row.querySelectorAll('.pt-score');
        let ptTotal = 0, ptMax = 0;
        ptInputs.forEach((el,i) => { ptTotal += +el.value||0; ptMax += maxScores.pt[i]||100; });
        const ptPS = ptMax ? ((ptTotal/ptMax)*100).toFixed(2) : 0;
        const ptWS = (ptPS * weights.pt / 100).toFixed(2);
        const qaInputs = row.querySelectorAll('.qa-score');
        let qaTotal = 0;
        qaInputs.forEach(el => { qaTotal += +el.value||0; });
        const qaMax = maxScores.qa[0]||100;
        const qaPS = qaMax ? ((qaTotal/qaMax)*100).toFixed(2) : 0;
        const qaWS = (qaPS * weights.qa / 100).toFixed(2);

        row.querySelector('.ww-total').textContent = wwTotal;
        row.querySelector('.ww-ps').textContent = wwPS;
        row.querySelector('.ww-ws').textContent = wwWS;
        row.querySelector('.pt-total').textContent = ptTotal;
        row.querySelector('.pt-ps').textContent = ptPS;
        row.querySelector('.pt-ws').textContent = ptWS;
        row.querySelector('.qa-total').textContent = qaTotal;
        row.querySelector('.qa-ps').textContent = qaPS;
        row.querySelector('.qa-ws').textContent = qaWS;

        const initial = (+wwWS + +ptWS + +qaWS).toFixed(2);
        const final = transmuteGrade(+initial);
        const passed = final >= 75;
        row.querySelector('.cell-initial').textContent = initial;
        row.querySelector('.cell-final').textContent = final;
        const badge = row.querySelector('.badge');
        badge.textContent = passed ? 'Passed' : 'Failed';
        badge.className = 'badge ' + (passed ? 'badge-passed' : 'badge-failed');
        row.dataset.status = passed ? 'Passed' : 'Failed';

        const sd = studentsData.find(s => s.student_id == sid);
        if (sd) {
            sd.scores.ww = Array.from(wwInputs).map(el => +el.value||0);
            sd.scores.pt = Array.from(ptInputs).map(el => +el.value||0);
            sd.scores.qa = [+qaInputs[0]?.value||0];
            sd.initial_grade = +initial;
            sd.final_grade = final;
            sd.remarks = passed ? 'Passed' : 'Failed';
        }
        updateClassSummary();
    }

    function transmuteGrade(init) {
        const table = [[100,100],[98.40,99],[96.80,98],[95.20,97],[93.60,96],[92.00,95],[90.40,94],[88.80,93],[87.20,92],[85.60,91],[84.00,90],[82.40,89],[80.80,88],[79.20,87],[77.60,86],[76.00,85],[74.40,84],[72.80,83],[71.20,82],[69.60,81],[68.00,80],[66.40,79],[64.80,78],[63.20,77],[61.60,76],[60.00,75],[56.00,74],[52.00,73],[48.00,72],[44.00,71],[40.00,70],[36.00,69],[32.00,68],[28.00,67],[24.00,66],[20.00,65],[16.00,64],[12.00,63],[8.00,62],[4.00,61],[0,60]];
        for (const [min, grade] of table) if (init >= min) return grade;
        return 60;
    }

    function updateClassSummary() {
        const rows = document.querySelectorAll('#tableBody tr:not(.summary-row)');
        let totalInit = 0, count = 0, passed = 0, failed = 0;
        rows.forEach(row => {
            if (row.style.display === 'none') return;
            const init = parseFloat(row.querySelector('.cell-initial')?.textContent) || 0;
            totalInit += init; count++;
            if (row.dataset.status === 'Passed') passed++; else failed++;
        });
        const mps = count ? (totalInit / count).toFixed(2) : '—';
        const classAve = count ? transmuteGrade(+mps) : '—';
        document.getElementById('infoClassAve').textContent = classAve;
        document.getElementById('infoMPS').textContent = mps;
        document.getElementById('infoPassed').textContent = passed;
        document.getElementById('infoFailed').textContent = failed;
        const aveCell = document.getElementById('summaryAve');
        const mpsCell = document.getElementById('summaryMPS');
        if (aveCell) aveCell.textContent = count ? 'Class Ave: ' + classAve : '—';
        if (mpsCell) mpsCell.textContent = count ? 'MPS: ' + mps : '—';
    }

    function updateSidePanelInfo() {
        const sOpt = document.getElementById('sectionSelect');
        const subOpt = document.getElementById('subjectSelect');
        document.getElementById('infoSection').textContent = sOpt?.options[sOpt.selectedIndex]?.text || '—';
        document.getElementById('infoSubject').textContent = subOpt?.options[subOpt.selectedIndex]?.text || '—';
    }

    function applyFilter() {
        const search = document.getElementById('searchStudent').value.toLowerCase();
        const status = document.getElementById('filterStatus').value;
        document.querySelectorAll('#tableBody tr:not(.summary-row)').forEach(row => {
            const name = row.querySelector('.student-name')?.textContent.toLowerCase() || '';
            const matchSearch = !search || name.includes(search);
            const matchStatus = !status || row.dataset.status === status;
            row.style.display = (matchSearch && matchStatus) ? '' : 'none';
        });
        updateClassSummary();
    }

    async function saveSheet() {
        const btn = document.getElementById('saveBtn');
        const orig = btn.innerHTML;
        btn.innerHTML = '<span class="spinner"></span> Saving…';
        btn.disabled = true;
        const payload = {
            section_id: sectionId, subject_id: subjectId, teacher_id: teacherId, quarter: currentQuarter,
            grades: studentsData.map(s => ({ student_id: s.student_id, ww: s.scores.ww, pt: s.scores.pt, qa: s.scores.qa })),
            max_scores: maxScores, weights: weights
        };
        try {
            const res = await fetch('../api/grading/save_grades.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
            const result = await res.json();
            showToast(result.success ? `Saved ${result.saved_count} student record(s)` : (result.error || 'Save failed'), result.success ? 'success' : 'error');
        } catch (e) { console.error(e); showToast('Failed to save grades', 'error'); }
        finally { btn.innerHTML = orig; btn.disabled = false; }
    }

    let toastTimer;
    function showToast(msg, type = 'success', duration = 3200) {
        clearTimeout(toastTimer);
        const toast = document.getElementById('toast');
        const icon = document.getElementById('toastIcon');
        const text = document.getElementById('toastMsg');
        text.textContent = msg;
        icon.className = type === 'error' ? 'bi bi-exclamation-circle-fill' : 'bi bi-check-circle-fill';
        toast.className = 'toast ' + type + ' show';
        toastTimer = setTimeout(() => toast.classList.remove('show'), duration);
    }

    function initSidebar() {
        const sidebar = document.getElementById('stsn-sidebar');
        const toggleBtn = document.getElementById('stsn-toggle');
        const overlay = document.getElementById('stsn-overlay');
        const collapseBtn = document.getElementById('stsn-collapse-btn');
        if (sidebar && localStorage.getItem('stsn-sidebar-collapsed') === 'true' && window.innerWidth >= 992) {
            sidebar.classList.add('collapsed');
            document.body.classList.add('sidebar-collapsed');
        }
        collapseBtn?.addEventListener('click', e => {
            e.stopPropagation();
            sidebar.classList.toggle('collapsed');
            const isCollapsed = sidebar.classList.contains('collapsed');
            document.body.classList.toggle('sidebar-collapsed', isCollapsed);
            localStorage.setItem('stsn-sidebar-collapsed', isCollapsed);
        });
        toggleBtn?.addEventListener('click', () => { sidebar.classList.toggle('mobile-open'); overlay.classList.toggle('visible'); });
        overlay?.addEventListener('click', () => { sidebar.classList.remove('mobile-open'); overlay.classList.remove('visible'); });
        window.addEventListener('resize', () => {
            if (!sidebar) return;
            if (window.innerWidth >= 992) { sidebar.classList.remove('mobile-open'); overlay.classList.remove('visible'); }
            else document.body.classList.remove('sidebar-collapsed');
        });
    }

    function escapeHtml(str) { return String(str).replace(/[&<>]/g, function(m){ if(m === '&') return '&amp;'; if(m === '<') return '&lt;'; if(m === '>') return '&gt;'; return m;}); }
</script>
</body>
</html>