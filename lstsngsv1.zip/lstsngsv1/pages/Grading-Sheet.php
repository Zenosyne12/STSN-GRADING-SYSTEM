<?php
// pages/Grading-Sheet.php
session_start();
require_once '../api/shared/db_connect.php';

function getTeacherSections(PDO $pdo, int $teacherId): array {
    $sql = "SELECT DISTINCT s.id, s.section_name, gl.grade_level_name
            FROM (
                SELECT section_id FROM tblsectionadviser WHERE teacher_id = :teacher_id
                UNION
                SELECT section_id FROM tblschedule WHERE teacher_id = :teacher_id2 AND is_active = 1
            ) AS teacher_sections
            JOIN tblsection s ON teacher_sections.section_id = s.id
            JOIN tblgradelevel gl ON s.grade_level_id = gl.id
            ORDER BY gl.grade_level_name, s.section_name";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['teacher_id' => $teacherId, 'teacher_id2' => $teacherId]);
    return $stmt->fetchAll();
}

function getSubjectsForSection(PDO $pdo, int $teacherId, int $sectionId): array {
    $sql = "SELECT DISTINCT sub.id, sub.subject_name
            FROM tblschedule sch
            JOIN tblsubjects sub ON sch.subject_id = sub.id
            WHERE sch.teacher_id = :teacher_id AND sch.section_id = :section_id AND sch.is_active = 1
            ORDER BY sub.subject_name";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['teacher_id' => $teacherId, 'section_id' => $sectionId]);
    return $stmt->fetchAll();
}

function getSectionSubjectInfo(PDO $pdo, int $sectionId, int $subjectId): array {
    $sql = "SELECT s.section_name, gl.grade_level_name, sub.subject_name, ay.year_label as year
            FROM tblsection s
            JOIN tblgradelevel gl ON s.grade_level_id = gl.id
            JOIN tblsubjects sub ON sub.id = :subject_id
            LEFT JOIN tblacademicyear ay ON ay.is_active = 1
            WHERE s.id = :section_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['subject_id' => $subjectId, 'section_id' => $sectionId]);
    $row = $stmt->fetch();
    if ($row) {
        return [
            'section_name' => $row['grade_level_name'] . ' - ' . $row['section_name'],
            'subject_name' => $row['subject_name'],
            'school_year'  => $row['year'] ?? date('Y') . '-' . (date('Y') + 1)
        ];
    }
    return ['section_name' => '', 'subject_name' => '', 'school_year' => date('Y') . '-' . (date('Y') + 1)];
}

$teacherId   = $_SESSION['teacher_id'] ?? 1;
$teacherName = $_SESSION['teacher_name'] ?? 'Teacher';

$sectionId  = isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0;
$subjectId  = isset($_GET['subject_id']) ? (int)$_GET['subject_id'] : 0;
$quarter    = isset($_GET['quarter']) ? (int)$_GET['quarter'] : 1;

$teacherSections = getTeacherSections($pdo, $teacherId);
$subjects        = ($sectionId) ? getSubjectsForSection($pdo, $teacherId, $sectionId) : [];

$sectionName   = '';
$subjectName   = '';
$schoolYear    = date('Y') . '-' . (date('Y') + 1);
if ($sectionId && $subjectId) {
    $info = getSectionSubjectInfo($pdo, $sectionId, $subjectId);
    $sectionName = $info['section_name'];
    $subjectName = $info['subject_name'];
    $schoolYear  = $info['school_year'];
}

$quarterNames = [1 => '1st', 2 => '2nd', 3 => '3rd', 4 => '4th'];
$quarterName  = $quarterNames[$quarter] ?? '1st';
$isSelectionValid = ($sectionId && $subjectId);

$wwCount = 10;
$ptCount = 10;
$qaCount = 5;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grading Sheet<?= $subjectId ? ' — ' . htmlspecialchars($subjectName) : '' ?> | STSN</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css/index.css">
    <style>
        :root {
            --primary: #0A2F44; --primary-soft: rgba(10,47,68,0.08); --accent: #C5A028;
            --bg: #F5F7FA; --surface: #FFFFFF; --surface-2: #F8F9FA;
            --text: #1E2A3E; --muted: #6C757D; --border: #E9ECEF;
            --shadow: 0 10px 30px rgba(10,47,68,0.08); --radius: 18px;
            --sidebar-width: 260px; --sidebar-collapsed-width: 72px;
            --ww-bg: #EBF4FF; --ww-text: #185FA5; --ww-border: #B8D8F8;
            --pt-bg: #F4EEFF; --pt-text: #534AB7; --pt-border: #D4C8F8;
            --qa-bg: #EAFAF3; --qa-text: #0F6E56; --qa-border: #A8E6D1;
            --gr-bg: #FFF8E1; --gr-text: #855E00; --gr-border: #F5D87A;
        }
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html, body { height: 100%; }
        body.stsn-layout { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); color: var(--text); overflow: hidden; }

        #stsn-toggle { position: fixed; top: 1rem; left: 1rem; z-index: 1100; width: 44px; height: 44px; border: 1px solid var(--border); border-radius: 12px; background: #fff; color: var(--primary); display: none; align-items: center; justify-content: center; box-shadow: var(--shadow); cursor: pointer; }
        #stsn-overlay { position: fixed; inset: 0; background: rgba(15,23,42,0.35); opacity: 0; visibility: hidden; transition: 0.25s ease; z-index: 1035; }
        #stsn-overlay.visible { opacity: 1; visibility: visible; }
        .page-shell { margin-left: var(--sidebar-width); height: 100vh; transition: margin-left 0.28s ease; display: flex; flex-direction: column; overflow: hidden; }
        body.sidebar-collapsed .page-shell { margin-left: var(--sidebar-collapsed-width); }

        /* â”€â”€ Top Bar â”€â”€ */
        .top-bar { background: var(--surface); border-bottom: 1px solid var(--border); padding: 0.85rem 1.5rem; display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap; flex-shrink: 0; position: sticky; top: 0; z-index: 50; }
        .top-bar-left h1 { font-size: 1.25rem; font-weight: 800; color: var(--primary); display: flex; align-items: center; gap: 0.5rem; }
        .top-bar-left p { font-size: 0.82rem; color: var(--muted); margin-top: 3px; }
        .top-bar-right { display: flex; gap: 0.55rem; align-items: center; flex-wrap: wrap; }
        .meta-chip { background: #fff; border: 1px solid var(--border); border-radius: 999px; padding: 0.45rem 0.8rem; font-size: 0.78rem; color: var(--muted); display: inline-flex; align-items: center; gap: 5px; white-space: nowrap; }

        /* â”€â”€ Buttons â”€â”€ */
        .btn { display: inline-flex; align-items: center; gap: 6px; padding: 0.6rem 1.1rem; border-radius: 12px; font-family: inherit; font-size: 0.85rem; font-weight: 700; cursor: pointer; border: 1px solid var(--border); transition: background 0.18s, border-color 0.18s, transform 0.1s; }
        .btn:active:not(:disabled) { transform: scale(0.97); }
        .btn-primary { background: var(--primary); color: #fff; border-color: var(--primary); }
        .btn-primary:hover:not(:disabled) { background: #0d3b56; border-color: #0d3b56; }
        .btn-secondary { background: #fff; color: var(--primary); }
        .btn-secondary:hover { background: var(--surface-2); }
        .btn-success { background: #0F6E56; color: #fff; border-color: #0F6E56; }
        .btn-success:hover:not(:disabled) { background: #0d5c48; }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; }

        /* â”€â”€ Toolbar â”€â”€ */
        .toolbar { background: var(--surface); border-bottom: 1px solid var(--border); padding: 0.75rem 1.5rem; display: flex; gap: 0.65rem; align-items: center; flex-wrap: wrap; flex-shrink: 0; }
        .toolbar-group { display: flex; align-items: center; gap: 6px; }
        .toolbar-label { font-size: 0.78rem; font-weight: 700; color: var(--muted); white-space: nowrap; }
        .toolbar select, .toolbar input[type="text"] { border: 1px solid var(--border); background: #fff; border-radius: 12px; padding: 0.6rem 0.85rem; font-family: inherit; font-size: 0.85rem; color: var(--text); transition: border-color 0.18s; }
        .toolbar select:focus, .toolbar input:focus { outline: none; border-color: var(--primary); }

        /* â”€â”€ Action bar above table (buttons live here) â”€â”€ */
        .action-bar {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 0.85rem 1.25rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            flex-wrap: wrap;
            margin-bottom: 0.5rem;
            flex-shrink: 0;
        }
        .action-bar-left { display: flex; align-items: center; gap: 0.65rem; flex-wrap: wrap; }
        .action-bar-right { display: flex; align-items: center; gap: 0.55rem; }

        /* â”€â”€ Page layout â”€â”€ */
        .page-main { flex: 1; min-height: 0; padding: 1.25rem 1.5rem 1.5rem; display: flex; flex-direction: column; gap: 1rem; overflow: hidden; }

        /* Workspace: full-width table + narrow sidebar (summary + legend only) */
        .workspace { flex: 1; min-height: 0; display: grid; grid-template-columns: minmax(0, 1fr) 290px; gap: 1rem; }

        .panel { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); box-shadow: var(--shadow); }
        .main-panel { overflow: hidden; display: flex; flex-direction: column; }
        .panel-header { padding: 1rem 1.25rem; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap; flex-shrink: 0; }
        .panel-title { display: flex; align-items: center; gap: 0.5rem; font-size: 1rem; font-weight: 700; color: var(--primary); }
        .panel-title i { color: var(--accent); font-size: 15px; }
        .panel-sub { font-size: 0.8rem; color: var(--muted); margin-top: 0.2rem; }
        .summary-pills { display: flex; gap: 0.45rem; flex-wrap: wrap; }
        .pill { display: inline-flex; align-items: center; gap: 4px; padding: 0.35rem 0.65rem; border-radius: 999px; font-size: 0.75rem; font-weight: 700; }
        .pill-ww { background: var(--ww-bg); color: var(--ww-text); }
        .pill-pt { background: var(--pt-bg); color: var(--pt-text); }
        .pill-qa { background: var(--qa-bg); color: var(--qa-text); }
        .pill-neu { background: var(--surface-2); color: var(--muted); }

        /* â”€â”€ Table â”€â”€ */
        .table-wrap { flex: 1; min-height: 0; overflow: auto; }
        .grading-table { width: 100%; border-collapse: collapse; font-size: 13px; }
        .grading-table thead th { position: sticky; top: 0; z-index: 3; border: 1px solid var(--border); padding: 0.65rem 0.5rem; font-family: inherit; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; text-align: center; }
        .th-def { background: var(--surface-2); color: var(--muted); }
        .th-ww { background: var(--ww-bg); color: var(--ww-text); }
        .th-pt { background: var(--pt-bg); color: var(--pt-text); }
        .th-qa { background: var(--qa-bg); color: var(--qa-text); }
        .th-gr { background: var(--gr-bg); color: var(--gr-text); }
        .grading-table tbody td { border: 1px solid #f0f2f5; padding: 0.75rem 0.5rem; text-align: center; vertical-align: middle; }
        .grading-table tbody tr:hover td { background: #fafbff; }
        .col-num { width: 44px; background: var(--surface-2); font-weight: 700; color: var(--muted); font-size: 12px; }
        .col-name { text-align: left !important; padding-left: 1rem !important; min-width: 200px; background: var(--surface-2); }
        .student-name { font-weight: 700; color: var(--text); font-size: 13px; }
        .student-sub { display: block; font-size: 11px; color: var(--muted); margin-top: 2px; }

        /* â”€â”€ Score inputs â”€â”€ */
        .score-input { width: 90px; border: 1.5px solid var(--border); background: #fff; border-radius: 8px; text-align: center; font-size: 14px; font-weight: 600; padding: 7px 4px; font-family: inherit; color: var(--text); transition: border-color 0.15s, box-shadow 0.15s; }
        .score-input:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(10,47,68,0.08); }
        .score-input:disabled { background: var(--surface-2); color: var(--muted); cursor: not-allowed; }
        .score-input.ww-input:focus { border-color: var(--ww-text); box-shadow: 0 0 0 3px rgba(24,95,165,0.1); }
        .score-input.pt-input:focus { border-color: var(--pt-text); box-shadow: 0 0 0 3px rgba(83,74,183,0.1); }
        .score-input.qa-input:focus { border-color: var(--qa-text); box-shadow: 0 0 0 3px rgba(15,110,86,0.1); }

        /* â”€â”€ Computed cells â”€â”€ */
        .cell-ps { background: rgba(234,250,243,0.5); color: var(--qa-text); font-weight: 600; font-size: 12px; min-width: 54px; }
        .cell-ws { background: rgba(241,240,255,0.5); color: var(--pt-text); font-weight: 600; font-size: 12px; min-width: 54px; }
        .cell-initial { background: var(--ww-bg); font-weight: 800; color: var(--ww-text); font-size: 14px; min-width: 60px; }
        .cell-final { background: var(--primary-soft); font-weight: 800; color: var(--primary); font-size: 15px; min-width: 60px; }
        .badge { display: inline-block; padding: 3px 10px; border-radius: 999px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
        .badge-passed { background: var(--qa-bg); color: var(--qa-text); border: 1px solid var(--qa-border); }
        .badge-failed { background: #FCEBEB; color: #A32D2D; border: 1px solid #F5BCBC; }
        .summary-row td { background: var(--primary-soft); font-weight: 700; color: var(--primary); border-top: 3px solid var(--primary) !important; padding: 0.85rem 0.5rem; font-size: 13px; }

        .imported-badge { display: inline-block; background: #EBF4FF; color: var(--ww-text); border: 1px solid var(--ww-border); border-radius: 6px; font-size: 10px; font-weight: 700; padding: 2px 6px; margin-left: 4px; vertical-align: middle; }


        /* â”€â”€ Right sidebar: summary + legend only â”€â”€ */
        .side-stack { display: flex; flex-direction: column; gap: 1rem; overflow-y: auto; }
        .side-panel { padding: 1.1rem 1.15rem 1.2rem; }
        .info-grid { display: grid; gap: 0.6rem; margin-top: 0.75rem; }
        .info-box { padding: 0.75rem; border-radius: 12px; background: var(--surface-2); }
        .info-label { font-size: 0.72rem; color: var(--muted); font-weight: 600; margin-bottom: 0.15rem; text-transform: uppercase; letter-spacing: 0.05em; }
        .info-value { font-size: 0.95rem; color: var(--text); font-weight: 700; }
        .info-value.passed { color: var(--qa-text); }
        .info-value.failed { color: #A32D2D; }

        .legend-list { display: grid; gap: 0.45rem; margin-top: 0.75rem; }
        .legend-item { display: flex; align-items: center; gap: 8px; font-size: 0.8rem; color: var(--muted); }
        .legend-dot { width: 11px; height: 11px; border-radius: 3px; flex-shrink: 0; }

        /* â”€â”€ Misc â”€â”€ */
        .empty-state { padding: 3rem 1rem; text-align: center; color: var(--muted); font-size: 0.9rem; }
        .empty-state i { font-size: 2.2rem; display: block; margin-bottom: 0.75rem; color: #C8CFD8; }
        .spinner { width: 15px; height: 15px; border: 2px solid rgba(255,255,255,0.4); border-top-color: #fff; border-radius: 50%; animation: spin 0.7s linear infinite; display: inline-block; flex-shrink: 0; }
        @keyframes spin { to { transform: rotate(360deg); } }

        /* â”€â”€ Import Modal â”€â”€ */
        .modal-backdrop { position: fixed; inset: 0; background: rgba(15,23,42,0.55); z-index: 2000; display: flex; align-items: center; justify-content: center; opacity: 0; visibility: hidden; transition: opacity 0.25s, visibility 0.25s; padding: 1rem; }
        .modal-backdrop.open { opacity: 1; visibility: visible; }
        .modal-box { background: #fff; border-radius: 20px; box-shadow: 0 24px 80px rgba(10,47,68,0.22); width: 100%; max-width: 860px; max-height: 90vh; display: flex; flex-direction: column; transform: translateY(20px); transition: transform 0.25s; }
        .modal-backdrop.open .modal-box { transform: translateY(0); }
        .modal-head { padding: 1.25rem 1.5rem; border-bottom: 1px solid var(--border); display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem; flex-shrink: 0; }
        .modal-head-title { font-size: 1.1rem; font-weight: 800; color: var(--primary); display: flex; align-items: center; gap: 8px; }
        .modal-head-title i { color: var(--accent); }
        .modal-head-sub { font-size: 0.8rem; color: var(--muted); margin-top: 4px; }
        .modal-close { width: 36px; height: 36px; border: 1px solid var(--border); border-radius: 10px; background: #fff; cursor: pointer; display: flex; align-items: center; justify-content: center; color: var(--muted); font-size: 18px; flex-shrink: 0; transition: background 0.15s; }
        .modal-close:hover { background: #fee2e2; color: #A32D2D; border-color: #fca5a5; }
        .modal-stats { padding: 0.85rem 1.5rem; background: var(--surface-2); border-bottom: 1px solid var(--border); display: flex; gap: 1rem; flex-wrap: wrap; flex-shrink: 0; }
        .mstat { display: flex; align-items: center; gap: 6px; font-size: 0.8rem; font-weight: 700; }
        .mstat-dot { width: 10px; height: 10px; border-radius: 50%; }
        .mstat-dot.matched { background: #0F6E56; }
        .mstat-dot.fuzzy { background: #C5A028; }
        .mstat-dot.unmatched { background: #A32D2D; }
        .mstat-count { color: var(--text); }
        .modal-excel-scale { padding: 0.65rem 1.5rem; background: #EBF4FF; border-bottom: 1px solid var(--ww-border); display: flex; gap: 1.25rem; flex-wrap: wrap; align-items: center; flex-shrink: 0; }
        .mes-label { font-size: 0.72rem; font-weight: 800; color: var(--ww-text); text-transform: uppercase; letter-spacing: 0.05em; }
        .mes-chips { display: flex; gap: 0.5rem; flex-wrap: wrap; }
        .mes-chip { padding: 0.3rem 0.65rem; border-radius: 999px; font-size: 0.75rem; font-weight: 700; }
        .mes-chip.ww { background: var(--ww-bg); color: var(--ww-text); border: 1px solid var(--ww-border); }
        .mes-chip.pt { background: var(--pt-bg); color: var(--pt-text); border: 1px solid var(--pt-border); }
        .mes-chip.qa { background: var(--qa-bg); color: var(--qa-text); border: 1px solid var(--qa-border); }
        .modal-body { flex: 1; overflow-y: auto; padding: 1rem 1.5rem; }
        .match-section-title { font-size: 0.72rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.08em; color: var(--muted); padding: 0.5rem 0 0.4rem; margin-top: 0.5rem; display: flex; align-items: center; gap: 8px; }
        .match-section-title::after { content:''; flex:1; height:1px; background: var(--border); }
        .match-row { display: grid; grid-template-columns: 32px 1fr 36px 1fr 1fr; align-items: center; gap: 0.6rem; padding: 0.65rem 0.75rem; border-radius: 12px; border: 1px solid var(--border); margin-bottom: 0.45rem; transition: border-color 0.15s, background 0.15s; background: #fff; }
        .match-row.status-matched { border-color: #A8E6D1; background: #F0FBF7; }
        .match-row.status-fuzzy { border-color: #F5D87A; background: #FFFBEC; }
        .match-row.status-unmatched { border-color: #F5BCBC; background: #FFF5F5; }
        .match-idx { font-size: 11px; color: var(--muted); font-weight: 700; text-align: center; }
        .match-excel-name { font-size: 0.82rem; font-weight: 700; color: var(--text); }
        .match-excel-scores { font-size: 10px; color: var(--muted); margin-top: 2px; }
        .match-arrow { font-size: 16px; color: var(--muted); text-align: center; }
        .match-system-select { border: 1.5px solid var(--border); border-radius: 10px; padding: 0.45rem 0.6rem; font-family: inherit; font-size: 0.82rem; font-weight: 600; color: var(--text); background: #fff; transition: border-color 0.15s; width: 100%; }
        .match-system-select:focus { outline: none; border-color: var(--primary); }
        .match-system-select.sel-matched { border-color: #0F6E56; background: #F0FBF7; }
        .match-system-select.sel-fuzzy { border-color: #C5A028; background: #FFFBEC; }
        .match-system-select.sel-none { border-color: #A32D2D; background: #FFF5F5; }
        .match-status-badge { font-size: 10px; font-weight: 700; padding: 3px 8px; border-radius: 999px; text-align: center; white-space: nowrap; }
        .msb-matched { background: var(--qa-bg); color: var(--qa-text); border: 1px solid var(--qa-border); }
        .msb-fuzzy { background: #FFF8E1; color: #855E00; border: 1px solid #F5D87A; }
        .msb-unmatched { background: #FCEBEB; color: #A32D2D; border: 1px solid #F5BCBC; }
        .modal-foot { padding: 1rem 1.5rem; border-top: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-shrink: 0; flex-wrap: wrap; }
        .modal-foot-info { font-size: 0.82rem; color: var(--muted); }
        .modal-foot-info strong { color: var(--primary); }
        .modal-foot-btns { display: flex; gap: 0.55rem; }


        /* â”€â”€ Total Highest Score row â”€â”€ */
        .hps-row td {
            background: #FFF8E1 !important;
            border-top: 2px solid #F5D87A !important;
            border-bottom: 2px solid #F5D87A !important;
            font-weight: 700;
            color: #855E00;
            font-size: 12px;
        }
        .hps-row .hps-label {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--muted);
        }
        .hps-row .hps-value {
            font-size: 14px;
            font-weight: 800;
            color: #E65100;
        }
        .hps-row .hps-ps {
            font-size: 12px;
            font-weight: 700;
            color: #0F6E56;
        }
        .hps-row .hps-ws {
            font-size: 12px;
            font-weight: 700;
            color: #534AB7;
        }

        /* â”€â”€ Responsive â”€â”€ */
        @media (max-width: 1200px) {
            .workspace { grid-template-columns: 1fr; }
            .side-stack { flex-direction: row; overflow-x: auto; }
            .side-panel { min-width: 260px; }
        }
        @media (max-width: 700px) {
            .match-row { grid-template-columns: 28px 1fr 28px 1fr; }
            .match-status-badge { display: none; }
        }
        @media (max-width: 991.98px) {
            body.stsn-layout { overflow: auto; }
            #stsn-toggle { display: inline-flex; }
            .page-shell, body.sidebar-collapsed .page-shell { margin-left: 0; height: auto; min-height: 100vh; }
            .page-main { overflow: visible; height: auto; padding-top: 0.75rem; }
            .workspace { grid-template-columns: 1fr; }
            .main-panel, .table-wrap { overflow: visible; }
        }
    </style>
</head>
<body class="stsn-layout">
<button id="stsn-toggle" aria-label="Toggle sidebar"><i class="bi bi-list"></i></button>
<div id="stsn-overlay"></div>

<?php include __DIR__ . '/../includes/teacher-sidebar.php'; ?>

<div class="page-shell">

    <!-- â•â•â• Top Bar (metadata only — no action buttons) â•â•â• -->
    <header class="top-bar">
        <div class="top-bar-left">
            <h1><i class="bi bi-journal-text" style="color: var(--accent);"></i> Grading Sheet</h1>
            <p id="topBarSub">
                <?php if ($isSelectionValid): ?>
                    <?= htmlspecialchars("$subjectName · $sectionName · {$quarterName} Quarter") ?>
                <?php else: ?>
                    Select a section and subject to start grading
                <?php endif; ?>
            </p>
        </div>
        <div class="top-bar-right">
            <div class="meta-chip"><i class="bi bi-person-badge"></i> <?= htmlspecialchars($teacherName) ?></div>
            <div class="meta-chip"><i class="bi bi-calendar3"></i> <?= htmlspecialchars($schoolYear) ?></div>
        </div>
    </header>

    <!-- â•â•â• Toolbar â•â•â• -->
    <div class="toolbar">
        <div class="toolbar-group">
            <span class="toolbar-label"><i class="bi bi-calendar-week"></i> Quarter</span>
            <select id="quarterSelect" onchange="changeQuarter()">
                <option value="1" <?= $quarter == 1 ? 'selected' : '' ?>>1st Quarter</option>
                <option value="2" <?= $quarter == 2 ? 'selected' : '' ?>>2nd Quarter</option>
                <option value="3" <?= $quarter == 3 ? 'selected' : '' ?>>3rd Quarter</option>
                <option value="4" <?= $quarter == 4 ? 'selected' : '' ?>>4th Quarter</option>
            </select>
        </div>
        <div class="toolbar-group" style="margin-left: auto; gap: 8px;">
            <select id="filterStatus" onchange="applyFilter()">
                <option value="">All Students</option>
                <option value="Passed">Passed Only</option>
                <option value="Failed">Failed Only</option>
            </select>
            <input type="text" id="searchStudent" placeholder="ðŸ” Search student…"
                   oninput="applyFilter()" style="width: 210px;">
        </div>
    </div>

    <main class="page-main">
        <div class="workspace">

            <!-- â•â•â• Main Table Panel â•â•â• -->
            <div class="panel main-panel">

                <!-- â”€â”€ Action Bar: buttons sit here, above the table â”€â”€ -->
                <div class="action-bar" id="actionBar" style="display: <?= $isSelectionValid ? 'flex' : 'none' ?>;">
                    <div class="action-bar-left">
                        <div class="panel-title" style="margin:0;">
                            <i class="bi bi-table"></i>
                            <span id="panelTitle"><?= $isSelectionValid ? htmlspecialchars("$subjectName — $sectionName") : 'No Section Selected' ?></span>
                        </div>
                        <div class="panel-sub" style="margin-top:2px;">
                            <span id="panelQuarter"><?= $quarterName ?></span> Quarter &nbsp;·&nbsp; S.Y. <?= htmlspecialchars($schoolYear) ?>
                            <span id="importedNote" style="display:none;margin-left:8px;">
                                <span class="imported-badge"><i class="bi bi-file-earmark-excel-fill"></i> Scores from DepEd Excel</span>
                            </span>
                        </div>
                    </div>
                    <div class="action-bar-right">
                        <!-- Import button -->
                        <button class="btn btn-success" id="importBtn"
                                onclick="document.getElementById('excelFile').click()"
                                <?= $isSelectionValid ? '' : 'disabled' ?>>
                            <i class="bi bi-file-earmark-arrow-up"></i> Import DepEd Excel
                        </button>
                        <input type="file" id="excelFile" accept=".xlsx,.xls"
                               style="display:none" onchange="handleExcelFile(this)"
                               <?= $isSelectionValid ? '' : 'disabled' ?>>
                        <!-- Save button -->
                        <button class="btn btn-primary" id="saveBtn"
                                onclick="saveSheet()"
                                <?= $isSelectionValid ? '' : 'disabled' ?>>
                            <i class="bi bi-save2"></i> Save Grades
                        </button>
                    </div>
                </div>

                <!-- â”€â”€ Weight / student-count pills â”€â”€ -->
                <div class="panel-header" style="border-top:none;">
                    <div class="summary-pills" style="margin-left:auto;">
                        <span class="pill pill-ww" id="pillWW">WW 40%</span>
                        <span class="pill pill-pt" id="pillPT">PT 40%</span>
                        <span class="pill pill-qa" id="pillQA">QA 20%</span>
                        <span class="pill pill-neu"><i class="bi bi-people-fill"></i> <span id="studentCountPill">0</span> Students</span>
                    </div>
                </div>

                <!-- â”€â”€ Grading table â”€â”€ -->
                <div class="table-wrap">
                    <table class="grading-table" id="gradingTable">
                        <thead>
                            <tr>
                                <th rowspan="2" class="th-def">#</th>
                                <th rowspan="2" class="th-def" style="text-align:left;padding-left:1rem;">Student Name</th>
                                <!-- Written Works: Total Score + PS + WS -->
                                <th colspan="3" class="th-ww" id="wwHeader">Written Works (40%)</th>
                                <!-- Performance Tasks: Total Score + PS + WS -->
                                <th colspan="3" class="th-pt" id="ptHeader">Performance Tasks (40%)</th>
                                <!-- Quarterly Assessment: Total Score + PS + WS -->
                                <th colspan="3" class="th-qa" id="qaHeader">Quarterly Assessment (20%)</th>
                                <th rowspan="2" class="th-gr">Initial<br>Grade</th>
                                <th rowspan="2" class="th-gr">Final<br>Grade</th>
                                <th rowspan="2" class="th-gr">Remarks</th>
                            </tr>
                            <tr>
                                <th class="th-ww">Total Score</th>
                                <th class="th-ww">PS</th>
                                <th class="th-ww">WS</th>
                                <th class="th-pt">Total Score</th>
                                <th class="th-pt">PS</th>
                                <th class="th-pt">WS</th>
                                <th class="th-qa">Total Score</th>
                                <th class="th-qa">PS</th>
                                <th class="th-qa">WS</th>
                            </tr>
                        </thead>
                        <tbody id="tableBody">
                            <?php if (!$isSelectionValid): ?>
                                <tr>
                                    <td colspan="14">
                                        <div class="empty-state">
                                            <i class="bi bi-arrow-up-circle"></i>
                                            Please select a section and subject to load the grading sheet.
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div><!-- /main-panel -->

            <!-- â•â•â• Right Sidebar: Class Summary + Legend only â•â•â• -->
            <div class="side-stack">

                <!-- Class Summary -->
                <div class="panel side-panel">
                    <div class="panel-title"><i class="bi bi-bar-chart-fill"></i> Class Summary</div>
                    <div class="info-grid">
                        <div class="info-box"><div class="info-label">Class Average (Final)</div><div class="info-value" id="infoClassAve">—</div></div>
                        <div class="info-box"><div class="info-label">Mean Percentage Score</div><div class="info-value" id="infoMPS">—</div></div>
                        <div class="info-box"><div class="info-label">Passed</div><div class="info-value passed" id="infoPassed">—</div></div>
                        <div class="info-box"><div class="info-label">Failed</div><div class="info-value failed" id="infoFailed">—</div></div>
                    </div>
                </div>

                <!-- Legend -->
                <div class="panel side-panel">
                    <div class="panel-title"><i class="bi bi-bookmarks-fill"></i> Legend</div>
                    <div class="legend-list">
                        <div class="legend-item"><div class="legend-dot" style="background:var(--ww-bg);border:1px solid var(--ww-text);"></div><span><strong>WW</strong> = Written Works</span></div>
                        <div class="legend-item"><div class="legend-dot" style="background:var(--pt-bg);border:1px solid var(--pt-text);"></div><span><strong>PT</strong> = Performance Tasks</span></div>
                        <div class="legend-item"><div class="legend-dot" style="background:var(--qa-bg);border:1px solid var(--qa-text);"></div><span><strong>QA</strong> = Quarterly Assessment</span></div>
                        <div class="legend-item" style="margin-top:4px;"><span style="font-size:0.77rem;"><strong>PS</strong> = (Total Score Ã· HPS) Ã— 100</span></div>
                        <div class="legend-item"><span style="font-size:0.77rem;"><strong>WS</strong> = PS Ã— Weight%</span></div>
                        <div class="legend-item"><span style="font-size:0.77rem;"><strong>Initial</strong> = WW_WS + PT_WS + QA_WS</span></div>
                        <div class="legend-item"><span style="font-size:0.77rem;"><strong>Final</strong> = Transmuted (DepEd K-12)</span></div>
                        <div class="legend-list" style="margin-top:6px;padding-top:6px;border-top:1px solid var(--border);">
                            <div class="legend-item" style="font-size:0.77rem;color:var(--ww-text);">
                                <i class="bi bi-file-earmark-excel-fill"></i>
                                <strong>PS, WS, HPS &amp; Weights imported directly from DepEd Excel</strong>
                            </div>
                        </div>
                    </div>
                </div>

            </div><!-- /side-stack -->

        </div><!-- /workspace -->
    </main>
</div><!-- /page-shell -->

<!-- â•â•â• Import Matching Modal â•â•â• -->
<div class="modal-backdrop" id="matchModal">
    <div class="modal-box">
        <div class="modal-head">
            <div>
                <div class="modal-head-title">
                    <i class="bi bi-diagram-3-fill"></i>
                    Match Excel Students to System Students
                </div>
                <div class="modal-head-sub" id="modalSubtitle">
                    Review and confirm how each student from the Excel file maps to your class roster.
                    PS, WS, HPS, and weights will be imported directly from Excel.
                </div>
            </div>
            <button class="modal-close" onclick="closeModal()" title="Cancel">âœ•</button>
        </div>
        <div class="modal-stats" id="modalStats"></div>
        <div class="modal-excel-scale" id="modalExcelScale" style="display:none;">
            <span class="mes-label"><i class="bi bi-file-earmark-excel-fill"></i> From Excel:</span>
            <div class="mes-chips" id="mesChips"></div>
        </div>
        <div id="sheetSelectorRow" style="padding:0.75rem 1.5rem;border-bottom:1px solid var(--border);display:none;align-items:center;gap:0.75rem;flex-shrink:0;">
            <span style="font-size:0.82rem;font-weight:700;color:var(--primary);">
                <i class="bi bi-layers-half"></i> Select Subject Sheet:
            </span>
            <select id="sheetSelector" onchange="onSheetChange()"
                    style="border:1px solid var(--border);border-radius:10px;padding:0.45rem 0.75rem;font-family:inherit;font-size:0.85rem;font-weight:600;color:var(--text);">
            </select>
            <span style="font-size:0.75rem;color:var(--muted);">Scores, PS, WS, HPS &amp; weights will be read from the selected sheet.</span>
        </div>
        <div class="modal-body" id="modalBody"></div>
        <div class="modal-foot">
            <div class="modal-foot-info" id="modalFootInfo"></div>
            <div class="modal-foot-btns">
                <button class="btn btn-secondary" onclick="closeModal()">
                    <i class="bi bi-x-circle"></i> Cancel
                </button>
                <button class="btn btn-primary" id="applyMatchBtn" onclick="applyMatches()">
                    <i class="bi bi-check2-all"></i> Apply &amp; Import Scores
                </button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.sheetjs.com/xlsx-0.20.1/package/dist/xlsx.full.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../js/sweet-alerts.js"></script>
<script>
// =====================================================================
//  Config
// =====================================================================
const teacherId    = <?= $teacherId ?>;
let sectionId      = <?= $sectionId ?>;
let subjectId      = <?= $subjectId ?>;
let currentQuarter = <?= $quarter ?>;
const subjectName  = <?= json_encode($subjectName) ?>;
const sectionName  = <?= json_encode($sectionName) ?>;
const schoolYear   = <?= json_encode($schoolYear) ?>;
const quarterName  = <?= json_encode($quarterName) ?>;
const teacherName  = <?= json_encode($teacherName) ?>;

const WW_COUNT = <?= $wwCount ?>;
const PT_COUNT = <?= $ptCount ?>;
const QA_COUNT = <?= $qaCount ?>;

let weights   = { ww: 40, pt: 40, qa: 20 };
let maxScores = { ww: 100, pt: 100, qa: 100 };
let studentsData = [];

// DepEd Excel column layout (0-based indices)
const DEPED = {
    COL_NAME:     1,
    COL_WW_START: 5,
    COL_WW_END:   14,
    COL_WW_TOTAL: 15,
    COL_WW_PS:    16,
    COL_WW_WS:    17,
    COL_PT_START: 18,
    COL_PT_END:   27,
    COL_PT_TOTAL: 28,
    COL_PT_PS:    29,
    COL_PT_WS:    30,
    COL_QA_START: 31,
    COL_QA_TOTAL: 31,
    COL_QA_PS:    32,
    COL_QA_WS:    33,
    COL_INITIAL:  34,
    COL_FINAL:    35,
    COL_HPS_WW_TOTAL:  15,
    COL_HPS_WW_WEIGHT: 17,
    COL_HPS_PT_TOTAL:  28,
    COL_HPS_PT_WEIGHT: 30,
    COL_HPS_QA_TOTAL:  31,
    COL_HPS_QA_WEIGHT: 33,
};

const DEPED_SKIP_SHEETS = ['input data', 'summary of quarterly grades', 'do not delete', 'transmutation'];

let importWorkbook   = null;
let importSheetNames = [];
let importMatches    = [];
let importExcelScale = { wwWeight: 0, ptWeight: 0, qaWeight: 0, wwHps: 0, ptHps: 0, qaHps: 0 };

document.addEventListener('DOMContentLoaded', () => {
    initSidebar();
    if (sectionId && subjectId) loadStudents();
    updateWeightLabels();
});

function changeQuarter() {
    currentQuarter = document.getElementById('quarterSelect').value;
    let url = `Grading-Sheet.php?quarter=${currentQuarter}`;
    if (sectionId) url += `&section_id=${sectionId}`;
    if (subjectId) url += `&subject_id=${subjectId}`;
    window.location.href = url;
}

async function loadStudents() {
    try {
        const res  = await fetch(`../api/grading/get_students.php?section_id=${sectionId}&subject_id=${subjectId}&quarter=${currentQuarter}`);
        const data = await res.json();
        if (data.success) {
            studentsData = data.students || [];
            if (data.weights)    { weights = data.weights; updateWeightLabels(); }
            if (data.max_scores) { maxScores = data.max_scores; }
            renderTable();
        } else {
            showToast(data.error || 'Failed to load students', 'error');
        }
    } catch (e) {
        console.error(e);
        showToast('Failed to load students', 'error');
    }
}

function updateWeightLabels() {
    document.getElementById('wwHeader').textContent = `Written Works (${weights.ww}%)`;
    document.getElementById('ptHeader').textContent = `Performance Tasks (${weights.pt}%)`;
    document.getElementById('qaHeader').textContent = `Quarterly Assessment (${weights.qa}%)`;
    document.getElementById('pillWW').textContent = `WW ${weights.ww}%`;
    document.getElementById('pillPT').textContent = `PT ${weights.pt}%`;
    document.getElementById('pillQA').textContent = `QA ${weights.qa}%`;
}

// =====================================================================
//  Render Table
//  - Total Score (editable input), PS (indicator), WS (indicator)
//  - Student sub-label shows LRN
// =====================================================================
function renderTable() {
    const tbody = document.getElementById('tableBody');
    if (!studentsData.length) {
        tbody.innerHTML = `<tr><td colspan="14"><div class="empty-state"><i class="bi bi-inbox"></i>No students found in this section.</div></td></tr>`;
        updateClassSummary();
        return;
    }

    let html = '';

    // â”€â”€ Total Highest Score row (from Excel / manual) â”€â”€
    html += `<tr class="hps-row">
        <td class="col-num"><i class="bi bi-trophy-fill" style="color:#C5A028;"></i></td>
        <td class="col-name"><span class="hps-label">Highest Possible Score</span></td>
        <!-- WW: Total | PS | WS -->
        <td class="hps-value">${maxScores.ww}</td>
        <td class="hps-ps">100</td>
        <td class="hps-ws">${weights.ww}</td>
        <!-- PT: Total | PS | WS -->
        <td class="hps-value">${maxScores.pt}</td>
        <td class="hps-ps">100</td>
        <td class="hps-ws">${weights.pt}</td>
        <!-- QA: Total | PS | WS -->
        <td class="hps-value">${maxScores.qa}</td>
        <td class="hps-ps">100</td>
        <td class="hps-ws">${weights.qa}</td>
        <!-- Initial | Final | Remarks -->
        <td colspan="3" style="font-size:11px;color:var(--muted);text-align:center;">
            <i class="bi bi-info-circle"></i> HPS from DepEd Excel
        </td>
    </tr>`;

    studentsData.forEach((student, idx) => {
        const s = student.scores || {};
        const passed = student.remarks === 'Passed';
        const hasImported = student._excelImported;

        const importedHint = hasImported
            ? `<span class="imported-badge" title="Scores imported from DepEd Excel">Excel</span>`
            : '';

        const psCls = 'cell-ps';
        const wsCls = 'cell-ws';

        html += `<tr data-status="${student.remarks || 'Failed'}" data-student-id="${student.student_id}">
            <td class="col-num">${idx + 1}</td>
            <td class="col-name">
                <div class="student-name">${escapeHtml(student.name)} ${importedHint}</div>
                <span class="student-sub">LRN: ${escapeHtml(student.lrn || student.student_id)}</span>
            </td>

            <!-- WW: Total Score (input) | PS | WS -->
            <td><input type="number" class="score-input ww-input"
                    value="${fmtRaw(s.ww_total)}" min="0" step="0.01"
                    oninput="onScoreInput(${student.student_id}, 'ww_total', this.value)"
                    ${sectionId && subjectId ? '' : 'disabled'}></td>
            <td class="${psCls}" id="ww_ps_${student.student_id}">${fmtVal(s.ww_ps)}</td>
            <td class="${wsCls}" id="ww_ws_${student.student_id}">${fmtVal(s.ww_ws)}</td>

            <!-- PT: Total Score (input) | PS | WS -->
            <td><input type="number" class="score-input pt-input"
                    value="${fmtRaw(s.pt_total)}" min="0" step="0.01"
                    oninput="onScoreInput(${student.student_id}, 'pt_total', this.value)"
                    ${sectionId && subjectId ? '' : 'disabled'}></td>
            <td class="${psCls}" id="pt_ps_${student.student_id}">${fmtVal(s.pt_ps)}</td>
            <td class="${wsCls}" id="pt_ws_${student.student_id}">${fmtVal(s.pt_ws)}</td>

            <!-- QA: Total Score (input) | PS | WS -->
            <td><input type="number" class="score-input qa-input"
                    value="${fmtRaw(s.qa_total)}" min="0" step="0.01"
                    oninput="onScoreInput(${student.student_id}, 'qa_total', this.value)"
                    ${sectionId && subjectId ? '' : 'disabled'}></td>
            <td class="${psCls}" id="qa_ps_${student.student_id}">${fmtVal(s.qa_ps)}</td>
            <td class="${wsCls}" id="qa_ws_${student.student_id}">${fmtVal(s.qa_ws)}</td>

            <td class="cell-initial" id="init_${student.student_id}">${fmtVal(student.initial_grade)}</td>
            <td class="cell-final"   id="final_${student.student_id}">${fmtVal(student.final_grade)}</td>
            <td id="rem_${student.student_id}">
                <span class="badge ${passed ? 'badge-passed' : 'badge-failed'}">${student.remarks || 'Failed'}</span>
            </td>
        </tr>`;
    });

    html += `<tr class="summary-row">
        <td colspan="2" style="text-align:left;padding-left:1rem;">Class Summary</td>
        <td colspan="3" style="text-align:center;">Written Works</td>
        <td colspan="3" style="text-align:center;">Performance Tasks</td>
        <td colspan="3" style="text-align:center;">Quarterly Assessment</td>
        <td colspan="2" id="summaryAve" style="text-align:center;">—</td>
        <td id="summaryMPS" style="text-align:center;">—</td>
    </tr>`;

    tbody.innerHTML = html;
    updateClassSummary();
    document.getElementById('studentCountPill').textContent = studentsData.length;
}

function onScoreInput(studentId, field, value) {
    const student = studentsData.find(s => s.student_id == studentId);
    if (!student) return;
    if (!student.scores) student.scores = {};
    student.scores[field] = parseFloat(value) || 0;
    student._excelImported = false;
    recalculateStudent(student);
    updateRowCells(student);
    updateClassSummary();
}

function updateRowCells(student) {
    const s = student.scores;
    const sid = student.student_id;
    const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = fmtVal(val); };
    set(`ww_ps_${sid}`, s.ww_ps);
    set(`ww_ws_${sid}`, s.ww_ws);
    set(`pt_ps_${sid}`, s.pt_ps);
    set(`pt_ws_${sid}`, s.pt_ws);
    set(`qa_ps_${sid}`, s.qa_ps);
    set(`qa_ws_${sid}`, s.qa_ws);
    set(`init_${sid}`, student.initial_grade);
    set(`final_${sid}`, student.final_grade);
    const remEl = document.getElementById(`rem_${sid}`);
    if (remEl) {
        const passed = student.remarks === 'Passed';
        remEl.innerHTML = `<span class="badge ${passed ? 'badge-passed' : 'badge-failed'}">${student.remarks}</span>`;
        const row = remEl.closest('tr');
        if (row) row.dataset.status = student.remarks;
    }
}

function recalculateStudent(student) {
    const s = student.scores || {};
    const wwTot = parseFloat(s.ww_total) || 0;
    const ptTot = parseFloat(s.pt_total) || 0;
    const qaTot = parseFloat(s.qa_total) || 0;

    const wwPs = maxScores.ww > 0 ? (wwTot / maxScores.ww) * 100 : 0;
    const ptPs = maxScores.pt > 0 ? (ptTot / maxScores.pt) * 100 : 0;
    const qaPs = maxScores.qa > 0 ? (qaTot / maxScores.qa) * 100 : 0;

    const wwWs = wwPs * weights.ww / 100;
    const ptWs = ptPs * weights.pt / 100;
    const qaWs = qaPs * weights.qa / 100;

    s.ww_ps = +wwPs.toFixed(2);
    s.ww_ws = +wwWs.toFixed(2);
    s.pt_ps = +ptPs.toFixed(2);
    s.pt_ws = +ptWs.toFixed(2);
    s.qa_ps = +qaPs.toFixed(2);
    s.qa_ws = +qaWs.toFixed(2);

    const initial = +(wwWs + ptWs + qaWs).toFixed(2);
    student.scores = s;
    student.initial_grade = initial;
    student.final_grade   = transmuteGrade(initial);
    student.remarks       = student.final_grade >= 75 ? 'Passed' : 'Failed';
}

function transmuteGrade(init) {
    const table = [
        [100,100],[98.40,99],[96.80,98],[95.20,97],[93.60,96],[92.00,95],
        [90.40,94],[88.80,93],[87.20,92],[85.60,91],[84.00,90],[82.40,89],
        [80.80,88],[79.20,87],[77.60,86],[76.00,85],[74.40,84],[72.80,83],
        [71.20,82],[69.60,81],[68.00,80],[66.40,79],[64.80,78],[63.20,77],
        [61.60,76],[60.00,75],[56.00,74],[52.00,73],[48.00,72],[44.00,71],
        [40.00,70],[36.00,69],[32.00,68],[28.00,67],[24.00,66],[20.00,65],
        [16.00,64],[12.00,63],[8.00,62],[4.00,61],[0,60]
    ];
    for (const [min, grade] of table) if (init >= min) return grade;
    return 60;
}

function updateClassSummary() {
    let totalInit = 0, count = 0, passed = 0, failed = 0;
    studentsData.forEach(student => {
        const init = parseFloat(student.initial_grade) || 0;
        totalInit += init; count++;
        if (student.remarks === 'Passed') passed++; else failed++;
    });
    const mps      = count ? (totalInit / count).toFixed(2) : '—';
    const classAve = count ? transmuteGrade(parseFloat(mps)) : '—';
    document.getElementById('infoClassAve').textContent = classAve;
    document.getElementById('infoMPS').textContent      = mps;
    document.getElementById('infoPassed').textContent   = count ? passed : '—';
    document.getElementById('infoFailed').textContent   = count ? failed : '—';
    const aveCell = document.getElementById('summaryAve');
    const mpsCell = document.getElementById('summaryMPS');
    if (aveCell) aveCell.textContent = count ? 'Class Ave: ' + classAve : '—';
    if (mpsCell) mpsCell.textContent = count ? 'MPS: ' + mps : '—';
}

function applyFilter() {
    const search = document.getElementById('searchStudent').value.toLowerCase();
    const status = document.getElementById('filterStatus').value;
    document.querySelectorAll('#tableBody tr:not(.summary-row)').forEach(row => {
        const name      = row.querySelector('.student-name')?.textContent.toLowerCase() || '';
        const matchSrch = !search || name.includes(search);
        const matchStat = !status || row.dataset.status === status;
        row.style.display = (matchSrch && matchStat) ? '' : 'none';
    });
}

// =====================================================================
//  Name-matching helpers
// =====================================================================
function normalizeName(name) {
    return String(name).toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
}

function levenshtein(a, b, maxDist = 6) {
    if (Math.abs(a.length - b.length) > maxDist) return maxDist + 1;
    const m = a.length, n = b.length;
    const dp = Array.from({ length: m + 1 }, (_, i) => i);
    for (let j = 1; j <= n; j++) {
        let prev = j;
        for (let i = 1; i <= m; i++) {
            const val = a[i-1] === b[j-1] ? dp[i-1] : 1 + Math.min(dp[i-1], dp[i], prev);
            dp[i-1] = prev;
            prev = val;
        }
        dp[m] = prev;
    }
    return dp[m];
}

function tokenSetScore(a, b) {
    const setA = new Set(a.split(' ').filter(Boolean));
    const setB = new Set(b.split(' ').filter(Boolean));
    const intersect = [...setA].filter(x => setB.has(x)).length;
    const union = new Set([...setA, ...setB]).size;
    return union === 0 ? 0 : intersect / union;
}

function findBestMatch(excelName) {
    const normExcel = normalizeName(excelName);
    for (const s of studentsData) {
        if (normalizeName(s.name) === normExcel) {
            return { studentId: s.student_id, studentName: s.name, matchType: 'exact', score: 1.0 };
        }
    }
    let best = null, bestScore = 0;
    for (const s of studentsData) {
        const normSys = normalizeName(s.name);
        const tScore  = tokenSetScore(normExcel, normSys);
        const lDist   = levenshtein(normExcel, normSys);
        const lScore  = 1 - lDist / Math.max(normExcel.length, normSys.length, 1);
        const combined = tScore * 0.7 + lScore * 0.3;
        if (combined > bestScore) { bestScore = combined; best = s; }
    }
    if (best) {
        const normSys = normalizeName(best.name);
        const tScore  = tokenSetScore(normExcel, normSys);
        const lDist   = levenshtein(normExcel, normSys);
        if (tScore >= 0.5 || lDist <= 3) {
            return { studentId: best.student_id, studentName: best.name, matchType: 'fuzzy', score: bestScore };
        }
    }
    return { studentId: null, studentName: null, matchType: 'none', score: 0 };
}

// =====================================================================
//  Excel import
// =====================================================================
async function handleExcelFile(input) {
    const file = input.files[0];
    if (!file) return;
    const btn = document.getElementById('importBtn');
    const origHTML = btn.innerHTML;
    btn.innerHTML = '<span class="spinner"></span> Reading…';
    btn.disabled = true;
    try {
        const buffer = await file.arrayBuffer();
        importWorkbook = XLSX.read(buffer, { type: 'array', cellFormula: false, cellNF: false });
        importSheetNames = importWorkbook.SheetNames.filter(n => !DEPED_SKIP_SHEETS.includes(n.toLowerCase().trim()));
        if (!importSheetNames.length) {
            showToast('No subject sheets found in this file. Check your DepEd Excel template.', 'error');
            return;
        }
        const selector = document.getElementById('sheetSelector');
        selector.innerHTML = importSheetNames.map(n => `<option value="${escapeHtml(n)}">${escapeHtml(n)}</option>`).join('');
        document.getElementById('sheetSelectorRow').style.display = importSheetNames.length > 1 ? 'flex' : 'none';
        buildMatchesForSheet(importSheetNames[0]);
        openModal();
    } catch (e) {
        console.error(e);
        showToast('Could not read file: ' + e.message, 'error');
    } finally {
        btn.innerHTML = origHTML;
        btn.disabled = false;
        input.value = '';
    }
}

function onSheetChange() {
    const sheetName = document.getElementById('sheetSelector').value;
    buildMatchesForSheet(sheetName);
    renderModalBody();
}

function buildMatchesForSheet(sheetName) {
    const ws = importWorkbook.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '', raw: true });
    importMatches = [];
    importExcelScale = { wwWeight: 0, ptWeight: 0, qaWeight: 0, wwHps: 0, ptHps: 0, qaHps: 0 };

    let hpsRowIdx = -1, dataStartRow = -1;
    for (let i = 0; i < Math.min(25, rows.length); i++) {
        const cellB = String(rows[i]?.[DEPED.COL_NAME] || '').trim().toUpperCase();
        if (cellB === 'HIGHEST POSSIBLE SCORE') { hpsRowIdx = i; dataStartRow = i + 1; break; }
    }
    if (dataStartRow === -1) {
        for (let i = 8; i < Math.min(25, rows.length); i++) {
            const cellA = rows[i]?.[0];
            if (!isNaN(parseFloat(cellA)) && parseFloat(cellA) >= 1) { dataStartRow = i; break; }
        }
    }
    if (dataStartRow === -1) {
        showToast(`Could not find student data in sheet "${sheetName}".`, 'error');
        return;
    }

    if (hpsRowIdx >= 0) {
        const hRow = rows[hpsRowIdx] || [];
        const rNum = v => { const n = parseFloat(v); return (isNaN(n) || n <= 0) ? 0 : n; };
        importExcelScale.wwHps = rNum(hRow[DEPED.COL_HPS_WW_TOTAL]);
        importExcelScale.ptHps = rNum(hRow[DEPED.COL_HPS_PT_TOTAL]);
        importExcelScale.qaHps = rNum(hRow[DEPED.COL_HPS_QA_TOTAL]);
        const wwW = rNum(hRow[DEPED.COL_HPS_WW_WEIGHT]);
        const ptW = rNum(hRow[DEPED.COL_HPS_PT_WEIGHT]);
        const qaW = rNum(hRow[DEPED.COL_HPS_QA_WEIGHT]);
        importExcelScale.wwWeight = wwW <= 1 ? Math.round(wwW * 100) : Math.round(wwW);
        importExcelScale.ptWeight = ptW <= 1 ? Math.round(ptW * 100) : Math.round(ptW);
        importExcelScale.qaWeight = qaW <= 1 ? Math.round(qaW * 100) : Math.round(qaW);
    }

    const readNum = v => { const n = parseFloat(v); return (isNaN(n) || n < 0) ? 0 : n; };

    for (let i = dataStartRow; i < rows.length; i++) {
        const row = rows[i] || [];
        const nameRaw = String(row[DEPED.COL_NAME] || '').trim();
        if (!nameRaw || ['MALE','FEMALE'].includes(nameRaw.toUpperCase()) || nameRaw.toLowerCase().includes('highest possible')) continue;

        const wwScores = [];
        for (let c = DEPED.COL_WW_START; c <= DEPED.COL_WW_END; c++) wwScores.push(readNum(row[c]));
        const ptScores = [];
        for (let c = DEPED.COL_PT_START; c <= DEPED.COL_PT_END; c++) ptScores.push(readNum(row[c]));
        const qaScores = [readNum(row[DEPED.COL_QA_START])];

        const wwPs = readNum(row[DEPED.COL_WW_PS]);
        const wwWs = readNum(row[DEPED.COL_WW_WS]);
        const ptPs = readNum(row[DEPED.COL_PT_PS]);
        const ptWs = readNum(row[DEPED.COL_PT_WS]);
        const qaPs = readNum(row[DEPED.COL_QA_PS]);
        const qaWs = readNum(row[DEPED.COL_QA_WS]);

        const wwSum = wwScores.reduce((a, v) => a + v, 0);
        const ptSum = ptScores.reduce((a, v) => a + v, 0);
        const qaSum = qaScores.reduce((a, v) => a + v, 0);
        const wwTotal = wwSum > 0 ? wwSum : readNum(row[DEPED.COL_WW_TOTAL]);
        const ptTotal = ptSum > 0 ? ptSum : readNum(row[DEPED.COL_PT_TOTAL]);
        const qaTotal = qaSum > 0 ? qaSum : readNum(row[DEPED.COL_QA_TOTAL]);

        const initialGrade = readNum(row[DEPED.COL_INITIAL]);
        const finalGrade   = readNum(row[DEPED.COL_FINAL]);
        const match = findBestMatch(nameRaw);

        importMatches.push({
            excelName: nameRaw || `(Row ${i + 1})`,
            excelRow: i, wwScores, ptScores, qaScores,
            wwTotal, ptTotal, qaTotal,
            wwPs, wwWs, ptPs, ptWs, qaPs, qaWs,
            initialGrade, finalGrade,
            matchedStudentId: match.studentId,
            matchType: match.matchType,
        });
    }
}

// =====================================================================
//  Modal
// =====================================================================
function openModal() {
    renderModalBody();
    document.getElementById('matchModal').classList.add('open');
}
function closeModal() {
    document.getElementById('matchModal').classList.remove('open');
    importWorkbook = null;
    importMatches = [];
    importExcelScale = { wwWeight: 0, ptWeight: 0, qaWeight: 0, wwHps: 0, ptHps: 0, qaHps: 0 };
}

function renderModalBody() {
    const body = document.getElementById('modalBody');
    const scaleBar = document.getElementById('modalExcelScale');
    const mesChips = document.getElementById('mesChips');
    const sc = importExcelScale;
    const hasScale = sc.wwWeight > 0 || sc.ptWeight > 0 || sc.qaWeight > 0;

    if (hasScale) {
        scaleBar.style.display = 'flex';
        mesChips.innerHTML =
            `<span class="mes-chip ww">WW ${sc.wwWeight}% · HPS ${sc.wwHps || '?'}</span>` +
            `<span class="mes-chip pt">PT ${sc.ptWeight}% · HPS ${sc.ptHps || '?'}</span>` +
            `<span class="mes-chip qa">QA ${sc.qaWeight}% · HPS ${sc.qaHps || '?'}</span>`;
    } else {
        scaleBar.style.display = 'none';
    }

    if (!importMatches.length) {
        body.innerHTML = `<div class="empty-state"><i class="bi bi-inbox"></i>No student rows found in this sheet.</div>`;
        updateModalStats();
        return;
    }

    const sysOptions = studentsData.map(s =>
        `<option value="${s.student_id}">${escapeHtml(s.name)} (LRN: ${escapeHtml(s.lrn || s.student_id)})</option>`
    ).join('');

    const exact     = importMatches.filter(m => m.matchType === 'exact');
    const fuzzy     = importMatches.filter(m => m.matchType === 'fuzzy');
    const unmatched = importMatches.filter(m => m.matchType === 'none');

    let html = '';

    const renderSection = (title, icon, items, colorClass) => {
        if (!items.length) return '';
        let s = `<div class="match-section-title" style="color:${colorClass};"><i class="bi ${icon}"></i> ${title} (${items.length})</div>`;
        items.forEach(m => {
            const idx = importMatches.indexOf(m);
            const scoreInfo = `WW:${m.wwTotal} (PS:${m.wwPs} WS:${m.wwWs}) · PT:${m.ptTotal} (PS:${m.ptPs} WS:${m.ptWs}) · QA:${m.qaTotal} (PS:${m.qaPs} WS:${m.qaWs})`;
            const statusCls = m.matchType === 'exact' ? 'status-matched' : m.matchType === 'fuzzy' ? 'status-fuzzy' : 'status-unmatched';
            const badgeCls  = m.matchType === 'exact' ? 'msb-matched' : m.matchType === 'fuzzy' ? 'msb-fuzzy' : 'msb-unmatched';
            const badgeTxt  = m.matchType === 'exact' ? 'Exact Match' : m.matchType === 'fuzzy' ? 'Fuzzy Match' : 'No Match';
            const selCls    = m.matchedStudentId ? (m.matchType === 'exact' ? 'sel-matched' : 'sel-fuzzy') : 'sel-none';

            s += `<div class="match-row ${statusCls}" id="mrow_${idx}">
                <div class="match-idx">${idx + 1}</div>
                <div>
                    <div class="match-excel-name">${escapeHtml(m.excelName)}</div>
                    <div class="match-excel-scores">${escapeHtml(scoreInfo)}</div>
                </div>
                <div class="match-arrow">â†’</div>
                <select class="match-system-select ${selCls}" id="msel_${idx}" onchange="onMatchChange(${idx}, this.value)">
                    <option value="">— Skip this student —</option>
                    ${sysOptions}
                </select>
                <div class="match-status-badge ${badgeCls}" id="mbadge_${idx}">${badgeTxt}</div>
            </div>`;
        });
        return s;
    };

    html += renderSection('Exact Matches', 'bi-check-circle-fill', exact, 'var(--qa-text)');
    html += renderSection('Fuzzy Matches — please verify', 'bi-exclamation-circle-fill', fuzzy, '#C5A028');
    html += renderSection('Unmatched — assign manually', 'bi-x-circle-fill', unmatched, '#A32D2D');

    body.innerHTML = html;
    importMatches.forEach((m, idx) => {
        const sel = document.getElementById(`msel_${idx}`);
        if (sel && m.matchedStudentId) sel.value = String(m.matchedStudentId);
    });
    updateModalStats();
    updateModalFootInfo();
}

function onMatchChange(idx, studentId) {
    const m = importMatches[idx];
    const prevType = m.matchType;
    m.matchedStudentId = studentId ? parseInt(studentId) : null;
    if (!studentId) { m.matchType = 'none'; } else { if (prevType !== 'exact') m.matchType = 'fuzzy'; }

    const row = document.getElementById(`mrow_${idx}`);
    const sel = document.getElementById(`msel_${idx}`);
    const bdg = document.getElementById(`mbadge_${idx}`);
    if (!row || !sel || !bdg) return;

    if (!studentId) {
        row.className = 'match-row status-unmatched';
        sel.className = 'match-system-select sel-none';
        bdg.className = 'match-status-badge msb-unmatched';
        bdg.textContent = 'Skipped';
    } else {
        row.className = 'match-row status-fuzzy';
        sel.className = 'match-system-select sel-fuzzy';
        bdg.className = 'match-status-badge msb-fuzzy';
        bdg.textContent = 'Manual';
    }
    updateModalStats();
    updateModalFootInfo();
}

function updateModalStats() {
    const exact     = importMatches.filter(m => m.matchedStudentId && m.matchType === 'exact').length;
    const fuzzy     = importMatches.filter(m => m.matchedStudentId && m.matchType === 'fuzzy').length;
    const unmatched = importMatches.filter(m => !m.matchedStudentId).length;
    document.getElementById('modalStats').innerHTML = `
        <div class="mstat"><div class="mstat-dot matched"></div><span class="mstat-count">${exact} Exact</span></div>
        <div class="mstat"><div class="mstat-dot fuzzy"></div><span class="mstat-count">${fuzzy} Fuzzy / Manual</span></div>
        <div class="mstat"><div class="mstat-dot unmatched"></div><span class="mstat-count">${unmatched} Skipped / Unmatched</span></div>
        <div class="mstat" style="margin-left:auto;font-size:0.78rem;color:var(--muted);">${importMatches.length} total Excel rows · ${studentsData.length} system students</div>`;
}

function updateModalFootInfo() {
    const matched = importMatches.filter(m => m.matchedStudentId).length;
    const total   = importMatches.length;
    document.getElementById('modalFootInfo').innerHTML =
        `<strong>${matched}</strong> of ${total} Excel students will be imported with PS, WS, HPS &amp; weights from Excel.`;
}

function applyMatches() {
    const applied = importMatches.filter(m => m.matchedStudentId);
    if (!applied.length) { showToast('No students matched. Nothing to import.', 'error'); return; }

    const sc = importExcelScale;
    const totalWeight = sc.wwWeight + sc.ptWeight + sc.qaWeight;
    if (totalWeight > 0) { weights = { ww: sc.wwWeight, pt: sc.ptWeight, qa: sc.qaWeight }; updateWeightLabels(); }
    if (sc.wwHps > 0) maxScores.ww = sc.wwHps;
    if (sc.ptHps > 0) maxScores.pt = sc.ptHps;
    if (sc.qaHps > 0) maxScores.qa = sc.qaHps;

    let updatedCount = 0;
    applied.forEach(m => {
        const student = studentsData.find(s => s.student_id == m.matchedStudentId);
        if (!student) return;
        student.ww_scores = m.wwScores;
        student.pt_scores = m.ptScores;
        student.qa_scores = m.qaScores;
        student._excelImported = true;
        if (!student.scores) student.scores = {};
        student.scores.ww_total = m.wwTotal;
        student.scores.pt_total = m.ptTotal;
        student.scores.qa_total = m.qaTotal;
        student.scores.ww_ps = m.wwPs;
        student.scores.ww_ws = m.wwWs;
        student.scores.pt_ps = m.ptPs;
        student.scores.pt_ws = m.ptWs;
        student.scores.qa_ps = m.qaPs;
        student.scores.qa_ws = m.qaWs;
        const wsSum = m.wwWs + m.ptWs + m.qaWs;
        student.initial_grade = (m.initialGrade > 0) ? m.initialGrade : +wsSum.toFixed(2);
        student.final_grade   = (m.finalGrade > 0)   ? m.finalGrade   : transmuteGrade(student.initial_grade);
        student.remarks       = student.final_grade >= 75 ? 'Passed' : 'Failed';
        updatedCount++;
    });

    renderTable();
    updateClassSummary();
    document.getElementById('importedNote').style.display = '';
    closeModal();
    const scaleNote = (totalWeight > 0) ? ` · Scale: WW${sc.wwWeight}% PT${sc.ptWeight}% QA${sc.qaWeight}%` : '';
    showToast(`Imported ${updatedCount} student${updatedCount !== 1 ? 's' : ''} with PS, WS &amp; grades from Excel${scaleNote}.`, 'success');
}

// =====================================================================
//  Save
// =====================================================================
async function saveSheet() {
    const btn = document.getElementById('saveBtn');
    const orig = btn.innerHTML;
    btn.innerHTML = '<span class="spinner"></span> Saving…';
    btn.disabled = true;
    const payload = {
        section_id: sectionId, subject_id: subjectId, teacher_id: teacherId, quarter: currentQuarter,
        weights: weights, max_scores: maxScores,
        grades: studentsData.map(s => ({
            student_id: s.student_id, scores: s.scores,
            ww_scores: s.ww_scores || [], pt_scores: s.pt_scores || [], qa_scores: s.qa_scores || [],
            initial_grade: s.initial_grade, final_grade: s.final_grade, remarks: s.remarks
        }))
    };
    try {
        const res = await fetch('../api/grading/save_grades.php', {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
        });
        const result = await res.json();
        showToast(result.success ? `Saved ${result.saved_count} record(s)` : (result.error || 'Save failed'), result.success ? 'success' : 'error');
    } catch (e) {
        console.error(e);
        showToast('Failed to save grades', 'error');
    } finally {
        btn.innerHTML = orig; btn.disabled = false;
    }
}

// =====================================================================
//  Toast
// =====================================================================
function showToast(msg, type = 'success', duration = 4000) {
    AppAlerts.showToast(msg, type, { timer: duration });
}

// =====================================================================
//  Sidebar
// =====================================================================
function initSidebar() {
    const sidebar    = document.getElementById('stsn-sidebar');
    const toggleBtn  = document.getElementById('stsn-toggle');
    const overlay    = document.getElementById('stsn-overlay');
    const collapseBtn = document.getElementById('stsn-collapse-btn');
    if (sidebar && localStorage.getItem('stsn-sidebar-collapsed') === 'true' && window.innerWidth >= 992) {
        sidebar.classList.add('collapsed');
        document.body.classList.add('sidebar-collapsed');
    }
    collapseBtn?.addEventListener('click', e => {
        e.stopPropagation();
        sidebar.classList.toggle('collapsed');
        const isC = sidebar.classList.contains('collapsed');
        document.body.classList.toggle('sidebar-collapsed', isC);
        localStorage.setItem('stsn-sidebar-collapsed', isC);
    });
    toggleBtn?.addEventListener('click', () => {
        sidebar.classList.toggle('mobile-open');
        overlay.classList.toggle('visible');
    });
    overlay?.addEventListener('click', () => {
        sidebar.classList.remove('mobile-open');
        overlay.classList.remove('visible');
    });
    window.addEventListener('resize', () => {
        if (!sidebar) return;
        if (window.innerWidth >= 992) { sidebar.classList.remove('mobile-open'); overlay.classList.remove('visible'); }
        else document.body.classList.remove('sidebar-collapsed');
    });
}

function fmtVal(v) {
    const n = parseFloat(v);
    if (isNaN(n) || n === 0) return '0';
    return n % 1 === 0 ? String(n) : n.toFixed(2);
}
function fmtRaw(v) {
    const n = parseFloat(v);
    return isNaN(n) ? '' : (n === 0 ? '' : n);
}
function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}
</script>
</body>
</html>
