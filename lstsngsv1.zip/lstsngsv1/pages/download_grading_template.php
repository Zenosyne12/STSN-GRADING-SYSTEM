<?php

require_once __DIR__ . '/../api/login/teacher_auth.php';
require_once __DIR__ . '/../includes/grading_engine.php';
require_once __DIR__ . '/../includes/grading_xlsx.php';

function gradingTemplateDownloadError(string $message, int $status): void
{
    http_response_code($status);
    header('Content-Type: text/plain; charset=utf-8');
    echo $message;
    exit;
}

$sectionId = (int)($_GET['section_id'] ?? 0);
$subjectId = (int)($_GET['subject_id'] ?? 0);
$templateConfigs = require __DIR__ . '/../includes/grading_templates_config.php';
$teacherId = (int)($_SESSION['teacher_id'] ?? 0);
if ($sectionId <= 0 || $subjectId <= 0 || $teacherId <= 0) {
    gradingTemplateDownloadError('A valid section and subject are required.', 400);
}

$termStmt = $pdo->query("
    SELECT t.id, t.term_number, t.term_label, ay.id AS academic_year_id, ay.year_label
    FROM tblconfig_terms t
    JOIN tblacademicyear ay ON ay.id = t.academic_year_id
    WHERE ay.is_active = 1 AND t.is_active = 1 AND t.is_closed = 0
    ORDER BY t.term_number ASC
    LIMIT 1
");
$term = $termStmt->fetch(PDO::FETCH_ASSOC);
if (!$term) {
    gradingTemplateDownloadError('There is no active, open term for the current school year.', 409);
}

$contextStmt = $pdo->prepare("
    SELECT s.id AS section_id, s.section_name, s.grade_level_id, s.strand,
           gl.grade_level_name, gl.grade_level_code,
           sub.id AS subject_id, sub.subject_name, sub.subject_type,
           ay.id AS academic_year_id, ay.year_label
    FROM tblsection s
    JOIN tblgradelevel gl ON gl.id = s.grade_level_id
    JOIN tblsubjects sub
      ON sub.id = :subject_id
     AND sub.grade_level_id = s.grade_level_id
     AND CAST(sub.strand AS CHAR) <=> CAST(s.strand AS CHAR)
     AND sub.academic_year_id = :subject_year_id
    JOIN tblacademicyear ay ON ay.id = :year_id AND ay.is_active = 1
    WHERE s.id = :section_id AND s.is_active = 1
    LIMIT 1
");
$contextStmt->execute([
    'subject_id' => $subjectId,
    'subject_year_id' => (int)$term['academic_year_id'],
    'year_id' => (int)$term['academic_year_id'],
    'section_id' => $sectionId,
]);
$context = $contextStmt->fetch(PDO::FETCH_ASSOC);
if (!$context) {
    gradingTemplateDownloadError('The selected section and subject do not match the active school year.', 404);
}

$gradeCode = (int)$context['grade_level_code'];
if ($gradeCode < 4 || $gradeCode > 10) {
    gradingTemplateDownloadError('Grading templates are available only for Grades 4–10.', 403);
}

$scheduleStmt = $pdo->prepare("
    SELECT 1
    FROM tblschedule
    WHERE section_id = ? AND subject_id = ? AND teacher_id = ?
      AND is_active = 1 AND school_year = ?
    LIMIT 1
");
$scheduleStmt->execute([$sectionId, $subjectId, $teacherId, $term['year_label']]);
if (!$scheduleStmt->fetchColumn()) {
    gradingTemplateDownloadError('You are not assigned to this section and subject.', 403);
}

$teacherStmt = $pdo->prepare("
    SELECT TRIM(CONCAT_WS(' ', fname, NULLIF(mname, ''), lname))
    FROM tblteacher
    WHERE id = ? AND is_active = 1
    LIMIT 1
");
$teacherStmt->execute([$teacherId]);
$teacherName = (string)($teacherStmt->fetchColumn() ?: ($_SESSION['teacher_name'] ?? 'Teacher'));

$studentsStmt = $pdo->prepare("
    SELECT s.lrn,
           CONCAT(s.lname, ', ', TRIM(CONCAT_WS(' ', NULLIF(s.fname, ''), NULLIF(s.mname, '')))) AS student_name
    FROM tblstudents s
    INNER JOIN tblsectionstudent ss ON ss.student_id = s.id
    WHERE ss.section_id = ?
      AND ss.is_active = 1
      AND ss.academic_year_id = ?
    ORDER BY s.lname, s.fname
");
$studentsStmt->execute([$sectionId, (int)$term['academic_year_id']]);
$students = $studentsStmt->fetchAll(PDO::FETCH_ASSOC);

$subjectName = (string)$context['subject_name'];
if (preg_match('/EPP|TLE/i', $subjectName)) {
    $templateType = 'EPP_TLE';
} elseif (preg_match('/GMRC|Values|Edukasyon sa Pagpapakatao/i', $subjectName)) {
    $templateType = 'GMRC';
} elseif (stripos($subjectName, 'MAPEH') !== false) {
    $templateType = 'MAPEH';
} else {
    $templateType = 'CORE';
}
$templateConfig = $templateConfigs[$templateType];

$metadata = [
    1 => 'STSN | School Year: ' . $term['year_label'],
    2 => $term['term_label']
        . ' | Grade Level: ' . $context['grade_level_name']
        . ' | Section: ' . $context['section_name']
        . ' | Teacher: ' . $teacherName
        . ' | Subject: ' . $context['subject_name'],
];
$rows = [
    1 => [1 => ['value' => $metadata[1], 'style' => 1]],
    2 => [1 => ['value' => $metadata[2], 'style' => 2]],
    3 => [],
    4 => [
        1 => ['value' => '', 'style' => 7],
        2 => ['value' => '', 'style' => 7],
        3 => ['value' => "LEARNER'S NAME", 'style' => 7],
        4 => ['value' => 'WRITTEN / ORAL WORKS (WWs)', 'style' => 7],
        5 => ['value' => '', 'style' => 7],
        6 => ['value' => '', 'style' => 7],
        7 => ['value' => '', 'style' => 7],
        8 => ['value' => '', 'style' => 7],
        9 => ['value' => '', 'style' => 7],
        10 => ['value' => '', 'style' => 7],
        11 => ['value' => '', 'style' => 7],
        12 => ['value' => 'PRODUCT / PERFORMANCE TASKS (PTs)', 'style' => 7],
        13 => ['value' => '', 'style' => 7],
        14 => ['value' => '', 'style' => 7],
        15 => ['value' => '', 'style' => 7],
        16 => ['value' => '', 'style' => 7],
        17 => ['value' => '', 'style' => 7],
        18 => ['value' => 'EXAMINATIONS (EXs)', 'style' => 7],
        19 => ['value' => '', 'style' => 7],
        20 => ['value' => '', 'style' => 7],
        21 => ['value' => 'Initial Grade', 'style' => 7],
        22 => ['value' => 'Term Grade', 'style' => 7],
        23 => ['value' => 'Descriptor', 'style' => 7],
    ],
    5 => [],
    6 => [],
    7 => [],
];
$subHeaders = [
    1 => '#',
    2 => 'LRN',
    3 => "LEARNER'S NAME",
    4 => 1,
    5 => 2,
    6 => 3,
    7 => 4,
    8 => 5,
    9 => 'Total',
    10 => 'PS',
    11 => 'WS',
    12 => 1,
    13 => 2,
    14 => 3,
    15 => 'Total',
    16 => 'PS',
    17 => 'WS',
    18 => 'ST1',
    19 => 'ST2',
    20 => 'TE',
    21 => 'Initial Grade',
    22 => 'Term Grade',
    23 => 'Descriptor',
];
foreach ($subHeaders as $column => $value) {
    $rows[5][$column] = ['value' => $value, 'style' => 8];
}

$hpsValues = array_fill(1, 23, '');
$hpsValues[3] = 'HIGHEST POSSIBLE SCORE';
$hpsValues[9] = 100;
$hpsValues[10] = 100;
$hpsValues[11] = $templateConfig['ww'];
$hpsValues[15] = 100;
$hpsValues[16] = 100;
$hpsValues[17] = $templateConfig['pt'];
$hpsValues[18] = 30;
$hpsValues[19] = 30;
$hpsValues[20] = 40;
foreach ($hpsValues as $column => $value) {
    $rows[7][$column] = ['value' => $value, 'style' => 9];
}

$merges = [
    'A1:W1',
    'A2:W2',
    'A4:B4',
    'D4:H4',
    'I4:K4',
    'L4:N4',
    'O4:Q4',
    'R4:T4',
];

foreach ($students as $index => $student) {
    $rowNumber = $index + 8;
    $studentName = trim((string)$student['student_name']);
    $studentValues = array_fill(1, 23, '');
    $studentValues[1] = $index + 1;
    $studentValues[2] = (string)($student['lrn'] ?? '');
    $studentValues[3] = $studentName;
    foreach ($studentValues as $column => $value) {
        $rows[$rowNumber][$column] = ['value' => $value, 'style' => 6];
    }
}

$xlsx = stsnXlsxCreate($rows, $merges, [
    1 => 6, 2 => 17, 3 => 32,
    4 => 9, 5 => 9, 6 => 9, 7 => 9, 8 => 9,
    9 => 11, 10 => 8, 11 => 8,
    12 => 9, 13 => 9, 14 => 9,
    15 => 11, 16 => 8, 17 => 8,
    18 => 10, 19 => 10, 20 => 10,
    21 => 14, 22 => 14, 23 => 18,
], 'TERM ' . (int)$term['term_number']);
$filename = $term['term_label'] . ' - ' . $context['section_name'] . ' - ' . $context['subject_name'] . '.xlsx';
$filename = preg_replace('/[^\pL\pN ._-]+/u', '', $filename) ?? 'Grading Template.xlsx';
$filename = trim(str_replace(["\r", "\n"], '', $filename));

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . strlen($xlsx));
header('Cache-Control: private, no-store, max-age=0');
echo $xlsx;
