<?php
require_once __DIR__ . '/../api/login/teacher_auth.php';

$teacherName = $_SESSION['teacher_name'] ?? 'Teacher';
$teacherId = (int) ($_SESSION['teacher_id'] ?? 0);

$activeYear = $pdo->query("
    SELECT id, year_label
    FROM tblacademicyear
    WHERE is_active = 1
    LIMIT 1
")->fetch(PDO::FETCH_ASSOC) ?: null;

$activeYearId = $activeYear ? (int) $activeYear['id'] : 0;
$schoolYear = $activeYear['year_label'] ?? date('Y') . '-' . (date('Y') + 1);

$quarterStmt = $pdo->prepare("
    SELECT quarter_number, quarter_label
    FROM tblquarters
    WHERE academic_year_id = ? AND is_active = 1
    ORDER BY quarter_number ASC
    LIMIT 1
");
$quarterStmt->execute([$activeYearId]);
$activeQuarter = $quarterStmt->fetch(PDO::FETCH_ASSOC) ?: null;
$quarterNumber = $activeQuarter ? (int) $activeQuarter['quarter_number'] : 1;
$quarterLabel = $activeQuarter['quarter_label'] ?? '1st';

$deadlineStmt = $pdo->prepare("
    SELECT adviser_deadline
    FROM tbldeadlines
    WHERE school_year = ? AND quarter = ?
    ORDER BY id DESC
    LIMIT 1
");
$deadlineStmt->execute([$schoolYear, $quarterNumber]);
$deadlineRow = $deadlineStmt->fetch(PDO::FETCH_ASSOC) ?: [];
$adviserDeadline = $deadlineRow['adviser_deadline'] ?? null;
$isDeadlinePast = $adviserDeadline ? strtotime($adviserDeadline) < time() : false;

$advisoryStmt = $pdo->prepare("
    SELECT
        sa.section_id,
        sec.section_name,
        sec.strand,
        gl.grade_level_name,
        gl.grade_level_code,
        COUNT(DISTINCT ss.student_id) AS total_students
    FROM tblsectionadviser sa
    INNER JOIN tblsection sec ON sec.id = sa.section_id
    INNER JOIN tblgradelevel gl ON gl.id = sec.grade_level_id
    LEFT JOIN tblsectionstudent ss
        ON ss.section_id = sa.section_id
       AND ss.academic_year_id = sa.academic_year_id
       AND ss.is_active = 1
    WHERE sa.teacher_id = ?
      AND sa.academic_year_id = ?
    GROUP BY sa.section_id, sec.section_name, sec.strand, gl.grade_level_name, gl.grade_level_code
    ORDER BY gl.sort_order ASC, sec.section_name ASC
");
$advisoryStmt->execute([$teacherId, $activeYearId]);
$advisories = $advisoryStmt->fetchAll(PDO::FETCH_ASSOC);
$selectedSectionId = isset($_GET['section_id']) ? (int) $_GET['section_id'] : (int) ($advisories[0]['section_id'] ?? 0);

$selectedAdvisory = null;
foreach ($advisories as $advisory) {
    if ((int) $advisory['section_id'] === $selectedSectionId) {
        $selectedAdvisory = $advisory;
        break;
    }
}

$students = [];
if ($selectedSectionId > 0 && $activeYearId > 0) {
    $studentStmt = $pdo->prepare("
        SELECT
            st.id,
            st.lrn,
            st.fname,
            st.mname,
            st.lname,
            st.gender
        FROM tblsectionstudent ss
        INNER JOIN tblstudents st ON st.id = ss.student_id
        WHERE ss.section_id = ?
          AND ss.academic_year_id = ?
          AND ss.is_active = 1
          AND COALESCE(st.is_active, 1) = 1
        ORDER BY st.lname ASC, st.fname ASC, st.mname ASC
    ");
    $studentStmt->execute([$selectedSectionId, $activeYearId]);
    $students = $studentStmt->fetchAll(PDO::FETCH_ASSOC);
}

$studentsPayload = array_map(static function (array $student): array {
    $middle = trim((string) ($student['mname'] ?? ''));
    $middleInitial = $middle !== '' ? strtoupper(substr($middle, 0, 1)) . '. ' : '';
    $fullName = trim(($student['lname'] ?? '') . ', ' . ($student['fname'] ?? '') . ' ' . $middleInitial);

    return [
        'id' => (int) $student['id'],
        'lrn' => (string) ($student['lrn'] ?? ''),
        'name' => preg_replace('/\s+/', ' ', $fullName),
        'gender' => (string) ($student['gender'] ?? ''),
    ];
}, $students);

$sectionLabel = $selectedAdvisory
    ? trim(($selectedAdvisory['grade_level_name'] ?? '') . ' - ' . ($selectedAdvisory['section_name'] ?? ''), ' -')
    : 'No advisory class selected';

$coreValues = [
    [
        'group' => 'Maka-Diyos',
        'statements' => [
            "Expresses one's spiritual beliefs while respecting those of others",
            'Shows adherence to ethical principles by upholding truth',
        ],
    ],
    [
        'group' => 'Makatao',
        'statements' => [
            'Is sensitive to individual, social, and multicultural differences',
            'Demonstrates contribution toward solidarity',
        ],
    ],
    [
        'group' => 'Makakalikasan',
        'statements' => [
            'Cares for the environment and utilizes resources wisely, judiciously, and economically',
        ],
    ],
    [
        'group' => 'Makabansa',
        'statements' => [
            'Demonstrates pride in being a Filipino; exercises the rights and responsibilities of a Filipino citizen',
            'Demonstrates appropriate behavior in carrying out activities in the school, community, and country',
        ],
    ],
];

$statementCount = array_sum(array_map(static fn($group) => count($group['statements']), $coreValues));
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deportment | STSN Grading System</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/system-alerts.css">
    <style>
        :root {
            --primary: #0A2F44;
            --primary-soft: rgba(10, 47, 68, 0.08);
            --accent: #C5A028;
            --bg: #F5F7FA;
            --surface: #FFFFFF;
            --surface-2: #F8F9FA;
            --text: #1E2A3E;
            --muted: #6C757D;
            --border: #E9ECEF;
            --danger: #DC3545;
            --success: #198754;
            --warning: #D97706;
            --shadow: 0 10px 30px rgba(10, 47, 68, 0.08);
            --radius: 18px;
            --sidebar-width: 264px;
            --sidebar-collapsed-width: 72px;
            --diyos: #EBF4FF;
            --tao: #F4EEFF;
            --kalikasan: #EAFAF3;
            --bansa: #FFF8E1;
        }

        * { box-sizing: border-box; }
        html, body { min-height: 100%; }
        body.stsn-layout { margin: 0; font-family: "Plus Jakarta Sans", sans-serif; background: var(--bg); color: var(--text); }

        #stsn-toggle { position: fixed; top: 1rem; left: 1rem; z-index: 1100; width: 44px; height: 44px; border: 1px solid var(--border); border-radius: 12px; background: #fff; color: var(--primary); display: none; align-items: center; justify-content: center; box-shadow: var(--shadow); cursor: pointer; }
        #stsn-overlay { position: fixed; inset: 0; background: rgba(15, 23, 42, 0.35); opacity: 0; visibility: hidden; transition: 0.25s ease; z-index: 1035; }
        #stsn-overlay.visible { opacity: 1; visibility: visible; }

        .page-shell { margin-left: var(--sidebar-width); min-height: 100vh; transition: margin-left 0.28s ease; display: flex; flex-direction: column; }
        body.sidebar-collapsed .page-shell { margin-left: var(--sidebar-collapsed-width); }

        .top-bar { background: var(--surface); border-bottom: 1px solid var(--border); padding: .85rem 1.5rem; display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap; position: sticky; top: 0; z-index: 40; }
        .top-bar-left h1 { margin: 0; font-size: 1.25rem; font-weight: 800; color: var(--primary); display: flex; align-items: center; gap: .5rem; }
        .top-bar-left p { margin: .2rem 0 0; color: var(--muted); font-size: .82rem; }
        .top-bar-right { display: flex; align-items: center; gap: .55rem; flex-wrap: wrap; }
        .meta-chip { background: #fff; border: 1px solid var(--border); border-radius: 999px; padding: .45rem .8rem; font-size: .78rem; color: var(--muted); display: inline-flex; align-items: center; gap: 5px; white-space: nowrap; }
        .meta-chip.warning { background: #fff8e1; border-color: #fde68a; color: #92400e; }
        .meta-chip.danger { background: #fee2e2; border-color: #fecaca; color: #b91c1c; }

        .btn { border: 1px solid var(--border); border-radius: 12px; background: #fff; color: var(--primary); font-family: inherit; font-weight: 800; font-size: .84rem; padding: .62rem .95rem; display: inline-flex; align-items: center; gap: 6px; cursor: pointer; text-decoration: none; }
        .btn:hover { background: var(--surface-2); }
        .btn-primary { background: var(--primary); border-color: var(--primary); color: #fff; }
        .btn-primary:hover { background: #0d3b56; }
        .btn:disabled { opacity: .55; cursor: not-allowed; }

        .page-main { padding: 1rem 1.5rem 1.5rem; display: grid; gap: 1rem; }
        .status-banner { border: 1px solid #fde68a; background: #fff8e1; color: #92400e; border-radius: 14px; padding: .85rem 1rem; display: flex; align-items: flex-start; gap: .65rem; font-size: .86rem; line-height: 1.45; }
        .status-banner.success { border-color: #a7f3d0; background: #ecfdf5; color: #065f46; }
        .status-banner.danger { border-color: #fecaca; background: #fee2e2; color: #991b1b; }

        .panel { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); box-shadow: var(--shadow); overflow: hidden; }
        .panel-header { padding: 1rem 1.25rem; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: flex-start; gap: 1rem; flex-wrap: wrap; }
        .panel-title { margin: 0; color: var(--primary); font-size: 1rem; font-weight: 800; display: flex; align-items: center; gap: .5rem; }
        .panel-title i { color: var(--accent); }
        .panel-sub { margin-top: .2rem; color: var(--muted); font-size: .8rem; }
        .summary-pills { display: flex; flex-wrap: wrap; gap: .45rem; }
        .pill { display: inline-flex; align-items: center; justify-content: center; border-radius: 999px; padding: .32rem .62rem; font-size: .72rem; font-weight: 800; white-space: nowrap; }
        .pill-neutral { background: var(--surface-2); color: var(--muted); }
        .pill-success { background: #d1fae5; color: #065f46; }
        .pill-warning { background: #fef3c7; color: #92400e; }

        .panel-header select.btn { appearance: none; -webkit-appearance: none; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='%236C757D' viewBox='0 0 16 16'%3E%3Cpath d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right .6rem center; padding-right: 1.6rem; }
        .panel-header .btn { font-size: .8rem; padding: .5rem .8rem; }
        .panel-header .summary-pills .pill { font-size: .68rem; padding: .25rem .5rem; }

        .table-wrap { overflow: auto; max-height: calc(100vh - 270px); }
        .deportment-table { width: max-content; min-width: 100%; border-collapse: collapse; font-size: 12px; }
        .deportment-table th, .deportment-table td { border: 1px solid #d8e0ea; }
        .deportment-table thead th { position: sticky; top: 0; z-index: 4; text-align: center; font-weight: 800; color: var(--primary); }
        .deportment-table th { padding: .45rem .35rem; }
        .deportment-table td { padding: .35rem; background: #fff; }
        .student-head { left: 0; z-index: 6 !important; background: #f8fafc !important; min-width: 230px; max-width: 230px; }
        .student-cell { position: sticky; left: 0; z-index: 3; background: #fff !important; min-width: 230px; max-width: 230px; }
        .student-name { font-weight: 800; color: var(--text); }
        .student-meta { color: var(--muted); font-size: .72rem; margin-top: 2px; }
        .group-head { min-width: 560px; font-size: .76rem; text-transform: uppercase; letter-spacing: .04em; }
        .statement-head { min-width: 165px; max-width: 165px; height: 82px; vertical-align: bottom; line-height: 1.25; font-size: .68rem; }
        .quarter-head { width: 42px; min-width: 42px; font-size: .62rem; line-height: 1.05; }
        .final-head { width: 48px; min-width: 48px; font-size: .62rem; line-height: 1.05; }
        .group-diyos { background: var(--diyos) !important; }
        .group-tao { background: var(--tao) !important; }
        .group-kalikasan { background: var(--kalikasan) !important; }
        .group-bansa { background: var(--bansa) !important; }
        .rating-select { width: 40px; border: 1px solid #ccd6e3; border-radius: 8px; padding: .28rem .18rem; font-family: inherit; font-size: .72rem; text-align: center; background: #fff; color: var(--text); }
        .rating-select.final { font-weight: 800; background: #f8fafc; }
        .row-imported td { background: #fbfdff; }

        .side-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: .8rem; }
        .mini-card { background: var(--surface); border: 1px solid var(--border); border-radius: 14px; padding: .85rem; box-shadow: var(--shadow); }
        .mini-label { color: var(--muted); font-size: .74rem; font-weight: 800; text-transform: uppercase; letter-spacing: .04em; }
        .mini-value { color: var(--primary); font-size: 1.25rem; font-weight: 800; margin-top: .2rem; }
        .legend { display: flex; flex-wrap: wrap; gap: .5rem; font-size: .78rem; color: var(--muted); }
        .legend strong { color: var(--primary); }
        .empty-state { padding: 2rem; text-align: center; color: var(--muted); }

        @media (max-width: 991.98px) {
            #stsn-toggle { display: flex; }
            .page-shell, body.sidebar-collapsed .page-shell { margin-left: 0; }
            .top-bar { padding: 4.5rem 1rem 1rem; }
            .page-main { padding-left: 1rem; padding-right: 1rem; }
            .side-grid { grid-template-columns: 1fr; }
            .table-wrap { max-height: none; }
        }

        @media (max-width: 640px) {
            .top-bar-left h1 { font-size: 1.05rem; }
            .panel-header { padding: .85rem; }
            .student-head, .student-cell { min-width: 190px; max-width: 190px; }
            .statement-head { min-width: 145px; max-width: 145px; }
        }
    </style>
    <link rel="stylesheet" href="../css/teacher-alerts.css">
</head>

<body class="stsn-layout">
    <button id="stsn-toggle" aria-label="Toggle sidebar"><i class="bi bi-list"></i></button>
    <div id="stsn-overlay"></div>

    <?php include __DIR__ . '/../includes/teacher-sidebar.php'; ?>

    <div class="page-shell">
        <header class="top-bar">
            <div class="top-bar-left">
                <h1><i class="bi bi-star"></i> Deportment</h1>
                <p><?= htmlspecialchars($sectionLabel) ?> core-values record for <?= htmlspecialchars($schoolYear) ?>.</p>
            </div>
            <div class="top-bar-right">
                <span class="meta-chip"><i class="bi bi-person-badge"></i> <?= htmlspecialchars($teacherName) ?></span>
                <span class="meta-chip"><i class="bi bi-calendar3"></i> <?= htmlspecialchars($quarterLabel) ?> Quarter</span>
                <span class="meta-chip <?= $isDeadlinePast ? 'danger' : 'warning' ?>">
                    <i class="bi bi-hourglass-split"></i>
                    <?= $adviserDeadline ? htmlspecialchars(date('M d, Y h:i A', strtotime($adviserDeadline))) : 'No adviser deadline set' ?>
                </span>
            </div>
        </header>

        <main class="page-main">
            <?php require_once __DIR__ . '/../includes/breadcrumb.php'; renderBreadcrumb([['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'], ['label' => 'Character Evaluation', 'href' => 'Deportment.php', 'icon' => 'bi bi-star'], ['label' => 'Deportment', 'icon' => 'bi bi-clipboard-check']], 'teacher'); ?>
            <div id="importStatus" class="status-banner <?= $isDeadlinePast ? 'danger' : 'success' ?>">
                <i class="bi <?= $isDeadlinePast ? 'bi-lock-fill' : 'bi-info-circle-fill' ?>"></i>
                <div>
                    <strong><?= $isDeadlinePast ? 'Deadline window has passed.' : 'Ready for import.' ?></strong>
                    The table below always lists all learners in the selected advisory. Importing fills matching ratings by LRN, name, or row order while keeping unmatched students visible.
                </div>
            </div>

            <section class="side-grid">
                <div class="mini-card">
                    <div class="mini-label">Students</div>
                    <div class="mini-value" id="studentCount"><?= number_format(count($students)) ?></div>
                </div>
                <div class="mini-card">
                    <div class="mini-label">Imported Rows</div>
                    <div class="mini-value" id="matchedCount">0</div>
                </div>
                <div class="mini-card">
                    <div class="mini-label">Core Values</div>
                    <div class="mini-value"><?= number_format($statementCount) ?></div>
                </div>
            </section>

            <section class="panel">
                <div class="panel-header" style="flex-wrap:wrap;gap:.75rem;">
                    <div>
                        <h2 class="panel-title"><i class="bi bi-table"></i> Learner Observed Values</h2>
                        <div class="panel-sub">Makadiyos, Makatao, Makakalikasan, and Makabansa with 1st to 4th quarter and final ratings.</div>
                        <div class="legend" aria-label="Rating legend">
                            <span><strong>AO</strong> = Always Observed</span>
                            <span><strong>SO</strong> = Sometimes Observed</span>
                            <span><strong>RO</strong> = Rarely Observed</span>
                            <span><strong>NO</strong> = Not Observed</span>
                        </div>
                    </div>
                    <div style="display:flex;align-items:center;gap:.55rem;flex-wrap:wrap;margin-left:auto;">
                        <select name="section_id" class="btn" style="padding:.52rem .75rem;" onchange="window.location.href='?section_id='+this.value">
                            <?php foreach ($advisories as $advisory): ?>
                                <?php
                                $id = (int) $advisory['section_id'];
                                $label = trim(($advisory['grade_level_name'] ?? '') . ' - ' . ($advisory['section_name'] ?? ''), ' -');
                                ?>
                                <option value="<?= $id ?>" <?= $id === $selectedSectionId ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($label) ?> (<?= number_format((int) $advisory['total_students']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <label class="btn" style="cursor:pointer;">
                            <i class="bi bi-upload"></i> Import
                            <input type="file" id="deportmentFile" accept=".xlsx,.xls,.csv" style="display:none;">
                        </label>
                        <button type="button" class="btn btn-primary" id="applyImportBtn" disabled>
                            <i class="bi bi-check2"></i> Apply
                        </button>
                        <button type="button" class="btn btn-primary" id="saveDeportmentBtn" <?= $students ? '' : 'disabled' ?>>
                            <i class="bi bi-save"></i> Save
                        </button>
                        <button type="button" class="btn" onclick="clearRatings()">
                            <i class="bi bi-eraser"></i> Clear
                        </button>
                    </div>
                </div>

                <?php if ($students): ?>
                    <div class="table-wrap">
                        <table class="deportment-table" id="deportmentTable">
                            <thead>
                                <tr>
                                    <th rowspan="3" class="student-head">Learner</th>
                                    <?php foreach ($coreValues as $valueIndex => $group): ?>
                                        <?php
                                        $slug = ['group-diyos', 'group-tao', 'group-kalikasan', 'group-bansa'][$valueIndex];
                                        $span = count($group['statements']) * 5;
                                        ?>
                                        <th colspan="<?= $span ?>" class="group-head <?= $slug ?>"><?= htmlspecialchars($group['group']) ?></th>
                                    <?php endforeach; ?>
                                </tr>
                                <tr>
                                    <?php foreach ($coreValues as $valueIndex => $group): ?>
                                        <?php $slug = ['group-diyos', 'group-tao', 'group-kalikasan', 'group-bansa'][$valueIndex]; ?>
                                        <?php foreach ($group['statements'] as $statement): ?>
                                            <th colspan="5" class="statement-head <?= $slug ?>"><?= htmlspecialchars($statement) ?></th>
                                        <?php endforeach; ?>
                                    <?php endforeach; ?>
                                </tr>
                                <tr>
                                    <?php foreach ($coreValues as $group): ?>
                                        <?php foreach ($group['statements'] as $statement): ?>
                                            <th class="quarter-head">1ST<br>QTR</th>
                                            <th class="quarter-head">2ND<br>QTR</th>
                                            <th class="quarter-head">3RD<br>QTR</th>
                                            <th class="quarter-head">4TH<br>QTR</th>
                                            <th class="final-head">FINAL</th>
                                        <?php endforeach; ?>
                                    <?php endforeach; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($studentsPayload as $rowIndex => $student): ?>
                                    <tr data-index="<?= $rowIndex ?>" data-student-id="<?= $student['id'] ?>" data-lrn="<?= htmlspecialchars($student['lrn']) ?>" data-name="<?= htmlspecialchars(strtolower($student['name'])) ?>">
                                        <td class="student-cell">
                                            <div class="student-name"><?= htmlspecialchars($student['name']) ?></div>
                                            <div class="student-meta">LRN: <?= htmlspecialchars($student['lrn'] ?: 'Not set') ?><?= $student['gender'] ? ' · ' . htmlspecialchars($student['gender']) : '' ?></div>
                                        </td>
                                        <?php for ($statement = 0; $statement < $statementCount; $statement++): ?>
                                            <?php for ($quarter = 1; $quarter <= 5; $quarter++): ?>
                                                <td>
                                                    <select class="rating-select <?= $quarter === 5 ? 'final' : '' ?>" data-statement="<?= $statement ?>" data-quarter="<?= $quarter ?>">
                                                        <option value=""></option>
                                                        <option value="AO">AO</option>
                                                        <option value="SO">SO</option>
                                                        <option value="RO">RO</option>
                                                        <option value="NO">NO</option>
                                                    </select>
                                                </td>
                                            <?php endfor; ?>
                                        <?php endfor; ?>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="bi bi-people"></i>
                        No active learners were found for this advisory class.
                    </div>
                <?php endif; ?>
            </section>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
    <script>
        const advisoryStudents = <?= json_encode($studentsPayload, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?>;
        const selectedSectionId = <?= (int) $selectedSectionId ?>;
        const statementCount = <?= (int) $statementCount ?>;
        const ratings = ['AO', 'SO', 'RO', 'NO'];
        let pendingImport = null;

        document.getElementById('deportmentFile')?.addEventListener('change', function(e){ handleImportFile(e); });
        document.getElementById('applyImportBtn')?.addEventListener('click', applyImport);
        document.getElementById('saveDeportmentBtn')?.addEventListener('click', saveDeportment);

        function normalizeText(value) {
            return String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
        }

        function normalizeRating(value) {
            const clean = String(value || '').toUpperCase().replace(/[^A-Z]/g, '');
            if (ratings.includes(clean)) return clean;
            if (clean === 'ALWAYSOBSERVED') return 'AO';
            if (clean === 'SOMETIMESOBSERVED') return 'SO';
            if (clean === 'RARELYOBSERVED') return 'RO';
            if (clean === 'NOTOBSERVED') return 'NO';
            return '';
        }

        async function handleImportFile(event) {
            const file = event.target.files?.[0];
            if (!file) return;
            if (typeof XLSX === 'undefined') {
                setImportStatus('danger', 'Excel parser unavailable.', 'Please check your internet connection, then reload this page.');
                return;
            }

            try {
                const buffer = await file.arrayBuffer();
                const workbook = XLSX.read(buffer, { type: 'array' });
                const sheet = workbook.Sheets[workbook.SheetNames[0]];

                const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });
                pendingImport = parseDeportmentRows(rows);

                document.getElementById('applyImportBtn').disabled = !pendingImport.length;
                setImportStatus(
                    pendingImport.length ? 'success' : 'danger',
                    pendingImport.length ? 'Import preview ready.' : 'No rating rows detected.',
                    pendingImport.length
                        ? `${pendingImport.length} possible row${pendingImport.length === 1 ? '' : 's'} found. Click Apply Import to fill the advisory table.`
                        : 'Make sure the file includes student names or LRN and AO/SO/RO/NO rating cells.'
                );
            } catch (error) {
                console.error(error);
                pendingImport = [];
                document.getElementById('applyImportBtn').disabled = true;
                setImportStatus('danger', 'Import failed.', error.message || 'The selected file could not be read.');
            } finally {
                event.target.value = '';
            }
        }

        
        function parseDeportmentRows(rows) {
            const parsed = [];
            const columnMap = [];

            let headerRowIndex = -1;
            const quarterFromHeader = (cell) => {
                const compact = String(cell || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
                if (/^(1|Q1|1ST|1STQTR|FIRST|FIRSTQTR|FIRSTQUARTER)$/.test(compact)) return 1;
                if (/^(2|Q2|2ND|2NDQTR|SECOND|SECONDQTR|SECONDQUARTER)$/.test(compact)) return 2;
                if (/^(3|Q3|3RD|3RDQTR|THIRD|THIRDQTR|THIRDQUARTER)$/.test(compact)) return 3;
                if (/^(4|Q4|4TH|4THQTR|FOURTH|FOURTHQTR|FOURTHQUARTER)$/.test(compact)) return 4;
                if (/^(FINAL|FINALRATING|FINALGRADE)$/.test(compact)) return 5;
                return 0;
            };

            for (let i = 0; i < rows.length; i++) {
                const row = rows[i].map(c => String(c || '').trim().toUpperCase());
                const qtrHits = row.filter(c => quarterFromHeader(c)).length;
                if (qtrHits >= 4) {
                    headerRowIndex = i;

                    let statementIdx = -1;
                    row.forEach((cell, colIdx) => {
                        const quarter = quarterFromHeader(cell);
                        if (quarter === 1) {
                            statementIdx++;
                            columnMap[colIdx] = { statement: statementIdx, quarter };
                        } else if (quarter >= 2 && quarter <= 5 && statementIdx >= 0) {
                            columnMap[colIdx] = { statement: statementIdx, quarter };
                        }
                    });
                    break;
                }
            }

            const hasColumnMap = columnMap.some(Boolean);

            const dataRows = headerRowIndex >= 0 ? rows.slice(headerRowIndex + 1) : rows;

            dataRows.forEach((row) => {
                const cells = row.map(c => String(c || '').trim());

                const ratingCells = cells.filter(c => normalizeRating(c));
                if (ratingCells.length < 4) return;

                const nameIndex = cells.findIndex(c => {
                    const n = normalizeText(c);
                    return (
                        n &&
                        !/^\d+$/.test(c) &&
                        /[a-z]{2,}/.test(n) &&
                        !ratings.includes(c.toUpperCase()) &&
                        !/(quarter|final|maka|expresses|shows|demonstrates|cares|sensitive|always|sometimes|rarely|not\s*observed)/i.test(n)
                    );
                });

                const lrnCell = cells.find(c => /^\d{8,}$/.test(c.replace(/\D/g, ''))) || '';

                const totalSlots = statementCount * 5;
                const values = new Array(totalSlots).fill('');

                if (hasColumnMap) {
                    cells.forEach((cell, colIdx) => {
                        const map = columnMap[colIdx];
                        if (!map) return;
                        const rating = normalizeRating(cell);
                        if (!rating) return;
                        const flatIndex = map.statement * 5 + (map.quarter - 1);
                        if (flatIndex >= 0 && flatIndex < totalSlots) {
                            values[flatIndex] = rating;
                        }
                    });
                } else {
                    let fill = 0;
                    cells.forEach(cell => {
                        const r = normalizeRating(cell);
                        if (r && fill < totalSlots) values[fill++] = r;
                    });
                }

                parsed.push({
                    name: nameIndex >= 0 ? cells[nameIndex] : '',
                    lrn: lrnCell.replace(/\D/g, ''),
                    values
                });
            });

            return parsed;
        }

        function applyImport() {
            if (!pendingImport?.length) return;
            clearRatings(false);

            let matched = 0;
            const unusedRows = [...pendingImport];

            document.querySelectorAll('#deportmentTable tbody tr').forEach((tr, index) => {
                const lrn = tr.dataset.lrn || '';
                const name = normalizeText(tr.dataset.name || '');
                let importIndex = unusedRows.findIndex((row) => row.lrn && lrn && row.lrn === lrn);

                if (importIndex < 0) {
                    importIndex = unusedRows.findIndex((row) => {
                        const importedName = normalizeText(row.name);
                        return importedName && name && (name.includes(importedName) || importedName.includes(name));
                    });
                }

                if (importIndex < 0 && unusedRows[index]) {
                    importIndex = index;
                }

                if (importIndex < 0) return;

                const imported = unusedRows.splice(importIndex, 1)[0];
                const selects = tr.querySelectorAll('.rating-select');

                imported.values.forEach((value, valueIndex) => {
                    if (selects[valueIndex] && value) {
                        selects[valueIndex].value = value;
                    }
                });

                tr.classList.add('row-imported');
                matched++;
            });

            document.getElementById('matchedCount').textContent = matched;
            setImportStatus('success', 'Import applied.', `${matched} of ${advisoryStudents.length} advisory learner${advisoryStudents.length === 1 ? '' : 's'} received imported deportment ratings.`);
        }

        async function loadSavedDeportment() {
            if (!selectedSectionId || !advisoryStudents.length) return;

            try {
                const response = await fetch(`../api/advisory/get_deportment.php?section_id=${encodeURIComponent(selectedSectionId)}`);
                const data = await response.json();
                if (!data.success) {
                    setImportStatus('danger', 'Unable to load saved ratings.', data.message || 'Please reload and try again.');
                    return;
                }

                let filled = 0;
                document.querySelectorAll('#deportmentTable tbody tr').forEach((tr) => {
                    const studentId = tr.dataset.studentId;
                    const studentRatings = data.records?.[studentId] || {};

                    tr.querySelectorAll('.rating-select').forEach((select) => {
                        const statement = select.dataset.statement;
                        const quarter = select.dataset.quarter;
                        const value = studentRatings?.[statement]?.[quarter] || '';
                        if (value) filled++;
                        select.value = value;
                    });
                });

                if (filled > 0) {
                    setImportStatus('success', 'Saved ratings loaded.', `${filled} deportment rating${filled === 1 ? '' : 's'} are ready for editing or printing after submission.`);
                }
            } catch (error) {
                setImportStatus('danger', 'Unable to load saved ratings.', 'Please reload and try again.');
            }
        }

        async function saveDeportment() {
            const btn = document.getElementById('saveDeportmentBtn');
            if (!btn || !selectedSectionId) return;

            const payload = [];
            document.querySelectorAll('#deportmentTable tbody tr').forEach((tr) => {
                const studentId = parseInt(tr.dataset.studentId || '0', 10);
                if (!studentId) return;

                tr.querySelectorAll('.rating-select').forEach((select) => {
                    const rating = normalizeRating(select.value);
                    if (!rating) return;
                    payload.push({
                        student_id: studentId,
                        statement_index: parseInt(select.dataset.statement || '0', 10),
                        quarter: parseInt(select.dataset.quarter || '0', 10),
                        rating
                    });
                });
            });

            const original = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = '<i class="bi bi-hourglass-split"></i> Saving...';

            try {
                const response = await fetch('../api/advisory/save_deportment.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ section_id: selectedSectionId, ratings: payload })
                });
                const data = await response.json();
                if (!data.success) {
                    throw new Error(data.message || 'Unable to save deportment ratings.');
                }

                setImportStatus('success', 'Ratings saved.', `${data.saved_count || 0} deportment rating${Number(data.saved_count || 0) === 1 ? '' : 's'} will appear in the admin grades report printout after submission.`);
            } catch (error) {
                setImportStatus('danger', 'Save failed.', error.message || 'Please try again.');
            } finally {
                btn.disabled = false;
                btn.innerHTML = original;
            }
        }

        function clearRatings(showStatus = true) {
            document.querySelectorAll('.rating-select').forEach((select) => select.value = '');
            document.querySelectorAll('.row-imported').forEach((row) => row.classList.remove('row-imported'));
            document.getElementById('matchedCount').textContent = '0';
            if (showStatus) setImportStatus('success', 'Ratings cleared.', 'All advisory rows remain visible and ready for a new import.');
        }

        function setImportStatus(kind, title, message) {
            const status = document.getElementById('importStatus');
            if (!status) return;
            status.className = `status-banner ${kind}`;
            const icon = kind === 'danger' ? 'bi-exclamation-circle-fill' : (kind === 'success' ? 'bi-check-circle-fill' : 'bi-info-circle-fill');
            status.innerHTML = `<i class="bi ${icon}"></i><div><strong>${escapeHtml(title)}</strong> ${escapeHtml(message)}</div>`;
        }

        function escapeHtml(value) {
            return String(value).replace(/[&<>"']/g, (char) => ({
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            }[char]));
        }

        loadSavedDeportment();

        (function () {
            const sidebar = document.getElementById('stsn-sidebar');
            const toggleBtn = document.getElementById('stsn-toggle');
            const collapseBtn = document.getElementById('stsn-collapse-btn');
            const overlay = document.getElementById('stsn-overlay');
            const body = document.body;
            const html = document.documentElement;

            if (!sidebar) return;

            const COOKIE_NAME = 'stsn_sidebar_collapsed';
            const mqDesktop = window.matchMedia('(min-width: 992px)');
            const mqMobile = window.matchMedia('(max-width: 991px)');

            requestAnimationFrame(function () {
                html.classList.remove('stsn-pre-collapsed');
            });

            if (toggleBtn) {
                toggleBtn.addEventListener('click', function () {
                    sidebar.classList.add('mobile-open');
                    if (overlay) overlay.classList.add('visible');
                });
            }

            if (overlay) overlay.addEventListener('click', closeMobileDrawer);

            if (collapseBtn) {
                collapseBtn.addEventListener('click', function () {
                    if (mqMobile.matches) {
                        closeMobileDrawer();
                        return;
                    }
                    const collapsed = sidebar.classList.toggle('collapsed');
                    body.classList.toggle('sidebar-collapsed', collapsed);
                    rotateChevron(collapsed);
                    setCookie(COOKIE_NAME, collapsed ? '1' : '0', 365);
                });
            }

            sidebar.querySelectorAll('.stsn-link').forEach(function (link) {
                link.addEventListener('click', function () {
                    if (mqMobile.matches) closeMobileDrawer();
                });
            });

            document.addEventListener('keydown', function (event) {
                if (event.key === 'Escape' && sidebar.classList.contains('mobile-open')) closeMobileDrawer();
            });

            window.addEventListener('resize', function () {
                if (mqDesktop.matches) closeMobileDrawer();
            });

            function closeMobileDrawer() {
                sidebar.classList.remove('mobile-open');
                if (overlay) overlay.classList.remove('visible');
            }

            function rotateChevron(collapsed) {
                const icon = collapseBtn ? collapseBtn.querySelector('i') : null;
                if (!icon) return;
                icon.classList.toggle('bi-chevron-left', !collapsed);
                icon.classList.toggle('bi-chevron-right', collapsed);
            }

            function setCookie(name, value, days) {
                const maxAge = days * 24 * 60 * 60;
                document.cookie = name + '=' + value + '; path=/; max-age=' + maxAge + '; SameSite=Lax';
            }
        })();
    </script>
</body>

</html>
