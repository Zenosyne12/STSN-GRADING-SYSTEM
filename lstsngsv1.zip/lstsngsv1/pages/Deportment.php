<?php
$schoolName = "EFILES ELEMENTARY SCHOOL";
$schoolYear = "2024-2025";
$subject = "LANGUAGE";
$gradeSection = "Grade 4 - Mabini";
$teacher = "Mr. Roberts";

$writtenWorksHPS = [10,10,10,10,10,10,10,10,10,10];
$performanceTasksHPS = [100,100,100,100,100,100,100,100,100,100];
$quarterlyAssessmentHPS = 100;

$students = [
    [
        'name' => 'ANDRE',
        'sex' => 'MALE',
        'ww' => [5,8,8,9,10,5,10,6,10,10],
        'pt' => [70,80,95,95,95,85,95,85,75,75],
        'qa' => 88,
    ],
    [
        'name' => 'BEA',
        'sex' => 'FEMALE',
        'ww' => [9,9,10,10,9,8,9,10,9,10],
        'pt' => [90,92,94,95,96,93,94,95,92,91],
        'qa' => 94,
    ],
    [
        'name' => 'CARLO',
        'sex' => 'MALE',
        'ww' => [6,7,8,7,8,7,8,7,8,7],
        'pt' => [78,80,82,81,79,80,78,82,80,79],
        'qa' => 81,
    ],
    [
        'name' => 'DIANA',
        'sex' => 'FEMALE',
        'ww' => [10,10,10,9,10,10,9,10,10,10],
        'pt' => [96,97,98,97,98,99,97,98,99,98],
        'qa' => 98,
    ],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Class Record | STSN Grading System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --ink: #111827;
            --muted: #6b7280;
            --line: #1f2937;
            --soft-line: #9ca3af;
            --paper: #ffffff;
            --bg: #eef2f7;
            --head: #f8fafc;
            --accent: #0f3d68;
            --good: #166534;
            --warn: #b45309;
            --bad: #b91c1c;
            --panel: #f8fafc;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            font-family: Inter, sans-serif;
            background: var(--bg);
            color: var(--ink);
        }

        .page {
            max-width: 1800px;
            margin: 20px auto;
            padding: 0 16px 24px;
        }

        .sheet {
            background: var(--paper);
            border: 1px solid #d1d5db;
            box-shadow: 0 12px 40px rgba(15, 23, 42, 0.08);
            overflow: hidden;
        }

        .sheet-header {
            padding: 18px 20px 10px;
            border-bottom: 2px solid var(--line);
        }

        .header-top {
            display: grid;
            grid-template-columns: 120px 1fr 160px;
            align-items: center;
            gap: 16px;
            margin-bottom: 8px;
        }

        .seal, .brand {
            min-height: 84px;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px dashed #cbd5e1;
            color: var(--muted);
            font-size: 12px;
            text-align: center;
            padding: 8px;
        }

        .title-wrap {
            text-align: center;
        }

        .title-wrap h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 800;
            letter-spacing: 0.02em;
        }

        .title-wrap p {
            margin: 4px 0 0;
            font-size: 11px;
            color: var(--muted);
            font-style: italic;
        }

        .meta-grid {
            display: grid;
            grid-template-columns: repeat(12, minmax(0, 1fr));
            gap: 8px 12px;
            align-items: center;
        }

        .meta-item {
            display: flex;
            align-items: center;
            gap: 8px;
            min-width: 0;
        }

        .meta-item label {
            font-weight: 700;
            white-space: nowrap;
        }

        .meta-box {
            flex: 1;
            min-height: 26px;
            border: 1px solid var(--line);
            padding: 4px 8px;
            font-size: 14px;
            background: #fff;
        }

        .span-3 { grid-column: span 3; }
        .span-4 { grid-column: span 4; }
        .span-5 { grid-column: span 5; }
        .span-6 { grid-column: span 6; }

        .record-layout {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 210px;
        }

        .table-wrap {
            overflow: auto;
            border-right: 2px solid var(--line);
        }

        table {
            border-collapse: collapse;
            width: 100%;
            min-width: 1450px;
        }

        th, td {
            border: 1px solid var(--line);
            padding: 0;
            text-align: center;
            font-size: 12px;
            vertical-align: middle;
        }

        th {
            background: var(--head);
            font-weight: 800;
        }

        .group-title {
            font-size: 13px;
            padding: 6px 4px;
        }

        .left-title {
            width: 250px;
            min-width: 250px;
        }

        .left-col {
            text-align: left;
            padding: 6px 8px;
            font-weight: 600;
            background: #fff;
        }

        .small-head {
            font-size: 11px;
            font-weight: 700;
            padding: 4px 2px;
        }

        .hps-row td,
        .hps-row th,
        .group-row td {
            background: #f3f4f6;
            font-weight: 700;
        }

        .index-col {
            width: 34px;
            min-width: 34px;
            font-weight: 700;
        }

        .score-cell {
            width: 42px;
            min-width: 42px;
            height: 34px;
        }

        .score-cell input,
        .qa-cell input {
            width: 100%;
            height: 100%;
            border: none;
            text-align: center;
            font: inherit;
            background: #fff;
        }

        .score-cell input:focus,
        .qa-cell input:focus {
            outline: 2px solid #93c5fd;
            outline-offset: -2px;
            background: #eff6ff;
        }

        .readonly {
            background: #f8fafc;
            font-weight: 700;
            color: #0f172a;
        }

        .section-cell {
            background: #e5e7eb;
            font-weight: 800;
            text-transform: uppercase;
        }

        .aside {
            background: #fff;
            padding: 10px;
        }

        .side-card {
            border: 1px solid var(--line);
            margin-bottom: 18px;
        }

        .side-card h3 {
            margin: 0;
            font-size: 12px;
            font-weight: 800;
            text-align: center;
            padding: 8px 6px;
            border-bottom: 1px solid var(--line);
            background: var(--head);
        }

        .side-card table {
            min-width: 100%;
        }

        .side-card td,
        .side-card th {
            font-size: 12px;
            padding: 6px 8px;
            border: 1px solid var(--line);
        }

        .summary-value.good { color: var(--good); font-weight: 800; }
        .summary-value.warn { color: var(--warn); font-weight: 800; }
        .summary-value.bad { color: var(--bad); font-weight: 800; }

        .footer-actions {
            display: flex;
            gap: 12px;
            justify-content: flex-end;
            padding: 16px 20px 20px;
            border-top: 1px solid #dbe3ee;
            background: #fbfdff;
        }

        .btn {
            border: 1px solid #cbd5e1;
            background: white;
            border-radius: 10px;
            padding: 10px 14px;
            font-weight: 700;
            cursor: pointer;
        }

        .btn-primary {
            background: var(--accent);
            color: white;
            border-color: var(--accent);
        }

        @media print {
            body { background: white; }
            .page { max-width: 100%; margin: 0; padding: 0; }
            .sheet { box-shadow: none; border: none; }
            .footer-actions { display: none; }
        }

        @media (max-width: 1200px) {
            .record-layout { grid-template-columns: 1fr; }
            .table-wrap { border-right: none; border-bottom: 2px solid var(--line); }
        }

        @media (max-width: 900px) {
            .header-top { grid-template-columns: 1fr; }
            .meta-grid { grid-template-columns: 1fr; }
            .span-3, .span-4, .span-5, .span-6 { grid-column: span 1; }
        }
    </style>
</head>
<body>
    <div class="page">
        <div class="sheet">
            <div class="sheet-header">
                <div class="header-top">
                    <div class="seal">School Seal</div>
                    <div class="title-wrap">
                        <h1>Class Record</h1>
                        <p>(Pursuant to DepEd Order 8, s. 2015)</p>
                    </div>
                    <div class="brand">DepEd Logo</div>
                </div>

                <div class="meta-grid">
                    <div class="meta-item span-3"><label>REGION</label><div class="meta-box"></div></div>
                    <div class="meta-item span-3"><label>DIVISION</label><div class="meta-box"></div></div>
                    <div class="meta-item span-2"><label>DISTRICT</label><div class="meta-box"></div></div>
                    <div class="meta-item span-2"><label>SCHOOL ID</label><div class="meta-box"></div></div>
                    <div class="meta-item span-2"><label>SCHOOL YEAR</label><div class="meta-box"><?php echo htmlspecialchars($schoolYear); ?></div></div>

                    <div class="meta-item span-6"><label>SCHOOL NAME</label><div class="meta-box"><?php echo htmlspecialchars($schoolName); ?></div></div>
                    <div class="meta-item span-3"><label>GRADE &amp; SECTION</label><div class="meta-box"><?php echo htmlspecialchars($gradeSection); ?></div></div>
                    <div class="meta-item span-3"><label>TEACHER</label><div class="meta-box"><?php echo htmlspecialchars($teacher); ?></div></div>
                    <div class="meta-item span-3"><label>SUBJECT</label><div class="meta-box"><?php echo htmlspecialchars($subject); ?></div></div>
                </div>
            </div>

            <div class="record-layout">
                <div class="table-wrap">
                    <table id="classRecordTable">
                        <tr>
                            <th colspan="2" class="group-title">FIRST QUARTER</th>
                            <th colspan="13" class="group-title">WRITTEN WORKS (30%)</th>
                            <th colspan="13" class="group-title">PERFORMANCE TASKS (50%)</th>
                            <th colspan="4" class="group-title">QUARTERLY ASSESSMENT (20%)</th>
                            <th rowspan="3" class="group-title">Initial<br>Grade</th>
                            <th rowspan="3" class="group-title">Quarterly<br>Grade</th>
                        </tr>
                        <tr>
                            <th colspan="2" class="left-title group-title">LEARNERS' NAMES</th>
                            <?php for ($i = 1; $i <= 10; $i++): ?><th class="small-head"><?php echo $i; ?></th><?php endfor; ?>
                            <th class="small-head">Total</th>
                            <th class="small-head">PS</th>
                            <th class="small-head">WS</th>
                            <?php for ($i = 1; $i <= 10; $i++): ?><th class="small-head"><?php echo $i; ?></th><?php endfor; ?>
                            <th class="small-head">Total</th>
                            <th class="small-head">PS</th>
                            <th class="small-head">WS</th>
                            <th class="small-head">Score</th>
                            <th class="small-head">PS</th>
                            <th class="small-head">WS</th>
                            <th class="small-head">Remarks</th>
                        </tr>
                        <tr class="hps-row">
                            <th colspan="2">HIGHEST POSSIBLE SCORE</th>
                            <?php foreach ($writtenWorksHPS as $value): ?><td><?php echo $value; ?></td><?php endforeach; ?>
                            <td id="wwHpsTotal"><?php echo array_sum($writtenWorksHPS); ?></td>
                            <td>100.00</td>
                            <td>30%</td>
                            <?php foreach ($performanceTasksHPS as $value): ?><td><?php echo $value; ?></td><?php endforeach; ?>
                            <td id="ptHpsTotal"><?php echo array_sum($performanceTasksHPS); ?></td>
                            <td>100.00</td>
                            <td>50%</td>
                            <td><?php echo $quarterlyAssessmentHPS; ?></td>
                            <td>100.00</td>
                            <td>20%</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>

                        <?php
                        $grouped = [];
                        foreach ($students as $student) {
                            $grouped[$student['sex']][] = $student;
                        }
                        ?>

                        <?php foreach ($grouped as $sex => $groupStudents): ?>
                            <tr class="group-row">
                                <td colspan="34" class="section-cell"><?php echo htmlspecialchars($sex); ?></td>
                            </tr>
                            <?php foreach ($groupStudents as $index => $student): ?>
                                <tr class="student-row">
                                    <td class="index-col"><?php echo $index + 1; ?></td>
                                    <td class="left-col student-name"><?php echo htmlspecialchars($student['name']); ?></td>

                                    <?php foreach ($student['ww'] as $score): ?>
                                        <td class="score-cell"><input type="number" min="0" max="100" value="<?php echo $score; ?>" class="ww-input"></td>
                                    <?php endforeach; ?>
                                    <td class="readonly ww-total">0</td>
                                    <td class="readonly ww-ps">0</td>
                                    <td class="readonly ww-ws">0</td>

                                    <?php foreach ($student['pt'] as $score): ?>
                                        <td class="score-cell"><input type="number" min="0" max="100" value="<?php echo $score; ?>" class="pt-input"></td>
                                    <?php endforeach; ?>
                                    <td class="readonly pt-total">0</td>
                                    <td class="readonly pt-ps">0</td>
                                    <td class="readonly pt-ws">0</td>

                                    <td class="qa-cell score-cell"><input type="number" min="0" max="100" value="<?php echo $student['qa']; ?>" class="qa-input"></td>
                                    <td class="readonly qa-ps">0</td>
                                    <td class="readonly qa-ws">0</td>
                                    <td class="readonly remarks">-</td>
                                    <td class="readonly initial-grade">0</td>
                                    <td class="readonly quarterly-grade">0</td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    </table>
                </div>

                <aside class="aside">
                    <div class="side-card">
                        <h3>NUMBER OF EXAMINEES</h3>
                        <table>
                            <tr><td>Total</td><td id="examCount">0</td></tr>
                            <tr><td>Highest Possible Score</td><td><?php echo $quarterlyAssessmentHPS; ?></td></tr>
                        </table>
                    </div>

                    <div class="side-card">
                        <h3>CRITERION-REFERENCED</h3>
                        <table>
                            <tr><td>Got 75% &amp; above</td><td id="above75">0</td></tr>
                            <tr><td>Percentage</td><td id="above75Pct">0%</td></tr>
                            <tr><td>Got below 75%</td><td id="below75">0</td></tr>
                            <tr><td>Percentage</td><td id="below75Pct">0%</td></tr>
                        </table>
                    </div>

                    <div class="side-card">
                        <h3>NORM-REFERENCED</h3>
                        <table>
                            <tr><td>Mean</td><td id="meanGrade">0</td></tr>
                            <tr><td>Median</td><td id="medianGrade">0</td></tr>
                            <tr><td>SD</td><td id="sdGrade">0</td></tr>
                            <tr><td>MPS</td><td id="mpsGrade">0%</td></tr>
                        </table>
                    </div>

                    <div class="side-card">
                        <h3>OTHER INFO</h3>
                        <table>
                            <tr><td>Highest Score</td><td id="highestQaScore">0</td></tr>
                            <tr><td>Lowest Score</td><td id="lowestQaScore">0</td></tr>
                            <tr><td>Total Score</td><td id="totalQaScore">0</td></tr>
                        </table>
                    </div>
                </aside>
            </div>

            <div class="footer-actions">
                <button class="btn" onclick="window.print()">Print Sheet</button>
                <button class="btn btn-primary">Save Grades</button>
            </div>
        </div>
    </div>

    <script>
        const wwHpsTotal = <?php echo array_sum($writtenWorksHPS); ?>;
        const ptHpsTotal = <?php echo array_sum($performanceTasksHPS); ?>;
        const qaHpsTotal = <?php echo $quarterlyAssessmentHPS; ?>;

        const transmute = (grade) => {
            if (grade >= 100) return 100;
            if (grade < 60) return 60;
            return Math.round(((grade - 60) * 1.0) + 60);
        };

        const round2 = (num) => (Math.round(num * 100) / 100).toFixed(2);

        function calculateRow(row) {
            const wwInputs = [...row.querySelectorAll('.ww-input')].map(input => Number(input.value) || 0);
            const ptInputs = [...row.querySelectorAll('.pt-input')].map(input => Number(input.value) || 0);
            const qa = Number(row.querySelector('.qa-input').value) || 0;

            const wwTotal = wwInputs.reduce((sum, val) => sum + val, 0);
            const ptTotal = ptInputs.reduce((sum, val) => sum + val, 0);

            const wwPs = wwHpsTotal ? (wwTotal / wwHpsTotal) * 100 : 0;
            const ptPs = ptHpsTotal ? (ptTotal / ptHpsTotal) * 100 : 0;
            const qaPs = qaHpsTotal ? (qa / qaHpsTotal) * 100 : 0;

            const wwWs = wwPs * 0.30;
            const ptWs = ptPs * 0.50;
            const qaWs = qaPs * 0.20;

            const initial = wwWs + ptWs + qaWs;
            const quarterly = Math.round(transmute(initial));

            row.querySelector('.ww-total').textContent = wwTotal;
            row.querySelector('.ww-ps').textContent = round2(wwPs);
            row.querySelector('.ww-ws').textContent = round2(wwWs);
            row.querySelector('.pt-total').textContent = ptTotal;
            row.querySelector('.pt-ps').textContent = round2(ptPs);
            row.querySelector('.pt-ws').textContent = round2(ptWs);
            row.querySelector('.qa-ps').textContent = round2(qaPs);
            row.querySelector('.qa-ws').textContent = round2(qaWs);
            row.querySelector('.initial-grade').textContent = round2(initial);
            row.querySelector('.quarterly-grade').textContent = quarterly;
            row.querySelector('.remarks').textContent = quarterly >= 75 ? 'Passed' : 'Failed';

            return quarterly;
        }

        function median(values) {
            if (!values.length) return 0;
            const sorted = [...values].sort((a, b) => a - b);
            const mid = Math.floor(sorted.length / 2);
            return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
        }

        function standardDeviation(values) {
            if (!values.length) return 0;
            const mean = values.reduce((a, b) => a + b, 0) / values.length;
            const variance = values.reduce((sum, value) => sum + Math.pow(value - mean, 2), 0) / values.length;
            return Math.sqrt(variance);
        }

        function refreshSummary() {
            const rows = [...document.querySelectorAll('.student-row')];
            const grades = rows.map(calculateRow);
            const qaScores = rows.map(row => Number(row.querySelector('.qa-input').value) || 0);
            const count = grades.length;
            const passed = grades.filter(g => g >= 75).length;
            const failed = count - passed;
            const total = grades.reduce((sum, val) => sum + val, 0);
            const mean = count ? total / count : 0;
            const mps = count ? (qaScores.reduce((sum, val) => sum + val, 0) / (count * qaHpsTotal)) * 100 : 0;
            const totalQa = qaScores.reduce((sum, val) => sum + val, 0);

            document.getElementById('examCount').textContent = count;
            document.getElementById('above75').textContent = passed;
            document.getElementById('below75').textContent = failed;
            document.getElementById('above75Pct').textContent = count ? round2((passed / count) * 100) + '%' : '0%';
            document.getElementById('below75Pct').textContent = count ? round2((failed / count) * 100) + '%' : '0%';
            document.getElementById('meanGrade').textContent = round2(mean);
            document.getElementById('medianGrade').textContent = round2(median(grades));
            document.getElementById('sdGrade').textContent = round2(standardDeviation(grades));
            document.getElementById('mpsGrade').textContent = round2(mps) + '%';
            document.getElementById('highestQaScore').textContent = count ? Math.max(...qaScores) : 0;
            document.getElementById('lowestQaScore').textContent = count ? Math.min(...qaScores) : 0;
            document.getElementById('totalQaScore').textContent = totalQa;
        }

        document.querySelectorAll('input').forEach(input => {
            input.addEventListener('input', refreshSummary);
        });

        refreshSummary();
    </script>
</body>
</html>
