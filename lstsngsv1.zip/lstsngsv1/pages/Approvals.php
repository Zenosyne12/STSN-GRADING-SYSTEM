<?php
require_once __DIR__ . '/../api/login/teacher_auth.php';
require_once __DIR__ . '/../includes/workflow_engine.php';

// Server-side guard: Approver only (Adviser / Subject Coordinator / Principal).
requireApprover();

$teacherName = $_SESSION['teacher_name'] ?? 'Teacher';
$teacherId = (int) ($_SESSION['teacher_id'] ?? 0);

$yearStmt = $pdo->query("SELECT id, year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
$activeYear = $yearStmt->fetch(PDO::FETCH_ASSOC) ?: null;
$activeYearId = $activeYear ? (int) $activeYear['id'] : 0;

// tblteacher.position holds the workflow position
// (Adviser, Principal, Subject Coordinator, Teacher).
$posStmt = $pdo->prepare("SELECT position FROM tblteacher WHERE id = ?");
$posStmt->execute([$teacherId]);
$position = $posStmt->fetchColumn() ?: '';
if ($position === '' || $position === null) {
    $position = ((int) ($_SESSION['role_id'] ?? 0) === 1) ? 'Registrar' : 'Teacher';
}

$pending = [];
if (function_exists('getPendingForPosition') && $activeYearId) {
    $pending = getPendingForPosition($pdo, $position, $activeYearId);
}

// Returned items — for anyone whose teacher_id matches their own id (any position)
$returned = [];
if (function_exists('getReturnedForTeacher') && $activeYearId && $teacherId > 0) {
    $returned = getReturnedForTeacher($pdo, $teacherId, $activeYearId);
}

// === Drill-down data (all grade levels + all sections) ===
// All grade levels
$allGradeLevels = [];
try {
    $allGradeLevels = $pdo->query("
        SELECT id, grade_level_name
        FROM tblgradelevel
        ORDER BY id ASC
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $allGradeLevels = []; }

// All active sections grouped by grade level
$sectionsByGL = [];
try {
    $secStmt = $pdo->query("
        SELECT id, section_name, grade_level_id
        FROM tblsection
        WHERE is_active = 1
        ORDER BY grade_level_id ASC, section_name ASC
    ");
    foreach ($secStmt->fetchAll(PDO::FETCH_ASSOC) as $sec) {
        $gid = (int)$sec['grade_level_id'];
        if (!isset($sectionsByGL[$gid])) $sectionsByGL[$gid] = [];
        $sectionsByGL[$gid][] = [
            'id'           => (int)$sec['id'],
            'section_name' => (string)$sec['section_name'],
        ];
    }
} catch (Throwable $e) { $sectionsByGL = []; }

// Pending items grouped by section_id
$pendingBySection = [];
foreach ($pending as $p) {
    $sid = (int)$p['section_id'];
    if (!isset($pendingBySection[$sid])) $pendingBySection[$sid] = [];
    $pendingBySection[$sid][] = [
        'instance_id'        => (int)$p['instance_id'],
        'subject_id'         => (int)$p['subject_id'],
        'subject_name'       => (string)($p['subject_name'] ?? ''),
        'subject_code'       => (string)($p['subject_code'] ?? ''),
        'term_id'            => (int)($p['term_id'] ?? 0),
        'academic_year_id'   => (int)$p['academic_year_id'],
        'teacher_name'       => (string)($p['teacher_name'] ?? ''),
        'allow_mark_checked' => (int)($p['allow_mark_checked'] ?? 0),
    ];
}

// Term labels (tblquarters) + max step per template, keyed for the pending cards.
$termMap = [];
$maxSteps = [];
try {
    foreach ($pdo->query("SELECT id, term_label FROM tblconfig_terms")->fetchAll(PDO::FETCH_ASSOC) as $q) {
        $termMap[(int) $q['id']] = $q['term_label'];
    }
    foreach ($pdo->query("SELECT template_id, MAX(step_order) AS max_step FROM tblworkflow_step GROUP BY template_id")->fetchAll(PDO::FETCH_ASSOC) as $s) {
        $maxSteps[(int) $s['template_id']] = (int) $s['max_step'];
    }
} catch (Throwable $e) {
}

$logsStmt = $pdo->prepare("
  SELECT l.id, l.step_order, l.actor_position, l.action, l.acted_at, t.template_name
  FROM tblworkflow_action_log l
  LEFT JOIN tblworkflow_instance i  ON i.id = l.instance_id
  LEFT JOIN tblworkflow_template t ON t.id = i.template_id
  ORDER BY l.id DESC LIMIT 10
");
$logsStmt->execute();
$recentLogs = $logsStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approvals | STSN Grading System</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/system-alerts.css">
    <link rel="stylesheet" href="../css/teacher-alerts.css">
    <style>
        :root {
            --primary: #0A2F44;
            --primary-soft: rgba(10, 47, 68, 0.08);
            --accent: #C5A028;
            --bg: #F5F7FA;
            --surface: #FFFFFF;
            --surface-2: #F8F9FA;
            --text: #1E2A3E;
            --muted: #6C757D;
            --border: #E9ECEF;
            --danger: #DC3545;
            --success: #198754;
            --shadow: 0 10px 30px rgba(10, 47, 68, 0.08);
            --radius: 18px;
            --sidebar-width: 264px;
            --sidebar-collapsed-width: 72px;
        }

        /* Dark mode — adapt page tokens (surfaces / text) without a redesign */
        html.dark-mode,
        [data-bs-theme="dark"] {
            --bg: #0f0f0f;
            --surface: #1e1e1e;
            --surface-2: #262626;
            --text: #e4e6e8;
            --muted: #9aa3ad;
            --border: #34393f;
            --primary-soft: rgba(120, 170, 255, 0.12);
            --shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        }
        /* Hardcoded light surfaces that bypass the tokens */
        html.dark-mode #stsn-toggle,
        [data-bs-theme="dark"] #stsn-toggle { background: var(--surface); color: #cfe0ff; }
        html.dark-mode .btn-secondary,
        [data-bs-theme="dark"] .btn-secondary { background: var(--surface-2); color: #cfe0ff; border-color: var(--border); }
        html.dark-mode .toolbar select,
        html.dark-mode .toolbar input[type="text"],
        html.dark-mode .form-field select,
        [data-bs-theme="dark"] .toolbar select,
        [data-bs-theme="dark"] .toolbar input[type="text"],
        [data-bs-theme="dark"] .form-field select { background: var(--surface-2); color: var(--text); border-color: var(--border); }

        * {
            box-sizing: border-box;
        }

        body.stsn-layout {
            margin: 0;
            font-family: "Plus Jakarta Sans", sans-serif;
            background: var(--bg);
            color: var(--text);
        }

        #stsn-toggle {
            position: fixed;
            top: 1rem;
            left: 1rem;
            z-index: 1100;
            width: 44px;
            height: 44px;
            border: 1px solid var(--border);
            border-radius: 12px;
            background: #fff;
            color: var(--primary);
            display: none;
            align-items: center;
            justify-content: center;
            box-shadow: var(--shadow);
            cursor: pointer;
        }

        #stsn-overlay {
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.35);
            opacity: 0;
            visibility: hidden;
            transition: 0.25s ease;
            z-index: 1035;
        }

        #stsn-overlay.visible {
            opacity: 1;
            visibility: visible;
        }

        .page-shell {
            margin-left: var(--sidebar-width);
            min-height: 100vh;
            transition: margin-left 0.28s ease;
            display: flex;
            flex-direction: column;
        }

        body.sidebar-collapsed .page-shell {
            margin-left: var(--sidebar-collapsed-width);
        }


        .top-bar {
            background: var(--surface);
            border-bottom: 1px solid var(--border);
            padding: .85rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            flex-wrap: wrap;
            position: sticky;
            top: 0;
            z-index: 40;
        }

        .top-bar-left h1 {
            margin: 0;
            font-size: 1.25rem;
            font-weight: 800;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: .5rem;
        }

        .top-bar-left p {
            margin: .2rem 0 0;
            color: var(--muted);
            font-size: .82rem;
        }

        .top-bar-right {
            display: flex;
            align-items: center;
            gap: .55rem;
            flex-wrap: wrap;
        }

        .meta-chip {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 999px;
            padding: .45rem .8rem;
            font-size: .78rem;
            color: var(--muted);
            display: inline-flex;
            align-items: center;
            gap: 5px;
            white-space: nowrap;
        }


        .page-main {
            padding: 1rem 1.5rem 1.5rem;
            display: grid;
            gap: 1rem;
        }

        .content-grid {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 320px;
            gap: 1rem;
        }


        .panel {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            overflow: hidden;
        }

        .panel-header {
            padding: 1rem 1.25rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .panel-title {
            margin: 0;
            color: var(--primary);
            font-size: 1rem;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: .5rem;
        }

        .panel-title i {
            color: var(--accent);
        }

        .panel-sub {
            margin-top: .2rem;
            color: var(--muted);
            font-size: .8rem;
        }


        .panel-header .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            background: #fff;
            color: var(--primary);
            border: 1.5px solid var(--border);
            border-radius: 999px;
            padding: 0.5rem 1rem;
            font-family: inherit;
            font-weight: 700;
            font-size: 0.8rem;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.15s ease;
            white-space: nowrap;
        }

        .panel-header .btn:hover {
            background: var(--surface-2);
            border-color: #c5d1dc;
        }

        .panel-header .btn-primary {
            background: var(--primary);
            border-color: var(--primary);
            color: #fff;
            box-shadow: 0 2px 8px rgba(10, 47, 68, 0.15);
        }

        .panel-header .btn-primary:hover {
            background: #0d3b56;
            border-color: #0d3b56;
            box-shadow: 0 4px 12px rgba(10, 47, 68, 0.2);
            transform: translateY(-1px);
        }

        .panel-header .btn:disabled {
            opacity: .45;
            cursor: not-allowed;
            box-shadow: none;
            transform: none;
        }

        .panel-header select.btn {
            appearance: none;
            -webkit-appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='%236C757D' viewBox='0 0 16 16'%3E%3Cpath d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right .6rem center;
            padding-right: 1.6rem;
        }

        .panel-header input[type="text"] {
            border: 1px solid var(--border);
            background: #fff;
            border-radius: 12px;
            padding: .52rem .75rem;
            font-family: inherit;
            font-size: .84rem;
            color: var(--text);
            width: 200px;
        }

        .table-wrap {
            overflow-x: auto;
            padding: 0 1rem 1rem;
        }

        .student-table {
            width: 100%;
            min-width: 860px;
            border-collapse: collapse;
            table-layout: fixed;
        }

        .student-table th {
            text-align: left;
            font-size: 0.77rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--muted);
            padding: 0.85rem 0.75rem;
            border-bottom: 1px solid var(--border);
            white-space: nowrap;
        }

        .student-table td {
            padding: 0.85rem 0.75rem;
            border-bottom: 1px solid var(--border);
            font-size: 0.9rem;
            vertical-align: middle;
        }

        .student-table tr:last-child td {
            border-bottom: none;
        }

        .student-table tr:hover td {
            background: var(--surface-2);
        }

        .td-center {
            text-align: center;
        }

        .student-table th,
        .student-table td {
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .col-lrn {
            width: 160px;
        }

        .col-student {
            width: auto;
        }

        .col-gender {
            width: 120px;
        }

        .col-parent {
            width: 190px;
        }

        .student-main {
            font-weight: 600;
            color: var(--text);
        }

        .student-sub {
            font-size: 0.78rem;
            color: var(--muted);
        }

        .row-actions {
            display: flex;
            gap: 0.4rem;
        }

        .mini-btn {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 0.35rem 0.7rem;
            border-radius: 8px;
            font-size: 0.78rem;
            font-weight: 600;
            cursor: pointer;
            border: 1px solid var(--border);
            background: #fff;
            color: var(--text);
            text-decoration: none;
            transition: 0.15s ease;
            font-family: inherit;
        }

        .mini-btn:hover {
            background: var(--surface-2);
        }

        .mini-btn.primary {
            background: var(--primary);
            color: #fff;
            border-color: var(--primary);
        }

        .side-stack {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .side-panel {
            padding: 1rem;
        }

        .load-list {
            display: flex;
            flex-direction: column;
            gap: 0.65rem;
        }

        .load-item {
            padding: 0.6rem 0;
            border-bottom: 1px dashed var(--border);
        }

        .load-item:last-child {
            border-bottom: none;
        }

        .load-item-title {
            font-size: 0.9rem;
            font-weight: 700;
            color: var(--text);
            margin-bottom: 0.2rem;
        }

        .load-item-sub {
            font-size: 0.8rem;
            color: var(--muted);
        }

        .compact-list {
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
            margin-top: 0.75rem;
        }

        .compact-item {
            display: flex;
            align-items: flex-start;
            gap: 0.65rem;
            cursor: pointer;
        }

        .compact-icon {
            width: 32px;
            height: 32px;
            background: var(--primary-soft);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary);
            font-size: 0.95rem;
            flex-shrink: 0;
        }

        .compact-title {
            font-size: 0.85rem;
            font-weight: 700;
            color: var(--text);
        }

        .compact-sub {
            font-size: 0.78rem;
            color: var(--muted);
        }

        .empty-state,
        .loading-state {
            padding: 1rem 0;
            color: var(--muted);
            font-size: 0.92rem;
        }


        .notif-wrap {
            position: relative;
        }

        .notif-btn {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            border: 1px solid var(--border);
            background: #fff;
            color: var(--primary);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: var(--shadow);
        }

        .notif-btn i {
            font-size: 1.15rem;
        }

        .notif-count {
            position: absolute;
            top: -2px;
            right: -2px;
            min-width: 18px;
            height: 18px;
            border-radius: 999px;
            border: 2px solid #fff;
            background: #ef4444;
            color: #fff;
            font-size: .68rem;
            font-weight: 700;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 0 4px;
            line-height: 1;
        }

        .notif-panel {
            position: absolute;
            top: calc(100% + 12px);
            right: 0;
            width: min(420px, calc(100vw - 2rem));
            max-height: 460px;
            overflow: auto;
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 16px;
            box-shadow: 0 18px 42px rgba(10, 47, 68, .18);
            padding: .85rem;
            z-index: 1200;
            opacity: 0;
            visibility: hidden;
            pointer-events: none;
            transform: translateY(8px) scale(.98);
            transform-origin: top right;
            transition: opacity .2s ease, transform .2s cubic-bezier(.22, 1, .36, 1), visibility .2s;
        }

        .notif-panel.open {
            opacity: 1;
            visibility: visible;
            pointer-events: auto;
            transform: translateY(0) scale(1);
        }

        .notif-panel-title {
            font-size: .95rem;
            font-weight: 800;
            color: var(--primary);
            padding: .35rem .35rem .65rem;
        }

        .notif-item {
            border: 1px solid #eef1f4;
            border-radius: 12px;
            padding: .72rem .8rem;
            background: #fafcff;
            margin-bottom: .6rem;
        }

        .notif-item:last-child {
            margin-bottom: 0;
        }

        .notif-item-title {
            font-size: .9rem;
            font-weight: 800;
            color: var(--text);
            line-height: 1.35;
        }

        .notif-item-sub {
            font-size: .84rem;
            color: var(--muted);
            margin-top: .25rem;
            line-height: 1.5;
        }


        .gs-modal-backdrop {
            display: flex;
            position: fixed;
            inset: 0;
            z-index: 2000;
            background: rgba(10, 20, 35, 0.55);
            backdrop-filter: blur(3px);
            align-items: center;
            justify-content: center;
            opacity: 0;
            visibility: hidden;
            pointer-events: none;
            transition: opacity .24s ease-in-out, visibility .24s;
        }

        .gs-modal-backdrop.open {
            opacity: 1;
            visibility: visible;
            pointer-events: auto;
        }

        .gs-modal {
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 24px 80px rgba(10, 47, 68, 0.22);
            width: 96vw;
            max-width: 1400px;
            max-height: 92vh;
            display: flex;
            flex-direction: column;
            transform: translateY(18px) scale(.985);
            opacity: 0;
            transition: transform .26s cubic-bezier(.22, 1, .36, 1), opacity .22s ease-out;
        }

        .gs-modal-backdrop.open .gs-modal {
            transform: translateY(0) scale(1);
            opacity: 1;
        }

        .gs-modal-header {
            padding: 1.1rem 1.5rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .gs-modal-title {
            font-size: 1.05rem;
            font-weight: 800;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .gs-modal-title i {
            color: var(--accent);
        }

        .gs-close-btn {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            border: 1px solid var(--border);
            background: #fff;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            color: var(--muted);
            transition: 0.15s;
        }

        .gs-close-btn:hover {
            background: #fee2e2;
            color: var(--danger);
            border-color: #fecaca;
        }

        .gs-modal-toolbar {
            padding: 0.75rem 1.5rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            gap: 0.75rem;
            flex-wrap: wrap;
            background: var(--surface-2);
        }

        .gs-modal-toolbar label {
            font-size: 0.82rem;
            font-weight: 700;
            color: var(--muted);
            white-space: nowrap;
        }

        .gs-modal-toolbar select {
            border: 1px solid var(--border);
            background: #fff;
            border-radius: 10px;
            padding: 0.5rem 0.75rem;
            font-family: inherit;
            font-size: 0.85rem;
            color: var(--text);
        }

        .gs-modal-toolbar .meta-chip {
            min-height: 39px;
            border-radius: 10px;
            color: var(--text);
            font-weight: 800;
        }

        .gs-modal-body {
            flex: 1;
            overflow: auto;
            padding: 1rem 1.5rem;
        }

        .submit-banner {
            border-radius: 12px;
            padding: 0.85rem 1.1rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 0.87rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }

        .submit-banner.not-submitted {
            background: #fff8e1;
            border: 1.5px solid #fde68a;
            color: #92400e;
        }

        .submit-banner.submitted {
            background: #d1fae5;
            border: 1.5px solid #6ee7b7;
            color: #065f46;
        }

        .submit-banner i {
            font-size: 1.1rem;
            flex-shrink: 0;
        }

        .attendance-modal {
            max-width: 860px;
        }

        .attendance-drop {
            border: 1.5px dashed #cbd5e1;
            border-radius: 14px;
            padding: 1rem;
            background: #f8fafc;
            display: flex;
            align-items: center;
            gap: .85rem;
            flex-wrap: wrap;
        }

        .attendance-drop input {
            flex: 1;
            min-width: 240px;
            font-family: inherit;
            font-size: .88rem;
        }

        .attendance-file-card {
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: .85rem 1rem;
            background: #fff;
            margin-top: 1rem;
            display: none;
        }

        .attendance-file-title {
            font-weight: 800;
            color: var(--primary);
            font-size: .94rem;
            display: flex;
            align-items: center;
            gap: .45rem;
        }

        .attendance-meta-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: .6rem;
            margin-top: .8rem;
        }

        .attendance-meta-item {
            background: #f8fafc;
            border: 1px solid #eef2f7;
            border-radius: 10px;
            padding: .65rem;
        }

        .attendance-meta-label {
            font-size: .72rem;
            color: var(--muted);
            text-transform: uppercase;
            font-weight: 800;
            letter-spacing: .04em;
        }

        .attendance-meta-value {
            font-size: .94rem;
            color: var(--text);
            font-weight: 800;
            margin-top: .12rem;
        }

        .attendance-preview {
            margin-top: 1rem;
            max-height: 280px;
            overflow: auto;
            border: 1px solid var(--border);
            border-radius: 12px;
            display: none;
        }

        .attendance-preview table {
            width: 100%;
            border-collapse: collapse;
            font-size: .82rem;
        }

        .attendance-preview th,
        .attendance-preview td {
            padding: .55rem .65rem;
            border-bottom: 1px solid var(--border);
            text-align: left;
        }

        .attendance-preview th {
            position: sticky;
            top: 0;
            background: #f8fafc;
            color: var(--primary);
            font-size: .75rem;
            text-transform: uppercase;
        }

        .attendance-warning {
            display: none;
            margin-top: .85rem;
            border: 1px solid #fde68a;
            background: #fff8e1;
            color: #92400e;
            border-radius: 12px;
            padding: .75rem .9rem;
            font-size: .84rem;
            font-weight: 600;
        }


        .q-pill {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 3px 10px;
            border-radius: 999px;
            font-size: 0.75rem;
            font-weight: 700;
        }

        .q-pill.submitted {
            background: #d1fae5;
            color: #065f46;
            border: 1px solid #6ee7b7;
        }

        .q-pill.not-submitted {
            background: #fef3c7;
            color: #92400e;
            border: 1px solid #fde68a;
        }

        .cr-wrap {
            overflow-x: auto;
        }

        .cr-table {
            border-collapse: collapse;
            font-size: 8.5pt;
            font-family: Arial, sans-serif;
            min-width: 100%;
            background: #fff;
            table-layout: fixed;
        }

        .cr-table th,
        .cr-table td {
            border: 1px solid #aab8cc;
        }

        .cr-num {
            width: 36px;
            min-width: 36px;
            max-width: 36px;
            text-align: left;
            font-size: 8pt;
            color: #555;
            padding: 3px 6px;
            border: 1px solid #aab8cc;
        }

        .cr-name-th {
            min-width: 200px;
            padding: 5px 10px;
            font-size: 9.5pt;
            font-weight: 700;
            color: #132f62;
            background: #f0f4ff;
            vertical-align: bottom;
        }

        .cr-name {
            min-width: 200px;
            width: 200px;
            padding: 4px 10px;
            font-size: 9pt;
            text-align: left;
            border: 1px solid #aab8cc;
        }

        .cr-grade {
            width: 72px;
            min-width: 72px;
            max-width: 72px;
            text-align: center;
            padding: 4px 6px;
            font-size: 9pt;
            border: 1px solid #aab8cc;
        }

        .cr-avg {
            width: 72px;
            min-width: 72px;
            max-width: 72px;
            text-align: center;
            font-weight: 700;
            padding: 4px 6px;
            font-size: 9pt;
            border: 1px solid #aab8cc;
        }

        .cr-subject-th {
            width: 72px;
            min-width: 72px;
            max-width: 72px;
            padding: 8px 6px;
            background: linear-gradient(180deg, #f0f4ff 0%, #e8eef8 100%);
            color: #132f62;
            font-size: 7.5pt;
            font-weight: 700;
            text-align: center;
            vertical-align: bottom;
            line-height: 1.25;
            border: 1px solid #aab8cc;
            word-break: break-word;
            hyphens: auto;
            white-space: normal;
        }

        .cr-subject-th .cr-subject-inner {
            display: block;
            white-space: normal;
            font-size: 7.5pt;
            font-weight: 700;
            color: #132f62;
            line-height: 1.25;
        }

        .cr-header-num {
            text-align: center;
            font-size: 8pt;
            font-weight: 700;
            padding: 3px 6px;
            background: #e8eef8;
            color: #3b5e96;
            border: 1px solid #aab8cc;
        }

        .cr-num-th {
            width: 36px;
            min-width: 36px;
            max-width: 36px;
            text-align: left;
            font-size: 8pt;
            font-weight: 700;
            background: linear-gradient(180deg, #f0f4ff 0%, #e8eef8 100%);
            color: #3b5e96;
            vertical-align: bottom;
            padding: 5px 6px;
            border: 1px solid #aab8cc;
        }

        .cr-name-th {
            min-width: 200px;
            padding: 5px 10px;
            font-size: 9.5pt;
            font-weight: 700;
            color: #132f62;
            background: linear-gradient(180deg, #f0f4ff 0%, #e8eef8 100%);
            vertical-align: bottom;
            border: 1px solid #aab8cc;
        }

        .cr-avg-th {
            width: 72px;
            min-width: 72px;
            max-width: 72px;
            text-align: center;
            font-size: 9pt;
            font-weight: 700;
            background: linear-gradient(180deg, #f0f4ff 0%, #e8eef8 100%);
            color: #132f62;
            vertical-align: bottom;
            padding: 5px 6px;
            border: 1px solid #aab8cc;
        }

        .cr-header-num {
            text-align: center;
            font-size: 8pt;
            font-weight: 700;
            padding: 3px 2px;
            background: #e8eef8;
            color: #3b5e96;
        }

        .cr-num-th {
            width: 32px;
            text-align: center;
            font-size: 8pt;
            font-weight: 700;
            background: #f0f4ff;
            color: #3b5e96;
            vertical-align: bottom;
            padding: 5px 2px;
        }

        .cr-name-th {
            min-width: 200px;
            padding: 5px 10px;
            font-size: 9.5pt;
            font-weight: 700;
            color: #132f62;
            background: #f0f4ff;
            vertical-align: bottom;
        }

        .cr-avg-th {
            width: 72px;
            text-align: center;
            font-size: 9pt;
            font-weight: 700;
            background: #f0f4ff;
            color: #132f62;
            vertical-align: bottom;
            padding: 5px 3px;
        }

        .cr-avg-th {
            width: 72px;
            text-align: center;
            font-size: 9pt;
            font-weight: 700;
            background: #f0f4ff;
            color: #132f62;
            vertical-align: bottom;
            padding: 5px 3px;
        }

        .cr-header-num {
            text-align: center;
            font-size: 8pt;
            font-weight: 700;
            padding: 3px 2px;
            background: #e8eef8;
            color: #3b5e96;
        }

        .cr-row-group {
            background: #d0d8e8;
            font-weight: 700;
            font-size: 8.5pt;
        }

        .cr-row-group td {
            padding: 3px 8px;
            color: #132f62;
            letter-spacing: .04em;
            text-align: left;
        }

        .cr-pass {
            color: #059669;
            font-weight: 700;
        }

        .cr-fail {
            color: #dc2626;
            font-weight: 700;
        }

        .cr-avg-cell {
            background: #f4f8ff;
            font-weight: 700;
        }

        .cr-table td.cr-grade,
        .cr-table td.cr-avg,
        .cr-table th.cr-grade,
        .cr-table th.cr-avg-th,
        .cr-table th.cr-header-num,
        .cr-table th.cr-subject-th {
            text-align: center;
        }

        .cr-empty-row td {
            background: #fff;
        }

        .cr-empty-row:nth-child(even) td {
            background: #fafcff;
        }

        .cr-num-th {
            width: 32px;
            text-align: center;
            font-size: 8pt;
            font-weight: 700;
            background: #f0f4ff;
            color: #3b5e96;
            vertical-align: bottom;
            padding: 5px 2px;
        }

        .gs-loading {
            text-align: center;
            padding: 3rem;
            color: var(--muted);
        }

        .gs-loading .spinner {
            display: inline-block;
            width: 32px;
            height: 32px;
            border: 3px solid var(--border);
            border-top-color: var(--primary);
            border-radius: 50%;
            animation: spin 0.75s linear infinite;
            margin-bottom: 0.75rem;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg)
            }
        }


        .gs-toast {
            position: fixed;
            bottom: 1.5rem;
            right: 1.5rem;
            z-index: 9999;
            padding: 0.85rem 1.2rem;
            border-radius: 14px;
            font-size: 0.88rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.6rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
            transform: translateY(80px);
            opacity: 0;
            transition: 0.3s ease;
            pointer-events: none;
            max-width: 380px;
        }

        .gs-toast.show {
            transform: translateY(0);
            opacity: 1;
        }

        .gs-toast.success {
            background: #065f46;
            color: #fff;
        }

        .gs-toast.error {
            background: #991b1b;
            color: #fff;
        }

        .gs-toast.warning {
            background: #92400e;
            color: #fff;
        }

        @media(max-width:1199px) {
            .content-grid {
                grid-template-columns: 1fr;
            }
        }

        @media(max-width:991.98px) {
            #stsn-toggle {
                display: inline-flex;
            }

            .page-shell,
            body.sidebar-collapsed .page-shell {
                margin-left: 0;
            }

            .page-main {
                padding: 5rem 1rem 1.5rem;
            }

            .top-bar {
                padding: 4.5rem 1rem 1rem;
            }

            .panel-header {
                flex-wrap: wrap;
            }
        }

        @media(max-width:767px) {
            .top-bar-left h1 {
                font-size: 1.05rem;
            }

            .panel-header input[type="text"] {
                width: 100%;
            }
        }



        .attendance-modern-drop {
            border: 2px dashed #c8daf8;
            border-radius: 16px;
            background: linear-gradient(135deg, #f8fbff 0%, #eef4ff 100%);
            padding: 2.5rem 2rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.25s cubic-bezier(0.22, 1, 0.36, 1);
            position: relative;
            overflow: hidden;
        }

        .attendance-modern-drop::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(26, 110, 245, 0.03) 0%, rgba(18, 72, 168, 0.03) 100%);
            opacity: 0;
            transition: opacity 0.25s ease;
        }

        .attendance-modern-drop:hover {
            border-color: #1a6ef5;
            background: linear-gradient(135deg, #f0f7ff 0%, #e6f0ff 100%);
            transform: translateY(-2px);
            box-shadow: 0 8px 32px rgba(26, 110, 245, 0.12);
        }

        .attendance-modern-drop:hover::before {
            opacity: 1;
        }

        .attendance-modern-drop.drag-over {
            border-color: #1a6ef5;
            background: #eef4ff;
            box-shadow: 0 0 0 4px rgba(26, 110, 245, 0.15);
        }

        .attendance-drop-content {
            position: relative;
            z-index: 1;
        }

        .attendance-drop-icon {
            width: 64px;
            height: 64px;
            background: linear-gradient(135deg, #1a6ef5 0%, #1248a8 100%);
            border-radius: 16px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            margin-bottom: 1rem;
            box-shadow: 0 4px 16px rgba(26, 110, 245, 0.3);
            transition: transform 0.25s cubic-bezier(0.22, 1, 0.36, 1);
        }

        .attendance-modern-drop:hover .attendance-drop-icon {
            transform: scale(1.08) rotate(-4deg);
        }

        .attendance-drop-icon svg {
            width: 28px;
            height: 28px;
        }

        .attendance-drop-title {
            font-size: 1.05rem;
            font-weight: 700;
            color: #132f62;
            margin-bottom: 0.35rem;
        }

        .attendance-drop-sub {
            font-size: 0.88rem;
            color: #7a93b8;
            margin-bottom: 0.5rem;
        }

        .attendance-browse {
            color: #1a6ef5;
            font-weight: 700;
            text-decoration: underline;
            text-underline-offset: 2px;
            cursor: pointer;
        }

        .attendance-drop-hint {
            font-size: 0.78rem;
            color: #a0aec0;
            background: rgba(255, 255, 255, 0.7);
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 999px;
            border: 1px solid #e2ebf8;
        }


        .attendance-actions-row {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-top: 1.25rem;
            flex-wrap: wrap;
        }

        .attendance-file-badge {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            background: #fff;
            border: 1.5px solid #e2ebf8;
            border-radius: 12px;
            padding: 0.65rem 1rem;
            flex: 1;
            min-width: 200px;
            transition: all 0.2s ease;
        }

        .attendance-file-badge:hover {
            border-color: #c8daf8;
            box-shadow: 0 2px 8px rgba(18, 72, 168, 0.06);
        }

        .attendance-file-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #065f46;
            font-size: 1.15rem;
            flex-shrink: 0;
        }

        .attendance-file-info {
            flex: 1;
            min-width: 0;
        }

        .attendance-file-name {
            font-size: 0.9rem;
            font-weight: 700;
            color: #132f62;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .attendance-file-meta {
            font-size: 0.78rem;
            color: #9ab0c8;
            margin-top: 0.1rem;
        }

        .attendance-file-remove {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            border: 1.5px solid #fee2e2;
            background: #fef2f2;
            color: #dc2626;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 0.85rem;
            transition: all 0.15s ease;
            flex-shrink: 0;
        }

        .attendance-file-remove:hover {
            background: #fee2e2;
            border-color: #fecaca;
            transform: scale(1.05);
        }

        .attendance-import-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: var(--primary);
            color: #fff;
            border: none;
            border-radius: 999px;
            padding: 0.55rem 1.1rem;
            font-family: inherit;
            font-size: 0.82rem;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(10, 47, 68, 0.15);
            transition: all 0.2s ease;
            white-space: nowrap;
        }

        .attendance-import-btn:hover:not(:disabled) {
            background: #0d3b56;
            box-shadow: 0 4px 12px rgba(10, 47, 68, 0.2);
            transform: translateY(-1px);
        }

        .attendance-import-btn:active:not(:disabled) {
            transform: translateY(0);
        }

        .attendance-import-btn:disabled {
            opacity: 0.45;
            cursor: not-allowed;
            box-shadow: none;
        }

        .attendance-import-icon {
            font-size: 0.95rem;
            display: inline-flex;
        }

        .attendance-preview {
            margin-top: 1.25rem;
            max-height: 320px;
            overflow: auto;
            border: 1.5px solid #e2ebf8;
            border-radius: 14px;
            display: none;
            background: #fff;
        }

        .attendance-preview table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.82rem;
        }

        .attendance-preview th,
        .attendance-preview td {
            padding: 0.55rem 0.65rem;
            border-bottom: 1px solid #eef2f7;
            text-align: left;
        }

        .attendance-preview th {
            position: sticky;
            top: 0;
            background: #f8fafc;
            color: #132f62;
            font-size: 0.75rem;
            text-transform: uppercase;
            font-weight: 700;
            letter-spacing: 0.04em;
            z-index: 2;
        }

        .attendance-preview tr:hover td {
            background: #f7fbff;
        }


        .attendance-warning {
            display: none;
            margin-top: 1rem;
            border: 1.5px solid #fde68a;
            background: linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%);
            color: #92400e;
            border-radius: 12px;
            padding: 0.85rem 1rem;
            font-size: 0.85rem;
            font-weight: 600;
            display: flex;
            align-items: flex-start;
            gap: 0.5rem;
        }

        .attendance-warning::before {
            content: '⚠';
            font-size: 1.1rem;
            flex-shrink: 0;
        }


        .attendance-meta-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
            gap: 0.65rem;
            margin-top: 1rem;
        }

        .attendance-meta-item {
            background: linear-gradient(135deg, #f8fbff 0%, #f4f8ff 100%);
            border: 1.5px solid #e2ebf8;
            border-radius: 12px;
            padding: 0.75rem;
            transition: all 0.2s ease;
        }

        .attendance-meta-item:hover {
            border-color: #c8daf8;
            transform: translateY(-1px);
            box-shadow: 0 2px 8px rgba(18, 72, 168, 0.06);
        }

        .attendance-meta-label {
            font-size: 0.72rem;
            color: #7a93b8;
            text-transform: uppercase;
            font-weight: 800;
            letter-spacing: 0.04em;
            margin-bottom: 0.25rem;
        }

        .attendance-meta-value {
            font-size: 1rem;
            color: #132f62;
            font-weight: 800;
        }



        .btn-pill {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.4rem;
            min-height: 38px;
            background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);
            color: var(--primary);
            border: 1px solid #d8e1ec;
            border-radius: 999px;
            padding: 0.52rem 1rem;
            font-family: inherit;
            font-weight: 800;
            font-size: 0.8rem;
            cursor: pointer;
            text-decoration: none;
            transition: background 0.16s ease, border-color 0.16s ease, color 0.16s ease, box-shadow 0.16s ease, transform 0.12s ease;
            white-space: nowrap;
            box-shadow: 0 1px 2px rgba(15, 23, 42, 0.06), inset 0 1px 0 rgba(255, 255, 255, 0.9);
        }

        .btn-pill:hover {
            background: #fff;
            border-color: #b9c8d8;
            box-shadow: 0 6px 16px rgba(15, 23, 42, 0.10);
            transform: translateY(-1px);
        }

        .btn-pill:active {
            transform: translateY(0);
            box-shadow: 0 1px 4px rgba(15, 23, 42, 0.08);
        }

        .btn-pill-primary {
            background: linear-gradient(135deg, #0A2F44 0%, #0f5f7d 100%);
            border-color: var(--primary);
            color: #fff;
            box-shadow: 0 8px 18px rgba(10, 47, 68, 0.20);
        }

        .btn-pill-primary:hover {
            background: linear-gradient(135deg, #0d3b56 0%, #127394 100%);
            border-color: #0d3b56;
            box-shadow: 0 10px 22px rgba(10, 47, 68, 0.26);
            transform: translateY(-1px);
        }

        .btn-pill-primary:disabled {
            background: #eef2f6;
            border-color: #d8e1ec;
            color: #8a98a8;
            opacity: 1;
            cursor: not-allowed;
            box-shadow: none;
            transform: none;
        }

        .btn-pill-muted {
            background: #f3f6f9;
            color: #7a8797;
            border-color: #dbe3ec;
            box-shadow: none;
        }

        .btn-pill-muted:hover {
            background: #f3f6f9;
            border-color: #dbe3ec;
            box-shadow: none;
            transform: none;
        }

        /* ==== Approvals-specific ==== */
        .approval-card {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 1rem 1.15rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            margin-bottom: .75rem;
            transition: .15s
        }

        .approval-card:hover {
            border-color: #C5A028;
            box-shadow: 0 4px 16px rgba(197, 160, 40, .10)
        }

        .approval-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            background: var(--primary-soft);
            color: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.15rem;
            flex-shrink: 0
        }

        .approval-info {
            flex: 1;
            min-width: 0
        }

        .approval-title {
            font-size: .95rem;
            font-weight: 800;
            color: var(--text)
        }

        .approval-sub {
            font-size: .82rem;
            color: var(--muted);
            margin-top: 3px
        }

        .approval-step {
            margin-top: 6px;
            display: flex;
            gap: .5rem;
            align-items: center
        }

        .step-badge {
            background: #FFF8E1;
            color: #855E00;
            font-size: .72rem;
            font-weight: 700;
            padding: 2px 8px;
            border-radius: 999px
        }

        .step-label {
            font-size: .78rem;
            color: var(--muted);
            font-weight: 600
        }

        .approval-actions {
            display: flex;
            gap: .4rem;
            flex-shrink: 0
        }

        .btn-danger-outline {
            background: #fff;
            color: #A32D2D;
            border: 1.5px solid #F5BCBC;
            padding: .5rem 1rem;
            border-radius: 999px;
            font-weight: 700;
            font-size: .8rem;
            cursor: pointer
        }

        .btn-danger-outline:hover {
            background: #FCEBEB
        }

        .btn-success {
            background: #0F6E56;
            color: #fff;
            border: 1.5px solid #0F6E56;
            padding: .5rem 1rem;
            border-radius: 999px;
            font-weight: 700;
            font-size: .8rem;
            cursor: pointer
        }

        .btn-success:hover {
            background: #0d5c48
        }

        .no-pending {
            padding: 2.5rem 1rem;
            text-align: center;
            color: var(--muted);
            font-size: .9rem
        }

        .no-pending i {
            font-size: 2.5rem;
            display: block;
            margin-bottom: .75rem;
            color: #C8CFD8
        }

        /* ============================================================
           Chain UI — Approval Timeline
           ============================================================ */
        .chain-section {
            background: #f8fbff;
            border: 1px solid #dce8f8;
            border-radius: 12px;
            padding: 1rem 1.2rem;
            margin-bottom: 1rem;
        }
        .chain-title {
            font-size: 0.9rem;
            font-weight: 800;
            color: #1248a8;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .chain-step {
            display: flex;
            gap: 0.85rem;
            position: relative;
            padding-bottom: 1.25rem;
        }
        .chain-step:last-child {
            padding-bottom: 0;
        }
        .chain-step::before {
            content: '';
            position: absolute;
            left: 14px;
            top: 32px;
            bottom: 0;
            width: 2px;
            background: #dce8f8;
        }
        .chain-step:last-child::before {
            display: none;
        }
        .chain-step.done::before {
            background: #a7f3d0;
        }
        .chain-step.current::before {
            background: linear-gradient(to bottom, #a7f3d0 20%, #dce8f8 20%);
        }

        .chain-icon {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1rem;
            flex-shrink: 0;
            position: relative;
            z-index: 2;
            background: #fff;
        }
        .chain-icon.chain-done {
            background: #d1fae5;
            color: #059669;
        }
        .chain-icon.chain-current {
            background: #dbeafe;
            color: #1248a8;
            animation: pulse-current 1.5s ease-in-out infinite;
        }
        .chain-icon.chain-pending {
            background: #f3f5f8;
            color: #c8d0d8;
        }
        @keyframes pulse-current {
            0%, 100% { box-shadow: 0 0 0 0 rgba(18,72,168,0.4); }
            50% { box-shadow: 0 0 0 6px rgba(18,72,168,0); }
        }

        .chain-content {
            flex: 1;
            padding-top: 0.15rem;
        }
        .chain-step-label {
            font-size: 0.85rem;
            font-weight: 800;
            color: #132f62;
            margin-bottom: 0.2rem;
        }
        .chain-step.pending .chain-step-label {
            color: #9ab0c8;
        }
        .chain-step.current .chain-step-label {
            color: #1248a8;
        }

        .chain-actor {
            font-size: 0.78rem;
            color: #3b5e96;
            margin-bottom: 0.15rem;
        }
        .chain-actor.pending-action {
            color: #9ab0c8;
            font-style: italic;
        }
        .chain-role {
            font-size: 0.72rem;
            color: #7a93b8;
        }

        .chain-date {
            font-size: 0.72rem;
            color: #7a93b8;
            margin-bottom: 0.15rem;
        }
        .chain-remarks {
            font-size: 0.75rem;
            color: #475569;
            background: #fff;
            border-left: 3px solid #b8d0fa;
            padding: 0.35rem 0.6rem;
            border-radius: 4px;
            margin-top: 0.3rem;
            font-style: italic;
        }

        .chain-doc-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            margin-top: 0.5rem;
            padding: 0.35rem 0.75rem;
            background: #fff;
            color: #1248a8;
            border: 1.5px solid #b8d0fa;
            border-radius: 6px;
            font-size: 0.72rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.15s;
        }
        .chain-doc-btn:hover {
            background: #eef4ff;
            border-color: #8db5f7;
            transform: translateY(-1px);
        }

        .chain-empty {
            text-align: center;
            padding: 1.5rem;
            color: #9ab0c8;
            font-style: italic;
            font-size: 0.82rem;
        }

        /* Dark mode */
        [data-bs-theme="dark"] .chain-section {
            background: #1f1f1f;
            border-color: #3a3a3a;
        }
        [data-bs-theme="dark"] .chain-title { color: #8ab4f8; }
        [data-bs-theme="dark"] .chain-step-label { color: #e4e6e8; }
        [data-bs-theme="dark"] .chain-actor { color: #a9b8cd; }
        [data-bs-theme="dark"] .chain-remarks {
            background: #2D2D2D;
            color: #ced4da;
        }
        [data-bs-theme="dark"] .chain-doc-btn {
            background: #2D2D2D;
            color: #8ab4f8;
            border-color: #4a5a6e;
        }
        [data-bs-theme="dark"] .chain-doc-btn:hover {
            background: #3a4a5e;
        }

        /* ============================================================
           VIEW MODAL — Drill-down Cards
           ============================================================ */
        .gs-modal-backdrop .gs-modal {
            width: 92vw;
            max-width: 900px;
            height: 80vh;                /* FIXED height, not max */
            min-height: 80vh;
            max-height: 80vh;
            display: flex;
            flex-direction: column;
        }
        .gs-modal-backdrop .gs-modal-body {
            flex: 1 1 auto;
            overflow-y: auto;
            min-height: 0;               /* allows flex child to shrink */
        }
        .gs-modal-backdrop .gs-modal-footer {
            flex-shrink: 0;
        }

        /* Modal content transition */
        .vm-body-inner {
            animation: vmFadeSlide 0.28s cubic-bezier(.22, 1, .36, 1) both;
        }
        @keyframes vmFadeSlide {
            from { opacity: 0; transform: translateX(12px); }
            to   { opacity: 1; transform: translateX(0); }
        }
        @keyframes vmFadeSlideBack {
            from { opacity: 0; transform: translateX(-12px); }
            to   { opacity: 1; transform: translateX(0); }
        }
        .vm-body-inner.vm-back {
            animation: vmFadeSlideBack 0.28s cubic-bezier(.22, 1, .36, 1) both;
        }

        /* Level 3 loading */
        .vm-loading {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 4rem 1rem;
            color: #7a93b8;
        }
        .vm-loading-spinner {
            width: 44px;
            height: 44px;
            border: 3px solid #e5eef8;
            border-top-color: #1248a8;
            border-radius: 50%;
            animation: vmSpin 0.8s linear infinite;
            margin-bottom: 1rem;
        }
        @keyframes vmSpin { to { transform: rotate(360deg); } }
        .gs-modal-backdrop .vm-loading-spinner { border-top-color: #8B1A1A; }
        .vm-cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 0.85rem;
            padding: 0.25rem;
        }
        .vm-card {
            position: relative;
            background: #fff;
            border: 1.5px solid #f5bcbc;
            border-radius: 14px;
            padding: 1.15rem 0.9rem 1rem;
            cursor: pointer;
            transition: all 0.2s cubic-bezier(.22, 1, .36, 1);
            text-align: center;
            overflow: hidden;
        }
        .vm-card::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(180deg, rgba(255,255,255,0) 60%, rgba(0,0,0,0.02) 100%);
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.2s;
        }
        .vm-card:hover::after { opacity: 1; }
        .vm-card:hover {
            border-color: #e79a9a;
            box-shadow: 0 4px 14px rgba(139,26,26,0.12);
            transform: translateY(-2px);
        }
        .vm-card:active {
            transform: translateY(0) scale(0.98);
        }
        .vm-card-checked-state {
            background: #f0fdf4;
            border-color: #a7f3d0;
        }
        .vm-card-icon {
            width: 48px;
            height: 48px;
            margin: 0 auto 0.55rem;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.35rem;
            transition: transform 0.2s;
            background: #fdf2f2;
            color: #8B1A1A;
        }
        .vm-card:hover .vm-card-icon {
            transform: scale(1.08);
        }
        .vm-card-checked-state .vm-card-icon {
            background: #d1fae5;
            color: #059669;
        }
        .vm-card-title {
            font-size: 0.95rem;
            font-weight: 800;
            color: #4a1414;
            margin-bottom: 0.2rem;
        }
        .vm-card-sub {
            font-size: 0.78rem;
            color: #a97b7b;
            margin-bottom: 0.35rem;
        }
        .vm-card-stat {
            font-size: 0.72rem;
            color: #b79a9a;
            margin-top: 0.25rem;
        }
        .vm-card-checked {
            font-size: 0.7rem;
            color: #059669;
            font-weight: 700;
            margin-top: 0.35rem;
        }
        .vm-card-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            font-size: 0.68rem;
            font-weight: 700;
            letter-spacing: 0.02em;
            padding: 0.28rem 0.7rem;
            border-radius: 999px;
            margin-top: 0.5rem;
            transition: transform 0.15s;
        }
        .vm-card:hover .vm-card-badge {
            transform: scale(1.03);
        }
        .gs-modal-header, .modal-header {
            padding: 1rem 1.35rem;
        }
        .gs-modal-title, .modal-title {
            font-size: 1rem;
            font-weight: 800;
            letter-spacing: 0.01em;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .vm-card-badge.checked { background: #d1fae5; color: #059669; }
        .vm-card-badge.pending { background: #fef3c7; color: #b45309; }
        .vm-card-badge.processing { background: #e2e8f0; color: #64748b; }

        .vm-action-bar {
            display: flex;
            gap: 0.6rem;
            flex-wrap: wrap;
            margin-bottom: 0.5rem;
        }
        .vm-action-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            padding: 0.55rem 1rem;
            background: #fff;
            color: #8B1A1A;
            border: 1.5px solid #f5bcbc;
            border-radius: 8px;
            font-size: 0.8rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.15s;
        }
        .vm-action-btn:hover { background: #fdf2f2; border-color: #e79a9a; }
        .vm-action-btn.checked {
            background: #d1fae5;
            color: #059669;
            border-color: #a7f3d0;
        }

        .vm-grade-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.82rem;
        }
        .vm-grade-table th {
            background: #8B1A1A;
            color: #fff;
            padding: 0.55rem 0.65rem;
            text-align: left;
            font-size: 0.72rem;
            text-transform: uppercase;
            letter-spacing: 0.03em;
        }
        .vm-grade-table td {
            padding: 0.5rem 0.65rem;
            border-bottom: 1px solid #f3eaea;
        }
        .vm-grade-table tr:hover td { background: #fdf2f2; }
        .vm-grade-table .pass { color: #059669; font-weight: 700; }
        .vm-grade-table .fail { color: #dc2626; font-weight: 700; }

        .vm-empty {
            text-align: center;
            padding: 3rem 1rem;
            color: #b79a9a;
            grid-column: 1 / -1;
        }
        .vm-empty i { font-size: 3rem; display: block; margin-bottom: 0.75rem; }
    </style>
    <!-- duplicate removed — already loaded in <head> -->
</head>

<body class="stsn-layout">
    <button id="stsn-toggle"><i class="bi bi-list"></i></button>
    <div id="stsn-overlay"></div>
    <?php include __DIR__ . '/../includes/teacher-sidebar.php'; ?>

    <div class="page-shell">
        <header class="top-bar">
            <div class="top-bar-left">
                <h1><i class="bi bi-inbox-fill" style="color:var(--accent)"></i> Approvals</h1>
                <p>Pending grade submissions for your review.</p>
            </div>
            <div class="top-bar-right">
                <span class="meta-chip"><i class="bi bi-person-badge"></i>
                    <?= htmlspecialchars($teacherName) ?></span>
                <span class="meta-chip"><i class="bi bi-shield-check"></i>
                    <?= htmlspecialchars($position) ?></span>
            </div>
        </header>

        <main class="page-main">
            <?php require_once __DIR__ . '/../includes/breadcrumb.php';
            renderBreadcrumb([
                ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'],
                ['label' => 'Approvals', 'icon' => 'bi bi-inbox-fill']
            ], 'teacher'); ?>

            <?php if (!empty($returned)): ?>
            <div class="panel" style="border-left:4px solid #DC3545;">
                <div class="panel-header">
                    <div>
                        <h2 class="panel-title" style="color:#DC3545;"><i class="bi bi-arrow-return-left"></i>
                            Returned to Me</h2>
                        <div class="panel-sub">Submissions sent back — review the reason and resubmit.</div>
                    </div>
                </div>
                <div style="padding:1rem 1.25rem;">
                    <?php foreach ($returned as $r): ?>
                        <div class="approval-card" style="border-color:#f5bcbc;background:#fff8f8;">
                            <div class="approval-icon" style="background:#fee2e2;color:#DC3545;">
                                <i class="bi bi-exclamation-triangle-fill"></i>
                            </div>
                            <div class="approval-info">
                                <div class="approval-title">
                                    <?= htmlspecialchars($r['subject_name']) ?>
                                    &middot; <?= htmlspecialchars($r['section_name']) ?>
                                </div>
                                <div class="approval-sub" style="color:#DC3545;">
                                    <strong>Reason:</strong> <?= htmlspecialchars($r['rejection_reason'] ?? 'No reason provided') ?>
                                </div>
                                <div class="approval-sub" style="font-size:.78rem;margin-top:2px;">
                                    Returned by <?= htmlspecialchars($r['rejected_by'] ?? '—') ?>
                                    &middot; <?= !empty($r['rejected_at']) ? date('M j, Y g:i A', strtotime($r['rejected_at'])) : '' ?>
                                </div>
                            </div>
                            <div class="approval-actions">
                                <a href="Grading-Sheet.php?section_id=<?= (int)$r['section_id'] ?>&subject_id=<?= (int)$r['subject_id'] ?>&quarter=<?= (int)$r['term_id'] ?>"
                                   class="btn-pill">
                                    <i class="bi bi-pencil-square"></i> Fix Grades
                                </a>
                                <button class="btn-success" onclick="resubmitInstance(<?= (int)$r['instance_id'] ?>)">
                                    <i class="bi bi-send"></i> Resubmit
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <div class="panel">
                <div class="panel-header">
                    <div>
                        <h2 class="panel-title"><i class="bi bi-hourglass-split"></i>
                            Pending My Action</h2>
                        <div class="panel-sub">Submissions waiting for your review.</div>
                    </div>
                </div>
                <div style="padding:1rem 1.25rem;">
                    <?php if (empty($pending)): ?>
                        <div class="no-pending">
                            <i class="bi bi-inbox"></i>
                            No pending approvals.
                        </div>
                    <?php else: ?>
                        <?php foreach ($pending as $p): ?>
                            <div class="approval-card">
                                <div class="approval-icon"><i class="bi bi-file-earmark-text"></i></div>
                                <div class="approval-info">
                                    <div class="approval-title">
                                        <?= htmlspecialchars($p['subject_name']) ?>
                                        &middot; <?= htmlspecialchars($p['section_name']) ?>
                                    </div>
                                    <div class="approval-sub">
                                        Submitted by <?= htmlspecialchars($p['teacher_name'] ?? 'Teacher') ?>
                                        &middot; <?= htmlspecialchars($termMap[(int) ($p['term_id'] ?? 0)] ?? 'Term') ?>
                                    </div>
                                    <!-- Step badge removed — reviewer knows their step -->
                                </div>
                                <div class="approval-actions">
                                    <button class="btn-pill" onclick="viewSubmission(<?= (int) $p['instance_id'] ?>)">
                                        <i class="bi bi-eye"></i> View
                                    </button>
                                    <button class="btn-danger-outline"
                                        onclick="rejectSubmission(<?= (int) $p['instance_id'] ?>)">
                                        <i class="bi bi-x-circle"></i> Return
                                    </button>
                                    <button class="btn-pill" onclick="alert('Document format not yet finalized. Coming soon.')">
                                        <i class="bi bi-file-earmark-check"></i> Approval Document
                                    </button>
                                    <button class="btn-success" onclick="approveSubmission(<?= (int) $p['instance_id'] ?>)">
                                        <i class="bi bi-check-circle"></i> Approve
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>



            <div class="gs-modal-backdrop" id="viewModal">
                <div class="gs-modal" style="max-width:900px;height:80vh;">
                    <div class="gs-modal-header">
                        <div class="gs-modal-title"><i class="bi bi-file-earmark-text"></i>
                            <span id="vmTitle">Submission</span>
                        </div>
                        <button class="gs-close-btn" onclick="closeViewModal()">
                            <i class="bi bi-x-lg"></i></button>
                    </div>
                    <div class="gs-modal-body" id="vmBody">
                        <div class="gs-loading">
                            <div class="spinner"></div>Loading...
                        </div>
                    </div>
                    <div class="gs-modal-footer" style="display:flex;gap:.5rem;justify-content:flex-end;padding:.85rem 1.25rem;border-top:1px solid #E9ECEF;">
                        <button type="button" class="btn-pill" id="vmBackBtn" onclick="vmBack()" style="display:none;">
                            <i class="bi bi-arrow-left"></i> Back
                        </button>
                        <button type="button" class="btn-pill" onclick="closeViewModal()">Close</button>
                    </div>
                </div>
            </div>

            <script>
                let currentInstanceId = null;

                function escapeHtml(s) {
                    return String(s ?? '').replace(/[&<>"']/g, c => ({
                        '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
                    }[c]));
                }

                // (legacy drill-down view removed)



                // ============================================================
                // View Modal — Drill-down hierarchy (Grade Level → Section → Grades)
                // ============================================================
                window._allGradeLevels = <?= json_encode(array_map(function($g) {
                    return ['id' => (int)$g['id'], 'name' => (string)$g['grade_level_name']];
                }, $allGradeLevels)) ?>;
                window._sectionsByGL = <?= json_encode($sectionsByGL) ?>;
                window._pendingBySection = <?= json_encode($pendingBySection) ?>;

                let _vmLevel = 1;
                let _vmBackDir = 'fwd';
                let _vmCurrentGL = 0;
                let _vmCurrentSection = null;
                let _vmChecks = {};
                window._lastVmData = null;

                function vmKey(sectionId, subjectId, termId, yearId) {
                    return sectionId + '_' + subjectId + '_' + (termId || 0) + '_' + yearId;
                }

                function viewSubmission(instanceId) {
                    currentInstanceId = instanceId;
                    _vmLevel = 1;
                    _vmCurrentGL = 0;
                    _vmCurrentSection = null;
                    openViewModal();
                }

                function openViewModal() {
                    const modalEl = document.getElementById('viewModal');
                    if (modalEl) {
                        modalEl.classList.add('open');
                        document.body.style.overflow = 'hidden';
                    }
                    loadChecks().then(renderVmLevel);
                }

                async function loadChecks() {
                    try {
                        const yearId = <?= (int)$activeYearId ?>;
                        const res = await fetch('../api/workflow/get_checks.php?academic_year_id=' + yearId).then(r => r.json());
                        if (res.success && Array.isArray(res.checks)) {
                            _vmChecks = {};
                            res.checks.forEach(c => {
                                _vmChecks[vmKey(c.section_id, c.subject_id, c.term_id, c.academic_year_id)] = true;
                            });
                        }
                    } catch (e) { console.warn('loadChecks failed', e); }
                }

                function vmBack() {
                    _vmBackDir = 'back';
                    if (_vmLevel === 3) { _vmLevel = 2; }
                    else if (_vmLevel === 2) { _vmLevel = 1; _vmCurrentGL = 0; }
                    renderVmLevel();
                }

                function renderVmLevel() {
                    const body = document.getElementById('vmBody');
                    const backBtn = document.getElementById('vmBackBtn');
                    const title = document.getElementById('vmTitle');
                    if (backBtn) backBtn.style.display = _vmLevel > 1 ? 'inline-flex' : 'none';

                    if (_vmLevel === 1) {
                        title.innerHTML = '<i class="bi bi-diagram-3-fill me-2"></i>Select Grade Level';

                        // Count pending + checked per grade level
                        const pendingByGL = {};
                        const checkedByGL = {};
                        Object.keys(window._pendingBySection || {}).forEach(sid => {
                            const list = window._pendingBySection[sid];
                            list.forEach(it => {
                                // Find the grade level that owns this section
                                let gid = 0;
                                Object.keys(window._sectionsByGL || {}).forEach(g => {
                                    if ((window._sectionsByGL[g] || []).some(s => s.id === Number(sid))) {
                                        gid = Number(g);
                                    }
                                });
                                if (!gid) return;
                                const key = vmKey(sid, it.subject_id, it.term_id, it.academic_year_id);
                                if (_vmChecks[key]) {
                                    checkedByGL[gid] = (checkedByGL[gid] || 0) + 1;
                                } else {
                                    pendingByGL[gid] = (pendingByGL[gid] || 0) + 1;
                                }
                            });
                        });

                        let html = '<div class="vm-cards-grid">';
                        (window._allGradeLevels || []).forEach(gl => {
                            const gid = gl.id;
                            const secCount = (window._sectionsByGL[gid] || []).length;
                            const pCount = pendingByGL[gid] || 0;
                            const cCount = checkedByGL[gid] || 0;

                            html += '<div class="vm-card" onclick="vmOpenGradeLevel(' + gid + ')">'
                                + '<div class="vm-card-icon"><i class="bi bi-mortarboard-fill"></i></div>'
                                + '<div class="vm-card-title">' + escapeHtml(gl.name) + '</div>'
                                + '<div class="vm-card-stat">' + secCount + ' section' + (secCount !== 1 ? 's' : '') + '</div>'
                                + (pCount > 0 ? '<div class="vm-card-badge pending"><i class="bi bi-hourglass-split"></i> ' + pCount + ' pending</div>' : '')
                                + (cCount > 0 ? '<div class="vm-card-checked"><i class="bi bi-check-circle-fill"></i> ' + cCount + ' checked</div>' : '')
                                + '</div>';
                        });
                        if (!(window._allGradeLevels || []).length) {
                            html += '<div class="vm-empty"><i class="bi bi-inbox"></i><p>No grade levels configured.</p></div>';
                        }
                        html += '</div>';
                        body.innerHTML = '<div class="vm-body-inner' + (_vmBackDir === 'back' ? ' vm-back' : '') + '">' + html + '</div>';
                    }

                    else if (_vmLevel === 2) {
                        const gl = (window._allGradeLevels || []).find(g => g.id === _vmCurrentGL);
                        const glName = gl ? gl.name : ('Grade Level ' + _vmCurrentGL);
                        title.innerHTML = '<i class="bi bi-people-fill me-2"></i>' + escapeHtml(glName) + ' — Sections';
                        const sections = (window._sectionsByGL[_vmCurrentGL] || []);

                        let html = '<div class="vm-cards-grid">';
                        sections.forEach(sec => {
                            const pendList = window._pendingBySection[sec.id] || [];
                            const hasPending = pendList.length > 0;
                            const anyChecked = hasPending && pendList.some(it =>
                                _vmChecks[vmKey(sec.id, it.subject_id, it.term_id, it.academic_year_id)]
                            );

                            let badge;
                            if (!hasPending) {
                                badge = '<div class="vm-card-badge processing"><i class="bi bi-hourglass"></i> Processing</div>';
                            } else if (anyChecked) {
                                badge = '<div class="vm-card-badge checked"><i class="bi bi-check-circle-fill"></i> Checked</div>';
                            } else {
                                badge = '<div class="vm-card-badge pending"><i class="bi bi-hourglass-split"></i> Pending Review</div>';
                            }

                            const subjText = hasPending
                                ? pendList.map(p => p.subject_name).join(', ')
                                : 'No submission yet';

                            html += '<div class="vm-card ' + (anyChecked ? 'vm-card-checked-state' : '') + '"'
                                + ' onclick="vmOpenSection(' + sec.id + ')">'
                                + '<div class="vm-card-icon"><i class="bi bi-book-fill"></i></div>'
                                + '<div class="vm-card-title">' + escapeHtml(sec.section_name) + '</div>'
                                + '<div class="vm-card-sub">' + escapeHtml(subjText) + '</div>'
                                + badge
                                + '</div>';
                        });
                        if (!sections.length) {
                            html += '<div class="vm-empty"><i class="bi bi-inbox"></i><p>No sections in this grade level.</p></div>';
                        }
                        html += '</div>';
                        body.innerHTML = '<div class="vm-body-inner' + (_vmBackDir === 'back' ? ' vm-back' : '') + '">' + html + '</div>';
                    }

                    else if (_vmLevel === 3 && _vmCurrentSection) {
                        title.innerHTML = '<i class="bi bi-table me-2"></i>' + escapeHtml(_vmCurrentSection.section_name) + ' — ' + escapeHtml(_vmCurrentSection.subject_name || '');
                        body.innerHTML = '<div class="vm-loading"><div class="vm-loading-spinner"></div><p>Loading grades...</p></div>';
                        loadSectionGrades(_vmCurrentSection);
                    }
                }

                function vmOpenGradeLevel(glId) { _vmBackDir = 'fwd'; _vmCurrentGL = Number(glId); _vmLevel = 2; renderVmLevel(); }

                function vmOpenSection(sectionId) {
                    const pendList = window._pendingBySection[sectionId] || [];
                    let secName = '';
                    Object.keys(window._sectionsByGL || {}).forEach(g => {
                        (window._sectionsByGL[g] || []).forEach(s => {
                            if (s.id === sectionId) secName = s.section_name;
                        });
                    });

                    if (!pendList.length) {
                        // No submission yet — show processing state
                        const body = document.getElementById('vmBody');
                        document.getElementById('vmTitle').innerHTML =
                            '<i class="bi bi-hourglass-split me-2"></i>' + escapeHtml(secName);
                        body.innerHTML = '<div class="vm-empty">'
                            + '<i class="bi bi-hourglass-split"></i>'
                            + '<p style="font-weight:700;color:#b45309;">Processing</p>'
                            + '<p style="font-size:.85rem;">This section has no submission yet. Waiting for the teacher to submit.</p>'
                            + '</div>';
                        _vmLevel = 3;
                        _vmBackDir = 'fwd';
                        _vmCurrentSection = { section_name: secName, subject_name: '' };
                        const bb = document.getElementById('vmBackBtn');
                        if (bb) bb.style.display = 'inline-flex';
                        return;
                    }

                    const first = pendList[0];
                    _vmCurrentSection = {
                        section_id:       sectionId,
                        instance_id:      first.instance_id,
                        subject_id:       first.subject_id,
                        subject_name:     first.subject_name,
                        subject_code:     first.subject_code,
                        term_id:          first.term_id,
                        academic_year_id: first.academic_year_id,
                        teacher_name:       first.teacher_name,
                        allow_mark_checked: first.allow_mark_checked,
                        section_name:     secName
                    };
                    _vmBackDir = 'fwd';
                    _vmLevel = 3;
                    renderVmLevel();
                }

                async function loadSectionGrades(item) {
                    try {
                        const res = await fetch('../api/workflow/get_submission.php?id=' + item.instance_id).then(r => r.json());
                        if (!res.success) {
                            document.getElementById('vmBody').innerHTML = '<div class="alert alert-danger">Failed to load grades: ' + escapeHtml(res.error || res.message || 'Unknown error') + '</div>';
                            return;
                        }
                        const isChecked = !!_vmChecks[vmKey(item.section_id, item.subject_id, item.term_id, item.academic_year_id)];
                        let html = '';
                        html += '<div class="vm-action-bar">';
                        html += '<button class="vm-action-btn" onclick="vmExportCSV()"><i class="bi bi-file-earmark-excel"></i> Export CSV</button>';
                        if (item.allow_mark_checked) html += '<button class="vm-action-btn ' + (isChecked ? 'checked' : '') + '" onclick="vmToggleCheck(' + item.section_id + ', ' + item.subject_id + ', ' + (item.term_id || 0) + ', ' + item.academic_year_id + ', ' + (isChecked ? 'false' : 'true') + ')">'
                            + '<i class="bi ' + (isChecked ? 'bi-check-circle-fill' : 'bi-check-circle') + '"></i> ' + (isChecked ? 'Checked' : 'Mark as Checked')
                            + '</button>';
                        html += '</div>';

                        html += '<div style="overflow-x:auto;margin-top:1rem;"><table class="vm-grade-table">';
                        html += '<thead><tr><th>#</th><th>Student Name</th><th>LRN</th><th>WW</th><th>PT</th><th>QA</th><th>Initial</th><th>Final</th><th>Remarks</th></tr></thead><tbody>';
                        (res.students || []).forEach((s, i) => {
                            const remRaw = String(s.remarks || '').toLowerCase();
                            const remClass = remRaw.includes('pass') ? 'pass' : (remRaw.includes('fail') ? 'fail' : '');
                            html += '<tr>'
                                + '<td>' + (i + 1) + '</td>'
                                + '<td>' + escapeHtml(s.name || '') + '</td>'
                                + '<td>' + escapeHtml(s.lrn || '') + '</td>'
                                + '<td>' + escapeHtml(s.ww != null ? s.ww : '—') + '</td>'
                                + '<td>' + escapeHtml(s.pt != null ? s.pt : '—') + '</td>'
                                + '<td>' + escapeHtml(s.qa != null ? s.qa : '—') + '</td>'
                                + '<td>' + escapeHtml(s.initial != null ? s.initial : '—') + '</td>'
                                + '<td><strong>' + escapeHtml(s.final != null ? s.final : '—') + '</strong></td>'
                                + '<td class="' + remClass + '">' + escapeHtml(s.remarks || '—') + '</td>'
                                + '</tr>';
                        });
                        if (!res.students || res.students.length === 0) {
                            html += '<tr><td colspan="9" class="text-center py-4 text-muted">No students found.</td></tr>';
                        }
                        html += '</tbody></table></div>';
                        document.getElementById('vmBody').innerHTML = html;
                        window._lastVmData = res;
                    } catch (e) {
                        document.getElementById('vmBody').innerHTML = '<div class="alert alert-danger">Error: ' + escapeHtml(e.message) + '</div>';
                    }
                }

                async function vmToggleCheck(sectionId, subjectId, termId, yearId, checked) {
                    try {
                        const res = await fetch('../api/workflow/toggle_check.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ section_id: sectionId, subject_id: subjectId, term_id: termId, academic_year_id: yearId, checked: checked })
                        }).then(r => r.json());
                        if (res.success) {
                            const key = vmKey(sectionId, subjectId, termId, yearId);
                            if (checked) { _vmChecks[key] = true; } else { delete _vmChecks[key]; }
                            loadSectionGrades(_vmCurrentSection);
                        } else {
                            alert(res.error || 'Failed to update check status');
                        }
                    } catch (e) { alert('Error: ' + e.message); }
                }

                function vmExportCSV() {
                    const d = window._lastVmData;
                    if (!d || !d.students || !d.students.length) { alert('No grade data to export'); return; }
                    const esc = v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
                    let csv = 'No.,Student Name,LRN,WW,PT,QA,Initial,Final,Remarks\n';
                    d.students.forEach((s, i) => {
                        csv += [i + 1, esc(s.name), esc(s.lrn), esc(s.ww), esc(s.pt), esc(s.qa), esc(s.initial), esc(s.final), esc(s.remarks)].join(',') + '\n';
                    });
                    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    const sec = _vmCurrentSection || {};
                    a.href = url;
                    a.download = ('grades_' + (sec.section_name || 'section') + '_' + (sec.subject_code || '') + '_' + (sec.term_id || '') + '.csv').replace(/\s/g, '_');
                    document.body.appendChild(a); a.click(); document.body.removeChild(a);
                    setTimeout(() => URL.revokeObjectURL(url), 1000);
                }

                function closeViewModal() {
                    document.getElementById('viewModal').classList.remove('open');
                    document.body.style.overflow = '';
                }

                async function approveSubmission(id) {
                    if (!confirm('Approve this submission?')) return;
                    await postAdvance(id, 'APPROVED', '');
                }

                async function rejectSubmission(id) {
                    const remarks = prompt('Reason for returning to Teacher:');
                    if (!remarks) return;
                    await postAdvance(id, 'REJECTED', remarks);
                }

                async function postAdvance(id, action, remarks) {
                    try {
                        const r = await fetch('../api/workflow/advance.php', {
                            method: 'POST', headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ instance_id: id, action: action, remarks: remarks })
                        });
                        const d = await r.json();
                        if (d.success) {
                            alert(d.message || 'Done');
                            location.reload();
                        } else { alert(d.message || 'Failed'); }
                    } catch (e) { alert('Network error.'); }
                }

                async function resubmitInstance(id) {
                    if (!confirm('Resubmit this submission to the Adviser?')) return;
                    try {
                        const r = await fetch('../api/workflow/resubmit.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ instance_id: id })
                        });
                        const d = await r.json();
                        if (d.success) {
                            alert(d.message || 'Resubmitted');
                            location.reload();
                        } else {
                            alert(d.message || 'Failed');
                        }
                    } catch (e) {
                        alert('Network error.');
                    }
                }

                (function () {
                    const sb = document.getElementById('stsn-sidebar'),
                        tg = document.getElementById('stsn-toggle'),
                        ov = document.getElementById('stsn-overlay'),
                        cb = document.getElementById('stsn-collapse-btn');
                    const saved = localStorage.getItem('stsn-sidebar-collapsed');
                    if (sb && saved === 'true' && window.innerWidth >= 992) {
                        sb.classList.add('collapsed'); document.body.classList.add('sidebar-collapsed');
                    }
                    cb?.addEventListener('click', e => {
                        e.stopPropagation(); sb.classList.toggle('collapsed');
                        const c = sb.classList.contains('collapsed');
                        document.body.classList.toggle('sidebar-collapsed', c);
                        localStorage.setItem('stsn-sidebar-collapsed', c);
                    });
                    tg?.addEventListener('click', () => {
                        sb.classList.toggle('mobile-open'); ov.classList.toggle('visible');
                    });
                    ov?.addEventListener('click', () => {
                        sb.classList.remove('mobile-open'); ov.classList.remove('visible');
                    });
                })();
            </script>
</body>

</html>