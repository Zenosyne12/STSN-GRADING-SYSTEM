<?php
require_once __DIR__ . '/../api/login/teacher_auth.php';

$teacherName = $_SESSION['teacher_name'] ?? 'Teacher';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Advisory | STSN Grading System</title>

    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css/index.css">

    <style>
        :root {
            --primary: #0A2F44;
            --primary-soft: rgba(10, 47, 68, 0.08);
            --accent: #C5A028;
            --bg: #F5F7FA;
            --surface: #FFFFFF;
            --surface-2: #F8F9FA;
            --text: #1E2A3E;
            --muted: #6C757D;
            --border: #E9ECEF;
            --danger: #DC3545;
            --warning: #F59E0B;
            --success: #198754;
            --shadow: 0 10px 30px rgba(10, 47, 68, 0.08);
            --radius: 18px;
            --sidebar-width: 264px;
            --sidebar-collapsed-width: 72px;
        }

        * { box-sizing: border-box; }

        body.stsn-layout {
            margin: 0;
            font-family: "Plus Jakarta Sans", sans-serif;
            background: var(--bg);
            color: var(--text);
        }

        #stsn-toggle {
            position: fixed;
            top: 1rem;
            left: 1rem;
            z-index: 1100;
            width: 44px;
            height: 44px;
            border: 1px solid var(--border);
            border-radius: 12px;
            background: #fff;
            color: var(--primary);
            display: none;
            align-items: center;
            justify-content: center;
            box-shadow: var(--shadow);
            cursor: pointer;
        }

        #stsn-toggle i { font-size: 1.3rem; }

        #stsn-overlay {
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.35);
            opacity: 0;
            visibility: hidden;
            transition: 0.25s ease;
            z-index: 1035;
        }

        #stsn-overlay.visible {
            opacity: 1;
            visibility: visible;
        }

        .page-shell {
            margin-left: var(--sidebar-width);
            min-height: 100vh;
            transition: margin-left 0.28s ease;
        }

        body.sidebar-collapsed .page-shell {
            margin-left: var(--sidebar-collapsed-width);
        }

        .page-main {
            padding: 1.5rem 2rem 2rem;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 1rem;
            flex-wrap: wrap;
            margin-bottom: 1.25rem;
        }

        .page-title h1 {
            margin: 0;
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--primary);
        }

        .page-title p {
            margin: 0.4rem 0 0;
            color: var(--muted);
            font-size: 0.94rem;
        }

        .header-meta {
            display: flex;
            gap: 0.7rem;
            flex-wrap: wrap;
        }

        .meta-chip {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 999px;
            padding: 0.6rem 0.9rem;
            font-size: 0.82rem;
            color: var(--muted);
            white-space: nowrap;
        }

        .toolbar {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 1rem;
            display: grid;
            grid-template-columns: 1.2fr 220px 220px auto;
            gap: 0.75rem;
            align-items: center;
            margin-bottom: 1rem;
        }

        .toolbar input,
        .toolbar select {
            width: 100%;
            border: 1px solid var(--border);
            background: #fff;
            border-radius: 12px;
            padding: 0.8rem 0.9rem;
            font-family: inherit;
            font-size: 0.9rem;
            color: var(--text);
        }

        .toolbar-actions {
            display: flex;
            gap: 0.65rem;
            flex-wrap: wrap;
            justify-content: flex-end;
        }

        .action-btn {
            border: 1px solid var(--border);
            background: #fff;
            color: var(--text);
            border-radius: 12px;
            padding: 0.78rem 0.95rem;
            cursor: pointer;
            font-family: inherit;
            font-weight: 600;
            font-size: 0.87rem;
            transition: 0.2s ease;
        }

        .action-btn:hover {
            background: var(--surface-2);
            transform: translateY(-1px);
        }

        .content-grid {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 320px;
            gap: 1rem;
        }

        .panel {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
        }

        .panel-header {
            padding: 1rem 1rem 0.9rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .panel-title {
            margin: 0;
            display: flex;
            align-items: center;
            gap: 0.55rem;
            font-size: 1rem;
            font-weight: 700;
            color: var(--primary);
        }

        .panel-title i { color: var(--accent); }

        .panel-sub {
            font-size: 0.82rem;
            color: var(--muted);
            margin-top: 0.2rem;
        }

        .table-wrap {
            overflow-x: auto;
            padding: 0 1rem 1rem;
        }

        .student-table {
            width: 100%;
            min-width: 900px;
            border-collapse: collapse;
        }

        .student-table th {
            text-align: left;
            font-size: 0.77rem;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            color: var(--muted);
            padding: 0.95rem 0 0.75rem;
            border-bottom: 1px solid var(--border);
        }

        .student-table td {
            padding: 0.95rem 0;
            border-bottom: 1px solid #f0f2f5;
            font-size: 0.9rem;
            vertical-align: middle;
        }

        .student-table tr:last-child td { border-bottom: none; }

        .student-main {
            font-weight: 700;
            color: var(--text);
        }

        .student-sub {
            display: block;
            font-size: 0.8rem;
            color: var(--muted);
            margin-top: 0.15rem;
        }

        .td-center { text-align: center; }

        .pill {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 999px;
            padding: 0.35rem 0.65rem;
            font-size: 0.74rem;
            font-weight: 700;
            white-space: nowrap;
        }

        .pill-danger {
            background: rgba(220, 53, 69, 0.1);
            color: var(--danger);
        }

        .pill-warning {
            background: rgba(245, 158, 11, 0.12);
            color: #b96f00;
        }

        .pill-success {
            background: rgba(25, 135, 84, 0.12);
            color: var(--success);
        }

        .pill-muted {
            background: #eef1f4;
            color: #5f6b76;
        }

        .row-actions {
            display: flex;
            gap: 0.45rem;
            flex-wrap: wrap;
        }

        .mini-btn {
            border: 1px solid var(--border);
            background: #fff;
            color: var(--text);
            border-radius: 10px;
            padding: 0.5rem 0.7rem;
            font-size: 0.78rem;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .mini-btn:hover {
            background: var(--surface-2);
        }

        .side-stack {
            display: grid;
            gap: 1rem;
        }

        .side-panel { padding: 1rem; }

        .compact-list {
            display: grid;
            gap: 0.8rem;
            margin-top: 1rem;
        }

        .compact-item {
            display: flex;
            gap: 0.75rem;
            align-items: flex-start;
        }

        .compact-icon {
            width: 38px;
            height: 38px;
            border-radius: 12px;
            background: var(--primary-soft);
            color: var(--primary);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .compact-title {
            font-size: 0.9rem;
            font-weight: 700;
            margin-bottom: 0.15rem;
        }

        .compact-sub {
            font-size: 0.82rem;
            color: var(--muted);
            line-height: 1.45;
        }

        .load-list {
            display: grid;
            gap: 0.75rem;
            margin-top: 1rem;
        }

        .load-item {
            padding: 0.9rem;
            border-radius: 14px;
            background: var(--surface-2);
        }

        .load-item-title {
            font-size: 0.9rem;
            font-weight: 700;
            color: var(--text);
            margin-bottom: 0.2rem;
        }

        .load-item-sub {
            font-size: 0.8rem;
            color: var(--muted);
            margin-bottom: 0.5rem;
        }

        .load-meta {
            display: flex;
            gap: 0.45rem;
            flex-wrap: wrap;
        }

        .empty-state,
        .loading-state {
            padding: 1rem 0;
            color: var(--muted);
            font-size: 0.92rem;
        }

        @media (max-width: 1199px) {
            .toolbar { grid-template-columns: 1fr 1fr; }
            .content-grid { grid-template-columns: 1fr; }
        }

        @media (max-width: 991.98px) {
            #stsn-toggle { display: inline-flex; }
            .page-shell,
            body.sidebar-collapsed .page-shell { margin-left: 0; }
            .page-main { padding: 5rem 1rem 1.5rem; }
            .toolbar { grid-template-columns: 1fr; }
            .toolbar-actions { justify-content: flex-start; }
        }

        @media (max-width: 767px) {
            .page-header {
                flex-direction: column;
                align-items: flex-start;
            }
            .page-title h1 { font-size: 1.45rem; }
        }
    </style>
</head>
<body class="stsn-layout">
    <button id="stsn-toggle" aria-label="Toggle sidebar">
        <i class="bi bi-list"></i>
    </button>

    <div id="stsn-overlay"></div>

    <?php include __DIR__ . '/../includes/teacher-sidebar.php'; ?>

    <div class="page-shell">
        <main class="page-main">
            <div class="page-header">
                <div class="page-title">
                    <h1>My Advisory</h1>
                    <p>View and manage your advisory section and student list.</p>
                </div>

                <div class="header-meta">
                    <div class="meta-chip"><i class="bi bi-person-badge"></i> <?php echo htmlspecialchars($teacherName); ?></div>
                    <div class="meta-chip"><i class="bi bi-mortarboard"></i> Advisory</div>
                </div>
            </div>

            <section class="toolbar">
                <input type="text" id="studentSearch" placeholder="Search student name or LRN">
                <select id="sectionSelect">
                    <option value="">Loading sections...</option>
                </select>
                <select id="genderFilter">
                    <option value="">All Genders</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
                <div class="toolbar-actions">
                    <button class="action-btn" type="button" onclick="loadAdvisory()">
                        <i class="bi bi-arrow-clockwise"></i> Refresh
                    </button>
                </div>
            </section>

            <section class="content-grid">
                <div class="panel">
                    <div class="panel-header">
                        <div>
                            <h2 class="panel-title"><i class="bi bi-people-fill"></i> <span id="sectionTitle">Loading...</span></h2>
                            <div class="panel-sub">Student masterlist for the selected advisory section.</div>
                        </div>
                    </div>

                    <div class="table-wrap">
                        <div id="loadingState" class="loading-state">Loading students...</div>

                        <table class="student-table" id="studentTable" style="display:none;">
                            <thead>
                                <tr>
                                    <th>Student</th>
                                    <th class="td-center">Gender</th>
                                    <th class="td-center">LRN</th>
                                    <th class="td-center">Grade Level</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="studentTableBody"></tbody>
                        </table>

                        <div id="emptyState" class="empty-state" style="display:none;">
                            No students found.
                        </div>
                    </div>
                </div>

                <div class="side-stack">
                    <div class="panel side-panel">
                        <h3 class="panel-title"><i class="bi bi-info-circle-fill"></i> Section Info</h3>
                        <div class="load-list" style="margin-top: 1rem;">
                            <div class="load-item">
                                <div class="load-item-title" id="infoSection">-</div>
                                <div class="load-item-sub">Advisory Section</div>
                            </div>
                            <div class="load-item">
                                <div class="load-item-title" id="infoStudents">0</div>
                                <div class="load-item-sub">Total Students</div>
                            </div>
                            <div class="load-item">
                                <div class="load-item-title" id="infoSchoolYear">-</div>
                                <div class="load-item-sub">School Year</div>
                            </div>
                        </div>
                    </div>

                    <div class="panel side-panel">
                        <h3 class="panel-title"><i class="bi bi-lightning-charge-fill"></i> Quick Actions</h3>
                        <div class="compact-list">
                            <div class="compact-item">
                                <div class="compact-icon"><i class="bi bi-journal-text"></i></div>
                                <div>
                                    <div class="compact-title">View Grades</div>
                                    <div class="compact-sub">Check individual student grades and performance records.</div>
                                </div>
                            </div>
                            <div class="compact-item">
                                <div class="compact-icon"><i class="bi bi-file-earmark-text"></i></div>
                                <div>
                                    <div class="compact-title">Generate Reports</div>
                                    <div class="compact-sub">Prepare advisory class reports and summaries.</div>
                                </div>
                            </div>
                            <div class="compact-item">
                                <div class="compact-icon"><i class="bi bi-envelope"></i></div>
                                <div>
                                    <div class="compact-title">Contact Parents</div>
                                    <div class="compact-sub">Reach out to guardians for student concerns.</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <script>
        const sectionSelect = document.getElementById('sectionSelect');
        const studentSearch = document.getElementById('studentSearch');
        const genderFilter = document.getElementById('genderFilter');
        const studentTable = document.getElementById('studentTable');
        const studentTableBody = document.getElementById('studentTableBody');
        const loadingState = document.getElementById('loadingState');
        const emptyState = document.getElementById('emptyState');

        let advisoryData = null;
        let currentStudents = [];

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text ?? '';
            return div.innerHTML;
        }

        async function loadAdvisory(sectionId = '') {
            loadingState.style.display = 'block';
            studentTable.style.display = 'none';
            emptyState.style.display = 'none';
            studentTableBody.innerHTML = '';

            try {
                let url = '../api/advisory/my_advisory.php';
                if (sectionId) {
                    url += '?section=' + encodeURIComponent(sectionId);
                }

                const response = await fetch(url, {
                    headers: { 'Accept': 'application/json' }
                });

                const rawText = await response.text();
                let data;
                try {
                    data = JSON.parse(rawText);
                } catch (e) {
                    console.error('API raw response:', rawText);
                    renderError('API error: ' + rawText);
                    return;
                }

                advisoryData = data;

                if (!response.ok || !data.success) {
                    renderError(data.message || 'Failed to load advisory data.');
                    return;
                }

                renderPage(data);
            } catch (error) {
                console.error(error);
                renderError('Unable to connect to the advisory API.');
            }
        }

        function renderPage(data) {
            document.getElementById('infoSchoolYear').textContent = data.academic_year?.label || '-';

            renderSections(data.advisories || [], data.selected_section);
            renderSelectedSection(data.selected_section);

            currentStudents = data.students || [];
            renderStudents(currentStudents);
        }

        function renderSections(advisories, selectedSection) {
            sectionSelect.innerHTML = '';

            if (!advisories.length) {
                sectionSelect.innerHTML = `<option value="">No advisory assigned</option>`;
                return;
            }

            advisories.forEach(section => {
                const option = document.createElement('option');
                option.value = section.section_id;
                option.textContent = section.display_name;

                if (selectedSection && Number(section.section_id) === Number(selectedSection.section_id)) {
                    option.selected = true;
                }

                sectionSelect.appendChild(option);
            });
        }

        function renderSelectedSection(section) {
            if (!section) {
                document.getElementById('sectionTitle').textContent = 'No advisory assigned';
                document.getElementById('infoSection').textContent = '-';
                document.getElementById('infoStudents').textContent = '0';
                return;
            }

            document.getElementById('sectionTitle').textContent = section.display_name || '-';
            document.getElementById('infoSection').textContent = section.display_name || '-';
            document.getElementById('infoStudents').textContent = section.total_students ?? 0;
        }

        function renderStudents(students) {
            loadingState.style.display = 'none';

            if (!students.length) {
                studentTable.style.display = 'none';
                emptyState.style.display = 'block';
                return;
            }

            emptyState.style.display = 'none';
            studentTable.style.display = 'table';

            studentTableBody.innerHTML = students.map(student => `
                <tr>
                    <td>
                        <div class="student-main">${escapeHtml(student.name || '-')}</div>
                        <span class="student-sub">ID: ${escapeHtml(String(student.id ?? '-'))}</span>
                    </td>
                    <td class="td-center">${escapeHtml(student.gender || '-')}</td>
                    <td class="td-center">${escapeHtml(student.lrn || '-')}</td>
                    <td class="td-center">${escapeHtml(student.grade_level_name || '-')}</td>
                    <td>
                        <div class="row-actions">
                            <a class="mini-btn" href="Grading-sheet.php?student_id=${encodeURIComponent(student.id)}">
                                Grades
                            </a>
                            
                        </div>
                    </td>
                </tr>
            `).join('');
        }

        function renderError(message) {
            loadingState.style.display = 'none';
            emptyState.style.display = 'block';
            emptyState.textContent = message;
            studentTableBody.innerHTML = '';
        }

        function getFilteredStudents() {
            const search = studentSearch.value.trim().toLowerCase();
            const gender = genderFilter.value;

            return currentStudents.filter(student => {
                const matchesSearch = !search ||
                    (student.name || '').toLowerCase().includes(search) ||
                    (student.lrn || '').toLowerCase().includes(search);

                const matchesGender = !gender || student.gender === gender;

                return matchesSearch && matchesGender;
            });
        }

        function filterStudents() {
            const filtered = getFilteredStudents();
            renderStudents(filtered);
        }

        studentSearch.addEventListener('input', filterStudents);
        genderFilter.addEventListener('change', filterStudents);

        sectionSelect.addEventListener('change', function () {
            loadAdvisory(this.value);
        });

        // Sidebar
        const sidebar = document.getElementById('stsn-sidebar');
        const toggleBtn = document.getElementById('stsn-toggle');
        const overlay = document.getElementById('stsn-overlay');
        const collapseBtn = document.getElementById('stsn-collapse-btn');

        const savedState = localStorage.getItem('stsn-sidebar-collapsed');

        if (sidebar && savedState === 'true' && window.innerWidth >= 992) {
            sidebar.classList.add('collapsed');
            document.body.classList.add('sidebar-collapsed');
        }

        if (collapseBtn && sidebar) {
            collapseBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                sidebar.classList.toggle('collapsed');
                const isCollapsed = sidebar.classList.contains('collapsed');
                document.body.classList.toggle('sidebar-collapsed', isCollapsed);
                localStorage.setItem('stsn-sidebar-collapsed', isCollapsed);
            });
        }

        if (toggleBtn && sidebar) {
            toggleBtn.addEventListener('click', function () {
                sidebar.classList.toggle('mobile-open');
                overlay.classList.toggle('visible');
            });
        }

        if (overlay && sidebar) {
            overlay.addEventListener('click', function () {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('visible');
            });
        }

        window.addEventListener('resize', function () {
            if (!sidebar) return;
            if (window.innerWidth >= 992) {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('visible');
            } else {
                document.body.classList.remove('sidebar-collapsed');
            }
        });

        loadAdvisory();
    </script>
</body>
</html>