<?php
require_once __DIR__ . '/../api/login/teacher_auth.php';

// Server-side guard: Adviser only (sidebar hides the link; this blocks direct URL access).
requireAdviser();

$teacherName = $_SESSION['teacher_name'] ?? 'Teacher';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Advisory | STSN Grading System</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/system-alerts.css">
    <style>
        :root {
            --primary: #0A2F44; --primary-soft: rgba(10,47,68,0.08);
            --accent: #C5A028; --bg: #F5F7FA; --surface: #FFFFFF;
            --surface-2: #F8F9FA; --text: #1E2A3E; --muted: #6C757D;
            --border: #E9ECEF; --danger: #DC3545; --success: #198754;
            --shadow: 0 10px 30px rgba(10,47,68,0.08); --radius: 18px;
            --sidebar-width: 264px; --sidebar-collapsed-width: 72px;
        }

        /* Dark mode — adapt page tokens (surfaces / text) without a redesign */
        html.dark-mode,
        [data-bs-theme="dark"] {
            --bg: #0f0f0f;
            --surface: #1e1e1e;
            --surface-2: #262626;
            --text: #e4e6e8;
            --muted: #9aa3ad;
            --border: #34393f;
            --primary-soft: rgba(120, 170, 255, 0.12);
            --shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        }
        /* Hardcoded light surfaces that bypass the tokens */
        html.dark-mode #stsn-toggle,
        [data-bs-theme="dark"] #stsn-toggle { background: var(--surface); color: #cfe0ff; }
        html.dark-mode .btn-secondary,
        [data-bs-theme="dark"] .btn-secondary { background: var(--surface-2); color: #cfe0ff; border-color: var(--border); }
        html.dark-mode .toolbar select,
        html.dark-mode .toolbar input[type="text"],
        html.dark-mode .form-field select,
        [data-bs-theme="dark"] .toolbar select,
        [data-bs-theme="dark"] .toolbar input[type="text"],
        [data-bs-theme="dark"] .form-field select { background: var(--surface-2); color: var(--text); border-color: var(--border); }

        * { box-sizing: border-box; }
        body.stsn-layout { margin:0; font-family:"Plus Jakarta Sans",sans-serif; background:var(--bg); color:var(--text); }

        #stsn-toggle { position:fixed; top:1rem; left:1rem; z-index:1100; width:44px; height:44px; border:1px solid var(--border); border-radius:12px; background:#fff; color:var(--primary); display:none; align-items:center; justify-content:center; box-shadow:var(--shadow); cursor:pointer; }
        #stsn-overlay { position:fixed; inset:0; background:rgba(15,23,42,0.35); opacity:0; visibility:hidden; transition:0.25s ease; z-index:1035; }
        #stsn-overlay.visible { opacity:1; visibility:visible; }
        .page-shell { margin-left:var(--sidebar-width); min-height:100vh; transition:margin-left 0.28s ease; display:flex; flex-direction:column; }
        body.sidebar-collapsed .page-shell { margin-left:var(--sidebar-collapsed-width); }

        
        .top-bar {
            background: var(--surface);
            border-bottom: 1px solid var(--border);
            padding: .85rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            flex-wrap: wrap;
            position: sticky;
            top: 0;
            z-index: 40;
        }
        .top-bar-left h1 {
            margin: 0;
            font-size: 1.25rem;
            font-weight: 800;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: .5rem;
        }
        .top-bar-left p {
            margin: .2rem 0 0;
            color: var(--muted);
            font-size: .82rem;
        }
        .top-bar-right {
            display: flex;
            align-items: center;
            gap: .55rem;
            flex-wrap: wrap;
        }
        .meta-chip {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 999px;
            padding: .45rem .8rem;
            font-size: .78rem;
            color: var(--muted);
            display: inline-flex;
            align-items: center;
            gap: 5px;
            white-space: nowrap;
        }

        
        .page-main { padding: 1rem 1.5rem 1.5rem; display: grid; gap: 1rem; }

        
        .content-grid { display:grid; grid-template-columns:minmax(0,1fr) 320px; gap:1rem; }

        
        .panel {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            overflow: hidden;
        }
        .panel-header {
            padding: 1rem 1.25rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 1rem;
            flex-wrap: wrap;
        }
        .panel-title {
            margin: 0;
            color: var(--primary);
            font-size: 1rem;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: .5rem;
        }
        .panel-title i { color: var(--accent); }
        .panel-sub {
            margin-top: .2rem;
            color: var(--muted);
            font-size: .8rem;
        }

        
        .panel-header .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            background: #fff;
            color: var(--primary);
            border: 1.5px solid var(--border);
            border-radius: 999px;
            padding: 0.5rem 1rem;
            font-family: inherit;
            font-weight: 700;
            font-size: 0.8rem;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.15s ease;
            white-space: nowrap;
        }
        .panel-header .btn:hover { background: var(--surface-2); border-color: #c5d1dc; }
        .panel-header .btn-primary {
            background: var(--primary);
            border-color: var(--primary);
            color: #fff;
            box-shadow: 0 2px 8px rgba(10,47,68,0.15);
        }
        .panel-header .btn-primary:hover { background: #0d3b56; border-color: #0d3b56; box-shadow: 0 4px 12px rgba(10,47,68,0.2); transform: translateY(-1px); }
        .panel-header .btn:disabled { opacity: .45; cursor: not-allowed; box-shadow: none; transform: none; }
        .panel-header select.btn {
            appearance: none;
            -webkit-appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='%236C757D' viewBox='0 0 16 16'%3E%3Cpath d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right .6rem center;
            padding-right: 1.6rem;
        }
        .panel-header input[type="text"] {
            border: 1px solid var(--border);
            background: #fff;
            border-radius: 12px;
            padding: .52rem .75rem;
            font-family: inherit;
            font-size: .84rem;
            color: var(--text);
            width: 200px;
        }

        .table-wrap { overflow-x:auto; padding:0 1rem 1rem; }
        .student-table {
            width:100%;
            min-width:860px;
            border-collapse:collapse;
            table-layout: fixed;
        }
        .student-table th {
            text-align:left;
            font-size:0.77rem;
            text-transform:uppercase;
            letter-spacing:0.05em;
            color:var(--muted);
            padding:0.85rem 0.75rem;
            border-bottom:1px solid var(--border);
            white-space:nowrap;
        }
        .student-table td {
            padding:0.85rem 0.75rem;
            border-bottom:1px solid var(--border);
            font-size:0.9rem;
            vertical-align:middle;
        }
        .student-table tr:last-child td { border-bottom:none; }
        .student-table tr:hover td { background:var(--surface-2); }
        .td-center { text-align:center; }
        .student-table th, .student-table td { overflow: hidden; text-overflow: ellipsis; }
        .col-lrn { width: 160px; }
        .col-student { width: auto; }
        .col-gender { width: 120px; }
        .col-parent { width: 190px; }
        .student-main { font-weight:600; color:var(--text); }
        .student-sub  { font-size:0.78rem; color:var(--muted); }
        .row-actions  { display:flex; gap:0.4rem; }
        .mini-btn {
            display:inline-flex;
            align-items:center;
            gap:4px;
            padding:0.35rem 0.7rem;
            border-radius:8px;
            font-size:0.78rem;
            font-weight:600;
            cursor:pointer;
            border:1px solid var(--border);
            background:#fff;
            color:var(--text);
            text-decoration:none;
            transition:0.15s ease;
            font-family:inherit;
        }
        .mini-btn:hover { background:var(--surface-2); }
        .mini-btn.primary { background:var(--primary); color:#fff; border-color:var(--primary); }

        .side-stack { display:flex; flex-direction:column; gap:1rem; }
        .side-panel  { padding:1rem; }
        .load-list   { display:flex; flex-direction:column; gap:0.65rem; }
        .load-item   { padding:0.6rem 0; border-bottom:1px dashed var(--border); }
        .load-item:last-child { border-bottom:none; }
        .load-item-title { font-size:0.9rem; font-weight:700; color:var(--text); margin-bottom:0.2rem; }
        .load-item-sub   { font-size:0.8rem; color:var(--muted); }
        .compact-list { display:flex; flex-direction:column; gap:0.75rem; margin-top:0.75rem; }
        .compact-item { display:flex; align-items:flex-start; gap:0.65rem; cursor:pointer; }
        .compact-icon { width:32px; height:32px; background:var(--primary-soft); border-radius:8px; display:flex; align-items:center; justify-content:center; color:var(--primary); font-size:0.95rem; flex-shrink:0; }
        .compact-title { font-size:0.85rem; font-weight:700; color:var(--text); }
        .compact-sub   { font-size:0.78rem; color:var(--muted); }
        .empty-state, .loading-state { padding:1rem 0; color:var(--muted); font-size:0.92rem; }

        
        .notif-wrap { position: relative; }
        .notif-btn { width:42px; height:42px; border-radius:50%; border:1px solid var(--border); background:#fff; color:var(--primary); display:inline-flex; align-items:center; justify-content:center; cursor:pointer; box-shadow:var(--shadow); }
        .notif-btn i { font-size:1.15rem; }
        .notif-count { position:absolute; top:-2px; right:-2px; min-width:18px; height:18px; border-radius:999px; border:2px solid #fff; background:#ef4444; color:#fff; font-size:.68rem; font-weight:700; display:none; align-items:center; justify-content:center; padding:0 4px; line-height:1; }
        .notif-panel { position:absolute; top:calc(100% + 12px); right:0; width:min(420px, calc(100vw - 2rem)); max-height:460px; overflow:auto; background:#fff; border:1px solid var(--border); border-radius:16px; box-shadow:0 18px 42px rgba(10,47,68,.18); padding:.85rem; z-index:1200; opacity:0; visibility:hidden; pointer-events:none; transform:translateY(8px) scale(.98); transform-origin:top right; transition:opacity .2s ease, transform .2s cubic-bezier(.22,1,.36,1), visibility .2s; }
        .notif-panel.open { opacity:1; visibility:visible; pointer-events:auto; transform:translateY(0) scale(1); }
        .notif-panel-title { font-size:.95rem; font-weight:800; color:var(--primary); padding:.35rem .35rem .65rem; }
        .notif-item { border:1px solid #eef1f4; border-radius:12px; padding:.72rem .8rem; background:#fafcff; margin-bottom:.6rem; }
        .notif-item:last-child { margin-bottom:0; }
        .notif-item-title { font-size:.9rem; font-weight:800; color:var(--text); line-height:1.35; }
        .notif-item-sub { font-size:.84rem; color:var(--muted); margin-top:.25rem; line-height:1.5; }

        
        .gs-modal-backdrop { display:flex; position:fixed; inset:0; z-index:2000; background:rgba(10,20,35,0.55); backdrop-filter:blur(3px); align-items:center; justify-content:center; opacity:0; visibility:hidden; pointer-events:none; transition:opacity .24s ease-in-out, visibility .24s; }
        .gs-modal-backdrop.open { opacity:1; visibility:visible; pointer-events:auto; }
        .gs-modal { background:#fff; border-radius:20px; box-shadow:0 24px 80px rgba(10,47,68,0.22); width:96vw; max-width:1400px; max-height:92vh; display:flex; flex-direction:column; transform:translateY(18px) scale(.985); opacity:0; transition:transform .26s cubic-bezier(.22,1,.36,1), opacity .22s ease-out; }
        .gs-modal-backdrop.open .gs-modal { transform:translateY(0) scale(1); opacity:1; }

        .gs-modal-header { padding:1.1rem 1.5rem; border-bottom:1px solid var(--border); display:flex; align-items:center; justify-content:space-between; gap:1rem; flex-wrap:wrap; }
        .gs-modal-title { font-size:1.05rem; font-weight:800; color:var(--primary); display:flex; align-items:center; gap:0.5rem; }
        .gs-modal-title i { color:var(--accent); }
        .gs-close-btn { width:36px; height:36px; border-radius:50%; border:1px solid var(--border); background:#fff; cursor:pointer; display:flex; align-items:center; justify-content:center; font-size:1.1rem; color:var(--muted); transition:0.15s; }
        .gs-close-btn:hover { background:#fee2e2; color:var(--danger); border-color:#fecaca; }

        .gs-modal-toolbar { padding:0.75rem 1.5rem; border-bottom:1px solid var(--border); display:flex; align-items:center; gap:0.75rem; flex-wrap:wrap; background:var(--surface-2); }
        .gs-modal-toolbar label { font-size:0.82rem; font-weight:700; color:var(--muted); white-space:nowrap; }
        .gs-modal-toolbar select { border:1px solid var(--border); background:#fff; border-radius:10px; padding:0.5rem 0.75rem; font-family:inherit; font-size:0.85rem; color:var(--text); }
        .gs-modal-toolbar .meta-chip { min-height:39px; border-radius:10px; color:var(--text); font-weight:800; }

        .gs-modal-body { flex:1; overflow:auto; padding:1rem 1.5rem; }

        
        .submit-banner { border-radius:12px; padding:0.85rem 1.1rem; display:flex; align-items:center; gap:0.75rem; font-size:0.87rem; font-weight:600; margin-bottom:1rem; }
        .submit-banner.not-submitted { background:#fff8e1; border:1.5px solid #fde68a; color:#92400e; }
        .submit-banner.processing    { background:#eff6ff; border:1.5px solid #bfdbfe; color:#1e40af; }
        .submit-banner.submitted     { background:#d1fae5; border:1.5px solid #6ee7b7; color:#065f46; }
        .submit-banner i { font-size:1.1rem; flex-shrink:0; }

        .attendance-modal { max-width:860px; }
        .attendance-drop { border:1.5px dashed #cbd5e1; border-radius:14px; padding:1rem; background:#f8fafc; display:flex; align-items:center; gap:.85rem; flex-wrap:wrap; }
        .attendance-drop input { flex:1; min-width:240px; font-family:inherit; font-size:.88rem; }
        .attendance-file-card { border:1px solid var(--border); border-radius:12px; padding:.85rem 1rem; background:#fff; margin-top:1rem; display:none; }
        .attendance-file-title { font-weight:800; color:var(--primary); font-size:.94rem; display:flex; align-items:center; gap:.45rem; }
        .attendance-meta-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:.6rem; margin-top:.8rem; }
        .attendance-meta-item { background:#f8fafc; border:1px solid #eef2f7; border-radius:10px; padding:.65rem; }
        .attendance-meta-label { font-size:.72rem; color:var(--muted); text-transform:uppercase; font-weight:800; letter-spacing:.04em; }
        .attendance-meta-value { font-size:.94rem; color:var(--text); font-weight:800; margin-top:.12rem; }
        .attendance-preview { margin-top:1rem; max-height:280px; overflow:auto; border:1px solid var(--border); border-radius:12px; display:none; }
        .attendance-preview table { width:100%; border-collapse:collapse; font-size:.82rem; }
        .attendance-preview th, .attendance-preview td { padding:.55rem .65rem; border-bottom:1px solid var(--border); text-align:left; }
        .attendance-preview th { position:sticky; top:0; background:#f8fafc; color:var(--primary); font-size:.75rem; text-transform:uppercase; }
        .attendance-warning { display:none; margin-top:.85rem; border:1px solid #fde68a; background:#fff8e1; color:#92400e; border-radius:12px; padding:.75rem .9rem; font-size:.84rem; font-weight:600; }

        
        .q-pill { display:inline-flex; align-items:center; gap:4px; padding:3px 10px; border-radius:999px; font-size:0.75rem; font-weight:700; }
        .q-pill.submitted     { background:#d1fae5; color:#065f46; border:1px solid #6ee7b7; }
        .q-pill.not-submitted { background:#fef3c7; color:#92400e; border:1px solid #fde68a; }

        


        .cr-wrap { overflow-x: auto; }
        .cr-table {
            border-collapse: collapse;
            font-size: 8.5pt;
            font-family: Arial, sans-serif;
            min-width: 100%;
            background: #fff;
            table-layout: fixed;
        }
        .cr-table th, .cr-table td {
            border: 1px solid #aab8cc;
        }
        .cr-num {
            width: 36px;
            min-width: 36px;
            max-width: 36px;
            text-align: left;
            font-size: 8pt;
            color: #555;
            padding: 3px 6px;
            border: 1px solid #aab8cc;
        }
        .cr-name-th {
            min-width: 200px;
            padding: 5px 10px;
            font-size: 9.5pt;
            font-weight: 700;
            color: #132f62;
            background: #f0f4ff;
            vertical-align: bottom;
        }
        .cr-name {
            min-width: 200px;
            width: 200px;
            padding: 4px 10px;
            font-size: 9pt;
            text-align: left;
            border: 1px solid #aab8cc;
        }
        .cr-grade {
            width: 72px;
            min-width: 72px;
            max-width: 72px;
            text-align: center;
            padding: 4px 6px;
            font-size: 9pt;
            border: 1px solid #aab8cc;
        }
        .cr-avg {
            width: 72px;
            min-width: 72px;
            max-width: 72px;
            text-align: center;
            font-weight: 700;
            padding: 4px 6px;
            font-size: 9pt;
            border: 1px solid #aab8cc;
        }
        
        
        .cr-subject-th {
            width: 72px;
            min-width: 72px;
            max-width: 72px;
            padding: 8px 6px;
            background: linear-gradient(180deg, #f0f4ff 0%, #e8eef8 100%);
            color: #132f62;
            font-size: 7.5pt;
            font-weight: 700;
            text-align: center;
            vertical-align: bottom;
            line-height: 1.25;
            border: 1px solid #aab8cc;
            word-break: break-word;
            hyphens: auto;
            white-space: normal;
        }
        .cr-subject-th .cr-subject-inner {
            display: block;
            white-space: normal;
            font-size: 7.5pt;
            font-weight: 700;
            color: #132f62;
            line-height: 1.25;
        }
        .cr-header-num {
            text-align: center;
            font-size: 8pt;
            font-weight: 700;
            padding: 3px 6px;
            background: #e8eef8;
            color: #3b5e96;
            border: 1px solid #aab8cc;
        }
        .cr-num-th {
            width: 36px;
            min-width: 36px;
            max-width: 36px;
            text-align: left;
            font-size: 8pt;
            font-weight: 700;
            background: linear-gradient(180deg, #f0f4ff 0%, #e8eef8 100%);
            color: #3b5e96;
            vertical-align: bottom;
            padding: 5px 6px;
            border: 1px solid #aab8cc;
        }
        .cr-name-th {
            min-width: 200px;
            padding: 5px 10px;
            font-size: 9.5pt;
            font-weight: 700;
            color: #132f62;
            background: linear-gradient(180deg, #f0f4ff 0%, #e8eef8 100%);
            vertical-align: bottom;
            border: 1px solid #aab8cc;
        }
        .cr-avg-th {
            width: 72px;
            min-width: 72px;
            max-width: 72px;
            text-align: center;
            font-size: 9pt;
            font-weight: 700;
            background: linear-gradient(180deg, #f0f4ff 0%, #e8eef8 100%);
            color: #132f62;
            vertical-align: bottom;
            padding: 5px 6px;
            border: 1px solid #aab8cc;
        }
        .cr-header-num {
            text-align: center;
            font-size: 8pt;
            font-weight: 700;
            padding: 3px 2px;
            background: #e8eef8;
            color: #3b5e96;
        }
        .cr-num-th {
            width: 32px;
            text-align: center;
            font-size: 8pt;
            font-weight: 700;
            background: #f0f4ff;
            color: #3b5e96;
            vertical-align: bottom;
            padding: 5px 2px;
        }
        .cr-name-th {
            min-width: 200px;
            padding: 5px 10px;
            font-size: 9.5pt;
            font-weight: 700;
            color: #132f62;
            background: #f0f4ff;
            vertical-align: bottom;
        }
        .cr-avg-th {
            width: 72px;
            text-align: center;
            font-size: 9pt;
            font-weight: 700;
            background: #f0f4ff;
            color: #132f62;
            vertical-align: bottom;
            padding: 5px 3px;
        }
        .cr-avg-th {
            width: 72px;
            text-align: center;
            font-size: 9pt;
            font-weight: 700;
            background: #f0f4ff;
            color: #132f62;
            vertical-align: bottom;
            padding: 5px 3px;
        }
        .cr-header-num {
            text-align: center;
            font-size: 8pt;
            font-weight: 700;
            padding: 3px 2px;
            background: #e8eef8;
            color: #3b5e96;
        }
        .cr-row-group {
            background: #d0d8e8;
            font-weight: 700;
            font-size: 8.5pt;
        }
        .cr-row-group td {
            padding: 3px 8px;
            color: #132f62;
            letter-spacing: .04em;
            text-align: left;
        }
        .cr-pass { color: #059669; font-weight: 700; }
        .cr-fail { color: #dc2626; font-weight: 700; }
        .cr-avg-cell { background: #f4f8ff; font-weight: 700; }
        .cr-table td.cr-grade,
        .cr-table td.cr-avg,
        .cr-table th.cr-grade,
        .cr-table th.cr-avg-th,
        .cr-table th.cr-header-num,
        .cr-table th.cr-subject-th {
            text-align: center;
        }
        .cr-empty-row td { background: #fff; }
        .cr-empty-row:nth-child(even) td { background: #fafcff; }
        .cr-num-th {
            width: 32px;
            text-align: center;
            font-size: 8pt;
            font-weight: 700;
            background: #f0f4ff;
            color: #3b5e96;
            vertical-align: bottom;
            padding: 5px 2px;
        }

        .gs-loading { text-align:center; padding:3rem; color:var(--muted); }
        .gs-loading .spinner { display:inline-block; width:32px; height:32px; border:3px solid var(--border); border-top-color:var(--primary); border-radius:50%; animation:spin 0.75s linear infinite; margin-bottom:0.75rem; }
        @keyframes spin { to{transform:rotate(360deg)} }

        
        .gs-toast { position:fixed; bottom:1.5rem; right:1.5rem; z-index:9999; padding:0.85rem 1.2rem; border-radius:14px; font-size:0.88rem; font-weight:600; display:flex; align-items:center; gap:0.6rem; box-shadow:0 8px 32px rgba(0,0,0,0.15); transform:translateY(80px); opacity:0; transition:0.3s ease; pointer-events:none; max-width:380px; }
        .gs-toast.show { transform:translateY(0); opacity:1; }
        .gs-toast.success { background:#065f46; color:#fff; }
        .gs-toast.error   { background:#991b1b; color:#fff; }
        .gs-toast.warning { background:#92400e; color:#fff; }

        @media(max-width:1199px){ .content-grid{ grid-template-columns:1fr; } }
        @media(max-width:991.98px){
            #stsn-toggle{ display:inline-flex; }
            .page-shell, body.sidebar-collapsed .page-shell{ margin-left:0; }
            .page-main{ padding:5rem 1rem 1.5rem; }
            .top-bar { padding: 4.5rem 1rem 1rem; }
            .panel-header{ flex-wrap:wrap; }
        }
        @media(max-width:767px){
            .top-bar-left h1{ font-size:1.05rem; }
            .panel-header input[type="text"] { width: 100%; }
        }
    
        
        .attendance-modern-drop {
            border: 2px dashed #c8daf8;
            border-radius: 16px;
            background: linear-gradient(135deg, #f8fbff 0%, #eef4ff 100%);
            padding: 2.5rem 2rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.25s cubic-bezier(0.22, 1, 0.36, 1);
            position: relative;
            overflow: hidden;
        }
        .attendance-modern-drop::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(26,110,245,0.03) 0%, rgba(18,72,168,0.03) 100%);
            opacity: 0;
            transition: opacity 0.25s ease;
        }
        .attendance-modern-drop:hover {
            border-color: #1a6ef5;
            background: linear-gradient(135deg, #f0f7ff 0%, #e6f0ff 100%);
            transform: translateY(-2px);
            box-shadow: 0 8px 32px rgba(26,110,245,0.12);
        }
        .attendance-modern-drop:hover::before {
            opacity: 1;
        }
        .attendance-modern-drop.drag-over {
            border-color: #1a6ef5;
            background: #eef4ff;
            box-shadow: 0 0 0 4px rgba(26,110,245,0.15);
        }
        .attendance-drop-content {
            position: relative;
            z-index: 1;
        }
        .attendance-drop-icon {
            width: 64px;
            height: 64px;
            background: linear-gradient(135deg, #1a6ef5 0%, #1248a8 100%);
            border-radius: 16px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            margin-bottom: 1rem;
            box-shadow: 0 4px 16px rgba(26,110,245,0.3);
            transition: transform 0.25s cubic-bezier(0.22, 1, 0.36, 1);
        }
        .attendance-modern-drop:hover .attendance-drop-icon {
            transform: scale(1.08) rotate(-4deg);
        }
        .attendance-drop-icon svg {
            width: 28px;
            height: 28px;
        }
        .attendance-drop-title {
            font-size: 1.05rem;
            font-weight: 700;
            color: #132f62;
            margin-bottom: 0.35rem;
        }
        .attendance-drop-sub {
            font-size: 0.88rem;
            color: #7a93b8;
            margin-bottom: 0.5rem;
        }
        .attendance-browse {
            color: #1a6ef5;
            font-weight: 700;
            text-decoration: underline;
            text-underline-offset: 2px;
            cursor: pointer;
        }
        .attendance-drop-hint {
            font-size: 0.78rem;
            color: #a0aec0;
            background: rgba(255,255,255,0.7);
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 999px;
            border: 1px solid #e2ebf8;
        }

        
        .attendance-actions-row {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-top: 1.25rem;
            flex-wrap: wrap;
        }
        .attendance-file-badge {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            background: #fff;
            border: 1.5px solid #e2ebf8;
            border-radius: 12px;
            padding: 0.65rem 1rem;
            flex: 1;
            min-width: 200px;
            transition: all 0.2s ease;
        }
        .attendance-file-badge:hover {
            border-color: #c8daf8;
            box-shadow: 0 2px 8px rgba(18,72,168,0.06);
        }
        .attendance-file-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #065f46;
            font-size: 1.15rem;
            flex-shrink: 0;
        }
        .attendance-file-info {
            flex: 1;
            min-width: 0;
        }
        .attendance-file-name {
            font-size: 0.9rem;
            font-weight: 700;
            color: #132f62;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .attendance-file-meta {
            font-size: 0.78rem;
            color: #9ab0c8;
            margin-top: 0.1rem;
        }
        .attendance-file-remove {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            border: 1.5px solid #fee2e2;
            background: #fef2f2;
            color: #dc2626;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 0.85rem;
            transition: all 0.15s ease;
            flex-shrink: 0;
        }
        .attendance-file-remove:hover {
            background: #fee2e2;
            border-color: #fecaca;
            transform: scale(1.05);
        }
        
        .attendance-import-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: var(--primary);
            color: #fff;
            border: none;
            border-radius: 999px;
            padding: 0.55rem 1.1rem;
            font-family: inherit;
            font-size: 0.82rem;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(10,47,68,0.15);
            transition: all 0.2s ease;
            white-space: nowrap;
        }
        .attendance-import-btn:hover:not(:disabled) {
            background: #0d3b56;
            box-shadow: 0 4px 12px rgba(10,47,68,0.2);
            transform: translateY(-1px);
        }
        .attendance-import-btn:active:not(:disabled) {
            transform: translateY(0);
        }
        .attendance-import-btn:disabled {
            opacity: 0.45;
            cursor: not-allowed;
            box-shadow: none;
        }
        .attendance-import-icon {
            font-size: 0.95rem;
            display: inline-flex;
        }

        
        .attendance-preview {
            margin-top: 1.25rem;
            max-height: 320px;
            overflow: auto;
            border: 1.5px solid #e2ebf8;
            border-radius: 14px;
            display: none;
            background: #fff;
        }
        .attendance-preview table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.82rem;
        }
        .attendance-preview th,
        .attendance-preview td {
            padding: 0.55rem 0.65rem;
            border-bottom: 1px solid #eef2f7;
            text-align: left;
        }
        .attendance-preview th {
            position: sticky;
            top: 0;
            background: #f8fafc;
            color: #132f62;
            font-size: 0.75rem;
            text-transform: uppercase;
            font-weight: 700;
            letter-spacing: 0.04em;
            z-index: 2;
        }
        .attendance-preview tr:hover td {
            background: #f7fbff;
        }

        
        .attendance-warning {
            display: none;
            margin-top: 1rem;
            border: 1.5px solid #fde68a;
            background: linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%);
            color: #92400e;
            border-radius: 12px;
            padding: 0.85rem 1rem;
            font-size: 0.85rem;
            font-weight: 600;
            display: flex;
            align-items: flex-start;
            gap: 0.5rem;
        }
        .attendance-warning::before {
            content: '⚠';
            font-size: 1.1rem;
            flex-shrink: 0;
        }

        
        .attendance-meta-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
            gap: 0.65rem;
            margin-top: 1rem;
        }
        .attendance-meta-item {
            background: linear-gradient(135deg, #f8fbff 0%, #f4f8ff 100%);
            border: 1.5px solid #e2ebf8;
            border-radius: 12px;
            padding: 0.75rem;
            transition: all 0.2s ease;
        }
        .attendance-meta-item:hover {
            border-color: #c8daf8;
            transform: translateY(-1px);
            box-shadow: 0 2px 8px rgba(18,72,168,0.06);
        }
        .attendance-meta-label {
            font-size: 0.72rem;
            color: #7a93b8;
            text-transform: uppercase;
            font-weight: 800;
            letter-spacing: 0.04em;
            margin-bottom: 0.25rem;
        }
        .attendance-meta-value {
            font-size: 1rem;
            color: #132f62;
            font-weight: 800;
        }

    
        
        .btn-pill {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.4rem;
            min-height: 38px;
            background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);
            color: var(--primary);
            border: 1px solid #d8e1ec;
            border-radius: 999px;
            padding: 0.52rem 1rem;
            font-family: inherit;
            font-weight: 800;
            font-size: 0.8rem;
            cursor: pointer;
            text-decoration: none;
            transition: background 0.16s ease, border-color 0.16s ease, color 0.16s ease, box-shadow 0.16s ease, transform 0.12s ease;
            white-space: nowrap;
            box-shadow: 0 1px 2px rgba(15,23,42,0.06), inset 0 1px 0 rgba(255,255,255,0.9);
        }
        .btn-pill:hover {
            background: #fff;
            border-color: #b9c8d8;
            box-shadow: 0 6px 16px rgba(15,23,42,0.10);
            transform: translateY(-1px);
        }
        .btn-pill:active {
            transform: translateY(0);
            box-shadow: 0 1px 4px rgba(15,23,42,0.08);
        }
        .btn-pill-primary {
            background: linear-gradient(135deg, #0A2F44 0%, #0f5f7d 100%);
            border-color: var(--primary);
            color: #fff;
            box-shadow: 0 8px 18px rgba(10,47,68,0.20);
        }
        .btn-pill-primary:hover {
            background: linear-gradient(135deg, #0d3b56 0%, #127394 100%);
            border-color: #0d3b56;
            box-shadow: 0 10px 22px rgba(10,47,68,0.26);
            transform: translateY(-1px);
        }
        .btn-pill-primary:disabled {
            background: #eef2f6;
            border-color: #d8e1ec;
            color: #8a98a8;
            opacity: 1;
            cursor: not-allowed;
            box-shadow: none;
            transform: none;
        }
        .btn-pill-muted {
            background: #f3f6f9;
            color: #7a8797;
            border-color: #dbe3ec;
            box-shadow: none;
        }
        .btn-pill-muted:hover {
            background: #f3f6f9;
            border-color: #dbe3ec;
            box-shadow: none;
            transform: none;
        }

    </style>
    <link rel="stylesheet" href="../css/teacher-alerts.css">
</head>
<body class="stsn-layout">
<button id="stsn-toggle"><i class="bi bi-list"></i></button>
<div id="stsn-overlay"></div>
<?php include __DIR__ . '/../includes/teacher-sidebar.php'; ?>

<div class="page-shell">
    
    <header class="top-bar">
        <div class="top-bar-left">
            <h1><i class="bi bi-people-fill" style="color:var(--accent);"></i> My Advisory</h1>
            <p>View and manage your advisory section and student list.</p>
        </div>
        <div class="top-bar-right">
            <span class="meta-chip"><i class="bi bi-person-badge"></i> <?= htmlspecialchars($teacherName) ?></span>
            <span class="meta-chip"><i class="bi bi-mortarboard"></i> Advisory</span>
            <div class="notif-wrap">
                <button type="button" class="notif-btn" id="notifBellBtn" aria-label="Notifications">
                    <i class="bi bi-bell-fill"></i>
                </button>
                <span class="notif-count" id="notifBellCount">0</span>
                <div class="notif-panel" id="notifPanel">
                    <div class="notif-panel-title">Notifications</div>
                    <div id="notifPanelList">
                        <div class="notif-item"><div class="notif-item-sub">Loading due date...</div></div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <main class="page-main">
        <?php require_once __DIR__ . '/../includes/breadcrumb.php'; renderBreadcrumb([['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'], ['label' => 'Adviser Review', 'href' => 'My-Advisory.php', 'icon' => 'bi bi-person-rolodex'], ['label' => 'My Advisory', 'icon' => 'bi bi-people-fill']], 'teacher'); ?>
        <section class="content-grid">
            
            <div class="panel">
                <div class="panel-header" style="flex-wrap:wrap;gap:.75rem;">
                    <div>
                        <h2 class="panel-title"><i class="bi bi-people-fill"></i> <span id="sectionTitle">Loading...</span></h2>
                        <div class="panel-sub">Student masterlist for the selected advisory section.</div>
                    </div>
                    <div style="display:flex;align-items:center;gap:.55rem;flex-wrap:wrap;margin-left:auto;">
                        <input type="text" id="studentSearch" placeholder="Search student name or LRN">
                        <select id="sectionSelect" class="btn" style="display:inline-flex;"><option value="">Loading sections...</option></select>
                        <select id="genderFilter" class="btn">
                            <option value="">All Genders</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                        <button class="btn" onclick="openAttendanceModal()">
                            <i class="bi bi-calendar-check"></i> Attendance
                        </button>
                        <button class="btn btn-primary" id="viewGradesBtn" onclick="openGradesModal()">
                            <i class="bi bi-table"></i> Grades Summary
                        </button>
                    </div>
                </div>
                <div class="table-wrap">
                    <div id="loadingState" class="loading-state">Loading students...</div>
                    <table class="student-table" id="studentTable" style="display:none;">
                        <thead><tr>
                            <th class="td-center col-lrn">LRN</th>
                            <th class="col-student">Student</th>
                            <th class="td-center col-gender">Gender</th>
                            <th class="td-center col-parent">Parents Contact</th>
                        </tr></thead>
                        <tbody id="studentTableBody"></tbody>
                    </table>
                    <div id="emptyState" class="empty-state" style="display:none;">No students found.</div>
                </div>
            </div>

            <div class="side-stack">
                <div class="panel side-panel">
                    <h3 class="panel-title"><i class="bi bi-info-circle-fill"></i> Section Info</h3>
                    <div class="load-list" style="margin-top:1rem;">
                        <div class="load-item"><div class="load-item-title" id="infoSection">-</div><div class="load-item-sub">Advisory Section</div></div>
                        <div class="load-item"><div class="load-item-title" id="infoStudents">0</div><div class="load-item-sub">Total Students</div></div>
                        <div class="load-item"><div class="load-item-title" id="infoSchoolYear">-</div><div class="load-item-sub">School Year</div></div>
                    </div>
                </div>
                <div class="panel side-panel">
                    <h3 class="panel-title"><i class="bi bi-lightning-charge-fill"></i> Quick Actions</h3>
                    <div class="compact-list">
                        <div class="compact-item" onclick="openGradesModal()">
                            <div class="compact-icon"><i class="bi bi-table"></i></div>
                            <div><div class="compact-title">View &amp; Submit Grades</div><div class="compact-sub">Review all subject grades and submit to admin for report cards.</div></div>
                        </div>
                        <div class="compact-item" onclick="openAttendanceModal()">
                            <div class="compact-icon"><i class="bi bi-calendar-check"></i></div>
                            <div><div class="compact-title">Attendance Input</div><div class="compact-sub">Import the monthly SF2 Excel attendance file for this advisory.</div></div>
                        </div>
                        <div class="compact-item">
                            <div class="compact-icon"><i class="bi bi-envelope"></i></div>
                            <div><div class="compact-title">Contact Parents</div><div class="compact-sub">Reach out to guardians for student concerns.</div></div>
                        </div>
                        <div class="compact-item" onclick="if (currentSectionId) { window.location.href = '../pages/Grading-Sheet.php?section_id=' + encodeURIComponent(currentSectionId); } else { showToast('No advisory section selected.', 'warning'); }">
                            <div class="compact-icon"><i class="bi bi-pencil-square"></i></div>
                            <div><div class="compact-title">Encode Grades</div><div class="compact-sub">Encode grades for advisory subjects.</div></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>


<div class="gs-modal-backdrop" id="gradesModal" onclick="handleBackdropClick(event)">
    <div class="gs-modal">
        <div class="gs-modal-header">
            <div class="gs-modal-title"><i class="bi bi-table"></i> Advisory Class Record</div>
            <div style="display:flex;align-items:center;gap:0.65rem;flex-wrap:wrap;">
                <span id="gsModalMeta" style="font-size:0.82rem;color:var(--muted);"></span>
                <button class="gs-close-btn" onclick="closeGradesModal()"><i class="bi bi-x-lg"></i></button>
            </div>
        </div>

        
        <div class="gs-modal-toolbar">
            <input type="hidden" id="gsQuarterSelect" value="1">
            <div class="meta-chip" id="gsQuarterChip"><i class="bi bi-calendar3"></i> Loading term...</div>

            
            <div id="quarterStatusRow" style="display:flex;gap:0.4rem;flex-wrap:wrap;"></div>

            <div style="margin-left:auto;display:flex;gap:0.5rem;align-items:center;flex-wrap:wrap;">
                <button class="btn-pill" onclick="openAttendanceModal()">
                    <i class="bi bi-calendar-check"></i> Attendance
                </button>
                <button class="btn-pill" onclick="printAdvisoryGrades()">
                    <i class="bi bi-printer"></i> Print
                </button>
                <button class="btn-pill btn-pill-primary" id="submitBtn" onclick="submitGradesToAdmin()">
                    <i class="bi bi-send-check"></i> Submit
                </button>
            </div>
        </div>

        <div class="gs-modal-body">
            
            <div id="submitBanner" style="display:none;"></div>

            
            <div id="gsContent">
                <div class="gs-loading"><div class="spinner"></div><div>Loading class record...</div></div>
            </div>
        </div>
    </div>
</div>


<div class="gs-modal-backdrop" id="attendanceModal" onclick="handleAttendanceBackdropClick(event)">
    <div class="gs-modal attendance-modal">
        <div class="gs-modal-header">
            <div class="gs-modal-title"><i class="bi bi-calendar-check"></i> Attendance Input</div>
            <button class="gs-close-btn" onclick="closeAttendanceModal()"><i class="bi bi-x-lg"></i></button>
        </div>
        <div class="gs-modal-body">
            
            <div class="attendance-modern-drop" id="attendanceDropZone">
                <input type="file" id="attendanceFile" accept=".xlsx,.xls" onchange="handleAttendanceFileChange(event)" hidden>
                <div class="attendance-drop-content" onclick="document.getElementById('attendanceFile').click()">
                    <div class="attendance-drop-icon">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                            <polyline points="17 8 12 3 7 8"/>
                            <line x1="12" y1="3" x2="12" y2="15"/>
                        </svg>
                    </div>
                    <div class="attendance-drop-title">Drop your SF2 attendance file here</div>
                    <div class="attendance-drop-sub">or <span class="attendance-browse">browse</span> to choose a file</div>
                    <div class="attendance-drop-hint">Supports .xlsx, .xls formats</div>
                </div>
            </div>

            <div class="attendance-actions-row" id="attendanceActionsRow" style="display:none;">
                <div class="attendance-file-badge" id="attendanceFileBadge">
                    <div class="attendance-file-icon"><i class="bi bi-file-earmark-excel"></i></div>
                    <div class="attendance-file-info">
                        <div class="attendance-file-name" id="attendanceFileName">Selected file</div>
                        <div class="attendance-file-meta" id="attendanceFileMeta">0 KB · Excel</div>
                    </div>
                    <button class="attendance-file-remove" onclick="clearAttendanceFile()" title="Remove file">
                        <i class="bi bi-x-lg"></i>
                    </button>
                </div>
                <button class="attendance-import-btn" id="importAttendanceBtn" onclick="submitAttendanceImport()" disabled>
                    <span class="attendance-import-icon"><i class="bi bi-cloud-upload-fill"></i></span>
                    <span class="attendance-import-text">Import Attendance</span>
                </button>
            </div>
            <div class="attendance-file-card" id="attendanceFileCard">
                <div class="attendance-file-title"><i class="bi bi-file-earmark-excel"></i><span id="attendanceFileName">Selected file</span></div>
                <div class="attendance-meta-grid">
                    <div class="attendance-meta-item"><div class="attendance-meta-label">Month</div><div class="attendance-meta-value" id="attendanceMonth">-</div></div>
                    <div class="attendance-meta-item"><div class="attendance-meta-label">School Year</div><div class="attendance-meta-value" id="attendanceSchoolYear">-</div></div>
                    <div class="attendance-meta-item"><div class="attendance-meta-label">School Days</div><div class="attendance-meta-value" id="attendanceSchoolDays">0</div></div>
                    <div class="attendance-meta-item"><div class="attendance-meta-label">Matched Learners</div><div class="attendance-meta-value" id="attendanceMatched">0</div></div>
                </div>
            </div>
            <div class="attendance-warning" id="attendanceWarning"></div>
            <div class="attendance-preview" id="attendancePreview"></div>
        </div>
    </div>
</div>


<div class="gs-toast" id="gsToast">
    <i id="gsToastIcon" class="bi bi-check-circle-fill"></i>
    <span id="gsToastMsg"></span>
</div>

<script src="https://cdn.sheetjs.com/xlsx-0.20.1/package/dist/xlsx.full.min.js"></script>
<script src="../js/teacher-alerts.js"></script>
<script src="../js/system-alerts.js"></script>
<script>

let advisoryData     = null;
let currentStudents  = [];
let currentSectionId = null;
let advisoryLoadInProgress = false;
let advisoryAutoRefreshTimer = null;
let quarterStatuses  = {};
let currentSubjects  = [];
let pendingAttendanceImport = null;
let activeQuarterNumber = 1;
let activeQuarterLabel = '1st';
let gradesSheetLoadInProgress = false;
let gradesSheetRefreshQueued = false;
let adviserSubmitInProgress = false;
let lastCanSubmitToAdmin = null;
const adviserRepairAttempts = new Set();

const sectionSelect    = document.getElementById('sectionSelect');
const studentSearch    = document.getElementById('studentSearch');
const genderFilter     = document.getElementById('genderFilter');
const studentTable     = document.getElementById('studentTable');
const studentTableBody = document.getElementById('studentTableBody');
const loadingState     = document.getElementById('loadingState');
const emptyState       = document.getElementById('emptyState');
const notifBellBtn     = document.getElementById('notifBellBtn');
const notifBellCount   = document.getElementById('notifBellCount');
const notifPanel       = document.getElementById('notifPanel');
const notifPanelList   = document.getElementById('notifPanelList');
const LAST_SEEN_KEY    = 'teacher-notif-last-seen-id';
let lastNotifications  = [];
let latestDeadlineInfo = null;

function esc(text) {
    const d = document.createElement('div');
    d.textContent = text ?? '';
    return d.innerHTML;
}


async function loadDeadlineFeed() {
    try {
        const res = await fetch('../api/deadline/get_teacher_deadline_feed.php', { headers:{'Accept':'application/json'} });
        const out = await res.json();
        if (!out.success || !out.data) { renderNotifPanel([]); return; }
        latestDeadlineInfo = out.data;
        const reminders = Array.isArray(out.data.reminders) ? out.data.reminders : [];
        renderNotifPanel(reminders);
    } catch (e) {
        latestDeadlineInfo = null;
        renderNotifPanel([]);
    }
}

function renderNotifPanel(reminders) {
    lastNotifications = reminders;
    const seenId = Number(localStorage.getItem(LAST_SEEN_KEY) || 0);
    const unread = reminders.filter(r => Number(r.id || 0) > seenId);
    const count  = unread.length;
    notifBellCount.style.display = count > 0 ? 'inline-flex' : 'none';
    notifBellCount.textContent   = count > 9 ? '9+' : String(count);

    const dueItems = [];
    if (latestDeadlineInfo?.teacher_deadline_display) {
        const tdl = latestDeadlineInfo.teacher_deadline_days;
        const tdlSuffix = (tdl && tdl.label)
            ? ` <span style="color:${tdl.is_overdue ? '#dc3545' : (tdl.is_today ? '#b96f00' : '#6c757d')};font-weight:600;">(${esc(tdl.label)})</span>`
            : '';
        dueItems.push(`<div class="notif-item"><div class="notif-item-title">Teacher Due Date</div><div class="notif-item-sub">${esc(latestDeadlineInfo.teacher_deadline_display)}${tdlSuffix}</div></div>`);
    }
    if (latestDeadlineInfo?.is_adviser && latestDeadlineInfo?.adviser_deadline_display) {
        const adl = latestDeadlineInfo.adviser_deadline_days;
        const adlSuffix = (adl && adl.label)
            ? ` <span style="color:${adl.is_overdue ? '#dc3545' : (adl.is_today ? '#b96f00' : '#6c757d')};font-weight:600;">(${esc(adl.label)})</span>`
            : '';
        dueItems.push(`<div class="notif-item"><div class="notif-item-title">Adviser Due Date</div><div class="notif-item-sub">${esc(latestDeadlineInfo.adviser_deadline_display)}${adlSuffix}</div></div>`);
    }
    const reminderItems = reminders.map(r => `
        <div class="notif-item${Number(r.id || 0) > seenId ? ' is-unread' : ''}">
            <div class="notif-item-title">${esc(r.title || 'Reminder')}</div>
            <div class="notif-item-sub">${esc(r.message || '')}</div>
            <div class="notif-item-sub">${esc(r.created_at_display || '')}</div>
        </div>`);
    const merged = [...dueItems, ...reminderItems];
    notifPanelList.innerHTML = merged.length
        ? merged.join('')
        : '<div class="notif-item"><div class="notif-item-sub">No active due date.</div></div>';
}


let toastTimer;
function showToast(msg, type = 'success') {
    if (window.TeacherAlerts) {
        TeacherAlerts.toast(msg, type, 4500);
        return;
    }
    clearTimeout(toastTimer);
    const toast   = document.getElementById('gsToast');
    const iconMap = { success:'bi-check-circle-fill', error:'bi-exclamation-circle-fill', warning:'bi-exclamation-triangle-fill' };
    document.getElementById('gsToastMsg').textContent = msg;
    document.getElementById('gsToastIcon').className  = 'bi ' + (iconMap[type] || iconMap.success);
    toast.className = `gs-toast ${type} show`;
    toastTimer = setTimeout(() => toast.classList.remove('show'), 4500);
}


async function loadAdvisory(sectionId = '', background = false) {
    if (advisoryLoadInProgress) return;
    advisoryLoadInProgress = true;

    if (!background) {
        loadingState.style.display = 'block';
        studentTable.style.display = 'none';
        emptyState.style.display   = 'none';
        studentTableBody.innerHTML = '';
    }

    try {
        let url = '../api/advisory/my_advisory.php';
        if (sectionId) url += '?section=' + encodeURIComponent(sectionId);
        const res  = await fetch(url, { headers:{'Accept':'application/json'} });
        const data = await res.json();
        advisoryData = data;
        if (!data.success) {
            if (!background) renderError(data.message || 'Failed to load.');
            return;
        }
        renderPage(data);
    } catch (e) {
        if (!background) renderError('Unable to connect to advisory API.');
    } finally {
        advisoryLoadInProgress = false;
    }
}

function renderPage(data) {
    document.getElementById('infoSchoolYear').textContent = data.academic_year?.label || '-';
    activeQuarterNumber = Number(data.active_quarter?.number || 1);
    activeQuarterLabel = data.active_quarter?.label
        || ['','1st Quarter','2nd Quarter','3rd Quarter','4th Quarter'][activeQuarterNumber]
        || `Term ${activeQuarterNumber}`;
    updateQuarterDisplay();
    renderSections(data.advisories || [], data.selected_section);
    renderSelectedSection(data.selected_section);
    currentStudents  = data.students || [];
    currentSectionId = data.selected_section?.section_id || null;
    filterStudents();
}

function updateQuarterDisplay() {
    const input = document.getElementById('gsQuarterSelect');
    const chip = document.getElementById('gsQuarterChip');
    if (input) input.value = String(activeQuarterNumber);
    if (chip) chip.innerHTML = `<i class="bi bi-calendar3"></i> ${esc(activeQuarterLabel)}`;
}

function renderSections(advisories, selected) {
    sectionSelect.innerHTML = '';
    sectionSelect.disabled = false;
    sectionSelect.style.display = 'inline-flex';
    if (!advisories.length) { sectionSelect.innerHTML = '<option value="">No advisory assigned</option>'; return; }
    advisories.forEach(s => {
        const o = document.createElement('option');
        o.value = s.section_id; o.textContent = s.display_name;
        if (selected && Number(s.section_id) === Number(selected.section_id)) o.selected = true;
        sectionSelect.appendChild(o);
    });
}

function renderSelectedSection(section) {
    if (!section) {
        document.getElementById('sectionTitle').textContent  = 'No advisory assigned';
        document.getElementById('infoSection').textContent   = '-';
        document.getElementById('infoStudents').textContent  = '0';
        return;
    }
    document.getElementById('sectionTitle').textContent  = section.display_name || '-';
    document.getElementById('infoSection').textContent   = section.display_name || '-';
    document.getElementById('infoStudents').textContent  = section.total_students ?? 0;
}

function renderStudents(students) {
    loadingState.style.display = 'none';
    if (!students.length) { studentTable.style.display='none'; emptyState.style.display='block'; return; }
    emptyState.style.display   = 'none';
    studentTable.style.display = 'table';
    studentTableBody.innerHTML = students.map(s => `
        <tr>
            <td class="td-center col-lrn">${esc(s.lrn||'-')}</td>
            <td class="col-student"><div class="student-main">${esc(s.name||'-')}</div></td>
            <td class="td-center col-gender">${esc(s.gender||'-')}</td>
            <td class="td-center col-parent">${esc(s.guardian_contact_num || s.mothers_contact_num || s.fathers_contact_num || '-')}</td>
        </tr>`).join('');
}

function renderError(msg) {
    loadingState.style.display = 'none';
    emptyState.style.display   = 'block';
    emptyState.textContent     = msg;
}

function filterStudents() {
    const q = studentSearch.value.trim().toLowerCase();
    const g = genderFilter.value;
    renderStudents(currentStudents.filter(s =>
        (!q || (s.name||'').toLowerCase().includes(q) || (s.lrn||'').toLowerCase().includes(q)) &&
        (!g || s.gender === g)
    ));
}

studentSearch.addEventListener('input', filterStudents);
genderFilter.addEventListener('change', filterStudents);
sectionSelect.addEventListener('change', function () {
    if (this.value) {
        window.location.href = '?section_id=' + encodeURIComponent(this.value);
    }
});

notifBellBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    notifPanel.classList.toggle('open');
    if (notifPanel.classList.contains('open') && lastNotifications.length) {
        const maxId = Math.max(...lastNotifications.map(r => Number(r.id || 0)));
        localStorage.setItem(LAST_SEEN_KEY, String(maxId));
        renderNotifPanel(lastNotifications);
    }
});
document.addEventListener('click', function (e) {
    if (!notifPanel.contains(e.target) && !notifBellBtn.contains(e.target)) {
        notifPanel.classList.remove('open');
    }
});


function openGradesModal() {
    if (!currentSectionId) { showToast('No advisory section selected.', 'warning'); return; }
    updateQuarterDisplay();
    document.getElementById('gradesModal').classList.add('open');
    document.body.style.overflow = 'hidden';
    loadGradesSheet();
}

function closeGradesModal() {
    document.getElementById('gradesModal').classList.remove('open');
    document.body.style.overflow = '';
}

function handleBackdropClick(e) {
    if (e.target === document.getElementById('gradesModal')) closeGradesModal();
}

document.addEventListener('keydown', e => {
    if (e.key === 'Escape') { closeGradesModal(); closeAttendanceModal(); }
});

function onQuarterChange() { loadGradesSheet(); }


function openAttendanceModal() {
    if (!currentSectionId) { showToast('No advisory section selected.', 'warning'); return; }
    document.getElementById('attendanceModal').classList.add('open');
    document.body.style.overflow = 'hidden';
}

function closeAttendanceModal() {
    document.getElementById('attendanceModal').classList.remove('open');
    document.body.style.overflow = document.getElementById('gradesModal').classList.contains('open') ? 'hidden' : '';
}

function handleAttendanceBackdropClick(e) {
    if (e.target === document.getElementById('attendanceModal')) closeAttendanceModal();
}


function normalizeAttendanceName(value) {
    return String(value || '').toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
}

function sortedAttendanceNameKey(value) {
    return normalizeAttendanceName(value).split(' ').filter(Boolean).sort().join(' ');
}

function buildStudentMatchIndex() {
    const direct = new Map();
    const sorted = new Map();
    currentStudents.forEach(st => {
        [normalizeAttendanceName(st.name), normalizeAttendanceName(st.lrn)]
            .filter(Boolean).forEach(key => direct.set(key, st));
        const sk = sortedAttendanceNameKey(st.name);
        if (sk) sorted.set(sk, st);
    });
    return { direct, sorted };
}

function cellText(row, index) { return String(row?.[index] ?? '').trim(); }

function firstNonEmpty(row, start, end) {
    for (let i = start; i <= end; i++) { const v = cellText(row, i); if (v) return v; }
    return '';
}

function monthNumberFromName(name) {
    const months = {
        january:1,jan:1,february:2,feb:2,march:3,mar:3,april:4,apr:4,
        may:5,june:6,jun:6,july:7,jul:7,august:8,aug:8,
        september:9,sept:9,sep:9,october:10,oct:10,november:11,nov:11,december:12,dec:12
    };
    return months[String(name||'').toLowerCase().replace(/[^a-z]/g,'')] || 0;
}

function formatAttendanceNumber(value) {
    const n = Number(value || 0);
    return Number.isInteger(n) ? String(n) : n.toFixed(1).replace(/\.0$/, '');
}

function parseAttendanceWorkbook(workbook, file) {
    const sheetName = workbook.SheetNames[0];
    const ws   = workbook.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json(ws, { header:1, defval:'', raw:false });
    const flat = rows.map(row => row.map(v => String(v ?? '').trim()));

    let monthName='', schoolYear='', schoolDays=0;

    for (const row of flat) {
        for (let c = 0; c < row.length; c++) {
            const value = row[c], lower = value.toLowerCase();
            if (!monthName && lower.includes('report for the') && lower.includes('month'))
                monthName = firstNonEmpty(row, c+1, Math.min(c+8, row.length-1));
            if (!schoolYear && lower.includes('school year'))
                schoolYear = firstNonEmpty(row, c+1, Math.min(c+5, row.length-1));
            if (!schoolDays && lower.includes('no of school days'))
                schoolDays = Number(firstNonEmpty(row, c+1, Math.min(c+4, row.length-1))) || 0;
        }
    }

    if (!monthName) monthName = sheetName.replace(/\d{4}/g,'').trim();
    const monthNumber = monthNumberFromName(monthName);

    const dateRowIndex = flat.findIndex(row => row.filter(v => /^\d{1,2}$/.test(v)).length >= 5);
    const dateCols = dateRowIndex >= 0
        ? flat[dateRowIndex].map((v,i) => (/^\d{1,2}$/.test(v) ? i : -1)).filter(i => i >= 0)
        : [];
    if (!schoolDays) schoolDays = dateCols.length;

    const totalHeaderRow = flat.find(row => row.some(v => v.toLowerCase()==='absent') && row.some(v => v.toLowerCase()==='present')) || [];
    const absentCol  = totalHeaderRow.findIndex(v => v.toLowerCase()==='absent');
    const presentCol = totalHeaderRow.findIndex(v => v.toLowerCase()==='present');

    const matchIndex = buildStudentMatchIndex();
    const records = [], unmatched = [];
    const startRow = Math.max(0, dateRowIndex + 2);

    for (let r = startRow; r < flat.length; r++) {
        const row = flat[r];
        const rawName = cellText(row, 1), lowerName = rawName.toLowerCase();
        if (!rawName || lowerName.includes('total per day') || lowerName==='male' || lowerName==='female') continue;
        if (!cellText(row, 0) && !rawName) continue;

        let daysAbsent  = Number(cellText(row, absentCol));
        let daysPresent = Number(cellText(row, presentCol));
        if (!Number.isFinite(daysAbsent))  daysAbsent  = 0;
        if (!Number.isFinite(daysPresent)) daysPresent = 0;

        if ((daysAbsent + daysPresent) <= 0 && dateCols.length) {
            daysAbsent = 0; daysPresent = 0;
            dateCols.forEach(c => {
                const mark = cellText(row, c).toLowerCase();
                if (mark==='x'||mark==='a'||mark==='absent') { daysAbsent += 1; }
                else if (mark==='h'||mark==='0.5'||mark==='1/2') { daysAbsent += 0.5; daysPresent += 0.5; }
                else { daysPresent += 1; }
            });
        }

        const key = normalizeAttendanceName(rawName);
        const sk  = sortedAttendanceNameKey(rawName);
        const matched = matchIndex.direct.get(key) || matchIndex.sorted.get(sk) || null;
        records.push({
            row_number: r+1, learner_name: rawName,
            student_id: matched?.id || 0, matched_name: matched?.name || '',
            school_days: schoolDays, days_present: daysPresent, days_absent: daysAbsent
        });
        if (!matched) unmatched.push(rawName);
    }

    return { filename:file.name, filesize:file.size, sheet_name:sheetName, month_name:monthName,
             month_number:monthNumber, school_year:schoolYear, school_days:schoolDays, records, unmatched };
}

async function handleAttendanceFileChange(event) {
    const file = event.target.files?.[0];
    pendingAttendanceImport = null;

    
    document.getElementById('importAttendanceBtn').disabled = true;
    document.getElementById('attendanceActionsRow').style.display = 'none';
    document.getElementById('attendancePreview').style.display  = 'none';
    document.getElementById('attendanceWarning').style.display  = 'none';
    document.getElementById('attendanceFileCard').style.display = 'none';

    if (!file) return;

    try {
        if (typeof XLSX === 'undefined') throw new Error('Excel parser did not load.');
        const buffer   = await file.arrayBuffer();
        const workbook = XLSX.read(buffer, { type:'array', cellFormula:false, cellNF:false });
        const parsed   = parseAttendanceWorkbook(workbook, file);
        pendingAttendanceImport = parsed;
        renderAttendancePreview(parsed);
    } catch (e) {
        showToast(e.message || 'Unable to read attendance file.', 'error');
        
        event.target.value = '';
    }
}

function clearAttendanceFile() {
    pendingAttendanceImport = null;
    document.getElementById('attendanceFile').value = '';
    document.getElementById('attendanceActionsRow').style.display = 'none';
    document.getElementById('attendancePreview').style.display = 'none';
    document.getElementById('attendanceWarning').style.display = 'none';
    document.getElementById('attendanceFileCard').style.display = 'none';
}

function renderAttendancePreview(parsed) {
    const matched = parsed.records.filter(r => r.student_id).length;

    
    document.getElementById('attendanceActionsRow').style.display = 'flex';
    document.getElementById('attendanceFileName').textContent   = parsed.filename;
    document.getElementById('attendanceFileMeta').textContent = `${Math.ceil(parsed.filesize/1024)} KB · Excel · ${parsed.month_name || 'Unknown month'}`;

    
    document.getElementById('attendanceFileCard').style.display = 'block';
    document.getElementById('attendanceMonth').textContent      = parsed.month_name || '-';
    document.getElementById('attendanceSchoolYear').textContent = parsed.school_year || '-';
    document.getElementById('attendanceSchoolDays').textContent = formatAttendanceNumber(parsed.school_days);
    document.getElementById('attendanceMatched').textContent    = `${matched}/${parsed.records.length}`;

    const warning  = document.getElementById('attendanceWarning');
    const warnings = [];
    if (!parsed.month_number) warnings.push('Month could not be detected from the file.');
    if (!parsed.school_year)  warnings.push('School year could not be detected from the file.');
    if (!matched)             warnings.push('No learner names matched the selected advisory section.');
    if (parsed.unmatched.length) warnings.push(`${parsed.unmatched.length} learner(s) were not matched and will be skipped.`);
    warning.textContent    = warnings.join(' ');
    warning.style.display  = warnings.length ? 'flex' : 'none';

    const previewRows = parsed.records.slice(0,12).map(r => `
        <tr>
            <td>${esc(r.learner_name)}</td>
            <td>${r.student_id ? esc(r.matched_name) : '<span style="color:var(--danger);font-weight:700;">Unmatched</span>'}</td>
            <td>${formatAttendanceNumber(r.school_days)}</td>
            <td>${formatAttendanceNumber(r.days_present)}</td>
            <td>${formatAttendanceNumber(r.days_absent)}</td>
        </tr>`).join('');
    document.getElementById('attendancePreview').innerHTML = `
        <table>
            <thead><tr><th>File Learner</th><th>Matched Student</th><th>School Days</th><th>Present</th><th>Absent</th></tr></thead>
            <tbody>${previewRows || '<tr><td colspan="5">No learner rows found.</td></tr>'}</tbody>
        </table>`;
    document.getElementById('attendancePreview').style.display = 'block';
    document.getElementById('importAttendanceBtn').disabled = !(parsed.month_number && parsed.school_year && matched);
}

async function submitAttendanceImport() {
    if (!pendingAttendanceImport || !currentSectionId) return;
    const btn = document.getElementById('importAttendanceBtn');
    btn.disabled  = true;
    btn.innerHTML = `
        <span class="spinner" style="width:16px;height:16px;border:2px solid rgba(255,255,255,0.3);border-top-color:#fff;border-radius:50%;animation:spin 0.75s linear infinite;display:inline-block;vertical-align:middle;margin-right:6px;"></span>
        <span>Importing…</span>
    `;
    try {
        const payload = {
            section_id:  parseInt(currentSectionId),
            filename:    pendingAttendanceImport.filename,
            month_name:  pendingAttendanceImport.month_name,
            month_number:pendingAttendanceImport.month_number,
            school_year: pendingAttendanceImport.school_year,
            school_days: pendingAttendanceImport.school_days,
            records:     pendingAttendanceImport.records
        };
        const res  = await fetch('../api/advisory/import_attendance.php', {
            method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)
        });
        const data = await res.json();
        if (!data.success) {
            showToast(data.message || 'Attendance import failed.', 'error');
        } else {
            showToast(`${data.message} Imported ${data.imported_count} learner(s).`, 'success');
            closeAttendanceModal();
            if (document.getElementById('gradesModal').classList.contains('open')) loadGradesSheet();
        }
    } catch (e) {
        showToast('Network error. Please try again.', 'error');
    } finally {
        btn.innerHTML = `
            <span class="attendance-import-icon"><i class="bi bi-cloud-upload-fill"></i></span>
            <span class="attendance-import-text">Import Attendance</span>
        `;
        btn.disabled  = !pendingAttendanceImport;
    }
}


async function loadGradesSheet(background = false) {
    if (gradesSheetLoadInProgress) {
        gradesSheetRefreshQueued = true;
        return;
    }
    gradesSheetLoadInProgress = true;
    const quarter   = document.getElementById('gsQuarterSelect').value;
    const gsContent = document.getElementById('gsContent');
    if (!background) {
        gsContent.innerHTML = `<div class="gs-loading"><div class="spinner"></div><div>Loading class record...</div></div>`;
    }
    if (!currentSectionId) {
        gradesSheetLoadInProgress = false;
        return;
    }
    try {
        const res  = await fetch(`../api/advisory/get_advisory_grades.php?section_id=${encodeURIComponent(currentSectionId)}&quarter=${encodeURIComponent(quarter)}`);
        const data = await res.json();
        if (!data.success) {
            gsContent.innerHTML = `<div class="gs-loading" style="color:var(--danger);">${esc(data.message||'Failed to load.')}</div>`;
            return;
        }
        document.getElementById('gsModalMeta').textContent =
            `${data.section?.grade_level_name||''} — ${data.section?.section_name||''} · S.Y. ${data.year_label||''} · ${activeQuarterLabel}`;
        currentSubjects = data.subjects || [];
        updateSubmissionUI(data.adviser_submission, data.can_submit_to_admin, data.status_summary);
        if (lastCanSubmitToAdmin === false && data.can_submit_to_admin) {
            showToast('All scheduled subject grades are in. The class record is ready to submit.', 'success');
        }
        lastCanSubmitToAdmin = !!data.can_submit_to_admin;
        renderDepEdClassRecord(data);
        repairPendingAdviserSubmission(data);
    } catch (e) {
        gsContent.innerHTML = `<div class="gs-loading" style="color:var(--danger);">Network error. Please try again.</div>`;
    } finally {
        gradesSheetLoadInProgress = false;
        if (gradesSheetRefreshQueued && document.getElementById('gradesModal').classList.contains('open')) {
            gradesSheetRefreshQueued = false;
            loadGradesSheet(true);
        }
    }
}

function updateSubmissionUI(adviserSubmission, canSubmitToAdmin, statusSummary) {
    const banner     = document.getElementById('submitBanner');
    const btn        = document.getElementById('submitBtn');
    const periodLabel = activeQuarterLabel;
    const isSubmitted = adviserSubmission && adviserSubmission.submitted_at;

    if (isSubmitted) {
        const isPublished = ['approved', 'finalized'].includes(String(adviserSubmission.status || '').toLowerCase());
        banner.style.display = 'flex';
        banner.className     = `submit-banner ${isPublished ? 'submitted' : 'processing'}`;
        banner.innerHTML     = isPublished
            ? `<i class="bi bi-check-circle-fill"></i><span><strong>${esc(periodLabel)}</strong> grades passed approval and are published.</span>`
            : '<i class="bi bi-hourglass-split"></i><span><strong>Processing</strong></span>';
        btn.disabled  = true;
        btn.style.display = 'inline-flex';
        btn.innerHTML = isPublished
            ? '<i class="bi bi-check2-circle"></i> Published'
            : '<i class="bi bi-hourglass-split"></i> Processing';
        btn.className = 'btn-pill btn-pill-primary';
    } else if (!canSubmitToAdmin) {
        banner.style.display = 'flex';
        banner.className     = 'submit-banner processing';
        banner.innerHTML     = '<i class="bi bi-hourglass-split"></i><span><strong>Processing</strong></span>';
        btn.style.display = 'none';
    } else {
        banner.style.display = 'flex';
        banner.className     = 'submit-banner not-submitted';
        banner.innerHTML     = `<i class="bi bi-exclamation-triangle-fill"></i>
            <span><strong>${esc(periodLabel)}</strong> grades are ready. Review the class record, then click Submit.</span>`;
        btn.style.display = 'inline-flex';
        btn.disabled  = false;
        btn.innerHTML = '<i class="bi bi-send-check"></i> Submit';
        btn.className = 'btn-pill btn-pill-primary';
    }
}

async function submitGradesToAdmin() {
    if (adviserSubmitInProgress) return;
    const quarter = parseInt(document.getElementById('gsQuarterSelect').value);
    const btn     = document.getElementById('submitBtn');

    const confirmed = await TeacherAlerts.confirm({
        title: 'Submit grades?',
        message:
            `Submit ${activeQuarterLabel} grades?\n\n` +
            `The class record will remain in Processing until all subject grades complete approval. ` +
            `It will only appear in report cards after approval is complete.\n\n` +
            `Make sure ALL subject teachers have submitted their grades.\n\n` +
            `Are you sure you want to proceed?`,
        confirmText: 'Submit',
        cancelText: 'Cancel'
    });
    if (!confirmed) return;

    adviserSubmitInProgress = true;
    btn.disabled  = true;
    btn.innerHTML = '<span class="spinner" style="width:14px;height:14px;border-width:2px;display:inline-block;vertical-align:middle;margin-right:4px;"></span> Submitting...';
    const banner = document.getElementById('submitBanner');
    banner.style.display = 'flex';
    banner.className = 'submit-banner processing';
    banner.innerHTML = '<i class="bi bi-hourglass-split"></i><span><strong>Processing</strong> — submitting the class record.</span>';

    try {
        const res  = await fetch('../api/advisory/submit_to_admin.php', {
            method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify({ section_id:parseInt(currentSectionId), quarter })
        });
        const data = await res.json();
        if (data.success) {
            showToast(data.message, 'success');
            btn.innerHTML = '<i class="bi bi-hourglass-split"></i> Processing';
            loadGradesSheet();
        } else {
            showToast(data.message || 'Submission failed.', 'error');
            btn.disabled  = false;
            btn.innerHTML = '<i class="bi bi-send-check"></i> Submit';
            updateSubmissionUI(null, true, null);
        }
    } catch (e) {
        showToast('Network error. Please try again.', 'error');
        btn.disabled  = false;
        btn.innerHTML = '<i class="bi bi-send-check"></i> Submit';
        updateSubmissionUI(null, true, null);
    } finally {
        adviserSubmitInProgress = false;
    }
}

async function repairPendingAdviserSubmission(data) {
    const submission = data.adviser_submission;
    if (!submission || String(submission.status || '').toLowerCase() !== 'pending') return;

    const repairKey = `${currentSectionId}:${data.quarter}:${data.year_label}`;
    if (adviserRepairAttempts.has(repairKey)) return;
    adviserRepairAttempts.add(repairKey);

    try {
        const response = await fetch('../api/advisory/submit_to_admin.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                section_id: parseInt(currentSectionId, 10),
                quarter: parseInt(data.quarter, 10),
                repair_existing: true
            })
        });
        const result = await response.json();
        if (!result.success) {
            showToast(result.message || 'Could not verify the pending approval workflow.', 'error');
            return;
        }
        if (result.approval_routing_changed || result.approval_complete) {
            loadGradesSheet(true);
        }
    } catch (error) {
        showToast('Could not verify the pending approval workflow. Please refresh and try again.', 'error');
    }
}


function renderDepEdClassRecord(data) {
    const { subjects, students } = data;
    const gsContent = document.getElementById('gsContent');

    if (!students.length) {
        gsContent.innerHTML = `<div class="gs-loading">No students found in this section.</div>`;
        return;
    }

    const males   = students.filter(s => (s.gender||'').toLowerCase() === 'male');
    const females = students.filter(s => (s.gender||'').toLowerCase() === 'female');
    const others  = students.filter(s => !['male','female'].includes((s.gender||'').toLowerCase()));
    let rowNum = 0;

    const subjectThs = subjects.map(s =>
        `<th class="cr-subject-th"><span class="cr-subject-inner">${esc(s.subject_name)}</span></th>`
    ).join('');

    const colNums = subjects.map((s,i) =>
        `<th class="cr-header-num cr-grade">${i+1}</th>`
    ).join('');

    const thead = `
        <tr>
            <th class="cr-num-th" rowspan="2" style="vertical-align:bottom;">#</th>
            <th class="cr-name-th" rowspan="2" style="vertical-align:bottom;">LEARNERS' NAMES</th>
            ${subjectThs}
            <th class="cr-avg-th" rowspan="2" style="vertical-align:bottom;">AVERAGE</th>
        </tr>
        <tr>${colNums}</tr>`;

    const dataRow = (st) => {
        rowNum++;
        const gradeCells = subjects.map(sub => {
            const g   = Number(st.grades?.[sub.id]?.final_grade || 0);
            const status = st.grades?.[sub.id]?.status || 'No Grades Yet';
            const cls = g >= 75 ? 'cr-pass' : g > 0 ? 'cr-fail' : '';
            return `<td class="cr-grade ${cls}">${g > 0 ? g : `<span style="font-size:7pt;color:#7a93b8;font-weight:700;">${esc(status)}</span>`}</td>`;
        }).join('');
        const avg    = Number(st.general_average ?? 0);
        const avgCls = avg >= 75 ? 'cr-pass' : avg > 0 ? 'cr-fail' : '';
        return `<tr>
            <td class="cr-num">${rowNum}</td>
            <td class="cr-name">${esc(st.full_name)}</td>
            ${gradeCells}
            <td class="cr-avg cr-avg-cell ${avgCls}">${Number.isFinite(avg) && avg > 0 ? avg : ''}</td>
        </tr>`;
    };

    const blankRows = (count, startNum) => Array.from({length:count}, (_,i) =>
        `<tr class="cr-empty-row">
            <td class="cr-num" style="color:#ccc;">${startNum+i}</td>
            <td class="cr-name">&nbsp;</td>
            ${subjects.map(() => '<td class="cr-grade"></td>').join('')}
            <td class="cr-avg cr-avg-cell"></td>
        </tr>`
    ).join('');

    const groupRow = (label) =>
        `<tr class="cr-row-group">
            <td class="cr-num"></td>
            <td colspan="${subjects.length+2}">${label}</td>
        </tr>`;

    const MIN_PER_GROUP = 13;
    let tbody = '';

    if (males.length > 0) {
        tbody += groupRow('MALE');
        males.forEach(st => { tbody += dataRow(st); });
        const fill = Math.max(0, MIN_PER_GROUP - males.length);
        tbody += blankRows(fill, rowNum+1);
        rowNum += fill;
    }
    if (females.length > 0) {
        tbody += groupRow('FEMALE');
        females.forEach(st => { tbody += dataRow(st); });
        const fill = Math.max(0, MIN_PER_GROUP - females.length);
        tbody += blankRows(fill, rowNum+1);
        rowNum += fill;
    }
    others.forEach(st => { tbody += dataRow(st); });

    gsContent.innerHTML = `
    <div class="cr-wrap">
        <table class="cr-table">
            <thead>${thead}</thead>
            <tbody>${tbody}</tbody>
        </table>
    </div>
    <div style="margin-top:0.75rem;font-size:0.82rem;color:var(--muted);">
        <i class="bi bi-info-circle"></i>
        <span style="color:#059669;font-weight:700;">Green</span> = Passed &nbsp;&middot;&nbsp;
        <span style="color:#dc2626;font-weight:700;">Red</span> = Failed &nbsp;&middot;&nbsp;
        Empty = No grade entered yet
    </div>`;
}


function printAdvisoryGrades() {
    const meta    = document.getElementById('gsModalMeta').textContent;
    const content = document.getElementById('gsContent').innerHTML;
    const win     = window.open('', '_blank', 'width=1100,height=800');
    win.document.write(`<!DOCTYPE html><html><head>
        <title>Advisory Class Record</title>
        <style>
            body{font-family:Arial,sans-serif;padding:20px;color:#1E2A3E;}
            h2{font-size:14pt;margin:0 0 4px;}p{font-size:9pt;color:#6C757D;margin:0 0 12px;}
            table{width:100%;border-collapse:collapse;font-size:8.5pt;}
            th,td{border:1px solid #aab8cc;padding:3px 4px;text-align:center;vertical-align:middle;}
            .cr-name{text-align:left;padding-left:8px;font-weight:600;min-width:160px;}
            .cr-num{width:28px;}
            .cr-angled-th{height:120px;width:38px;min-width:38px;position:relative;vertical-align:bottom;padding:0;overflow:visible;background:#f0f4ff;}
            .cr-angled-th .cr-th-inner{display:block;transform-origin:bottom left;transform:rotate(-62deg);white-space:nowrap;font-size:7pt;font-weight:700;padding:2px 4px;position:absolute;bottom:10px;left:12px;color:#132f62;max-width:110px;overflow:hidden;text-overflow:ellipsis;}
            .cr-avg-th{width:60px;text-align:center;font-size:8pt;font-weight:700;background:#f0f4ff;}
            .cr-header-num{text-align:center;font-size:7pt;font-weight:700;padding:2px;background:#e8eef8;color:#3b5e96;}
            .cr-row-group{background:#d0d8e8;font-weight:700;font-size:8pt;}
            .cr-row-group td{padding:3px 8px;color:#132f62;text-align:left;}
            .cr-pass{color:#059669;font-weight:700;}
            .cr-fail{color:#dc2626;font-weight:700;}
            .cr-avg-cell{background:#f4f8ff;font-weight:700;}
            @media print{body{padding:8px;}}
        
        /* ── Modern Attendance Upload ── */
        .attendance-modern-drop {
            border: 2px dashed #c8daf8;
            border-radius: 16px;
            background: linear-gradient(135deg, #f8fbff 0%, #eef4ff 100%);
            padding: 2.5rem 2rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.25s cubic-bezier(0.22, 1, 0.36, 1);
            position: relative;
            overflow: hidden;
        }
        .attendance-modern-drop::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(26,110,245,0.03) 0%, rgba(18,72,168,0.03) 100%);
            opacity: 0;
            transition: opacity 0.25s ease;
        }
        .attendance-modern-drop:hover {
            border-color: #1a6ef5;
            background: linear-gradient(135deg, #f0f7ff 0%, #e6f0ff 100%);
            transform: translateY(-2px);
            box-shadow: 0 8px 32px rgba(26,110,245,0.12);
        }
        .attendance-modern-drop:hover::before {
            opacity: 1;
        }
        .attendance-modern-drop.drag-over {
            border-color: #1a6ef5;
            background: #eef4ff;
            box-shadow: 0 0 0 4px rgba(26,110,245,0.15);
        }
        .attendance-drop-content {
            position: relative;
            z-index: 1;
        }
        .attendance-drop-icon {
            width: 64px;
            height: 64px;
            background: linear-gradient(135deg, #1a6ef5 0%, #1248a8 100%);
            border-radius: 16px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            margin-bottom: 1rem;
            box-shadow: 0 4px 16px rgba(26,110,245,0.3);
            transition: transform 0.25s cubic-bezier(0.22, 1, 0.36, 1);
        }
        .attendance-modern-drop:hover .attendance-drop-icon {
            transform: scale(1.08) rotate(-4deg);
        }
        .attendance-drop-icon svg {
            width: 28px;
            height: 28px;
        }
        .attendance-drop-title {
            font-size: 1.05rem;
            font-weight: 700;
            color: #132f62;
            margin-bottom: 0.35rem;
        }
        .attendance-drop-sub {
            font-size: 0.88rem;
            color: #7a93b8;
            margin-bottom: 0.5rem;
        }
        .attendance-browse {
            color: #1a6ef5;
            font-weight: 700;
            text-decoration: underline;
            text-underline-offset: 2px;
            cursor: pointer;
        }
        .attendance-drop-hint {
            font-size: 0.78rem;
            color: #a0aec0;
            background: rgba(255,255,255,0.7);
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 999px;
            border: 1px solid #e2ebf8;
        }

        /* ── Attendance Actions Row ── */
        .attendance-actions-row {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-top: 1.25rem;
            flex-wrap: wrap;
        }
        .attendance-file-badge {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            background: #fff;
            border: 1.5px solid #e2ebf8;
            border-radius: 12px;
            padding: 0.65rem 1rem;
            flex: 1;
            min-width: 200px;
            transition: all 0.2s ease;
        }
        .attendance-file-badge:hover {
            border-color: #c8daf8;
            box-shadow: 0 2px 8px rgba(18,72,168,0.06);
        }
        .attendance-file-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #065f46;
            font-size: 1.15rem;
            flex-shrink: 0;
        }
        .attendance-file-info {
            flex: 1;
            min-width: 0;
        }
        .attendance-file-name {
            font-size: 0.9rem;
            font-weight: 700;
            color: #132f62;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .attendance-file-meta {
            font-size: 0.78rem;
            color: #9ab0c8;
            margin-top: 0.1rem;
        }
        .attendance-file-remove {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            border: 1.5px solid #fee2e2;
            background: #fef2f2;
            color: #dc2626;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 0.85rem;
            transition: all 0.15s ease;
            flex-shrink: 0;
        }
        .attendance-file-remove:hover {
            background: #fee2e2;
            border-color: #fecaca;
            transform: scale(1.05);
        }
        /* ── Pill Button Style (matching design system) ── */
        .attendance-import-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: var(--primary);
            color: #fff;
            border: none;
            border-radius: 999px;
            padding: 0.55rem 1.1rem;
            font-family: inherit;
            font-size: 0.82rem;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(10,47,68,0.15);
            transition: all 0.2s ease;
            white-space: nowrap;
        }
        .attendance-import-btn:hover:not(:disabled) {
            background: #0d3b56;
            box-shadow: 0 4px 12px rgba(10,47,68,0.2);
            transform: translateY(-1px);
        }
        .attendance-import-btn:active:not(:disabled) {
            transform: translateY(0);
        }
        .attendance-import-btn:disabled {
            opacity: 0.45;
            cursor: not-allowed;
            box-shadow: none;
        }
        .attendance-import-icon {
            font-size: 0.95rem;
            display: inline-flex;
        }

        /* ── Attendance Preview ── */
        .attendance-preview {
            margin-top: 1.25rem;
            max-height: 320px;
            overflow: auto;
            border: 1.5px solid #e2ebf8;
            border-radius: 14px;
            display: none;
            background: #fff;
        }
        .attendance-preview table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.82rem;
        }
        .attendance-preview th,
        .attendance-preview td {
            padding: 0.55rem 0.65rem;
            border-bottom: 1px solid #eef2f7;
            text-align: left;
        }
        .attendance-preview th {
            position: sticky;
            top: 0;
            background: #f8fafc;
            color: #132f62;
            font-size: 0.75rem;
            text-transform: uppercase;
            font-weight: 700;
            letter-spacing: 0.04em;
            z-index: 2;
        }
        .attendance-preview tr:hover td {
            background: #f7fbff;
        }

        /* ── Attendance Warning ── */
        .attendance-warning {
            display: none;
            margin-top: 1rem;
            border: 1.5px solid #fde68a;
            background: linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%);
            color: #92400e;
            border-radius: 12px;
            padding: 0.85rem 1rem;
            font-size: 0.85rem;
            font-weight: 600;
            display: flex;
            align-items: flex-start;
            gap: 0.5rem;
        }
        .attendance-warning::before {
            content: '⚠';
            font-size: 1.1rem;
            flex-shrink: 0;
        }

        /* ── Attendance Meta Cards ── */
        .attendance-meta-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
            gap: 0.65rem;
            margin-top: 1rem;
        }
        .attendance-meta-item {
            background: linear-gradient(135deg, #f8fbff 0%, #f4f8ff 100%);
            border: 1.5px solid #e2ebf8;
            border-radius: 12px;
            padding: 0.75rem;
            transition: all 0.2s ease;
        }
        .attendance-meta-item:hover {
            border-color: #c8daf8;
            transform: translateY(-1px);
            box-shadow: 0 2px 8px rgba(18,72,168,0.06);
        }
        .attendance-meta-label {
            font-size: 0.72rem;
            color: #7a93b8;
            text-transform: uppercase;
            font-weight: 800;
            letter-spacing: 0.04em;
            margin-bottom: 0.25rem;
        }
        .attendance-meta-value {
            font-size: 1rem;
            color: #132f62;
            font-weight: 800;
        }

    
        /* ── Pill Buttons (unified design system) ── */
        .btn-pill {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            background: #fff;
            color: var(--primary);
            border: 1.5px solid var(--border);
            border-radius: 999px;
            padding: 0.5rem 1rem;
            font-family: inherit;
            font-weight: 700;
            font-size: 0.8rem;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.15s ease;
            white-space: nowrap;
        }
        .btn-pill:hover {
            background: var(--surface-2);
            border-color: #c5d1dc;
        }
        .btn-pill-primary {
            background: var(--primary);
            border-color: var(--primary);
            color: #fff;
            box-shadow: 0 2px 8px rgba(10,47,68,0.15);
        }
        .btn-pill-primary:hover {
            background: #0d3b56;
            border-color: #0d3b56;
            box-shadow: 0 4px 12px rgba(10,47,68,0.2);
            transform: translateY(-1px);
        }
        .btn-pill-primary:disabled {
            opacity: 0.45;
            cursor: not-allowed;
            box-shadow: none;
            transform: none;
        }

    </style>
    </head><body>
        <h2>Advisory Class Record</h2><p>${esc(meta)}</p>${content}
    </body></html>`);
    win.document.close(); win.focus();
    setTimeout(() => win.print(), 600);
}


const sidebar     = document.getElementById('stsn-sidebar');
const toggleBtn   = document.getElementById('stsn-toggle');
const overlay     = document.getElementById('stsn-overlay');
const collapseBtn = document.getElementById('stsn-collapse-btn');

const savedState = localStorage.getItem('stsn-sidebar-collapsed');
if (sidebar && savedState === 'true' && window.innerWidth >= 992) {
    sidebar.classList.add('collapsed');
    document.body.classList.add('sidebar-collapsed');
}
collapseBtn?.addEventListener('click', e => {
    e.stopPropagation();
    sidebar.classList.toggle('collapsed');
    const c = sidebar.classList.contains('collapsed');
    document.body.classList.toggle('sidebar-collapsed', c);
    localStorage.setItem('stsn-sidebar-collapsed', c);
});
toggleBtn?.addEventListener('click', () => {
    sidebar.classList.toggle('mobile-open');
    overlay.classList.toggle('visible');
});
overlay?.addEventListener('click', () => {
    sidebar.classList.remove('mobile-open');
    overlay.classList.remove('visible');
});
window.addEventListener('resize', () => {
    if (!sidebar) return;
    if (window.innerWidth >= 992) { sidebar.classList.remove('mobile-open'); overlay.classList.remove('visible'); }
    else document.body.classList.remove('sidebar-collapsed');
});


(function setupAttendanceDragDrop() {
    const dropZone = document.getElementById('attendanceDropZone');
    const fileInput = document.getElementById('attendanceFile');
    if (!dropZone || !fileInput) return;

    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => dropZone.classList.add('drag-over'), false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => dropZone.classList.remove('drag-over'), false);
    });

    dropZone.addEventListener('drop', (e) => {
        const files = e.dataTransfer.files;
        if (files.length) {
            fileInput.files = files;
            handleAttendanceFileChange({ target: { files: files } });
        }
    }, false);
})();


const initialSectionId = new URLSearchParams(window.location.search).get('section_id') || '';
function syncAdvisoryAutoRefresh() {
    if (document.visibilityState === 'visible') {
        if (advisoryAutoRefreshTimer === null) {
            advisoryAutoRefreshTimer = window.setInterval(() => {
                if (!advisoryLoadInProgress && (currentSectionId || initialSectionId)) {
                    loadAdvisory(currentSectionId || initialSectionId, true);
                }
            }, 30000);
        }
    } else if (advisoryAutoRefreshTimer !== null) {
        window.clearInterval(advisoryAutoRefreshTimer);
        advisoryAutoRefreshTimer = null;
    }
}

document.addEventListener('visibilitychange', syncAdvisoryAutoRefresh);
syncAdvisoryAutoRefresh();
loadDeadlineFeed();
loadAdvisory(initialSectionId);
setInterval(() => {
    if (document.visibilityState === 'visible') {
        loadDeadlineFeed();
        if (!adviserSubmitInProgress && document.getElementById('gradesModal').classList.contains('open')) {
            loadGradesSheet(true);
        }
    }
}, 30000);
</script>
</body>
</html>
