<?php
require_once __DIR__ . '/../api/login/teacher_auth.php';

$teacherName = $_SESSION['teacher_name'] ?? 'Teacher';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Advisory | STSN Grading System</title>

    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css/index.css">

    <style>
        :root {
            --primary: #0A2F44;
            --primary-soft: rgba(10, 47, 68, 0.08);
            --accent: #C5A028;
            --bg: #F5F7FA;
            --surface: #FFFFFF;
            --surface-2: #F8F9FA;
            --text: #1E2A3E;
            --muted: #6C757D;
            --border: #E9ECEF;
            --shadow: 0 10px 30px rgba(10, 47, 68, 0.08);
            --radius: 18px;
            --sidebar-width: 260px;
            --sidebar-collapsed-width: 72px;
        }

        * { box-sizing: border-box; }
        html, body { height: 100%; }

        body.stsn-layout {
            margin: 0;
            font-family: "Plus Jakarta Sans", sans-serif;
            background: var(--bg);
            color: var(--text);
            overflow: hidden;
        }

        #stsn-toggle {
            position: fixed;
            top: 1rem;
            left: 1rem;
            z-index: 1100;
            width: 44px;
            height: 44px;
            border: 1px solid var(--border);
            border-radius: 12px;
            background: #fff;
            color: var(--primary);
            display: none;
            align-items: center;
            justify-content: center;
            box-shadow: var(--shadow);
            cursor: pointer;
        }

        #stsn-overlay {
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.35);
            opacity: 0;
            visibility: hidden;
            transition: 0.25s ease;
            z-index: 1035;
        }

        #stsn-overlay.visible {
            opacity: 1;
            visibility: visible;
        }

        .page-shell {
            margin-left: var(--sidebar-width);
            height: 100vh;
            transition: margin-left 0.28s ease;
            display: flex;
            flex-direction: column;
        }

        body.sidebar-collapsed .page-shell {
            margin-left: var(--sidebar-collapsed-width);
        }

        .page-main {
            padding: 1.25rem 1.5rem 1.5rem;
            height: 100%;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .page-title h1 {
            margin: 0;
            font-size: 1.75rem;
            font-weight: 800;
            color: var(--primary);
        }

        .page-title p {
            margin: 0.4rem 0 0;
            color: var(--muted);
            font-size: 0.92rem;
        }

        .header-meta {
            display: flex;
            gap: 0.6rem;
            flex-wrap: wrap;
        }

        .meta-chip {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 999px;
            padding: 0.55rem 0.85rem;
            font-size: 0.8rem;
            color: var(--muted);
            white-space: nowrap;
        }

        .top-controls {
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 0.75rem;
            align-items: center;
        }

        .top-controls select,
        .top-controls input {
            width: 100%;
            border: 1px solid var(--border);
            background: #fff;
            border-radius: 14px;
            padding: 0.8rem 0.95rem;
            font-family: inherit;
            font-size: 0.9rem;
            color: var(--text);
        }

        .workspace-grid {
            flex: 1;
            min-height: 0;
            display: grid;
            grid-template-columns: minmax(0, 1fr) 320px;
            gap: 1rem;
        }

        .panel {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
        }

        .main-panel {
            min-height: 0;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        .panel-header {
            padding: 1rem 1rem 0.9rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .panel-title {
            margin: 0;
            display: flex;
            align-items: center;
            gap: 0.55rem;
            font-size: 1rem;
            font-weight: 700;
            color: var(--primary);
        }

        .panel-title i {
            color: var(--accent);
        }

        .panel-sub {
            font-size: 0.83rem;
            color: var(--muted);
            margin-top: 0.2rem;
        }

        .summary-inline {
            display: flex;
            gap: 0.55rem;
            flex-wrap: wrap;
        }

        .summary-pill {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            padding: 0.45rem 0.7rem;
            border-radius: 999px;
            background: var(--surface-2);
            color: var(--muted);
            font-size: 0.78rem;
            font-weight: 600;
        }

        .table-wrap {
            flex: 1;
            min-height: 0;
            overflow: auto;
            padding: 0 1rem 1rem;
        }

        .student-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 900px;
        }

        .student-table th {
            text-align: left;
            font-size: 0.76rem;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            color: var(--muted);
            padding: 0.95rem 0 0.75rem;
            border-bottom: 1px solid var(--border);
            background: #fff;
            position: sticky;
            top: 0;
            z-index: 2;
        }

        .student-table td {
            padding: 0.9rem 0;
            border-bottom: 1px solid #f0f2f5;
            font-size: 0.89rem;
            vertical-align: middle;
        }

        .student-name {
            font-weight: 700;
            color: var(--text);
        }

        .student-sub {
            display: block;
            font-size: 0.79rem;
            color: var(--muted);
            margin-top: 0.15rem;
        }

        .action-cell {
            white-space: nowrap;
        }

        .view-grade-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            padding: 0.55rem 0.85rem;
            border: 1px solid var(--primary);
            background: var(--primary);
            color: #fff;
            border-radius: 10px;
            font-size: 0.82rem;
            font-weight: 600;
            text-decoration: none;
            transition: 0.2s ease;
        }

        .view-grade-btn:hover {
            background: #0d3b56;
            border-color: #0d3b56;
            color: #fff;
        }

        .side-stack {
            min-height: 0;
            display: grid;
            grid-template-rows: auto auto;
            gap: 1rem;
        }

        .side-panel {
            padding: 1rem;
        }

        .info-grid,
        .alert-list {
            display: grid;
            gap: 0.75rem;
        }

        .info-box,
        .alert-item {
            padding: 0.9rem;
            border-radius: 14px;
            background: var(--surface-2);
        }

        .info-label {
            font-size: 0.77rem;
            color: var(--muted);
            font-weight: 600;
            margin-bottom: 0.25rem;
        }

        .info-value,
        .alert-title {
            font-size: 1rem;
            color: var(--text);
            font-weight: 700;
        }

        .alert-desc {
            font-size: 0.8rem;
            color: var(--muted);
            line-height: 1.45;
            margin-top: 0.35rem;
        }

        .empty-state {
            padding: 1rem 0;
            color: var(--muted);
            font-size: 0.9rem;
        }

        @media (max-width: 1200px) {
            .workspace-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 991.98px) {
            body.stsn-layout {
                overflow: auto;
            }

            #stsn-toggle {
                display: inline-flex;
            }

            .page-shell,
            body.sidebar-collapsed .page-shell {
                margin-left: 0;
                height: auto;
                min-height: 100vh;
            }

            .page-main {
                padding: 5rem 1rem 1rem;
                height: auto;
                overflow: visible;
            }

            .workspace-grid,
            .top-controls {
                grid-template-columns: 1fr;
            }

            .main-panel,
            .table-wrap {
                overflow: visible;
            }
        }
    </style>
</head>
<body class="stsn-layout">
    <button id="stsn-toggle" aria-label="Toggle sidebar">
        <i class="bi bi-list"></i>
    </button>

    <div id="stsn-overlay"></div>

    <?php include __DIR__ . '/../includes/teacher-sidebar.php'; ?>

    <div class="page-shell">
        <main class="page-main">
            <div class="page-header">
                <div class="page-title">
                    <h1>My Advisory</h1>
                    <p>View and manage your advisory section and student list.</p>
                </div>

                <div class="header-meta">
                    <div class="meta-chip"><i class="bi bi-person-badge"></i> <span id="teacherName"><?php echo htmlspecialchars($teacherName); ?></span></div>
                    <div class="meta-chip"><i class="bi bi-mortarboard"></i> <span id="schoolYear">Loading...</span></div>
                </div>
            </div>

            <div class="top-controls">
                <select id="sectionSelect">
                    <option value="">Loading sections...</option>
                </select>

                <input type="text" id="studentSearch" placeholder="Search student name or LRN">
            </div>

            <section class="workspace-grid">
                <div class="panel main-panel">
                    <div class="panel-header">
                        <div>
                            <h2 class="panel-title">
                                <i class="bi bi-people-fill"></i>
                                <span id="sectionTitle">Loading...</span>
                            </h2>
                            <div class="panel-sub">Student masterlist for the selected advisory section.</div>
                        </div>

                        <div class="summary-inline">
                            <span class="summary-pill">
                                <i class="bi bi-people"></i>
                                <span id="studentCount">0</span> Students
                            </span>
                        </div>
                    </div>

                    <div class="table-wrap">
                        <table class="student-table">
                            <thead>
                                <tr>
                                    <th>Student</th>
                                    <th>Gender</th>
                                    <th>LRN</th>
                                    <th>Grade Level</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="studentTableBody">
                                <tr>
                                    <td colspan="5">Loading data...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="side-stack">
                    <div class="panel side-panel">
                        <h3 class="panel-title"><i class="bi bi-info-circle-fill"></i> Section Info</h3>
                        <div class="info-grid" style="margin-top: 1rem;">
                            <div class="info-box">
                                <div class="info-label">Advisory Section</div>
                                <div class="info-value" id="infoSection">-</div>
                            </div>
                            <div class="info-box">
                                <div class="info-label">Total Students</div>
                                <div class="info-value" id="infoStudents">0</div>
                            </div>
                        </div>
                    </div>

                    <div class="panel side-panel">
                        <h3 class="panel-title"><i class="bi bi-person-lines-fill"></i> Students in Section</h3>
                        <div class="alert-list" id="alertList" style="margin-top: 1rem;">
                            <div class="empty-state">No students found.</div>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <script>
        const sectionSelect = document.getElementById('sectionSelect');
        const studentSearch = document.getElementById('studentSearch');
        const studentTableBody = document.getElementById('studentTableBody');
        const alertList = document.getElementById('alertList');

        let advisoryData = null;
        let currentStudents = [];

        async function loadAdvisory(sectionId = '') {
            try {
                let url = '../api/advisory/my_advisory.php';

                if (sectionId) {
                    url += '?section=' + encodeURIComponent(sectionId);
                }

                const response = await fetch(url, {
                    headers: {
                        'Accept': 'application/json'
                    }
                });

                const rawText = await response.text();

                let data;
                try {
                    data = JSON.parse(rawText);
                } catch (e) {
                    console.error('API raw response:', rawText);
                    renderError('API error: ' + rawText);
                    return;
                }

                advisoryData = data;

                if (!response.ok || !data.success) {
                    renderError(data.message || 'Failed to load advisory data.');
                    console.error(data);
                    return;
                }

                renderPage(data);
            } catch (error) {
                console.error(error);
                renderError('Unable to connect to the advisory API.');
            }
        }

        function renderPage(data) {
            document.getElementById('teacherName').textContent = data.teacher?.name || '<?php echo htmlspecialchars($teacherName); ?>';
            document.getElementById('schoolYear').textContent = data.academic_year?.label || '-';

            renderSections(data.advisories || [], data.selected_section);
            renderSelectedSection(data.selected_section);

            currentStudents = data.students || [];
            renderStudents(currentStudents);
            renderAlerts(data.alerts || []);
        }

        function renderSections(advisories, selectedSection) {
            sectionSelect.innerHTML = '';

            if (!advisories.length) {
                sectionSelect.innerHTML = `<option value="">No advisory assigned</option>`;
                return;
            }

            advisories.forEach(section => {
                const option = document.createElement('option');
                option.value = section.section_id;
                option.textContent = section.display_name;

                if (selectedSection && Number(section.section_id) === Number(selectedSection.section_id)) {
                    option.selected = true;
                }

                sectionSelect.appendChild(option);
            });
        }

        function renderSelectedSection(section) {
            if (!section) {
                document.getElementById('sectionTitle').textContent = 'No advisory assigned';
                document.getElementById('studentCount').textContent = '0';
                document.getElementById('infoSection').textContent = '-';
                document.getElementById('infoStudents').textContent = '0';
                return;
            }

            document.getElementById('sectionTitle').textContent = section.display_name || '-';
            document.getElementById('studentCount').textContent = section.total_students ?? 0;
            document.getElementById('infoSection').textContent = section.display_name || '-';
            document.getElementById('infoStudents').textContent = section.total_students ?? 0;
        }

        function renderStudents(students) {
            if (!students.length) {
                studentTableBody.innerHTML = `
                    <tr>
                        <td colspan="5">No students found in this section.</td>
                    </tr>
                `;
                return;
            }

            studentTableBody.innerHTML = students.map(student => `
                <tr>
                    <td>
                        <div class="student-name">${escapeHtml(student.name || '-')}</div>
                        <span class="student-sub">ID: ${escapeHtml(String(student.id ?? '-'))}</span>
                    </td>
                    <td>${escapeHtml(student.gender || '-')}</td>
                    <td>${escapeHtml(student.lrn || '-')}</td>
                    <td>${escapeHtml(student.grade_level_name || '-')}</td>
                    <td class="action-cell">
                        <a class="view-grade-btn" href="StudentGrades.php?student_id=${encodeURIComponent(student.id)}">
                            <i class="bi bi-journal-text"></i>
                            View Grades
                        </a>
                    </td>
                </tr>
            `).join('');
        }

        function renderAlerts(alerts) {
            if (!alerts.length) {
                alertList.innerHTML = `<div class="empty-state">No students found.</div>`;
                return;
            }

            alertList.innerHTML = alerts.map(alert => `
                <div class="alert-item">
                    <div class="alert-title">${escapeHtml(alert.title || '-')}</div>
                    <div class="alert-desc">${escapeHtml(alert.desc || '-')}</div>
                </div>
            `).join('');
        }

        function renderError(message) {
            studentTableBody.innerHTML = `
                <tr>
                    <td colspan="5">${escapeHtml(message)}</td>
                </tr>
            `;
            alertList.innerHTML = `<div class="empty-state">${escapeHtml(message)}</div>`;
        }

        function filterStudents(keyword) {
            const term = keyword.trim().toLowerCase();

            if (!term) {
                renderStudents(currentStudents);
                return;
            }

            const filtered = currentStudents.filter(student => {
                const name = (student.name || '').toLowerCase();
                const lrn = (student.lrn || '').toLowerCase();
                return name.includes(term) || lrn.includes(term);
            });

            renderStudents(filtered);
        }

        function escapeHtml(value) {
            return String(value)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        sectionSelect.addEventListener('change', function () {
            loadAdvisory(this.value);
        });

        studentSearch.addEventListener('input', function () {
            filterStudents(this.value);
        });

        const sidebar = document.getElementById('stsn-sidebar');
        const toggleBtn = document.getElementById('stsn-toggle');
        const overlay = document.getElementById('stsn-overlay');
        const collapseBtn = document.getElementById('stsn-collapse-btn');

        const savedState = localStorage.getItem('stsn-sidebar-collapsed');

        if (sidebar && savedState === 'true' && window.innerWidth >= 992) {
            sidebar.classList.add('collapsed');
            document.body.classList.add('sidebar-collapsed');
        }

        if (collapseBtn && sidebar) {
            collapseBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                sidebar.classList.toggle('collapsed');

                const isCollapsed = sidebar.classList.contains('collapsed');
                document.body.classList.toggle('sidebar-collapsed', isCollapsed);
                localStorage.setItem('stsn-sidebar-collapsed', isCollapsed);
            });
        }

        if (toggleBtn && sidebar) {
            toggleBtn.addEventListener('click', function () {
                sidebar.classList.toggle('mobile-open');
                overlay.classList.toggle('visible');
            });
        }

        if (overlay && sidebar) {
            overlay.addEventListener('click', function () {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('visible');
            });
        }

        window.addEventListener('resize', function () {
            if (!sidebar) return;

            if (window.innerWidth >= 992) {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('visible');
            } else {
                document.body.classList.remove('sidebar-collapsed');
            }
        });

        loadAdvisory();
    </script>
</body>
</html>