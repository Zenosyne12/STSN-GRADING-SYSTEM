<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

require_once __DIR__ . '/api/shared/db_connect.php';

function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$schoolYears = [];
$sections = [];

try {
    $ayStmt = $pdo->query("SELECT id, year_label, is_active FROM tblacademicyear ORDER BY year_label DESC");
    if ($ayStmt)
        $schoolYears = $ayStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    $schoolYears = [];
}

try {
    $secStmt = $pdo->query("
        SELECT s.id, s.section_name, gl.grade_level_name
        FROM tblsection s
        LEFT JOIN tblgradelevel gl ON gl.id = s.grade_level_id
        ORDER BY gl.id ASC, s.section_name ASC
    ");
    if ($secStmt)
        $sections = $secStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    $sections = [];
}

$activeSchoolYear = '';
foreach ($schoolYears as $sy) {
    if ((int) ($sy['is_active'] ?? 0) === 1) {
        $activeSchoolYear = $sy['year_label'];
        break;
    }
}
if ($activeSchoolYear === '' && !empty($schoolYears))
    $activeSchoolYear = $schoolYears[0]['year_label'];

$activeQuarterNumber = 1;
$activeQuarterLabel = '1st';
try {
    $qStmt = $pdo->query("
        SELECT quarter_number, quarter_label
        FROM tblquarters
        WHERE is_active = 1
        LIMIT 1
    ");
    $activeQuarterRow = $qStmt ? $qStmt->fetch(PDO::FETCH_ASSOC) : null;
    if ($activeQuarterRow) {
        $activeQuarterNumber = (int) ($activeQuarterRow['quarter_number'] ?? 1);
        $activeQuarterLabel = (string) ($activeQuarterRow['quarter_label'] ?? $activeQuarterLabel);
    }
} catch (Throwable $e) {
}

$selectedSchoolYear = $activeSchoolYear;
$selectedQuarter = $activeQuarterNumber;
if (!in_array($selectedQuarter, [1, 2, 3, 4], true))
    $selectedQuarter = 1;
$quarterNames = [1 => '1st', 2 => '2nd', 3 => '3rd', 4 => '4th'];
$selectedQuarterName = $activeQuarterLabel ?: ($quarterNames[$selectedQuarter] ?? (string) $selectedQuarter);

/* ── Term-based (trimester) migration: auto-progress + term bar + summary counts ── */
$activeYearId = 0;
foreach ($schoolYears as $sy) {
    if ((int) ($sy['is_active'] ?? 0) === 1) { $activeYearId = (int) $sy['id']; break; }
}
if ($activeYearId === 0 && !empty($schoolYears))
    $activeYearId = (int) $schoolYears[0]['id'];

/* Auto-progress terms (3D): close past terms, activate the term containing today */
$today = date('Y-m-d');
try {
    $pdo->prepare("UPDATE tblconfig_terms
            SET is_closed = 1, is_active = 0
            WHERE academic_year_id = ?
              AND end_date IS NOT NULL AND end_date < ?
              AND is_closed = 0")
        ->execute([$activeYearId, $today]);
    $pdo->prepare("UPDATE tblconfig_terms
            SET is_active = 1
            WHERE academic_year_id = ?
              AND start_date IS NOT NULL AND end_date IS NOT NULL
              AND start_date <= ? AND end_date >= ?
              AND is_closed = 0")
        ->execute([$activeYearId, $today, $today]);
} catch (Throwable $e) {
    // Silent fail — don't break page
    error_log('Term auto-progress error: ' . $e->getMessage());
}

/* Load the terms for the active academic year (3A) */
$terms = [];
try {
    $termsStmt = $pdo->prepare("SELECT id, term_number, term_label, start_date, end_date, is_active, is_closed
            FROM tblconfig_terms
            WHERE academic_year_id = ?
            ORDER BY term_number ASC");
    $termsStmt->execute([$activeYearId]);
    $terms = $termsStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
    $terms = [];
}

/* Auto-detect the current term by today's date; fallback = first non-closed term */
$currentTermNumber = null;
foreach ($terms as $t) {
    if (!empty($t['start_date']) && !empty($t['end_date'])
        && $today >= $t['start_date'] && $today <= $t['end_date']) {
        $currentTermNumber = (int) $t['term_number'];
        break;
    }
}
if ($currentTermNumber === null) {
    foreach ($terms as $t) {
        if (empty($t['is_closed'])) { $currentTermNumber = (int) $t['term_number']; break; }
    }
}
if ($currentTermNumber === null && $terms)
    $currentTermNumber = (int) $terms[0]['term_number'];

$currentTermLabel = (string) $selectedQuarterName;
foreach ($terms as $t) {
    if ((int) $t['term_number'] === (int) $currentTermNumber) {
        $currentTermLabel = (string) $t['term_label'];
        break;
    }
}

/* Keep the page filters/modal on the current term (term numbers replace quarters) */
if ($currentTermNumber !== null)
    $selectedQuarter = $currentTermNumber;

/* Summary card counts for the current term (3C — adapted to the real schema:
   tbldeadlines: quarter + school_year + teacher/adviser/attendance datetimes;
   tbladviser_submissions: quarter + school_year + status) */
$activeDeadlines = 0;
$teachersCompliant = 0;
$advisersPending = 0;
$overdue = 0;
try {
    if ($selectedSchoolYear !== '' && $selectedQuarter > 0) {
        $dStmt = $pdo->prepare("SELECT
                SUM(CASE WHEN GREATEST(COALESCE(teacher_deadline, '1000-01-01'),
                                       COALESCE(adviser_deadline, '1000-01-01'),
                                       COALESCE(attendance_deadline, '1000-01-01')) >= NOW()
                        THEN 1 ELSE 0 END) AS active_count,
                SUM(CASE WHEN GREATEST(COALESCE(teacher_deadline, '1000-01-01'),
                                       COALESCE(adviser_deadline, '1000-01-01'),
                                       COALESCE(attendance_deadline, '1000-01-01')) < NOW()
                        THEN 1 ELSE 0 END) AS overdue_count
            FROM tbldeadlines
            WHERE school_year = ? AND quarter = ?");
        $dStmt->execute([$selectedSchoolYear, $selectedQuarter]);
        $dRow = $dStmt->fetch(PDO::FETCH_ASSOC) ?: [];
        $activeDeadlines = (int) ($dRow['active_count'] ?? 0);
        $overdue         = (int) ($dRow['overdue_count'] ?? 0);

        $sStmt = $pdo->prepare("SELECT
                SUM(CASE WHEN status IN ('approved','finalized') THEN 1 ELSE 0 END) AS compliant_count,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_count
            FROM tbladviser_submissions
            WHERE school_year = ? AND quarter = ?");
        $sStmt->execute([$selectedSchoolYear, $selectedQuarter]);
        $sRow = $sStmt->fetch(PDO::FETCH_ASSOC) ?: [];
        $teachersCompliant = (int) ($sRow['compliant_count'] ?? 0);
        $advisersPending   = (int) ($sRow['pending_count'] ?? 0);
    }
} catch (Throwable $e) {
    error_log('Deadline summary counts error: ' . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deadline Management | STSN Grading System</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        /* ============================================================
           THEME VARIABLES (Light & Dark)
           ============================================================ */
        :root,
        [data-bs-theme="light"] {
            --ay-bg: #f3f7fd;
            --ay-card: #ffffff;
            --ay-card-soft: #fafcff;
            --ay-border: #dce8f8;
            --ay-border-soft: #e8f0fb;
            --ay-text: #213a5e;
            --ay-text-strong: #132f62;
            --ay-text-muted: #7a93b8;
            --ay-text-dim: #9ab0c8;
            --ay-head-bg: #f4f8ff;
            --ay-head-text: #3b5e96;
            --ay-row-hover: #f7fbff;
            --ay-row-border: #f0f5fc;
            --ay-input-bg: #ffffff;
            --ay-input-border: #c8daf8;
            --ay-input-text: #213a5e;
            --ay-section-name: #132f62;

            /* Buttons */
            --ay-btn-outline-bg: #ffffff;
            --ay-btn-outline-text: #1a6ef5;
            --ay-btn-outline-border: #dce8f8;
            --ay-btn-outline-hover-bg: #eef4ff;
            --ay-btn-outline-hover-border: #9cc2fc;

            --ay-btn-ghost-bg: transparent;
            --ay-btn-ghost-text: #1a6ef5;
            --ay-btn-ghost-border: #b8d0fa;
            --ay-btn-ghost-hover-bg: #eef4ff;

            --ay-btn-warning-bg: #fff8e6;
            --ay-btn-warning-text: #8a5c00;
            --ay-btn-warning-border: #f5d98a;
            --ay-btn-warning-hover-bg: #fff0c0;
            --ay-btn-warning-hover-border: #f0c832;

            --ay-btn-danger-bg: #fff0f0;
            --ay-btn-danger-text: #b91c1c;
            --ay-btn-danger-border: #fca5a5;
            --ay-btn-danger-hover-bg: #fee2e2;
            --ay-btn-danger-hover-border: #f87171;

            --ay-btn-success-bg: #eef9f1;
            --ay-btn-success-text: #1a7a3c;
            --ay-btn-success-border: #a3dbb5;
            --ay-btn-success-hover-bg: #d1fae5;
            --ay-btn-success-hover-border: #6ee7b7;

            /* Badges */
            --ay-badge-open-bg: #e6f0ff;
            --ay-badge-open-text: #1248a8;
            --ay-badge-open-border: #b8d0fa;

            --ay-badge-closed-bg: #f3f5f8;
            --ay-badge-closed-text: #7a8ea8;
            --ay-badge-closed-border: #dde4ee;

            --ay-badge-teacher-bg: linear-gradient(130deg, #e8f4ff, #d4e8ff);
            --ay-badge-teacher-text: #1a5fd1;
            --ay-badge-teacher-border: #a8c8f5;

            --ay-badge-adviser-bg: #eef9f1;
            --ay-badge-adviser-text: #1a7a3c;
            --ay-badge-adviser-border: #a3dbb5;

            --ay-badge-submitted-bg: #eef9f1;
            --ay-badge-submitted-text: #1a7a3c;
            --ay-badge-submitted-border: #a3dbb5;

            --ay-badge-unsubmitted-bg: #fff8e6;
            --ay-badge-unsubmitted-text: #8a5c00;
            --ay-badge-unsubmitted-border: #f5d98a;

            /* Stat cards */
            --ay-stat-value: #173454;
            --ay-stat-label: #274d78;
            --ay-stat-note: #a0acb9;
            --ay-stat-border: #dfe4eb;
            --ay-stat-bg: #ffffff;
            --ay-stat-shadow: rgba(20, 50, 90, .03);

            /* Quarter tracker */
            --ay-tracker-bg: #ffffff;
            --ay-tracker-border: #dfe4eb;
            --ay-tracker-title: #34516f;
            --ay-tracker-date: #8a9aae;
            --ay-track-bg: #e2e5e9;
            --ay-track-segment: #e2e5e9;
            --ay-track-segment-divider: #fff;
            --ay-track-active: #3165df;
            --ay-track-label: #8c9db0;
            --ay-track-label-active: #2860d9;
        }

        [data-bs-theme="dark"] {
            --ay-bg: #1a1a1a;
            --ay-card: #2D2D2D;
            --ay-card-soft: #262626;
            --ay-border: #3a3a3a;
            --ay-border-soft: #3a3a3a;
            --ay-text: #e4e6e8;
            --ay-text-strong: #ffffff;
            --ay-text-muted: #adb5bd;
            --ay-text-dim: #8b939a;
            --ay-head-bg: #2D2D2D;
            --ay-head-text: #ffffff;
            --ay-row-hover: #343434;
            --ay-row-border: #3a3a3a;
            --ay-input-bg: #3a3a3a;
            --ay-input-border: #4a5a6e;
            --ay-input-text: #e4e6e8;
            --ay-section-name: #ffffff;

            --ay-btn-outline-bg: #3a3a3a;
            --ay-btn-outline-text: #8ab4f8;
            --ay-btn-outline-border: #4a5a6e;
            --ay-btn-outline-hover-bg: #4a4a4a;
            --ay-btn-outline-hover-border: #6a7a8e;

            --ay-btn-ghost-bg: transparent;
            --ay-btn-ghost-text: #8ab4f8;
            --ay-btn-ghost-border: #4a5a6e;
            --ay-btn-ghost-hover-bg: #3a3a3a;

            --ay-btn-warning-bg: #3a2f14;
            --ay-btn-warning-text: #ffcc66;
            --ay-btn-warning-border: #5c4820;
            --ay-btn-warning-hover-bg: #4a3c18;
            --ay-btn-warning-hover-border: #6e5830;

            --ay-btn-danger-bg: #3a1f24;
            --ay-btn-danger-text: #ff8b9e;
            --ay-btn-danger-border: #5c2d35;
            --ay-btn-danger-hover-bg: #4a262c;
            --ay-btn-danger-hover-border: #6e3640;

            --ay-btn-success-bg: #17351f;
            --ay-btn-success-text: #6ee7a0;
            --ay-btn-success-border: #2b5c38;
            --ay-btn-success-hover-bg: #1e4028;
            --ay-btn-success-hover-border: #3a7048;

            --ay-badge-open-bg: #1e2a3d;
            --ay-badge-open-text: #8ab4f8;
            --ay-badge-open-border: #2d4366;

            --ay-badge-closed-bg: #3a3a3a;
            --ay-badge-closed-text: #a9b8cd;
            --ay-badge-closed-border: #4a5a6e;

            --ay-badge-teacher-bg: #1e2a3d;
            --ay-badge-teacher-text: #8ab4f8;
            --ay-badge-teacher-border: #2d4366;

            --ay-badge-adviser-bg: #17351f;
            --ay-badge-adviser-text: #6ee7a0;
            --ay-badge-adviser-border: #2b5c38;

            --ay-badge-submitted-bg: #17351f;
            --ay-badge-submitted-text: #6ee7a0;
            --ay-badge-submitted-border: #2b5c38;

            --ay-badge-unsubmitted-bg: #3a2f14;
            --ay-badge-unsubmitted-text: #ffcc66;
            --ay-badge-unsubmitted-border: #5c4820;

            --ay-stat-value: #ffffff;
            --ay-stat-label: #cfd8e3;
            --ay-stat-note: #8b939a;
            --ay-stat-border: #3a3a3a;
            --ay-stat-bg: #2D2D2D;
            --ay-stat-shadow: rgba(0, 0, 0, .2);

            --ay-tracker-bg: #2D2D2D;
            --ay-tracker-border: #3a3a3a;
            --ay-tracker-title: #cfd8e3;
            --ay-tracker-date: #8b939a;
            --ay-track-bg: #3a3a3a;
            --ay-track-segment: #3a3a3a;
            --ay-track-segment-divider: #2D2D2D;
            --ay-track-active: #1a6ef5;
            --ay-track-label: #8b939a;
            --ay-track-label-active: #8ab4f8;
        }

        /* ============================================================
           BASE
           ============================================================ */
        body {
            background: var(--ay-bg);
        }

        /* ============================================================
           PAGE HEADER
           ============================================================ */
        .ay-page-header,
        .page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            box-shadow: none;
        }

        .ay-page-header h3,
        .page-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 .2rem;
            letter-spacing: .01em;
        }

        .ay-page-header p,
        .page-header p {
            margin: 0;
            font-size: .88rem;
            opacity: .85;
        }

        .ay-active-chip {
            display: inline-flex;
            align-items: center;
            gap: .45rem;
            background: rgba(255, 255, 255, .15);
            border: 1.5px solid rgba(255, 255, 255, .3);
            border-radius: 999px;
            padding: .45rem 1rem;
            font-size: .88rem;
            font-weight: 700;
            color: #fff;
            white-space: nowrap;
        }

        .btn-ay-white {
            background: rgba(255, 255, 255, .12);
            color: #fff;
            border: 1.5px solid rgba(255, 255, 255, .35);
            padding: .42rem .9rem;
            font-size: .82rem;
            border-radius: 8px;
        }

        .btn-ay-white:hover {
            background: rgba(255, 255, 255, .22);
            color: #fff;
        }

        /* ============================================================
           CARDS
           ============================================================ */
        .ay-card {
            background: var(--ay-card);
            border: 1px solid var(--ay-border);
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18, 72, 168, .06);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }

        .ay-card-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid var(--ay-border-soft);
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: .75rem;
            background: var(--ay-card);
        }

        .ay-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: var(--ay-text-strong);
            margin: 0 0 .15rem;
        }

        .ay-card-subtitle {
            font-size: .8rem;
            color: var(--ay-text-muted);
            margin: 0;
        }

        /* ============================================================
           TABLES
           ============================================================ */
        .ay-table {
            width: 100%;
            border-collapse: collapse;
        }

        .ay-table thead th {
            background: var(--ay-head-bg);
            color: var(--ay-head-text);
            font-size: .75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .06em;
            padding: .85rem 1.2rem;
            border-bottom: 1.5px solid var(--ay-border);
            white-space: nowrap;
        }

        .ay-table tbody tr:not(:last-child) td {
            border-bottom: 1px solid var(--ay-row-border);
        }

        .ay-table tbody tr:hover td {
            background: var(--ay-row-hover);
        }

        .ay-table tbody td {
            padding: .9rem 1.2rem;
            font-size: .93rem;
            color: var(--ay-text);
            vertical-align: middle;
        }

        [data-bs-theme="dark"] .ay-table tbody td {
            color: #ffffff !important;
        }

        .ay-table-sm thead th {
            padding: .65rem 1rem;
            font-size: .72rem;
        }

        .ay-table-sm tbody td {
            padding: .7rem 1rem;
            font-size: .88rem;
        }

        .row-selected td {
            background: var(--ay-row-hover) !important;
        }

        /* ============================================================
           BADGES
           ============================================================ */
        .ay-badge {
            display: inline-flex;
            align-items: center;
            gap: .3rem;
            padding: .32rem .75rem;
            border-radius: 999px;
            font-size: .78rem;
            font-weight: 700;
            letter-spacing: .03em;
        }

        .ay-badge-open {
            background: var(--ay-badge-open-bg);
            color: var(--ay-badge-open-text);
            border: 1.5px solid var(--ay-badge-open-border);
        }

        .ay-badge-closed {
            background: var(--ay-badge-closed-bg);
            color: var(--ay-badge-closed-text);
            border: 1.5px solid var(--ay-badge-closed-border);
        }

        .ay-badge-teacher {
            background: var(--ay-badge-teacher-bg);
            color: var(--ay-badge-teacher-text);
            border: 1.5px solid var(--ay-badge-teacher-border);
        }

        .ay-badge-adviser {
            background: var(--ay-badge-adviser-bg);
            color: var(--ay-badge-adviser-text);
            border: 1.5px solid var(--ay-badge-adviser-border);
        }

        .ay-badge-submitted {
            background: var(--ay-badge-submitted-bg);
            color: var(--ay-badge-submitted-text);
            border: 1.5px solid var(--ay-badge-submitted-border);
        }

        .ay-badge-unsubmitted {
            background: var(--ay-badge-unsubmitted-bg);
            color: var(--ay-badge-unsubmitted-text);
            border: 1.5px solid var(--ay-badge-unsubmitted-border);
        }

        /* ============================================================
           BUTTONS
           ============================================================ */
        .btn-ay {
            font-weight: 600;
            font-size: .82rem;
            border-radius: 8px;
            padding: .42rem .9rem;
            cursor: pointer;
            transition: all .14s;
            border: 1.5px solid transparent;
            line-height: 1.4;
            display: inline-flex;
            align-items: center;
            gap: .3rem;
        }

        .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            box-shadow: 0 2px 8px rgba(26, 110, 245, .2);
        }

        .btn-ay-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
        }

        .btn-ay-outline {
            background: var(--ay-btn-outline-bg);
            color: var(--ay-btn-outline-text);
            border-color: var(--ay-btn-outline-border);
        }

        .btn-ay-outline:hover {
            background: var(--ay-btn-outline-hover-bg);
            border-color: var(--ay-btn-outline-hover-border);
            color: var(--ay-btn-outline-text);
        }

        .btn-ay-ghost {
            background: var(--ay-btn-ghost-bg);
            color: var(--ay-btn-ghost-text);
            border-color: var(--ay-btn-ghost-border);
        }

        .btn-ay-ghost:hover {
            background: var(--ay-btn-ghost-hover-bg);
            color: var(--ay-btn-ghost-text);
        }

        .btn-ay-warning {
            background: var(--ay-btn-warning-bg);
            color: var(--ay-btn-warning-text);
            border-color: var(--ay-btn-warning-border);
        }

        .btn-ay-warning:hover {
            background: var(--ay-btn-warning-hover-bg);
            border-color: var(--ay-btn-warning-hover-border);
            color: var(--ay-btn-warning-text);
        }

        .btn-ay-danger {
            background: var(--ay-btn-danger-bg);
            color: var(--ay-btn-danger-text);
            border-color: var(--ay-btn-danger-border);
        }

        .btn-ay-danger:hover {
            background: var(--ay-btn-danger-hover-bg);
            border-color: var(--ay-btn-danger-hover-border);
            color: var(--ay-btn-danger-text);
        }

        .btn-ay-success {
            background: var(--ay-btn-success-bg);
            color: var(--ay-btn-success-text);
            border-color: var(--ay-btn-success-border);
        }

        .btn-ay-success:hover {
            background: var(--ay-btn-success-hover-bg);
            border-color: var(--ay-btn-success-hover-border);
            color: var(--ay-btn-success-text);
        }

        .btn-ay-sm {
            padding: .28rem .65rem;
            font-size: .78rem;
        }

        /* ============================================================
           MODAL BASE
           ============================================================ */
        #lockedEntriesModal .modal-content,
        #deadlineModal .modal-content {
            border-radius: 14px;
            border: none;
            overflow: hidden;
            background: var(--ay-card);
        }

        /* ------------------------------------------------------------
           BULLETPROOF BLUE GRADIENT HEADERS (both modals)
           Uses ::before pseudo-element so external themes can't strip it
           ------------------------------------------------------------ */

        /* ---- Locked Entries Modal Header ---- */
        #lockedEntriesModal .modal-header {
            position: relative;
            z-index: 0;
            color: #fff !important;
            border-bottom: 0 !important;
            background-color: #0b3d91 !important;
            overflow: hidden;
            border-top-left-radius: 14px;
            border-top-right-radius: 14px;
        }
        #lockedEntriesModal .modal-header::before {
            content: "";
            position: absolute;
            inset: 0;
            z-index: -1;
            background: linear-gradient(135deg, #0b3d91 0%, #1457b8 52%, #1d75e8 100%);
            pointer-events: none;
        }
        #lockedEntriesModal .modal-header > * {
            position: relative;
            z-index: 1;
        }
        #lockedEntriesModal .modal-title,
        #lockedEntriesModal .modal-header i {
            color: #fff !important;
        }
        #lockedEntriesModal .modal-header .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%) !important;
            opacity: 1 !important;
            background-color: transparent;
            border-radius: 50%;
        }

        /* ---- Set Deadline Modal Header ---- */
        #deadlineModal .modal-header {
            position: relative;
            z-index: 0;
            color: #fff !important;
            border-bottom: 0 !important;
            background-color: #0b3d91 !important;
            overflow: hidden;
            border-top-left-radius: 14px;
            border-top-right-radius: 14px;
        }
        #deadlineModal .modal-header::before {
            content: "";
            position: absolute;
            inset: 0;
            z-index: -1;
            background: linear-gradient(135deg, #0b3d91 0%, #1457b8 52%, #1d75e8 100%);
            pointer-events: none;
        }
        #deadlineModal .modal-header > * {
            position: relative;
            z-index: 1;
        }
        #deadlineModal .modal-title,
        #deadlineModal .modal-header i {
            color: #fff !important;
        }
        #deadlineModal .modal-header .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%) !important;
            opacity: 1 !important;
            background-color: transparent;
            border-radius: 50%;
        }

        /* ---- Modal bodies & footers ---- */
        #lockedEntriesModal .modal-body,
        #deadlineModal .modal-body {
            background: var(--ay-card);
            color: var(--ay-text);
        }

        #lockedEntriesModal .modal-footer,
        #deadlineModal .modal-footer {
            background: var(--ay-card-soft);
            border-top: 1px solid var(--ay-border);
        }

        #lockedEntriesModal .btn-ay-outline {
            background: var(--ay-btn-outline-bg);
            color: var(--ay-btn-outline-text);
            border-color: var(--ay-btn-outline-border);
        }

        #lockedEntriesModal .btn-ay-outline:hover {
            background: var(--ay-btn-outline-hover-bg);
            color: var(--ay-btn-outline-text);
        }

        #deadlineModal .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            box-shadow: 0 2px 8px rgba(26, 110, 245, .2);
        }

        #deadlineModal .btn-ay-outline {
            background: var(--ay-btn-outline-bg);
            color: var(--ay-btn-outline-text);
            border-color: var(--ay-btn-outline-border);
        }

        /* ============================================================
           SECTION LIST & FORM CONTROLS
           ============================================================ */
        .section-list {
            max-height: 220px;
            overflow-y: auto;
            border: 1.5px solid var(--ay-input-border);
            border-radius: 10px;
            padding: .75rem;
            background: var(--ay-card);
        }

        .section-list .form-check-label {
            font-size: .88rem;
            color: var(--ay-text);
        }

        .compliance-panel {
            padding: 1.2rem;
        }

        .compliance-panel h6 {
            font-size: .88rem;
            font-weight: 700;
            color: var(--ay-text-strong);
            margin-bottom: .9rem;
        }

        .locked-item {
            background: var(--ay-card);
            border: 1.5px solid var(--ay-border);
            border-radius: 12px;
            padding: .9rem 1rem;
            margin-bottom: .6rem;
        }

        .locked-item:last-child {
            margin-bottom: 0;
        }

        .modal.fade .modal-dialog {
            transform: translateY(18px) scale(.985);
            opacity: 0;
            transition: transform .24s cubic-bezier(.22, 1, .36, 1), opacity .24s ease-out;
        }

        .modal.show .modal-dialog {
            transform: translateY(0) scale(1);
            opacity: 1;
        }

        .modal-backdrop.fade {
            transition: opacity .24s ease-in-out;
        }

        .ay-modal .modal-content {
            border: 0;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(18, 72, 168, .16);
            background: var(--ay-card);
        }

        .ay-modal .modal-header {
            background: var(--ay-head-bg);
            border-bottom: 1px solid var(--ay-border);
            border-radius: 16px 16px 0 0;
            padding: 1rem 1.3rem;
        }

        .ay-modal .modal-title {
            font-size: 1rem;
            font-weight: 700;
            color: var(--ay-text-strong);
        }

        .ay-modal .modal-body {
            padding: 1.3rem;
            background: var(--ay-card);
        }

        .ay-modal .modal-footer {
            border-top: 1px solid var(--ay-border-soft);
            padding: .9rem 1.3rem;
            background: var(--ay-card-soft);
            border-radius: 0 0 16px 16px;
        }

        .ay-modal .form-label {
            font-size: .85rem;
            font-weight: 700;
            color: var(--ay-text-muted);
            margin-bottom: .4rem;
        }

        [data-bs-theme="dark"] .ay-modal .form-label {
            color: #ffffff;
        }

        .ay-modal .form-control,
        .ay-modal .form-select {
            border-radius: 10px;
            border: 1.5px solid var(--ay-input-border);
            min-height: 42px;
            font-size: .9rem;
            color: var(--ay-input-text);
            padding: .45rem .85rem;
            background: var(--ay-input-bg);
        }

        .ay-modal .form-control:focus,
        .ay-modal .form-select:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, .12);
        }

        [data-bs-theme="dark"] .ay-modal .form-control,
        [data-bs-theme="dark"] .ay-modal .form-select {
            background: #3a3a3a;
            color: #e4e6e8;
            border-color: #4a5a6e;
        }

        [data-bs-theme="dark"] .ay-modal .form-select option {
            background: #2D2D2D;
            color: #e4e6e8;
        }

        [data-bs-theme="dark"] .ay-modal .form-control::placeholder {
            color: #adb5bd;
        }

        .meta-chip {
            display: inline-flex;
            align-items: center;
            gap: .45rem;
            min-height: 42px;
            border: 1.5px solid var(--ay-input-border);
            border-radius: 10px;
            padding: .48rem .85rem;
            background: var(--ay-input-bg);
            color: var(--ay-input-text);
            font-size: .9rem;
            font-weight: 700;
        }

        .meta-chip i {
            color: #1a6ef5;
        }

        [data-bs-theme="dark"] .meta-chip {
            background: #3a3a3a;
            color: #e4e6e8;
            border-color: #4a5a6e;
        }

        /* ============================================================
           EMPTY STATES
           ============================================================ */
        .ay-empty {
            text-align: center;
            padding: 2rem 1.5rem;
            color: var(--ay-text-dim);
        }

        .ay-empty i {
            font-size: 2rem;
            display: block;
            margin-bottom: .5rem;
            opacity: .5;
        }

        .ay-empty p {
            margin: 0;
            font-size: .92rem;
        }

        /* ============================================================
           ALERT CONTAINER
           ============================================================ */
        #alertContainer .alert {
            border-radius: 12px;
            border: 1.5px solid;
            font-size: .88rem;
            font-weight: 500;
        }

        #alertContainer:empty {
            display: none;
        }

        /* ============================================================
           COMPLIANCE TRACKER TABS
           ============================================================ */
        .nav-tabs .nav-link {
            color: var(--ay-head-text);
            font-weight: 600;
            border: none;
            border-bottom: 3px solid transparent;
            padding: .75rem 1.5rem;
            font-size: .9rem;
            background: transparent;
        }

        .nav-tabs .nav-link.active {
            color: var(--ay-text-strong);
            background: transparent;
            border-bottom-color: #1a6ef5;
        }

        .nav-tabs .nav-link:hover {
            border-bottom-color: var(--ay-border);
            color: var(--ay-text-strong);
        }

        .nav-tabs {
            border-bottom: 1px solid var(--ay-border);
            padding: 0 1.4rem;
            background: var(--ay-card-soft);
        }

        [data-bs-theme="dark"] .nav-tabs .nav-link.active {
            color: #8ab4f8;
        }

        .tab-content {
            padding: 0;
        }

        .tab-pane {
            padding: 0;
        }

        .tab-pane .table-responsive {
            margin: 0;
        }

        /* ============================================================
           DEADLINE OVERVIEW
           ============================================================ */
        .deadline-overview {
            margin: .75rem 0 1rem;
        }

        .quarter-tracker {
            background: var(--ay-tracker-bg);
            border: 1px solid var(--ay-tracker-border);
            border-radius: 9px;
            padding: .72rem .95rem .62rem;
            box-shadow: 0 1px 4px var(--ay-stat-shadow);
        }

        .quarter-tracker-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            margin-bottom: .45rem;
        }

        .quarter-tracker-title {
            margin: 0;
            color: var(--ay-tracker-title);
            font-size: .68rem;
            font-weight: 600;
            letter-spacing: .1em;
            text-transform: uppercase;
        }

        .quarter-tracker-date {
            color: var(--ay-tracker-date);
            font-size: .67rem;
            white-space: nowrap;
        }

        .quarter-track {
            position: relative;
            height: 9px;
            border-radius: 999px;
            background: var(--ay-track-bg);
            overflow: hidden;
        }

        .quarter-segments {
            display: flex;
            height: 100%;
            width: 100%;
        }

        .quarter-segment {
            flex: 1;
            height: 100%;
            background: var(--ay-track-segment);
            border-right: 2px solid var(--ay-track-segment-divider);
        }

        .quarter-segment:last-child {
            border-right: 0;
        }

        .quarter-segment.active {
            background: var(--ay-track-active);
        }

        .quarter-labels {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            margin-top: .42rem;
            text-align: center;
        }

        .quarter-label {
            color: var(--ay-track-label);
            font-size: .58rem;
            line-height: 1;
        }

        .quarter-label.active {
            color: var(--ay-track-label-active);
            font-weight: 700;
        }

        .deadline-summary-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: .8rem;
            margin-top: .8rem;
        }

        .deadline-stat-card {
            position: relative;
            min-height: 108px;
            background: var(--ay-stat-bg);
            border: 1px solid var(--ay-stat-border);
            border-radius: 9px;
            padding: .9rem 1rem .85rem 1.15rem;
            overflow: hidden;
            box-shadow: 0 1px 4px var(--ay-stat-shadow);
        }

        .deadline-stat-card::before {
            content: "";
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 3px;
        }

        .deadline-stat-card.blue::before { background: #2867e8; }
        .deadline-stat-card.green::before { background: #16a45a; }
        .deadline-stat-card.orange::before { background: #f3a500; }
        .deadline-stat-card.red::before { background: #ff3345; }

        .deadline-stat-value {
            color: var(--ay-stat-value);
            font-size: 2rem;
            line-height: 1;
            font-weight: 700;
            margin-bottom: .35rem;
        }

        .deadline-stat-label {
            color: var(--ay-stat-label);
            font-size: .82rem;
            line-height: 1.25;
            font-weight: 600;
        }

        .deadline-stat-note {
            color: var(--ay-stat-note);
            font-size: .7rem;
            line-height: 1.25;
            margin-top: .22rem;
        }

        /* ============================================================
           RESPONSIVE
           ============================================================ */
        @media (max-width: 767.98px) {
            .ay-page-header,
            .page-header {
                padding: 1.1rem 1.2rem;
                border-radius: 14px;
            }

            .deadline-summary-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .quarter-tracker-top {
                align-items: flex-start;
                flex-direction: column;
                gap: .2rem;
            }
        }

        @media (max-width: 480px) {
            .deadline-summary-grid {
                grid-template-columns: 1fr;
            }
        }
    /* ============================================================
   Term Bar (trimester) — replaces the 4-quarter tracker
   ============================================================ */
.term-bar {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(0, 1fr));
    gap: 0.5rem;
    padding: 0.75rem 1rem;
    background: #f8fafc;
    border-radius: 10px;
    border: 1px solid #e2e8f0;
    margin-bottom: 1rem;
}
.term-cell {
    text-align: center;
    padding: 0.55rem 0.5rem;
    background: #ffffff;
    border: 1.5px solid #e2e8f0;
    border-radius: 8px;
    font-size: 0.85rem;
    font-weight: 600;
    color: #94a3b8;
    transition: all 0.15s ease;
    position: relative;
}
.term-cell.past {
    background: #f1f5f9;
    color: #64748b;
    border-color: #cbd5e1;
}
.term-cell.active {
    background: linear-gradient(135deg, #1248a8 0%, #1a6ef5 100%);
    color: #ffffff;
    border-color: #1248a8;
    box-shadow: 0 4px 12px rgba(18, 72, 168, 0.25);
}
.term-cell.closed {
    opacity: 0.6;
}
.term-cell .term-tag {
    display: block;
    font-size: 0.65rem;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    opacity: 0.85;
    margin-top: 2px;
}
</style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <div class="app-wrapper">
        <?php require_once("includes/header.php"); ?>
        <?php require_once("includes/sidebar.php"); ?>

        <main class="app-main">
            <div class="app-content">
                <div class="container-fluid py-3">

                    <div id="alertContainer" class="mb-3"></div>

                    <input type="hidden" id="filterSchoolYear" value="<?= e($selectedSchoolYear) ?>">
                    <input type="hidden" id="filterQuarter" value="<?= (int) $selectedQuarter ?>">

                    <div class="page-header">
                        <div>
                            <h3><i class="bi bi-hourglass-split me-2"></i>Deadline Management</h3>
                            <p>Set submission schedules and monitor closing compliance.</p>
                        </div>
                        <div class="page-header-actions">
                            <button type="button" class="btn btn-ay btn-ay-white" id="btnOpenCreate">
                                <i class="bi bi-plus-circle"></i> Set Deadline
                            </button>
                            <button type="button" class="btn btn-ay btn-ay-white" id="btnViewLocks">
                                <i class="bi bi-shield-lock"></i> Locked Entries
                            </button>
                        </div>
                    </div>

                    <?php require_once __DIR__ . '/includes/breadcrumb.php';
                    renderBreadcrumb([['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'], ['label' => 'Deadline Management', 'href' => 'Deadline.php', 'icon' => 'bi bi-hourglass-split'], ['label' => 'Deadline', 'icon' => 'bi bi-hourglass-split']]); ?>

                    <div class="deadline-overview">
                        <div class="quarter-tracker">
                            <div class="quarter-tracker-top">
                                <p class="quarter-tracker-title">Academic Year <?= e($selectedSchoolYear ?: '—') ?> · Term Deadline Window</p>
                                <span class="quarter-tracker-date"><?php
                                    $currentTermRow = null;
                                    foreach ($terms as $t) {
                                        if ((int) $t['term_number'] === (int) $currentTermNumber) { $currentTermRow = $t; break; }
                                    }
                                    echo $currentTermRow
                                        ? e(($currentTermRow['term_label'] ?: ('Term ' . $currentTermNumber)) . ' — ' . ($currentTermRow['start_date'] ?: '?') . ' to ' . ($currentTermRow['end_date'] ?: '?'))
                                        : 'No terms configured';
                                ?></span>
                            </div>

                            <div class="term-bar">
                                <?php foreach ($terms as $t):
                                    $tn        = (int) $t['term_number'];
                                    $isCurrent = ($tn === (int) $currentTermNumber);
                                    $isPast    = ($currentTermNumber !== null && $tn < $currentTermNumber);
                                    $cls = 'term-cell';
                                    if ($isCurrent) $cls .= ' active';
                                    if ($isPast)    $cls .= ' past';
                                    if (!empty($t['is_closed'])) $cls .= ' closed';
                                ?>
                                    <div class="<?= $cls ?>">
                                        <span class="term-num"><?= e($t['term_label'] ?: ('Term ' . $tn)) ?></span>
                                        <?php if ($isCurrent): ?><span class="term-tag">Current</span><?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <div class="deadline-summary-grid">
                            <div class="deadline-stat-card blue">
                                <div class="deadline-stat-value"><?= (int) $activeDeadlines ?></div>
                                <div class="deadline-stat-label">Active Deadlines</div>
                                <div class="deadline-stat-note"><?= $activeDeadlines > 0 ? e($currentTermLabel . ' · ' . $selectedSchoolYear) : 'No records yet' ?></div>
                            </div>
                            <div class="deadline-stat-card green">
                                <div class="deadline-stat-value"><?= (int) $teachersCompliant ?></div>
                                <div class="deadline-stat-label">Teachers Compliant</div>
                                <div class="deadline-stat-note"><?= $teachersCompliant > 0 ? e($currentTermLabel . ' · ' . $selectedSchoolYear) : 'No records yet' ?></div>
                            </div>
                            <div class="deadline-stat-card orange">
                                <div class="deadline-stat-value"><?= (int) $advisersPending ?></div>
                                <div class="deadline-stat-label">Advisers Pending</div>
                                <div class="deadline-stat-note"><?= $advisersPending > 0 ? e($currentTermLabel . ' · ' . $selectedSchoolYear) : 'No records yet' ?></div>
                            </div>
                            <div class="deadline-stat-card red">
                                <div class="deadline-stat-value"><?= (int) $overdue ?></div>
                                <div class="deadline-stat-label">Overdue</div>
                                <div class="deadline-stat-note"><?= $overdue > 0 ? e($currentTermLabel . ' · ' . $selectedSchoolYear) : 'No records yet' ?></div>
                            </div>
                        </div>
                    </div>

                    <div class="ay-card">
                        <div class="ay-card-header">
                            <div>
                                <p class="ay-card-title">Deadline List</p>
                                <p class="ay-card-subtitle">All configured deadlines for the selected school year and
                                    quarter.</p>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="ay-table">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Due Date</th>
                                        <th style="text-align:center;">Type</th>
                                        <th>Applicable To</th>
                                        <th style="text-align:center;">Compliance</th>
                                        <th style="text-align:center;">Status</th>
                                        <th style="text-align:center; width:300px;">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="deadlineTableBody">
                                    <tr>
                                        <td colspan="7">
                                            <div class="ay-empty"><i class="bi bi-hourglass"></i>
                                                <p>Loading deadlines…</p>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- ===== NEW COMPLIANCE TRACKER CARD ===== -->
                    <div class="ay-card">
                        <div class="ay-card-header">
                            <div>
                                <p class="ay-card-title">Compliance Tracker</p>
                                <p class="ay-card-subtitle" id="selectedDeadlineSubtitle">Submission status per teacher and adviser</p>
                            </div>
                            <div class="d-flex gap-2 flex-wrap">
                                <button type="button" class="btn btn-ay btn-ay-ghost btn-ay-sm" id="btnRemindAllTeachers" disabled>
                                    <i class="bi bi-bell"></i> Remind All Teachers
                                </button>
                                <button type="button" class="btn btn-ay btn-ay-ghost btn-ay-sm" id="btnRemindAllAdvisers" disabled>
                                    <i class="bi bi-bell"></i> Remind All Advisers
                                </button>
                            </div>
                        </div>

                        <!-- Tabs -->
                        <ul class="nav nav-tabs" id="complianceTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="teachers-tab" data-bs-toggle="tab" data-bs-target="#teachers" type="button" role="tab" aria-controls="teachers" aria-selected="true">Teachers</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="advisers-tab" data-bs-toggle="tab" data-bs-target="#advisers" type="button" role="tab" aria-controls="advisers" aria-selected="false">Advisers</button>
                            </li>
                        </ul>
                        <div class="tab-content" id="complianceTabContent">
                            <!-- Teachers tab -->
                            <div class="tab-pane fade show active" id="teachers" role="tabpanel" aria-labelledby="teachers-tab">
                                <div class="table-responsive">
                                    <table class="ay-table ay-table-sm">
                                        <thead>
                                            <tr>
                                                <th>NAME</th>
                                                <th>SECTION</th>
                                                <th>SUBJECT</th>
                                                <th>STATUS</th>
                                                <th>SUBMITTED</th>
                                                <th style="text-align:center;">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="teacherDetailsBody">
                                            <tr>
                                                <td colspan="6">
                                                    <div class="ay-empty" style="padding:1.2rem;">
                                                        <i class="bi bi-person-dash"></i>
                                                        <p>Select a deadline to load.</p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- Advisers tab -->
                            <div class="tab-pane fade" id="advisers" role="tabpanel" aria-labelledby="advisers-tab">
                                <div class="table-responsive">
                                    <table class="ay-table ay-table-sm">
                                        <thead>
                                            <tr>
                                                <th>NAME</th>
                                                <th>SECTION</th>
                                                <th>STATUS</th>
                                                <th>SUBMITTED</th>
                                                <th style="text-align:center;">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="adviserDetailsBody">
                                            <tr>
                                                <td colspan="5">
                                                    <div class="ay-empty" style="padding:1.2rem;">
                                                        <i class="bi bi-person-dash"></i>
                                                        <p>Select a deadline to load.</p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ===== END COMPLIANCE TRACKER CARD ===== -->

                </div>
            </div>
        </main>

        <?php require_once("includes/footer.php"); ?>
    </div>

    <!-- Deadline Modal -->
    <div class="modal fade ay-modal" id="deadlineModal" tabindex="-1" data-bs-backdrop="false">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <form id="deadlineForm">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deadlineModalTitle"><i class="bi bi-plus-circle me-2"></i>Set
                            Deadline</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="id" id="deadlineId">
                        <input type="hidden" name="title" id="deadlineTitleInput">

                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">School Year</label>
                                <input type="hidden" name="school_year" id="deadlineSchoolYearInput"
                                    value="<?= e($selectedSchoolYear) ?>" required>
                                <div class="meta-chip w-100"><i class="bi bi-calendar2-check"></i> S.Y.
                                    <?= e($selectedSchoolYear ?: 'None') ?></div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Quarter</label>
                                <input type="hidden" name="quarter" id="deadlineQuarterInput"
                                    value="<?= (int) $selectedQuarter ?>" required>
                                <div class="meta-chip w-100"><i class="bi bi-calendar3"></i>
                                    <?= e($selectedQuarterName) ?> Quarter</div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Type</label>
                                <select class="form-select" name="deadline_type" id="deadlineTypeInput" required>
                                    <option value="">— Select type —</option>
                                    <option value="Teacher">Teacher</option>
                                    <option value="Adviser">Adviser</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Due Date</label>
                                <input type="date" class="form-control" name="due_date" id="deadlineDueDateInput"
                                    required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Due Time</label>
                                <input type="time" class="form-control" name="due_time" id="deadlineDueTimeInput"
                                    required>
                            </div>
                            <div class="col-12" id="teacherSectionsWrapper">
                                <label class="form-label">Sections for Teacher Deadline</label>
                                <div class="section-list">
                                    <?php if (!empty($sections)): ?>
                                        <?php foreach ($sections as $section): ?>
                                            <div class="form-check mb-2">
                                                <input class="form-check-input section-checkbox" type="checkbox"
                                                    name="applicable_to[]" value="<?= (int) $section['id'] ?>"
                                                    id="section_<?= (int) $section['id'] ?>">
                                                <label class="form-check-label" for="section_<?= (int) $section['id'] ?>">
                                                    <?= e($section['section_name']) ?>
                                                    <span style="color:var(--ay-text-muted);">·
                                                        <?= e($section['grade_level_name'] ?? 'Unknown') ?></span>
                                                </label>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <div style="color:var(--ay-text-muted);font-size:.85rem;">No sections found.</div>
                                    <?php endif; ?>
                                </div>
                                <div class="form-text" style="font-size:.78rem;color:var(--ay-text-muted);">Required for teacher
                                    deadlines. Not needed for adviser deadlines.</div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-ay btn-ay-outline" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-ay btn-ay-primary"><i class="bi bi-check-circle"></i> Save
                            Deadline</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Locked Entries Modal -->
    <div class="modal fade ay-modal" id="lockedEntriesModal" tabindex="-1" data-bs-backdrop="false">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-shield-lock me-2"></i>Locked Entries</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-search"></i></span>
                            <input type="search" class="form-control" id="lockedEntriesSearch"
                                placeholder="Search locked entries">
                        </div>
                    </div>
                    <div id="lockedEntriesContainer">
                        <div class="ay-empty"><i class="bi bi-shield-lock"></i>
                            <p>No locked entry data loaded yet.</p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-ay btn-ay-outline" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./js/adminlte.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>

    <script>
        const filterSchoolYear = document.getElementById('filterSchoolYear');
        const filterQuarter = document.getElementById('filterQuarter');
        const btnOpenCreate = document.getElementById('btnOpenCreate');
        const btnViewLocks = document.getElementById('btnViewLocks');
        const btnRemindAllTeachers = document.getElementById('btnRemindAllTeachers');
        const btnRemindAllAdvisers = document.getElementById('btnRemindAllAdvisers');
        const deadlineTableBody = document.getElementById('deadlineTableBody');
        const teacherDetailsBody = document.getElementById('teacherDetailsBody');
        const adviserDetailsBody = document.getElementById('adviserDetailsBody');
        const lockedEntriesContainer = document.getElementById('lockedEntriesContainer');
        const lockedEntriesSearch = document.getElementById('lockedEntriesSearch');
        const alertContainer = document.getElementById('alertContainer');
        const deadlineForm = document.getElementById('deadlineForm');
        const deadlineTypeInput = document.getElementById('deadlineTypeInput');
        const teacherSectionsWrapper = document.getElementById('teacherSectionsWrapper');
        const deadlineTitleInput = document.getElementById('deadlineTitleInput');

        const deadlineModal = new bootstrap.Modal(document.getElementById('deadlineModal'));
        const lockedEntriesModal = new bootstrap.Modal(document.getElementById('lockedEntriesModal'));

        let allDeadlines = [];
        let selectedDeadlineId = null;
        let selectedDeadlineTitle = '';
        let selectedDeadlineType = '';
        let deadlineAutoRefreshTimer = null;
        let deadlineAutoRefreshRunning = false;
        const DEADLINE_AUTO_REFRESH_MS = 30000;
        let selectedTeacherRows = [];
        let selectedAdviserRows = [];

        function esc(str) {
            if (str == null) return '';
            return String(str).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[m]);
        }

        function toast(msg, type = 'success') {
            const map = {
                success: { title: 'Success', color: 'green', icon: 'bi bi-check-circle-fill' },
                danger: { title: 'Error', color: 'red', icon: 'bi bi-exclamation-octagon-fill' },
                warning: { title: 'Warning', color: 'yellow', icon: 'bi bi-exclamation-triangle-fill' },
                info: { title: 'Info', color: 'blue', icon: 'bi bi-info-circle-fill' },
            };
            const c = map[type] || map.success;
            iziToast.show({
                title: c.title, message: msg, color: c.color, icon: c.icon,
                iconColor: '#fff', theme: 'light', position: 'topRight', timeout: 4000,
                progressBar: true, close: true, pauseOnHover: true,
                transitionIn: 'fadeInDown', transitionOut: 'fadeOutUp'
            });
        }

        function showAlert(message, type = 'success') {
            const iconMap = { success: 'bi-check-circle-fill', danger: 'bi-exclamation-octagon-fill', warning: 'bi-exclamation-triangle-fill', info: 'bi-info-circle-fill' };
            const borderMap = { success: 'var(--ay-btn-success-border)', danger: 'var(--ay-btn-danger-border)', warning: 'var(--ay-btn-warning-border)', info: 'var(--ay-badge-open-border)' };
            const bgMap = { success: 'var(--ay-btn-success-bg)', danger: 'var(--ay-btn-danger-bg)', warning: 'var(--ay-btn-warning-bg)', info: 'var(--ay-badge-open-bg)' };
            alertContainer.innerHTML = `
            <div style="background:${bgMap[type] || bgMap.info};border:1.5px solid ${borderMap[type] || borderMap.info};border-radius:12px;padding:.85rem 1.1rem;display:flex;align-items:center;gap:.65rem;font-size:.88rem;font-weight:500;color:var(--ay-text);">
                <i class="bi ${iconMap[type] || iconMap.info}" style="font-size:1.1rem;flex-shrink:0;"></i>
                <span style="flex:1;">${message}</span>
                <button onclick="this.parentElement.remove()" style="background:none;border:none;cursor:pointer;font-size:1rem;color:var(--ay-text-muted);padding:0;">×</button>
            </div>`;
        }

        async function fetchJson(url, options = {}) {
            const response = await fetch(url, options);
            const raw = await response.text();
            let data;
            try { data = JSON.parse(raw); } catch { throw new Error('Server returned non-JSON. Check endpoint.'); }
            if (!data.success) throw new Error(data.message || 'Request failed.');
            return data;
        }

        function normalizeType(value) {
            return String(value || '').toLowerCase().includes('adviser') ? 'Adviser' : 'Teacher';
        }

        function generateTitle(type, quarter) {
            if (!type || !quarter) return '';
            return `Q${quarter} ${type} Submission`;
        }

        function getDeadlineTypeFromId(id, fallback = '') {
            const raw = String(id || '').toLowerCase();
            if (raw.includes('_adviser')) return 'Adviser';
            if (raw.includes('_teacher')) return 'Teacher';
            return normalizeType(fallback);
        }

        function getDeadlineBaseId(id) {
            return parseInt(String(id || '').split('_')[0], 10) || 0;
        }

        function toggleSectionVisibility() {
            teacherSectionsWrapper.style.display = normalizeType(deadlineTypeInput.value) === 'Teacher' ? '' : 'none';
        }

        function formatStatus(row) {
            if (row.status) return String(row.status);
            const due = new Date(row.due_at || row.due_datetime || row.due_date);
            if (isNaN(due.getTime())) return 'Open';
            return due.getTime() < Date.now() ? 'Closed' : 'Open';
        }


        function updateQuarterTracker() {
            const activeQuarter = parseInt(filterQuarter.value || '1', 10);
            const segments = document.querySelectorAll('.quarter-segment');
            const labels = document.querySelectorAll('.quarter-label');

            segments.forEach((segment, index) => {
                segment.classList.remove('active-green', 'active-blue');
                if (index + 1 < activeQuarter) {
                    segment.classList.add('active-green');
                } else if (index + 1 === activeQuarter) {
                    segment.classList.add('active-blue');
                }
            });

            labels.forEach((label, index) => {
                label.classList.toggle('active', index + 1 === activeQuarter);
                label.textContent = index + 1 === activeQuarter
                    ? `Q${index + 1} (Active)`
                    : `Q${index + 1}`;
            });
        }

        // ── Render deadline table ─────────────────────────────────────────────────
        function renderDeadlineRows(rows) {
            if (!rows.length) {
                deadlineTableBody.innerHTML = `<tr><td colspan="7"><div class="ay-empty"><i class="bi bi-hourglass"></i><p>No deadlines found for the selected filters.</p></div></td></tr>`;
                return;
            }
            deadlineTableBody.innerHTML = rows.map(row => {
                const type = normalizeType(row.deadline_type);
                const status = formatStatus(row);
                const isOpen = status.toLowerCase() !== 'closed';
                const isSelected = String(selectedDeadlineId || '') === String(row.id || '');
                return `<tr class="${isSelected ? 'row-selected' : ''}" style="cursor:pointer;"
                        onclick='viewDeadlineDetails(${JSON.stringify(String(row.id || row.deadline_id || ''))}, ${JSON.stringify(row.title || generateTitle(type, row.quarter) || 'Deadline')}, ${JSON.stringify(type)})'>
                <td><strong style="color:var(--ay-text-strong);">${esc(row.title || generateTitle(type, row.quarter) || 'Untitled')}</strong></td>
                <td>${esc(row.due_at_display || row.due_datetime_display || row.due_date || '—')}</td>
                <td style="text-align:center;">
                    <span class="ay-badge ${type === 'Teacher' ? 'ay-badge-teacher' : 'ay-badge-adviser'}">${esc(type)}</span>
                </td>
                <td>${esc(row.applicable_to_display || (type === 'Teacher' ? 'Selected sections' : 'All Advisers'))}</td>
                <td style="text-align:center;">${esc(row.compliance_display || '0/0 submitted')}</td>
                <td style="text-align:center;">
                    <span class="ay-badge ${isOpen ? 'ay-badge-open' : 'ay-badge-closed'}">
                        <i class="bi bi-${isOpen ? 'unlock' : 'lock'}"></i> ${esc(status)}
                    </span>
                </td>
                <td style="text-align:center;">
                    <div style="display:inline-flex;gap:.3rem;flex-wrap:wrap;">
                        <button class="btn btn-ay btn-ay-warning btn-ay-sm"
                                onclick='event.stopPropagation();openEditDeadline(${JSON.stringify(String(row.id || ''))})'>
                            <i class="bi bi-pencil-square"></i>
                        </button>
                        <button class="btn btn-ay btn-ay-danger btn-ay-sm"
                                onclick='event.stopPropagation();deleteDeadline(${JSON.stringify(String(row.id || row.deadline_id || ''))})'>
                            <i class="bi bi-trash3"></i>
                        </button>
                        <button class="btn btn-ay btn-ay-primary btn-ay-sm"
                                onclick="event.stopPropagation();sendReminderAll(${parseInt(row.deadline_id || row.id || 0)},'${type === 'Teacher' ? 'teacher' : 'adviser'}')">
                            <i class="bi bi-bell"></i> Remind
                        </button>
                    </div>
                </td>
            </tr>`;
            }).join('');
        }

        // ── Render compliance tables (new design) ──────────────────────────────
        function renderTeacherDetails() {
            if (!selectedTeacherRows.length) {
                teacherDetailsBody.innerHTML = `<tr><td colspan="6"><div class="ay-empty" style="padding:1.2rem;"><i class="bi bi-person-dash"></i><p>No teacher compliance records.</p></div></td></tr>`;
                return;
            }
            teacherDetailsBody.innerHTML = selectedTeacherRows.map(row => {
                const submitted = String(row.status_label || row.status || '').toLowerCase() === 'submitted';
                const statusText = row.status_label || row.status || 'Not Submitted';
                return `<tr>
                <td>${esc(row.teacher_name || '—')}</td>
                <td>${esc(row.section_name || '—')}</td>
                <td>${esc(row.subject_name || '—')}</td>
                <td>
                    <span class="ay-badge ${submitted ? 'ay-badge-submitted' : 'ay-badge-unsubmitted'}">${esc(statusText)}</span>
                </td>
                <td>${esc(row.submitted_at_display || row.submitted_at || '—')}</td>
                <td style="text-align:center;">
                    ${submitted ? '' : `<button class="btn btn-ay btn-ay-ghost btn-ay-sm" onclick="sendTeacherReminder(${parseInt(selectedDeadlineId || 0)},${parseInt(row.teacher_id || 0)})"><i class="bi bi-bell"></i> Remind</button>`}
                </td>
            </tr>`;
            }).join('');
        }

        function renderAdviserDetails() {
            if (!selectedAdviserRows.length) {
                adviserDetailsBody.innerHTML = `<tr><td colspan="5"><div class="ay-empty" style="padding:1.2rem;"><i class="bi bi-person-dash"></i><p>No adviser compliance records.</p></div></td></tr>`;
                return;
            }
            adviserDetailsBody.innerHTML = selectedAdviserRows.map(row => {
                const submitted = String(row.status_label || row.status || '').toLowerCase() === 'submitted';
                const statusText = row.status_label || row.status || 'Not Submitted';
                return `<tr>
                <td>${esc(row.adviser_name || row.teacher_name || '—')}</td>
                <td>${esc(row.section_name || '—')}</td>
                <td>
                    <span class="ay-badge ${submitted ? 'ay-badge-submitted' : 'ay-badge-unsubmitted'}">${esc(statusText)}</span>
                </td>
                <td>${esc(row.submitted_at_display || row.submitted_at || '—')}</td>
                <td style="text-align:center;">
                    ${submitted ? '' : `<button class="btn btn-ay btn-ay-ghost btn-ay-sm" onclick="sendAdviserReminder(${parseInt(selectedDeadlineId || 0)},${parseInt(row.adviser_id || row.teacher_id || 0)})"><i class="bi bi-bell"></i> Remind</button>`}
                </td>
            </tr>`;
            }).join('');
        }

        // ── API calls ─────────────────────────────────────────────────────────────
        async function loadDeadlineList() {
            const params = new URLSearchParams({ school_year: filterSchoolYear.value || '', quarter: filterQuarter.value || '' });
            const data = await fetchJson(`api/deadline/get_deadline_list.php?${params}`);
            allDeadlines = Array.isArray(data.rows) ? data.rows : (data.data?.rows || []);
            renderDeadlineRows(allDeadlines);
            if (selectedDeadlineId && !allDeadlines.some(r => String(r.id || '') === String(selectedDeadlineId))) {
                clearComplianceSelection();
            }
        }

        async function refreshDeadlineData({ showErrors = false } = {}) {
            if (deadlineAutoRefreshRunning) return;
            deadlineAutoRefreshRunning = true;
            try {
                await loadDeadlineList();
                if (selectedDeadlineId) {
                    await viewDeadlineDetails(selectedDeadlineId, selectedDeadlineTitle, selectedDeadlineType, false);
                }
            } catch (err) {
                if (showErrors) toast(err.message, 'danger');
                else console.warn('Deadline auto-refresh failed:', err);
            } finally {
                deadlineAutoRefreshRunning = false;
            }
        }

        function clearComplianceSelection() {
            selectedDeadlineId = null;
            selectedDeadlineTitle = '';
            selectedDeadlineType = '';
            selectedTeacherRows = [];
            selectedAdviserRows = [];
            document.getElementById('selectedDeadlineSubtitle').textContent = 'Submission status per teacher and adviser';
            btnRemindAllTeachers.disabled = true;
            btnRemindAllAdvisers.disabled = true;
            // Reset both tables to placeholder
            teacherDetailsBody.innerHTML = `<tr><td colspan="6"><div class="ay-empty" style="padding:1.2rem;"><i class="bi bi-person-dash"></i><p>Select a deadline to load.</p></div></td></tr>`;
            adviserDetailsBody.innerHTML = `<tr><td colspan="5"><div class="ay-empty" style="padding:1.2rem;"><i class="bi bi-person-dash"></i><p>Select a deadline to load.</p></div></td></tr>`;
        }

        async function viewDeadlineDetails(deadlineId, title, type = '', showEndedAlert = true) {
            selectedDeadlineId = String(deadlineId || '');
            selectedDeadlineTitle = title || 'Deadline';
            selectedDeadlineType = getDeadlineTypeFromId(deadlineId, type || title);

            // Update subtitle
            document.getElementById('selectedDeadlineSubtitle').textContent = `${selectedDeadlineType} compliance for the selected deadline.`;
            btnRemindAllTeachers.disabled = selectedDeadlineType !== 'Teacher';
            btnRemindAllAdvisers.disabled = selectedDeadlineType !== 'Adviser';
            renderDeadlineRows(allDeadlines);

            const selectedRow = allDeadlines.find(row => String(row.id || '') === String(selectedDeadlineId));
            if (showEndedAlert && selectedRow && (selectedRow.is_overdue || String(selectedRow.status || '').toLowerCase() === 'closed')) {
                showAlert(
                    `${selectedRow.title || selectedDeadlineTitle} ended on ${selectedRow.due_at_display || 'the selected due date'}.`,
                    'warning'
                );
            }

            // Switch to the appropriate tab
            const tabId = selectedDeadlineType === 'Teacher' ? 'teachers-tab' : 'advisers-tab';
            const tabElement = document.getElementById(tabId);
            if (tabElement) {
                const tab = new bootstrap.Tab(tabElement);
                tab.show();
            }

            try {
                const baseId = getDeadlineBaseId(deadlineId);
                selectedTeacherRows = [];
                selectedAdviserRows = [];

                if (selectedDeadlineType === 'Teacher') {
                    const td = await fetchJson(`api/deadline/get_deadline_teacher_details.php?deadline_id=${baseId}`);
                    selectedTeacherRows = Array.isArray(td.rows) ? td.rows : (td.data?.rows || []);
                    renderTeacherDetails();
                } else {
                    const ad = await fetchJson(`api/deadline/get_deadline_adviser_details.php?deadline_id=${baseId}`);
                    selectedAdviserRows = Array.isArray(ad.rows) ? ad.rows : (ad.data?.rows || []);
                    renderAdviserDetails();
                }
            } catch (err) {
                toast(err.message, 'danger');
            }
        }

        async function sendReminderAll(deadlineId, recipientType) {
            try {
                const fd = new FormData();
                fd.append('deadline_id', getDeadlineBaseId(deadlineId));
                fd.append('recipient_type', recipientType);
                const data = await fetchJson('api/deadline/send_deadline_reminder_all.php', { method: 'POST', body: fd });
                toast(data.message || 'Reminders sent.');
            } catch (err) { toast(err.message, 'danger'); }
        }

        async function sendTeacherReminder(deadlineId, teacherId) {
            try {
                const fd = new FormData();
                fd.append('deadline_id', getDeadlineBaseId(deadlineId));
                fd.append('teacher_id', teacherId);
                const data = await fetchJson('api/deadline/send_teacher_reminder.php', { method: 'POST', body: fd });
                toast(data.message || 'Teacher reminder sent.');
            } catch (err) { toast(err.message, 'danger'); }
        }

        async function sendAdviserReminder(deadlineId, adviserId) {
            try {
                const fd = new FormData();
                fd.append('deadline_id', getDeadlineBaseId(deadlineId));
                fd.append('adviser_id', adviserId);
                const data = await fetchJson('api/deadline/send_adviser_reminder.php', { method: 'POST', body: fd });
                toast(data.message || 'Adviser reminder sent.');
            } catch (err) { toast(err.message, 'danger'); }
        }

        function resetDeadlineForm() {
            deadlineForm.reset();
            document.getElementById('deadlineModalTitle').innerHTML = '<i class="bi bi-plus-circle me-2"></i>Set Deadline';
            document.getElementById('deadlineId').value = '';
            document.getElementById('deadlineSchoolYearInput').value = filterSchoolYear.value || '';
            document.getElementById('deadlineQuarterInput').value = filterQuarter.value || '1';
            document.getElementById('deadlineTypeInput').value = '';
            deadlineTitleInput.value = '';
            document.querySelectorAll('.section-checkbox').forEach(cb => cb.checked = false);
            toggleSectionVisibility();
        }

        async function openEditDeadline(deadlineId) {
            try {
                const data = await fetchJson(`api/deadline/get_deadline_details.php?deadline_id=${deadlineId}`);
                const row = data.row || data.data?.row || null;
                if (!row) throw new Error('Deadline details not found.');
                resetDeadlineForm();
                const type = normalizeType(row.deadline_type);
                document.getElementById('deadlineModalTitle').innerHTML = '<i class="bi bi-pencil-square me-2"></i>Edit Deadline';
                document.getElementById('deadlineId').value = row.id || '';
                document.getElementById('deadlineSchoolYearInput').value = row.school_year || filterSchoolYear.value || '';
                document.getElementById('deadlineQuarterInput').value = String(row.quarter || '1');
                document.getElementById('deadlineTypeInput').value = type;
                document.getElementById('deadlineDueDateInput').value = row.due_date || '';
                document.getElementById('deadlineDueTimeInput').value = row.due_time || '';
                deadlineTitleInput.value = row.title || generateTitle(type, row.quarter || '1');
                const applicable = Array.isArray(row.applicable_sections) ? row.applicable_sections.map(Number) : [];
                document.querySelectorAll('.section-checkbox').forEach(cb => { cb.checked = applicable.includes(Number(cb.value)); });
                toggleSectionVisibility();
                deadlineModal.show();
            } catch (err) { toast(err.message, 'danger'); }
        }

        async function deleteDeadline(deadlineId) {
            iziToast.question({
                timeout: 20000, close: false, overlay: true, displayMode: 'once', zindex: 9999,
                title: 'Confirm', message: 'Delete this deadline?', position: 'center', color: 'red',
                buttons: [
                    ['<button><b>Yes, delete</b></button>', async (inst, t) => {
                        inst.hide({ transitionOut: 'fadeOut' }, t);
                        try {
                            const fd = new FormData();
                            fd.append('deadline_id', deadlineId);
                            const data = await fetchJson('api/deadline/delete_deadline.php', { method: 'POST', body: fd });
                            toast(data.message || 'Deadline deleted.');
                            await loadDeadlineList();
                            if (String(selectedDeadlineId || '') === String(deadlineId || '')) clearComplianceSelection();
                        } catch (err) { toast(err.message, 'danger'); }
                    }, true],
                    ['<button>Cancel</button>', (inst, t) => inst.hide({ transitionOut: 'fadeOut' }, t)]
                ]
            });
        }

        async function loadLockedEntries() {
            const data = await fetchJson('api/deadline/get_locked_entries.php');
            lockedEntriesRows = Array.isArray(data.rows) ? data.rows : (data.data?.rows || []);
            renderLockedEntries();
        }

        let lockedEntriesRows = [];

        function renderLockedEntries() {
            const term = (lockedEntriesSearch.value || '').trim().toLowerCase();
            const rows = term
                ? lockedEntriesRows.filter(row => [
                    row.teacher_name, row.adviser_name, row.user_name, row.deadline_title,
                    row.section_name, row.subject_name, row.school_year, row.locked_since
                ].some(value => String(value || '').toLowerCase().includes(term)))
                : lockedEntriesRows;
            if (!rows.length) {
                lockedEntriesContainer.innerHTML = `<div class="ay-empty"><i class="bi bi-shield-check"></i><p>${term ? 'No locked entries match your search.' : 'No locked entries found.'}</p></div>`;
                return;
            }
            lockedEntriesContainer.innerHTML = rows.map(row => `
            <div class="locked-item">
                <div style="font-weight:700;color:var(--ay-text-strong);">${esc(row.teacher_name || row.adviser_name || row.user_name || 'Faculty')}</div>
                <div style="font-size:.82rem;color:var(--ay-text-muted);margin:.2rem 0 .65rem;">
                    ${esc(row.deadline_title || 'Locked submission')} · ${esc(row.section_name || 'No section')} · ${esc(row.locked_since || row.created_at || '—')}
                </div>
                <button class="btn btn-ay btn-ay-danger btn-ay-sm" onclick="unlockLockedEntry(${parseInt(row.id || row.lock_id || 0)})">
                    <i class="bi bi-unlock"></i> Unlock
                </button>
            </div>
        `).join('');
        }

        async function unlockLockedEntry(lockId) {
            if (!lockId) { toast('Unable to determine lock record id.', 'danger'); return; }
            iziToast.question({
                timeout: 20000, close: false, overlay: true, displayMode: 'once', zindex: 9999,
                title: 'Confirm', message: 'Unlock this entry?', position: 'center', color: 'blue',
                buttons: [
                    ['<button><b>Yes, unlock</b></button>', async (inst, t) => {
                        inst.hide({ transitionOut: 'fadeOut' }, t);
                        try {
                            const fd = new FormData();
                            fd.append('id', lockId);
                            const data = await fetchJson('api/deadline/unlock_locked_entry.php', { method: 'POST', body: fd });
                            toast(data.message || 'Entry unlocked.');
                            await loadLockedEntries();
                            if (selectedDeadlineId) await viewDeadlineDetails(selectedDeadlineId, selectedDeadlineTitle, selectedDeadlineType, false);
                        } catch (err) { toast(err.message, 'danger'); }
                    }, true],
                    ['<button>Cancel</button>', (inst, t) => inst.hide({ transitionOut: 'fadeOut' }, t)]
                ]
            });
        }

        // ── Event listeners ───────────────────────────────────────────────────────
        deadlineTypeInput.addEventListener('change', () => {
            toggleSectionVisibility();
            deadlineTitleInput.value = generateTitle(deadlineTypeInput.value, document.getElementById('deadlineQuarterInput').value);
        });

        document.getElementById('deadlineQuarterInput').addEventListener('change', function () {
            deadlineTitleInput.value = generateTitle(deadlineTypeInput.value, this.value);
        });

        deadlineForm.addEventListener('submit', async function (e) {
            e.preventDefault();
            const type = normalizeType(deadlineTypeInput.value);
            const quarter = document.getElementById('deadlineQuarterInput').value;
            deadlineTitleInput.value = generateTitle(type, quarter);
            if (type === 'Teacher' && ![...document.querySelectorAll('.section-checkbox:checked')].length) {
                toast('Please select at least one section for a teacher deadline.', 'warning');
                return;
            }
            try {
                const data = await fetchJson('api/deadline/save_deadline.php', { method: 'POST', body: new FormData(deadlineForm) });
                deadlineModal.hide();
                toast(data.message || 'Deadline saved.');
                await loadDeadlineList();
            } catch (err) { toast(err.message, 'danger'); }
        });

        btnOpenCreate.addEventListener('click', () => { resetDeadlineForm(); deadlineModal.show(); });
        btnViewLocks.addEventListener('click', async () => {
            try { lockedEntriesSearch.value = ''; await loadLockedEntries(); lockedEntriesModal.show(); }
            catch (err) { toast(err.message, 'danger'); }
        });
        lockedEntriesSearch.addEventListener('input', renderLockedEntries);
        btnRemindAllTeachers.addEventListener('click', () => { if (selectedDeadlineId) sendReminderAll(selectedDeadlineId, 'teacher'); });
        btnRemindAllAdvisers.addEventListener('click', () => { if (selectedDeadlineId) sendReminderAll(selectedDeadlineId, 'adviser'); });

        // Expose to inline onclick handlers
        window.viewDeadlineDetails = viewDeadlineDetails;
        window.openEditDeadline = openEditDeadline;
        window.deleteDeadline = deleteDeadline;
        window.sendReminderAll = sendReminderAll;
        window.sendTeacherReminder = sendTeacherReminder;
        window.sendAdviserReminder = sendAdviserReminder;
        window.unlockLockedEntry = unlockLockedEntry;

        deadlineAutoRefreshTimer = window.setInterval(() => {
            if (!document.hidden) refreshDeadlineData();
        }, DEADLINE_AUTO_REFRESH_MS);
        window.addEventListener('beforeunload', () => window.clearInterval(deadlineAutoRefreshTimer));

        // ── Init ──────────────────────────────────────────────────────────────────
        (async function init() {
            toggleSectionVisibility();
            updateQuarterTracker();
            clearComplianceSelection();
            await refreshDeadlineData({ showErrors: true });
        })();
    </script>
</body>

</html>