<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

require_once __DIR__ . '/api/shared/db_connect.php';

function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

$schoolYears = [];
$sections = [];

try {
    $ayStmt = $pdo->query("SELECT id, year_label, is_active FROM tblacademicyear ORDER BY year_label DESC");
    if ($ayStmt) {
        $schoolYears = $ayStmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Throwable $e) {
    $schoolYears = [];
}

try {
    $secStmt = $pdo->query("
        SELECT s.id, s.section_name, gl.grade_level_name
        FROM tblsection s
        LEFT JOIN tblgradelevel gl ON gl.id = s.grade_level_id
        ORDER BY gl.id ASC, s.section_name ASC
    ");
    if ($secStmt) {
        $sections = $secStmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Throwable $e) {
    $sections = [];
}

$activeSchoolYear = '';
foreach ($schoolYears as $sy) {
    if ((int)($sy['is_active'] ?? 0) === 1) {
        $activeSchoolYear = $sy['year_label'];
        break;
    }
}
if ($activeSchoolYear === '' && !empty($schoolYears)) {
    $activeSchoolYear = $schoolYears[0]['year_label'];
}

$selectedSchoolYear = isset($_GET['school_year']) && $_GET['school_year'] !== ''
    ? trim($_GET['school_year'])
    : $activeSchoolYear;

$selectedQuarter = isset($_GET['quarter']) ? (int) $_GET['quarter'] : 1;
if (!in_array($selectedQuarter, [1, 2, 3, 4], true)) {
    $selectedQuarter = 1;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deadline Management</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        body {
            background: #f8f9fb;
        }

        .page-wrap {
            padding: 1.25rem 0 1.5rem;
        }

        .card {
            border: 1px solid #e9ecef;
            box-shadow: 0 0.25rem 1rem rgba(0, 0, 0, 0.04);
        }

        .table thead th {
            white-space: nowrap;
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            color: #6c757d;
            background: #f8f9fa;
        }

        .table td,
        .table th {
            vertical-align: middle;
        }

        .section-list {
            max-height: 240px;
            overflow-y: auto;
            border: 1px solid #dee2e6;
            border-radius: 0.5rem;
            padding: 0.75rem;
            background: #fff;
        }

        .empty-state {
            padding: 1.5rem;
            text-align: center;
            color: #6c757d;
        }

        .deadline-row-selected {
            background: #eef5ff !important;
        }

        .locked-item + .locked-item {
            margin-top: 0.75rem;
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid page-wrap">
                <div id="alertContainer" class="mb-3"></div>

                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                    <div>
                        <h1 class="h3 mb-1">Deadline Management</h1>
                        <div class="text-muted">Set teacher and adviser deadlines, then monitor compliance.</div>
                    </div>
                    <div class="d-flex flex-wrap gap-2">
                        <button type="button" class="btn btn-primary" id="btnOpenCreate">
                            <i class="bi bi-plus-circle me-1"></i> Set Deadline
                        </button>
                        <button type="button" class="btn btn-outline-secondary" id="btnRefreshTop">
                            <i class="bi bi-arrow-clockwise me-1"></i> Refresh
                        </button>
                        <button type="button" class="btn btn-outline-secondary" id="btnViewLocks">
                            <i class="bi bi-shield-lock me-1"></i> Locked Entries
                        </button>
                    </div>
                </div>

                <div class="card mb-3">
                    <div class="card-body">
                        <div class="row g-3 align-items-end">
                            <div class="col-md-4">
                                <label class="form-label">School Year</label>
                                <select id="filterSchoolYear" class="form-select">
                                    <?php foreach ($schoolYears as $sy): ?>
                                        <option value="<?= e($sy['year_label']) ?>" <?= $sy['year_label'] === $selectedSchoolYear ? 'selected' : '' ?>>
                                            <?= e($sy['year_label']) ?> <?= (int)($sy['is_active'] ?? 0) === 1 ? '(Active)' : '' ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-md-3">
                                <label class="form-label">Quarter</label>
                                <select id="filterQuarter" class="form-select">
                                    <option value="1" <?= $selectedQuarter === 1 ? 'selected' : '' ?>>Quarter 1</option>
                                    <option value="2" <?= $selectedQuarter === 2 ? 'selected' : '' ?>>Quarter 2</option>
                                    <option value="3" <?= $selectedQuarter === 3 ? 'selected' : '' ?>>Quarter 3</option>
                                    <option value="4" <?= $selectedQuarter === 4 ? 'selected' : '' ?>>Quarter 4</option>
                                </select>
                            </div>

                            <div class="col-md-5">
                                <div class="d-flex gap-2">
                                    <button type="button" class="btn btn-outline-secondary w-100" id="btnRefresh">
                                        <i class="bi bi-arrow-repeat me-1"></i> Reload List
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card mb-3">
                    <div class="card-header bg-white">
                        <div class="fw-semibold">Deadline List</div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Due Date</th>
                                    <th>Type</th>
                                    <th>Applicable To</th>
                                    <th>Compliance</th>
                                    <th>Status</th>
                                    <th class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="deadlineTableBody">
                                <tr>
                                    <td colspan="7" class="empty-state">Loading deadlines...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="card mb-3">
                    <div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center gap-2">
                        <div>
                            <div class="fw-semibold" id="selectedDeadlineTitle">Compliance</div>
                            <div class="text-muted small" id="selectedDeadlineSubtitle">Select a deadline to view teacher and adviser compliance.</div>
                        </div>
                        <div class="d-flex gap-2">
                            <button type="button" class="btn btn-outline-primary btn-sm" id="btnRemindAllTeachers" disabled>
                                Remind All Teachers
                            </button>
                            <button type="button" class="btn btn-outline-primary btn-sm" id="btnRemindAllAdvisers" disabled>
                                Remind All Advisers
                            </button>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-lg-6">
                                <h6 class="mb-3">Teacher Compliance</h6>
                                <div class="table-responsive">
                                    <table class="table table-sm align-middle">
                                        <thead>
                                            <tr>
                                                <th>Teacher</th>
                                                <th>Section</th>
                                                <th>Status</th>
                                                <th>Submitted At</th>
                                                <th class="text-end">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="teacherDetailsBody">
                                            <tr>
                                                <td colspan="5" class="empty-state">Select a deadline to load teacher compliance.</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <h6 class="mb-3">Adviser Compliance</h6>
                                <div class="table-responsive">
                                    <table class="table table-sm align-middle">
                                        <thead>
                                            <tr>
                                                <th>Adviser</th>
                                                <th>Section</th>
                                                <th>Status</th>
                                                <th>Submitted At</th>
                                                <th class="text-end">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="adviserDetailsBody">
                                            <tr>
                                                <td colspan="5" class="empty-state">Select a deadline to load adviser compliance.</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php require_once("includes/footer.php"); ?>
</div>

<div class="modal fade" id="deadlineModal" tabindex="-1" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <form id="deadlineForm">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title mb-1" id="deadlineModalTitle">Set Deadline</h5>
                        <div class="text-muted small">Create or edit a teacher or adviser deadline.</div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <input type="hidden" name="id" id="deadlineId">
                    <input type="hidden" name="title" id="deadlineTitleInput">

                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">School Year</label>
                            <select class="form-select" name="school_year" id="deadlineSchoolYearInput" required>
                                <?php foreach ($schoolYears as $sy): ?>
                                    <option value="<?= e($sy['year_label']) ?>" <?= $sy['year_label'] === $selectedSchoolYear ? 'selected' : '' ?>>
                                        <?= e($sy['year_label']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Quarter</label>
                            <select class="form-select" name="quarter" id="deadlineQuarterInput" required>
                                <option value="1">Quarter 1</option>
                                <option value="2">Quarter 2</option>
                                <option value="3">Quarter 3</option>
                                <option value="4">Quarter 4</option>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Type</label>
                            <select class="form-select" name="deadline_type" id="deadlineTypeInput" required>
                                <option value="">Select type</option>
                                <option value="Teacher">Teacher</option>
                                <option value="Adviser">Adviser</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Due Date</label>
                            <input type="date" class="form-control" name="due_date" id="deadlineDueDateInput" required>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Due Time</label>
                            <input type="time" class="form-control" name="due_time" id="deadlineDueTimeInput" required>
                        </div>

                        <div class="col-12" id="teacherSectionsWrapper">
                            <label class="form-label">Sections for Teacher Deadline</label>
                            <div class="section-list">
                                <?php if (!empty($sections)): ?>
                                    <?php foreach ($sections as $section): ?>
                                        <div class="form-check mb-2">
                                            <input
                                                class="form-check-input section-checkbox"
                                                type="checkbox"
                                                name="applicable_to[]"
                                                value="<?= (int) $section['id'] ?>"
                                                id="section_<?= (int) $section['id'] ?>"
                                            >
                                            <label class="form-check-label" for="section_<?= (int) $section['id'] ?>">
                                                <?= e($section['section_name']) ?>
                                                <span class="text-muted">· <?= e($section['grade_level_name'] ?? 'Unknown Grade Level') ?></span>
                                            </label>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="text-muted small">No sections found.</div>
                                <?php endif; ?>
                            </div>
                            <div class="form-text">Required for teacher deadlines. Not needed for adviser deadlines.</div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Deadline</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="lockedEntriesModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <h5 class="modal-title mb-1">Locked Entries</h5>
                    <div class="text-muted small">Simple list of locked submissions with unlock action.</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="lockedEntriesContainer">
                    <div class="empty-state">No locked entry data loaded yet.</div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="./js/sweet-alerts.js"></script>

<script>
    const filterSchoolYear = document.getElementById('filterSchoolYear');
    const filterQuarter = document.getElementById('filterQuarter');

    const btnRefresh = document.getElementById('btnRefresh');
    const btnRefreshTop = document.getElementById('btnRefreshTop');
    const btnOpenCreate = document.getElementById('btnOpenCreate');
    const btnViewLocks = document.getElementById('btnViewLocks');
    const btnRemindAllTeachers = document.getElementById('btnRemindAllTeachers');
    const btnRemindAllAdvisers = document.getElementById('btnRemindAllAdvisers');

    const deadlineTableBody = document.getElementById('deadlineTableBody');
    const teacherDetailsBody = document.getElementById('teacherDetailsBody');
    const adviserDetailsBody = document.getElementById('adviserDetailsBody');
    const lockedEntriesContainer = document.getElementById('lockedEntriesContainer');
    const alertContainer = document.getElementById('alertContainer');

    const deadlineForm = document.getElementById('deadlineForm');
    const deadlineModal = new bootstrap.Modal(document.getElementById('deadlineModal'));
    const lockedEntriesModal = new bootstrap.Modal(document.getElementById('lockedEntriesModal'));

    const deadlineTypeInput = document.getElementById('deadlineTypeInput');
    const teacherSectionsWrapper = document.getElementById('teacherSectionsWrapper');
    const deadlineTitleInput = document.getElementById('deadlineTitleInput');

    let allDeadlines = [];
    let selectedDeadlineId = null;
    let selectedDeadlineTitle = '';
    let selectedTeacherRows = [];
    let selectedAdviserRows = [];

    function escapeHtml(str) {
        if (str === null || str === undefined) return '';
        return String(str).replace(/[&<>"']/g, function (m) {
            return ({
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            })[m];
        });
    }

    function showAlert(message, type = 'success') {
        AppAlerts.showToast(message, type);
    }

    async function fetchJson(url, options = {}) {
        const response = await fetch(url, options);
        const raw = await response.text();

        let data;
        try {
            data = JSON.parse(raw);
        } catch (err) {
            console.error('Non-JSON response from:', url, raw);
            throw new Error('Server returned non-JSON output. Check the endpoint response in Network tab.');
        }

        if (!data.success) {
            throw new Error(data.message || 'Request failed.');
        }

        return data;
    }

    function normalizeDeadlineType(value) {
        const text = String(value || '').toLowerCase();
        if (text.includes('adviser')) return 'Adviser';
        return 'Teacher';
    }

    function generateTitle(type, quarter) {
        if (!type || !quarter) return '';
        return `Q${quarter} ${type} Submission`;
    }

    function toggleSectionVisibility() {
        const type = normalizeDeadlineType(deadlineTypeInput.value);
        teacherSectionsWrapper.style.display = type === 'Teacher' ? '' : 'none';
    }

    function formatStatus(row) {
        if (row.status) {
            return String(row.status);
        }

        const dueSource = row.due_at || row.due_datetime || row.due_date;
        if (!dueSource) {
            return 'Open';
        }

        const due = new Date(dueSource);
        if (Number.isNaN(due.getTime())) {
            return 'Open';
        }

        return due.getTime() < Date.now() ? 'Closed' : 'Open';
    }

    function renderDeadlineRows(rows) {
        if (!rows.length) {
            deadlineTableBody.innerHTML = `
                <tr>
                    <td colspan="7" class="empty-state">No deadlines found for the selected school year and quarter.</td>
                </tr>
            `;
            return;
        }

        deadlineTableBody.innerHTML = rows.map(row => {
            const rowType = normalizeDeadlineType(row.deadline_type);
            const rowStatus = formatStatus(row);
            const statusClass = rowStatus.toLowerCase() === 'closed' ? 'secondary' : 'success';
            const isSelected = parseInt(selectedDeadlineId || 0, 10) === parseInt(row.id || 0, 10) ? 'deadline-row-selected' : '';

            return `
                <tr class="${isSelected}">
                    <td>${escapeHtml(row.title || generateTitle(rowType, row.quarter) || 'Untitled Deadline')}</td>
                    <td>${escapeHtml(row.due_at_display || row.due_datetime_display || row.due_date || '-')}</td>
                    <td>${escapeHtml(rowType)}</td>
                    <td>${escapeHtml(row.applicable_to_display || (rowType === 'Teacher' ? 'Selected sections' : 'Advisers'))}</td>
                    <td>${escapeHtml(row.compliance_display || '0/0 submitted')}</td>
                    <td><span class="badge text-bg-${statusClass}">${escapeHtml(rowStatus)}</span></td>
                    <td class="text-end">
                        <div class="btn-group btn-group-sm">
                            <button type="button" class="btn btn-outline-secondary" onclick="viewDeadlineDetails(${parseInt(row.id, 10)}, ${JSON.stringify(row.title || generateTitle(rowType, row.quarter) || 'Deadline')})">View</button>
                            <button type="button" class="btn btn-outline-primary" onclick="openEditDeadline(${parseInt(row.id, 10)})">Edit</button>
                            <button type="button" class="btn btn-outline-danger" onclick="deleteDeadline(${parseInt(row.id, 10)})">Delete</button>
                            <button type="button" class="btn btn-primary" onclick="sendReminderAll(${parseInt(row.id, 10)}, 'all')">Remind All</button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');
    }

    function renderTeacherDetails() {
        if (!selectedTeacherRows.length) {
            teacherDetailsBody.innerHTML = `<tr><td colspan="5" class="empty-state">No teacher compliance records found.</td></tr>`;
            return;
        }

        teacherDetailsBody.innerHTML = selectedTeacherRows.map(row => {
            const statusText = String(row.status_label || row.status || 'Not Submitted');
            const submitted = statusText.toLowerCase() === 'submitted';
            return `
                <tr>
                    <td>${escapeHtml(row.teacher_name || '-')}</td>
                    <td>${escapeHtml(row.section_name || '-')}</td>
                    <td><span class="badge text-bg-${submitted ? 'success' : 'secondary'}">${escapeHtml(statusText)}</span></td>
                    <td>${escapeHtml(row.submitted_at_display || row.submitted_at || '-')}</td>
                    <td class="text-end">
                        ${submitted ? '' : `<button type="button" class="btn btn-sm btn-outline-primary" onclick="sendTeacherReminder(${parseInt(selectedDeadlineId || 0, 10)}, ${parseInt(row.teacher_id || 0, 10)})">Send Reminder</button>`}
                    </td>
                </tr>
            `;
        }).join('');
    }

    function renderAdviserDetails() {
        if (!selectedAdviserRows.length) {
            adviserDetailsBody.innerHTML = `<tr><td colspan="5" class="empty-state">No adviser compliance records found.</td></tr>`;
            return;
        }

        adviserDetailsBody.innerHTML = selectedAdviserRows.map(row => {
            const statusText = String(row.status_label || row.status || 'Not Submitted');
            const submitted = statusText.toLowerCase() === 'submitted';
            return `
                <tr>
                    <td>${escapeHtml(row.adviser_name || row.teacher_name || '-')}</td>
                    <td>${escapeHtml(row.section_name || '-')}</td>
                    <td><span class="badge text-bg-${submitted ? 'success' : 'secondary'}">${escapeHtml(statusText)}</span></td>
                    <td>${escapeHtml(row.submitted_at_display || row.submitted_at || '-')}</td>
                    <td class="text-end">
                        ${submitted ? '' : `<button type="button" class="btn btn-sm btn-outline-primary" onclick="sendAdviserReminder(${parseInt(selectedDeadlineId || 0, 10)}, ${parseInt(row.adviser_id || row.teacher_id || 0, 10)})">Send Reminder</button>`}
                    </td>
                </tr>
            `;
        }).join('');
    }

    async function loadDeadlineList() {
        const params = new URLSearchParams({
            school_year: filterSchoolYear.value || '',
            quarter: filterQuarter.value || ''
        });

        const data = await fetchJson(`api/deadline/get_deadline_list.php?${params.toString()}`);
        allDeadlines = Array.isArray(data.rows) ? data.rows : (data.data?.rows || []);
        renderDeadlineRows(allDeadlines);

        if (selectedDeadlineId) {
            const stillExists = allDeadlines.some(row => parseInt(row.id || 0, 10) === parseInt(selectedDeadlineId, 10));
            if (!stillExists) {
                clearComplianceSelection();
            } else {
                renderDeadlineRows(allDeadlines);
            }
        }
    }

    function clearComplianceSelection() {
        selectedDeadlineId = null;
        selectedDeadlineTitle = '';
        selectedTeacherRows = [];
        selectedAdviserRows = [];
        document.getElementById('selectedDeadlineTitle').textContent = 'Compliance';
        document.getElementById('selectedDeadlineSubtitle').textContent = 'Select a deadline to view teacher and adviser compliance.';
        btnRemindAllTeachers.disabled = true;
        btnRemindAllAdvisers.disabled = true;
        teacherDetailsBody.innerHTML = `<tr><td colspan="5" class="empty-state">Select a deadline to load teacher compliance.</td></tr>`;
        adviserDetailsBody.innerHTML = `<tr><td colspan="5" class="empty-state">Select a deadline to load adviser compliance.</td></tr>`;
    }

    async function loadTeacherDetails(deadlineId) {
        const data = await fetchJson(`api/deadline/get_deadline_teacher_details.php?deadline_id=${deadlineId}`);
        selectedTeacherRows = Array.isArray(data.rows) ? data.rows : (data.data?.rows || []);
        renderTeacherDetails();
    }

    async function loadAdviserDetails(deadlineId) {
        const data = await fetchJson(`api/deadline/get_deadline_adviser_details.php?deadline_id=${deadlineId}`);
        selectedAdviserRows = Array.isArray(data.rows) ? data.rows : (data.data?.rows || []);
        renderAdviserDetails();
    }

    async function viewDeadlineDetails(deadlineId, title) {
        selectedDeadlineId = deadlineId;
        selectedDeadlineTitle = title || 'Deadline';
        document.getElementById('selectedDeadlineTitle').textContent = selectedDeadlineTitle;
        document.getElementById('selectedDeadlineSubtitle').textContent = 'Teacher and adviser compliance for the selected deadline.';
        btnRemindAllTeachers.disabled = false;
        btnRemindAllAdvisers.disabled = false;

        try {
            await Promise.all([
                loadTeacherDetails(deadlineId),
                loadAdviserDetails(deadlineId)
            ]);
            renderDeadlineRows(allDeadlines);
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    async function sendReminderAll(deadlineId, recipientType) {
        try {
            const formData = new FormData();
            formData.append('deadline_id', deadlineId);
            formData.append('recipient_type', recipientType);

            const data = await fetchJson('api/deadline/send_deadline_reminder_all.php', {
                method: 'POST',
                body: formData
            });

            showAlert(data.message || 'Reminders sent.');
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    async function sendTeacherReminder(deadlineId, teacherId) {
        try {
            const formData = new FormData();
            formData.append('deadline_id', deadlineId);
            formData.append('teacher_id', teacherId);

            const data = await fetchJson('api/deadline/send_teacher_reminder.php', {
                method: 'POST',
                body: formData
            });

            showAlert(data.message || 'Teacher reminder sent.');
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    async function sendAdviserReminder(deadlineId, adviserId) {
        try {
            const formData = new FormData();
            formData.append('deadline_id', deadlineId);
            formData.append('adviser_id', adviserId);

            const data = await fetchJson('api/deadline/send_adviser_reminder.php', {
                method: 'POST',
                body: formData
            });

            showAlert(data.message || 'Adviser reminder sent.');
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    function resetDeadlineForm() {
        deadlineForm.reset();
        document.getElementById('deadlineModalTitle').textContent = 'Set Deadline';
        document.getElementById('deadlineId').value = '';
        document.getElementById('deadlineSchoolYearInput').value = filterSchoolYear.value || '';
        document.getElementById('deadlineQuarterInput').value = filterQuarter.value || '1';
        document.getElementById('deadlineTypeInput').value = '';
        deadlineTitleInput.value = '';
        document.querySelectorAll('.section-checkbox').forEach(cb => cb.checked = false);
        toggleSectionVisibility();
    }

    async function openEditDeadline(deadlineId) {
        try {
            const data = await fetchJson(`api/deadline/get_deadline_details.php?deadline_id=${deadlineId}`);
            const row = data.row || data.data?.row || null;

            if (!row) {
                throw new Error('Deadline details not found.');
            }

            resetDeadlineForm();

            const normalizedType = normalizeDeadlineType(row.deadline_type);
            document.getElementById('deadlineModalTitle').textContent = 'Edit Deadline';
            document.getElementById('deadlineId').value = row.id || '';
            document.getElementById('deadlineSchoolYearInput').value = row.school_year || filterSchoolYear.value || '';
            document.getElementById('deadlineQuarterInput').value = String(row.quarter || '1');
            document.getElementById('deadlineTypeInput').value = normalizedType;
            document.getElementById('deadlineDueDateInput').value = row.due_date || '';
            document.getElementById('deadlineDueTimeInput').value = row.due_time || '';
            deadlineTitleInput.value = row.title || generateTitle(normalizedType, row.quarter || '1');

            const applicableSections = Array.isArray(row.applicable_sections)
                ? row.applicable_sections.map(value => Number(value))
                : [];

            document.querySelectorAll('.section-checkbox').forEach(cb => {
                cb.checked = applicableSections.includes(Number(cb.value));
            });

            toggleSectionVisibility();
            deadlineModal.show();
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    async function deleteDeadline(deadlineId) {
        if (!confirm('Delete this deadline?')) {
            return;
        }

        try {
            const formData = new FormData();
            formData.append('deadline_id', deadlineId);

            const data = await fetchJson('api/deadline/delete_deadline.php', {
                method: 'POST',
                body: formData
            });

            showAlert(data.message || 'Deadline deleted.');
            await loadDeadlineList();

            if (parseInt(selectedDeadlineId || 0, 10) === parseInt(deadlineId, 10)) {
                clearComplianceSelection();
            }
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    async function loadLockedEntries() {
        const data = await fetchJson('api/deadline/get_locked_entries.php');
        const rows = Array.isArray(data.rows) ? data.rows : (data.data?.rows || []);

        if (!rows.length) {
            lockedEntriesContainer.innerHTML = `<div class="empty-state">No locked entries found.</div>`;
            return;
        }

        lockedEntriesContainer.innerHTML = rows.map(row => `
            <div class="locked-item border rounded p-3">
                <div class="fw-semibold">${escapeHtml(row.teacher_name || row.adviser_name || row.user_name || 'Faculty')}</div>
                <div class="text-muted small mb-2">
                    ${escapeHtml(row.deadline_title || 'Locked submission')} ·
                    ${escapeHtml(row.section_name || 'No section')} ·
                    ${escapeHtml(row.locked_since || row.created_at || '-')}
                </div>
                <button type="button" class="btn btn-sm btn-outline-danger" onclick="unlockLockedEntry(${parseInt(row.id || row.lock_id || 0, 10)})">
                    Unlock
                </button>
            </div>
        `).join('');
    }

    async function unlockLockedEntry(lockId) {
        if (!lockId) {
            showAlert('Unable to determine lock record id.', 'danger');
            return;
        }

        if (!confirm('Unlock this entry?')) {
            return;
        }

        try {
            const formData = new FormData();
            formData.append('id', lockId);

            const data = await fetchJson('api/deadline/unlock_locked_entry.php', {
                method: 'POST',
                body: formData
            });

            showAlert(data.message || 'Entry unlocked.');
            await loadLockedEntries();

            if (selectedDeadlineId) {
                await viewDeadlineDetails(selectedDeadlineId, selectedDeadlineTitle);
            }
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    deadlineTypeInput.addEventListener('change', function () {
        toggleSectionVisibility();
        deadlineTitleInput.value = generateTitle(deadlineTypeInput.value, document.getElementById('deadlineQuarterInput').value);
    });

    document.getElementById('deadlineQuarterInput').addEventListener('change', function () {
        deadlineTitleInput.value = generateTitle(deadlineTypeInput.value, this.value);
    });

    deadlineForm.addEventListener('submit', async function (e) {
        e.preventDefault();

        const type = normalizeDeadlineType(deadlineTypeInput.value);
        const quarter = document.getElementById('deadlineQuarterInput').value;
        deadlineTitleInput.value = generateTitle(type, quarter);

        if (type === 'Teacher') {
            const selectedSections = [...document.querySelectorAll('.section-checkbox:checked')];
            if (!selectedSections.length) {
                showAlert('Please select at least one section for a teacher deadline.', 'danger');
                return;
            }
        }

        try {
            const formData = new FormData(deadlineForm);
            const data = await fetchJson('api/deadline/save_deadline.php', {
                method: 'POST',
                body: formData
            });

            deadlineModal.hide();
            showAlert(data.message || 'Deadline saved.');
            await loadDeadlineList();
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    });

    btnOpenCreate.addEventListener('click', function () {
        resetDeadlineForm();
        deadlineModal.show();
    });

    btnRefresh.addEventListener('click', loadDeadlineList);

    btnRefreshTop.addEventListener('click', async function () {
        try {
            await loadDeadlineList();
            if (selectedDeadlineId) {
                await viewDeadlineDetails(selectedDeadlineId, selectedDeadlineTitle);
            }
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    });

    btnViewLocks.addEventListener('click', async function () {
        try {
            await loadLockedEntries();
            lockedEntriesModal.show();
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    });

    btnRemindAllTeachers.addEventListener('click', function () {
        if (!selectedDeadlineId) return;
        sendReminderAll(selectedDeadlineId, 'teacher');
    });

    btnRemindAllAdvisers.addEventListener('click', function () {
        if (!selectedDeadlineId) return;
        sendReminderAll(selectedDeadlineId, 'adviser');
    });

    filterSchoolYear.addEventListener('change', async function () {
        clearComplianceSelection();
        await loadDeadlineList();
    });

    filterQuarter.addEventListener('change', async function () {
        clearComplianceSelection();
        await loadDeadlineList();
    });

    window.viewDeadlineDetails = viewDeadlineDetails;
    window.openEditDeadline = openEditDeadline;
    window.deleteDeadline = deleteDeadline;
    window.sendReminderAll = sendReminderAll;
    window.sendTeacherReminder = sendTeacherReminder;
    window.sendAdviserReminder = sendAdviserReminder;
    window.unlockLockedEntry = unlockLockedEntry;

    (async function initPage() {
        toggleSectionVisibility();
        clearComplianceSelection();

        try {
            await loadDeadlineList();
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    })();
</script>
</body>
</html>
