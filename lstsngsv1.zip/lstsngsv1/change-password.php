<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: /lstsngsv1/login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password - St. Theresa's School of Novaliches</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="css/system-alerts.css">
    <script src="js/system-alerts.js"></script>

    <style>
        :root {
            --maroon: #9e112d;
            --maroon-dark: #7d0d24;
            --gold: #d4a72c;
            --navy: #173b67;
            --white: #ffffff;
            --text: #2b2b2b;
            --muted: #777;
            --border: #e6d9dc;
            --input-bg: rgba(255, 255, 255, 0.92);
            --danger-bg: #fff1f3;
            --danger-border: #f3c3cb;
            --danger-text: #8a1830;
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f7f6;
        }

        .main-wrapper {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }

        .password-card {
            width: 100%;
            max-width: 450px;
            background: rgba(255, 255, 255, 0.97);
            border-radius: 22px;
            padding: 40px;
            box-shadow: 0 22px 50px rgba(0, 0, 0, 0.18);
            border: 1px solid rgba(255, 255, 255, 0.5);
        }

        .brand {
            text-align: center;
            margin-bottom: 28px;
        }

        .brand-logo {
            width: 68px;
            height: 68px;
            margin: 0 auto 12px;
            border-radius: 15px;
            background: linear-gradient(145deg, #fff, #f7efef);
            border: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 8px 18px rgba(158, 17, 45, 0.07);
        }

        .brand-logo img {
            width: 44px;
            height: 44px;
            object-fit: contain;
        }

        .brand h1 {
            margin: 0;
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--maroon);
        }

        .brand p {
            margin: 6px 0 0;
            font-size: .88rem;
            color: var(--muted);
        }

        .error-box {
            display: flex;
            gap: 10px;
            align-items: flex-start;
            background: var(--danger-bg);
            border: 1px solid var(--danger-border);
            color: var(--danger-text);
            border-radius: 14px;
            padding: 12px 13px;
            margin-bottom: 16px;
            font-size: .88rem;
        }

        .hint-box {
            background: #fff8eb;
            border: 1px solid #f1dfb6;
            color: #7a5d23;
            border-radius: 14px;
            padding: 12px 13px;
            margin-bottom: 18px;
            font-size: .84rem;
            line-height: 1.55;
        }

        .requirements {
            background: #fafafa;
            border: 1px solid #eaeaea;
            border-radius: 11px;
            padding: 12px;
            margin: -4px 0 18px;
            font-size: .76rem;
        }

        .requirement {
            display: flex;
            align-items: center;
            gap: 6px;
            margin: 5px 0;
            color: #999;
        }

        .requirement.met { color: #198754; }
        .requirement.unmet { color: var(--maroon); }

        .form-group {
            margin-bottom: 15px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-size: .9rem;
            font-weight: 700;
            color: #56494b;
        }

        .input-wrap {
            position: relative;
        }

        .input-icon {
            position: absolute;
            top: 50%;
            left: 14px;
            transform: translateY(-50%);
            color: #9a8d8f;
            font-size: .95rem;
        }

        .form-control {
            width: 100%;
            height: 46px;
            border: 1.5px solid var(--border);
            border-radius: 11px;
            background: var(--input-bg);
            padding: 0 44px 0 42px;
            font-family: inherit;
            font-size: .93rem;
            color: var(--text);
            outline: none;
            transition: .18s ease;
        }

        .form-control:focus {
            border-color: rgba(158, 17, 45, .45);
            box-shadow: 0 0 0 4px rgba(158, 17, 45, 0.08);
            background: #fff;
        }

        .toggle-password {
            position: absolute;
            top: 50%;
            right: 13px;
            transform: translateY(-50%);
            background: transparent;
            border: none;
            color: #988b8d;
            cursor: pointer;
            padding: 0;
            font-size: 1rem;
        }

        .helper-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            flex-wrap: wrap;
            margin: 6px 0 18px;
        }

        .match-text {
            min-height: 18px;
            font-size: .82rem;
            font-weight: 600;
        }

        .match-ok {
            color: #198754;
        }

        .match-bad {
            color: var(--maroon);
        }

        .submit-btn {
            width: 100%;
            height: 46px;
            border: none;
            border-radius: 11px;
            background: linear-gradient(135deg, var(--maroon), var(--maroon-dark));
            color: var(--white);
            font-family: inherit;
            font-size: .95rem;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 8px 20px rgba(158, 17, 45, 0.18);
            transition: .15s ease;
        }

        .submit-btn:hover:not(:disabled) {
            transform: translateY(-1px);
            box-shadow: 0 10px 24px rgba(158, 17, 45, 0.25);
        }

        .submit-btn:disabled { opacity: .55; cursor: not-allowed; box-shadow: none; transform: none; }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 22px;
            color: var(--maroon);
            text-decoration: none;
            font-weight: 600;
            font-size: .88rem;
        }

        .back-link:hover { text-decoration: underline; }

        @media (max-width: 480px) {
            .main-wrapper {
                padding: 16px;
            }

            .password-card {
                padding: 24px 18px 20px;
                border-radius: 18px;
            }

            .brand h1 {
                font-size: 1.65rem;
            }

            .brand-logo {
                width: 68px;
                height: 68px;
            }

            .brand-logo img {
                width: 44px;
                height: 44px;
            }

            .form-control,
            .submit-btn {
                height: 52px;
            }
        }
    </style>
</head>
<body class="login-page">
    <div class="main-wrapper">
        <div class="password-card">
            <div class="brand">
                <div class="brand-logo">
                    <img src="assets/img/stsn logo.png" alt="STSN Logo">
                </div>
                <h1>Change Password</h1>
                <p>Create a password for your account before continuing.</p>
            </div>

            <?php if (isset($_GET['error']) && $_GET['error'] !== ''): ?>
                <div class="error-box">
                    <i class="bi bi-exclamation-octagon-fill mt-1"></i>
                    <div><?php echo htmlspecialchars($_GET['error']); ?></div>
                </div>
            <?php endif; ?>

            <div class="hint-box">
                Password must be 8+ characters with uppercase, lowercase, number, and special character. Avoid sequential patterns like abc or 123.
            </div>

            <form action="api/login/process_change_password.php" method="post" id="changePasswordForm" novalidate>
                <div class="form-group">
                    <label class="form-label" for="new_password">New Password</label>
                    <div class="input-wrap">
                        <i class="bi bi-lock-fill input-icon"></i>
                        <input
                            type="password"
                            class="form-control"
                            name="new_password"
                            id="new_password"
                            placeholder="Enter new password"
                            required
                            minlength="8"
                            autofocus
                        >
                        <button type="button" class="toggle-password" data-target="new_password">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                </div>

                <div class="requirements" aria-live="polite">
                    <div class="requirement" id="req-length"><i class="bi bi-circle"></i> At least 8 characters</div>
                    <div class="requirement" id="req-upper"><i class="bi bi-circle"></i> One uppercase letter</div>
                    <div class="requirement" id="req-lower"><i class="bi bi-circle"></i> One lowercase letter</div>
                    <div class="requirement" id="req-number"><i class="bi bi-circle"></i> One number</div>
                    <div class="requirement" id="req-special"><i class="bi bi-circle"></i> One special character</div>
                    <div class="requirement" id="req-noseq"><i class="bi bi-circle"></i> No sequential pattern</div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="confirm_password">Confirm Password</label>
                    <div class="input-wrap">
                        <i class="bi bi-shield-check input-icon"></i>
                        <input
                            type="password"
                            class="form-control"
                            name="confirm_password"
                            id="confirm_password"
                            placeholder="Confirm new password"
                            required
                            minlength="8"
                        >
                        <button type="button" class="toggle-password" data-target="confirm_password">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                </div>

                <div class="helper-row">
                    <div id="matchText" class="match-text"></div>
                </div>

                <button type="submit" class="submit-btn" id="submitBtn" disabled>
                    UPDATE PASSWORD <i class="bi bi-arrow-right ms-1"></i>
                </button>
            </form>

            <a href="login.php" class="back-link"><i class="bi bi-arrow-left"></i> Back to Login</a>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const newPassword = document.getElementById('new_password');
            const confirmPassword = document.getElementById('confirm_password');
            const matchText = document.getElementById('matchText');
            const form = document.getElementById('changePasswordForm');
            const submitBtn = document.getElementById('submitBtn');
            const requirements = {
                length: { elem: document.getElementById('req-length'), test: password => password.length >= 8 },
                upper: { elem: document.getElementById('req-upper'), test: password => /[A-Z]/.test(password) },
                lower: { elem: document.getElementById('req-lower'), test: password => /[a-z]/.test(password) },
                number: { elem: document.getElementById('req-number'), test: password => /[0-9]/.test(password) },
                special: { elem: document.getElementById('req-special'), test: password => /[!@#$%^&*()_\-+=\[\]{};:'",.<>?\/\\|`~]/.test(password) },
                noseq: { elem: document.getElementById('req-noseq'), test: password => checkSequential(password) }
            };

            function checkSequential(password) {
                const sequence = 'abcdefghijklmnopqrstuvwxyz0123456789';
                const value = password.toLowerCase();
                for (let i = 0; i < value.length - 2; i++) {
                    const part = value.substring(i, i + 3);
                    if (sequence.includes(part) || sequence.includes(part.split('').reverse().join(''))) return false;
                }
                return true;
            }

            function updateRequirement(requirement, state) {
                const icon = requirement.elem.querySelector('i');
                requirement.elem.classList.remove('met', 'unmet');
                if (state === null) {
                    icon.className = 'bi bi-circle';
                    return;
                }
                requirement.elem.classList.add(state ? 'met' : 'unmet');
                icon.className = state ? 'bi bi-check-circle-fill' : 'bi bi-x-circle-fill';
            }

            function updateRequirements() {
                const password = newPassword.value;
                const hasInput = password.length > 0;
                let allMet = true;
                Object.values(requirements).forEach(requirement => {
                    const state = hasInput ? requirement.test(password) : null;
                    updateRequirement(requirement, state);
                    allMet = allMet && state === true;
                });
                submitBtn.disabled = !(allMet && password === confirmPassword.value && password.length > 0);
            }

            function updateMatchStatus() {
                const a = newPassword.value;
                const b = confirmPassword.value;

                matchText.textContent = '';
                matchText.className = 'match-text';

                if (!a || !b) return;

                if (a === b) {
                    matchText.textContent = 'Passwords match';
                    matchText.classList.add('match-ok');
                } else {
                    matchText.textContent = 'Passwords do not match';
                    matchText.classList.add('match-bad');
                }
                updateRequirements();
            }

            document.querySelectorAll('.toggle-password').forEach(button => {
                button.addEventListener('click', function () {
                    const target = document.getElementById(this.dataset.target);
                    const icon = this.querySelector('i');
                    const show = target.type === 'password';

                    target.type = show ? 'text' : 'password';
                    icon.className = show ? 'bi bi-eye-slash' : 'bi bi-eye';

                });
            });

            newPassword.addEventListener('input', updateMatchStatus);
            confirmPassword.addEventListener('input', updateMatchStatus);
            newPassword.addEventListener('input', updateRequirements);
            confirmPassword.addEventListener('input', updateRequirements);
            updateRequirements();

            form.addEventListener('submit', function (e) {
                const passwordValue = newPassword.value.trim();
                const allMet = Object.values(requirements).every(requirement => requirement.test(passwordValue));

                if (!allMet) {
                    e.preventDefault();
                    SystemAlerts.show('Password must be 8+ characters with uppercase, lowercase, number, and special character. Avoid sequential patterns like abc or 123.', 'error');
                    newPassword.focus();
                    return;
                }

                if (newPassword.value !== confirmPassword.value) {
                    e.preventDefault();
                    SystemAlerts.show('Passwords do not match.', 'error');
                    confirmPassword.focus();
                }
            });
        });
    </script>
</body>
</html>
