<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: /lstsngsv1/login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password - St. Theresa's School of Novaliches</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="css/login.css">

    <style>
        :root {
            --maroon: #9e112d;
            --maroon-dark: #7d0d24;
            --gold: #d4a72c;
            --navy: #173b67;
            --white: #ffffff;
            --text: #2b2b2b;
            --muted: #777;
            --border: #e6d9dc;
            --input-bg: rgba(255, 255, 255, 0.92);
            --danger-bg: #fff1f3;
            --danger-border: #f3c3cb;
            --danger-text: #8a1830;
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
        }

        .main-wrapper {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }

        .password-card {
            width: 100%;
            max-width: 430px;
            background: rgba(255, 255, 255, 0.96);
            border-radius: 22px;
            padding: 30px 26px 24px;
            box-shadow: 0 22px 60px rgba(0, 0, 0, 0.22);
            border: 1px solid rgba(255, 255, 255, 0.45);
            backdrop-filter: blur(6px);
        }

        .brand {
            text-align: center;
            margin-bottom: 20px;
        }

        .brand-logo {
            width: 76px;
            height: 76px;
            margin: 0 auto 14px;
            border-radius: 18px;
            background: linear-gradient(145deg, #fff, #f7efef);
            border: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 10px 22px rgba(158, 17, 45, 0.08);
        }

        .brand-logo img {
            width: 50px;
            height: 50px;
            object-fit: contain;
        }

        .brand h1 {
            margin: 0;
            font-size: 1.9rem;
            font-weight: 800;
            color: var(--maroon);
            line-height: 1.1;
        }

        .brand p {
            margin: 8px auto 0;
            max-width: 300px;
            font-size: .93rem;
            line-height: 1.6;
            color: var(--muted);
        }

        .school-name {
            margin-top: 10px;
            font-size: .8rem;
            font-weight: 700;
            color: var(--navy);
            text-transform: uppercase;
            letter-spacing: .04em;
        }

        .error-box {
            display: flex;
            gap: 10px;
            align-items: flex-start;
            background: var(--danger-bg);
            border: 1px solid var(--danger-border);
            color: var(--danger-text);
            border-radius: 14px;
            padding: 12px 13px;
            margin-bottom: 16px;
            font-size: .88rem;
        }

        .hint-box {
            background: #fff8eb;
            border: 1px solid #f1dfb6;
            color: #7a5d23;
            border-radius: 14px;
            padding: 12px 13px;
            margin-bottom: 18px;
            font-size: .84rem;
            line-height: 1.55;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-size: .9rem;
            font-weight: 700;
            color: #56494b;
        }

        .input-wrap {
            position: relative;
        }

        .input-icon {
            position: absolute;
            top: 50%;
            left: 14px;
            transform: translateY(-50%);
            color: #9a8d8f;
            font-size: .95rem;
        }

        .form-control {
            width: 100%;
            height: 54px;
            border: 1px solid var(--border);
            border-radius: 15px;
            background: var(--input-bg);
            padding: 0 44px 0 42px;
            font-family: inherit;
            font-size: .95rem;
            color: var(--text);
            outline: none;
            transition: .18s ease;
        }

        .form-control:focus {
            border-color: rgba(158, 17, 45, .45);
            box-shadow: 0 0 0 4px rgba(158, 17, 45, 0.08);
            background: #fff;
        }

        .toggle-password {
            position: absolute;
            top: 50%;
            right: 13px;
            transform: translateY(-50%);
            background: transparent;
            border: none;
            color: #988b8d;
            cursor: pointer;
            padding: 0;
            font-size: 1rem;
        }

        .helper-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            flex-wrap: wrap;
            margin: 6px 0 18px;
        }

        .show-pass {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: .88rem;
            color: var(--muted);
            user-select: none;
        }

        .show-pass input {
            width: 16px;
            height: 16px;
            accent-color: var(--maroon);
        }

        .match-text {
            min-height: 18px;
            font-size: .82rem;
            font-weight: 600;
        }

        .match-ok {
            color: #198754;
        }

        .match-bad {
            color: var(--maroon);
        }

        .submit-btn {
            width: 100%;
            height: 54px;
            border: none;
            border-radius: 15px;
            background: linear-gradient(135deg, var(--maroon), var(--maroon-dark));
            color: var(--white);
            font-family: inherit;
            font-size: .94rem;
            font-weight: 800;
            letter-spacing: .02em;
            cursor: pointer;
            box-shadow: 0 14px 28px rgba(158, 17, 45, 0.22);
            transition: .18s ease;
        }

        .submit-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 16px 32px rgba(158, 17, 45, 0.26);
        }

        @media (max-width: 480px) {
            .main-wrapper {
                padding: 16px;
            }

            .password-card {
                padding: 24px 18px 20px;
                border-radius: 18px;
            }

            .brand h1 {
                font-size: 1.65rem;
            }

            .brand-logo {
                width: 68px;
                height: 68px;
            }

            .brand-logo img {
                width: 44px;
                height: 44px;
            }

            .form-control,
            .submit-btn {
                height: 52px;
            }
        }
    </style>
</head>
<body>
    <div class="main-wrapper">
        <div class="password-card">
            <div class="brand">
                <div class="brand-logo">
                    <img src="assets/img/stsn logo.png" alt="STSN Logo">
                </div>
                <h1>Change Password</h1>
                <p>Create a password for your account before continuing.</p>
                <div class="school-name">St. Theresa's School of Novaliches</div>
            </div>

            <?php if (isset($_GET['error']) && $_GET['error'] !== ''): ?>
                <div class="error-box">
                    <i class="bi bi-exclamation-octagon-fill mt-1"></i>
                    <div><?php echo htmlspecialchars($_GET['error']); ?></div>
                </div>
            <?php endif; ?>

            <div class="hint-box">
                Password must be at least 6 characters long.
            </div>

            <form action="api/login/process_change_password.php" method="post" id="changePasswordForm" novalidate>
                <div class="form-group">
                    <label class="form-label" for="new_password">New Password</label>
                    <div class="input-wrap">
                        <i class="bi bi-lock-fill input-icon"></i>
                        <input
                            type="password"
                            class="form-control"
                            name="new_password"
                            id="new_password"
                            placeholder="Enter new password"
                            required
                            minlength="6"
                            autofocus
                        >
                        <button type="button" class="toggle-password" data-target="new_password">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="confirm_password">Confirm Password</label>
                    <div class="input-wrap">
                        <i class="bi bi-shield-check input-icon"></i>
                        <input
                            type="password"
                            class="form-control"
                            name="confirm_password"
                            id="confirm_password"
                            placeholder="Confirm new password"
                            required
                            minlength="6"
                        >
                        <button type="button" class="toggle-password" data-target="confirm_password">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                </div>

                <div class="helper-row">
                    <label class="show-pass">
                        <input type="checkbox" id="showAllPass">
                        <span>Show password</span>
                    </label>
                    <div id="matchText" class="match-text"></div>
                </div>

                <button type="submit" class="submit-btn">
                    UPDATE PASSWORD <i class="bi bi-arrow-right ms-1"></i>
                </button>
            </form>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const newPassword = document.getElementById('new_password');
            const confirmPassword = document.getElementById('confirm_password');
            const showAllPass = document.getElementById('showAllPass');
            const matchText = document.getElementById('matchText');
            const form = document.getElementById('changePasswordForm');

            function updateMatchStatus() {
                const a = newPassword.value;
                const b = confirmPassword.value;

                matchText.textContent = '';
                matchText.className = 'match-text';

                if (!a || !b) return;

                if (a === b) {
                    matchText.textContent = 'Passwords match';
                    matchText.classList.add('match-ok');
                } else {
                    matchText.textContent = 'Passwords do not match';
                    matchText.classList.add('match-bad');
                }
            }

            showAllPass.addEventListener('change', function () {
                const type = this.checked ? 'text' : 'password';
                newPassword.type = type;
                confirmPassword.type = type;

                document.querySelectorAll('.toggle-password i').forEach(icon => {
                    icon.className = this.checked ? 'bi bi-eye-slash' : 'bi bi-eye';
                });
            });

            document.querySelectorAll('.toggle-password').forEach(button => {
                button.addEventListener('click', function () {
                    const target = document.getElementById(this.dataset.target);
                    const icon = this.querySelector('i');
                    const show = target.type === 'password';

                    target.type = show ? 'text' : 'password';
                    icon.className = show ? 'bi bi-eye-slash' : 'bi bi-eye';

                    if (newPassword.type === 'text' && confirmPassword.type === 'text') {
                        showAllPass.checked = true;
                    } else if (newPassword.type === 'password' && confirmPassword.type === 'password') {
                        showAllPass.checked = false;
                    }
                });
            });

            newPassword.addEventListener('input', updateMatchStatus);
            confirmPassword.addEventListener('input', updateMatchStatus);

            form.addEventListener('submit', function (e) {
                if (newPassword.value.trim().length < 6) {
                    e.preventDefault();
                    alert('Password must be at least 6 characters long.');
                    newPassword.focus();
                    return;
                }

                if (newPassword.value !== confirmPassword.value) {
                    e.preventDefault();
                    alert('Passwords do not match.');
                    confirmPassword.focus();
                }
            });
        });
    </script>
</body>
</html>