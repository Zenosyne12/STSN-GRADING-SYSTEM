<?php
require_once 'includes/auth.php';
requireAdmin();
require_once 'api/shared/db_connect.php';

function h($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}
$gradeLevels = [];
try {
    $stmt = $pdo->query("SELECT id, grade_level_name FROM tblgradelevel ORDER BY id ASC");
    $gradeLevels = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $gradeLevels = [];
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Scheduling</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        body {
            background: #f3f7fd;
        }

        .ay-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }

        .ay-page-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 0.2rem;
            letter-spacing: 0.01em;
        }

        .ay-page-header p {
            margin: 0;
            font-size: 0.88rem;
            opacity: 0.85;
        }

        .ay-active-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            background: rgba(255, 255, 255, 0.15);
            border: 1.5px solid rgba(255, 255, 255, 0.3);
            border-radius: 999px;
            padding: 0.45rem 1rem;
            font-size: 0.88rem;
            font-weight: 700;
            color: #fff;
            white-space: nowrap;
        }

        .ay-card {
            background: #fff;
            border: 1px solid #dce8f8;
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18, 72, 168, 0.06);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }

        .ay-card-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid #e8f0fb;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
            background: #fff;
        }

        .ay-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: #132f62;
            margin: 0 0 0.15rem;
        }

        .ay-card-subtitle {
            font-size: 0.8rem;
            color: #7a93b8;
            margin: 0;
        }

        .ay-toolbar {
            display: flex;
            gap: 0.6rem;
            flex-wrap: wrap;
            align-items: center;
        }

        .ay-card-body {
            padding: 0;
        }

        .ay-card-footer {
            padding: 0.85rem 1.2rem;
            border-top: 1px solid #e8f0fb;
            background: #fafcff;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 0.75rem;
        }

        .ay-footer-meta {
            font-size: 0.84rem;
            color: #6f87ab;
            font-weight: 600;
        }

        .ay-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
        }

        .ay-table thead th {
            background: #f4f8ff;
            color: #3b5e96;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 0.85rem 1rem;
            border-bottom: 1.5px solid #dce8f8;
            white-space: nowrap;
            text-align: center;
        }

        .ay-table tbody tr:not(:last-child) td {
            border-bottom: 1px solid #f0f5fc;
        }

        .ay-table tbody tr:hover td {
            background: #f7fbff;
        }

        .ay-table tbody td {
            padding: 0.9rem 1rem;
            font-size: 0.93rem;
            color: #213a5e;
            vertical-align: middle;
            text-align: center;
        }

        .ay-left {
            text-align: left !important;
        }

        .row-num {
            color: #a0b4cc;
            font-size: 0.82rem;
            font-weight: 600;
        }

        .year-label {
            font-weight: 700;
            color: #132f62;
        }

        .ay-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.32rem 0.75rem;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }

        .ay-badge-active {
            background: #e6f0ff;
            color: #1248a8;
            border: 1.5px solid #b8d0fa;
        }

        .ay-badge-inactive {
            background: #f3f5f8;
            color: #7a8ea8;
            border: 1.5px solid #dde4ee;
        }

        /* â”€â”€ Strand badges â”€â”€ */
        .ay-strand-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.3rem 0.7rem;
            border-radius: 999px;
            font-size: 0.75rem;
            font-weight: 700;
            letter-spacing: 0.04em;
            white-space: nowrap;
        }
        .ay-strand-STEM    { background:#e8f4ff; color:#0a4fa8; border:1.5px solid #a8ccf0; }
        .ay-strand-ABM     { background:#fff3e8; color:#9a4200; border:1.5px solid #f0c8a8; }
        .ay-strand-HUMSS   { background:#f3e8ff; color:#6a0a9a; border:1.5px solid #d0a8f0; }
        .ay-strand-TVLICT  { background:#e8fff3; color:#0a6e3a; border:1.5px solid #a8d8b8; }
        .ay-strand-none    { background:#f3f5f8; color:#9aabb8; border:1.5px solid #dde4ee; font-style:italic; }

        .btn-ay {
            font-weight: 600;
            font-size: 0.82rem;
            border-radius: 8px;
            padding: 0.42rem 0.9rem;
            cursor: pointer;
            transition: background 0.15s, border-color 0.15s, color 0.15s, box-shadow 0.15s;
            border: 1.5px solid transparent;
            line-height: 1.4;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: .35rem;
        }

        .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            border-color: transparent;
            box-shadow: 0 2px 8px rgba(26, 110, 245, 0.2);
        }

        .btn-ay-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
        }

        .ay-empty {
            text-align: center;
            padding: 2.5rem 1.5rem;
            color: #9ab0c8;
        }

        .ay-empty i {
            font-size: 2.2rem;
            display: block;
            margin-bottom: 0.6rem;
            opacity: 0.5;
        }

        .ay-empty p {
            margin: 0;
            font-size: 0.95rem;
        }

        .ay-mobile-card {
            background: #fff;
            border: 1.5px solid #dce8f8;
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 1px 6px rgba(18, 72, 168, 0.05);
        }

        .ay-mobile-card + .ay-mobile-card {
            margin-top: 0.75rem;
        }

        .ay-mobile-card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.85rem 1rem;
            border-bottom: 1px solid #edf3fc;
            background: #f9fbff;
            gap: .75rem;
        }

        .ay-mobile-card-title {
            font-weight: 700;
            color: #132f62;
            font-size: 0.95rem;
        }

        .ay-mobile-card-body {
            padding: 0.85rem 1rem;
        }

        .ay-mobile-row {
            display: flex;
            justify-content: space-between;
            gap: .75rem;
            padding: .2rem 0;
            font-size: .9rem;
        }

        .ay-mobile-label {
            color: #7a93b8;
            font-weight: 600;
        }

        .ay-mobile-actions {
            display: grid;
            gap: .5rem;
            padding: 0 1rem 1rem;
        }

        .ay-pagination {
            display: flex;
            gap: 0.3rem;
            list-style: none;
            margin: 0;
            padding: 0;
            justify-content: flex-end;
            flex-wrap: wrap;
        }

        .ay-pagination .ay-page-item .ay-page-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
            border-radius: 7px;
            font-size: 0.83rem;
            font-weight: 600;
            cursor: pointer;
            border: 1.5px solid #dce8f8;
            color: #1a6ef5;
            background: #fff;
            transition: all 0.13s;
            padding: 0 0.5rem;
            text-decoration: none;
        }

        .ay-pagination .ay-page-item .ay-page-link:hover {
            background: #eef4ff;
            border-color: #9cc2fc;
        }

        .ay-pagination .ay-page-item.active .ay-page-link {
            background: #1a6ef5;
            border-color: #1a6ef5;
            color: #fff;
        }

        .ay-pagination .ay-page-item.disabled .ay-page-link {
            background: #f8fbff;
            border-color: #e2ebf8;
            color: #9ab0c8;
            cursor: not-allowed;
            pointer-events: none;
        }

        @media (max-width: 767.98px) {
            .ay-page-header {
                padding: 1.1rem 1.2rem;
                border-radius: 14px;
            }

            .ay-card-footer {
                flex-direction: column;
                align-items: stretch;
            }

            .ay-footer-meta {
                text-align: center;
            }

            .ay-pagination {
                justify-content: center;
            }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3">

                <div class="ay-page-header">
                    <div>
                        <h3><i class="bi bi-calendar-week me-2"></i>Section Scheduling</h3>
                        <p>Manage and set Schedules to Sections.</p>
                    </div>
                    <div class="ay-active-chip">
                        <i class="bi bi-calendar3"></i>
                        Scheduling Directory
                    </div>
                </div>

                <div class="ay-card">
                    <div class="ay-card-header">
                        <div>
                            <p class="ay-card-title">Section List</p>
                            <p class="ay-card-subtitle">Filter by grade level and open a section to manage its schedule.</p>
                        </div>

                        <div class="ay-toolbar">
                            <select class="form-select form-select-sm" id="gradeLevelFilter" style="min-width:180px; border-radius:10px; border:1.5px solid #dce8f8;">
                                <option value="">All Grade Levels</option>
                                <?php foreach ($gradeLevels as $gl): ?>
                                    <option value="<?= h($gl['id']) ?>"><?= h($gl['grade_level_name']) ?></option>
                                <?php endforeach; ?>
                            </select>

                            <div class="input-group input-group-sm" style="min-width:220px;">
                                <span class="input-group-text bg-white" style="border:1.5px solid #dce8f8; border-right:0;"><i class="bi bi-search"></i></span>
                                <input class="form-control" type="search" id="searchInput" placeholder="Search section..." style="border:1.5px solid #dce8f8; border-left:0;">
                            </div>
                        </div>
                    </div>

                    <div class="ay-card-body">
                        <div class="d-none d-md-block">
                            <table class="ay-table" id="sectionTable">
                                <thead>
                                    <tr>
                                        <th style="width:50px;">#</th>
                                        <th>Grade Level</th>
                                        <th>Section Name</th>
                                        <th style="width:130px;">Strand</th>
                                        <th style="width:120px;">Status</th>
                                        <th style="width:170px;">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="sectionTableBody">
                                    <tr>
                                        <td colspan="6">
                                            <div class="ay-empty">
                                                <i class="bi bi-hourglass-split"></i>
                                                <p>Loading sections...</p>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="d-block d-md-none p-3" id="sectionCardView"></div>
                    </div>

                    <div class="ay-card-footer">
                        <div class="ay-footer-meta" id="paginationInfo">Showing 0 to 0 of 0 sections</div>
                        <ul class="ay-pagination" id="pagination"></ul>
                    </div>
                </div>

            </div>
        </div>
    </main>

    <?php require_once("includes/footer.php"); ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="./js/sweet-alerts.js"></script>
<script>
function esc(str) {
    return (str ?? '').toString()
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function showAlert(message, type = 'success') {
    const config = {
        success: { title: 'Success', color: 'blue', icon: 'bi bi-check-circle-fill' },
        danger:  { title: 'Error',   color: 'red',  icon: 'bi bi-exclamation-octagon-fill' },
        warning: { title: 'Warning', color: 'yellow', icon: 'bi bi-exclamation-triangle-fill' },
        info:    { title: 'Info',    color: 'blue',  icon: 'bi bi-info-circle-fill' }
    };
    const selected = config[type] || config.success;
    iziToast.show({
        title: selected.title, message, color: selected.color, icon: selected.icon,
        iconColor: '#fff', theme: 'light', position: 'topRight', timeout: 4000,
        progressBar: true, close: true, pauseOnHover: true, drag: true,
        transitionIn: 'fadeInDown', transitionOut: 'fadeOutUp', maxWidth: 420
    });
}

async function fetchJson(url, options = {}) {
    const res  = await fetch(url, options);
    const text = await res.text();
    try { return JSON.parse(text); }
    catch (e) { console.error('Invalid JSON:', url, text); throw new Error('Invalid server response'); }
}

/* â”€â”€ Strand badge renderer â”€â”€ */
const STRAND_MAP = {
    'STEM':    { cls: 'ay-strand-STEM',   icon: 'bi-atom',           label: 'STEM'    },
    'ABM':     { cls: 'ay-strand-ABM',    icon: 'bi-bar-chart-fill', label: 'ABM'     },
    'HUMSS':   { cls: 'ay-strand-HUMSS',  icon: 'bi-people-fill',    label: 'HUMSS'   },
    'TVL-ICT': { cls: 'ay-strand-TVLICT', icon: 'bi-cpu-fill',       label: 'TVL-ICT' },
};

function strandBadge(strand, gradeLevelName) {
    // Only show for SHS (Grade 11 / Grade 12)
    const gl = (gradeLevelName || '').toLowerCase();
    const isSHS = gl.includes('grade 11') || gl.includes('grade 12');
    if (!isSHS) return '<span style="color:#c8d8e8; font-size:.8rem;">—</span>';

    const s = (strand || '').trim().toUpperCase().replace('-', '-'); // normalize
    const key = Object.keys(STRAND_MAP).find(k => k.toUpperCase() === s);
    if (key) {
        const m = STRAND_MAP[key];
        return `<span class="ay-strand-badge ${m.cls}"><i class="bi ${m.icon}"></i>${m.label}</span>`;
    }
    return `<span class="ay-strand-badge ay-strand-none"><i class="bi bi-dash-circle"></i>No Strand</span>`;
}

let currentPage  = 1;
const itemsPerPage = 5;
let allSections  = [];

function getTotalPages() {
    return Math.max(1, Math.ceil(allSections.length / itemsPerPage));
}

function changePage(page) {
    const totalPages = getTotalPages();
    if (page < 1 || page > totalPages || page === currentPage) return;
    currentPage = page;
    renderSections();
}

function renderPagination(totalItems) {
    const pagination = document.getElementById('pagination');
    const totalPages = getTotalPages();
    if (!totalItems || totalPages <= 1) { pagination.innerHTML = ''; return; }

    let html = `
        <li class="ay-page-item ${currentPage === 1 ? 'disabled' : ''}">
            <a class="ay-page-link" href="#" onclick="changePage(${currentPage - 1}); return false;">Previous</a>
        </li>`;
    for (let n = 1; n <= totalPages; n++) {
        html += `
        <li class="ay-page-item ${n === currentPage ? 'active' : ''}">
            <a class="ay-page-link" href="#" onclick="changePage(${n}); return false;">${n}</a>
        </li>`;
    }
    html += `
        <li class="ay-page-item ${currentPage === totalPages ? 'disabled' : ''}">
            <a class="ay-page-link" href="#" onclick="changePage(${currentPage + 1}); return false;">Next</a>
        </li>`;
    pagination.innerHTML = html;
}

function updatePaginationInfo(totalItems, start, end) {
    document.getElementById('paginationInfo').textContent = totalItems
        ? `Showing ${start} to ${end} of ${totalItems} sections`
        : 'Showing 0 to 0 of 0 sections';
}

function renderSections() {
    const tableBody = document.getElementById('sectionTableBody');
    const cardView  = document.getElementById('sectionCardView');
    const totalPages = getTotalPages();
    if (currentPage > totalPages) currentPage = totalPages;

    const startIndex = (currentPage - 1) * itemsPerPage;
    const list       = allSections.slice(startIndex, startIndex + itemsPerPage);
    const startDisplay = allSections.length ? startIndex + 1 : 0;
    const endDisplay   = allSections.length ? startIndex + list.length : 0;

    /* â”€â”€ Desktop table â”€â”€ */
    tableBody.innerHTML = list.length ? list.map((s, i) => `
        <tr>
            <td><span class="row-num">${startIndex + i + 1}</span></td>
            <td>${esc(s.grade_level_name || '-')}</td>
            <td class="ay-left"><span class="year-label">${esc(s.section_name || '-')}</span></td>
            <td>${strandBadge(s.strand, s.grade_level_name)}</td>
            <td>
                ${String(s.is_active) === '1'
                    ? `<span class="ay-badge ay-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                    : `<span class="ay-badge ay-badge-inactive">Inactive</span>`}
            </td>
            <td>
                <a href="schedule_manage.php?section_id=${encodeURIComponent(s.id)}" class="btn-ay btn-ay-primary">
                    <i class="bi bi-calendar3"></i> Manage
                </a>
            </td>
        </tr>
    `).join('') : `
        <tr><td colspan="6">
            <div class="ay-empty"><i class="bi bi-folder2-open"></i><p>No sections found.</p></div>
        </td></tr>`;

    /* â”€â”€ Mobile cards â”€â”€ */
    cardView.innerHTML = list.length ? list.map((s, i) => `
        <div class="ay-mobile-card">
            <div class="ay-mobile-card-header">
                <span class="ay-mobile-card-title">${startIndex + i + 1}. ${esc(s.section_name || '-')}</span>
                ${String(s.is_active) === '1'
                    ? `<span class="ay-badge ay-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                    : `<span class="ay-badge ay-badge-inactive">Inactive</span>`}
            </div>
            <div class="ay-mobile-card-body">
                <div class="ay-mobile-row">
                    <span class="ay-mobile-label">Grade Level</span>
                    <span>${esc(s.grade_level_name || '-')}</span>
                </div>
                <div class="ay-mobile-row">
                    <span class="ay-mobile-label">Strand</span>
                    <span>${strandBadge(s.strand, s.grade_level_name)}</span>
                </div>
            </div>
            <div class="ay-mobile-actions">
                <a href="schedule_manage.php?section_id=${encodeURIComponent(s.id)}" class="btn-ay btn-ay-primary">
                    <i class="bi bi-calendar3"></i> Manage
                </a>
            </div>
        </div>
    `).join('') : `
        <div class="ay-empty"><i class="bi bi-folder2-open"></i><p>No sections found.</p></div>`;

    updatePaginationInfo(allSections.length, startDisplay, endDisplay);
    renderPagination(allSections.length);
}

async function loadSections(resetPage = false) {
    try {
        if (resetPage) currentPage = 1;

        const search       = document.getElementById('searchInput').value.trim();
        const gradeLevelId = document.getElementById('gradeLevelFilter').value;

        let url = `api/schedule/sections.php?s=${encodeURIComponent(search)}`;
        if (gradeLevelId) url += `&grade_level_id=${encodeURIComponent(gradeLevelId)}`;

        const data  = await fetchJson(url);
        allSections = data.sections || data.data || [];
        renderSections();
    } catch (err) {
        console.error(err);
        showAlert('Failed to load sections: ' + err.message, 'danger');
    }
}

document.getElementById('searchInput').addEventListener('input', () => loadSections(true));
document.getElementById('gradeLevelFilter').addEventListener('change', () => loadSections(true));

loadSections();
</script>
</body>
</html>
