<?php
require_once 'includes/auth.php';
requireAdmin();
require_once 'api/shared/db_connect.php';

function h($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}
$gradeLevels = [];
try {
    $stmt = $pdo->query("SELECT id, grade_level_name FROM tblgradelevel ORDER BY id ASC");
    $gradeLevels = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $gradeLevels = [];
}
?>
<!doctype html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
    <meta charset="utf-8">
    <title>STSN Grading System | Scheduling</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        :root,
        [data-bs-theme="light"] {
            --ay-bg: #f3f7fd;
            --ay-card: #ffffff;
            --ay-card-soft: #fafcff;
            --ay-border: #dce8f8;
            --ay-border-soft: #e8f0fb;
            --ay-text: #213a5e;
            --ay-text-strong: #132f62;
            --ay-text-muted: #7a93b8;
            --ay-text-dim: #9ab0c8;
            --ay-head-bg: #f4f8ff;
            --ay-head-text: #3b5e96;
            --ay-row-hover: #f7fbff;
            --ay-row-border: #f0f5fc;
            --ay-shadow: rgba(18,72,168,.06);
            --ay-section-name: #132f62;
        }

        [data-bs-theme="dark"] {
            --ay-bg: #1a1a1a;
            --ay-card: #2D2D2D;
            --ay-card-soft: #262626;
            --ay-border: #3a3a3a;
            --ay-border-soft: #3a3a3a;
            --ay-text: #e4e6e8;
            --ay-text-strong: #ffffff;
            --ay-text-muted: #adb5bd;
            --ay-text-dim: #8b939a;
            --ay-head-bg: #2D2D2D;
            --ay-head-text: #ffffff;
            --ay-row-hover: #343434;
            --ay-row-border: #3a3a3a;
            --ay-shadow: rgba(0,0,0,.35);
            --ay-section-name: #ffffff;
        }

        body {
            background: var(--ay-bg);
        }

        .ay-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }

        .ay-page-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 0.2rem;
            letter-spacing: 0.01em;
        }

        .ay-page-header p {
            margin: 0;
            font-size: 0.88rem;
            opacity: 0.85;
        }

        .ay-active-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            background: rgba(255, 255, 255, 0.15);
            border: 1.5px solid rgba(255, 255, 255, 0.3);
            border-radius: 999px;
            padding: 0.45rem 1rem;
            font-size: 0.88rem;
            font-weight: 700;
            color: #fff;
            white-space: nowrap;
        }

        .ay-card {
            background: var(--ay-card);
            border: 1px solid var(--ay-border);
            border-radius: 16px;
            box-shadow: 0 2px 12px var(--ay-shadow);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }

        .ay-card-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid var(--ay-border-soft);
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
            background: var(--ay-card);
        }

        .ay-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: var(--ay-text-strong);
            margin: 0 0 0.15rem;
        }

        .ay-card-subtitle {
            font-size: 0.8rem;
            color: var(--ay-text-muted);
            margin: 0;
        }

        .ay-toolbar {
            display: flex;
            gap: 0.6rem;
            flex-wrap: wrap;
            align-items: center;
        }

        .ay-card-body {
            padding: 0;
        }

        .ay-card-footer {
            padding: 0.85rem 1.2rem;
            border-top: 1px solid var(--ay-border-soft);
            background: var(--ay-card-soft);
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 0.75rem;
        }

        .ay-footer-meta {
            font-size: 0.84rem;
            color: var(--ay-text-muted);
            font-weight: 600;
        }

        .ay-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
        }

        .ay-table thead th {
            background: var(--ay-head-bg);
            color: var(--ay-head-text);
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 0.85rem 1rem;
            border-bottom: 1.5px solid var(--ay-border);
            white-space: nowrap;
            text-align: center;
        }

        .ay-table tbody tr:not(:last-child) td {
            border-bottom: 1px solid var(--ay-row-border);
        }

        .ay-table tbody tr:hover td {
            background: var(--ay-row-hover);
        }

        .ay-table tbody td {
            padding: 0.9rem 1rem;
            font-size: 0.93rem;
            color: var(--ay-text);
            vertical-align: middle;
            text-align: center;
        }

        .ay-left {
            text-align: left !important;
        }
        .ay-section-name {
            text-align: center !important;
        }

        .row-num {
            color: var(--ay-text-dim);
            font-size: 0.82rem;
            font-weight: 600;
        }

        .year-label {
            font-weight: 700;
            color: var(--ay-section-name);
        }

        [data-bs-theme="dark"] .year-label,
        [data-bs-theme="dark"] .ay-table tbody td .year-label {
            color: #ffffff !important;
        }

        .ay-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.32rem 0.75rem;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }

        .ay-badge-active {
            background: #e6f0ff;
            color: #1248a8;
            border: 1.5px solid #b8d0fa;
        }

        .ay-badge-inactive {
            background: #f3f5f8;
            color: #7a8ea8;
            border: 1.5px solid #dde4ee;
        }

        [data-bs-theme="dark"] .ay-badge-active {
            background: #1e2a3d;
            color: #8ab4f8;
            border-color: #2d4366;
        }

        [data-bs-theme="dark"] .ay-badge-inactive {
            background: #3a3a3a;
            color: #a9b8cd;
            border-color: #4a5a6e;
        }

        /* TRACK / STRAND BADGES */
        .ay-strand-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.3rem 0.7rem;
            border-radius: 999px;
            font-size: 0.75rem;
            font-weight: 700;
            letter-spacing: 0.04em;
            white-space: nowrap;
        }
        .ay-strand-STEM    { background:#e8f4ff; color:#0a4fa8; border:1.5px solid #a8ccf0; }
        .ay-strand-ABM     { background:#fff3e8; color:#9a4200; border:1.5px solid #f0c8a8; }
        .ay-strand-HUMSS   { background:#f3e8ff; color:#6a0a9a; border:1.5px solid #d0a8f0; }
        .ay-strand-TVLICT  { background:#e8fff3; color:#0a6e3a; border:1.5px solid #a8d8b8; }
        .ay-track-academic { background:#eef4ff; color:#1248a8; border:1.5px solid #b8d0fa; }
        .ay-track-techpro  { background:#fff3e8; color:#9a4200; border:1.5px solid #f0c8a8; }
        .ay-strand-none    { background:#f3f5f8; color:#9aabb8; border:1.5px solid #dde4ee; font-style:italic; }

        [data-bs-theme="dark"] .ay-strand-STEM    { background:#1e2a3d; color:#8ab4f8; border-color:#2d4366; }
        [data-bs-theme="dark"] .ay-strand-ABM     { background:#3a2f14; color:#ffcc66; border-color:#5c4820; }
        [data-bs-theme="dark"] .ay-strand-HUMSS   { background:#2d1e42; color:#c4b5fd; border-color:#4c3670; }
        [data-bs-theme="dark"] .ay-strand-TVLICT  { background:#17351f; color:#6ee7a0; border-color:#2b5c38; }
        [data-bs-theme="dark"] .ay-track-academic { background:#1e2a3d; color:#8ab4f8; border-color:#2d4366; }
        [data-bs-theme="dark"] .ay-track-techpro  { background:#3a2f14; color:#ffcc66; border-color:#5c4820; }
        [data-bs-theme="dark"] .ay-strand-none    { background:#3a3a3a; color:#a9b8cd; border-color:#4a5a6e; }

        .btn-ay {
            font-weight: 600;
            font-size: 0.82rem;
            border-radius: 8px;
            padding: 0.42rem 0.9rem;
            cursor: pointer;
            transition: background 0.15s, border-color 0.15s, color 0.15s, box-shadow 0.15s;
            border: 1.5px solid transparent;
            line-height: 1.4;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: .35rem;
        }

        .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            border-color: transparent;
            box-shadow: 0 2px 8px rgba(26, 110, 245, 0.2);
        }

        .btn-ay-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
        }

        .ay-empty {
            text-align: center;
            padding: 2.5rem 1.5rem;
            color: var(--ay-text-dim);
        }

        .ay-empty i {
            font-size: 2.2rem;
            display: block;
            margin-bottom: 0.6rem;
            opacity: 0.5;
        }

        .ay-empty p {
            margin: 0;
            font-size: 0.95rem;
        }

        .ay-mobile-card {
            background: var(--ay-card);
            border: 1.5px solid var(--ay-border);
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 1px 6px var(--ay-shadow);
        }

        .ay-mobile-card + .ay-mobile-card {
            margin-top: 0.75rem;
        }

        .ay-mobile-card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.85rem 1rem;
            border-bottom: 1px solid var(--ay-border-soft);
            background: var(--ay-card-soft);
            gap: .75rem;
        }

        .ay-mobile-card-title {
            font-weight: 700;
            color: var(--ay-section-name);
            font-size: 0.95rem;
        }

        .ay-mobile-card-body {
            padding: 0.85rem 1rem;
        }

        .ay-mobile-row {
            display: flex;
            justify-content: space-between;
            gap: .75rem;
            padding: .2rem 0;
            font-size: .9rem;
            color: var(--ay-text);
        }

        .ay-mobile-label {
            color: var(--ay-text-muted);
            font-weight: 600;
        }

        .ay-mobile-actions {
            display: grid;
            gap: .5rem;
            padding: 0 1rem 1rem;
        }

        .ay-pagination {
            display: flex;
            gap: 0.3rem;
            list-style: none;
            margin: 0;
            padding: 0;
            justify-content: flex-end;
            flex-wrap: wrap;
        }

        .ay-pagination .ay-page-item .ay-page-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
            border-radius: 7px;
            font-size: 0.83rem;
            font-weight: 600;
            cursor: pointer;
            border: 1.5px solid var(--ay-border);
            color: #1a6ef5;
            background: var(--ay-card);
            transition: all 0.13s;
            padding: 0 0.5rem;
            text-decoration: none;
        }

        .ay-pagination .ay-page-item .ay-page-link:hover {
            background: var(--ay-row-hover);
            border-color: #9cc2fc;
        }

        [data-bs-theme="dark"] .ay-pagination .ay-page-item .ay-page-link {
            color: #7ab7ff;
        }

        .ay-pagination .ay-page-item.active .ay-page-link {
            background: #1a6ef5;
            border-color: #1a6ef5;
            color: #fff;
        }

        .ay-pagination .ay-page-item.disabled .ay-page-link {
            background: var(--ay-card-soft);
            border-color: var(--ay-border);
            color: var(--ay-text-dim);
            cursor: not-allowed;
            pointer-events: none;
        }

        /* Form controls (dark mode support) */
        .form-select,
        .form-control {
            color: var(--ay-text);
            background-color: var(--ay-card);
            border-color: var(--ay-border);
        }

        [data-bs-theme="dark"] .form-select,
        [data-bs-theme="dark"] .form-control,
        [data-bs-theme="dark"] .input-group-text {
            color: var(--ay-text);
            background-color: var(--ay-card-soft);
            border-color: var(--ay-border) !important;
        }

        @media (max-width: 767.98px) {
            .ay-page-header {
                padding: 1.1rem 1.2rem;
                border-radius: 14px;
            }

            .ay-card-footer {
                flex-direction: column;
                align-items: stretch;
            }

            .ay-footer-meta {
                text-align: center;
            }

            .ay-pagination {
                justify-content: center;
            }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3">

                <div class="page-header">
                    <div>
                        <h3><i class="bi bi-calendar-week me-2"></i>Section Scheduling</h3>
                        <p>Manage and set Schedules to Sections.</p>
                    </div>
                </div>

                <?php require_once __DIR__ . '/includes/breadcrumb.php'; renderBreadcrumb([['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'], ['label' => 'Maintenance', 'href' => 'schedule.php', 'icon' => 'bi bi-tools'], ['label' => 'Scheduling', 'icon' => 'bi bi-calendar-week']]); ?>
                <div class="ay-card">
                    <div class="ay-card-header">
                        <div>
                            <p class="ay-card-title">Section List</p>
                            <p class="ay-card-subtitle">Filter by grade level and open a section to manage its schedule.</p>
                        </div>

                        <div class="ay-toolbar">
                            <select class="form-select form-select-sm" id="gradeLevelFilter" style="min-width:180px; border-radius:10px;">
                                <option value="">All Grade Levels</option>
                                <?php foreach ($gradeLevels as $gl): ?>
                                    <option value="<?= h($gl['id']) ?>"><?= h($gl['grade_level_name']) ?></option>
                                <?php endforeach; ?>
                            </select>

                            <div class="input-group input-group-sm" style="min-width:220px;">
                                <span class="input-group-text"><i class="bi bi-search"></i></span>
                                <input class="form-control" type="search" id="searchInput" placeholder="Search section...">
                            </div>
                        </div>
                    </div>

                    <div class="ay-card-body">
                        <div class="d-none d-md-block">
                            <table class="ay-table" id="sectionTable">
                                <thead>
                                    <tr>
                                        <th style="width:50px;">#</th>
                                        <th>Grade Level</th>
                                        <th class="ay-section-name">Section Name</th>
                                        <th style="width:190px;">Track</th>
                                        <th style="width:120px;">Status</th>
                                        <th style="width:170px;">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="sectionTableBody">
                                    <tr>
                                        <td colspan="6">
                                            <div class="ay-empty">
                                                <i class="bi bi-hourglass-split"></i>
                                                <p>Loading sections...</p>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="d-block d-md-none p-3" id="sectionCardView"></div>
                    </div>

                    <div class="ay-card-footer">
                        <div class="ay-footer-meta" id="paginationInfo">Showing 0 to 0 of 0 sections</div>
                        <ul class="ay-pagination" id="pagination"></ul>
                    </div>
                </div>

            </div>
        </div>
    </main>

    <?php require_once("includes/footer.php"); ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>

<script>
function esc(str) {
    return (str ?? '').toString()
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function showAlert(message, type = 'success') {
    const config = {
        success: { title: 'Success', color: 'blue', icon: 'bi bi-check-circle-fill' },
        danger:  { title: 'Error',   color: 'red',  icon: 'bi bi-exclamation-octagon-fill' },
        warning: { title: 'Warning', color: 'yellow', icon: 'bi bi-exclamation-triangle-fill' },
        info:    { title: 'Info',    color: 'blue',  icon: 'bi bi-info-circle-fill' }
    };
    const selected = config[type] || config.success;
    iziToast.show({
        title: selected.title, message, color: selected.color, icon: selected.icon,
        iconColor: '#fff', theme: 'light', position: 'topRight', timeout: 4000,
        progressBar: true, close: true, pauseOnHover: true, drag: true,
        transitionIn: 'fadeInDown', transitionOut: 'fadeOutUp', maxWidth: 420
    });
}

async function fetchJson(url, options = {}) {
    const res  = await fetch(url, options);
    const text = await res.text();
    try { return JSON.parse(text); }
    catch (e) { console.error('Invalid JSON:', url, text); throw new Error('Invalid server response'); }
}


const STRAND_MAP = {
    'STEM':    { cls: 'ay-strand-STEM',   icon: 'bi-atom',           label: 'STEM'    },
    'ABM':     { cls: 'ay-strand-ABM',    icon: 'bi-bar-chart-fill', label: 'ABM'     },
    'HUMSS':   { cls: 'ay-strand-HUMSS',  icon: 'bi-people-fill',    label: 'HUMSS'   },
    'TVL-ICT': { cls: 'ay-strand-TVLICT', icon: 'bi-cpu-fill',       label: 'TVL-ICT' },
};

const TRACK_MAP = {
    'ACADEMIC': { cls: 'ay-track-academic', icon: 'bi-mortarboard-fill', label: 'Academic' },
    'TECHNICAL-PROFESSIONAL (TECH-PRO)': { cls: 'ay-track-techpro', icon: 'bi-tools', label: 'Technical-Professional (Tech-Pro)' },
    'TECHNICAL-PROFESSIONAL': { cls: 'ay-track-techpro', icon: 'bi-tools', label: 'Technical-Professional (Tech-Pro)' },
    'TECH-PRO': { cls: 'ay-track-techpro', icon: 'bi-tools', label: 'Technical-Professional (Tech-Pro)' },
};

function strandBadge(strand, gradeLevelName) {

    const gl = (gradeLevelName || '').toLowerCase();
    const isSHS = gl.includes('grade 11') || gl.includes('grade 12');
    if (!isSHS) return '<span style="color:#c8d8e8; font-size:.8rem;">—</span>';

    const s = (strand || '').trim().toUpperCase().replace('-', '-');
    const trackKey = s.replace(/\s+/g, ' ');
    const track = TRACK_MAP[trackKey] || (trackKey.startsWith('TECHNICAL-PROFESSIONAL')
        ? TRACK_MAP['TECHNICAL-PROFESSIONAL']
        : null);
    if (track) {
        return `<span class="ay-strand-badge ${track.cls}"><i class="bi ${track.icon}"></i>${track.label}</span>`;
    }

    const key = Object.keys(STRAND_MAP).find(k => k.toUpperCase() === s);
    if (key) {
        const m = STRAND_MAP[key];
        return `<span class="ay-strand-badge ${m.cls}"><i class="bi ${m.icon}"></i>${m.label}</span>`;
    }
    return `<span class="ay-strand-badge ay-strand-none"><i class="bi bi-dash-circle"></i>No Track</span>`;
}

let currentPage  = 1;
const itemsPerPage = 5;
let allSections  = [];

function getTotalPages() {
    return Math.max(1, Math.ceil(allSections.length / itemsPerPage));
}

function changePage(page) {
    const totalPages = getTotalPages();
    if (page < 1 || page > totalPages || page === currentPage) return;
    currentPage = page;
    renderSections();
}

function renderPagination(totalItems) {
    const pagination = document.getElementById('pagination');
    const totalPages = getTotalPages();
    if (!totalItems || totalPages <= 1) { pagination.innerHTML = ''; return; }

    let html = `
        <li class="ay-page-item ${currentPage === 1 ? 'disabled' : ''}">
            <a class="ay-page-link" href="#" onclick="changePage(${currentPage - 1}); return false;">Previous</a>
        </li>`;
    for (let n = 1; n <= totalPages; n++) {
        html += `
        <li class="ay-page-item ${n === currentPage ? 'active' : ''}">
            <a class="ay-page-link" href="#" onclick="changePage(${n}); return false;">${n}</a>
        </li>`;
    }
    html += `
        <li class="ay-page-item ${currentPage === totalPages ? 'disabled' : ''}">
            <a class="ay-page-link" href="#" onclick="changePage(${currentPage + 1}); return false;">Next</a>
        </li>`;
    pagination.innerHTML = html;
}

function updatePaginationInfo(totalItems, start, end) {
    document.getElementById('paginationInfo').textContent = totalItems
        ? `Showing ${start} to ${end} of ${totalItems} sections`
        : 'Showing 0 to 0 of 0 sections';
}

function renderSections() {
    const tableBody = document.getElementById('sectionTableBody');
    const cardView  = document.getElementById('sectionCardView');
    const totalPages = getTotalPages();
    if (currentPage > totalPages) currentPage = totalPages;

    const startIndex = (currentPage - 1) * itemsPerPage;
    const list       = allSections.slice(startIndex, startIndex + itemsPerPage);
    const startDisplay = allSections.length ? startIndex + 1 : 0;
    const endDisplay   = allSections.length ? startIndex + list.length : 0;


    tableBody.innerHTML = list.length ? list.map((s, i) => `
        <tr>
            <td><span class="row-num">${startIndex + i + 1}</span></td>
            <td>${esc(s.grade_level_name || '-')}</td>
            <td class="ay-section-name"><span class="year-label">${esc(s.section_name || '-')}</span></td>
            <td>${strandBadge(s.track || s.strand, s.grade_level_name)}</td>
            <td>
                ${String(s.is_active) === '1'
                    ? `<span class="ay-badge ay-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                    : `<span class="ay-badge ay-badge-inactive">Inactive</span>`}
            </td>
            <td>
                <a href="schedule_manage.php?section_id=${encodeURIComponent(s.id)}" class="btn-ay btn-ay-primary">
                    <i class="bi bi-calendar3"></i> Manage
                </a>
            </td>
        </tr>
    `).join('') : `
        <tr><td colspan="6">
            <div class="ay-empty"><i class="bi bi-folder2-open"></i><p>No sections found.</p></div>
        </td></tr>`;


    cardView.innerHTML = list.length ? list.map((s, i) => `
        <div class="ay-mobile-card">
            <div class="ay-mobile-card-header">
                <span class="ay-mobile-card-title">${startIndex + i + 1}. ${esc(s.section_name || '-')}</span>
                ${String(s.is_active) === '1'
                    ? `<span class="ay-badge ay-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                    : `<span class="ay-badge ay-badge-inactive">Inactive</span>`}
            </div>
            <div class="ay-mobile-card-body">
                <div class="ay-mobile-row">
                    <span class="ay-mobile-label">Grade Level</span>
                    <span>${esc(s.grade_level_name || '-')}</span>
                </div>
                <div class="ay-mobile-row">
                    <span class="ay-mobile-label">Track</span>
                    <span>${strandBadge(s.track || s.strand, s.grade_level_name)}</span>
                </div>
            </div>
            <div class="ay-mobile-actions">
                <a href="schedule_manage.php?section_id=${encodeURIComponent(s.id)}" class="btn-ay btn-ay-primary">
                    <i class="bi bi-calendar3"></i> Manage
                </a>
            </div>
        </div>
    `).join('') : `
        <div class="ay-empty"><i class="bi bi-folder2-open"></i><p>No sections found.</p></div>`;

    updatePaginationInfo(allSections.length, startDisplay, endDisplay);
    renderPagination(allSections.length);
}

async function loadSections(resetPage = false) {
    try {
        if (resetPage) currentPage = 1;

        const search       = document.getElementById('searchInput').value.trim();
        const gradeLevelId = document.getElementById('gradeLevelFilter').value;

        let url = `api/schedule/sections.php?s=${encodeURIComponent(search)}`;
        if (gradeLevelId) url += `&grade_level_id=${encodeURIComponent(gradeLevelId)}`;

        const data  = await fetchJson(url);
        allSections = data.sections || data.data || [];
        renderSections();
    } catch (err) {
        console.error(err);
        showAlert('Failed to load sections: ' + err.message, 'danger');
    }
}

document.getElementById('searchInput').addEventListener('input', () => loadSections(true));
document.getElementById('gradeLevelFilter').addEventListener('change', () => loadSections(true));

loadSections();
</script>
</body>
</html>