<?php
require_once 'includes/auth.php';
requireAdmin();
require_once 'api/shared/db_connect.php';

$totalArchivedCount = 0;

try {
    $stmtTeachers = $pdo->query("SELECT COUNT(*) FROM tblTeacher WHERE is_archived = 1");
    $totalArchivedCount += (int) ($stmtTeachers ? $stmtTeachers->fetchColumn() : 0);
} catch (Throwable $e) {
}

try {
    $stmtStudents = $pdo->query("SELECT COUNT(*) FROM tblStudentInfo WHERE is_archived = 1");
    $totalArchivedCount += (int) ($stmtStudents ? $stmtStudents->fetchColumn() : 0);
} catch (Throwable $e) {
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Archive Management</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">

    <style>
        body {
            background: #f3f7fd;
        }

        .ay-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }

        .ay-page-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 0.2rem;
            letter-spacing: 0.01em;
        }

        .ay-page-header p {
            margin: 0;
            font-size: 0.88rem;
            opacity: 0.85;
        }

        .ay-active-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            background: rgba(255, 255, 255, 0.15);
            border: 1.5px solid rgba(255, 255, 255, 0.3);
            border-radius: 999px;
            padding: 0.45rem 1rem;
            font-size: 0.88rem;
            font-weight: 700;
            color: #fff;
            white-space: nowrap;
        }

        .ay-active-chip i {
            font-size: 0.9rem;
            opacity: 0.9;
        }

        .ay-card {
            background: #fff;
            border: 1px solid #dce8f8;
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18, 72, 168, 0.06);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }

        .ay-card-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid #e8f0fb;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
            background: #fff;
        }

        .ay-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: #132f62;
            margin: 0 0 0.15rem;
        }

        .ay-card-subtitle {
            font-size: 0.8rem;
            color: #7a93b8;
            margin: 0;
        }

        .ay-card-body {
            padding: 0;
        }

        .ay-card-footer {
            padding: 0.75rem 1.2rem;
            border-top: 1px solid #e8f0fb;
            background: #fafcff;
        }

        .ay-filter-bar {
            padding: 1rem 1.2rem;
            display: flex;
            flex-wrap: wrap;
            align-items: end;
            gap: 0.9rem;
            background: #fff;
        }

        .ay-filter-group {
            display: flex;
            flex-direction: column;
            gap: 0.4rem;
            min-width: 180px;
            flex: 1 1 220px;
        }

        .ay-filter-group.search-group {
            flex: 2 1 320px;
        }

        .ay-filter-label {
            font-size: 0.78rem;
            font-weight: 700;
            color: #3b5e96;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .ay-filter-control {
            border-radius: 10px;
            border: 1.5px solid #c8daf8;
            min-height: 42px;
            font-size: 0.9rem;
            color: #213a5e;
            padding: 0.45rem 0.85rem;
            background: #fff;
            outline: none;
            transition: border-color 0.15s, box-shadow 0.15s;
        }

        .ay-filter-control:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.12);
        }

        .btn-ay {
            font-weight: 600;
            font-size: 0.82rem;
            border-radius: 8px;
            padding: 0.42rem 0.9rem;
            cursor: pointer;
            transition: background 0.15s, border-color 0.15s, color 0.15s, box-shadow 0.15s;
            border: 1.5px solid transparent;
            line-height: 1.4;
        }

        .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            border-color: transparent;
            box-shadow: 0 2px 8px rgba(26, 110, 245, 0.2);
        }

        .btn-ay-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
            box-shadow: 0 3px 12px rgba(26, 110, 245, 0.3);
        }

        .btn-ay-secondary {
            background: #fff;
            color: #5a7299;
            border-color: #dce8f8;
        }

        .btn-ay-secondary:hover {
            background: #f5f9ff;
            color: #264b84;
            border-color: #b9d2f9;
        }

        .btn-ay-activate {
            background: #1a6ef5;
            color: #fff;
            border-color: #1a6ef5;
        }

        .btn-ay-activate:hover {
            background: #1560d8;
            border-color: #1560d8;
            color: #fff;
        }

        .btn-ay-delete {
            background: #fff;
            color: #d43f57;
            border-color: #f1c5cd;
        }

        .btn-ay-delete:hover {
            background: #fff1f3;
            color: #b92f45;
            border-color: #e6a5b1;
        }

        .ay-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
        }

        .ay-table thead th {
            background: #f4f8ff;
            color: #3b5e96;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 0.85rem 1.2rem;
            border-bottom: 1.5px solid #dce8f8;
            white-space: nowrap;
        }

        .ay-table tbody tr {
            transition: background 0.12s;
        }

        .ay-table tbody tr:not(:last-child) td {
            border-bottom: 1px solid #f0f5fc;
        }

        .ay-table tbody tr:hover td {
            background: #f7fbff;
        }

        .ay-table tbody td {
            padding: 0.9rem 1.2rem;
            font-size: 0.93rem;
            color: #213a5e;
            vertical-align: middle;
        }

        .ay-table tbody td .row-num {
            color: #a0b4cc;
            font-size: 0.82rem;
            font-weight: 600;
        }

        .archive-name {
            font-weight: 700;
            color: #132f62;
            margin-bottom: 0.1rem;
        }

        .archive-subtext {
            color: #7f96b8;
            font-size: 0.79rem;
            line-height: 1.35;
        }

        .archive-role-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.32rem 0.75rem;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0.03em;
            border: 1.5px solid transparent;
        }

        .archive-role-teacher {
            background: #e9f1ff;
            color: #1248a8;
            border-color: #bfd5fb;
        }

        .archive-role-student {
            background: #eefbf3;
            color: #1e8b55;
            border-color: #cbeed9;
        }

        .archive-date {
            white-space: nowrap;
            font-weight: 600;
            color: #355787;
        }

        .archive-actions {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.6rem;
            flex-wrap: nowrap;
            white-space: nowrap;
        }

        .archive-actions .btn-ay {
            min-width: 110px;
        }

        .ay-pagination {
            display: flex;
            gap: 0.3rem;
            list-style: none;
            margin: 0;
            padding: 0;
            justify-content: flex-end;
        }

        .ay-pagination .ay-page-item .ay-page-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
            border-radius: 7px;
            font-size: 0.83rem;
            font-weight: 600;
            cursor: pointer;
            border: 1.5px solid #dce8f8;
            color: #1a6ef5;
            background: #fff;
            transition: all 0.13s;
            padding: 0 0.5rem;
        }

        .ay-pagination .ay-page-item .ay-page-link:hover {
            background: #eef4ff;
            border-color: #9cc2fc;
        }

        .ay-pagination .ay-page-item.active .ay-page-link {
            background: #1a6ef5;
            border-color: #1a6ef5;
            color: #fff;
        }

        .ay-empty {
            text-align: center;
            padding: 2.5rem 1.5rem;
            color: #9ab0c8;
        }

        .ay-empty i {
            font-size: 2.2rem;
            display: block;
            margin-bottom: 0.6rem;
            opacity: 0.5;
        }

        .ay-empty p {
            margin: 0;
            font-size: 0.95rem;
        }

        .ay-mobile-card {
            background: #fff;
            border: 1.5px solid #dce8f8;
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 1px 6px rgba(18, 72, 168, 0.05);
        }

        .ay-mobile-card + .ay-mobile-card {
            margin-top: 0.75rem;
        }

        .ay-mobile-card-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 0.75rem;
            padding: 0.85rem 1rem;
            border-bottom: 1px solid #edf3fc;
            background: #f9fbff;
        }

        .ay-mobile-card-title {
            font-weight: 700;
            color: #132f62;
            font-size: 0.95rem;
            margin-bottom: 0.15rem;
        }

        .ay-mobile-card-body {
            padding: 0.95rem 1rem;
        }

        .ay-mobile-meta {
            display: grid;
            gap: 0.55rem;
            margin-bottom: 0.9rem;
        }

        .ay-mobile-meta-item {
            font-size: 0.84rem;
            color: #4f678d;
            line-height: 1.4;
        }

        .ay-mobile-meta-item strong {
            color: #244675;
        }

        .ay-mobile-actions {
            display: grid;
            gap: 0.55rem;
        }

        @media (max-width: 991.98px) {
            .archive-actions .btn-ay {
                min-width: 96px;
                padding-left: 0.75rem;
                padding-right: 0.75rem;
            }
        }

        @media (max-width: 767.98px) {
            .ay-page-header {
                padding: 1.1rem 1.2rem;
                border-radius: 14px;
            }

            .ay-filter-bar {
                padding: 1rem;
            }
        }
    </style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <div class="app-wrapper">
        <?php require_once("includes/header.php"); ?>
        <?php require_once("includes/sidebar.php"); ?>

        <main class="app-main">
            <div class="app-content">
                <div class="container-fluid py-3">

                    <div class="ay-page-header">
                        <div>
                            <h3><i class="bi bi-archive me-2"></i>Archive Management</h3>
                            <p>View and manage deactivated teacher & student accounts</p>
                        </div>
                        <div class="ay-active-chip">
                            <i class="bi bi-archive-fill"></i>
                            Archived:&nbsp;<span id="archiveCountText"><?= (int) $totalArchivedCount ?></span>
                        </div>
                    </div>

                    <div class="ay-card">
                        <div class="ay-filter-bar">
                            <div class="ay-filter-group">
                                <label for="roleFilter" class="ay-filter-label">Role Filter</label>
                                <select id="roleFilter" class="ay-filter-control">
                                    <option value="all">All</option>
                                    <option value="teacher">Teacher</option>
                                    <option value="student">Student</option>
                                </select>
                            </div>

                            <div class="ay-filter-group search-group">
                                <label for="searchInput" class="ay-filter-label">Search</label>
                                <input
                                    type="text"
                                    id="searchInput"
                                    class="ay-filter-control"
                                    placeholder="Search by name, email, LRN, or employee ID">
                            </div>

                            <div class="ay-filter-group" style="flex: 0 0 auto; min-width: 140px;">
                                <label class="ay-filter-label">&nbsp;</label>
                                <button type="button" class="btn btn-ay btn-ay-secondary w-100" id="clearFiltersBtn">
                                    <i class="bi bi-x-circle me-1"></i> Clear
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="ay-card">
                        <div class="ay-card-header">
                            <div>
                                <p class="ay-card-title">Archived Accounts</p>
                                <p class="ay-card-subtitle">Only soft-deleted users appear here. Restore to reactivate.</p>
                            </div>
                        </div>

                        <div class="ay-card-body">
                            <div class="d-none d-md-block">
                                <table class="ay-table" id="archiveTable">
                                    <thead>
                                        <tr>
                                            <th style="width:64px; text-align:center;">#</th>
                                            <th>Name</th>
                                            <th>Email / LRN</th>
                                            <th style="width:130px; text-align:center;">Role</th>
                                            <th style="width:180px; text-align:center;">Archived Date</th>
                                            <th style="width:280px; text-align:center;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="tableBody">
                                        <tr>
                                            <td colspan="6">
                                                <div class="ay-empty">
                                                    <i class="bi bi-hourglass-split"></i>
                                                    <p>Loading archived accounts...</p>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <div class="d-block d-md-none p-3" id="cardView"></div>
                        </div>

                        <div class="ay-card-footer">
                            <ul class="ay-pagination" id="pagination"></ul>
                        </div>
                    </div>

                </div>
            </div>
        </main>

        <?php require_once("includes/footer.php"); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./js/adminlte.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>

    <script>
        let currentPage = 1;
        let currentRole = 'all';
        let currentSearch = '';
        let searchDebounceTimer = null;

        function showAlert(message, type = 'success') {
            const config = {
                success: {
                    title: 'Success',
                    color: 'blue',
                    icon: 'bi bi-check-circle-fill'
                },
                danger: {
                    title: 'Error',
                    color: 'red',
                    icon: 'bi bi-exclamation-octagon-fill'
                },
                warning: {
                    title: 'Warning',
                    color: 'yellow',
                    icon: 'bi bi-exclamation-triangle-fill'
                },
                info: {
                    title: 'Info',
                    color: 'blue',
                    icon: 'bi bi-info-circle-fill'
                }
            };

            const selected = config[type] || config.success;

            iziToast.show({
                title: selected.title,
                message: message,
                color: selected.color,
                icon: selected.icon,
                iconColor: '#fff',
                theme: 'light',
                position: 'topRight',
                timeout: 4000,
                progressBar: true,
                close: true,
                pauseOnHover: true,
                drag: true,
                transitionIn: 'fadeInDown',
                transitionOut: 'fadeOutUp',
                maxWidth: 420
            });
        }

        function updateArchiveCount(total = 0) {
            const countEl = document.getElementById('archiveCountText');
            if (countEl) {
                countEl.textContent = Number(total) || 0;
            }
        }

        function escapeHtml(value) {
            return String(value ?? '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        function formatDate(value) {
            if (!value) return '—';
            const normalized = String(value).replace('T', ' ');
            return normalized.length >= 16 ? normalized.slice(0, 16) : normalized;
        }

        function getNormalizedAccount(item) {
            const role = String(item.role || item.user_type || '').toLowerCase();
            const firstName = item.first_name || item.firstname || '';
            const middleName = item.middle_name || item.middlename || '';
            const lastName = item.last_name || item.lastname || '';
            const fullName = item.full_name ||
                item.name ||
                [firstName, middleName, lastName].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();

            return {
                id: item.id || item.account_id || item.user_id || '',
                name: fullName || 'Unnamed Account',
                email: item.email || '',
                role: role === 'teacher' ? 'teacher' : (role === 'student' ? 'student' : ''),
                roleLabel: role === 'teacher' ? 'Teacher' : (role === 'student' ? 'Student' : '—'),
                lrn: item.lrn || item.student_lrn || '',
                employeeId: item.employee_id || item.employee_no || item.teacher_no || '',
                archivedAt: item.archived_at || item.date_archived || item.deleted_at || '',
                reason: item.archive_reason || item.reason || ''
            };
        }

        async function fetchJson(url, options = {}) {
            const response = await fetch(url, options);
            const raw = await response.text();

            try {
                return JSON.parse(raw);
            } catch (e) {
                console.error('Non-JSON response:', raw);
                throw new Error('Server returned an invalid response.');
            }
        }

        async function loadArchived(page = 1, role = currentRole, search = currentSearch) {
            currentPage = page;
            currentRole = role;
            currentSearch = search;

            const params = new URLSearchParams();
            params.set('page', page);

            if (role && role !== 'all') {
                params.set('role', role);
            }

            if (search && search.trim() !== '') {
                params.set('search', search.trim());
            }

            try {
                const data = await fetchJson(`api/archive/read.php?${params.toString()}`);
                render(
                    data.accounts || data.users || [],
                    data.page || page,
                    data.pages || 1,
                    data.total_count ?? data.total ?? 0
                );
            } catch (error) {
                showAlert(error.message, 'danger');
            }
        }

        function render(list, page, pages, totalCount = 0) {
            const tableBody = document.getElementById('tableBody');
            const cardView = document.getElementById('cardView');
            const pagination = document.getElementById('pagination');

            updateArchiveCount(totalCount);

            if (!Array.isArray(list) || !list.length) {
                const emptyHtml = `
                    <div class="ay-empty">
                        <i class="bi bi-archive"></i>
                        <p>No archived accounts found.</p>
                    </div>
                `;
                tableBody.innerHTML = `<tr><td colspan="6">${emptyHtml}</td></tr>`;
                cardView.innerHTML = emptyHtml;
                pagination.innerHTML = '';
                return;
            }

            const offset = (page - 1) * 10;

            tableBody.innerHTML = list.map((rawItem, index) => {
                const item = getNormalizedAccount(rawItem);
                const roleBadgeClass = item.role === 'student' ? 'archive-role-student' : 'archive-role-teacher';
                const roleIcon = item.role === 'student' ? 'bi bi-mortarboard-fill' : 'bi bi-easel-fill';

                const identifierHtml = `
                    <div>${escapeHtml(item.email || '—')}</div>
                    <div class="archive-subtext">
                        ${item.role === 'student'
                            ? `LRN: ${escapeHtml(item.lrn || '—')}`
                            : `Employee ID: ${escapeHtml(item.employeeId || '—')}`}
                    </div>
                `;

                return `
                    <tr>
                        <td style="text-align:center;">
                            <span class="row-num">${offset + index + 1}</span>
                        </td>
                        <td>
                            <div class="archive-name">${escapeHtml(item.name)}</div>
                        </td>
                        <td>${identifierHtml}</td>
                        <td style="text-align:center;">
                            <span class="archive-role-badge ${roleBadgeClass}">
                                <i class="${roleIcon}"></i> ${escapeHtml(item.roleLabel)}
                            </span>
                        </td>
                        <td style="text-align:center;">
                            <span class="archive-date">${escapeHtml(formatDate(item.archivedAt))}</span>
                        </td>
                        <td style="text-align:center;">
                            <div class="archive-actions">
                                <button class="btn btn-ay btn-ay-activate" onclick="restoreUser('${escapeHtml(item.id)}', '${escapeHtml(item.role)}')">
                                    <i class="bi bi-arrow-repeat me-1"></i> Restore
                                </button>
                                <button class="btn btn-ay btn-ay-delete" onclick="deleteUserPermanently('${escapeHtml(item.id)}', '${escapeHtml(item.role)}')">
                                    <i class="bi bi-trash3 me-1"></i> Delete
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            }).join('');

            cardView.innerHTML = list.map((rawItem, index) => {
                const item = getNormalizedAccount(rawItem);
                const roleBadgeClass = item.role === 'student' ? 'archive-role-student' : 'archive-role-teacher';
                const roleIcon = item.role === 'student' ? 'bi bi-mortarboard-fill' : 'bi bi-easel-fill';

                return `
                    <div class="ay-mobile-card">
                        <div class="ay-mobile-card-header">
                            <div>
                                <div class="ay-mobile-card-title">${offset + index + 1}. ${escapeHtml(item.name)}</div>
                                <div class="archive-subtext">${escapeHtml(item.email || '—')}</div>
                            </div>
                            <span class="archive-role-badge ${roleBadgeClass}">
                                <i class="${roleIcon}"></i> ${escapeHtml(item.roleLabel)}
                            </span>
                        </div>
                        <div class="ay-mobile-card-body">
                            <div class="ay-mobile-meta">
                                <div class="ay-mobile-meta-item">
                                    <strong>${item.role === 'student' ? 'LRN' : 'Employee ID'}:</strong>
                                    ${escapeHtml(item.role === 'student' ? (item.lrn || '—') : (item.employeeId || '—'))}
                                </div>
                                <div class="ay-mobile-meta-item">
                                    <strong>Archived Date:</strong>
                                    ${escapeHtml(formatDate(item.archivedAt))}
                                </div>
                            </div>
                            <div class="ay-mobile-actions">
                                <button class="btn btn-ay btn-ay-activate w-100" onclick="restoreUser('${escapeHtml(item.id)}', '${escapeHtml(item.role)}')">
                                    <i class="bi bi-arrow-repeat me-1"></i> Restore
                                </button>
                                <button class="btn btn-ay btn-ay-delete w-100" onclick="deleteUserPermanently('${escapeHtml(item.id)}', '${escapeHtml(item.role)}')">
                                    <i class="bi bi-trash3 me-1"></i> Delete Permanently
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');

            pagination.innerHTML = Array.from({ length: pages }, (_, idx) => {
                const pageNumber = idx + 1;
                return `
                    <li class="ay-page-item ${pageNumber === page ? 'active' : ''}">
                        <a class="ay-page-link" onclick="loadArchived(${pageNumber}, currentRole, currentSearch)">${pageNumber}</a>
                    </li>
                `;
            }).join('');
        }

        function restoreUser(id, role) {
            iziToast.question({
                timeout: 20000,
                close: false,
                overlay: true,
                displayMode: 'once',
                id: 'restore-account-confirm',
                zindex: 9999,
                title: 'Confirm Restore',
                message: 'Are you sure you want to restore this archived account?',
                position: 'center',
                color: 'blue',
                icon: 'bi bi-arrow-repeat',
                buttons: [
                    [
                        '<button><b>Yes</b></button>',
                        async function (instance, toast) {
                            instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');

                            try {
                                const res = await fetchJson('api/archive/restore.php', {
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify({ id, role })
                                });

                                if (res.success) {
                                    showAlert(res.message || 'Archived account restored successfully.', 'success');
                                    loadArchived(currentPage, currentRole, currentSearch);
                                } else {
                                    showAlert(res.error || res.message || 'Restore failed.', 'danger');
                                }
                            } catch (error) {
                                showAlert(error.message, 'danger');
                            }
                        },
                        true
                    ],
                    [
                        '<button>No</button>',
                        function (instance, toast) {
                            instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');
                            showAlert('Restore cancelled.', 'info');
                        }
                    ]
                ]
            });
        }

        function deleteUserPermanently(id, role) {
            iziToast.question({
                timeout: 25000,
                close: false,
                overlay: true,
                displayMode: 'once',
                id: 'delete-account-confirm',
                zindex: 9999,
                title: 'Permanent Delete',
                message: 'This action is irreversible. Are you sure you want to permanently delete this account?',
                position: 'center',
                color: 'red',
                icon: 'bi bi-exclamation-octagon-fill',
                buttons: [
                    [
                        '<button><b>Delete</b></button>',
                        async function (instance, toast) {
                            instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');

                            try {
                                const res = await fetchJson('api/archive/delete.php', {
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify({ id, role })
                                });

                                if (res.success) {
                                    showAlert(res.message || 'Archived account permanently deleted.', 'success');
                                    loadArchived(currentPage, currentRole, currentSearch);
                                } else {
                                    showAlert(res.error || res.message || 'Delete failed.', 'danger');
                                }
                            } catch (error) {
                                showAlert(error.message, 'danger');
                            }
                        },
                        true
                    ],
                    [
                        '<button>Cancel</button>',
                        function (instance, toast) {
                            instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');
                            showAlert('Permanent delete cancelled.', 'info');
                        }
                    ]
                ]
            });
        }

        document.getElementById('roleFilter').addEventListener('change', function () {
            currentRole = this.value;
            loadArchived(1, currentRole, currentSearch);
        });

        document.getElementById('searchInput').addEventListener('input', function () {
            const value = this.value;

            clearTimeout(searchDebounceTimer);
            searchDebounceTimer = setTimeout(() => {
                currentSearch = value.trim();
                loadArchived(1, currentRole, currentSearch);
            }, 500);
        });

        document.getElementById('clearFiltersBtn').addEventListener('click', function () {
            document.getElementById('roleFilter').value = 'all';
            document.getElementById('searchInput').value = '';
            currentRole = 'all';
            currentSearch = '';
            loadArchived(1, currentRole, currentSearch);
        });

        loadArchived();
    </script>
</body>

</html>