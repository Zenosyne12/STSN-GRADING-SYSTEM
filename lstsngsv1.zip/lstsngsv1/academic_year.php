<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/api/shared/db_connect.php';

// ── Active Academic Year ──────────────────────────────────────────────────────
$activeYearLabel = '';
try {
    $stmtActive      = $pdo->query("SELECT year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
    $activeYearLabel = $stmtActive ? (string)$stmtActive->fetchColumn() : '';
} catch (Throwable $e) { $activeYearLabel = ''; }

$activeQuarter = null;
try {
    $stmt = $pdo->query("
        SELECT q.*, ay.year_label
        FROM tblquarters q
        JOIN tblacademicyear ay ON q.academic_year_id = ay.id
        WHERE q.is_active = 1
        LIMIT 1
    ");
    $activeQuarter = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $activeQuarter = null; }

$viewYearId  = isset($_GET['view_year']) ? (int)$_GET['view_year'] : null;
$viewingYear = null;

if ($viewYearId) {
    $stmt = $pdo->prepare("SELECT id, year_label, is_active FROM tblacademicyear WHERE id = ?");
    $stmt->execute([$viewYearId]);
    $viewingYear = $stmt->fetch(PDO::FETCH_ASSOC);
}
if (!$viewingYear) {
    $stmt = $pdo->query("SELECT id, year_label, is_active FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
    $viewingYear = $stmt->fetch(PDO::FETCH_ASSOC);
}
if (!$viewingYear) {
    $stmt = $pdo->query("SELECT id, year_label, is_active FROM tblacademicyear ORDER BY year_label DESC LIMIT 1");
    $viewingYear = $stmt->fetch(PDO::FETCH_ASSOC);
}

$allYears    = $pdo->query("SELECT id, year_label, is_active FROM tblacademicyear ORDER BY year_label DESC")->fetchAll(PDO::FETCH_ASSOC);
$defaultTab  = isset($_GET['tab']) && $_GET['tab'] === 'quarters' ? 'quarters' : 'years';

// ── Get existing academic years for modal dropdown ────────────────────────────
$existingYears = [];
$maxYear = 0;
try {
    $stmt = $pdo->query("SELECT year_label FROM tblacademicyear ORDER BY year_label ASC");
    $existingYears = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Find the maximum year (e.g., "2026-2027" -> 2026)
    foreach ($existingYears as $yearLabel) {
        $parts = explode('-', $yearLabel);
        if (isset($parts[0]) && is_numeric($parts[0])) {
            $maxYear = max($maxYear, (int)$parts[0]);
        }
    }
} catch (Throwable $e) { 
    $existingYears = []; 
    $maxYear = 0;
}

// Build available years: only years AFTER the max existing year
$availableYears = [];
for ($y = $maxYear + 1; $y <= 2035; $y++) {
    $yearLabel = $y . '-' . ($y + 1);
    // Also skip if somehow it exists (double check)
    if (!in_array($yearLabel, $existingYears)) {
        $availableYears[] = $yearLabel;
    }
}

// Sort ascending (next year at top)
sort($availableYears);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Academic Management</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
    <link rel="stylesheet" href="./css/academic_year.css">

</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3">

                <!-- Page Header -->
                <div class="am-page-header">
                    <div>
                        <h3><i class="bi bi-calendar-range me-2"></i>Academic Management</h3>
                        <p>Manage Academic Years and Quarters</p>
                    </div>
                    <div class="d-flex gap-2 align-items-center flex-wrap">
                        <div class="am-chip">
                            <i class="bi bi-calendar2-check-fill"></i>
                            Active Year:&nbsp;<span id="activeYearText"><?= htmlspecialchars($activeYearLabel ?: 'None') ?></span>
                        </div>
                        <div class="am-chip">
                            <i class="bi bi-calendar3"></i>
                            Active Quarter:&nbsp;<span id="activeQuarterText">
                                <?= $activeQuarter
                                    ? htmlspecialchars($activeQuarter['quarter_label'] . ' Quarter')
                                    : 'None' ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Promotion result banner (hidden by default) -->
                <div class="am-promo-banner d-none" id="promoBanner">
                    <i class="bi bi-arrow-up-circle-fill"></i>
                    <span id="promoBannerText"></span>
                </div>

                <!-- Tabbed Card -->
                <div class="am-card">
                    <div class="am-tabs">
                        <button class="am-tab-btn <?= $defaultTab === 'years' ? 'active' : '' ?>" id="tab-years" onclick="switchTab('years')">
                            <i class="bi bi-calendar-range"></i> Academic Years
                        </button>
                        <button class="am-tab-btn <?= $defaultTab === 'quarters' ? 'active' : '' ?>" id="tab-quarters" onclick="switchTab('quarters')">
                            <i class="bi bi-calendar3"></i> Quarters
                        </button>
                    </div>

                    <!-- TAB: ACADEMIC YEARS -->
                    <div id="pane-years" <?= $defaultTab !== 'years' ? 'style="display:none"' : '' ?>>
                        <div class="am-card-header">
                            <div>
                                <p class="am-card-title">Academic Year List</p>
                                <p class="am-card-subtitle">Only one academic year should remain active at a time. Activating a new year will auto-promote students.</p>
                            </div>
                            <button class="btn-am btn-am-primary" data-bs-toggle="modal" data-bs-target="#yearModal">
                                <i class="bi bi-plus-circle"></i> New Academic Year
                            </button>
                        </div>
                        <div class="am-card-body">
                            <div class="d-none d-md-block">
                                <table class="am-table">
                                    <thead>
                                        <tr>
                                            <th style="width:60px;text-align:center;">#</th>
                                            <th>Academic Year</th>
                                            <th style="width:130px;text-align:center;">Status</th>
                                            <th style="width:220px;text-align:center;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="yearTableBody">
                                        <tr><td colspan="4"><div class="am-empty"><i class="bi bi-hourglass-split"></i><p>Loading...</p></div></td></tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="d-block d-md-none p-3" id="yearCardView"></div>
                        </div>
                        <div class="am-card-footer">
                            <div class="am-footer-note" id="yearCountText"></div>
                            <ul class="am-pagination" id="yearPagination"></ul>
                        </div>
                    </div>

                    <!-- TAB: QUARTERS -->
                    <div id="pane-quarters" <?= $defaultTab !== 'quarters' ? 'style="display:none"' : '' ?>>
                        <div class="am-card-header">
                            <div>
                                <p class="am-card-title">Quarter List</p>
                                <p class="am-card-subtitle" id="quarterSubtitle">
                                    S.Y. <?= htmlspecialchars($viewingYear['year_label'] ?? '') ?>
                                    &mdash; Only one quarter can be active at a time.
                                </p>
                            </div>
                            <div class="d-flex align-items-center gap-2 flex-wrap">
                                <select class="year-select-inline" id="yearNavigator" onchange="changeQYear(this.value)">
                                    <?php foreach ($allYears as $year): ?>
                                        <option value="<?= $year['id'] ?>" <?= ($viewingYear && $viewingYear['id'] == $year['id']) ? 'selected' : '' ?>>
                                            S.Y. <?= htmlspecialchars($year['year_label']) ?> <?= $year['is_active'] ? '(Active)' : '' ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <button class="btn-am btn-am-primary" onclick="loadQuarters()">
                                    <i class="bi bi-arrow-clockwise"></i> Refresh
                                </button>
                            </div>
                        </div>
                        <div class="am-card-body">
                            <div class="d-none d-md-block">
                                <table class="am-table">
                                    <thead>
                                        <tr>
                                            <th style="width:60px;text-align:center;">#</th>
                                            <th>Quarter</th>
                                            <th style="width:130px;text-align:center;">Status</th>
                                            <th style="width:320px;text-align:center;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="quarterTableBody">
                                        <tr><td colspan="4"><div class="am-empty"><i class="bi bi-hourglass-split"></i><p>Loading...</p></div></td></tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="d-block d-md-none p-3" id="quarterCardView"></div>
                        </div>
                        <div class="am-card-footer">
                            <div class="am-footer-note" id="quarterCountText"></div>
                            <ul class="am-pagination" id="quarterPagination"></ul>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </main>
    <?php require_once("includes/footer.php"); ?>
</div>

<!-- MODAL: Add Academic Year -->
<div class="modal fade am-modal" id="yearModal" tabindex="-1" data-bs-backdrop="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="yearForm">
                <div class="modal-header">
                    <h5 class="modal-title" id="yearModalTitle"><i class="bi bi-calendar-plus me-2"></i>Add Academic Year</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="yearId">
                    <div class="mb-2">
                        <label class="form-label">School Year <span class="text-danger">*</span></label>
                        <select class="form-select" id="yearLabel" required>
                            <option value="">— Select academic year —</option>
                            <?php foreach ($availableYears as $year): ?>
                                <option value="<?= $year ?>"><?= $year ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="form-text text-muted">New years are inactive by default. 4 quarters will be created automatically.</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-am btn-am-deactivate" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn-am btn-am-primary"><i class="bi bi-check-circle"></i> Save Academic Year</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- MODAL: Edit Quarter Dates -->
<div class="modal fade am-modal" id="editModal" tabindex="-1" data-bs-backdrop="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="editForm">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-calendar-event me-2"></i>Edit Quarter Dates</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="editQuarterId">
                    <div class="am-info-box">
                        <h6>Quarter</h6>
                        <p id="editQuarterName">1st Quarter</p>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Start Date</label>
                            <input type="date" class="form-control" id="editStartDate">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">End Date</label>
                            <input type="date" class="form-control" id="editEndDate">
                        </div>
                    </div>
                    <div class="form-text text-muted"><i class="bi bi-info-circle me-1"></i>Leave blank if dates are not yet determined.</div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-am btn-am-deactivate" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn-am btn-am-primary"><i class="bi bi-check-circle"></i> Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>
<script>
    // ── State ──────────────────────────────────────────────────────────────────
    let currentQYearId   = <?= $viewingYear ? (int)$viewingYear['id'] : 'null' ?>;
    let yearCurrentPage  = 1;
    let totalYears       = 0;
    const yearRowsPerPage = 10;

    // ── Utilities ──────────────────────────────────────────────────────────────
    function escapeHtml(v) {
        return String(v ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
    }

    function showAlert(message, type = 'success') {
        const cfg = {
            success: { title:'Success', color:'blue',   icon:'bi bi-check-circle-fill' },
            danger:  { title:'Error',   color:'red',    icon:'bi bi-exclamation-octagon-fill' },
            warning: { title:'Warning', color:'yellow', icon:'bi bi-exclamation-triangle-fill' },
            info:    { title:'Info',    color:'blue',   icon:'bi bi-info-circle-fill' }
        };
        const s = cfg[type] || cfg.success;
        iziToast.show({ title:s.title, message, color:s.color, icon:s.icon, iconColor:'#fff', theme:'light',
            position:'topRight', timeout:5000, progressBar:true, close:true, pauseOnHover:true,
            drag:true, transitionIn:'fadeInDown', transitionOut:'fadeOutUp', maxWidth:460 });
    }

    async function fetchJson(url, options = {}) {
        const res = await fetch(url, options);
        const raw = await res.text();
        try { return JSON.parse(raw); }
        catch (e) { console.error('Non-JSON:', raw); throw new Error('Server returned an invalid response.'); }
    }

    function updateActiveDisplays(activeYear, activeQuarter) {
        if (activeYear !== undefined) {
            const el = document.getElementById('activeYearText');
            if (el) el.textContent = activeYear || 'None';
        }
        if (activeQuarter !== undefined) {
            const el = document.getElementById('activeQuarterText');
            if (el) el.textContent = activeQuarter
                ? `${activeQuarter.quarter_label} Quarter, S.Y. ${activeQuarter.year_label}`
                : 'None';
        }
    }

    function buildPagination(containerId, currentPage, totalPages, onClickFn) {
        let html = `<li class="am-page-item ${currentPage<=1?'disabled':''}">
            <a class="am-page-link" href="javascript:void(0)" onclick="${onClickFn}(${currentPage-1})">Previous</a></li>`;
        for (let n = 1; n <= totalPages; n++) {
            html += `<li class="am-page-item ${n===currentPage?'active':''}">
                <a class="am-page-link" href="javascript:void(0)" onclick="${onClickFn}(${n})">${n}</a></li>`;
        }
        html += `<li class="am-page-item ${currentPage>=totalPages?'disabled':''}">
            <a class="am-page-link" href="javascript:void(0)" onclick="${onClickFn}(${currentPage+1})">Next</a></li>`;
        document.getElementById(containerId).innerHTML = html;
    }

    function showPromoBanner(msg) {
        const banner = document.getElementById('promoBanner');
        const text   = document.getElementById('promoBannerText');
        if (!banner || !text) return;
        text.textContent = msg;
        banner.classList.remove('d-none');
        setTimeout(() => banner.classList.add('d-none'), 8000);
    }

    // ── Tab switching ──────────────────────────────────────────────────────────
    function switchTab(name) {
        ['years','quarters'].forEach(t => {
            document.getElementById(`tab-${t}`).classList.toggle('active', t === name);
            document.getElementById(`pane-${t}`).style.display = t === name ? '' : 'none';
        });
        if (name === 'quarters') loadQuarters();
        if (name === 'years')    loadYears(yearCurrentPage);
    }

    // ── Academic Years ─────────────────────────────────────────────────────────
    async function loadYears(page = 1) {
        yearCurrentPage = page;
        try {
            const data = await fetchJson(`api/academic-year/read.php?p=${page}`);
            totalYears = Number(data.total || 0);
            renderYears(data.years || [], data.page || 1, data.pages || 1, data.active_year || '');
        } catch (e) { showAlert(e.message, 'danger'); }
    }

    function renderYears(list, page, pages, activeYear) {
        const tbody    = document.getElementById('yearTableBody');
        const cardView = document.getElementById('yearCardView');
        const countEl  = document.getElementById('yearCountText');
        updateActiveDisplays(activeYear, undefined);

        if (!list.length) {
            const empty = `<div class="am-empty"><i class="bi bi-calendar-x"></i><p>No academic years found.</p></div>`;
            tbody.innerHTML = `<tr><td colspan="4">${empty}</td></tr>`;
            cardView.innerHTML = empty;
            if (countEl) countEl.textContent = 'No academic years to display.';
            document.getElementById('yearPagination').innerHTML = '';
            return;
        }

        const offset = (page - 1) * yearRowsPerPage;
        if (countEl) countEl.textContent = `Showing ${offset+1}–${offset+list.length} of ${totalYears} academic year${totalYears===1?'':'s'}`;

        tbody.innerHTML = list.map((y, i) => {
            const isActive = Number(y.is_active) === 1;
            const badge    = isActive
                ? `<span class="am-badge am-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                : `<span class="am-badge am-badge-inactive">Inactive</span>`;
            const toggleBtn = isActive
                ? `<button class="btn-am btn-am-deactivate" onclick="toggleYear(${y.id},0)"><i class="bi bi-pause-circle"></i> Deactivate</button>`
                : `<button class="btn-am btn-am-activate"   onclick="toggleYear(${y.id},1)"><i class="bi bi-play-circle"></i> Activate</button>`;
            return `<tr>
                <td style="text-align:center;"><span class="am-row-num">${offset+i+1}</span></td>
                <td><span class="am-year-name">${escapeHtml(y.year_label)}</span></td>
                <td style="text-align:center;">${badge}</td>
                <td style="text-align:center;"><div class="am-actions">${toggleBtn}</div></td>
            </tr>`;
        }).join('');

        cardView.innerHTML = list.map((y, i) => {
            const isActive = Number(y.is_active) === 1;
            const badge    = isActive
                ? `<span class="am-badge am-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                : `<span class="am-badge am-badge-inactive">Inactive</span>`;
            const toggleBtn = isActive
                ? `<button class="btn-am btn-am-deactivate w-100" onclick="toggleYear(${y.id},0)"><i class="bi bi-pause-circle"></i> Deactivate</button>`
                : `<button class="btn-am btn-am-activate w-100"   onclick="toggleYear(${y.id},1)"><i class="bi bi-play-circle"></i> Activate</button>`;
            return `<div class="am-mobile-card">
                <div class="am-mobile-card-header">
                    <div><div class="am-mobile-card-title">${offset+i+1}. ${escapeHtml(y.year_label)}</div></div>
                    ${badge}
                </div>
                <div class="am-mobile-card-body"><div class="am-mobile-actions">${toggleBtn}</div></div>
            </div>`;
        }).join('');

        buildPagination('yearPagination', page, pages, 'loadYears');
    }

    function toggleYear(id, newState) {
        const msg = newState
            ? 'Activate this academic year? Students from the previous year will be automatically promoted to the next grade level.'
            : 'Are you sure you want to deactivate this academic year?';

        iziToast.question({
            timeout:20000, close:false, overlay:true, displayMode:'once',
            id:'ay-toggle', zindex:9999, title:'Confirm',
            message: msg, position:'center',
            color: newState ? 'blue' : 'yellow', icon:'bi bi-question-circle-fill',
            buttons: [
                ['<button><b>Yes</b></button>', async function(instance, toast) {
                    instance.hide({transitionOut:'fadeOut'}, toast, 'button');
                    try {
                        const res = await fetchJson('api/academic-year/toggle.php', {
                            method:'POST', headers:{'Content-Type':'application/json'},
                            body: JSON.stringify({id, is_active: newState})
                        });
                        if (res.success) {
                            showAlert(res.message, 'success');
                            // Show promotion banner if promotion ran
                            if (res.promoted > 0 || res.retained > 0 || res.skipped > 0) {
                                showPromoBanner(`Auto-promotion complete — Promoted: ${res.promoted}, Retained: ${res.retained}, Graduated/Skipped: ${res.skipped}.`);
                            }
                            loadYears(yearCurrentPage);
                            updateQYearNavigator();
                        } else {
                            showAlert(res.message || res.error || 'Toggle failed.', 'danger');
                        }
                    } catch(e) { showAlert(e.message, 'danger'); }
                }, true],
                ['<button>No</button>', function(instance, toast) {
                    instance.hide({transitionOut:'fadeOut'}, toast, 'button');
                    showAlert('Action cancelled.', 'info');
                }]
            ]
        });
    }

    // ── Refresh modal dropdown after save ──────────────────────────────────────
    async function refreshYearDropdown() {
        try {
            const data = await fetchJson('api/academic-year/read.php?available_only=1');
            const select = document.getElementById('yearLabel');
            const availableYears = data.available_years || [];

            select.innerHTML = '<option value="">— Select academic year —</option>';
            availableYears.forEach(year => {
                const option = document.createElement('option');
                option.value = year;
                option.textContent = year;
                select.appendChild(option);
            });
        } catch (e) {
            console.error('Failed to refresh dropdown:', e);
        }
    }

    document.getElementById('yearForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        const payload = { id: document.getElementById('yearId').value || null, year_label: document.getElementById('yearLabel').value.trim() };
        try {
            const res = await fetchJson('api/academic-year/save.php', {
                method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)
            });
            if (res.success) {
                bootstrap.Modal.getInstance(document.getElementById('yearModal')).hide();
                this.reset();
                showAlert(res.message, 'success');
                loadYears(yearCurrentPage);
                updateQYearNavigator();
                // Refresh the dropdown to remove the newly added year
                await refreshYearDropdown();
            } else {
                showAlert(res.message || res.error || 'Save failed.', 'danger');
            }
        } catch(e) { showAlert(e.message, 'danger'); }
    });

    document.getElementById('yearModal').addEventListener('hidden.bs.modal', () => {
        document.getElementById('yearForm').reset();
        document.getElementById('yearId').value = '';
        document.getElementById('yearModalTitle').innerHTML = '<i class="bi bi-calendar-plus me-2"></i>Add Academic Year';
    });

    // Also refresh dropdown when modal opens (in case another admin added a year)
    document.getElementById('yearModal').addEventListener('show.bs.modal', () => {
        refreshYearDropdown();
    });

    // ── Quarters ───────────────────────────────────────────────────────────────
    function changeQYear(yearId) { currentQYearId = yearId; loadQuarters(); }

    async function updateQYearNavigator() {
        try {
            const data = await fetchJson('api/academic-year/read.php?p=1&all=1');
            if (data.all_years) {
                const select = document.getElementById('yearNavigator');
                select.innerHTML = data.all_years.map(y =>
                    `<option value="${y.id}" ${y.id == currentQYearId ? 'selected' : ''}>
                        S.Y. ${escapeHtml(y.year_label)} ${y.is_active==1?'(Active)':''}
                    </option>`
                ).join('');
            }
        } catch(_) {}
    }

    async function loadQuarters() {
        try {
            const data = await fetchJson(`api/quarters/read.php?view_year_id=${currentQYearId}`);
            if (data.all_years) {
                const select = document.getElementById('yearNavigator');
                select.innerHTML = data.all_years.map(y =>
                    `<option value="${y.id}" ${y.id == currentQYearId ? 'selected' : ''}>
                        S.Y. ${escapeHtml(y.year_label)} ${y.is_active==1?'(Active)':''}
                    </option>`
                ).join('');
            }
            renderQuarters(data.quarters || [], data.viewing_year, data.active_quarter);
        } catch(e) { showAlert(e.message, 'danger'); }
    }

    function renderQuarters(quarters, viewingYear, activeQuarter) {
        updateActiveDisplays(undefined, activeQuarter);

        const subtitle = document.getElementById('quarterSubtitle');
        if (subtitle && viewingYear) {
            subtitle.innerHTML = `S.Y. ${escapeHtml(viewingYear.year_label)}${viewingYear.is_active!=1?' (Inactive)':''} &mdash; Only one quarter can be active at a time.`;
        }

        const countEl = document.getElementById('quarterCountText');

        if (!quarters.length) {
            const empty = `<div class="am-empty"><i class="bi bi-calendar-x"></i><p>No quarters found for this academic year.</p></div>`;
            document.getElementById('quarterTableBody').innerHTML = `<tr><td colspan="4">${empty}</td></tr>`;
            document.getElementById('quarterCardView').innerHTML = empty;
            if (countEl) countEl.textContent = '';
            document.getElementById('quarterPagination').innerHTML = '';
            return;
        }

        if (countEl) countEl.textContent = `Showing ${quarters.length} quarter${quarters.length===1?'':'s'}`;

        const rows = quarters.map((q, i) => {
            const isGloballyActive = activeQuarter && activeQuarter.id == q.id;
            const isClosed         = Number(q.is_closed) === 1;
            const isYearActive     = Number(q.year_is_active) === 1;

            let badge;
            if (isGloballyActive)
                badge = `<span class="am-badge am-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`;
            else if (isClosed)
                badge = `<span class="am-badge am-badge-archived"><i class="bi bi-archive-fill"></i> Archived</span>`;
            else
                badge = `<span class="am-badge am-badge-inactive">Inactive</span>`;

            let actions = '';
            if (isClosed) {
                actions = `<button class="btn-am btn-am-restore" onclick="toggleArchive(${q.id},0)"><i class="bi bi-box-arrow-up"></i> Restore</button>`;
            } else if (isGloballyActive) {
                actions = `
                    <button class="btn-am btn-am-deactivate" onclick="toggleQuarter(${q.id},0)"><i class="bi bi-pause-circle"></i> Deactivate</button>
                    <button class="btn-am btn-am-archive"    onclick="toggleArchive(${q.id},1)"><i class="bi bi-archive"></i> Archive</button>`;
            } else {
                const disableActivate = !isYearActive
                    ? 'disabled title="Year is inactive"'
                    : (activeQuarter ? 'disabled title="Another quarter is active"' : '');
                actions = `
                    <button class="btn-am btn-am-activate" onclick="toggleQuarter(${q.id},1)" ${disableActivate}><i class="bi bi-play-circle"></i> Activate</button>
                    <button class="btn-am btn-am-edit"     onclick="editQuarter(${q.id},'${escapeHtml(q.quarter_label)}','${q.start_date||''}','${q.end_date||''}')"><i class="bi bi-pencil-square"></i> Edit</button>
                    <button class="btn-am btn-am-archive"  onclick="toggleArchive(${q.id},1)"><i class="bi bi-archive"></i></button>`;
            }
            return { q, badge, actions, i };
        });

        document.getElementById('quarterTableBody').innerHTML = rows.map(({q,badge,actions,i}) => `
            <tr>
                <td style="text-align:center;"><span class="am-row-num">${i+1}</span></td>
                <td>
                    <span class="am-year-name">${escapeHtml(q.quarter_label)} Quarter</span>
                    <div style="font-size:0.8rem;color:#7a93b8;margin-top:0.1rem;">S.Y. ${escapeHtml(q.year_label)}</div>
                </td>
                <td style="text-align:center;">${badge}</td>
                <td style="text-align:center;white-space:nowrap;"><div class="am-actions">${actions}</div></td>
            </tr>`).join('');

        document.getElementById('quarterCardView').innerHTML = rows.map(({q,badge,actions,i}) => `
            <div class="am-mobile-card">
                <div class="am-mobile-card-header">
                    <div>
                        <div class="am-mobile-card-title">${i+1}. ${escapeHtml(q.quarter_label)} Quarter</div>
                        <p class="am-mobile-card-subtitle">S.Y. ${escapeHtml(q.year_label)}</p>
                    </div>
                    ${badge}
                </div>
                <div class="am-mobile-card-body">
                    <div class="am-mobile-actions" style="flex-direction:row;flex-wrap:wrap;">${actions}</div>
                </div>
            </div>`).join('');

        document.getElementById('quarterPagination').innerHTML =
            `<li class="am-page-item active"><a class="am-page-link" href="javascript:void(0)">1</a></li>`;
    }

    function editQuarter(id, label, startDate, endDate) {
        document.getElementById('editQuarterId').value    = id;
        document.getElementById('editQuarterName').textContent = label + ' Quarter';
        document.getElementById('editStartDate').value   = startDate;
        document.getElementById('editEndDate').value     = endDate;
        new bootstrap.Modal(document.getElementById('editModal')).show();
    }

    document.getElementById('editForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        const payload = {
            id:         document.getElementById('editQuarterId').value,
            start_date: document.getElementById('editStartDate').value || null,
            end_date:   document.getElementById('editEndDate').value   || null,
        };
        try {
            const res = await fetchJson('api/quarters/save.php', {
                method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)
            });
            if (res.success) {
                bootstrap.Modal.getInstance(document.getElementById('editModal')).hide();
                showAlert(res.message, 'success');
                loadQuarters();
            } else { showAlert(res.error || 'Update failed.', 'danger'); }
        } catch(e) { showAlert(e.message, 'danger'); }
    });

    function toggleQuarter(id, newState) {
        iziToast.question({
            timeout:20000, close:false, overlay:true, displayMode:'once',
            id:'quarter-toggle', zindex:9999, title:'Confirm',
            message: newState ? 'Activate this quarter? This will deactivate any currently active quarter.' : 'Deactivate this quarter?',
            position:'center', color: newState?'blue':'yellow', icon:'bi bi-question-circle-fill',
            buttons: [
                ['<button><b>Yes</b></button>', async function(instance, toast) {
                    instance.hide({transitionOut:'fadeOut'}, toast, 'button');
                    try {
                        const res = await fetchJson('api/quarters/toggle.php', {
                            method:'POST', headers:{'Content-Type':'application/json'},
                            body: JSON.stringify({id, is_active: newState})
                        });
                        if (res.success) { showAlert(res.message, 'success'); loadQuarters(); }
                        else { showAlert(res.error || 'Toggle failed.', 'danger'); }
                    } catch(e) { showAlert(e.message, 'danger'); }
                }, true],
                ['<button>No</button>', function(instance, toast) {
                    instance.hide({transitionOut:'fadeOut'}, toast, 'button');
                }]
            ]
        });
    }

    function toggleArchive(id, isClosed) {
        iziToast.question({
            timeout:20000, close:false, overlay:true, displayMode:'once',
            id:'archive-toggle', zindex:9999, title:'Confirm',
            message: isClosed
                ? 'Archive this quarter? It will be preserved for records but hidden from active operations.'
                : 'Restore this quarter from archive?',
            position:'center', color: isClosed?'yellow':'blue', icon:'bi bi-archive',
            buttons: [
                ['<button><b>Yes</b></button>', async function(instance, toast) {
                    instance.hide({transitionOut:'fadeOut'}, toast, 'button');
                    try {
                        const res = await fetchJson('api/quarters/close.php', {
                            method:'POST', headers:{'Content-Type':'application/json'},
                            body: JSON.stringify({id, is_closed: isClosed})
                        });
                        if (res.success) { showAlert(res.message, 'success'); loadQuarters(); }
                        else { showAlert(res.error || 'Operation failed.', 'danger'); }
                    } catch(e) { showAlert(e.message, 'danger'); }
                }, true],
                ['<button>No</button>', function(instance, toast) {
                    instance.hide({transitionOut:'fadeOut'}, toast, 'button');
                }]
            ]
        });
    }

    // ── Init ───────────────────────────────────────────────────────────────────
    const defaultTab = '<?= $defaultTab ?>';
    if (defaultTab === 'quarters') loadQuarters();
    else                           loadYears();
</script>
</body>
</html>