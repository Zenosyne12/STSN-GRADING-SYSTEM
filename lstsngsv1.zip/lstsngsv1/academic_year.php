<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();
if (!isAdminSession() && !isSuperAdminSession()) {
    requireAdmin();
}
require_once __DIR__ . '/api/shared/db_connect.php';

$activeYearId = null;
$activeYearLabel = '';
try {
    $stmtActive = $pdo->query("SELECT id, year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
    $activeYear = $stmtActive ? ($stmtActive->fetch(PDO::FETCH_ASSOC) ?: []) : [];
    $activeYearId = isset($activeYear['id']) ? (int) $activeYear['id'] : null;
    $activeYearLabel = (string) ($activeYear['year_label'] ?? '');
} catch (Throwable $e) { $activeYearLabel = ''; }

/* Grading terms are manually activated and closed by an administrator. */
$termRows = [];
if ($activeYearId !== null) {
    try {
        $stmtTerms = $pdo->prepare("
            SELECT id, academic_year_id, term_number, term_label, term_type,
                   is_active, is_closed
            FROM tblconfig_terms
            WHERE academic_year_id = ?
            ORDER BY term_number ASC
        ");
        $stmtTerms->execute([$activeYearId]);
        $termRows = $stmtTerms->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) { $termRows = []; }
}

$activeTermNumber = 0;
$activeTermLabel = '';
foreach ($termRows as $termRow) {
    if ((int) $termRow['is_active'] === 1) {
        $activeTermNumber = (int) $termRow['term_number'];
        $activeTermLabel = (string) $termRow['term_label'];
        break;
    }
}
$nextEligibleNumber = $activeTermNumber === 0 ? 1 : $activeTermNumber + 1;

$viewYearId  = isset($_GET['view_year']) ? (int)$_GET['view_year'] : null;
$viewingYear = null;

if ($viewYearId) {
    $stmt = $pdo->prepare("SELECT id, year_label, term_structure, is_active FROM tblacademicyear WHERE id = ?");
    $stmt->execute([$viewYearId]);
    $viewingYear = $stmt->fetch(PDO::FETCH_ASSOC);
}
if (!$viewingYear) {
    $stmt = $pdo->query("SELECT id, year_label, term_structure, is_active FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
    $viewingYear = $stmt->fetch(PDO::FETCH_ASSOC);
}
if (!$viewingYear) {
    $stmt = $pdo->query("SELECT id, year_label, term_structure, is_active FROM tblacademicyear ORDER BY year_label DESC LIMIT 1");
    $viewingYear = $stmt->fetch(PDO::FETCH_ASSOC);
}

$allYears    = $pdo->query("SELECT id, year_label, term_structure, is_active FROM tblacademicyear WHERE archived_at IS NULL ORDER BY year_label DESC")->fetchAll(PDO::FETCH_ASSOC);
$defaultTab  = isset($_GET['tab']) && $_GET['tab'] === 'quarters' ? 'quarters' : 'years';
?>
<!doctype html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
    <meta charset="utf-8">
    <title>STSN Grading System | Academic Management</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="./css/academic_year.css">
    <style>
        /* ============================================================
           THEME VARIABLES (Light & Dark)
           ============================================================ */
        :root,
        [data-bs-theme="light"] {
            --am-bg: #f3f7fd;
            --am-card: #ffffff;
            --am-card-soft: #fafcff;
            --am-border: #dce8f8;
            --am-border-soft: #e8f0fb;
            --am-text: #213a5e;
            --am-text-strong: #132f62;
            --am-text-muted: #7a93b8;
            --am-text-dim: #9ab0c8;
            --am-head-bg: #f4f8ff;
            --am-head-text: #3b5e96;
            --am-row-hover: #f7fbff;
            --am-row-border: #f0f5fc;
            --am-input-bg: #ffffff;
            --am-input-border: #c8daf8;
            --am-input-text: #213a5e;

            --am-tab-text: #3b5e96;
            --am-tab-active: #1248a8;
            --am-tab-border: #dce8f8;

            --am-badge-active-bg: #e6f0ff;
            --am-badge-active-text: #1248a8;
            --am-badge-active-border: #b8d0fa;

            --am-badge-inactive-bg: #f3f5f8;
            --am-badge-inactive-text: #7a8ea8;
            --am-badge-inactive-border: #dde4ee;

            --am-pagination-text: #1a6ef5;
            --am-pagination-border: #dce8f8;
            --am-pagination-active-bg: #1a6ef5;
            --am-pagination-active-text: #ffffff;
            --am-pagination-disabled: #9ab0c8;
        }

        [data-bs-theme="dark"] {
            --am-bg: #1a1a1a;
            --am-card: #2D2D2D;
            --am-card-soft: #262626;
            --am-border: #3a3a3a;
            --am-border-soft: #3a3a3a;
            --am-text: #e4e6e8;
            --am-text-strong: #ffffff;
            --am-text-muted: #adb5bd;
            --am-text-dim: #8b939a;
            --am-head-bg: #2D2D2D;
            --am-head-text: #ffffff;
            --am-row-hover: #343434;
            --am-row-border: #3a3a3a;
            --am-input-bg: #3a3a3a;
            --am-input-border: #4a5a6e;
            --am-input-text: #e4e6e8;

            --am-tab-text: #adb5bd;
            --am-tab-active: #8ab4f8;
            --am-tab-border: #3a3a3a;

            --am-badge-active-bg: #1e2a3d;
            --am-badge-active-text: #8ab4f8;
            --am-badge-active-border: #2d4366;

            --am-badge-inactive-bg: #3a3a3a;
            --am-badge-inactive-text: #a9b8cd;
            --am-badge-inactive-border: #4a5a6e;

            --am-pagination-text: #8ab4f8;
            --am-pagination-border: #3a3a3a;
            --am-pagination-active-bg: #1a6ef5;
            --am-pagination-active-text: #ffffff;
            --am-pagination-disabled: #6c757d;
        }

        /* Force breadcrumb to start at the very left */
        .breadcrumb-container,
        .breadcrumb {
            display: flex !important;
            justify-content: flex-start !important;
            margin-left: 0 !important;
            padding-left: 0 !important;
            width: 100% !important;
        }
        .breadcrumb-container ol,
        .breadcrumb ol {
            margin-left: 0 !important;
            padding-left: 0 !important;
            justify-content: flex-start !important;
            width: 100% !important;
        }

        /* ============================================================
           DARK MODE OVERRIDES FOR .am-* CLASSES
           ============================================================ */
        [data-bs-theme="dark"] body {
            background: var(--am-bg) !important;
            color: var(--am-text) !important;
        }

        /* Card */
        [data-bs-theme="dark"] .am-card {
            background: var(--am-card) !important;
            border-color: var(--am-border) !important;
            box-shadow: 0 2px 12px rgba(0,0,0,.35) !important;
            color: var(--am-text) !important;
        }

        /* Tabs */
        [data-bs-theme="dark"] .am-tabs {
            background: var(--am-card-soft) !important;
            border-bottom-color: var(--am-border) !important;
        }
        [data-bs-theme="dark"] .am-tab-btn {
            color: var(--am-tab-text) !important;
            background: transparent !important;
            border-color: transparent !important;
        }
        [data-bs-theme="dark"] .am-tab-btn:hover {
            color: var(--am-tab-active) !important;
        }
        [data-bs-theme="dark"] .am-tab-btn.active {
            color: var(--am-tab-active) !important;
            border-bottom-color: var(--am-tab-active) !important;
            background: transparent !important;
        }

        /* Card header / body / footer */
        [data-bs-theme="dark"] .am-card-header {
            background: var(--am-card) !important;
            border-bottom-color: var(--am-border-soft) !important;
        }
        [data-bs-theme="dark"] .am-card-body {
            background: var(--am-card) !important;
            color: var(--am-text) !important;
        }
        [data-bs-theme="dark"] .am-card-footer {
            background: var(--am-card-soft) !important;
            border-top-color: var(--am-border-soft) !important;
        }
        [data-bs-theme="dark"] .am-footer-note {
            color: var(--am-text-muted) !important;
        }

        /* Card titles */
        [data-bs-theme="dark"] .am-card-title {
            color: var(--am-text-strong) !important;
        }
        [data-bs-theme="dark"] .am-card-subtitle {
            color: var(--am-text-muted) !important;
        }

        /* Table */
        [data-bs-theme="dark"] .am-table {
            background: var(--am-card) !important;
            color: var(--am-text) !important;
        }
        [data-bs-theme="dark"] .am-table thead th {
            background: var(--am-head-bg) !important;
            color: var(--am-head-text) !important;
            border-bottom-color: var(--am-border) !important;
        }
        [data-bs-theme="dark"] .am-table tbody tr:not(:last-child) td {
            border-bottom-color: var(--am-row-border) !important;
        }
        [data-bs-theme="dark"] .am-table tbody tr:hover td {
            background: var(--am-row-hover) !important;
        }
        [data-bs-theme="dark"] .am-table tbody td {
            color: var(--am-text) !important;
            background: transparent !important;
        }
        [data-bs-theme="dark"] .am-row-num {
            color: var(--am-text-dim) !important;
        }
        [data-bs-theme="dark"] .am-year-name {
            color: var(--am-text-strong) !important;
        }

        /* Badges */
        [data-bs-theme="dark"] .am-badge {
            color: var(--am-text) !important;
        }
        [data-bs-theme="dark"] .am-badge-active {
            background: var(--am-badge-active-bg) !important;
            color: var(--am-badge-active-text) !important;
            border-color: var(--am-badge-active-border) !important;
        }
        [data-bs-theme="dark"] .am-badge-inactive {
            background: var(--am-badge-inactive-bg) !important;
            color: var(--am-badge-inactive-text) !important;
            border-color: var(--am-badge-inactive-border) !important;
        }

        /* Inline "term" badge */
        [data-bs-theme="dark"] .am-table td .am-badge[style] {
            background: #1e2a3d !important;
            color: #8ab4f8 !important;
            border: 1px solid #2d4366 !important;
        }

        /* Empty state */
        [data-bs-theme="dark"] .am-empty {
            color: var(--am-text-dim) !important;
        }
        [data-bs-theme="dark"] .am-empty i {
            color: var(--am-text-dim) !important;
        }
        [data-bs-theme="dark"] .am-empty p {
            color: var(--am-text-dim) !important;
        }

        /* Pagination */
        [data-bs-theme="dark"] .am-pagination .am-page-item .am-page-link {
            background: var(--am-card) !important;
            border-color: var(--am-pagination-border) !important;
            color: var(--am-pagination-text) !important;
        }
        [data-bs-theme="dark"] .am-pagination .am-page-item .am-page-link:hover {
            background: var(--am-row-hover) !important;
            border-color: #6a7a8e !important;
        }
        [data-bs-theme="dark"] .am-pagination .am-page-item.active .am-page-link {
            background: var(--am-pagination-active-bg) !important;
            border-color: var(--am-pagination-active-bg) !important;
            color: var(--am-pagination-active-text) !important;
        }
        [data-bs-theme="dark"] .am-pagination .am-page-item.disabled .am-page-link {
            background: var(--am-card-soft) !important;
            color: var(--am-pagination-disabled) !important;
        }

        /* Mobile cards */
        [data-bs-theme="dark"] .am-mobile-card {
            background: var(--am-card) !important;
            border-color: var(--am-border) !important;
            color: var(--am-text) !important;
        }
        [data-bs-theme="dark"] .am-mobile-card-header {
            background: var(--am-card-soft) !important;
            border-bottom-color: var(--am-border-soft) !important;
        }
        [data-bs-theme="dark"] .am-mobile-card-title {
            color: var(--am-text-strong) !important;
        }
        [data-bs-theme="dark"] .am-mobile-card-body {
            background: var(--am-card) !important;
            color: var(--am-text) !important;
        }

        /* Promo banner */
        [data-bs-theme="dark"] .am-promo-banner {
            background: #1e2a3d !important;
            color: #8ab4f8 !important;
            border-color: #2d4366 !important;
        }

        /* ============================================================
           MODAL BODY / FOOTER THEMING
           ============================================================ */
        [data-bs-theme="dark"] .am-modal .modal-content {
            background: var(--am-card) !important;
            color: var(--am-text) !important;
        }
        [data-bs-theme="dark"] .am-modal .modal-title {
            color: #fff !important;
        }
        [data-bs-theme="dark"] .am-modal .modal-body {
            background: var(--am-card) !important;
            color: var(--am-text) !important;
        }
        [data-bs-theme="dark"] .am-modal .modal-footer {
            background: var(--am-card-soft) !important;
            border-top-color: var(--am-border) !important;
        }
        [data-bs-theme="dark"] .am-modal .form-label {
            color: var(--am-text-strong) !important;
        }
        [data-bs-theme="dark"] .am-modal .form-control,
        [data-bs-theme="dark"] .am-modal .form-select {
            background: #3a3a3a !important;
            color: #e4e6e8 !important;
            border-color: #4a5a6e !important;
        }
        [data-bs-theme="dark"] .am-modal .form-control::placeholder {
            color: #adb5bd !important;
        }
        [data-bs-theme="dark"] .am-modal .form-select option {
            background: #2D2D2D !important;
            color: #e4e6e8 !important;
        }
        [data-bs-theme="dark"] .am-modal .form-text,
        [data-bs-theme="dark"] .am-modal .text-muted {
            color: #adb5bd !important;
        }

        /* ============================================================
           BULLETPROOF BLUE GRADIENT MODAL HEADERS
           ============================================================ */

        /* ---- #yearModal (New / Edit Academic Year) ---- */
        #yearModal .modal-header {
            position: relative;
            z-index: 0;
            color: #fff !important;
            border-bottom: 0 !important;
            background-color: #0b3d91 !important;
            overflow: hidden;
            border-top-left-radius: 14px;
            border-top-right-radius: 14px;
            padding: 1rem 1.25rem;
        }
        #yearModal .modal-header::before {
            content: "";
            position: absolute;
            inset: 0;
            z-index: -1;
            background: linear-gradient(135deg, #0b3d91 0%, #1457b8 52%, #1d75e8 100%);
            pointer-events: none;
        }
        #yearModal .modal-header > * {
            position: relative;
            z-index: 1;
        }
        #yearModal .modal-title,
        #yearModal .modal-header i {
            color: #fff !important;
        }
        #yearModal .modal-header .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%) !important;
            opacity: 1 !important;
            background-color: transparent;
            border-radius: 50%;
        }

        /* Year Modal — Improved Design */
        #yearModal .modal-dialog { max-width: 560px; }
        #yearModal .modal-content {
            border: 0; border-radius: 16px;
            box-shadow: 0 20px 60px rgba(18,72,168,0.25);
            overflow: hidden;
        }
        #yearModal .modal-body {
            padding: 1.75rem 1.5rem 1.25rem;
            background: #ffffff;
        }
        #yearModal .modal-footer {
            padding: 1rem 1.5rem 1.25rem;
            background: #fafcff;
            border-top: 1px solid #e8f0fb;
        }
        #yearModal .form-label {
            font-size: 0.85rem; font-weight: 700;
            color: #3b5e96; margin-bottom: 0.45rem;
        }
        #yearModal .form-control,
        #yearModal .form-select {
            border: 1.5px solid #c8daf8;
            border-radius: 10px; min-height: 44px;
            padding: 0.5rem 0.9rem; font-size: 0.92rem;
            color: #213a5e; background: #ffffff;
            transition: all 0.15s ease;
        }
        #yearModal .form-control:focus,
        #yearModal .form-select:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26,110,245,0.12);
            outline: none;
        }
        #yearModal .form-select {
            appearance: none; -webkit-appearance: none;
            background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%231a6ef5'><path d='M8 10.5l-4-4 1-1L8 8.5l3-3 1 1z'/></svg>");
            background-repeat: no-repeat;
            background-position: right 0.75rem center;
            background-size: 16px;
            padding-right: 2.5rem;
        }
        #yearModal .form-text {
            font-size: 0.78rem; color: #7a93b8; margin-top: 0.35rem;
        }
        #yearModal .mb-3 { margin-bottom: 1.15rem !important; }

        /* ---- #editModal (Edit Quarter Dates) ---- */
        #editModal .modal-header {
            position: relative;
            z-index: 0;
            color: #fff !important;
            border-bottom: 0 !important;
            background-color: #0b3d91 !important;
            overflow: hidden;
            border-top-left-radius: 14px;
            border-top-right-radius: 14px;
            padding: 1rem 1.25rem;
        }
        #editModal .modal-header::before {
            content: "";
            position: absolute;
            inset: 0;
            z-index: -1;
            background: linear-gradient(135deg, #0b3d91 0%, #1457b8 52%, #1d75e8 100%);
            pointer-events: none;
        }
        #editModal .modal-header > * {
            position: relative;
            z-index: 1;
        }
        #editModal .modal-title,
        #editModal .modal-header i {
            color: #fff !important;
        }
        #editModal .modal-header .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%) !important;
            opacity: 1 !important;
            background-color: transparent;
            border-radius: 50%;
        }

        /* Info box in edit modal */
        [data-bs-theme="dark"] .am-info-box {
            background: var(--am-card-soft) !important;
            border-color: var(--am-border) !important;
        }
        [data-bs-theme="dark"] .am-info-box h6 {
            color: var(--am-text-strong) !important;
        }
        [data-bs-theme="dark"] .am-info-box p {
            color: var(--am-text) !important;
        }

        /* ============================================================
           ★★★ EDIT BUTTON — YELLOW / AMBER ★★★
           ============================================================ */

        /* LIGHT MODE — yellow/amber */
        .btn-am-edit {
            background: #fff8e6 !important;
            color: #8a5c00 !important;
            border: 1.5px solid #f5d98a !important;
            border-radius: 8px !important;
        }
        .btn-am-edit i {
            color: inherit !important;
        }
        .btn-am-edit:hover {
            background: #fff0c0 !important;
            border-color: #f0c832 !important;
            color: #8a5c00 !important;
        }

        /* DARK MODE — yellow/amber */
        [data-bs-theme="dark"] .btn-am-edit {
            background: #3a2f14 !important;
            color: #ffcc66 !important;
            border-color: #5c4820 !important;
        }
        [data-bs-theme="dark"] .btn-am-edit i {
            color: #ffcc66 !important;
        }
        [data-bs-theme="dark"] .btn-am-edit:hover {
            background: #4a3c18 !important;
            border-color: #6e5830 !important;
            color: #ffcc66 !important;
        }
        [data-bs-theme="dark"] .btn-am-edit:hover i {
            color: #ffcc66 !important;
        }

        /* Disabled state */
        .btn-am-edit:disabled,
        .btn-am-edit.disabled {
            background: var(--am-card-soft) !important;
            color: var(--am-text-dim) !important;
            border-color: var(--am-border) !important;
            opacity: .65;
            cursor: not-allowed;
        }
        .btn-am-edit:disabled i,
        .btn-am-edit.disabled i {
            color: var(--am-text-dim) !important;
        }

        /* ============================================================
           ★★★ ACTIVATE / DEACTIVATE BUTTONS ★★★
           ============================================================ */

        /* Activate — green (keep) */
        [data-bs-theme="dark"] .btn-am-activate {
            background: #17351f !important;
            color: #6ee7a0 !important;
            border-color: #2b5c38 !important;
        }
        [data-bs-theme="dark"] .btn-am-activate:hover {
            background: #1e4028 !important;
            border-color: #3a7048 !important;
            color: #6ee7a0 !important;
        }

        .term-action-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 180px;
            min-height: 38px;
            padding: 0.5rem 0.85rem;
            font-size: 0.85rem;
            font-weight: 600;
            line-height: 1.25;
            border-radius: 8px;
            white-space: nowrap;
            gap: 0.4rem;
        }

        /* Deactivate — DARK BLUE (matches the first reference screenshot) */
        [data-bs-theme="dark"] .btn-am-deactivate {
            background: #1e2a3d !important;
            color: #8ab4f8 !important;
            border-color: #2d4366 !important;
        }
        [data-bs-theme="dark"] .btn-am-deactivate i {
            color: #8ab4f8 !important;
        }
        [data-bs-theme="dark"] .btn-am-deactivate:hover {
            background: #2a3a54 !important;
            border-color: #3d5a80 !important;
            color: #8ab4f8 !important;
        }
        [data-bs-theme="dark"] .btn-am-deactivate:hover i {
            color: #8ab4f8 !important;
        }

        /* Body bg in dark */
        [data-bs-theme="dark"] .app-main,
        [data-bs-theme="dark"] .app-content {
            background: var(--am-bg) !important;
        }

        /* Page header keeps gradient */
        [data-bs-theme="dark"] .page-header,
        [data-bs-theme="dark"] .ay-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%) !important;
            color: #fff !important;
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3 stsn-anim-fade-in-up">

                <div class="page-header">
                    <div>
                        <h3><i class="bi bi-calendar-range me-2"></i>Academic Management</h3>
                        <p>Manage Academic Years and Grading Terms</p>
                    </div>
                </div>

                <?php require_once __DIR__ . '/includes/breadcrumb.php'; renderBreadcrumb([['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'], ['label' => 'Academic Settings', 'href' => 'academic_year.php', 'icon' => 'bi bi-sliders'], ['label' => $defaultTab === 'quarters' ? 'Grading Terms' : 'Academic Year', 'icon' => $defaultTab === 'quarters' ? 'bi bi-calendar3' : 'bi bi-calendar-range']]); ?>
                
                <div class="am-promo-banner d-none" id="promoBanner">
                    <i class="bi bi-arrow-up-circle-fill"></i>
                    <span id="promoBannerText"></span>
                </div>

                <div class="am-card">
                    <div class="am-tabs">
                        <button class="am-tab-btn <?= $defaultTab === 'years' ? 'active' : '' ?>" id="tab-years" onclick="switchTab('years')">
                            <i class="bi bi-calendar-range"></i> Academic Years
                        </button>
                        <button class="am-tab-btn <?= $defaultTab === 'quarters' ? 'active' : '' ?>" id="tab-quarters" onclick="switchTab('quarters')">
                            <i class="bi bi-calendar3"></i> Grading Terms
                        </button>
                    </div>

                    <div id="pane-years" <?= $defaultTab !== 'years' ? 'style="display:none"' : '' ?>>
                        <div class="am-card-header">
                            <div>
                                <p class="am-card-title">Academic Year List</p>
                                <p class="am-card-subtitle">Only one academic year should remain active at a time. Activating a new year will auto-promote students.</p>
                            </div>
                            <div class="d-flex align-items-center gap-3 flex-wrap">
                                <button class="btn-am btn-am-primary" data-bs-toggle="modal" data-bs-target="#yearModal">
                                    <i class="bi bi-plus-circle"></i> New Academic Year
                                </button>
                            </div>
                        </div>
                        <div class="am-card-body">
                            <div class="d-none d-md-block">
                                <table class="am-table">
                                    <thead>
                                        <tr>
                                            <th style="width:60px;text-align:center;">#</th>
                                            <th>Academic Year</th>
                                            <th>Term Structure</th>
                                            <th style="width:130px;text-align:center;">Status</th>
                                            <th style="width:220px;text-align:center;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="yearTableBody">
                                        <tr><td colspan="5"><div class="am-empty"><i class="bi bi-hourglass-split"></i><p>Loading...</p></div></td></tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="d-block d-md-none p-3" id="yearCardView"></div>
                        </div>
                        <div class="am-card-footer">
                            <div class="am-footer-note" id="yearCountText"></div>
                            <ul class="am-pagination" id="yearPagination"></ul>
                        </div>
                    </div>

                    <div id="pane-quarters" <?= $defaultTab !== 'quarters' ? 'style="display:none"' : '' ?>>
                        <div class="am-card-header">
                            <div>
                                <p class="am-card-title">Grading Term List</p>
                                <p class="am-card-subtitle">
                                    <?= $activeYearId !== null
                                        ? 'Manage terms for active academic year S.Y. ' . htmlspecialchars($activeYearLabel)
                                        : 'Activate an academic year before managing grading terms.' ?>
                                </p>
                            </div>
                        </div>
                        <div class="am-card-body">
                            <?php if ($activeYearId === null): ?>
                                <div class="am-empty"><i class="bi bi-calendar-x"></i><p>No active academic year.</p></div>
                            <?php elseif (empty($termRows)): ?>
                                <div class="am-empty"><i class="bi bi-calendar-x"></i><p>No grading terms found for the active academic year.</p></div>
                            <?php else: ?>
                            <div class="d-none d-md-block">
                                <table class="am-table">
                                    <thead>
                                        <tr>
                                            <th style="width:60px;text-align:center;">#</th>
                                            <th>Term</th>
                                            <th>Type</th>
                                            <th style="width:130px;text-align:center;">Status</th>
                                            <th style="width:230px;text-align:center;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($termRows as $i => $row): ?>
                                            <tr>
                                                <td style="text-align:center;"><span class="am-row-num"><?= $i + 1 ?></span></td>
                                                <td>
                                                    <span class="am-year-name"><?= htmlspecialchars($row['term_label']) ?></span>
                                                    <div style="font-size:0.8rem;color:var(--am-text-muted);margin-top:0.1rem;">S.Y. <?= htmlspecialchars($activeYearLabel) ?></div>
                                                </td>
                                                <td><?= htmlspecialchars($row['term_type']) ?></td>
                                                <td style="text-align:center;">
                                                    <?php if (!empty($row['is_closed'])): ?>
                                                        <span class="badge bg-secondary">Closed</span>
                                                    <?php elseif (!empty($row['is_active'])): ?>
                                                        <span class="badge bg-success">Active</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-light text-dark">Inactive</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="text-center">
                                                    <?php if (!empty($row['is_active'])): ?>
                                                        <button type="button" class="btn-am btn-am-close-term term-action-btn js-close-term"
                                                            data-term-id="<?= (int) $row['id'] ?>"
                                                            data-term-label="<?= htmlspecialchars($row['term_label'], ENT_QUOTES, 'UTF-8') ?>">
                                                            <i class="bi bi-lock-fill"></i> Close This Term
                                                        </button>
                                                    <?php elseif ((int) $row['term_number'] === $nextEligibleNumber): ?>
                                                        <button type="button" class="btn-am btn-am-activate term-action-btn js-activate-term"
                                                            data-term-id="<?= (int) $row['id'] ?>"
                                                            data-term-number="<?= (int) $row['term_number'] ?>"
                                                            data-year-id="<?= $activeYearId ?>"
                                                            data-term-label="<?= htmlspecialchars($row['term_label'], ENT_QUOTES, 'UTF-8') ?>"
                                                            data-prev-term-label="<?= htmlspecialchars($activeTermLabel, ENT_QUOTES, 'UTF-8') ?>">
                                                            <i class="bi bi-play-circle"></i> Activate This Term
                                                        </button>
                                                    <?php elseif (!empty($row['is_closed'])): ?>
                                                        <span class="text-muted">&mdash;</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="d-block d-md-none p-3">
                                <?php foreach ($termRows as $i => $row): ?>
                                    <div class="am-mobile-card">
                                        <div class="am-mobile-card-header">
                                            <div>
                                                <div class="am-mobile-card-title"><?= $i + 1 ?>. <?= htmlspecialchars($row['term_label']) ?></div>
                                                <p class="am-mobile-card-subtitle">S.Y. <?= htmlspecialchars($activeYearLabel) ?></p>
                                            </div>
                                            <?php if (!empty($row['is_closed'])): ?>
                                                <span class="badge bg-secondary">Closed</span>
                                            <?php elseif (!empty($row['is_active'])): ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php else: ?>
                                                <span class="badge bg-light text-dark">Inactive</span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="am-mobile-card-body">
                                            <div style="font-size:.85rem;color:var(--am-text-muted);">
                                                <div><strong>Type:</strong> <?= htmlspecialchars($row['term_type']) ?></div>
                                            </div>
                                            <div class="am-mobile-actions mt-2">
                                                <?php if (!empty($row['is_active'])): ?>
                                                    <button type="button" class="btn-am btn-am-close-term term-action-btn w-100 js-close-term"
                                                        data-term-id="<?= (int) $row['id'] ?>"
                                                        data-term-label="<?= htmlspecialchars($row['term_label'], ENT_QUOTES, 'UTF-8') ?>">
                                                        <i class="bi bi-lock-fill"></i> Close This Term
                                                    </button>
                                                <?php elseif ((int) $row['term_number'] === $nextEligibleNumber): ?>
                                                    <button type="button" class="btn-am btn-am-activate term-action-btn w-100 js-activate-term"
                                                        data-term-id="<?= (int) $row['id'] ?>"
                                                        data-term-number="<?= (int) $row['term_number'] ?>"
                                                        data-year-id="<?= $activeYearId ?>"
                                                        data-term-label="<?= htmlspecialchars($row['term_label'], ENT_QUOTES, 'UTF-8') ?>"
                                                        data-prev-term-label="<?= htmlspecialchars($activeTermLabel, ENT_QUOTES, 'UTF-8') ?>">
                                                        <i class="bi bi-play-circle"></i> Activate This Term
                                                    </button>
                                                <?php elseif (!empty($row['is_closed'])): ?>
                                                    <span class="text-muted">No action available</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="am-card-footer">
                            <div class="am-footer-note"><?= count($termRows) ?> term<?= count($termRows) === 1 ? '' : 's' ?> for active year</div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </main>
    <?php require_once("includes/footer.php"); ?>
</div>


<div class="modal fade am-modal" id="yearModal" tabindex="-1" data-bs-backdrop="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="yearForm">
                <div class="modal-header">
                    <h5 class="modal-title" id="yearModalTitle"><i class="bi bi-calendar-plus me-2"></i>New Academic Year</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="yearId">
                    
                    <div class="mb-3">
                        <label class="form-label">School Year <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="yearLabel" placeholder="e.g., 2027-2028" required>
                        <div class="form-text text-muted">Format: YYYY-YYYY (e.g., 2027-2028)</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Term Structure <span class="text-danger">*</span></label>
                        <select class="form-select" id="termStructure" required>
                            <option value="quarterly">Quarterly (4 terms)</option>
                            <option value="trimester" selected>Trimester (3 terms)</option>
                            <option value="semestral">Semestral (2 terms)</option>
                        </select>
                        <div class="form-text text-muted">This determines how many grading terms will be created.</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-am btn-am-deactivate" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn-am btn-am-primary"><i class="bi bi-check-circle"></i> Create Academic Year</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="activateTermModal" tabindex="-1" aria-labelledby="activateTermModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius:14px;overflow:hidden;border:none;">
            <div class="modal-header" style="background:linear-gradient(130deg,#1248a8 0%,#1a6ef5 100%);color:#fff;border:none;padding:1rem 1.25rem;">
                <h5 class="modal-title" id="activateTermModalTitle">
                    <i class="bi bi-play-circle me-2"></i>Activate Term?
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" style="padding:1.5rem;">
                <p class="mb-2">
                    Activating <strong id="activateTermLabel"></strong> will close
                    <strong id="activatePrevTermLabel"></strong> automatically. Continue?
                </p>
                <div id="activateTermError" class="alert alert-danger d-none mt-3 mb-0"
                    style="border-radius:10px;font-size:0.9rem;">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    <span id="activateTermErrorText"></span>
                </div>
            </div>
            <div class="modal-footer" style="background:#f8fafc;border-top:1px solid #e2e8f0;padding:0.85rem 1.25rem;">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="activateTermConfirmBtn"
                    style="background:linear-gradient(130deg,#1248a8 0%,#1a6ef5 100%);border:none;font-weight:600;">
                    <i class="bi bi-play-circle me-1"></i>Activate
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Quarter edit modal removed — grading terms are managed by the System Administrator (read-only view). -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>
<script>
    let currentQYearId   = <?= $viewingYear ? (int)$viewingYear['id'] : 'null' ?>;
    let yearCurrentPage  = 1;
    let totalYears       = 0;
    const yearRowsPerPage = 10;

    function escapeHtml(v) {
        return String(v ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
    }

    function showAlert(message, type = 'success') {
        const cfg = {
            success: { title:'Success', color:'blue',   icon:'bi bi-check-circle-fill' },
            danger:  { title:'Error',   color:'red',    icon:'bi bi-exclamation-octagon-fill' },
            warning: { title:'Warning', color:'yellow', icon:'bi bi-exclamation-triangle-fill' },
            info:    { title:'Info',    color:'blue',   icon:'bi bi-info-circle-fill' }
        };
        const s = cfg[type] || cfg.success;
        iziToast.show({ title:s.title, message, color:s.color, icon:s.icon, iconColor:'#fff', theme:'light',
            position:'topRight', timeout:5000, progressBar:true, close:true, pauseOnHover:true,
            drag:true, transitionIn:'fadeInDown', transitionOut:'fadeOutUp', maxWidth:460 });
    }

    async function fetchJson(url, options = {}) {
        const res = await fetch(url, options);
        const raw = await res.text();
        try { return JSON.parse(raw); }
        catch (e) { console.error('Non-JSON:', raw);
        throw new Error('Server returned an invalid response.'); }
    }

    function updateActiveDisplays(activeYear) {
        if (activeYear !== undefined) {
            const el = document.getElementById('activeYearText');
            if (el) el.textContent = activeYear || 'None';
        }
    }

    async function refreshFooterStatus() {
        const yearEl = document.getElementById('footerAcademicYear');
        const quarterEl = document.getElementById('footerActiveQuarter');
        if (!yearEl || !quarterEl) return;

        try {
            const yearData = await fetchJson('api/academic-year/read.php?p=1&all=1');
            const activeYear = (yearData.all_years || []).find(year => Number(year.is_active) === 1);
            const yearLabel = activeYear?.year_label || '';

            if (!yearLabel) {
                yearEl.className = 'stsn-year-chip no-year';
                yearEl.innerHTML = '<i class="bi bi-calendar2-x"></i> No Active Year';
                quarterEl.className = 'stsn-year-chip no-year';
                quarterEl.innerHTML = '<i class="bi bi-calendar3"></i> No Active Quarter';
                return;
            }

            yearEl.className = 'stsn-year-chip';
            yearEl.innerHTML = `<i class="bi bi-calendar2-check-fill"></i> S.Y. ${escapeHtml(yearLabel)}`;

            const quarterData = await fetchJson(`api/quarters/read.php?view_year_id=${encodeURIComponent(activeYear.id)}`);
            const activeQuarter = quarterData.active_quarter;
            if (activeQuarter && Number(activeQuarter.academic_year_id) === Number(activeYear.id)) {
                quarterEl.className = 'stsn-year-chip';
                quarterEl.innerHTML = `<i class="bi bi-calendar3"></i> ${escapeHtml(activeQuarter.quarter_label)} Quarter`;
            } else {
                quarterEl.className = 'stsn-year-chip no-year';
                quarterEl.innerHTML = '<i class="bi bi-calendar3"></i> No Active Quarter';
            }
        } catch (error) {
            console.warn('Footer status refresh failed.', error);
        }
    }

    function buildPagination(containerId, currentPage, totalPages, onClickFn) {
        let html = `<li class="am-page-item ${currentPage<=1?'disabled':''}">
            <a class="am-page-link" href="javascript:void(0)" onclick="${onClickFn}(${currentPage-1})">Previous</a></li>`;
        for (let n = 1; n <= totalPages; n++) {
            html += `<li class="am-page-item ${n===currentPage?'active':''}">
                <a class="am-page-link" href="javascript:void(0)" onclick="${onClickFn}(${n})">${n}</a></li>`;
        }
        html += `<li class="am-page-item ${currentPage>=totalPages?'disabled':''}">
            <a class="am-page-link" href="javascript:void(0)" onclick="${onClickFn}(${currentPage+1})">Next</a></li>`;
        document.getElementById(containerId).innerHTML = html;
    }

    function showPromoBanner(msg) {
        const banner = document.getElementById('promoBanner');
        const text   = document.getElementById('promoBannerText');
        if (!banner || !text) return;
        text.textContent = msg;
        banner.classList.remove('d-none');
        setTimeout(() => banner.classList.add('d-none'), 8000);
    }

    // ── Tab switching ──────────────────────────────────────────────────────────
    function switchTab(name) {
        ['years','quarters'].forEach(t => {
            document.getElementById(`tab-${t}`).classList.toggle('active', t === name);
            document.getElementById(`pane-${t}`).style.display = t === name ? '' : 'none';
        });
        if (name === 'years')    loadYears(yearCurrentPage);
    }

    // ── Academic Years ─────────────────────────────────────────────────────────
    async function loadYears(page = 1) {
        yearCurrentPage = page;
        try {
            const data = await fetchJson(`api/academic-year/read.php?p=${page}`);
            totalYears = Number(data.total || 0);
            renderYears(data.years || [], data.page || 1, data.pages || 1, data.active_year || '');
        } catch (e) { showAlert(e.message, 'danger'); }
    }

    function renderYears(list, page, pages, activeYear) {
        const tbody    = document.getElementById('yearTableBody');
        const cardView = document.getElementById('yearCardView');
        const countEl  = document.getElementById('yearCountText');
        updateActiveDisplays(activeYear);
        if (!list.length) {
            const emptyMessage = 'No academic years to display.';
            tbody.innerHTML = `<tr><td colspan="5" class="text-center py-4 text-muted">${emptyMessage}</td></tr>`;
            cardView.innerHTML = `<div class="text-center py-4 text-muted">${emptyMessage}</div>`;
            if (countEl) countEl.textContent = 'No academic years to display.';
            document.getElementById('yearPagination').innerHTML = '';
            return;
        }

        const offset = (page - 1) * yearRowsPerPage;
        if (countEl) countEl.textContent = `Showing ${offset+1}–${offset+list.length} of ${totalYears} academic year${totalYears===1?'':'s'}`;
        tbody.innerHTML = list.map((y, i) => {
            const isActive = Number(y.is_active) === 1;
            const badge    = isActive
                ? `<span class="am-badge am-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                : `<span class="am-badge am-badge-inactive">Inactive</span>`;
            const toggleBtn = isActive
                ? `<button class="btn-am btn-am-deactivate" onclick="toggleYear(${y.id},0)"><i class="bi bi-power"></i> Deactivate</button>`
                : `<button class="btn-am btn-am-activate" onclick="toggleYear(${y.id},1)"><i class="bi bi-play-circle"></i> Activate</button>`;
            
            const structureMap = {
                quarterly: { label: 'Quarterly', count: 4, badge: 'background:#e0f2fe;color:#075985;' },
                trimester: { label: 'Trimester', count: 3, badge: 'background:#1248a8;color:#ffffff;' },
                semestral: { label: 'Semestral', count: 2, badge: 'background:#e0f2fe;color:#075985;' }
            };
            const structureInfo = structureMap[y.term_structure] || structureMap.trimester;
            const termLabel = `${structureInfo.label} (${structureInfo.count})`;
            
            return `<tr>
                <td style="text-align:center;"><span class="am-row-num">${offset+i+1}</span></td>
                <td><span class="am-year-name">${escapeHtml(y.year_label)}</span></td>
                <td><span class="am-badge" style="${structureInfo.badge}">${escapeHtml(termLabel)}</span></td>
                <td style="text-align:center;">${badge}</td>
                <td style="text-align:center;"><div class="am-actions">${toggleBtn}</div></td>
            </tr>`;
        }).join('');

        cardView.innerHTML = list.map((y, i) => {
            const isActive = Number(y.is_active) === 1;
            const badge    = isActive
                ? `<span class="am-badge am-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                : `<span class="am-badge am-badge-inactive">Inactive</span>`;
            const toggleBtn = isActive
                ? `<button class="btn-am btn-am-deactivate w-100" onclick="toggleYear(${y.id},0)"><i class="bi bi-power"></i> Deactivate</button>`
                : `<button class="btn-am btn-am-activate w-100" onclick="toggleYear(${y.id},1)"><i class="bi bi-play-circle"></i> Activate</button>`;
            
            const structureMapM = {
                quarterly: { label: 'Quarterly', count: 4 },
                trimester: { label: 'Trimester', count: 3 },
                semestral: { label: 'Semestral', count: 2 }
            };
            const structureInfoM = structureMapM[y.term_structure] || structureMapM.trimester;
            const termLabel = `${structureInfoM.label} (${structureInfoM.count})`;
            
            return `<div class="am-mobile-card">
                <div class="am-mobile-card-header">
                    <div><div class="am-mobile-card-title">${offset+i+1}. ${escapeHtml(y.year_label)}</div></div>
                    ${badge}
                </div>
                <div class="am-mobile-card-body">
                    <div style="font-size:.85rem;color:var(--am-text-muted);margin-bottom:.5rem;">
                        <div><strong>Term:</strong> ${escapeHtml(termLabel)}</div>
                    </div>
                    <div class="am-mobile-actions">${toggleBtn}</div>
                </div>
            </div>`;
        }).join('');

        buildPagination('yearPagination', page, pages, 'loadYears');
    }

    function toggleYear(id, newState) {
        const msg = newState
            ? 'Activate this academic year? Students from the previous year will be automatically promoted to the next grade level.'
            : 'Are you sure you want to deactivate this academic year?';
        iziToast.question({
            timeout:20000, close:false, overlay:true, displayMode:'once',
            id:'ay-toggle', zindex:9999, title:'Confirm',
            message: msg, position:'center',
            color: newState ? 'blue' : 'yellow', icon:'bi bi-question-circle-fill',
            buttons: [
                ['<button><b>Yes</b></button>', async function(instance, toast) {
                    instance.hide({transitionOut:'fadeOut'}, toast, 'button');
                    try {
                        const res = await fetchJson('api/academic-year/toggle.php', {
                            method:'POST', headers:{'Content-Type':'application/json'},
                            body: JSON.stringify({id, is_active: newState})
                        });
                        if (!res.success && Number(res.pending_review || 0) > 0 && res.redirect) {
                            showAlert(`Please review ${res.pending_review} student${Number(res.pending_review) === 1 ? '' : 's'} first.`, 'danger');
                            window.setTimeout(() => {
                                window.location.href = res.redirect;
                            }, 1500);
                        } else if (res.success) {
                            showAlert(res.message, 'success');
                            if (res.promoted > 0 || res.retained > 0 || res.graduated > 0) {
                                showPromoBanner(`Promotion complete — Promoted: ${res.promoted}, Retained: ${res.retained}, Graduated: ${res.graduated}.`);
                            }
                            loadYears(yearCurrentPage);
                            updateQYearNavigator();
                            refreshFooterStatus();
                            if (typeof window.refreshAcademicYearDot === 'function') {
                                window.refreshAcademicYearDot();
                            }
                        } else {
                            showAlert(res.message || res.error || 'Toggle failed.', 'danger');
                        }
                    } catch(e) { showAlert(e.message, 'danger');
                    }
                }, true],
                ['<button>No</button>', function(instance, toast) {
                    instance.hide({transitionOut:'fadeOut'}, toast, 'button');
                }]
            ]
        });
    }

    document.getElementById('yearForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        const payload = { 
            id: document.getElementById('yearId').value || null, 
            year_label: document.getElementById('yearLabel').value.trim(),
            term_structure: document.getElementById('termStructure').value.trim()
        };
        try {
            const res = await fetchJson('api/academic-year/save.php', {
                method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)
            });
            if (!res.success && Number(res.pending_review || 0) > 0 && res.redirect) {
                showAlert(`Please review ${res.pending_review} students first.`, 'danger');
                window.setTimeout(() => {
                    window.location.href = res.redirect;
                }, 1500);
            } else if (res.success) {
                bootstrap.Modal.getInstance(document.getElementById('yearModal')).hide();
                this.reset();
                showAlert(res.message, 'success');
                loadYears(yearCurrentPage);
                updateQYearNavigator();
                if (typeof window.refreshAcademicYearDot === 'function') {
                    window.refreshAcademicYearDot();
                }
            } else {
                showAlert(res.message || res.error || 'Save failed.', 'danger');
            }
        } catch(e) { showAlert(e.message, 'danger'); }
    });

    document.getElementById('yearModal').addEventListener('hidden.bs.modal', () => {
        document.getElementById('yearForm').reset();
        document.getElementById('yearId').value = '';
        document.getElementById('yearModalTitle').innerHTML = '<i class="bi bi-calendar-plus me-2"></i>New Academic Year';
    });

    // ── Grading Terms: manually controlled by an administrator ────────────────

    const activeTermNumber = <?= $activeTermNumber ?>;
    let pendingTermActivation = null;

    async function submitTermActivation(termId, termNumber, showModal) {
        const errorContainer = document.getElementById('activateTermError');
        const errorText = document.getElementById('activateTermErrorText');
        if (showModal) errorContainer.classList.add('d-none');

        try {
            const result = await fetchJson('api/terms/activate.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    term_id: termId,
                    term_number: termNumber,
                    academic_year_id: <?= (int) ($activeYearId ?? 0) ?>,
                    close_previous: true
                })
            });
            if (!result.success) throw new Error(result.message || 'The term could not be activated.');

            if (showModal) bootstrap.Modal.getOrCreateInstance(document.getElementById('activateTermModal')).hide();
            showAlert(result.message || 'Term activated successfully.', 'success');
            window.setTimeout(() => window.location.reload(), 1200);
            return true;
        } catch (error) {
            if (showModal) {
                errorText.textContent = error.message;
                errorContainer.classList.remove('d-none');
            } else {
                showAlert(error.message, 'danger');
            }
            return false;
        } finally {
            const confirmButton = document.getElementById('activateTermConfirmBtn');
            confirmButton.disabled = false;
            confirmButton.innerHTML = '<i class="bi bi-play-circle me-1"></i>Activate';
        }
    }

    function activateTerm(termNumber, termLabel, previousLabel, termId) {
        if (termNumber === 1 || activeTermNumber === 0) {
            submitTermActivation(termId, termNumber, false);
            return;
        }

        pendingTermActivation = {termId, termNumber};
        document.getElementById('activateTermLabel').textContent = termLabel;
        document.getElementById('activatePrevTermLabel').textContent = previousLabel;
        document.getElementById('activateTermError').classList.add('d-none');
        bootstrap.Modal.getOrCreateInstance(document.getElementById('activateTermModal')).show();
    }

    document.querySelectorAll('.js-activate-term').forEach(button => {
        button.addEventListener('click', () => activateTerm(
            Number(button.dataset.termNumber),
            button.dataset.termLabel || 'the next term',
            button.dataset.prevTermLabel || 'the previous term',
            Number(button.dataset.termId)
        ));
    });

    document.getElementById('activateTermConfirmBtn').addEventListener('click', async function() {
        if (!pendingTermActivation) return;
        this.disabled = true;
        this.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Activating';
        const activated = await submitTermActivation(
            pendingTermActivation.termId,
            pendingTermActivation.termNumber,
            true
        );
        if (activated) pendingTermActivation = null;
    });

    function confirmTermAction(button) {
        const termId = Number(button.dataset.termId);
        const termLabel = button.dataset.termLabel || 'this term';
        const message = `Close ${termLabel}? This will lock all grades for this term. Cannot be undone.`;

        iziToast.question({
            timeout: 20000, close: false, overlay: true, displayMode: 'once',
            title: 'Confirm', message, position: 'center',
            color: 'red', icon: 'bi bi-question-circle-fill',
            buttons: [
                ['<button><b>Yes</b></button>', async function(instance, toast) {
                    instance.hide({transitionOut: 'fadeOut'}, toast, 'button');
                    try {
                        const result = await fetchJson('api/terms/close.php', {
                            method: 'POST',
                            headers: {'Content-Type': 'application/json'},
                            body: JSON.stringify({term_id: termId})
                        });
                        if (!result.success) {
                            showAlert(result.message || 'The term action failed.', 'danger');
                            return;
                        }
                        showAlert(result.message, 'success');
                        window.location.href = 'academic_year.php?tab=quarters';
                    } catch (error) {
                        showAlert(error.message, 'danger');
                    }
                }, true],
                ['<button>No</button>', function(instance, toast) {
                    instance.hide({transitionOut: 'fadeOut'}, toast, 'button');
                }]
            ]
        });
    }

    document.querySelectorAll('.js-close-term').forEach(button => {
        button.addEventListener('click', () => confirmTermAction(button));
    });

    async function updateQYearNavigator() {
        try {
            const data = await fetchJson('api/academic-year/read.php?p=1&all=1');
            if (data.all_years && data.all_years.length) {
                const activeYear = data.all_years.find(y => Number(y.is_active) === 1) || data.all_years[0];
                currentQYearId = activeYear.id;
                const input = document.getElementById('yearNavigator');
                const chip = document.getElementById('yearNavigatorChip');
                if (input) input.value = activeYear.id;
                if (chip) chip.innerHTML = `<i class="bi bi-calendar2-check"></i> S.Y. ${escapeHtml(activeYear.year_label)}`;
            }
        } catch(_) {}
    }

    // Terms are rendered server-side and actions refresh the active-year list.

    const defaultTab = '<?= $defaultTab ?>';
    if (defaultTab !== 'quarters') loadYears();

    window.setInterval(() => {
        refreshFooterStatus();
    }, 60000);
</script>
</body>
</html>