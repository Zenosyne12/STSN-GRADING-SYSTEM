<?php
session_start();
require_once __DIR__ . '/api/shared/CSRFToken.php';

// If no user_id in session, redirect back to forgot password
$user_id = $_SESSION['reset_user_id'] ?? null;
if (!$user_id) {
    header("Location: forgot_password.php");
    exit;
}

$csrfToken = CSRFToken::generate();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter Code - STSN Grading System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        :root {
            --maroon: #9e112d;
            --maroon-dark: #7d0d24;
            --navy: #173b67;
            --muted: #777;
            --border: #e6d9dc;
            --input-bg: rgba(255, 255, 255, 0.92);
        }
        * { box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background: #f8f7f6; }
        
        .main-wrapper {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }
        .code-card {
            width: 100%;
            max-width: 430px;
            background: rgba(255, 255, 255, 0.96);
            border-radius: 22px;
            padding: 30px 26px 24px;
            box-shadow: 0 22px 60px rgba(0, 0, 0, 0.22);
            border: 1px solid rgba(255, 255, 255, 0.45);
            backdrop-filter: blur(6px);
        }
        .brand {
            text-align: center;
            margin-bottom: 20px;
        }
        .brand-logo {
            width: 76px; height: 76px;
            margin: 0 auto 14px;
            border-radius: 18px;
            background: linear-gradient(145deg, #fff, #f7efef);
            border: 1px solid var(--border);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 10px 22px rgba(158, 17, 45, 0.08);
        }
        .brand-logo img {
            width: 50px; height: 50px;
            object-fit: contain;
        }
        .brand h1 {
            margin: 0;
            font-size: 1.9rem;
            font-weight: 700;
            color: var(--maroon);
            line-height: 1.1;
        }
        .brand p {
            margin: 8px auto 0;
            max-width: 300px;
            font-size: .93rem;
            color: var(--muted);
        }
        .school-name {
            margin-top: 10px;
            font-size: .8rem;
            font-weight: 700;
            color: var(--navy);
            text-transform: uppercase;
            letter-spacing: .04em;
        }
        
        .alert-box {
            display: flex;
            gap: 10px;
            align-items: flex-start;
            border-radius: 14px;
            padding: 12px 13px;
            margin-bottom: 16px;
            font-size: .88rem;
        }
        .alert-error {
            background: #fff1f3;
            border: 1px solid #f3c3cb;
            color: #8a1830;
        }
        
        .hint-box {
            background: #fff8eb;
            border: 1px solid #f1dfb6;
            color: #7a5d23;
            border-radius: 14px;
            padding: 12px 13px;
            margin-bottom: 18px;
            font-size: .84rem;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-size: .9rem;
            font-weight: 700;
            color: #56494b;
        }
        .input-wrap {
            position: relative;
        }
        .input-icon {
            position: absolute;
            top: 50%; left: 14px;
            transform: translateY(-50%);
            color: #9a8d8f;
            font-size: .95rem;
        }
        .form-control {
            width: 100%;
            height: 54px;
            border: 1px solid var(--border);
            border-radius: 15px;
            background: var(--input-bg);
            padding: 0 44px 0 42px;
            font-family: 'Courier New', monospace;
            font-size: 1.2rem;
            font-weight: bold;
            letter-spacing: 3px;
            color: #2b2b2b;
            text-transform: uppercase;
            outline: none;
            transition: .18s ease;
        }
        .form-control:focus {
            border-color: rgba(158, 17, 45, .45);
            box-shadow: 0 0 0 4px rgba(158, 17, 45, 0.08);
            background: #fff;
        }
        .form-control.error {
            border-color: #f3c3cb;
            background: #fff1f3;
        }
        
        .submit-btn {
            width: 100%;
            height: 54px;
            border: none;
            border-radius: 15px;
            background: linear-gradient(135deg, var(--maroon), var(--maroon-dark));
            color: #fff;
            font-family: inherit;
            font-size: .94rem;
            font-weight: 700;
            letter-spacing: .02em;
            cursor: pointer;
            box-shadow: 0 14px 28px rgba(158, 17, 45, 0.22);
            transition: .18s ease;
        }
        .submit-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        .submit-btn:hover:not(:disabled) {
            transform: translateY(-1px);
            box-shadow: 0 16px 32px rgba(158, 17, 45, 0.26);
        }
        
        .timer {
            text-align: center;
            font-size: .9rem;
            color: #666;
            margin-bottom: 15px;
        }
        .timer.warning {
            color: #dc3545;
            font-weight: bold;
        }
        
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: var(--maroon);
            text-decoration: none;
            font-weight: 600;
            font-size: .9rem;
        }
        .back-link:hover {
            text-decoration: underline;
        }
        
        @media (max-width: 480px) {
            .main-wrapper { padding: 16px; }
            .code-card { padding: 24px 18px 20px; }
            .brand h1 { font-size: 1.65rem; }
        }
    </style>
</head>
<body>
    <div class="main-wrapper">
        <div class="code-card">
            <div class="brand">
                <div class="brand-logo">
                    <img src="assets/img/stsn logo.png" alt="STSN Logo">
                </div>
                <h1>Enter Code</h1>
                <p>Check your email for the code</p>
                <div class="school-name">St. Theresa's School of Novaliches</div>
            </div>

            <div id="errorBox" class="alert-box alert-error" style="display: none;">
                <i class="bi bi-exclamation-octagon-fill"></i>
                <div id="errorMessage"></div>
            </div>

            <div class="hint-box">
                <i class="bi bi-info-circle me-2"></i>
                Code sent to your email. Valid for <strong>10 minutes</strong>.
            </div>

            <div class="timer" id="timer">
                Time remaining: <strong id="countdown">10:00</strong>
            </div>

            <form id="verifyForm">
                <input type="hidden" name="_csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                <input type="hidden" name="user_id" value="<?= htmlspecialchars($user_id) ?>">

                <div class="form-group">
                    <label class="form-label" for="code">
                        <i class="bi bi-shield-check me-2"></i>Verification Code
                    </label>
                    <div class="input-wrap">
                        <i class="bi bi-lock-fill input-icon"></i>
                        <input
                            type="text"
                            class="form-control"
                            name="code"
                            id="code"
                            placeholder="e.g. ABC12345"
                            required
                            maxlength="8"
                            autofocus
                        >
                    </div>
                </div>

                <button type="submit" class="submit-btn" id="submitBtn">
                    VERIFY CODE <i class="bi bi-arrow-right ms-1"></i>
                </button>
            </form>

            <a href="forgot_password.php" class="back-link">
                <i class="bi bi-arrow-left me-2"></i>Try different username
            </a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const form = document.getElementById('verifyForm');
            const codeInput = document.getElementById('code');
            const submitBtn = document.getElementById('submitBtn');
            const errorBox = document.getElementById('errorBox');
            const errorMessage = document.getElementById('errorMessage');
            const timerDiv = document.getElementById('timer');
            const countdown = document.getElementById('countdown');

            // Start countdown timer (10 minutes = 600 seconds)
            let timeLeft = 600;
            const timerInterval = setInterval(function () {
                timeLeft--;

                const minutes = Math.floor(timeLeft / 60);
                const seconds = timeLeft % 60;
                const display = minutes + ':' + (seconds < 10 ? '0' : '') + seconds;

                countdown.textContent = display;

                if (timeLeft <= 60) {
                    timerDiv.classList.add('warning');
                }

                if (timeLeft <= 0) {
                    clearInterval(timerInterval);
                    codeInput.disabled = true;
                    submitBtn.disabled = true;
                    errorMessage.textContent = 'Code has expired. Request a new one.';
                    errorBox.style.display = 'flex';
                }
            }, 1000);

            // Auto-format code (uppercase, max 8 chars)
            codeInput.addEventListener('input', function () {
                this.value = this.value.toUpperCase().substring(0, 8);
            });

            // Form submission
            form.addEventListener('submit', function (e) {
                e.preventDefault();

                const code = codeInput.value.trim();

                if (code.length !== 8) {
                    errorMessage.textContent = 'Code must be 8 characters (e.g., ABC12345)';
                    errorBox.style.display = 'flex';
                    return;
                }

                errorBox.style.display = 'none';
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Verifying...';

                // Send to verification endpoint
                fetch('api/login/verify_code.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'user_id=' + encodeURIComponent(document.querySelector('input[name="user_id"]').value) +
                          '&code=' + encodeURIComponent(code) +
                          '&_csrf_token=' + encodeURIComponent(document.querySelector('input[name="_csrf_token"]').value)
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        // Redirect to password reset
                        window.location.href = 'reset_password.php';
                    } else {
                        errorMessage.textContent = data.error || 'Invalid code';
                        errorBox.style.display = 'flex';
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = 'VERIFY CODE <i class="bi bi-arrow-right ms-1"></i>';
                    }
                })
                .catch(err => {
                    errorMessage.textContent = 'Error verifying code. Please try again.';
                    errorBox.style.display = 'flex';
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = 'VERIFY CODE <i class="bi bi-arrow-right ms-1"></i>';
                });
            });
        });
    </script>
</body>
</html>