<?php
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/api/shared/db_connect.php';
require_once __DIR__ . '/includes/archive_engine.php';
ensureProfileArchiveSchema($pdo);

$years = [];

try {
	$sql = "
		SELECT
			ay.id,
			ay.year_label,
			ay.is_active,
			ay.archived_at,
			(SELECT COUNT(*) FROM (
				SELECT student_id FROM tblstudent_archive WHERE academic_year_id = ay.id
				UNION
				SELECT student_id FROM tblsectionstudent WHERE academic_year_id = ay.id
				UNION
				SELECT student_id FROM tblenrollment WHERE academic_year_id = ay.id
			) AS year_students) AS student_count,
			(SELECT COUNT(DISTINCT ss.section_id) FROM tblsectionstudent ss WHERE ss.academic_year_id = ay.id) AS sections,
			(SELECT COUNT(DISTINCT sad.teacher_id) FROM tblsectionadviser sad WHERE sad.academic_year_id = ay.id) AS teacher_count,
			(SELECT COUNT(*) FROM tblgrades g WHERE g.academic_year_id = ay.id) AS grade_count
		FROM tblacademicyear ay
		WHERE 1=1
	";
	$sql .= ' ORDER BY ay.year_label DESC';
	$stmt = $pdo->query($sql);
	$years = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
	error_log('[historical_records] Failed to load archive years: ' . $e->getMessage());
	$years = [];
}

$archivedYears = array_values(array_filter($years, static fn($year) => !empty($year['archived_at'])));
$currentYears = array_values(array_filter($years, static fn($year) =>
	(int) $year['is_active'] === 1
	&& empty($year['archived_at'])
));
$archivedUserCount = array_sum(array_map(
	static fn($year) => (int) $year['student_count'] + (int) $year['teacher_count'],
	$archivedYears
));
$visibleArchiveYears = array_merge($currentYears, $archivedYears);
$totalArchived = count($archivedYears);
?>
<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>STSN Grading System | Academic Year Archive</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
	<link rel="stylesheet"
		href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
	<link rel="stylesheet" href="./css/adminlte.css">
	<link rel="stylesheet" href="./css/historical-records.css">

	<style>
		/* ============================================================
	   DARK MODE OVERRIDES for Historical Records page
	   ============================================================ */
		:root,
		[data-bs-theme="light"] {
			--hr-card-bg: #ffffff;
			--hr-card-soft: #fafcff;
			--hr-border: #dce8f8;
			--hr-border-soft: #e8f0fb;
			--hr-text: #213a5e;
			--hr-text-strong: #132f62;
			--hr-text-muted: #7a93b8;
			--hr-text-dim: #9ab0c8;
			--hr-input-bg: #ffffff;
			--hr-input-border: #c8daf8;
			--hr-input-text: #213a5e;
			--hr-input-placeholder: #9ab0c8;
			--hr-shadow: rgba(18, 72, 168, 0.06);
			--hr-icon-blue-bg: #eef4ff;
			--hr-icon-blue-text: #1248a8;
			--hr-icon-green-bg: #e8fbf1;
			--hr-icon-green-text: #0f6c45;
			--hr-icon-purple-bg: #f3ebff;
			--hr-icon-purple-text: #6a1ea8;
			--hr-status-active-bg: #e8fbf1;
			--hr-status-active-text: #0f6c45;
			--hr-status-archived-bg: #eef4ff;
			--hr-status-archived-text: #1248a8;
			--hr-view-bg: linear-gradient(130deg, #1a6ef5, #1248a8);
			--hr-view-text: #ffffff;
		}

		[data-bs-theme="dark"] {
			--hr-card-bg: #2D2D2D;
			--hr-card-soft: #262626;
			--hr-border: #3a3a3a;
			--hr-border-soft: #3a3a3a;
			--hr-text: #e4e6e8;
			--hr-text-strong: #ffffff;
			--hr-text-muted: #adb5bd;
			--hr-text-dim: #8b939a;
			--hr-input-bg: #3a3a3a;
			--hr-input-border: #4a5a6e;
			--hr-input-text: #e4e6e8;
			--hr-input-placeholder: #adb5bd;
			--hr-shadow: rgba(0, 0, 0, 0.35);
			--hr-icon-blue-bg: #1e2a3d;
			--hr-icon-blue-text: #8ab4f8;
			--hr-icon-green-bg: #17351f;
			--hr-icon-green-text: #6ee7a0;
			--hr-icon-purple-bg: #2d1e42;
			--hr-icon-purple-text: #c4b5fd;
			--hr-status-active-bg: #17351f;
			--hr-status-active-text: #6ee7a0;
			--hr-status-archived-bg: #1e2a3d;
			--hr-status-archived-text: #8ab4f8;
			--hr-view-bg: linear-gradient(130deg, #1a6ef5, #1248a8);
			--hr-view-text: #ffffff;
		}

		/* ✅ HINDI NA NAG-O-OVERRIDE NG BACKGROUND — text color lang */
		[data-bs-theme="dark"] .hr-archive-page {
			color: var(--hr-text);
		}

		/* Header */
		[data-bs-theme="dark"] .page-header {
			background: linear-gradient(130deg, #0f3573 0%, #0f4fb8 100%) !important;
			color: #ffffff !important;
		}

		[data-bs-theme="dark"] .page-header h3,
		[data-bs-theme="dark"] .page-header p {
			color: #ffffff !important;
		}

		/* Breadcrumb */
		[data-bs-theme="dark"] .breadcrumb,
		[data-bs-theme="dark"] .breadcrumb-wrapper,
		[data-bs-theme="dark"] .hr-breadcrumb {
			background: var(--hr-card-bg) !important;
			border-color: var(--hr-border) !important;
			color: var(--hr-text) !important;
		}

		[data-bs-theme="dark"] .breadcrumb a,
		[data-bs-theme="dark"] .breadcrumb-item a {
			color: #8ab4f8 !important;
		}

		[data-bs-theme="dark"] .breadcrumb-item.active,
		[data-bs-theme="dark"] .breadcrumb-item+.breadcrumb-item::before {
			color: var(--hr-text-muted) !important;
		}

		/* Summary cards */
		[data-bs-theme="dark"] .hr-summary-card {
			background: var(--hr-card-bg) !important;
			border: 1px solid var(--hr-border) !important;
			color: var(--hr-text) !important;
			box-shadow: 0 2px 12px var(--hr-shadow) !important;
		}

		[data-bs-theme="dark"] .hr-summary-card strong,
		[data-bs-theme="dark"] .hr-summary-card b {
			color: var(--hr-text-strong) !important;
		}

		[data-bs-theme="dark"] .hr-summary-card span {
			color: var(--hr-text-muted) !important;
		}

		[data-bs-theme="dark"] .hr-summary-card i {
			color: var(--hr-icon-blue-text) !important;
		}

		[data-bs-theme="dark"] .hr-summary-card.protected i {
			color: var(--hr-icon-green-text) !important;
		}

		[data-bs-theme="dark"] .hr-summary-badge {
			background: var(--hr-status-active-bg) !important;
			color: var(--hr-status-active-text) !important;
			border-color: var(--hr-border) !important;
		}

		/* Search toolbar */
		[data-bs-theme="dark"] .hr-archive-toolbar,
		[data-bs-theme="dark"] .hr-archive-search {
			background: var(--hr-input-bg) !important;
			border-color: var(--hr-input-border) !important;
			color: var(--hr-input-text) !important;
		}

		[data-bs-theme="dark"] .hr-archive-search i {
			color: var(--hr-text-muted) !important;
		}

		[data-bs-theme="dark"] .hr-archive-search input {
			background: transparent !important;
			border: 0 !important;
			color: var(--hr-input-text) !important;
		}

		[data-bs-theme="dark"] .hr-archive-search input::placeholder {
			color: var(--hr-input-placeholder) !important;
			opacity: 1 !important;
		}

		/* Table card */
		[data-bs-theme="dark"] .hr-archive-table-card {
			background: var(--hr-card-bg) !important;
			border-color: var(--hr-border) !important;
			color: var(--hr-text) !important;
			box-shadow: 0 2px 12px var(--hr-shadow) !important;
		}

		[data-bs-theme="dark"] .hr-archive-table {
			background: var(--hr-card-bg) !important;
			color: var(--hr-text) !important;
		}

		[data-bs-theme="dark"] .hr-archive-table thead th {
			background: var(--hr-card-soft) !important;
			color: var(--hr-text-strong) !important;
			border-bottom-color: var(--hr-border) !important;
		}

		[data-bs-theme="dark"] .hr-archive-table tbody td {
			background: var(--hr-card-bg) !important;
			color: var(--hr-text) !important;
			border-bottom-color: var(--hr-border-soft) !important;
		}

		[data-bs-theme="dark"] .hr-archive-table tbody tr:hover td {
			background: #353535 !important;
		}

		[data-bs-theme="dark"] .hr-archive-year {
			color: var(--hr-text-strong) !important;
			font-weight: 700;
		}

		[data-bs-theme="dark"] .hr-archive-empty {
			color: var(--hr-text-muted) !important;
			background: var(--hr-card-bg) !important;
		}

		/* Status badge */
		[data-bs-theme="dark"] .hr-archive-status {
			background: var(--hr-status-archived-bg) !important;
			color: var(--hr-status-archived-text) !important;
		}

		[data-bs-theme="dark"] .hr-archive-status.active {
			background: var(--hr-status-active-bg) !important;
			color: var(--hr-status-active-text) !important;
		}

		/* View Records button */
		[data-bs-theme="dark"] .hr-archive-view {
			background: var(--hr-view-bg) !important;
			color: var(--hr-view-text) !important;
			box-shadow: 0 2px 8px rgba(26, 110, 245, 0.25) !important;
		}

		[data-bs-theme="dark"] .hr-archive-view:hover {
			background: linear-gradient(130deg, #1560d8, #103d90) !important;
			color: #ffffff !important;
		}

		/* Table footer */
		[data-bs-theme="dark"] .hr-archive-footer {
			background: var(--hr-card-soft) !important;
			color: var(--hr-text-muted) !important;
			border-top-color: var(--hr-border) !important;
		}

		[data-bs-theme="dark"] .hr-archive-footer i {
			color: var(--hr-text-dim) !important;
		}

		/* Sidebar */
		[data-bs-theme="dark"] .sidebar-wrapper,
		[data-bs-theme="dark"] .app-sidebar,
		[data-bs-theme="dark"] .main-sidebar,
		[data-bs-theme="dark"] .custom-sidebar {
			background-color: #2D2D2D !important;
			color: #e4e6e8 !important;
		}

		[data-bs-theme="dark"] .sidebar-wrapper a,
		[data-bs-theme="dark"] .sidebar-wrapper .nav-link,
		[data-bs-theme="dark"] .sidebar-wrapper .sidebar-brand-text {
			color: #e4e6e8 !important;
		}

		[data-bs-theme="dark"] .sidebar-wrapper .nav-link:hover,
		[data-bs-theme="dark"] .sidebar-wrapper .nav-link.active {
			background-color: #3a3a3a !important;
			color: #ffffff !important;
		}

		/* Footer */
		[data-bs-theme="dark"] .app-footer,
		[data-bs-theme="dark"] footer.main-footer {
			background: #2D2D2D !important;
			color: #adb5bd !important;
			border-top-color: #3a3a3a !important;
		}

		/* Text helpers */
		[data-bs-theme="dark"] .hr-archive-page h1,
		[data-bs-theme="dark"] .hr-archive-page h2,
		[data-bs-theme="dark"] .hr-archive-page h3,
		[data-bs-theme="dark"] .hr-archive-page h4,
		[data-bs-theme="dark"] .hr-archive-page h5,
		[data-bs-theme="dark"] .hr-archive-page h6 {
			color: var(--hr-text-strong) !important;
		}

		[data-bs-theme="dark"] .hr-archive-page a {
			color: #8ab4f8;
		}

		[data-bs-theme="dark"] .hr-archive-page a:hover {
			color: #b3ceff;
		}
		/* ============================================================
		   Historical Records — Compact Archive Cards ("baraha" grid)
		   ============================================================ */
		.hr-archive-grid {
			display: grid;
			grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
			gap: 1rem;
			margin-top: 1rem;
		}
		.hr-archive-card {
			background: var(--hr-card-bg);
			border: 1.5px solid var(--hr-border);
			border-radius: 14px;
			box-shadow: 0 2px 10px var(--hr-shadow);
			overflow: hidden;
			transition: all 0.18s ease;
			display: flex;
			flex-direction: column;
			height: 100%;
		}
		.hr-archive-card:hover {
			transform: translateY(-3px);
			box-shadow: 0 10px 28px rgba(18,72,168,0.12);
			border-color: #b8d0fa;
		}
		.hr-archive-card:focus {
			outline: none;
			border-color: #1a6ef5;
			box-shadow: 0 0 0 3px rgba(26,110,245,0.15);
		}
		.hr-archive-card-header {
			display: flex;
			align-items: flex-start;
			justify-content: space-between;
			gap: 0.5rem;
			padding: 0.9rem 1rem;
			border-bottom: 1px solid #e8f0fb;
			background: #fafcff;
		}
		.hr-archive-icon {
			width: 40px;
			height: 40px;
			border-radius: 10px;
			background: #f3f5f8;
			color: #7a8ea8;
			display: flex;
			align-items: center;
			justify-content: center;
			font-size: 1.15rem;
			flex-shrink: 0;
		}
		.hr-archive-heading { display: flex; align-items: center; gap: 0.75rem; min-width: 0; }
		.hr-archive-title { font-size: 1rem; font-weight: 800; color: #132f62; line-height: 1.25; margin: 0 0 0.15rem; }
		.hr-archive-sub { font-size: 0.72rem; color: #7a93b8; margin: 0; line-height: 1.3; }
		.hr-archive-badge {
			display: inline-flex;
			align-items: center;
			padding: 0.25rem 0.6rem;
			border-radius: 999px;
			font-size: 0.65rem;
			font-weight: 700;
			text-transform: uppercase;
			letter-spacing: 0.04em;
			background: #f3f5f8;
			color: #7a8ea8;
			border: 1px solid #dde4ee;
			white-space: nowrap;
			flex-shrink: 0;
		}
		.hr-archive-badge.archived {
			background: #e6f0ff;
			color: #1248a8;
			border-color: #b8d0fa;
		}
		.hr-archive-badge.current {
			background: #e8fbf1;
			color: #0f6c45;
			border-color: #a3dbb5;
		}
		.hr-archive-body { padding: 0.9rem 1rem; flex: 1 1 auto; }
		.hr-mini-stats { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 0.5rem; }
		.hr-mini-stat {
			background: #f8fbff;
			border-radius: 8px;
			padding: 0.5rem 0.6rem;
			display: flex;
			flex-direction: column;
			align-items: center;
			text-align: center;
			gap: 0.1rem;
		}
		.hr-mini-stat strong { font-size: 1.05rem; font-weight: 800; color: #132f62; line-height: 1; }
		.hr-mini-stat span { font-size: 0.65rem; color: #7a93b8; text-transform: uppercase; letter-spacing: 0.04em; font-weight: 600; }
		.hr-archive-card .hr-archive-footer {
			display: flex;
			gap: 0.4rem;
			padding: 0.75rem 1rem;
			border-top: 1px solid var(--hr-border-soft);
			background: var(--hr-card-soft);
		}
		.hr-archive-card .hr-archive-footer .btn {
			display: inline-flex;
			align-items: center;
			justify-content: center;
			flex: 1 1 0;
			min-width: 0;
			font-size: 0.72rem;
			padding: 0.35rem 0.45rem;
			white-space: nowrap;
		}
		.hr-archive-card .hr-archive-footer .btn:disabled {
			opacity: 0.5;
			cursor: not-allowed;
		}
		.hr-archive-empty-state { grid-column: 1 / -1; text-align: center; padding: 3rem 1rem; color: #9ab0c8; }
		.hr-archive-empty-state i { font-size: 2.5rem; display: block; margin-bottom: 0.75rem; opacity: 0.6; }

		/* Dark mode — compact archive cards */
		[data-bs-theme="dark"] .hr-archive-card { background: var(--hr-card-bg); border-color: var(--hr-border); }
		[data-bs-theme="dark"] .hr-archive-card-header { background: var(--hr-card-soft); border-color: var(--hr-border); }
		[data-bs-theme="dark"] .hr-archive-card .hr-archive-footer { background: var(--hr-card-soft); border-color: var(--hr-border); }
		[data-bs-theme="dark"] .hr-archive-icon,
		[data-bs-theme="dark"] .hr-archive-badge { background: #333; color: #adb5bd; border-color: #444; }
		[data-bs-theme="dark"] .hr-archive-badge.archived {
			background: #1e2a3d;
			color: #8ab4f8;
			border-color: #2d4366;
		}
		[data-bs-theme="dark"] .hr-archive-badge.current {
			background: #17351f;
			color: #6ee7a0;
			border-color: #2b5c38;
		}
		[data-bs-theme="dark"] .hr-archive-title { color: var(--hr-text-strong); }
		[data-bs-theme="dark"] .hr-archive-sub { color: var(--hr-text-muted); }
		[data-bs-theme="dark"] .hr-mini-stat { background: #1f1f1f; }
		[data-bs-theme="dark"] .hr-mini-stat strong { color: #f1f3f5; }
		[data-bs-theme="dark"] .hr-mini-stat span { color: #adb5bd; }

		@media (max-width: 380px) {
			.hr-archive-card .hr-archive-footer { flex-direction: column; }
		}

		@media (max-width: 767.98px) {
			.hr-archive-grid { grid-template-columns: 1fr; }
		}
	</style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
	<div class="app-wrapper">
		<?php require_once __DIR__ . '/includes/header.php'; ?>
		<?php require_once __DIR__ . '/includes/sidebar.php'; ?>

		<main class="app-main">
			<div class="app-content">
				<div class="container-fluid py-3 hr-archive-page">
					<div class="page-header">
						<div>
							<h3><i class="bi bi-calendar3 me-2"></i>Academic Year Archive</h3>
							<p>Academic years and their records</p>
						</div>
					</div>

					<?php require_once __DIR__ . '/includes/breadcrumb.php';
					renderBreadcrumb([
						['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door'],
						['label' => 'Archive', 'href' => 'historical_records.php', 'icon' => 'bi bi-archive'],
						['label' => 'Historical Records', 'icon' => 'bi bi-clock-history']
					]); ?>

					<section class="hr-summary-grid" aria-label="Archive summary">
						<div class="hr-summary-card stsn-anim-fade-in-up">
							<i class="bi bi-archive-fill"></i>
							<strong><?= $totalArchived ?></strong>
							<b>Archived Academic Years</b>
							<span>Academic years preserved</span>
						</div>
						<div class="hr-summary-card stsn-anim-fade-in-up stsn-anim-delay-100">
							<i class="bi bi-people-fill"></i>
							<strong><?= number_format($archivedUserCount) ?></strong>
							<b>Archived Users</b>
							<span>Historical student and teacher records</span>
						</div>
						<div class="hr-summary-card stsn-anim-fade-in-up stsn-anim-delay-200">
							<i class="bi bi-clipboard2-fill"></i>
							<strong><?= number_format(array_sum(array_map(static fn($year) => (int) $year['grade_count'], $archivedYears))) ?></strong>
							<b>Archived Grade Records</b>
							<span>Historical grade entries</span>
						</div>
					</section>

					<div class="hr-archive-toolbar">
						<label class="hr-archive-search">
							<i class="bi bi-search"></i>
							<input type="search" id="archiveYearSearch"
								placeholder="Search academic years..." aria-label="Search academic years">
						</label>
					</div>

					<section>
						<?php if (!$visibleArchiveYears): ?>
							<div class="hr-archive-empty-state">
								<i class="bi bi-archive"></i>
								<strong>No archived years yet</strong>
								<p class="mb-0 mt-2" style="font-size:0.85rem;">Archived academic years and archived profiles will appear here.</p>
							</div>
						<?php else: ?>
							<div class="row g-3" id="archivedYearCards">
								<?php foreach ($visibleArchiveYears as $index => $year): ?>
								<div class="col-md-6 col-lg-4 archive-year-card" data-school-year="<?= htmlspecialchars((string)$year['year_label'], ENT_QUOTES, 'UTF-8') ?>">
									<div class="hr-archive-card stsn-anim-fade-in-up <?= ['', 'stsn-anim-delay-100', 'stsn-anim-delay-200', 'stsn-anim-delay-300'][$index % 4] ?>">
										<div class="hr-archive-card-header">
											<div class="hr-archive-heading">
												<div class="hr-archive-icon"><i class="bi bi-archive-fill"></i></div>
												<div>
													<h5 class="hr-archive-title">Series of <?= htmlspecialchars($year['year_label']) ?></h5>
													<p class="hr-archive-sub">
														<?= !empty($year['archived_at'])
															? 'Archived on ' . htmlspecialchars(date('M d, Y', strtotime($year['archived_at'])))
															: 'Current academic year records' ?>
													</p>
												</div>
											</div>
											<span class="hr-archive-badge <?= !empty($year['archived_at']) ? 'archived' : 'current' ?>"><?= !empty($year['archived_at']) ? 'Archived' : 'Current Year' ?></span>
										</div>
										<div class="hr-archive-body">
											<div class="hr-mini-stats">
												<div class="hr-mini-stat">
													<strong><?= (int)$year['student_count'] ?></strong>
													<span>Students</span>
												</div>
												<div class="hr-mini-stat">
													<strong><?= (int)$year['teacher_count'] ?></strong>
													<span>Teachers</span>
												</div>
												<div class="hr-mini-stat">
													<strong><?= (int)$year['grade_count'] ?></strong>
													<span>Grades</span>
												</div>
											</div>
										</div>
										<div class="hr-archive-footer">
											<a href="historical_selection.php?year_id=<?= (int)$year['id'] ?>"
											   class="btn btn-outline-primary btn-sm hr-archive-view">
												<i class="bi bi-eye me-1"></i>View Records
											</a>
											<?php if (!empty($year['archived_at']) && (int) $year['is_active'] !== 1): ?>
												<button type="button" class="btn btn-outline-primary btn-sm"
													onclick="restoreArchivedYear(<?= (int) $year['id'] ?>, <?= htmlspecialchars(json_encode((string) $year['year_label']), ENT_QUOTES, 'UTF-8') ?>)">
													<i class="bi bi-arrow-counterclockwise me-1"></i>Restore
												</button>
											<?php endif; ?>
										</div>
									</div>
								</div>
								<?php endforeach; ?>
							</div>
							<div id="archiveYearNoResults" class="hr-archive-empty-state" style="display:none;">
								<i class="bi bi-search"></i>
								<strong>No matching archived years</strong>
							</div>
						<?php endif; ?>
						<footer class="hr-archive-footer">
							<span><?= $totalArchived ?> archived academic year<?= $totalArchived === 1 ? '' : 's' ?> · <?= count($currentYears) ?> current academic year<?= count($currentYears) === 1 ? '' : 's' ?> shown</span>
							<span><i class="bi bi-lock"></i> Year records are read-only; individually archived profiles can be restored</span>
						</footer>
					</section>
				</div>
			</div>
		</main>
		<?php require_once __DIR__ . '/includes/footer.php'; ?>
	</div>
	<div class="modal fade" id="restoreConfirmModal" tabindex="-1" aria-labelledby="restoreConfirmTitle" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content" style="border-radius:14px;overflow:hidden;border:none;">
				<div class="modal-header" style="background:linear-gradient(130deg,#1248a8 0%,#1a6ef5 100%);color:#fff;border:none;padding:1rem 1.25rem;">
					<h5 class="modal-title" id="restoreConfirmTitle">
						<i class="bi bi-arrow-counterclockwise me-2"></i>Restore Academic Year?
					</h5>
					<button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body" style="padding:1.5rem;">
					<p class="mb-2">
						Restore <strong id="restoreYearLabel">S.Y. 2026-2027</strong>?
					</p>
					<ul style="color:#64748b;font-size:0.9rem;">
						<li>This will make it the active academic year.</li>
						<li>Archived data will become editable again.</li>
						<li>Terms, grades, and schedules will be reactivated.</li>
					</ul>
					<div id="restoreError" class="alert alert-danger d-none mt-3 mb-0"
						style="border-radius:10px;font-size:0.9rem;">
						<i class="bi bi-exclamation-triangle-fill me-2"></i>
						<span id="restoreErrorText"></span>
					</div>
				</div>
				<div class="modal-footer" style="background:#f8fafc;border-top:1px solid #e2e8f0;padding:0.85rem 1.25rem;">
					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
						Cancel
					</button>
					<button type="button" class="btn btn-primary" id="restoreConfirmBtn"
						style="background:linear-gradient(130deg,#1248a8 0%,#1a6ef5 100%);border:none;font-weight:600;">
						<i class="bi bi-arrow-counterclockwise me-1"></i>Yes, Restore Year
					</button>
				</div>
			</div>
		</div>
	</div>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
	<script src="./js/adminlte.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>
	<script>
		let pendingRestoreYearId = null;
		let pendingRestoreYearLabel = '';

		function restoreArchivedYear(yearId, yearLabel) {
			pendingRestoreYearId = yearId;
			pendingRestoreYearLabel = yearLabel;

			const errorBox = document.getElementById('restoreError');
			if (errorBox) errorBox.classList.add('d-none');

			document.getElementById('restoreYearLabel').textContent = 'S.Y. ' + yearLabel;
			bootstrap.Modal.getOrCreateInstance(document.getElementById('restoreConfirmModal')).show();
		}

		document.getElementById('restoreConfirmBtn').addEventListener('click', async function () {
			if (!pendingRestoreYearId) return;

			const button = this;
			const originalHtml = button.innerHTML;
			button.disabled = true;
			button.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Restoring...';

			const errorBox = document.getElementById('restoreError');
			const errorText = document.getElementById('restoreErrorText');
			if (errorBox) errorBox.classList.add('d-none');

			try {
				const response = await fetch('api/archive/restore.php', {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify({
						type: 'year',
						year_id: pendingRestoreYearId,
						reason: 'Manual restore by admin'
					})
				});
				const result = await response.json();
				if (!response.ok || !result.success) {
					throw new Error(result.message || result.error || 'Restore failed.');
				}

				if (typeof window.refreshAcademicYearDot === 'function') {
					window.refreshAcademicYearDot();
				}

				console.log('Restore response:', result);
				console.log('Restore response message:', result.message);

				const responseMessage = typeof result.message === 'string' ? result.message.trim() : '';
				const responseYearLabel = typeof result.year_label === 'string' ? result.year_label.trim() : '';
				const yearLabel = typeof pendingRestoreYearLabel === 'string'
					? pendingRestoreYearLabel.trim()
					: responseYearLabel;
				const successMessage = responseMessage
					|| (yearLabel ? `S.Y. ${yearLabel} restored successfully.` : 'Academic year restored successfully.');
				console.log('SHOWING SUCCESS TOAST:', successMessage);
				console.log('result.success was:', result.success);

				const modalElement = document.getElementById('restoreConfirmModal');
				const modal = bootstrap.Modal.getInstance(modalElement);
				if (modal) modal.hide();

				console.log('=== RESTORE HANDLER V3 (2026-10-09) ===');
				console.log('Calling iziToast with:', JSON.stringify({
					title: 'Success',
					message: successMessage
				}));
				console.log('successMessage type:', typeof successMessage);
				console.log('successMessage value:', successMessage);
				iziToast.success({
					title: 'Success',
					message: successMessage,
					position: 'topRight',
					timeout: 1200
				});
				window.setTimeout(() => window.location.reload(), 1300);
			} catch (error) {
				errorText.textContent = error.message;
				errorBox.classList.remove('d-none');
				button.disabled = false;
				button.innerHTML = originalHtml;
			}
		});

		(function () {
			const searchInput = document.getElementById('archiveYearSearch');
			const cards = Array.from(document.querySelectorAll('.archive-year-card'));
			const noResults = document.getElementById('archiveYearNoResults');
			if (!searchInput || cards.length === 0) return;

			searchInput.addEventListener('input', function () {
				const query = searchInput.value.trim().toLocaleLowerCase();
				let visibleCount = 0;
				cards.forEach(function (card) {
					const matches = card.dataset.schoolYear.toLocaleLowerCase().includes(query);
					card.style.display = matches ? '' : 'none';
					if (matches) visibleCount++;
				});
				if (noResults) noResults.style.display = visibleCount === 0 ? '' : 'none';
			});
			searchInput.dispatchEvent(new Event('input'));
		})();
	</script>
</body>

</html>