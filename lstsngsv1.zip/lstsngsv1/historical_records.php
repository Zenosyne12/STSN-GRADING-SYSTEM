﻿<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/api/shared/db_connect.php';

$search = trim((string) ($_GET['search'] ?? ''));
$years = [];

try {
	$sql = "
		SELECT
			ay.id,
			ay.year_label,
			ay.is_active,
			ay.created_at,
			GREATEST(
				(SELECT COUNT(DISTINCT student_id) FROM tblstudent_archive WHERE academic_year_id = ay.id),
				(SELECT COUNT(DISTINCT student_id) FROM tblsectionstudent WHERE academic_year_id = ay.id),
				(SELECT COUNT(DISTINCT student_id) FROM tblenrollment WHERE academic_year_id = ay.id)
			) AS students,
			(SELECT COUNT(DISTINCT ss.section_id) FROM tblsectionstudent ss WHERE ss.academic_year_id = ay.id) AS sections,
			(SELECT COUNT(DISTINCT sad.teacher_id) FROM tblsectionadviser sad WHERE sad.academic_year_id = ay.id) AS teachers,
			(SELECT COUNT(*) FROM tblgrades g WHERE g.academic_year_id = ay.id) AS grade_records
		FROM tblacademicyear ay
		WHERE 1=1
	";
	$params = [];
	if ($search !== '') {
		$sql .= ' AND ay.year_label LIKE ?';
		$params[] = '%' . $search . '%';
	}
	$sql .= ' ORDER BY ay.year_label DESC';
	$stmt = $pdo->prepare($sql);
	$stmt->execute($params);
	$years = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
	$years = [];
}

$archivedYears = array_values(array_filter($years, static fn($year) => (int) ($year['is_active'] ?? 0) !== 1));
$totalArchived = count($archivedYears);
$totalYears = count($years);
?>
<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>STSN Grading System | Academic Year Archive</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
	<link rel="stylesheet"
		href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
	<link rel="stylesheet" href="./css/adminlte.css">
	<link rel="stylesheet" href="./css/historical-records.css">

	<style>
		/* ============================================================
	   DARK MODE OVERRIDES for Historical Records page
	   ============================================================ */
		:root,
		[data-bs-theme="light"] {
			--hr-card-bg: #ffffff;
			--hr-card-soft: #fafcff;
			--hr-border: #dce8f8;
			--hr-border-soft: #e8f0fb;
			--hr-text: #213a5e;
			--hr-text-strong: #132f62;
			--hr-text-muted: #7a93b8;
			--hr-text-dim: #9ab0c8;
			--hr-input-bg: #ffffff;
			--hr-input-border: #c8daf8;
			--hr-input-text: #213a5e;
			--hr-input-placeholder: #9ab0c8;
			--hr-shadow: rgba(18, 72, 168, 0.06);
			--hr-icon-blue-bg: #eef4ff;
			--hr-icon-blue-text: #1248a8;
			--hr-icon-green-bg: #e8fbf1;
			--hr-icon-green-text: #0f6c45;
			--hr-icon-purple-bg: #f3ebff;
			--hr-icon-purple-text: #6a1ea8;
			--hr-status-active-bg: #e8fbf1;
			--hr-status-active-text: #0f6c45;
			--hr-status-archived-bg: #eef4ff;
			--hr-status-archived-text: #1248a8;
			--hr-view-bg: linear-gradient(130deg, #1a6ef5, #1248a8);
			--hr-view-text: #ffffff;
		}

		[data-bs-theme="dark"] {
			--hr-card-bg: #2D2D2D;
			--hr-card-soft: #262626;
			--hr-border: #3a3a3a;
			--hr-border-soft: #3a3a3a;
			--hr-text: #e4e6e8;
			--hr-text-strong: #ffffff;
			--hr-text-muted: #adb5bd;
			--hr-text-dim: #8b939a;
			--hr-input-bg: #3a3a3a;
			--hr-input-border: #4a5a6e;
			--hr-input-text: #e4e6e8;
			--hr-input-placeholder: #adb5bd;
			--hr-shadow: rgba(0, 0, 0, 0.35);
			--hr-icon-blue-bg: #1e2a3d;
			--hr-icon-blue-text: #8ab4f8;
			--hr-icon-green-bg: #17351f;
			--hr-icon-green-text: #6ee7a0;
			--hr-icon-purple-bg: #2d1e42;
			--hr-icon-purple-text: #c4b5fd;
			--hr-status-active-bg: #17351f;
			--hr-status-active-text: #6ee7a0;
			--hr-status-archived-bg: #1e2a3d;
			--hr-status-archived-text: #8ab4f8;
			--hr-view-bg: linear-gradient(130deg, #1a6ef5, #1248a8);
			--hr-view-text: #ffffff;
		}

		/* ✅ HINDI NA NAG-O-OVERRIDE NG BACKGROUND — text color lang */
		[data-bs-theme="dark"] .hr-archive-page {
			color: var(--hr-text);
		}

		/* Header */
		[data-bs-theme="dark"] .page-header {
			background: linear-gradient(130deg, #0f3573 0%, #0f4fb8 100%) !important;
			color: #ffffff !important;
		}

		[data-bs-theme="dark"] .page-header h3,
		[data-bs-theme="dark"] .page-header p {
			color: #ffffff !important;
		}

		/* Breadcrumb */
		[data-bs-theme="dark"] .breadcrumb,
		[data-bs-theme="dark"] .breadcrumb-wrapper,
		[data-bs-theme="dark"] .hr-breadcrumb {
			background: var(--hr-card-bg) !important;
			border-color: var(--hr-border) !important;
			color: var(--hr-text) !important;
		}

		[data-bs-theme="dark"] .breadcrumb a,
		[data-bs-theme="dark"] .breadcrumb-item a {
			color: #8ab4f8 !important;
		}

		[data-bs-theme="dark"] .breadcrumb-item.active,
		[data-bs-theme="dark"] .breadcrumb-item+.breadcrumb-item::before {
			color: var(--hr-text-muted) !important;
		}

		/* Summary cards */
		[data-bs-theme="dark"] .hr-summary-card {
			background: var(--hr-card-bg) !important;
			border: 1px solid var(--hr-border) !important;
			color: var(--hr-text) !important;
			box-shadow: 0 2px 12px var(--hr-shadow) !important;
		}

		[data-bs-theme="dark"] .hr-summary-card strong,
		[data-bs-theme="dark"] .hr-summary-card b {
			color: var(--hr-text-strong) !important;
		}

		[data-bs-theme="dark"] .hr-summary-card span {
			color: var(--hr-text-muted) !important;
		}

		[data-bs-theme="dark"] .hr-summary-card i {
			color: var(--hr-icon-blue-text) !important;
		}

		[data-bs-theme="dark"] .hr-summary-card.protected i {
			color: var(--hr-icon-green-text) !important;
		}

		[data-bs-theme="dark"] .hr-summary-badge {
			background: var(--hr-status-active-bg) !important;
			color: var(--hr-status-active-text) !important;
			border-color: var(--hr-border) !important;
		}

		/* Search toolbar */
		[data-bs-theme="dark"] .hr-archive-toolbar,
		[data-bs-theme="dark"] .hr-archive-search {
			background: var(--hr-input-bg) !important;
			border-color: var(--hr-input-border) !important;
			color: var(--hr-input-text) !important;
		}

		[data-bs-theme="dark"] .hr-archive-search i {
			color: var(--hr-text-muted) !important;
		}

		[data-bs-theme="dark"] .hr-archive-search input {
			background: transparent !important;
			border: 0 !important;
			color: var(--hr-input-text) !important;
		}

		[data-bs-theme="dark"] .hr-archive-search input::placeholder {
			color: var(--hr-input-placeholder) !important;
			opacity: 1 !important;
		}

		/* Table card */
		[data-bs-theme="dark"] .hr-archive-table-card {
			background: var(--hr-card-bg) !important;
			border-color: var(--hr-border) !important;
			color: var(--hr-text) !important;
			box-shadow: 0 2px 12px var(--hr-shadow) !important;
		}

		[data-bs-theme="dark"] .hr-archive-table {
			background: var(--hr-card-bg) !important;
			color: var(--hr-text) !important;
		}

		[data-bs-theme="dark"] .hr-archive-table thead th {
			background: var(--hr-card-soft) !important;
			color: var(--hr-text-strong) !important;
			border-bottom-color: var(--hr-border) !important;
		}

		[data-bs-theme="dark"] .hr-archive-table tbody td {
			background: var(--hr-card-bg) !important;
			color: var(--hr-text) !important;
			border-bottom-color: var(--hr-border-soft) !important;
		}

		[data-bs-theme="dark"] .hr-archive-table tbody tr:hover td {
			background: #353535 !important;
		}

		[data-bs-theme="dark"] .hr-archive-year {
			color: var(--hr-text-strong) !important;
			font-weight: 700;
		}

		[data-bs-theme="dark"] .hr-archive-empty {
			color: var(--hr-text-muted) !important;
			background: var(--hr-card-bg) !important;
		}

		/* Status badge */
		[data-bs-theme="dark"] .hr-archive-status {
			background: var(--hr-status-archived-bg) !important;
			color: var(--hr-status-archived-text) !important;
		}

		[data-bs-theme="dark"] .hr-archive-status.active {
			background: var(--hr-status-active-bg) !important;
			color: var(--hr-status-active-text) !important;
		}

		/* View Records button */
		[data-bs-theme="dark"] .hr-archive-view {
			background: var(--hr-view-bg) !important;
			color: var(--hr-view-text) !important;
			box-shadow: 0 2px 8px rgba(26, 110, 245, 0.25) !important;
		}

		[data-bs-theme="dark"] .hr-archive-view:hover {
			background: linear-gradient(130deg, #1560d8, #103d90) !important;
			color: #ffffff !important;
		}

		/* Table footer */
		[data-bs-theme="dark"] .hr-archive-footer {
			background: var(--hr-card-soft) !important;
			color: var(--hr-text-muted) !important;
			border-top-color: var(--hr-border) !important;
		}

		[data-bs-theme="dark"] .hr-archive-footer i {
			color: var(--hr-text-dim) !important;
		}

		/* Sidebar */
		[data-bs-theme="dark"] .sidebar-wrapper,
		[data-bs-theme="dark"] .app-sidebar,
		[data-bs-theme="dark"] .main-sidebar,
		[data-bs-theme="dark"] .custom-sidebar {
			background-color: #2D2D2D !important;
			color: #e4e6e8 !important;
		}

		[data-bs-theme="dark"] .sidebar-wrapper a,
		[data-bs-theme="dark"] .sidebar-wrapper .nav-link,
		[data-bs-theme="dark"] .sidebar-wrapper .sidebar-brand-text {
			color: #e4e6e8 !important;
		}

		[data-bs-theme="dark"] .sidebar-wrapper .nav-link:hover,
		[data-bs-theme="dark"] .sidebar-wrapper .nav-link.active {
			background-color: #3a3a3a !important;
			color: #ffffff !important;
		}

		/* Footer */
		[data-bs-theme="dark"] .app-footer,
		[data-bs-theme="dark"] footer.main-footer {
			background: #2D2D2D !important;
			color: #adb5bd !important;
			border-top-color: #3a3a3a !important;
		}

		/* Text helpers */
		[data-bs-theme="dark"] .hr-archive-page h1,
		[data-bs-theme="dark"] .hr-archive-page h2,
		[data-bs-theme="dark"] .hr-archive-page h3,
		[data-bs-theme="dark"] .hr-archive-page h4,
		[data-bs-theme="dark"] .hr-archive-page h5,
		[data-bs-theme="dark"] .hr-archive-page h6 {
			color: var(--hr-text-strong) !important;
		}

		[data-bs-theme="dark"] .hr-archive-page a {
			color: #8ab4f8;
		}

		[data-bs-theme="dark"] .hr-archive-page a:hover {
			color: #b3ceff;
		}
		/* ============================================================
		   Historical Records — Compact Archive Cards ("baraha" grid)
		   ============================================================ */
		.hr-archive-grid {
			display: grid;
			grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
			gap: 1rem;
			margin-top: 1rem;
		}
		.hr-archive-card {
			background: #fff;
			border: 1.5px solid #dce8f8;
			border-radius: 14px;
			box-shadow: 0 2px 10px rgba(18,72,168,0.06);
			overflow: hidden;
			transition: all 0.18s ease;
			display: flex;
			flex-direction: column;
			cursor: pointer;
			height: 100%;
		}
		.hr-archive-card:hover {
			transform: translateY(-3px);
			box-shadow: 0 10px 28px rgba(18,72,168,0.12);
			border-color: #b8d0fa;
		}
		.hr-archive-card:focus {
			outline: none;
			border-color: #1a6ef5;
			box-shadow: 0 0 0 3px rgba(26,110,245,0.15);
		}
		.hr-archive-card-header {
			display: flex;
			align-items: flex-start;
			justify-content: space-between;
			gap: 0.5rem;
			padding: 0.9rem 1rem;
			border-bottom: 1px solid #e8f0fb;
			background: #fafcff;
		}
		.hr-archive-icon {
			width: 40px;
			height: 40px;
			border-radius: 10px;
			background: #f3f5f8;
			color: #7a8ea8;
			display: flex;
			align-items: center;
			justify-content: center;
			font-size: 1.15rem;
			flex-shrink: 0;
		}
		.hr-archive-title { font-size: 1rem; font-weight: 800; color: #132f62; line-height: 1.25; margin: 0 0 0.15rem; }
		.hr-archive-sub { font-size: 0.72rem; color: #7a93b8; margin: 0; line-height: 1.3; }
		.hr-archive-badge {
			display: inline-flex;
			align-items: center;
			padding: 0.25rem 0.6rem;
			border-radius: 999px;
			font-size: 0.65rem;
			font-weight: 700;
			text-transform: uppercase;
			letter-spacing: 0.04em;
			background: #f3f5f8;
			color: #7a8ea8;
			border: 1px solid #dde4ee;
			white-space: nowrap;
			flex-shrink: 0;
		}
		.hr-archive-body { padding: 0.9rem 1rem; flex: 1 1 auto; }
		.hr-mini-stats { display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem; }
		.hr-mini-stat {
			background: #f8fbff;
			border-radius: 8px;
			padding: 0.5rem 0.6rem;
			display: flex;
			flex-direction: column;
			gap: 0.1rem;
		}
		.hr-mini-stat strong { font-size: 1.05rem; font-weight: 800; color: #132f62; line-height: 1; }
		.hr-mini-stat span { font-size: 0.65rem; color: #7a93b8; text-transform: uppercase; letter-spacing: 0.04em; font-weight: 600; }
		.hr-archive-card .hr-archive-footer { padding: 0.75rem 1rem; }
		.hr-archive-card .hr-archive-footer .hr-archive-view { flex: 1 1 auto; text-align: center; justify-content: center; }
		.hr-archive-empty-state { grid-column: 1 / -1; text-align: center; padding: 3rem 1rem; color: #9ab0c8; }
		.hr-archive-empty-state i { font-size: 2.5rem; display: block; margin-bottom: 0.75rem; opacity: 0.6; }

		/* Dark mode — compact archive cards */
		[data-bs-theme="dark"] .hr-archive-card { background: var(--hr-card-bg); border-color: var(--hr-border); }
		[data-bs-theme="dark"] .hr-archive-card-header { background: var(--hr-card-soft); border-color: var(--hr-border); }
		[data-bs-theme="dark"] .hr-archive-card .hr-archive-footer { background: var(--hr-card-soft); border-color: var(--hr-border); }
		[data-bs-theme="dark"] .hr-archive-title { color: var(--hr-text-strong); }
		[data-bs-theme="dark"] .hr-archive-sub { color: var(--hr-text-muted); }
		[data-bs-theme="dark"] .hr-mini-stat { background: #1f1f1f; }
		[data-bs-theme="dark"] .hr-mini-stat strong { color: #f1f3f5; }
		[data-bs-theme="dark"] .hr-mini-stat span { color: #adb5bd; }

		@media (max-width: 767.98px) {
			.hr-archive-grid { grid-template-columns: 1fr; }
		}
	</style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
	<div class="app-wrapper">
		<?php require_once __DIR__ . '/includes/header.php'; ?>
		<?php require_once __DIR__ . '/includes/sidebar.php'; ?>

		<main class="app-main">
			<div class="app-content">
				<div class="container-fluid py-3 hr-archive-page">
					<div class="page-header">
						<div>
							<h3><i class="bi bi-calendar3 me-2"></i>Academic Year Archive</h3>
							<p>Archived academic years and their historical records</p>
						</div>
					</div>

					<?php require_once __DIR__ . '/includes/breadcrumb.php';
					renderBreadcrumb([
						['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door'],
						['label' => 'Archive', 'href' => 'historical_records.php', 'icon' => 'bi bi-archive'],
						['label' => 'Historical Records', 'icon' => 'bi bi-clock-history']
					]); ?>

					<section class="hr-summary-grid" aria-label="Archive summary">
						<div class="hr-summary-card">
							<i class="bi bi-archive-fill"></i>
							<strong><?= $totalArchived ?></strong>
							<b>Archived Academic Years</b>
							<span>Academic years preserved</span>
						</div>
						<div class="hr-summary-card">
							<i class="bi bi-people-fill"></i>
							<strong><?= number_format(array_sum(array_map(static fn($year) => (int) $year['students'] + (int) $year['teachers'], $archivedYears))) ?></strong>
							<b>Archived Users</b>
							<span>Historical student and teacher records</span>
						</div>
						<div class="hr-summary-card">
							<i class="bi bi-clipboard2-fill"></i>
							<strong><?= number_format(array_sum(array_map(static fn($year) => (int) $year['grade_records'], $archivedYears))) ?></strong>
							<b>Archived Grade Records</b>
							<span>Historical grade entries</span>
						</div>
					</section>

					<form class="hr-archive-toolbar" method="get">
						<label class="hr-archive-search">
							<i class="bi bi-search"></i>
							<input type="search" name="search" value="<?= htmlspecialchars($search) ?>"
								placeholder="Search academic years..." aria-label="Search academic years">
						</label>
					</form>

					<section class="hr-archive-table-card">
						<div class="table-responsive">
							<?php if (!$archivedYears): ?>
								<div class="hr-archive-empty-state">
									<i class="bi bi-archive"></i>
									<strong>No archived years yet</strong>
									<p class="mb-0 mt-2" style="font-size:0.85rem;">Archived academic years will appear here once a school year is closed.</p>
								</div>
							<?php else: ?>
								<div class="hr-archive-grid">
									<?php foreach ($archivedYears as $year): ?>
									<div class="hr-archive-card"
									     tabindex="0" role="button"
									     aria-label="View archived records for S.Y. <?= htmlspecialchars($year['year_label']) ?>"
									     onclick="window.location.href='historical_selection.php?year_id=<?= (int) $year['id'] ?>'"
									     onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();window.location.href='historical_selection.php?year_id=<?= (int) $year['id'] ?>';}">
										<div class="hr-archive-card-header">
											<div class="d-flex align-items-center gap-2">
												<div class="hr-archive-icon"><i class="bi bi-archive-fill"></i></div>
												<div>
													<h6 class="hr-archive-title">S.Y. <?= htmlspecialchars($year['year_label']) ?></h6>
													<p class="hr-archive-sub mb-0"><i class="bi bi-clock-history me-1"></i>Archived: <?= !empty($year['created_at']) ? htmlspecialchars(date('M j, Y', strtotime($year['created_at']))) : '&mdash;' ?></p>
												</div>
											</div>
											<span class="hr-archive-badge"><i class="bi bi-lock-fill me-1"></i>Archived</span>
										</div>
										<div class="hr-archive-body">
											<div class="hr-mini-stats">
												<div class="hr-mini-stat"><strong><?= number_format((int) $year['students']) ?></strong><span>Students</span></div>
												<div class="hr-mini-stat"><strong><?= number_format((int) $year['sections']) ?></strong><span>Sections</span></div>
												<div class="hr-mini-stat"><strong><?= number_format((int) $year['teachers']) ?></strong><span>Teachers</span></div>
												<div class="hr-mini-stat"><strong><?= number_format((int) $year['grade_records']) ?></strong><span>Records</span></div>
											</div>
										</div>
										<div class="hr-archive-footer">
											<a href="historical_selection.php?year_id=<?= (int) $year['id'] ?>" class="hr-archive-view" onclick="event.stopPropagation();">
												<i class="bi bi-eye me-1"></i> View Records
											</a>
										</div>
									</div>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>
						</div>
						<footer class="hr-archive-footer">
							<span><?= $totalYears ?> academic year<?= $totalYears === 1 ? '' : 's' ?> found</span>
							<span><i class="bi bi-lock"></i> All records are read-only and protected</span>
						</footer>
					</section>
				</div>
			</div>
		</main>
		<?php require_once __DIR__ . '/includes/footer.php'; ?>
	</div>
	<script src="./vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script src="./js/adminlte.js"></script>
</body>

</html>