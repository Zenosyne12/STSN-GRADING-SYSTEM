<?php
require_once __DIR__ . '/includes/auth.php';
requireLogin();
if (!isAdminSession() && !isSuperAdminSession()) {
    requireAdmin();
}
require_once __DIR__ . '/api/shared/db_connect.php';

$hasExplicitMode = array_key_exists('mode', $_GET);
$reviewMode = ($_GET['mode'] ?? 'newyear') === 'archive' ? 'archive' : 'newyear';
$oldYearId = $reviewMode === 'archive'
    ? filter_input(INPUT_GET, 'academic_year_id', FILTER_VALIDATE_INT)
    : filter_input(INPUT_GET, 'old_year_id', FILTER_VALIDATE_INT);
$newYearId = filter_input(INPUT_GET, 'new_year_id', FILTER_VALIDATE_INT);
$oldYear = null;
$newYear = null;

if ((!$hasExplicitMode && !$oldYearId && !$newYearId)
    || ($reviewMode === 'archive' && (!$oldYearId || $oldYearId < 1))) {
    $pendingArchiveStmt = $pdo->query("
        SELECT ay.id, ay.year_label
        FROM tblacademicyear ay
        JOIN tblenrollment e ON e.academic_year_id = ay.id
        WHERE e.promotion_decision = 'PENDING_REVIEW'
          AND ay.archived_at IS NOT NULL
        GROUP BY ay.id, ay.year_label, ay.archived_at
        ORDER BY ay.archived_at DESC, ay.id DESC
        LIMIT 1
    ");
    $pendingArchive = $pendingArchiveStmt->fetch(PDO::FETCH_ASSOC) ?: null;
    if ($pendingArchive) {
        $reviewMode = 'archive';
        $oldYearId = (int) $pendingArchive['id'];
        $oldYear = $pendingArchive;
    }
}

$newYears = $reviewMode === 'newyear' ? $pdo->query("
    SELECT id, year_label
    FROM tblacademicyear
    WHERE is_active = 0 AND archived_at IS NULL
    ORDER BY id DESC
")->fetchAll(PDO::FETCH_ASSOC) : [];

if ($oldYearId && $oldYearId > 0) {
    $oldYearQuery = $reviewMode === 'archive'
        ? 'SELECT id, year_label FROM tblacademicyear WHERE id = ? AND is_active = 0 AND archived_at IS NOT NULL LIMIT 1'
        : 'SELECT id, year_label FROM tblacademicyear WHERE id = ? AND is_active = 1 AND archived_at IS NULL LIMIT 1';
    $oldYearStmt = $pdo->prepare($oldYearQuery);
    $oldYearStmt->execute([$oldYearId]);
    $oldYear = $oldYearStmt->fetch(PDO::FETCH_ASSOC) ?: null;
}
if (!$oldYear && $reviewMode === 'newyear') {
    $oldYearStmt = $pdo->query("
        SELECT ay.id, ay.year_label
        FROM tblenrollment e
        JOIN tblacademicyear ay ON ay.id = e.academic_year_id
        WHERE e.is_active = 1 AND e.promotion_decision = 'PENDING_REVIEW'
          AND ay.is_active = 1 AND ay.archived_at IS NULL
        ORDER BY ay.id DESC
        LIMIT 1
    ");
    $oldYear = $oldYearStmt->fetch(PDO::FETCH_ASSOC) ?: null;
}
$oldYearId = (int) ($oldYear['id'] ?? 0);

if ($reviewMode === 'newyear') {
    foreach ($newYears as $candidateYear) {
        if ((int) $candidateYear['id'] === (int) $newYearId) {
            $newYear = $candidateYear;
            break;
        }
    }
    if (!$newYear && $newYears) {
        $newYear = $newYears[0];
    }
}
$newYearId = (int) ($newYear['id'] ?? 0);
$hasReviewContext = $oldYear && ($reviewMode === 'archive' || $newYear);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Promotion Review | STSN</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
    <style>
        .promotion-page { padding: 1.25rem; }
        .promotion-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            color: #fff;
            border-radius: 16px;
            padding: 1.35rem 1.5rem;
            margin-bottom: 1rem;
        }
        .promotion-header h1 { margin: 0; font-size: 1.5rem; font-weight: 700; }
        .promotion-header p { margin: .25rem 0 0; opacity: .88; }
        .promotion-bulk, .promotion-footer {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: .65rem;
            margin: 1rem 0;
        }
        .promotion-summary {
            display: grid;
            grid-template-columns: repeat(4, minmax(130px, 1fr));
            gap: .75rem;
            margin: 1rem 0;
        }
        .promotion-summary-card, .promotion-table-card {
            background: var(--bs-body-bg, #fff);
            border: 1px solid rgba(18,72,168,.14);
            border-radius: 12px;
            padding: 1rem;
            box-shadow: 0 4px 16px rgba(18,72,168,.06);
        }
        .promotion-summary-card span { display: block; color: #64748b; font-size: .82rem; }
        .promotion-summary-card strong { display: block; color: #1248a8; font-size: 1.5rem; }
        .promotion-bulk {
            justify-content: space-between;
            margin-bottom: .5rem;
        }
        .promotion-bulk strong { font-size: 1.1rem; }
        .promo-table-wrap {
            --report-card: #fff;
            --report-border: #dce8f8;
            --report-head-bg: #f4f8ff;
            --report-head-text: #3b5e96;
            --report-row-border: #f0f5fc;
            --report-row-hover: #f7fbff;
            background: var(--report-card);
            border: 1px solid var(--report-border);
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18, 72, 168, .06);
            overflow: hidden;
            margin: 1rem 0 1.5rem;
        }
        .promo-table {
            width: 100%;
            min-width: 760px;
            border-collapse: collapse;
            table-layout: fixed;
        }
        .promo-table thead th {
            background: var(--report-head-bg);
            color: var(--report-head-text);
            font-size: .75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .06em;
            padding: .85rem 1.2rem;
            border-bottom: 1.5px solid var(--report-border);
            white-space: nowrap;
            text-align: left;
        }
        .promo-table tbody td {
            padding: .9rem 1.2rem;
            font-size: .93rem;
            color: #213a5e;
            vertical-align: middle;
        }
        .promo-table tbody tr:not(:last-child) td { border-bottom: 1px solid var(--report-row-border); }
        .promo-table tbody tr:hover td { background: var(--report-row-hover); }
        .promo-table .col-num { width: 56px; text-align: center; color: #7a93b8; font-weight: 600; }
        .promo-table .col-name { width: 24%; font-weight: 600; color: #132f62; }
        .promo-table .col-grade { width: 14%; }
        .promo-table .col-failed-subjects { width: 30%; }
        .promo-table .col-count { width: 80px; text-align: center; }
        .promo-table .col-decision { width: 220px; text-align: center; }
        .promo-table tbody .promotion-empty { padding: 2rem; text-align: center; color: #7a93b8; }
        [data-bs-theme="dark"] .promo-table-wrap {
            --report-card: #2d2d2d;
            --report-border: #3a3a3a;
            --report-head-bg: #2d2d2d;
            --report-head-text: #fff;
            --report-row-border: #3a3a3a;
            --report-row-hover: #343434;
        }
        [data-bs-theme="dark"] .promo-table tbody td { color: #fff; }
        .failed-badge {
            display: inline-block;
            background: #fee2e2;
            color: #991b1b;
            border-radius: 999px;
            padding: 2px 10px;
            font-weight: 700;
            font-size: .78rem;
        }
        .decision-buttons {
            display: inline-flex;
            gap: 8px;
        }
        .decision-buttons input[type="radio"] {
            display: none;
        }
        .decision-buttons label {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 18px;
            border-radius: 8px;
            font-size: .82rem;
            font-weight: 600;
            cursor: pointer;
            transition: all .15s ease;
            user-select: none;
            background: #fff;
            color: #1e40af;
            border: 1.5px solid #93c5fd;
        }
        .decision-buttons label:hover {
            background: #eff6ff;
            border-color: #60a5fa;
        }
        .decision-buttons label:has(input:checked) {
            background: linear-gradient(135deg, #1e40af, #2563eb);
            color: #fff;
            border-color: #1e40af;
            box-shadow: 0 2px 6px rgba(30, 64, 175, .25);
        }
        .promotion-footer { justify-content: flex-end; }
        .btn-promotion-cancel {
            background: linear-gradient(135deg, #1248a8, #1a6ef5);
            border: 0;
            color: #fff;
        }
        .promotion-table-card { padding: 0; overflow: hidden; }
        .promotion-table-card table { margin: 0; }
        .promotion-table-card thead { background: #eff6ff; color: #1248a8; }
        .promotion-empty { padding: 2rem; text-align: center; color: #64748b; }
        @media (max-width: 700px) {
            .promotion-page { padding: .75rem; }
            .promotion-summary { grid-template-columns: repeat(2, minmax(120px, 1fr)); }
            .promotion-header { padding: 1rem; }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once __DIR__ . '/includes/header.php'; ?>
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid promotion-page">
                <header class="promotion-header stsn-anim-fade-in-up">
                    <h1><i class="bi bi-person-check me-2"></i>Promotion Review</h1>
                    <p><?= $reviewMode === 'archive'
                        ? 'The academic year is archived. Review and save student promotion decisions.'
                        : 'Review student promotion decisions before activating an academic year.' ?></p>
                </header>

                <div class="stsn-anim-fade-in-up stsn-anim-delay-100">
                    <?php require_once __DIR__ . '/includes/breadcrumb.php'; renderBreadcrumb([
                        ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door'],
                        ['label' => 'Academic Settings', 'href' => 'academic_year.php', 'icon' => 'bi bi-calendar-range'],
                        ['label' => 'Promotion Review', 'icon' => 'bi bi-person-check'],
                    ]); ?>
                </div>

                <?php if ($hasReviewContext): ?>
                    <section class="promotion-summary" aria-label="Promotion summary">
                        <div class="promotion-summary-card stsn-anim-fade-in-up"><span>Pending Review</span><strong id="pendingCount">0</strong></div>
                        <div class="promotion-summary-card stsn-anim-fade-in-up stsn-anim-delay-100"><span>Promoted</span><strong id="promotedCount">0</strong></div>
                        <div class="promotion-summary-card stsn-anim-fade-in-up stsn-anim-delay-200"><span>Retained</span><strong id="retainedCount">0</strong></div>
                        <div class="promotion-summary-card stsn-anim-fade-in-up stsn-anim-delay-300"><span>Graduated</span><strong id="graduatedCount">0</strong></div>
                    </section>
                    <div class="promotion-bulk">
                        <strong>Pending Students</strong>
                        <div class="d-flex flex-wrap gap-2">
                            <button type="button" class="btn btn-outline-primary" onclick="setAllDecisions('PROMOTED')">Promote All Pending</button>
                            <button type="button" class="btn btn-outline-secondary" onclick="setAllDecisions('RETAINED')">Retain All Pending</button>
                        </div>
                    </div>
                    <section class="ay-card promo-table-wrap stsn-anim-fade-in-up stsn-anim-delay-100">
                        <div class="table-responsive">
                            <table class="ay-table section-report-table promo-table">
                                <colgroup>
                                    <col class="col-num">
                                    <col class="col-name">
                                    <col class="col-grade">
                                    <col class="col-failed-subjects">
                                    <col class="col-count">
                                    <col class="col-decision">
                                </colgroup>
                                <thead><tr><th class="col-num">#</th><th class="col-name">Student Name</th><th class="col-grade">Grade</th><th class="col-failed-subjects">Failed Subjects</th><th class="col-count">Count</th><th class="col-decision">Decision</th></tr></thead>
                                <tbody id="pendingStudents">
                                    <tr><td colspan="6" class="promotion-empty">Loading promotion review...</td></tr>
                                </tbody>
                            </table>
                        </div>
                    </section>
                    <footer class="promotion-footer">
                        <a href="academic_year.php" class="btn btn-promotion-cancel">Cancel</a>
                        <button type="button" class="btn btn-success" id="applyDecisions" onclick="applyPromotionDecisions()">Apply Decisions</button>
                    </footer>
                <?php else: ?>
                    <div class="promotion-table-card promotion-empty stsn-anim-fade-in-up stsn-anim-delay-200">
                        <i class="bi bi-check-circle fs-3"></i>
                        <p class="mb-0 mt-2">There is no active promotion review.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
    <?php require_once __DIR__ . '/includes/footer.php'; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>
<?php if ($hasReviewContext): ?>
<script>
    const reviewMode = <?= json_encode($reviewMode) ?>;
    const oldYearId = <?= $oldYearId ?>;
    const newYearId = <?= $newYearId ?>;
    let pendingStudents = [];

    function escapeHtml(value) {
        return String(value ?? '').replace(/[&<>"']/g, character => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
        })[character]);
    }

    function promotionToast(message, type) {
        iziToast.show({
            title: type === 'success' ? 'Success' : 'Error',
            message,
            color: type === 'success' ? 'green' : 'red',
            position: 'topRight',
            timeout: 4000
        });
    }

    async function loadPromotionPreview() {
        const body = document.getElementById('pendingStudents');
        body.innerHTML = '<tr><td colspan="6" class="promotion-empty">Loading promotion review...</td></tr>';
        const previewUrl = reviewMode === 'archive'
            ? `api/academic-year/promotion-preview.php?mode=archive&academic_year_id=${oldYearId}`
            : `api/academic-year/promotion-preview.php?old_year_id=${oldYearId}&new_year_id=${newYearId}`;
        const response = await fetch(previewUrl);
        const data = await response.json();
        if (!response.ok || !data.success) {
            throw new Error(data.error || 'Unable to load promotion preview.');
        }

        document.getElementById('pendingCount').textContent = data.summary.pending_review || 0;
        document.getElementById('promotedCount').textContent = data.summary.promoted || 0;
        document.getElementById('retainedCount').textContent = data.summary.retained || 0;
        document.getElementById('graduatedCount').textContent = data.summary.graduated || 0;
        pendingStudents = data.pending_students || [];

        if (!pendingStudents.length) {
            body.innerHTML = '<tr><td colspan="6" class="promotion-empty">No students need a manual promotion decision.</td></tr>';
            const applyButton = document.getElementById('applyDecisions');
            applyButton.disabled = false;
            applyButton.textContent = reviewMode === 'archive' ? 'Go to Academic Years' : 'Apply Decisions';
            return;
        }
        document.getElementById('applyDecisions').disabled = false;
        document.getElementById('applyDecisions').textContent = 'Apply Decisions';
        body.innerHTML = pendingStudents.map((student, index) => `
            <tr>
                <td class="col-num">${index + 1}</td>
                <td class="col-name">${escapeHtml(student.student_name)}</td>
                <td>${escapeHtml(student.grade_level)}</td>
                <td>${escapeHtml(student.failed_subjects || '—')}</td>
                <td class="col-count"><span class="failed-badge">${Number(student.failed_count)}</span></td>
                <td class="col-decision">
                    <div class="decision-buttons">
                        <label>
                            <input type="radio" name="decision_${Number(student.enrollment_id)}" value="PROMOTED" checked>
                            <i class="bi bi-check-circle"></i> Promote
                        </label>
                        <label>
                            <input type="radio" name="decision_${Number(student.enrollment_id)}" value="RETAINED">
                            <i class="bi bi-x-circle"></i> Retain
                        </label>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    function setAllDecisions(decision) {
        pendingStudents.forEach(student => {
            const radio = document.querySelector(`input[name="decision_${Number(student.enrollment_id)}"][value="${decision}"]`);
            if (radio) radio.checked = true;
        });
    }

    async function applyPromotionDecisions() {
        if (reviewMode === 'archive' && pendingStudents.length === 0) {
            var page = document.querySelector('.promotion-page');
            var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
            if (!page || reduced) { window.location.href = 'academic_year.php'; return; }
            page.style.transition = 'opacity 180ms cubic-bezier(0.22, 1, 0.36, 1), transform 180ms cubic-bezier(0.22, 1, 0.36, 1)';
            page.style.opacity = '0';
            page.style.transform = 'translateY(-8px)';
            window.setTimeout(function () { window.location.href = 'academic_year.php'; }, 180);
            return;
        }

        const decisions = pendingStudents.map(student => {
            const selected = document.querySelector(`input[name="decision_${Number(student.enrollment_id)}"]:checked`);
            return {
                enrollment_id: Number(student.enrollment_id),
                decision: selected ? selected.value : 'PROMOTED'
            };
        });
        const button = document.getElementById('applyDecisions');
        button.disabled = true;
        try {
            const response = await fetch('api/academic-year/promotion-review-save.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ academic_year_id: oldYearId, mode: reviewMode, decisions })
            });
            const data = await response.json();
            if (!response.ok || !data.success) {
                throw new Error(data.error || 'Unable to save promotion decisions.');
            }
            if (Number(data.remaining_pending) === 0) {
                if (reviewMode === 'archive') {
                    promotionToast('Promotion decisions saved. You can now create a new academic year.', 'success');
                    window.setTimeout(function () {
                        var page = document.querySelector('.promotion-page');
                        var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
                        if (!page || reduced) { window.location.href = 'academic_year.php'; return; }
                        page.style.transition = 'opacity 180ms cubic-bezier(0.22, 1, 0.36, 1), transform 180ms cubic-bezier(0.22, 1, 0.36, 1)';
                        page.style.opacity = '0';
                        page.style.transform = 'translateY(-8px)';
                        window.setTimeout(function () { window.location.href = 'academic_year.php'; }, 180);
                    }, 1200);
                } else {
                    const activationResponse = await fetch('api/academic-year/toggle.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id: newYearId, is_active: 1 })
                    });
                    const activationData = await activationResponse.json();
                    if (!activationResponse.ok || !activationData.success) {
                        throw new Error(activationData.message || activationData.error || 'Unable to activate the academic year.');
                    }
                    promotionToast('Promotion decisions saved and the academic year activated.', 'success');
                    window.setTimeout(function () {
                        var page = document.querySelector('.promotion-page');
                        var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
                        if (!page || reduced) { window.location.href = 'academic_year.php'; return; }
                        page.style.transition = 'opacity 180ms cubic-bezier(0.22, 1, 0.36, 1), transform 180ms cubic-bezier(0.22, 1, 0.36, 1)';
                        page.style.opacity = '0';
                        page.style.transform = 'translateY(-8px)';
                        window.setTimeout(function () { window.location.href = 'academic_year.php'; }, 180);
                    }, 1200);
                }
                return;
            }
            promotionToast(`${data.remaining_pending} review decision(s) remain.`, 'error');
            await loadPromotionPreview();
        } catch (error) {
            promotionToast(error.message, 'error');
            button.disabled = false;
        }
    }

    loadPromotionPreview().catch(error => {
        document.getElementById('pendingStudents').innerHTML =
            `<tr><td colspan="6" class="promotion-empty">${escapeHtml(error.message)}</td></tr>`;
        promotionToast(error.message, 'error');
    });
</script>
<?php endif; ?>
<script>
(function () {
    var links = document.querySelectorAll(
        '.promotion-page a[href="academic_year.php"], .promotion-page a[href="Dashboard.php"]'
    );
    if (!links.length) return;
    var page = document.querySelector('.promotion-page');
    if (!page) return;
    var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    links.forEach(function (link) {
        link.addEventListener('click', function (e) {
            var href = link.getAttribute('href');
            if (!href || e.ctrlKey || e.metaKey || e.shiftKey) return;
            e.preventDefault();
            if (reduced) { window.location.href = href; return; }
            page.style.transition = 'opacity 180ms cubic-bezier(0.22, 1, 0.36, 1), transform 180ms cubic-bezier(0.22, 1, 0.36, 1)';
            page.style.opacity = '0';
            page.style.transform = 'translateY(-8px)';
            window.setTimeout(function () { window.location.href = href; }, 180);
        });
    });
})();
</script>
</body>
</html>
