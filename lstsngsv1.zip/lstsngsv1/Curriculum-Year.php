<?php
require_once 'includes/auth.php';
requireLogin();
require_once 'api/shared/db_connect.php';

// Admin (1) or Super Admin (4) only.
$roleId = (int) ($_SESSION['role_id'] ?? 0);
if (!in_array($roleId, [1, 4], true)) {
    redirectTo('/lstsngsv1/login.php');
}

$yearId   = isset($_GET['year_id']) ? (int) $_GET['year_id'] : 0;
$readOnly = isset($_GET['view']);

if ($yearId <= 0) {
    redirectTo('Curriculum.php');
}

// Year info
$stmt = $pdo->prepare("
    SELECT id, year_label, start_date, end_date,
           curriculum_status, curriculum_archived_at
    FROM tblacademicyear
    WHERE id = ? LIMIT 1
");
$stmt->execute([$yearId]);
$year = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$year) {
    redirectTo('Curriculum.php');
}

$isSuperAdmin = ($roleId === 4);
$isArchived   = (($year['curriculum_status'] ?? 'NONE') === 'ARCHIVED') || $readOnly;

/* Aliases consumed by the tree markup + scripts inherited from Curriculum.php */
$viewYear     = $year;
$viewYearId   = $yearId;
$readOnlyView = $isArchived;
?>
<!doctype html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
    <meta charset="utf-8">
    <title>Curriculum - S.Y. <?= htmlspecialchars($year['year_label']) ?> | STSN</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <style>
        :root,
        [data-bs-theme="light"] {
            --cy-bg: #f3f7fd;
            --cy-card: #ffffff;
            --cy-card-soft: #fafcff;
            --cy-border: #dce8f8;
            --cy-border-soft: #e8f0fb;
            --cy-text: #213a5e;
            --cy-text-strong: #132f62;
            --cy-text-muted: #7a93b8;
            --cy-text-dim: #9ab0c8;
            --cy-tree-text: #3a5a82;
            --cy-tree-level: #1248a8;
            --cy-tree-active-bg: #eef4ff;
            --cy-tree-active-text: #1a6ef5;
            --cy-head-bg: #f4f8ff;
            --cy-head-text: #3b5e96;
            --cy-row-hover: #f7fbff;
            --cy-row-border: #f0f5fc;
            --cy-input-bg: #ffffff;
            --cy-input-border: #c8daf8;
            --cy-input-text: #213a5e;
            --cy-shadow: rgba(18,72,168,.06);
            --cy-caret: #6b84a2;
        }

        [data-bs-theme="dark"] {
            --cy-bg: #1a1a1a;
            --cy-card: #2D2D2D;
            --cy-card-soft: #262626;
            --cy-border: #3a3a3a;
            --cy-border-soft: #3a3a3a;
            --cy-text: #e4e6e8;
            --cy-text-strong: #f1f3f5;
            --cy-text-muted: #adb5bd;
            --cy-text-dim: #8b939a;
            --cy-tree-text: #ffffff;
            --cy-tree-level: #ffffff;
            --cy-tree-active-bg: #343434;
            --cy-tree-active-text: #ffffff;
            --cy-head-bg: #2D2D2D;
            --cy-head-text: #e8eef7;
            --cy-row-hover: #343434;
            --cy-row-border: #3a3a3a;
            --cy-input-bg: #3a3a3a;
            --cy-input-border: #4a5a6e;
            --cy-input-text: #e8eef7;
            --cy-shadow: rgba(0,0,0,.35);
            --cy-caret: #94a7bf;
        }

        body { background: var(--cy-bg); }

        .ay-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px; padding: 1.4rem 1.6rem; color: #fff;
            margin-bottom: 1.25rem; display: flex; flex-wrap: wrap;
            align-items: center; justify-content: space-between; gap: 1rem;
        }
        .ay-page-header h3 { font-size: 1.25rem; font-weight: 700; margin: 0 0 .2rem; letter-spacing: .01em; }
        .ay-page-header p { margin: 0; font-size: .88rem; opacity: .85; }

        .ay-layout {
            display: grid; grid-template-columns: 290px 1fr;
            gap: 1.2rem; align-items: start;
        }
        @media (max-width: 991px) { .ay-layout { grid-template-columns: 1fr; } }

        .ay-card {
            background: var(--cy-card); border: 1px solid var(--cy-border);
            border-radius: 16px; box-shadow: 0 2px 12px var(--cy-shadow); overflow: hidden;
            margin-bottom: 1.5rem;
        }
        .ay-card-header {
            padding: 1.1rem 1.4rem; border-bottom: 1px solid var(--cy-border-soft);
            display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between;
            gap: .75rem; background: var(--cy-card);
        }
        .ay-card-title { font-size: 1rem; font-weight: 700; color: var(--cy-text-strong); margin: 0 0 .15rem; }
        .ay-card-subtitle { font-size: .8rem; color: var(--cy-text-muted); margin: 0; }
        .ay-card-footer {
            padding: .75rem 1.2rem; border-top: 1px solid var(--cy-border-soft);
            background: var(--cy-card-soft); display: flex; justify-content: space-between;
            align-items: center; gap: .75rem; flex-wrap: wrap;
        }
        .ay-footer-note { font-size: .82rem; color: var(--cy-text-muted); }

        /* TREE NAVIGATION */
        .ay-tree-wrap { padding: .6rem; }
        .ay-tree-level { margin-bottom: .35rem; }
        .ay-tree-level > summary {
            cursor: pointer; display: flex; align-items: center; gap: .45rem;
            padding: .65rem .75rem; border-radius: 10px; font-weight: 700;
            font-size: .8rem; color: var(--cy-tree-level); text-transform: uppercase;
            letter-spacing: .05em; user-select: none; list-style: none;
            background: transparent;
        }
        .ay-tree-level > summary::marker,
        .ay-tree-level > summary::-webkit-details-marker { display: none; }
        .ay-caret { transition: transform .18s; font-size: .75rem; color: var(--cy-caret); }
        .ay-tree-level[open] > summary .ay-caret { transform: rotate(90deg); }

        .ay-grade-item,
        .ay-strand-item {
            display: flex; align-items: center; gap: .45rem;
            padding: .55rem .75rem .55rem 1.2rem;
            border-radius: 10px; cursor: pointer;
            font-size: .9rem; color: var(--cy-tree-text);
            margin-bottom: .2rem;
        }
        .ay-grade-item:hover,
        .ay-strand-item:hover {
            background: transparent; color: var(--cy-tree-text); transform: none;
        }
        .ay-grade-item.active,
        .ay-strand-item.active {
            background: var(--cy-tree-active-bg);
            color: var(--cy-tree-active-text);
            font-weight: 700;
        }
        .ay-grade-dot, .ay-strand-dot {
            width: 6px; height: 6px; border-radius: 50%;
            background: #1a6ef5; flex-shrink: 0;
        }
        .ay-grade-item .ay-grade-dot { margin-top: .12rem; }
        .ay-grade-item.active .ay-grade-dot,
        .ay-strand-item.active .ay-strand-dot { background: #1a6ef5; }

        .ay-shs-grade { margin-bottom: .3rem; }
        .ay-shs-grade > summary {
            cursor: pointer; display: flex; align-items: center; gap: .45rem;
            padding: .55rem .75rem .55rem 1.2rem; border-radius: 10px;
            font-weight: 700; font-size: .9rem; color: var(--cy-tree-text);
            user-select: none; list-style: none; background: transparent;
        }
        .ay-shs-grade > summary:hover {
            background: transparent; color: var(--cy-tree-text);
        }
        .ay-shs-grade > summary::marker,
        .ay-shs-grade > summary::-webkit-details-marker { display: none; }
        .ay-shs-grade[open] > summary .ay-caret { transform: rotate(90deg); }
        .ay-shs-grade-list { padding-left: .9rem; padding-top: .15rem; }

        /* TABLE */
        .ay-table { width: 100%; border-collapse: collapse; background: var(--cy-card); }
        .ay-table thead th {
            background: var(--cy-head-bg); color: var(--cy-head-text); font-size: .75rem;
            font-weight: 700; text-transform: uppercase; letter-spacing: .06em;
            padding: .85rem 1.2rem; border-bottom: 1.5px solid var(--cy-border); white-space: nowrap;
            text-align: left;
        }
        .ay-table tbody tr:not(:last-child) td { border-bottom: 1px solid var(--cy-row-border); }
        .ay-table tbody tr:hover td { background: var(--cy-row-hover); }
        .ay-table tbody td { padding: .9rem 1.2rem; font-size: .93rem; color: var(--cy-text); vertical-align: middle; }

        .ay-empty { text-align: center; padding: 2.5rem 1.5rem; color: var(--cy-text-dim); }
        .ay-empty i { font-size: 2.2rem; display: block; margin-bottom: .6rem; opacity: .5; }
        .ay-empty p { margin: 0; font-size: .95rem; }

        /* BADGES */
        .ay-badge {
            display: inline-flex; align-items: center; gap: .3rem;
            padding: .32rem .75rem; border-radius: 999px;
            font-size: .78rem; font-weight: 700; letter-spacing: .03em;
        }
        .ay-badge-active { background: #e6f0ff; color: #1248a8; border: 1.5px solid #b8d0fa; }
        [data-bs-theme="dark"] .ay-badge-active { background: #1e2a3d; color: #8ab4f8; border-color: #2d4366; }
        .ay-badge-inactive { background: #f3f5f8; color: #7a8ea8; border: 1.5px solid #dde4ee; }
        [data-bs-theme="dark"] .ay-badge-inactive { background: #3a3a3a; color: #a9b8cd; border-color: #4a5a6e; }
        .ay-badge-core { background: #eaf2ff; color: #1248a8; border: 1.5px solid #bdd4fb; }
        [data-bs-theme="dark"] .ay-badge-core { background: #1e2a3d; color: #8ab4f8; border-color: #2d4366; }
        .ay-badge-applied { background: #e8fbf2; color: #0a6b47; border: 1.5px solid #a9e2ca; }
        [data-bs-theme="dark"] .ay-badge-applied { background: #17351f; color: #6ee7a0; border-color: #2b5c38; }
        .ay-badge-specialized { background: #fff4e9; color: #8a4800; border: 1.5px solid #f8cf98; }
        [data-bs-theme="dark"] .ay-badge-specialized { background: #3a2f14; color: #ffcc66; border-color: #5c4820; }
        .ay-badge-elective { background: #f5ebff; color: #5b1a96; border: 1.5px solid #d9b6ff; }
        [data-bs-theme="dark"] .ay-badge-elective { background: #2d1e42; color: #c4b5fd; border-color: #4c3670; }

        /* BUTTONS */
        .btn-ay {
            font-weight: 600; font-size: .82rem; border-radius: 8px;
            padding: .42rem .9rem; cursor: pointer; transition: all .14s;
            border: 1.5px solid transparent; line-height: 1.4;
        }
        .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff; box-shadow: 0 2px 8px rgba(26,110,245,.2);
        }
        .btn-ay-primary:hover { background: linear-gradient(130deg, #1560d8, #103d90); color: #fff; }
        .btn-ay-outline { background: var(--cy-card); color: #1a6ef5; border-color: var(--cy-border); }
        .btn-ay-outline:hover { background: var(--cy-tree-active-bg); border-color: #9cc2fc; }
        [data-bs-theme="dark"] .btn-ay-outline { color: #7ab7ff; }
        [data-bs-theme="dark"] .btn-ay-outline:hover { background: #343434; color: #a5ccff; }

        .btn-ay-danger { background: #fff5f5; color: #d64545; border-color: #f3c2c2; }
        .btn-ay-danger:hover { background: #ffe8e8; color: #bb2d3b; border-color: #e9a8a8; }
        [data-bs-theme="dark"] .btn-ay-danger { background: #3a1f24; color: #ff8b9e; border-color: #5c2d35; }
        [data-bs-theme="dark"] .btn-ay-danger:hover { background: #4a262c; border-color: #6e3640; color: #ffb0be; }

        .btn-ay-sm { padding: .28rem .65rem; font-size: .78rem; }
        .btn-ay-icon { width: 32px; height: 32px; padding: 0; border-radius: 8px;
                       display: inline-flex; align-items: center; justify-content: center; font-size: .85rem; }

        .ay-search {
            border: 1.5px solid var(--cy-input-border); border-radius: 10px;
            padding: .42rem .85rem; font-size: .88rem; color: var(--cy-input-text);
            min-width: 220px; background: var(--cy-input-bg);
        }
        .ay-search:focus { border-color: #1a6ef5; outline: none; box-shadow: 0 0 0 3px rgba(26,110,245,.1); }

        /* PAGINATION */
        .ay-pagination {
            display: flex; gap: .3rem; list-style: none; margin: 0; padding: 0;
            justify-content: flex-end; align-items: center; flex-wrap: wrap;
        }
        .ay-pagination .ay-page-item .ay-page-link {
            display: inline-flex; align-items: center; justify-content: center;
            min-width: 32px; height: 32px; border-radius: 7px; font-size: .83rem;
            font-weight: 600; cursor: pointer; border: 1.5px solid var(--cy-border);
            color: #1a6ef5; background: var(--cy-card); transition: all .13s; padding: 0 .65rem;
        }
        .ay-pagination .ay-page-item .ay-page-link:hover { background: var(--cy-tree-active-bg); border-color: #9cc2fc; }
        [data-bs-theme="dark"] .ay-pagination .ay-page-item .ay-page-link { color: #7ab7ff; }
        .ay-pagination .ay-page-item.active .ay-page-link {
            background: #1a6ef5; border-color: #1a6ef5; color: #fff;
        }
        .ay-pagination .ay-page-item.disabled .ay-page-link {
            background: var(--cy-card-soft); border-color: var(--cy-border); color: var(--cy-text-dim);
            cursor: not-allowed; pointer-events: none;
        }

        .ay-context { display: flex; align-items: center; gap: .4rem; flex-wrap: wrap; font-size: .8rem; color: var(--cy-text-muted); }
        .ay-context-pill {
            background: var(--cy-tree-active-bg); color: var(--cy-tree-active-text); border-radius: 999px;
            padding: .2rem .65rem; font-weight: 700; font-size: .76rem;
        }

        /* ============================================================
           MODAL — Light mode default
           ============================================================ */
        .ay-modal .modal-content {
            border: 0; border-radius: 16px;
            box-shadow: 0 8px 32px rgba(18,72,168,.16);
            background: var(--cy-card);
        }
        .ay-modal .modal-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-bottom: 0;
            border-radius: 16px 16px 0 0;
            padding: 1rem 1.3rem;
        }
        .ay-modal .modal-title { font-size: 1rem; font-weight: 700; color: #fff; }
        .ay-modal .modal-header .btn-close { filter: brightness(0) invert(1); opacity: .9; }
        .ay-modal .modal-header .btn-close:hover { opacity: 1; }
        .ay-modal .modal-body { padding: 1.3rem; background: var(--cy-card); color: var(--cy-text); }
        .ay-modal .modal-footer {
            border-top: 1px solid var(--cy-border-soft); padding: .9rem 1.3rem;
            background: var(--cy-card-soft); border-radius: 0 0 16px 16px;
        }
        .ay-modal .form-label { font-size: .85rem; font-weight: 700; color: var(--cy-text-muted); margin-bottom: .4rem; }
        .ay-modal .form-control,
        .ay-modal .form-select {
            border-radius: 10px; border: 1.5px solid var(--cy-input-border);
            min-height: 42px; font-size: .9rem; color: var(--cy-input-text);
            padding: .45rem .85rem; background: var(--cy-input-bg);
        }
        .ay-modal .form-control:focus,
        .ay-modal .form-select:focus { border-color: #1a6ef5; box-shadow: 0 0 0 3px rgba(26,110,245,.12); }

        /* ============================================================
           MODAL — DARK MODE
           Keep blue gradient header, rest is #2D2D2D
           ============================================================ */
        [data-bs-theme="dark"] .ay-modal .modal-content {
            background: #2D2D2D !important;
            border: 1px solid #3a3a3a !important;
            box-shadow: 0 8px 32px rgba(0, 0, 0, .75) !important;
        }

        /* Force the blue gradient header even in dark mode */
        [data-bs-theme="dark"] .ay-modal .modal-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%) !important;
            border-bottom: 0 !important;
            border-radius: 16px 16px 0 0 !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-title {
            color: #ffffff !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-header .btn-close {
            filter: brightness(0) invert(1) !important;
            opacity: 0.9 !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-header .btn-close:hover {
            opacity: 1 !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-body {
            background: #2D2D2D !important;
            color: #e4e6e8 !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-footer {
            background: #262626 !important;
            border-top: 1px solid #3a3a3a !important;
            border-radius: 0 0 16px 16px !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-label {
            color: #e4e6e8 !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-control,
        [data-bs-theme="dark"] .ay-modal .form-select {
            background: #1f1f1f !important;
            border-color: #3a3a3a !important;
            color: #e4e6e8 !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-control::placeholder {
            color: #8b939a !important;
            opacity: 1 !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-select option {
            background: #1f1f1f !important;
            color: #e4e6e8 !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-control:focus,
        [data-bs-theme="dark"] .ay-modal .form-select:focus {
            background: #1f1f1f !important;
            border-color: #1a6ef5 !important;
            color: #ffffff !important;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.35) !important;
        }

        [data-bs-theme="dark"] .ay-modal .text-danger {
            color: #ff6b81 !important;
        }

        /* Cancel button visible on dark */
        [data-bs-theme="dark"] .ay-modal .btn-ay-outline {
            background: #3a3a3a !important;
            color: #e4e6e8 !important;
            border-color: #4a4a4a !important;
        }

        [data-bs-theme="dark"] .ay-modal .btn-ay-outline:hover {
            background: #4a4a4a !important;
            border-color: #5a5a5a !important;
            color: #ffffff !important;
        }

        /* Modal backdrop */
        [data-bs-theme="dark"] .modal-backdrop {
            background-color: #000 !important;
        }

        /* MOBILE CARDS */
        .ay-mobile-card {
            background: var(--cy-card); border: 1.5px solid var(--cy-border);
            border-radius: 14px; overflow: hidden;
            box-shadow: 0 1px 6px var(--cy-shadow);
        }
        .ay-mobile-card + .ay-mobile-card { margin-top: .75rem; }
        .ay-mobile-card-header {
            display: flex; align-items: center; justify-content: space-between;
            padding: .85rem 1rem; border-bottom: 1px solid var(--cy-border-soft); background: var(--cy-card-soft);
        }
        .ay-mobile-card-title { font-weight: 700; color: var(--cy-text-strong); font-size: .95rem; }
        .ay-mobile-card-body { padding: .85rem 1rem; }
        .ay-mobile-card-body .grade-label { font-size: .82rem; color: var(--cy-text-muted); margin-bottom: .65rem; }

        /* ============================================================
           Curriculum tree — Bootstrap accordion with smooth animation
           ============================================================ */
        .curriculum-tree .accordion-item {
            background: var(--cy-card);
            border: 1px solid var(--cy-border-soft);
            border-radius: 10px;
            margin-bottom: .5rem;
            overflow: hidden;
        }
        .curriculum-tree .stage-row .accordion-button {
            background: var(--cy-head-bg);
            color: var(--cy-tree-text);
            font-weight: 700;
            font-size: .92rem;
            padding: .7rem .9rem;
            box-shadow: none;
            transition: all 0.2s ease;
        }
        .curriculum-tree .stage-row .accordion-button:not(.collapsed) {
            background: var(--cy-tree-active-bg);
            color: var(--cy-tree-active-text);
        }
        .curriculum-tree .stage-row .accordion-button::after { display: none; }
        .curriculum-tree .stage-label {
            transition: color 0.18s ease;
        }
        .curriculum-tree .chevron {
            transition: transform 0.22s ease;
            color: var(--cy-caret);
        }
        .curriculum-tree [aria-expanded="true"] .chevron {
            transform: rotate(90deg);
        }
        .curriculum-tree .grade-row {
            display: flex;
            align-items: center;
            gap: .35rem;
            padding: .5rem .75rem;
            border-radius: 8px;
            border-left: 3px solid transparent;
            color: var(--cy-tree-text);
            font-size: .88rem;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: background-color 0.18s ease,
                        border-color 0.18s ease,
                        padding-left 0.18s ease;
        }
        .curriculum-tree .grade-row:hover {
            background-color: #F8F9FA;
            border-left-color: #0D6EFD;
        }
        .curriculum-tree .grade-row.active {
            background-color: #EBF4FF;
            border-left: 3px solid #0D6EFD;
            padding-left: 0.35rem;
            color: var(--cy-tree-active-text);
        }
        .curriculum-tree .track-row {
            padding-left: 1.6rem;
            font-weight: 500;
            font-size: .85rem;
        }

        /* Smooth height animation for accordion bodies */
        .collapse {
            transition: height 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .collapsing {
            transition: height 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        }

        /* ============================================================
           CURRICULUM CARDS (one card per academic year)
           ============================================================ */
        .curriculum-card {
            background: var(--cy-card);
            border: 1.5px solid #dce8f8;
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18,72,168,0.06);
            margin-bottom: 1.25rem;
            overflow: hidden;
            transition: all 0.18s ease;
        }

        /* Clickable card behavior */
        .curriculum-card--clickable {
            cursor: pointer;
            user-select: none;
        }
        .curriculum-card--clickable:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 28px rgba(18,72,168,0.12);
            border-color: #b8d0fa;
        }
        .curriculum-card--clickable:active {
            transform: translateY(-1px);
            box-shadow: 0 4px 14px rgba(18,72,168,0.15);
        }
        .curriculum-card--clickable:focus {
            outline: none;
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26,110,245,0.15),
                        0 10px 28px rgba(18,72,168,0.12);
        }
        .curriculum-card--clickable:focus-visible {
            outline: 2px solid #1a6ef5;
            outline-offset: 2px;
        }

        /* Buttons inside clickable cards should not trigger card click */
        .curriculum-card--clickable .curriculum-card-footer a,
        .curriculum-card--clickable .curriculum-card-footer button {
            cursor: pointer;
            position: relative;
            z-index: 2;
        }

        /* Dark mode */
        [data-bs-theme="dark"] .curriculum-card--clickable:hover {
            border-color: #4a5a6e;
        }

        .curriculum-card--active {
            border-color: #1a6ef5;
            box-shadow: 0 4px 20px rgba(26,110,245,0.15);
        }
        .curriculum-card--archived { opacity: 0.92; }
        .curriculum-card--archived:hover {
            opacity: 1;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(18,72,168,0.12);
        }

        .curriculum-card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 1.25rem 1.5rem;
            border-bottom: 1px solid #e8f0fb;
            background: #fafcff;
            gap: .75rem;
            flex-wrap: wrap;
        }
        .curriculum-card--active .curriculum-card-header {
            background: linear-gradient(135deg, #f0f6ff 0%, #e6f0ff 100%);
        }

        .curriculum-icon {
            width: 52px;
            height: 52px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.4rem;
            flex-shrink: 0;
        }
        .curriculum-icon--active { background: linear-gradient(135deg, #1a6ef5, #1248a8); color: #fff; }
        .curriculum-icon--archived { background: #f3f5f8; color: #7a8ea8; }

        .curriculum-card-title { font-size: 1.15rem; font-weight: 800; color: #132f62; }
        .curriculum-card-sub { font-size: 0.82rem; color: #7a93b8; }

        .curriculum-status-badge {
            display: inline-flex;
            align-items: center;
            padding: 0.4rem 1rem;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .curriculum-status--active {
            background: #d1fae5;
            color: #065f46;
            border: 1.5px solid #6ee7b7;
        }
        .curriculum-status--archived {
            background: #f3f5f8;
            color: #7a8ea8;
            border: 1.5px solid #dde4ee;
        }

        .curriculum-card-body { padding: 1.25rem 1.5rem; }
        .curriculum-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: 0.85rem;
        }
        .curriculum-stat {
            display: flex;
            align-items: center;
            gap: 0.65rem;
            padding: 0.75rem 1rem;
            background: #f8fbff;
            border-radius: 10px;
            font-size: 0.88rem;
            color: #213a5e;
        }
        .curriculum-stat i { font-size: 1.2rem; color: #1a6ef5; }
        .curriculum-stat strong { color: #132f62; font-weight: 800; }

        .curriculum-card-footer {
            display: flex;
            gap: 0.55rem;
            padding: 1rem 1.5rem;
            border-top: 1px solid #e8f0fb;
            background: #fafcff;
            flex-wrap: wrap;
        }

        .archived-section-title {
            font-size: 1rem;
            font-weight: 800;
            color: #7a93b8;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            margin-bottom: 1rem;
        }

        /* Subject row action cluster (tree UI) */
        .ay-row-actions { display: inline-flex; gap: .35rem; flex-wrap: wrap; align-items: center; }
        .ay-row-locked { color: var(--cy-text-dim); font-size: .85rem; }

        /* Dark mode support */
        [data-bs-theme="dark"] .curriculum-card { background: #2D2D2D; border-color: #3a3a3a; }
        [data-bs-theme="dark"] .curriculum-card-header { background: #262626; border-bottom-color: #3a3a3a; }
        [data-bs-theme="dark"] .curriculum-card--active .curriculum-card-header { background: #22304a; }
        [data-bs-theme="dark"] .curriculum-card-title { color: #ffffff; }
        [data-bs-theme="dark"] .curriculum-card-sub { color: #adb5bd; }
        [data-bs-theme="dark"] .curriculum-stat { background: #1f1f1f; color: #e4e6e8; }
        [data-bs-theme="dark"] .curriculum-stat strong { color: #f1f3f5; }
        [data-bs-theme="dark"] .curriculum-card-footer { background: #262626; border-top-color: #3a3a3a; }
        [data-bs-theme="dark"] .curriculum-status--archived { background: #333; color: #adb5bd; border-color: #444; }

        @media (max-width: 767.98px) {
            .ay-page-header { padding: 1.1rem 1.2rem; border-radius: 14px; }
            .ay-card-footer { justify-content: center; }
            .ay-pagination { justify-content: center; }
        }

        /* ============================================================
           Curriculum-Year.php specifics
           ============================================================ */
        .cy-back-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            padding: 0.5rem 1rem;
            background: var(--cy-card);
            color: #1248a8;
            border: 1.5px solid #dce8f8;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.85rem;
            text-decoration: none;
            margin-bottom: 1rem;
        }
        .cy-back-btn:hover {
            background: #eef4ff;
            border-color: #9cc2fc;
        }
        .cy-readonly-banner {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.85rem 1.25rem;
            background: #f3f5f8;
            border: 1.5px solid #dde4ee;
            border-left: 4px solid #7a8ea8;
            border-radius: 10px;
            color: #556677;
            font-size: 0.88rem;
            margin-bottom: 1rem;
        }
        .cy-readonly-banner i {
            font-size: 1.2rem;
            color: #7a8ea8;
        }
        [data-bs-theme="dark"] .cy-back-btn { background: #2D2D2D; border-color: #3a3a3a; color: #9cc2fc; }
        [data-bs-theme="dark"] .cy-back-btn:hover { background: #22304a; }
        [data-bs-theme="dark"] .cy-readonly-banner { background: #262626; border-color: #3a3a3a; color: #ced4da; }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3">

                <a href="Curriculum.php" class="cy-back-btn">
                    <i class="bi bi-arrow-left"></i> Back to Curriculum List
                </a>

                <div class="page-header">
                    <div>
                        <h3><i class="bi bi-journal-bookmark-fill me-2"></i>S.Y. <?= htmlspecialchars($year['year_label']) ?></h3>
                        <p>
                            <?= htmlspecialchars((string) $year['start_date']) ?>
                            &rarr;
                            <?= htmlspecialchars((string) $year['end_date']) ?>
                            &nbsp;&middot;&nbsp;
                            <?php if ($isArchived): ?>
                                <span class="badge bg-secondary"><i class="bi bi-archive-fill me-1"></i>Archived</span>
                            <?php else: ?>
                                <span class="badge bg-success"><i class="bi bi-check-circle-fill me-1"></i>Active</span>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>

                <?php require_once __DIR__ . '/includes/breadcrumb.php'; renderBreadcrumb([
                    ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'],
                    ['label' => 'Curriculum', 'href' => 'Curriculum.php', 'icon' => 'bi bi-journal-bookmark-fill'],
                    ['label' => 'S.Y. ' . $year['year_label'], 'icon' => 'bi bi-calendar3']
                ]); ?>

                <?php if ($isArchived): ?>
                <div class="cy-readonly-banner">
                    <i class="bi bi-lock-fill"></i>
                    <div>
                        <strong>Read-only mode.</strong>
                        This curriculum has been archived. Subjects cannot be added, edited, or deleted.
                    </div>
                </div>
                <?php endif; ?>

                <!-- TREE UI (MOVED FROM CURRICULUM.PHP) -->
                <div class="curriculum-tree-wrapper mt-4" id="curriculumTreeWrapper">
                    <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
                        <h5 class="mb-0">
                            <i class="bi bi-diagram-3 me-2"></i>
                            Subjects for S.Y. <?= $viewYear ? htmlspecialchars($viewYear['year_label']) : '' ?>
                            <?php if ($readOnlyView && $viewYear): ?>
                                <span class="badge bg-secondary ms-2">Read-only (Archived)</span>
                            <?php endif; ?>
                        </h5>
                        <a href="Curriculum.php" class="btn btn-ay btn-ay-outline btn-ay-sm">
                            <i class="bi bi-x-lg me-1"></i> Close
                        </a>
                    </div>
                <div class="ay-layout">
                    
                    <div>
                        <div class="ay-card" style="margin-bottom:0;">
                            <div class="ay-card-header">
                                <div>
                                    <p class="ay-card-title"><i class="bi bi-diagram-3 me-1"></i>Grade Levels</p>
                                    <p class="ay-card-subtitle">Select a grade or track to manage subjects</p>
                                </div>
                                <span id="navSpinner" class="spinner-border spinner-border-sm text-primary" style="display:none;"></span>
                            </div>
                            <div class="ay-tree-wrap" id="gradeNavWrapper">
                                <div class="ay-empty" style="padding:1.6rem 1rem;">
                                    <span class="spinner-border spinner-border-sm me-1"></span> Loading...
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div>
                        <div class="ay-card" style="margin-bottom:0;">
                            <div class="ay-card-header">
                                <div>
                                    <p class="ay-card-title mb-1" id="subjectsPanelTitle">Select a grade level</p>
                                    <div class="ay-context" id="subjectsCtx"></div>
                                </div>
                                <div style="display:flex;gap:.5rem;align-items:center;flex-wrap:wrap;" id="subjectsActions"></div>
                            </div>

                            <div class="d-none d-md-block">
                                <table class="ay-table" id="subjectsTable">
                                    <thead>
                                        <tr>
                                            <th style="width:56px;text-align:center;">#</th>
                                            <th>Subject / Learning Area</th>
                                            <th style="width:120px;">Type</th>
                                            <th style="width:120px;text-align:center;">Status</th>
                                            <th style="width:180px;text-align:center;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="subjectsTableBody">
                                        <tr>
                                            <td colspan="5">
                                                <div class="ay-empty">
                                                    <i class="bi bi-arrow-left-circle"></i>
                                                    <p>Choose a grade or track from the left panel.</p>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <div class="d-block d-md-none p-3" id="subjectsCards"></div>

                            <div class="ay-card-footer">
                                <div class="ay-footer-note" id="subjectsCountText"></div>
                                <ul class="ay-pagination" id="subjectsPagination"></ul>
                            </div>
                        </div>
                    </div>
                </div>
                </div><!-- /.curriculum-tree-wrapper -->

            </div>
        </div>
    </main>
    <?php require_once("includes/footer.php"); ?>
</div>


<div class="modal fade ay-modal" id="subjectModal" tabindex="-1" data-bs-backdrop="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="subjectForm" novalidate>
                <div class="modal-header">
                    <h5 class="modal-title" id="subjectModalTitle"><i class="bi bi-plus-circle me-2"></i>Add Subject</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="sfCurriculumId">
                    <input type="hidden" id="sfGradeLevelId">
                    <input type="hidden" id="sfStrand" value="">
                    <input type="hidden" id="sfCode">

                    <div class="mb-3">
                        <label class="form-label">Subject Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="sfName" maxlength="150" required>
                    </div>

                    <div class="mb-3" id="sfTypeWrap">
                        <label class="form-label">Type</label>
                        <select class="form-select" id="sfType">
                            <option value="CORE">Core</option>
                            <option value="APPLIED">Applied</option>
                            <option value="SPECIALIZED">Specialized</option>
                            <option value="ELECTIVE">Elective</option>
                        </select>
                    </div>

                    <div class="mb-3" id="sfActiveWrap">
                        <label class="form-label">Status</label>
                        <select class="form-select" id="sfActive">
                            <option value="1">Active</option>
                            <option value="0">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-ay btn-ay-outline" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-ay btn-ay-primary" id="btnSaveSubject">
                        <i class="bi bi-check-circle me-1"></i> Save Subject
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>
<script>
const APP_BASE = (window.location.pathname.replace(/\/[^\/]*$/, '')) || '';

/* ---- Curriculum-year context (injected by PHP) ---- */
const CURRICULUM_YEAR_ID   = <?= $viewYear ? (int) $viewYear['id'] : 'null' ?>;
const CURRICULUM_READ_ONLY = <?= $readOnlyView ? 'true' : 'false' ?>;
const IS_SUPER_ADMIN       = <?= $isSuperAdmin ? 'true' : 'false' ?>;

let activeGradeId = null;
let activeStrand  = null;
let activeGrade   = null;
let activeIsShs   = false;
let subjectsCache = [];
let currentPage   = 1;
let searchTerm    = '';
const rowsPerPage = 5;

function toast(msg, type = 'success') {
    const map = {
        success: { title: 'Success', color: 'green',  icon: 'bi bi-check-circle-fill' },
        danger:  { title: 'Error',   color: 'red',    icon: 'bi bi-exclamation-octagon-fill' },
        warning: { title: 'Warning', color: 'yellow', icon: 'bi bi-exclamation-triangle-fill' },
        info:    { title: 'Info',    color: 'blue',   icon: 'bi bi-info-circle-fill' },
    };
    const c = map[type] || map.success;
    iziToast.show({
        title: c.title, message: msg, color: c.color, icon: c.icon,
        iconColor: '#fff', theme: 'light', position: 'topRight',
        timeout: 4000, progressBar: true, close: true, pauseOnHover: true,
        transitionIn: 'fadeInDown', transitionOut: 'fadeOutUp'
    });
}

function confirmAction(message, onYes) {
    iziToast.destroy();
    iziToast.question({
        timeout: 20000, close: false, overlay: true, displayMode: 'once',
        zindex: 99999, title: 'Confirm Delete', message: message,
        position: 'center', color: 'blue', icon: 'bi bi-question-circle-fill', drag: false,
        buttons: [
            ['<button><b>Yes, Delete</b></button>',
                function (instance, toastRef) {
                    instance.hide({ transitionOut: 'fadeOut' }, toastRef, 'button');
                    onYes();
                }, true],
            ['<button>Cancel</button>',
                function (instance, toastRef) {
                    instance.hide({ transitionOut: 'fadeOut' }, toastRef, 'button');
                }]
        ]
    });
}

async function api(url, opts = {}) {
    const response = await fetch(url, opts);
    const raw = await response.text();
    if (!response.ok) {
        let msg = `HTTP ${response.status}`;
        try { const j = JSON.parse(raw); if (j && j.error) msg = j.error; } catch (e) { /* not JSON */ }
        console.error('API error:', url, response.status, raw);
        throw new Error(msg);
    }
    try { return JSON.parse(raw); }
    catch (err) {
        console.error('Invalid server response from', url, ':', raw);
        throw new Error(`Invalid server response from ${url}`);
    }
}

function escapeHtml(v) {
    return String(v ?? '')
        .replaceAll('&','&amp;').replaceAll('<','&lt;')
        .replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'","&#039;");
}

function typeBadge(type) {
    const m = {
        CORE:        ['ay-badge-core',        'Core'],
        APPLIED:     ['ay-badge-applied',     'Applied'],
        SPECIALIZED: ['ay-badge-specialized', 'Specialized'],
        ELECTIVE:    ['ay-badge-elective',    'Elective'],
    };
    const [cls, lbl] = m[type] || m.CORE;
    return `<span class="ay-badge ${cls}">${lbl}</span>`;
}

function buildAutoSubjectCode(name) {
    const code = String(name || '').trim().toUpperCase()
        .replace(/[^A-Z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 50);
    return code || 'SUBJECT';
}

function renderTypeForGrade(type, isShs) {
    return isShs ? typeBadge(type) : `<span style="color:var(--cy-text-dim);">—</span>`;
}

function clearNavSelection() {
    document.querySelectorAll('.grade-row').forEach(el => el.classList.remove('active'));
}

function openNavPath(sourceEl) {
    // Expand every ancestor collapse (Bootstrap) so the active row is visible.
    let panel = sourceEl.closest('.accordion-collapse');
    while (panel) {
        const btn = document.querySelector(`[data-bs-target="#${panel.id}"]`);
        if (btn) {
            btn.classList.remove('collapsed');
            btn.setAttribute('aria-expanded', 'true');
        }
        bootstrap.Collapse.getOrCreateInstance(panel, { toggle: false }).show();
        const parent = panel.parentElement ? panel.parentElement.closest('.accordion-collapse') : null;
        panel = parent;
    }
}

/* Bootstrap collapse handles the accordion behaviour (data-bs-parent). */

async function loadTree() {
    document.getElementById('navSpinner').style.display = 'inline-block';
    try {
        const d = await api(`${APP_BASE}/api/curriculum/structure.php`);
        if (!d.success) throw new Error(d.error || 'Failed to load structure.');
        renderTree(d.data || []);
    } catch (e) {
        toast(e.message, 'danger');
        document.getElementById('gradeNavWrapper').innerHTML =
            `<div class="ay-empty"><i class="bi bi-exclamation-circle"></i><p>${escapeHtml(e.message)}</p></div>`;
    } finally {
        document.getElementById('navSpinner').style.display = 'none';
    }
}

/* ============================================================
   ★ FIXED HIERARCHY
   Kindergarten       → Kindergarten
   Elementary         → Grade 1–6
   Junior High School → Grade 7–10
   Senior High School → Grade 11–12 (with tracks)
   ============================================================ */
function normalizeTree(tree) {
    const allGrades = [];
    tree.forEach(level => {
        (level.grades || []).forEach(g => allGrades.push(g));
    });

    const groups = { KINDER: [], ELEM: [], JHS: [], SHS: [] };

    allGrades.forEach(g => {
        const label = String(g.grade_label || '').trim();

        // Kindergarten intentionally excluded — it uses developmental 
        // domains (see SuperAdmin/Kinder-Skills.php) instead of subjects.
        if (/kinder/i.test(label)) {
            return;
        }

        const numMatch = label.match(/(\d+)/);
        if (!numMatch) return;
        const n = parseInt(numMatch[1], 10);

        if (n >= 1 && n <= 6)        groups.ELEM.push(g);
        else if (n >= 7 && n <= 10)  groups.JHS.push(g);
        else if (n >= 11)            groups.SHS.push(g);
    });

    Object.values(groups).forEach(arr => {
        arr.sort((a, b) => {
            const na = parseInt((String(a.grade_label || '').match(/\d+/) || [0])[0], 10);
            const nb = parseInt((String(b.grade_label || '').match(/\d+/) || [0])[0], 10);
            return na - nb;
        });
    });

    const levelMeta = [
        { code: 'ELEM',   label: 'Elementary' },
        { code: 'JHS',    label: 'Junior High School' },
        { code: 'SHS',    label: 'Senior High School' }
    ];

    return levelMeta
        .map(meta => ({
            code:   meta.code,
            label:  meta.label,
            grades: groups[meta.code] || []
        }))
        .filter(level => level.grades.length > 0);
}

function renderTree(tree) {
    const wrap = document.getElementById('gradeNavWrapper');
    wrap.innerHTML = '';
    wrap.classList.add('curriculum-tree');

    const normalized = normalizeTree(tree);
    const meta = {
        ELEM: { icon: 'bi-backpack' },
        JHS:  { icon: 'bi-book' },
        SHS:  { icon: 'bi-mortarboard' }
    };

    const acc = document.createElement('div');
    acc.className = 'accordion';
    acc.id = 'curriculumAccordion';

    normalized.forEach(level => {
        const m = meta[level.code] || { icon: 'bi-circle' };
        const headId = `stageHead_${level.code}`;
        const bodyId = `stageBody_${level.code}`;

        const item = document.createElement('div');
        item.className = 'accordion-item curriculum-tree-stage';
        item.innerHTML = `
            <h2 class="accordion-header stage-row" id="${headId}">
                <button class="accordion-button collapsed" type="button"
                        data-bs-toggle="collapse" data-bs-target="#${bodyId}"
                        aria-expanded="false" aria-controls="${bodyId}">
                    <i class="bi bi-chevron-right chevron me-2"></i>
                    <i class="bi ${m.icon} me-2"></i>
                    <span class="stage-label">${escapeHtml(level.label)}</span>
                </button>
            </h2>`;

        const body = document.createElement('div');
        body.id = bodyId;
        body.className = 'accordion-collapse collapse';
        body.setAttribute('aria-labelledby', headId);
        body.dataset.bsParent = '#curriculumAccordion';

        const bodyInner = document.createElement('div');
        bodyInner.className = 'accordion-body p-2';

        (level.grades || []).forEach(g => {
            g._levelCode = level.code;
            g._levelLabel = level.label;
            if (level.code === 'SHS') {
                bodyInner.appendChild(renderShsGradeNode(g, bodyId, g.id));
            } else {
                bodyInner.appendChild(gradeItem(g));
            }
        });

        body.appendChild(bodyInner);
        item.appendChild(body);
        acc.appendChild(item);
    });

    wrap.appendChild(acc);
}

function gradeItem(g) {
    const row = document.createElement('a');
    row.href = 'javascript:void(0)';
    row.className = 'grade-row';
    row.dataset.gid = g.id;
    row.innerHTML = `<i class="bi bi-journal-text me-2"></i><span>${escapeHtml(g.grade_label)}</span>`;
    row.addEventListener('click', () => selectGrade(g, row, false));
    return row;
}

function renderShsGradeNode(g, parentBodyId, uniqueKey) {
    const node = document.createElement('div');
    const tracksId = `shsTracks_${uniqueKey}`;

    const gradeRow = document.createElement('a');
    gradeRow.href = 'javascript:void(0)';
    gradeRow.className = 'grade-row';
    gradeRow.setAttribute('data-bs-toggle', 'collapse');
    gradeRow.setAttribute('data-bs-target', `#${tracksId}`);
    gradeRow.setAttribute('aria-expanded', 'false');
    gradeRow.setAttribute('aria-controls', tracksId);
    gradeRow.innerHTML = `<i class="bi bi-chevron-right chevron me-1"></i><i class="bi bi-journal-text me-2"></i><span>${escapeHtml(g.grade_label)}</span>`;
    node.appendChild(gradeRow);

    const tracks = document.createElement('div');
    tracks.className = 'collapse';
    tracks.id = tracksId;
    tracks.dataset.bsParent = `#${parentBodyId}`;

    const list = document.createElement('div');
    list.className = 'track-list';
    [
        { value: '', label: 'All Tracks' },
        { value: 'Academic', label: 'Academic Track' },
        { value: 'Technical-Professional (Tech-Pro)', label: 'Technical-Professional (Tech-Pro)' }
    ].forEach(track => {
        const item = document.createElement('a');
        item.href = 'javascript:void(0)';
        item.className = 'grade-row track-row';
        item.dataset.gid = g.id;
        item.dataset.strand = track.value;
        item.innerHTML = `<i class="bi bi-signpost-2 me-2"></i><span>${escapeHtml(track.label)}</span>`;
        item.addEventListener('click', (e) => { e.stopPropagation(); selectStrand(g, track.value, item); });
        list.appendChild(item);
    });
    tracks.appendChild(list);
    node.appendChild(tracks);
    return node;
}

function selectGrade(g, sourceEl = null, isShs = false) {
    activeStrand  = null;
    activeGradeId = Number(g.id);
    activeIsShs   = Boolean(isShs);
    activeGrade = {
        id: Number(g.id),
        grade_label: g.grade_label,
        level_label: g._levelLabel || '',
        is_shs: activeIsShs
    };
    clearNavSelection();
    if (sourceEl) { sourceEl.classList.add('active'); openNavPath(sourceEl); }
    else document.querySelector(`.ay-grade-item[data-gid="${g.id}"]`)?.classList.add('active');
    currentPage = 1; searchTerm = '';
    loadAssignedSubjects(activeGradeId, null);
}

function selectStrand(g, strand, sourceEl) {
    activeGradeId = Number(g.id);
    activeStrand  = strand || null;   // empty value = "All Tracks"
    activeIsShs   = true;
    activeGrade = {
        id: Number(g.id),
        grade_label: g.grade_label,
        level_label: g._levelLabel || '',
        is_shs: true
    };
    clearNavSelection(); sourceEl.classList.add('active'); openNavPath(sourceEl);
    currentPage = 1; searchTerm = '';
    loadAssignedSubjects(activeGradeId, activeStrand);
}

function updateSubjectTypeVisibility(isShs) {
    const typeWrap   = document.getElementById('sfTypeWrap');
    const typeSelect = document.getElementById('sfType');
    if (isShs) {
        typeWrap.style.display = '';
    } else {
        typeWrap.style.display = 'none';
        typeSelect.value = 'CORE';
    }
}

function updateSubjectsCount(page, listLength, total) {
    const countEl = document.getElementById('subjectsCountText');
    if (!countEl) return;
    if (total === 0) { countEl.textContent = 'No subjects to display.'; return; }
    const start = ((page - 1) * rowsPerPage) + 1;
    const end = start + listLength - 1;
    countEl.textContent = `Showing ${start}-${end} of ${total} subjects`;
}

async function loadAssignedSubjects(gradeId, strand = null) {
    const tbody = document.getElementById('subjectsTableBody');
    tbody.innerHTML =
        `<tr><td colspan="5"><div class="ay-empty"><span class="spinner-border spinner-border-sm me-1"></span>Loading...</div></td></tr>`;
    try {
        let url = `${APP_BASE}/api/curriculum/assigned_subjects.php?grade_id=${gradeId}`;
        if (strand && activeIsShs) url += `&strand=${encodeURIComponent(strand)}`;
        if (CURRICULUM_YEAR_ID) url += `&academic_year_id=${encodeURIComponent(CURRICULUM_YEAR_ID)}`;
        const d = await api(url);
        if (!d.success) throw new Error(d.error || 'Failed to load subjects.');
        activeGrade = d.grade || activeGrade;
        subjectsCache = d.subjects || [];
        renderAssignedSubjects(subjectsCache, activeGrade, strand);
    } catch (e) {
        // Show a visible error instead of an infinite "Loading..." state
        console.error('Failed to load subjects:', e);
        toast(e.message, 'danger');
        tbody.innerHTML =
            `<tr><td colspan="5"><div class="alert alert-danger m-3" role="alert">` +
            `<i class="bi bi-exclamation-octagon-fill me-2"></i>Failed to load subjects: ${escapeHtml(e.message)}</div></td></tr>`;
        document.getElementById('subjectsCards').innerHTML = '';
        renderPagination(1, 1, 'subjectsPagination');
    }
}

function paginate(list, page) {
    const total = list.length;
    const pages = Math.ceil(total / rowsPerPage) || 1;
    const safePage = Math.min(Math.max(page, 1), pages);
    const start = (safePage - 1) * rowsPerPage;
    const paginated = list.slice(start, start + rowsPerPage);
    return { paginated, page: safePage, pages, total };
}

/* Build the per-row action buttons.
   - Active curriculum (not read-only): Admins + Super Admins get Edit.
   - Super Admins additionally get Delete (any state).
   - Archived / read-only: no Edit; only a lock indicator for non-Super-Admins. */
function subjectActionButtons(s, compact = false) {
    const sizeCls = compact ? 'btn-ay-sm' : 'btn-ay-icon';
    let html = '';
    if (!CURRICULUM_READ_ONLY) {
        html += `<button type="button" class="btn btn-ay btn-ay-outline ${sizeCls} js-edit-subject"
            data-id="${Number(s.curriculum_id)}" title="Edit"><i class="bi bi-pencil-square"></i></button>`;
    }
    if (IS_SUPER_ADMIN) {
        html += `<button type="button" class="btn btn-ay btn-ay-danger ${sizeCls} js-delete-subject"
            data-id="${Number(s.curriculum_id)}" data-name="${escapeHtml(s.subject_name)}" title="Delete"><i class="bi bi-trash3"></i></button>`;
    }
    if (html === '') {
        html = '<span class="ay-row-locked" title="Read-only"><i class="bi bi-lock"></i></span>';
    }
    return html;
}

function renderAssignedSubjects(list, grade, strand) {
    let title = `${grade.grade_label || ''} — Assigned Subjects`;
    if (strand) title = `${grade.grade_label || ''} — ${strand} Track — Assigned Subjects`;
    document.getElementById('subjectsPanelTitle').textContent = title;

    let ctxHtml = grade.level_label ? `<span class="ay-context-pill">${escapeHtml(grade.level_label)}</span>` : '';
    if (strand) ctxHtml += `<span class="ay-context-pill">Track: ${escapeHtml(strand)}</span>`;
    else if (activeIsShs) ctxHtml += `<span class="ay-context-pill">All Tracks</span>`;
    document.getElementById('subjectsCtx').innerHTML = ctxHtml;

    document.getElementById('subjectsActions').innerHTML = `
        ${activeIsShs ? `
        <select class="form-select form-select-sm ay-track-select" style="width:auto;" onchange="setTrackFilter(this.value)">
            <option value="" ${!strand ? 'selected' : ''}>All Tracks</option>
            <option value="Academic" ${strand === 'Academic' ? 'selected' : ''}>Academic</option>
            <option value="Technical-Professional (Tech-Pro)" ${strand === 'Technical-Professional (Tech-Pro)' ? 'selected' : ''}>Tech-Pro</option>
        </select>` : ''}
        <input class="ay-search" type="search" id="searchInput" placeholder="Search subjects...">
        ${CURRICULUM_READ_ONLY ? '' : `
        <button type="button" class="btn btn-ay btn-ay-primary" onclick="openSubjectModal()">
            <i class="bi bi-plus-circle me-1"></i> Add Subject
        </button>`}
    `;

    const trackSelect = document.querySelector('.ay-track-select');
    if (trackSelect) trackSelect.value = strand || '';

    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.value = searchTerm;
        searchInput.addEventListener('input', e => {
            clearTimeout(window.searchDebounce);
            window.searchDebounce = setTimeout(() => {
                searchTerm = e.target.value.trim().toLowerCase();
                currentPage = 1;
                renderAssignedSubjects(subjectsCache, activeGrade, activeStrand);
            }, 300);
        });
    }

    let filtered = list;
    if (searchTerm) {
        filtered = list.filter(s =>
            (s.subject_name || '').toLowerCase().includes(searchTerm) ||
            (s.subject_code || '').toLowerCase().includes(searchTerm)
        );
    }

    const { paginated, page, pages, total } = paginate(filtered, currentPage);
    const tbody = document.getElementById('subjectsTableBody');
    const cards = document.getElementById('subjectsCards');

    updateSubjectsCount(page, paginated.length, total);

    if (!paginated.length) {
        const emptyHtml = `<div class="ay-empty"><i class="bi bi-book"></i><p>No subjects found.</p></div>`;
        tbody.innerHTML = `<tr><td colspan="5">${emptyHtml}</td></tr>`;
        cards.innerHTML = emptyHtml;
        renderPagination(1, 1, 'subjectsPagination');
        return;
    }

    const offset = (page - 1) * rowsPerPage;

    tbody.innerHTML = paginated.map((s, i) => `
        <tr>
            <td style="text-align:center;color:var(--cy-text-dim);font-size:.82rem;">${offset + i + 1}</td>
            <td>
                <div style="font-weight:700;color:var(--cy-text-strong);">${escapeHtml(s.subject_name)}</div>
                <div style="font-size:.76rem;color:var(--cy-text-muted);">${escapeHtml(s.subject_code)}</div>
            </td>
            <td>${renderTypeForGrade(s.subject_type, activeIsShs)}</td>
            <td style="text-align:center;">
                <span class="ay-badge ${Number(s.is_active) === 1 ? 'ay-badge-active' : 'ay-badge-inactive'}">
                    ${Number(s.is_active) === 1 ? '<i class="bi bi-check-circle-fill"></i> Active' : 'Inactive'}
                </span>
            </td>
            <td style="text-align:center;">
                <div class="ay-row-actions">
                    ${subjectActionButtons(s)}
                </div>
            </td>
        </tr>
    `).join('');

    cards.innerHTML = paginated.map((s, i) => `
        <div class="ay-mobile-card">
            <div class="ay-mobile-card-header">
                <span class="ay-mobile-card-title">${offset + i + 1}. ${escapeHtml(s.subject_name)}</span>
                ${renderTypeForGrade(s.subject_type, activeIsShs)}
            </div>
            <div class="ay-mobile-card-body">
                <div class="grade-label"><i class="bi bi-upc-scan me-1"></i>${escapeHtml(s.subject_code)}</div>
                <div style="display:flex;gap:.4rem;flex-wrap:wrap;align-items:center;">
                    <span class="ay-badge ${Number(s.is_active) === 1 ? 'ay-badge-active' : 'ay-badge-inactive'}">
                        ${Number(s.is_active) === 1 ? 'Active' : 'Inactive'}
                    </span>
                    ${subjectActionButtons(s, true)}
                </div>
            </div>
        </div>
    `).join('');

    renderPagination(page, pages, 'subjectsPagination');
}

function renderPagination(page, pages, elementId) {
    const pagination = document.getElementById(elementId);
    if (!pagination) return;
    if (pages <= 1) { pagination.innerHTML = ''; return; }

    let html = '';
    html += `<li class="ay-page-item ${page <= 1 ? 'disabled' : ''}">
        <a class="ay-page-link" onclick="${page > 1 ? `goToPage(${page - 1})` : 'return false;'}">Previous</a>
    </li>`;
    for (let n = 1; n <= pages; n++) {
        html += `<li class="ay-page-item ${n === page ? 'active' : ''}">
            <a class="ay-page-link" onclick="goToPage(${n})">${n}</a>
        </li>`;
    }
    html += `<li class="ay-page-item ${page >= pages ? 'disabled' : ''}">
        <a class="ay-page-link" onclick="${page < pages ? `goToPage(${page + 1})` : 'return false;'}">Next</a>
    </li>`;
    pagination.innerHTML = html;
}

function goToPage(page) {
    currentPage = page;
    renderAssignedSubjects(subjectsCache, activeGrade, activeStrand);
}

function setTrackFilter(value) {
    activeStrand = value || null;   // empty = All Tracks
    currentPage = 1;
    loadAssignedSubjects(activeGradeId, activeStrand);
}

function openSubjectModalById(id) {
    const row = subjectsCache.find(x => Number(x.curriculum_id) === Number(id));
    if (!row) { toast('Subject not found.', 'warning'); return; }
    openSubjectModal(row);
}

function openSubjectModal(row = null) {
    if (CURRICULUM_READ_ONLY) { toast('This curriculum is archived and read-only.', 'warning'); return; }
    if (!activeGradeId) { toast('Select a grade or strand first.', 'warning'); return; }
    const gradeId = Number(row ? (row.grade_level_id || activeGradeId) : activeGradeId);
    const strand  = row ? (row.strand || activeStrand) : activeStrand;

    document.getElementById('sfCurriculumId').value = row ? row.curriculum_id : '';
    document.getElementById('sfGradeLevelId').value  = gradeId;
    document.getElementById('sfStrand').value        = strand || '';
    document.getElementById('sfCode').value          = row ? (row.subject_code || '') : '';
    document.getElementById('sfName').value          = row ? (row.subject_name || '') : '';
    document.getElementById('sfType').value          = row ? (row.subject_type || 'CORE') : 'CORE';
    document.getElementById('sfActive').value        = row ? Number(row.is_active ?? 1) : 1;

    updateSubjectTypeVisibility(activeIsShs);

    document.getElementById('subjectModalTitle').innerHTML = row
        ? '<i class="bi bi-pencil-square me-2"></i>Edit Subject'
        : '<i class="bi bi-plus-circle me-2"></i>Add Subject';

    bootstrap.Modal.getOrCreateInstance(document.getElementById('subjectModal')).show();
}

document.getElementById('subjectForm').addEventListener('submit', async function (e) {
    e.preventDefault();
    const gradeId = Number(document.getElementById('sfGradeLevelId').value || 0);
    const subjectName = document.getElementById('sfName').value.trim();
    const strand = document.getElementById('sfStrand').value || null;

    const payload = {
        curriculum_id:  document.getElementById('sfCurriculumId').value || null,
        academic_year_id: CURRICULUM_YEAR_ID,
        grade_level_id: gradeId,
        strand:         strand,
        subject_code:   document.getElementById('sfCode').value.trim() || buildAutoSubjectCode(subjectName),
        subject_name:   subjectName,
        subject_type:   activeIsShs ? document.getElementById('sfType').value : 'CORE',
        is_active:      Number(document.getElementById('sfActive').value || 1),
    };

    const btn = document.getElementById('btnSaveSubject');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Saving...';

    try {
        const res = await api(`${APP_BASE}/api/curriculum/save_subject.php`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
        });
        if (res.success) {
            bootstrap.Modal.getInstance(document.getElementById('subjectModal')).hide();
            toast(res.message || 'Subject saved.');
            loadAssignedSubjects(activeGradeId, activeStrand);
        } else { toast(res.error || 'Save failed.', 'danger'); }
    } catch (err) { toast(err.message, 'danger'); }
    finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-check-circle me-1"></i> Save Subject';
    }
});

document.addEventListener('click', function (e) {
    const editBtn = e.target.closest('.js-edit-subject');
    if (editBtn) {
        const id = Number(editBtn.dataset.id || 0);
        if (id > 0) openSubjectModalById(id);
        return;
    }
    const deleteBtn = e.target.closest('.js-delete-subject');
    if (deleteBtn) {
        if (!IS_SUPER_ADMIN) { toast('Only Super Admins can delete subjects.', 'danger'); return; }
        const id = Number(deleteBtn.dataset.id || 0);
        const name = deleteBtn.dataset.name || '';
        if (id <= 0) { toast('Invalid subject record.', 'danger'); return; }
        confirmAction(`Delete <b>${name}</b> from this grade/strand?`, async () => {
            try {
                const res = await api(`${APP_BASE}/api/curriculum/delete_subject.php`, {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ curriculum_id: id })
                });
                if (res.success) {
                    toast(res.message || 'Deleted.');
                    loadAssignedSubjects(activeGradeId, activeStrand);
                } else { toast(res.error || 'Delete failed.', 'danger'); }
            } catch (err) { toast(err.message || 'Delete request failed.', 'danger'); }
        });
        return;
    }
});

document.getElementById('subjectModal').addEventListener('hidden.bs.modal', () => {
    document.getElementById('subjectForm').reset();
    document.getElementById('sfCurriculumId').value = '';
    document.getElementById('subjectModalTitle').innerHTML = '<i class="bi bi-plus-circle me-2"></i>Add Subject';
});

/* ============================================================
   Curriculum lifecycle (create / archive)
   ============================================================ */
document.addEventListener('DOMContentLoaded', function () {
    const createBtn = document.getElementById('createCurriculumBtn');
    if (createBtn && !createBtn.disabled) {
        createBtn.addEventListener('click', function () {
            const modalEl = document.getElementById('createCurriculumModal');
            if (modalEl) bootstrap.Modal.getOrCreateInstance(modalEl).show();
        });
    }

    const createForm = document.getElementById('createCurriculumForm');
    if (createForm) {
        createForm.addEventListener('submit', async function (e) {
            e.preventDefault();
            const fd = new FormData(createForm);
            const payload = {
                academic_year_id: parseInt(fd.get('academic_year_id'), 10) || 0,
                copy_previous: fd.get('copy_previous') === '1'
            };

            const submitBtn = createForm.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Creating...';
            }

            try {
                const res = await api(`${APP_BASE}/api/curriculum/create.php`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
                    body: JSON.stringify(payload)
                });
                if (res.success) {
                    location.reload();
                } else {
                    toast(res.error || 'Failed to create curriculum.', 'danger');
                }
            } catch (err) {
                toast(err.message, 'danger');
            } finally {
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = '<i class="bi bi-check-circle me-1"></i> Create Curriculum';
                }
            }
        });
    }
});

async function deactivateCurriculum(yearId) {
    if (!confirm('Archive this curriculum? All subjects and grade records will become read-only. This cannot be undone.')) return;

    try {
        const res = await api(`${APP_BASE}/api/curriculum/deactivate.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            body: JSON.stringify({ academic_year_id: yearId })
        });
        if (res.success) {
            location.reload();
        } else {
            toast(res.error || 'Failed to archive curriculum.', 'danger');
        }
    } catch (err) {
        toast(err.message, 'danger');
    }
}

if (CURRICULUM_YEAR_ID) loadTree();
</script>
</body>
</html>
