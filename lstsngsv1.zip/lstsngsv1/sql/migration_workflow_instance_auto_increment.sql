-- Allow approval workflow instances to be created without manually supplying an id.
-- Preserves existing IDs and adds the missing primary key required by AUTO_INCREMENT.
ALTER TABLE tblworkflow_instance
    MODIFY id BIGINT NOT NULL AUTO_INCREMENT,
    ADD PRIMARY KEY (id);
