CREATE TABLE IF NOT EXISTS tblpsgc_location_cache (
    location_type ENUM('REGION', 'PROVINCE', 'CITY', 'BARANGAY') NOT NULL,
    psgc_code VARCHAR(16) NOT NULL,
    parent_code VARCHAR(16) NOT NULL,
    local_id INT NOT NULL,
    location_name VARCHAR(150) NOT NULL,
    postal_code VARCHAR(20) NULL,
    cached_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (location_type, psgc_code),
    KEY idx_psgc_location_parent (location_type, parent_code, cached_at),
    KEY idx_psgc_location_local (location_type, local_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS tblpsgc_location_cache_state (
    location_type ENUM('REGION', 'PROVINCE', 'CITY', 'BARANGAY') NOT NULL,
    parent_code VARCHAR(16) NOT NULL,
    synced_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (location_type, parent_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
