-- ============================================================
-- Migration: Approval Documents
-- Feature: Printable "Certificate of Grade Approval" documents
-- Table: tblapproval_documents
-- Engine: InnoDB | Charset: utf8mb4
-- ============================================================

CREATE TABLE IF NOT EXISTS tblapproval_documents (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    document_id VARCHAR(50) NOT NULL UNIQUE,
    instance_id INT UNSIGNED NOT NULL,
    section_id INT UNSIGNED NOT NULL,
    subject_id INT UNSIGNED NOT NULL,
    term_id INT UNSIGNED NULL,
    academic_year_id INT UNSIGNED NOT NULL,
    generated_by INT UNSIGNED NULL,
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    verification_hash VARCHAR(64) NULL,
    is_revoked TINYINT(1) DEFAULT 0,
    revoked_at DATETIME NULL,
    revoked_by INT UNSIGNED NULL,
    INDEX idx_instance (instance_id),
    INDEX idx_section (section_id),
    INDEX idx_year (academic_year_id),
    INDEX idx_doc_id (document_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
