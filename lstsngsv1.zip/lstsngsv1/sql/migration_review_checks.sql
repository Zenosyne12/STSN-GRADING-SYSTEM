-- ============================================================
-- Migration: Workflow Review Checks (Phase 2 - "Mark as Checked")
-- Feature: Per-user visual indicator for reviewed submissions.
--          Does NOT affect the approval workflow.
-- ============================================================

CREATE TABLE IF NOT EXISTS tblworkflow_review_checks (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    section_id INT UNSIGNED NOT NULL,
    subject_id INT UNSIGNED NOT NULL,
    term_id INT UNSIGNED NULL,
    academic_year_id INT UNSIGNED NOT NULL,
    checked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unq_review_check (user_id, section_id, subject_id, term_id, academic_year_id),
    INDEX idx_user_year (user_id, academic_year_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
