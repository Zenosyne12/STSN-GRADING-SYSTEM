-- ============================================================
-- migration_curriculum_years.sql
-- Adds per-academic-year curriculum support.
--   * tblsubjects   -> academic_year_id (fresh subject copy per year)
--   * tblacademicyear -> curriculum_status / archived_at / created_at
-- Run ONCE against dbstsn. Safe to run before deploying the new
-- Curriculum.php (the page reads these columns).
-- NOTE: MySQL DDL auto-commits, so the transaction only guards the
--       two UPDATE statements below (it is otherwise a no-op).
-- ============================================================

START TRANSACTION;

-- 1. Add academic_year_id to tblsubjects (fresh copy per year)
ALTER TABLE tblsubjects
    ADD COLUMN academic_year_id INT NULL AFTER id,
    ADD INDEX idx_year (academic_year_id);

-- 2. Add curriculum state to tblacademicyear
ALTER TABLE tblacademicyear
    ADD COLUMN curriculum_status ENUM('NONE','ACTIVE','ARCHIVED')
        DEFAULT 'NONE' AFTER is_active,
    ADD COLUMN curriculum_archived_at DATETIME NULL AFTER curriculum_status,
    ADD COLUMN curriculum_created_at DATETIME NULL AFTER curriculum_archived_at;

-- 3. Auto-assign existing subjects to the current active year
UPDATE tblsubjects
SET academic_year_id = (SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1)
WHERE academic_year_id IS NULL;

-- 4. Mark current year's curriculum as ACTIVE (subjects already exist)
UPDATE tblacademicyear
SET curriculum_status = 'ACTIVE',
    curriculum_created_at = NOW()
WHERE is_active = 1 AND EXISTS (
    SELECT 1 FROM tblsubjects WHERE academic_year_id = tblacademicyear.id
);

COMMIT;

-- Verify
SELECT id, year_label, is_active, curriculum_status
FROM tblacademicyear
ORDER BY id DESC;
