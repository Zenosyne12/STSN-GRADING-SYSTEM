CREATE TABLE IF NOT EXISTS tblprofile_archive (
    id INT NOT NULL AUTO_INCREMENT,
    profile_type ENUM('STUDENT', 'TEACHER') NOT NULL,
    profile_id INT NOT NULL,
    academic_year_id INT NOT NULL,
    archived_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    archived_by INT NULL,
    restored_at TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_profile_year (profile_type, profile_id, academic_year_id),
    KEY idx_profile_archive_year (academic_year_id, profile_type, restored_at),
    CONSTRAINT fk_profile_archive_year
        FOREIGN KEY (academic_year_id) REFERENCES tblacademicyear (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS tblprofile_archive_section (
    profile_archive_id INT NOT NULL,
    section_student_id INT NOT NULL,
    PRIMARY KEY (profile_archive_id, section_student_id),
    CONSTRAINT fk_profile_archive_section_archive
        FOREIGN KEY (profile_archive_id) REFERENCES tblprofile_archive (id) ON DELETE CASCADE,
    CONSTRAINT fk_profile_archive_section_membership
        FOREIGN KEY (section_student_id) REFERENCES tblsectionstudent (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS tblprofile_archive_enrollment (
    profile_archive_id INT NOT NULL,
    enrollment_id INT NOT NULL,
    PRIMARY KEY (profile_archive_id, enrollment_id),
    CONSTRAINT fk_profile_archive_enrollment_archive
        FOREIGN KEY (profile_archive_id) REFERENCES tblprofile_archive (id) ON DELETE CASCADE,
    KEY idx_profile_archive_enrollment_record (enrollment_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
