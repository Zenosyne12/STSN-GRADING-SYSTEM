CREATE TABLE IF NOT EXISTS tblclusters (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cluster_name VARCHAR(255) NOT NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO tblclusters (cluster_name) VALUES
    ('Aesthetic, Wellness and Human Care'),
    ('Agri-Fishery Business and Food Innovation'),
    ('Artisanry and Creative Enterprise'),
    ('Arts, Social Sciences and Humanities'),
    ('Automotive and Small Engine Technologies'),
    ('Business and Entrepreneurship'),
    ('Construction and Building Technologies'),
    ('Creative Arts and Design Technologies'),
    ('Field Experience'),
    ('Hospitality and Tourism'),
    ('ICT Support and Computer Programming Technologies'),
    ('Industrial Technologies'),
    ('Maritime'),
    ('Science, Technology, Engineering and Mathematics'),
    ('Sports, Health and Wellness'),
    ('Work Immersion');
