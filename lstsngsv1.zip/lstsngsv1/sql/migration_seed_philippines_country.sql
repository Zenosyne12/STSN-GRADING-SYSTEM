INSERT INTO tblcountry (id, country_name, country_code)
SELECT 1, 'Philippines', 'PH'
WHERE NOT EXISTS (
    SELECT 1
    FROM tblcountry
    WHERE id = 1
);
