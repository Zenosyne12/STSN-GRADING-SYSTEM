-- ============================================================
-- migration_workflow_per_year.sql
-- PHASE B — Per-school-year workflow templates + "Mark as Checked"
--
-- Changes dbstsn so that:
--   * each academic year owns its OWN workflow template
--     (tblworkflow_template.academic_year_id)
--   * each step carries an allow_mark_checked flag that controls
--     whether that step may use the "Mark as Checked" action.
--
-- Run ONCE against the dbstsn database.
-- ============================================================

-- 1) Bind each template to an academic year.
--    NOTE: tblacademicyear.id is a SIGNED int, so this column is
--    INT NULL (NOT INT UNSIGNED) to keep the column types aligned.
ALTER TABLE tblworkflow_template
    ADD COLUMN academic_year_id INT NULL AFTER id,
    ADD INDEX idx_year (academic_year_id);

-- 2) Per-step flag controlling the "Mark as Checked" action.
--    NOT NULL + DEFAULT 0 matches the rest of the tblworkflow_step flags.
ALTER TABLE tblworkflow_step
    ADD COLUMN allow_mark_checked TINYINT(1) NOT NULL DEFAULT 0 AFTER action_type;

-- 3) Backfill: existing template(s) -> the currently active academic year.
UPDATE tblworkflow_template
   SET academic_year_id = (
       SELECT id FROM tblacademicyear WHERE is_active = 1 ORDER BY id ASC LIMIT 1
   )
 WHERE academic_year_id IS NULL;

-- 4) Backfill: Subject Coordinator steps are the ones that can be marked checked.
UPDATE tblworkflow_step
   SET allow_mark_checked = 1
 WHERE required_position = 'Subject Coordinator';
