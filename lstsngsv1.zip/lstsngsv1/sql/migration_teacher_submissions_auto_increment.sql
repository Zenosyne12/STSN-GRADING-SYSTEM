-- Ensure teacher submissions can be created without manually supplying an id.
ALTER TABLE tblteacher_submissions
    MODIFY id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    ADD PRIMARY KEY (id);
