<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/api/shared/db_connect.php';
require_once __DIR__ . '/includes/workflow_engine.php';

$adminName = $_SESSION['username'] ?? 'Registrar';
$adminId = (int)($_SESSION['user_id'] ?? $_SESSION['teacher_id'] ?? 0);

$activeYear = $pdo->query("SELECT id, year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1")->fetch(PDO::FETCH_ASSOC) ?: null;
$activeYearId = $activeYear ? (int)$activeYear['id'] : 0;
$activeYearLabel = $activeYear['year_label'] ?? '';

$pending = [];
if (function_exists('getPendingForPosition') && $activeYearId) {
    $pending = getPendingForPosition($pdo, 'Registrar', $activeYearId);
}

// === Drill-down data (all grade levels + all sections) ===
// All grade levels
$allGradeLevels = [];
try {
    $allGradeLevels = $pdo->query("
        SELECT id, grade_level_name
        FROM tblgradelevel
        ORDER BY id ASC
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $allGradeLevels = []; }

// All active sections grouped by grade level
$sectionsByGL = [];
try {
    $secStmt = $pdo->query("
        SELECT id, section_name, grade_level_id
        FROM tblsection
        WHERE is_active = 1
        ORDER BY grade_level_id ASC, section_name ASC
    ");
    foreach ($secStmt->fetchAll(PDO::FETCH_ASSOC) as $sec) {
        $gid = (int)$sec['grade_level_id'];
        if (!isset($sectionsByGL[$gid])) $sectionsByGL[$gid] = [];
        $sectionsByGL[$gid][] = [
            'id'           => (int)$sec['id'],
            'section_name' => (string)$sec['section_name'],
        ];
    }
} catch (Throwable $e) { $sectionsByGL = []; }

// Pending items grouped by section_id
$pendingBySection = [];
foreach ($pending as $p) {
    $sid = (int)$p['section_id'];
    if (!isset($pendingBySection[$sid])) $pendingBySection[$sid] = [];
    $pendingBySection[$sid][] = [
        'instance_id'        => (int)$p['instance_id'],
        'subject_id'         => (int)$p['subject_id'],
        'subject_name'       => (string)($p['subject_name'] ?? ''),
        'subject_code'       => (string)($p['subject_code'] ?? ''),
        'term_id'            => (int)($p['term_id'] ?? 0),
        'academic_year_id'   => (int)$p['academic_year_id'],
        'teacher_name'       => (string)($p['teacher_name'] ?? ''),
        'allow_mark_checked' => (int)($p['allow_mark_checked'] ?? 0),
    ];
}

$termMap = [];
$maxSteps = [];
try {
    foreach ($pdo->query("SELECT id, term_label FROM tblconfig_terms")->fetchAll(PDO::FETCH_ASSOC) as $q) {
        $termMap[(int)$q['id']] = $q['term_label'];
    }
    foreach ($pdo->query("SELECT template_id, MAX(step_order) AS max_step FROM tblworkflow_step GROUP BY template_id")->fetchAll(PDO::FETCH_ASSOC) as $s) {
        $maxSteps[(int)$s['template_id']] = (int)$s['max_step'];
    }
} catch (Throwable $e) {}

$logsStmt = $pdo->prepare("SELECT l.id, l.step_order, l.actor_position, l.action, l.acted_at FROM tblworkflow_action_log l ORDER BY l.id DESC LIMIT 10");
$logsStmt->execute();
$recentLogs = $logsStmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!doctype html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
    <meta charset="utf-8">
    <title>STSN Grading System | Grade Approvals</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <style>
        /* ============================================================
           THEME VARIABLES (Light & Dark)
           ============================================================ */
        :root,
        [data-bs-theme="light"] {
            --ay-bg: #f3f7fd;
            --ay-card: #ffffff;
            --ay-card-soft: #fafcff;
            --ay-border: #dce8f8;
            --ay-border-soft: #e8f0fb;
            --ay-text: #213a5e;
            --ay-text-strong: #132f62;
            --ay-text-muted: #7a93b8;
            --ay-text-dim: #9ab0c8;
            --ay-head-bg: #f4f8ff;
            --ay-head-text: #3b5e96;
            --ay-row-hover: #f7fbff;
            --ay-row-border: #f0f5fc;
            --ay-input-bg: #ffffff;
            --ay-input-border: #c8daf8;
            --ay-input-text: #213a5e;
            --ay-section-name: #132f62;
            --ay-grade-text: #213a5e;

            /* Buttons */
            --ay-btn-outline-bg: #ffffff;
            --ay-btn-outline-text: #1a6ef5;
            --ay-btn-outline-border: #dce8f8;
            --ay-btn-outline-hover-bg: #eef4ff;
            --ay-btn-outline-hover-border: #9cc2fc;

            --ay-btn-success-bg: #ecfdf5;
            --ay-btn-success-text: #065f46;
            --ay-btn-success-border: #a7f3d0;
            --ay-btn-success-hover-bg: #d1fae5;
            --ay-btn-success-hover-border: #6ee7b7;
        }

        [data-bs-theme="dark"] {
            --ay-bg: #1a1a1a;
            --ay-card: #2D2D2D;
            --ay-card-soft: #262626;
            --ay-border: #3a3a3a;
            --ay-border-soft: #3a3a3a;
            --ay-text: #e4e6e8;
            --ay-text-strong: #ffffff;
            --ay-text-muted: #adb5bd;
            --ay-text-dim: #8b939a;
            --ay-head-bg: #2D2D2D;
            --ay-head-text: #ffffff;
            --ay-row-hover: #343434;
            --ay-row-border: #3a3a3a;
            --ay-input-bg: #3a3a3a;
            --ay-input-border: #4a5a6e;
            --ay-input-text: #e4e6e8;
            --ay-section-name: #ffffff;
            --ay-grade-text: #e4e6e8;

            --ay-btn-outline-bg: #3a3a3a;
            --ay-btn-outline-text: #8ab4f8;
            --ay-btn-outline-border: #4a5a6e;
            --ay-btn-outline-hover-bg: #4a4a4a;
            --ay-btn-outline-hover-border: #6a7a8e;

            --ay-btn-success-bg: #17351f;
            --ay-btn-success-text: #6ee7a0;
            --ay-btn-success-border: #2b5c38;
            --ay-btn-success-hover-bg: #1e4028;
            --ay-btn-success-hover-border: #3a7048;
        }

        /* ============================================================
           BASE
           ============================================================ */
        body {
            background: var(--ay-bg);
        }

        /* ============================================================
           PAGE HEADER
           ============================================================ */
        .ay-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }
        .ay-page-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 .2rem;
        }
        .ay-page-header p {
            margin: 0;
            font-size: .88rem;
            opacity: .85;
        }
        .ay-active-chip {
            display: inline-flex;
            align-items: center;
            gap: .45rem;
            background: rgba(255, 255, 255, .15);
            border: 1.5px solid rgba(255, 255, 255, .3);
            border-radius: 999px;
            padding: .45rem 1rem;
            font-size: .88rem;
            font-weight: 700;
            color: #fff;
            white-space: nowrap;
        }

        /* ============================================================
           CARDS
           ============================================================ */
        .ay-card {
            background: var(--ay-card);
            border: 1px solid var(--ay-border);
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18, 72, 168, .06);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }
        .ay-card-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid var(--ay-border-soft);
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: .75rem;
            background: var(--ay-card);
        }
        .ay-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: var(--ay-text-strong);
            margin: 0 0 .15rem;
        }
        .ay-card-subtitle {
            font-size: .8rem;
            color: var(--ay-text-muted);
            margin: 0;
        }
        .ay-card-footer {
            padding: .75rem 1.2rem;
            border-top: 1px solid var(--ay-border-soft);
            background: var(--ay-card-soft);
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: .75rem;
            flex-wrap: wrap;
        }

        /* ============================================================
           EMPTY STATES
           ============================================================ */
        .ay-empty {
            text-align: center;
            padding: 2.5rem 1.5rem;
            color: var(--ay-text-dim);
        }
        .ay-empty i {
            font-size: 2.2rem;
            display: block;
            margin-bottom: .6rem;
            opacity: .5;
        }
        .ay-empty p {
            margin: 0;
            font-size: .95rem;
        }

        /* ============================================================
           BUTTONS
           ============================================================ */
        .btn-ay {
            font-weight: 600;
            font-size: .82rem;
            border-radius: 8px;
            padding: .42rem .9rem;
            cursor: pointer;
            transition: all .14s;
            border: 1.5px solid transparent;
            line-height: 1.4;
            display: inline-flex;
            align-items: center;
            gap: .3rem;
        }
        .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            box-shadow: 0 2px 8px rgba(26, 110, 245, .2);
        }
        .btn-ay-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
        }
        .btn-ay-outline {
            background: var(--ay-btn-outline-bg);
            color: var(--ay-btn-outline-text);
            border-color: var(--ay-btn-outline-border);
        }
        .btn-ay-outline:hover {
            background: var(--ay-btn-outline-hover-bg);
            border-color: var(--ay-btn-outline-hover-border);
            color: var(--ay-btn-outline-text);
        }
        .btn-ay-success {
            background: var(--ay-btn-success-bg);
            color: var(--ay-btn-success-text);
            border-color: var(--ay-btn-success-border);
        }
        .btn-ay-success:hover {
            background: var(--ay-btn-success-hover-bg);
            border-color: var(--ay-btn-success-hover-border);
            color: var(--ay-btn-success-text);
        }
        .btn-ay-sm {
            padding: .28rem .65rem;
            font-size: .78rem;
        }

        /* ============================================================
           APPROVALS
           ============================================================ */
        .approval-card{display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:1.1rem 1.3rem;border-bottom:1px solid var(--ay-border-soft);transition:.15s}
        .approval-card:last-child{border-bottom:none}
        .approval-card:hover{background:var(--ay-row-hover)}
        .approval-icon{width:46px;height:46px;border-radius:12px;background:rgba(26,110,245,.1);color:#1a6ef5;display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0}
        .approval-title{font-size:.98rem;font-weight:700;color:var(--ay-text-strong)}
        .approval-sub{font-size:.83rem;color:var(--ay-text-muted);margin-top:2px}
        .step-badge{background:#fef3c7;color:#92400e;font-size:.72rem;font-weight:700;padding:3px 10px;border-radius:999px;display:inline-block}
        .step-label{font-size:.78rem;color:var(--ay-text-muted);font-weight:600;margin-left:8px}
        .approval-actions{display:flex;gap:.4rem;flex-shrink:0}

        @media(max-width:767.98px) {
            .ay-page-header {
                padding: 1.1rem 1.2rem;
                border-radius: 14px;
            }
            .ay-card-footer {
                justify-content: center;
            }
        }

        /* ============================================================
           Chain UI — Approval Timeline
           ============================================================ */
        .chain-section {
            background: #f8fbff;
            border: 1px solid #dce8f8;
            border-radius: 12px;
            padding: 1rem 1.2rem;
            margin-bottom: 1rem;
        }
        .chain-title {
            font-size: 0.9rem;
            font-weight: 800;
            color: #1248a8;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .chain-step {
            display: flex;
            gap: 0.85rem;
            position: relative;
            padding-bottom: 1.25rem;
        }
        .chain-step:last-child {
            padding-bottom: 0;
        }
        .chain-step::before {
            content: '';
            position: absolute;
            left: 14px;
            top: 32px;
            bottom: 0;
            width: 2px;
            background: #dce8f8;
        }
        .chain-step:last-child::before {
            display: none;
        }
        .chain-step.done::before {
            background: #a7f3d0;
        }
        .chain-step.current::before {
            background: linear-gradient(to bottom, #a7f3d0 20%, #dce8f8 20%);
        }

        .chain-icon {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1rem;
            flex-shrink: 0;
            position: relative;
            z-index: 2;
            background: #fff;
        }
        .chain-icon.chain-done {
            background: #d1fae5;
            color: #059669;
        }
        .chain-icon.chain-current {
            background: #dbeafe;
            color: #1248a8;
            animation: pulse-current 1.5s ease-in-out infinite;
        }
        .chain-icon.chain-pending {
            background: #f3f5f8;
            color: #c8d0d8;
        }
        @keyframes pulse-current {
            0%, 100% { box-shadow: 0 0 0 0 rgba(18,72,168,0.4); }
            50% { box-shadow: 0 0 0 6px rgba(18,72,168,0); }
        }

        .chain-content {
            flex: 1;
            padding-top: 0.15rem;
        }
        .chain-step-label {
            font-size: 0.85rem;
            font-weight: 800;
            color: #132f62;
            margin-bottom: 0.2rem;
        }
        .chain-step.pending .chain-step-label {
            color: #9ab0c8;
        }
        .chain-step.current .chain-step-label {
            color: #1248a8;
        }

        .chain-actor {
            font-size: 0.78rem;
            color: #3b5e96;
            margin-bottom: 0.15rem;
        }
        .chain-actor.pending-action {
            color: #9ab0c8;
            font-style: italic;
        }
        .chain-role {
            font-size: 0.72rem;
            color: #7a93b8;
        }

        .chain-date {
            font-size: 0.72rem;
            color: #7a93b8;
            margin-bottom: 0.15rem;
        }
        .chain-remarks {
            font-size: 0.75rem;
            color: #475569;
            background: #fff;
            border-left: 3px solid #b8d0fa;
            padding: 0.35rem 0.6rem;
            border-radius: 4px;
            margin-top: 0.3rem;
            font-style: italic;
        }

        .chain-doc-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            margin-top: 0.5rem;
            padding: 0.35rem 0.75rem;
            background: #fff;
            color: #1248a8;
            border: 1.5px solid #b8d0fa;
            border-radius: 6px;
            font-size: 0.72rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.15s;
        }
        .chain-doc-btn:hover {
            background: #eef4ff;
            border-color: #8db5f7;
            transform: translateY(-1px);
        }

        .chain-empty {
            text-align: center;
            padding: 1.5rem;
            color: #9ab0c8;
            font-style: italic;
            font-size: 0.82rem;
        }

        /* Dark mode */
        [data-bs-theme="dark"] .chain-section {
            background: #1f1f1f;
            border-color: #3a3a3a;
        }
        [data-bs-theme="dark"] .chain-title { color: #8ab4f8; }
        [data-bs-theme="dark"] .chain-step-label { color: #e4e6e8; }
        [data-bs-theme="dark"] .chain-actor { color: #a9b8cd; }
        [data-bs-theme="dark"] .chain-remarks {
            background: #2D2D2D;
            color: #ced4da;
        }
        [data-bs-theme="dark"] .chain-doc-btn {
            background: #2D2D2D;
            color: #8ab4f8;
            border-color: #4a5a6e;
        }
        [data-bs-theme="dark"] .chain-doc-btn:hover {
            background: #3a4a5e;
        }

        /* ============================================================
           VIEW MODAL — Drill-down Cards
           ============================================================ */
        /* Fixed modal size */
        #viewModal .modal-dialog {
            max-width: 900px;
        }
        #viewModal .modal-content {
            height: 80vh;                /* FIXED height */
            min-height: 80vh;
            max-height: 80vh;
            display: flex;
            flex-direction: column;
        }
        #viewModal .modal-body {
            flex: 1 1 auto;
            overflow-y: auto;
            min-height: 0;
        }
        #viewModal .modal-footer {
            flex-shrink: 0;
        }

        /* Modal content transition */
        .vm-body-inner {
            animation: vmFadeSlide 0.28s cubic-bezier(.22, 1, .36, 1) both;
        }
        @keyframes vmFadeSlide {
            from { opacity: 0; transform: translateX(12px); }
            to   { opacity: 1; transform: translateX(0); }
        }
        @keyframes vmFadeSlideBack {
            from { opacity: 0; transform: translateX(-12px); }
            to   { opacity: 1; transform: translateX(0); }
        }
        .vm-body-inner.vm-back {
            animation: vmFadeSlideBack 0.28s cubic-bezier(.22, 1, .36, 1) both;
        }

        /* Level 3 loading */
        .vm-loading {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 4rem 1rem;
            color: #7a93b8;
        }
        .vm-loading-spinner {
            width: 44px;
            height: 44px;
            border: 3px solid #e5eef8;
            border-top-color: #1248a8;
            border-radius: 50%;
            animation: vmSpin 0.8s linear infinite;
            margin-bottom: 1rem;
        }
        @keyframes vmSpin { to { transform: rotate(360deg); } }

        .vm-cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 0.85rem;
            padding: 0.25rem;
        }
        .vm-card {
            position: relative;
            background: #fff;
            border: 1.5px solid #dce8f8;
            border-radius: 14px;
            padding: 1.15rem 0.9rem 1rem;
            cursor: pointer;
            transition: all 0.2s cubic-bezier(.22, 1, .36, 1);
            text-align: center;
            overflow: hidden;
        }
        .vm-card::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(180deg, rgba(255,255,255,0) 60%, rgba(0,0,0,0.02) 100%);
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.2s;
        }
        .vm-card:hover::after { opacity: 1; }
        .vm-card:hover {
            border-color: #8db5f7;
            box-shadow: 0 4px 14px rgba(18,72,168,0.12);
            transform: translateY(-2px);
        }
        .vm-card:active {
            transform: translateY(0) scale(0.98);
        }
        .vm-card-checked-state {
            background: #f0fdf4;
            border-color: #a7f3d0;
        }
        .vm-card-icon {
            width: 48px;
            height: 48px;
            margin: 0 auto 0.55rem;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.35rem;
            transition: transform 0.2s;
            background: #eef4ff;
            color: #1248a8;
        }
        .vm-card:hover .vm-card-icon {
            transform: scale(1.08);
        }
        .vm-card-checked-state .vm-card-icon {
            background: #d1fae5;
            color: #059669;
        }
        .vm-card-title {
            font-size: 0.95rem;
            font-weight: 800;
            color: #132f62;
            margin-bottom: 0.2rem;
        }
        .vm-card-sub {
            font-size: 0.78rem;
            color: #7a93b8;
            margin-bottom: 0.35rem;
        }
        .vm-card-stat {
            font-size: 0.72rem;
            color: #9ab0c8;
            margin-top: 0.25rem;
        }
        .vm-card-checked {
            font-size: 0.7rem;
            color: #059669;
            font-weight: 700;
            margin-top: 0.35rem;
        }
        .vm-card-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            font-size: 0.68rem;
            font-weight: 700;
            letter-spacing: 0.02em;
            padding: 0.28rem 0.7rem;
            border-radius: 999px;
            margin-top: 0.5rem;
            transition: transform 0.15s;
        }
        .vm-card:hover .vm-card-badge {
            transform: scale(1.03);
        }
        .gs-modal-header, .modal-header {
            padding: 1rem 1.35rem;
        }
        .gs-modal-title, .modal-title {
            font-size: 1rem;
            font-weight: 800;
            letter-spacing: 0.01em;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .vm-card-badge.checked { background: #d1fae5; color: #059669; }
        .vm-card-badge.pending { background: #fef3c7; color: #b45309; }
        .vm-card-badge.processing { background: #e2e8f0; color: #64748b; }

        .vm-action-bar {
            display: flex;
            gap: 0.6rem;
            flex-wrap: wrap;
            margin-bottom: 0.5rem;
        }
        .vm-action-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            padding: 0.55rem 1rem;
            background: #fff;
            color: #1248a8;
            border: 1.5px solid #b8d0fa;
            border-radius: 8px;
            font-size: 0.8rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.15s;
        }
        .vm-action-btn:hover { background: #eef4ff; border-color: #8db5f7; }
        .vm-action-btn.checked {
            background: #d1fae5;
            color: #059669;
            border-color: #a7f3d0;
        }

        .vm-grade-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.82rem;
        }
        .vm-grade-table th {
            background: #1248a8;
            color: #fff;
            padding: 0.55rem 0.65rem;
            text-align: left;
            font-size: 0.72rem;
            text-transform: uppercase;
            letter-spacing: 0.03em;
        }
        .vm-grade-table td {
            padding: 0.5rem 0.65rem;
            border-bottom: 1px solid #eef2f7;
        }
        .vm-grade-table tr:hover td { background: #f8fbff; }
        .vm-grade-table .pass { color: #059669; font-weight: 700; }
        .vm-grade-table .fail { color: #dc2626; font-weight: 700; }

        .vm-empty {
            text-align: center;
            padding: 3rem 1rem;
            color: #9ab0c8;
            grid-column: 1 / -1;
        }
        .vm-empty i { font-size: 3rem; display: block; margin-bottom: 0.75rem; }

        [data-bs-theme="dark"] .vm-card { background: #1f1f1f; border-color: #3a3a3a; }
        [data-bs-theme="dark"] .vm-card-title { color: #e4e6e8; }
        [data-bs-theme="dark"] .vm-action-btn { background: #2D2D2D; color: #8ab4f8; border-color: #4a5a6e; }
    </style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <div class="app-wrapper">
        <?php require_once("includes/header.php"); ?>
        <?php require_once("includes/sidebar.php"); ?>
        <main class="app-main">
            <div class="app-content">
                <div class="container-fluid py-3">

                    <div class="ay-page-header">
                        <div>
                            <h3><i class="bi bi-inbox-fill me-2"></i>Grade Approvals</h3>
                            <p>Final review &amp; publication of grade submissions</p>
                        </div>
                        <div class="ay-active-chip"><i class="bi bi-shield-check"></i>
                            <?= htmlspecialchars($adminName) ?> · Registrar</div>
                    </div>
                    <?php require_once __DIR__ . '/includes/breadcrumb.php';
                    renderBreadcrumb([['label'=>'Home','href'=>'Dashboard.php','icon'=>'bi bi-house-door-fill'],['label'=>'Approvals','icon'=>'bi bi-inbox-fill']]); ?>

                    <div class="ay-card">
                        <div class="ay-card-header">
                            <div>
                                <p class="ay-card-title"><i class="bi bi-hourglass-split me-2"></i>Pending My Action</p>
                                <p class="ay-card-subtitle">Submissions waiting for final publication</p>
                            </div>
                        </div>
                        <div>
                            <?php if (empty($pending)): ?>
                                <div class="ay-empty"><i class="bi bi-inbox"></i><p>No pending approvals.</p></div>
                            <?php else: ?>
                                <?php foreach ($pending as $p): ?>
                                    <div class="approval-card">
                                        <div style="display:flex;align-items:center;gap:1rem;flex:1;min-width:0">
                                            <div class="approval-icon"><i class="bi bi-file-earmark-text"></i></div>
                                            <div style="flex:1;min-width:0">
                                                <div class="approval-title"><?= htmlspecialchars($p['subject_name']) ?> · <?= htmlspecialchars($p['section_name']) ?></div>
                                                <div class="approval-sub">Submitted by <?= htmlspecialchars($p['teacher_name'] ?? 'Teacher') ?> · <?= htmlspecialchars($termMap[(int)($p['term_id'] ?? 0)] ?? 'Term') ?></div>
                                                <!-- Step badge removed — reviewer knows their step -->
                                            </div>
                                        </div>
                                        <div class="approval-actions">
                                            <button class="btn-ay btn-ay-outline" onclick="viewSubmission(<?= (int)$p['instance_id'] ?>)"><i class="bi bi-eye"></i> View</button>
                                            <button class="btn-ay btn-ay-outline" style="color:#dc2626;border-color:#fecaca" onclick="rejectSubmission(<?= (int)$p['instance_id'] ?>)"><i class="bi bi-x-circle"></i> Return</button>
                                            <button class="btn-ay btn-ay-outline" onclick="alert('Document format not yet finalized. Coming soon.')"><i class="bi bi-file-earmark-check"></i> Approval Document</button>
                                            <button class="btn-ay btn-ay-success" onclick="approveSubmission(<?= (int)$p['instance_id'] ?>)"><i class="bi bi-check-circle-fill"></i> Publish</button>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <?php require_once("includes/footer.php"); ?>
    </div>

    <div class="modal fade" id="viewModal" tabindex="-1">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content" style="border-radius:16px;border:none;overflow:hidden">
                <div class="modal-header" style="background:linear-gradient(130deg,#1248a8,#1a6ef5);color:#fff;border:none">
                    <h5 class="modal-title" id="vmTitle"><i class="bi bi-file-earmark-text me-2"></i>Submission</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="vmBody" style="padding:1.25rem">
                    <div style="text-align:center;padding:2rem;color:var(--ay-text-muted)"><div class="spinner-border spinner-border-sm me-2"></div>Loading...</div>
                </div>
                <div class="modal-footer" style="background:#f8fbff;border-top:1px solid #dce8f8;">
                    <button type="button" class="btn-ay btn-ay-outline" id="vmBackBtn" onclick="vmBack()" style="display:none;">
                        <i class="bi bi-arrow-left"></i> Back
                    </button>
                    <button type="button" class="btn-ay btn-ay-outline" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>
    <script src="./js/adminlte.js"></script>
    <script>
        let viewModalInstance = null;
        function escapeHtml(s) {
            return String(s ?? '').replace(/[&<>"']/g, c => ({
                '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
            }[c]));
        }
        function toast(msg, type) {
            iziToast.show({title: type === 'success' ? 'Success' : type === 'danger' ? 'Error' : 'Info',
                message: msg, color: type === 'success' ? 'green' : type === 'danger' ? 'red' : 'blue',
                position: 'topRight', timeout: 5000, progressBar: true});
        }
        // (drill-down view functions defined below)
        // ============================================================
        // View Modal — Drill-down hierarchy (Grade Level → Section → Grades)
        // ============================================================
        window._allGradeLevels = <?= json_encode(array_map(function($g) {
            return ['id' => (int)$g['id'], 'name' => (string)$g['grade_level_name']];
        }, $allGradeLevels)) ?>;
        window._sectionsByGL = <?= json_encode($sectionsByGL) ?>;
        window._pendingBySection = <?= json_encode($pendingBySection) ?>;

        let _vmLevel = 1;
        let _vmBackDir = 'fwd';
        let _vmCurrentGL = 0;
        let _vmCurrentSection = null;
        let _vmChecks = {};
        window._lastVmData = null;

        function vmKey(sectionId, subjectId, termId, yearId) {
            return sectionId + '_' + subjectId + '_' + (termId || 0) + '_' + yearId;
        }

        function viewSubmission(instanceId) {
            _vmLevel = 1;
            _vmCurrentGL = 0;
            _vmCurrentSection = null;
            openViewModal();
        }

        function openViewModal() {
            let modalEl = document.getElementById('viewModal');
            if (!modalEl) {
                document.body.insertAdjacentHTML('beforeend', '<div class="modal fade" id="viewModal" tabindex="-1"><div class="modal-dialog modal-xl modal-dialog-scrollable"><div class="modal-content" style="border-radius:14px;overflow:hidden;"><div class="modal-header" style="background:linear-gradient(135deg,#1248a8,#1a6ef5);color:#fff;border:none;"><h5 class="modal-title" id="vmTitle"><i class="bi bi-folder2-open me-2"></i>Review Submissions</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div><div class="modal-body" id="vmBody" style="min-height:400px;"></div><div class="modal-footer" style="background:#f8fbff;border-top:1px solid #dce8f8;"><button type="button" class="btn-ay btn-ay-outline" id="vmBackBtn" onclick="vmBack()" style="display:none;"><i class="bi bi-arrow-left"></i> Back</button><button type="button" class="btn-ay btn-ay-outline" data-bs-dismiss="modal">Close</button></div></div></div></div>');
                modalEl = document.getElementById('viewModal');
            }
            loadChecks().then(() => {
                renderVmLevel();
                if (typeof bootstrap !== 'undefined') {
                    bootstrap.Modal.getOrCreateInstance(modalEl).show();
                }
            });
        }

        async function loadChecks() {
            try {
                const yearId = <?= (int)$activeYearId ?>;
                const res = await fetch('api/workflow/get_checks.php?academic_year_id=' + yearId).then(r => r.json());
                if (res.success && Array.isArray(res.checks)) {
                    _vmChecks = {};
                    res.checks.forEach(c => {
                        _vmChecks[vmKey(c.section_id, c.subject_id, c.term_id, c.academic_year_id)] = true;
                    });
                }
            } catch (e) { console.warn('loadChecks failed', e); }
        }

        function vmBack() {
            _vmBackDir = 'back';
            if (_vmLevel === 3) { _vmLevel = 2; }
            else if (_vmLevel === 2) { _vmLevel = 1; _vmCurrentGL = 0; }
            renderVmLevel();
        }

        function renderVmLevel() {
            const body = document.getElementById('vmBody');
            const backBtn = document.getElementById('vmBackBtn');
            const title = document.getElementById('vmTitle');
            if (backBtn) backBtn.style.display = _vmLevel > 1 ? 'inline-flex' : 'none';

            if (_vmLevel === 1) {
                title.innerHTML = '<i class="bi bi-diagram-3-fill me-2"></i>Select Grade Level';

                // Count pending + checked per grade level
                const pendingByGL = {};
                const checkedByGL = {};
                Object.keys(window._pendingBySection || {}).forEach(sid => {
                    const list = window._pendingBySection[sid];
                    list.forEach(it => {
                        let gid = 0;
                        Object.keys(window._sectionsByGL || {}).forEach(g => {
                            if ((window._sectionsByGL[g] || []).some(s => s.id === Number(sid))) {
                                gid = Number(g);
                            }
                        });
                        if (!gid) return;
                        const key = vmKey(sid, it.subject_id, it.term_id, it.academic_year_id);
                        if (_vmChecks[key]) {
                            checkedByGL[gid] = (checkedByGL[gid] || 0) + 1;
                        } else {
                            pendingByGL[gid] = (pendingByGL[gid] || 0) + 1;
                        }
                    });
                });

                let html = '<div class="vm-cards-grid">';
                (window._allGradeLevels || []).forEach(gl => {
                    const gid = gl.id;
                    const secCount = (window._sectionsByGL[gid] || []).length;
                    const pCount = pendingByGL[gid] || 0;
                    const cCount = checkedByGL[gid] || 0;

                    html += '<div class="vm-card" onclick="vmOpenGradeLevel(' + gid + ')">'
                        + '<div class="vm-card-icon"><i class="bi bi-mortarboard-fill"></i></div>'
                        + '<div class="vm-card-title">' + escapeHtml(gl.name) + '</div>'
                        + '<div class="vm-card-stat">' + secCount + ' section' + (secCount !== 1 ? 's' : '') + '</div>'
                        + (pCount > 0 ? '<div class="vm-card-badge pending"><i class="bi bi-hourglass-split"></i> ' + pCount + ' pending</div>' : '')
                        + (cCount > 0 ? '<div class="vm-card-checked"><i class="bi bi-check-circle-fill"></i> ' + cCount + ' checked</div>' : '')
                        + '</div>';
                });
                if (!(window._allGradeLevels || []).length) {
                    html += '<div class="vm-empty"><i class="bi bi-inbox"></i><p>No grade levels configured.</p></div>';
                }
                html += '</div>';
                body.innerHTML = '<div class="vm-body-inner' + (_vmBackDir === 'back' ? ' vm-back' : '') + '">' + html + '</div>';
            } else if (_vmLevel === 2) {
                const gl = (window._allGradeLevels || []).find(g => g.id === _vmCurrentGL);
                const glName = gl ? gl.name : ('Grade Level ' + _vmCurrentGL);
                title.innerHTML = '<i class="bi bi-people-fill me-2"></i>' + escapeHtml(glName) + ' — Sections';
                const sections = (window._sectionsByGL[_vmCurrentGL] || []);

                let html = '<div class="vm-cards-grid">';
                sections.forEach(sec => {
                    const pendList = window._pendingBySection[sec.id] || [];
                    const hasPending = pendList.length > 0;
                    const anyChecked = hasPending && pendList.some(it =>
                        _vmChecks[vmKey(sec.id, it.subject_id, it.term_id, it.academic_year_id)]
                    );

                    let badge;
                    if (!hasPending) {
                        badge = '<div class="vm-card-badge processing"><i class="bi bi-hourglass"></i> Processing</div>';
                    } else if (anyChecked) {
                        badge = '<div class="vm-card-badge checked"><i class="bi bi-check-circle-fill"></i> Checked</div>';
                    } else {
                        badge = '<div class="vm-card-badge pending"><i class="bi bi-hourglass-split"></i> Pending Review</div>';
                    }

                    const subjText = hasPending
                        ? pendList.map(p => p.subject_name).join(', ')
                        : 'No submission yet';

                    html += '<div class="vm-card ' + (anyChecked ? 'vm-card-checked-state' : '') + '"'
                        + ' onclick="vmOpenSection(' + sec.id + ')">'
                        + '<div class="vm-card-icon"><i class="bi bi-book-fill"></i></div>'
                        + '<div class="vm-card-title">' + escapeHtml(sec.section_name) + '</div>'
                        + '<div class="vm-card-sub">' + escapeHtml(subjText) + '</div>'
                        + badge
                        + '</div>';
                });
                if (!sections.length) {
                    html += '<div class="vm-empty"><i class="bi bi-inbox"></i><p>No sections in this grade level.</p></div>';
                }
                html += '</div>';
                body.innerHTML = '<div class="vm-body-inner' + (_vmBackDir === 'back' ? ' vm-back' : '') + '">' + html + '</div>';
            } else if (_vmLevel === 3 && _vmCurrentSection) {
                title.innerHTML = '<i class="bi bi-table me-2"></i>' + escapeHtml(_vmCurrentSection.section_name) + ' — ' + escapeHtml(_vmCurrentSection.subject_name || '');
                body.innerHTML = '<div class="vm-loading"><div class="vm-loading-spinner"></div><p>Loading grades...</p></div>';
                loadSectionGrades(_vmCurrentSection);
            }
        }

        function vmOpenGradeLevel(glId) { _vmBackDir = 'fwd'; _vmCurrentGL = Number(glId); _vmLevel = 2; renderVmLevel(); }

        function vmOpenSection(sectionId) {
            const pendList = window._pendingBySection[sectionId] || [];
            let secName = '';
            Object.keys(window._sectionsByGL || {}).forEach(g => {
                (window._sectionsByGL[g] || []).forEach(s => {
                    if (s.id === sectionId) secName = s.section_name;
                });
            });

            if (!pendList.length) {
                const body = document.getElementById('vmBody');
                document.getElementById('vmTitle').innerHTML =
                    '<i class="bi bi-hourglass-split me-2"></i>' + escapeHtml(secName);
                body.innerHTML = '<div class="vm-empty">'
                    + '<i class="bi bi-hourglass-split"></i>'
                    + '<p style="font-weight:700;color:#b45309;">Processing</p>'
                    + '<p style="font-size:.85rem;">This section has no submission yet. Waiting for the teacher to submit.</p>'
                    + '</div>';
                _vmLevel = 3;
                _vmBackDir = 'fwd';
                _vmCurrentSection = { section_name: secName, subject_name: '' };
                const bb = document.getElementById('vmBackBtn');
                if (bb) bb.style.display = 'inline-flex';
                return;
            }

            const first = pendList[0];
            _vmCurrentSection = {
                section_id:       sectionId,
                instance_id:      first.instance_id,
                subject_id:       first.subject_id,
                subject_name:     first.subject_name,
                subject_code:     first.subject_code,
                term_id:          first.term_id,
                academic_year_id: first.academic_year_id,
                teacher_name:       first.teacher_name,
                allow_mark_checked: first.allow_mark_checked,
                section_name:     secName
            };
            _vmBackDir = 'fwd';
            _vmLevel = 3;
            renderVmLevel();
        }

        async function loadSectionGrades(item) {
            try {
                const res = await fetch('api/workflow/admin_get_submission.php?id=' + item.instance_id).then(r => r.json());
                if (!res.success) {
                    document.getElementById('vmBody').innerHTML = '<div class="alert alert-danger">Failed to load grades: ' + escapeHtml(res.error || res.message || 'Unknown error') + '</div>';
                    return;
                }
                const isChecked = !!_vmChecks[vmKey(item.section_id, item.subject_id, item.term_id, item.academic_year_id)];
                let html = '';
                html += '<div class="vm-action-bar">';
                html += '<button class="vm-action-btn" onclick="vmExportCSV()"><i class="bi bi-file-earmark-excel"></i> Export CSV</button>';
                if (item.allow_mark_checked) html += '<button class="vm-action-btn ' + (isChecked ? 'checked' : '') + '" onclick="vmToggleCheck(' + item.section_id + ', ' + item.subject_id + ', ' + (item.term_id || 0) + ', ' + item.academic_year_id + ', ' + (isChecked ? 'false' : 'true') + ')">'
                    + '<i class="bi ' + (isChecked ? 'bi-check-circle-fill' : 'bi-check-circle') + '"></i> ' + (isChecked ? 'Checked' : 'Mark as Checked')
                    + '</button>';
                html += '</div>';

                html += '<div style="overflow-x:auto;margin-top:1rem;"><table class="vm-grade-table">';
                html += '<thead><tr><th>#</th><th>Student Name</th><th>LRN</th><th>WW</th><th>PT</th><th>QA</th><th>Initial</th><th>Final</th><th>Remarks</th></tr></thead><tbody>';
                (res.students || []).forEach((s, i) => {
                    const remRaw = String(s.remarks || '').toLowerCase();
                    const remClass = remRaw.includes('pass') ? 'pass' : (remRaw.includes('fail') ? 'fail' : '');
                    html += '<tr>'
                        + '<td>' + (i + 1) + '</td>'
                        + '<td>' + escapeHtml(s.name || '') + '</td>'
                        + '<td>' + escapeHtml(s.lrn || '') + '</td>'
                        + '<td>' + escapeHtml(s.ww != null ? s.ww : '—') + '</td>'
                        + '<td>' + escapeHtml(s.pt != null ? s.pt : '—') + '</td>'
                        + '<td>' + escapeHtml(s.qa != null ? s.qa : '—') + '</td>'
                        + '<td>' + escapeHtml(s.initial != null ? s.initial : '—') + '</td>'
                        + '<td><strong>' + escapeHtml(s.final != null ? s.final : '—') + '</strong></td>'
                        + '<td class="' + remClass + '">' + escapeHtml(s.remarks || '—') + '</td>'
                        + '</tr>';
                });
                if (!res.students || res.students.length === 0) {
                    html += '<tr><td colspan="9" class="text-center py-4 text-muted">No students found.</td></tr>';
                }
                html += '</tbody></table></div>';
                document.getElementById('vmBody').innerHTML = html;
                window._lastVmData = res;
            } catch (e) {
                document.getElementById('vmBody').innerHTML = '<div class="alert alert-danger">Error: ' + escapeHtml(e.message) + '</div>';
            }
        }

        async function vmToggleCheck(sectionId, subjectId, termId, yearId, checked) {
            try {
                const res = await fetch('api/workflow/toggle_check.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ section_id: sectionId, subject_id: subjectId, term_id: termId, academic_year_id: yearId, checked: checked })
                }).then(r => r.json());
                if (res.success) {
                    const key = vmKey(sectionId, subjectId, termId, yearId);
                    if (checked) { _vmChecks[key] = true; } else { delete _vmChecks[key]; }
                    loadSectionGrades(_vmCurrentSection);
                } else {
                    alert(res.error || 'Failed to update check status');
                }
            } catch (e) { alert('Error: ' + e.message); }
        }

        function vmExportCSV() {
            const d = window._lastVmData;
            if (!d || !d.students || !d.students.length) { alert('No grade data to export'); return; }
            const esc = v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
            let csv = 'No.,Student Name,LRN,WW,PT,QA,Initial,Final,Remarks\n';
            d.students.forEach((s, i) => {
                csv += [i + 1, esc(s.name), esc(s.lrn), esc(s.ww), esc(s.pt), esc(s.qa), esc(s.initial), esc(s.final), esc(s.remarks)].join(',') + '\n';
            });
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            const sec = _vmCurrentSection || {};
            a.href = url;
            a.download = ('grades_' + (sec.section_name || 'section') + '_' + (sec.subject_code || '') + '_' + (sec.term_id || '') + '.csv').replace(/\s/g, '_');
            document.body.appendChild(a); a.click(); document.body.removeChild(a);
            setTimeout(() => URL.revokeObjectURL(url), 1000);
        }

        async function approveSubmission(id){
            if (!confirm('Publish this submission? Grades will be finalized.')) return;
            await postAdvance(id, 'APPROVED', '');
        }
        async function rejectSubmission(id){
            const remarks = prompt('Reason for returning:');
            if (!remarks) return;
            await postAdvance(id, 'REJECTED', remarks);
        }
        async function postAdvance(id, action, remarks){
            try {
                const r = await fetch('api/workflow/admin_advance.php', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({instance_id:id, action:action, remarks:remarks})});
                const d = await r.json();
                if (d.success) { toast(d.message||'Done','success'); setTimeout(()=>location.reload(),1200); }
                else { toast(d.message||'Failed','danger'); }
            } catch(e) { toast('Network error','danger'); }
        }
        /* printApprovalDocument() removed — will be re-implemented in chain view */
    </script>
</body>

</html>
