<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/api/shared/db_connect.php';

// â”€â”€ Active counts for header â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
$totalArchivedCount = 0;
try {
    $stmtTeachers = $pdo->query("SELECT COUNT(*) FROM tblTeacher WHERE is_archived = 1");
    $totalArchivedCount += (int) ($stmtTeachers ? $stmtTeachers->fetchColumn() : 0);
} catch (Throwable $e) {}

try {
    $stmtStudents = $pdo->query("SELECT COUNT(*) FROM tblStudentInfo WHERE is_archived = 1");
    $totalArchivedCount += (int) ($stmtStudents ? $stmtStudents->fetchColumn() : 0);
} catch (Throwable $e) {}

// Which tab to open by default
$defaultTab = isset($_GET['tab']) && $_GET['tab'] === 'archive' ? 'archive' : 'accounts';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Account & Archive Management</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        body { background: #f3f7fd; }

        /* â”€â”€ Page Header â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
        .am-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }
        .am-page-header h3 {
            font-size: 1.25rem; font-weight: 700; margin: 0 0 0.2rem;
            letter-spacing: 0.01em;
        }
        .am-page-header p { margin: 0; font-size: 0.88rem; opacity: 0.85; }

        .am-chip {
            display: inline-flex; align-items: center; gap: 0.45rem;
            background: rgba(255,255,255,0.15);
            border: 1.5px solid rgba(255,255,255,0.3);
            border-radius: 999px; padding: 0.45rem 1rem;
            font-size: 0.88rem; font-weight: 700; color: #fff; white-space: nowrap;
        }
        .am-chip i { font-size: 0.9rem; opacity: 0.9; }

        /* â”€â”€ Tabs â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
        .am-tabs {
            border-bottom: 1px solid #e8f0fb;
            display: flex; gap: 0.2rem;
            padding: 0.2rem 1rem 0;
            background: #fff;
            margin-bottom: 0;
        }
        .am-tab-btn {
            padding: 0.85rem 1rem;
            font-size: 0.88rem; font-weight: 700;
            color: #6b84a2; border: none; background: none; cursor: pointer;
            border-bottom: 3px solid transparent;
            transition: color 0.13s, border-color 0.13s;
            display: inline-flex; align-items: center; gap: 0.45rem;
        }
        .am-tab-btn:hover:not(.active) { color: #1248a8; }
        .am-tab-btn.active { color: #1a6ef5; border-bottom-color: #1a6ef5; }

        /* â”€â”€ Shared Card â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
        .am-card {
            background: #fff; border: 1px solid #dce8f8;
            border-radius: 16px; box-shadow: 0 2px 12px rgba(18,72,168,0.06);
            overflow: hidden; margin-bottom: 1.5rem;
        }
        .am-card-header {
            padding: 1.1rem 1.4rem; border-bottom: 1px solid #e8f0fb;
            display: flex; flex-wrap: wrap; align-items: center;
            justify-content: space-between; gap: 0.75rem; background: #fff;
        }
        .am-card-title   { font-size: 1rem; font-weight: 700; color: #132f62; margin: 0 0 0.15rem; }
        .am-card-subtitle { font-size: 0.8rem; color: #7a93b8; margin: 0; }
        .am-card-body    { padding: 0; }
        .am-card-footer  { padding: 0.75rem 1.2rem; border-top: 1px solid #e8f0fb; background: #fafcff; }

        /* â”€â”€ Buttons â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
        .btn-am {
            font-weight: 600; font-size: 0.82rem; border-radius: 8px;
            padding: 0.42rem 0.9rem; cursor: pointer;
            transition: all 0.15s;
            border: 1.5px solid transparent; line-height: 1.4;
            text-decoration: none; display: inline-flex;
            align-items: center; justify-content: center; gap: .35rem;
            white-space: nowrap;
        }
        .btn-am-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff; border-color: transparent;
            box-shadow: 0 2px 8px rgba(26,110,245,0.2);
        }
        .btn-am-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90); color: #fff;
            box-shadow: 0 3px 12px rgba(26,110,245,0.3);
        }
        .btn-am-info {
            background: #eef4ff; color: #1248a8; border-color: #cfe0fb;
        }
        .btn-am-info:hover { background: #dfeaff; color: #0f3d90; border-color: #b8d0fa; }
        .btn-am-danger {
            background: #fff0f1; color: #b42318; border-color: #f5b5ba;
        }
        .btn-am-danger:hover { background: #ffe2e4; color: #9a1e14; border-color: #eb8f97; }
        .btn-am-success {
            background: #e6f6ea; color: #16794b; border-color: #bfe8ce;
        }
        .btn-am-success:hover { background: #d7f0df; color: #12643e; border-color: #a6ddba; }
        .btn-am-light {
            background: #fff; color: #1248a8; border-color: #b8d0fa;
        }
        .btn-am-light:hover { background: #eef4ff; border-color: #8db5f7; color: #0f3d90; }
        .btn-am-activate   { background: #1a6ef5; color: #fff; border-color: #1a6ef5; }
        .btn-am-activate:hover { background: #1560d8; border-color: #1560d8; color: #fff; }
        .btn-am-delete {
            background: #fff; color: #d43f57; border-color: #f1c5cd;
        }
        .btn-am-delete:hover { background: #fff1f3; color: #b92f45; border-color: #e6a5b1; }
        .btn-am-sm { padding: 0.28rem 0.65rem; font-size: 0.78rem; }

        /* â”€â”€ Shared Table â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
        .am-table { width: 100%; border-collapse: collapse; margin: 0; }
        .am-table thead th {
            background: #f4f8ff; color: #3b5e96;
            font-size: 0.73rem; font-weight: 700;
            text-transform: uppercase; letter-spacing: 0.06em;
            padding: 0.85rem 1rem; border-bottom: 1.5px solid #dce8f8; white-space: nowrap;
        }
        .am-table tbody tr { transition: background 0.12s; }
        .am-table tbody tr:not(:last-child) td { border-bottom: 1px solid #f0f5fc; }
        .am-table tbody tr:hover td { background: #f7fbff; }
        .am-table tbody td {
            padding: 0.9rem 1rem; font-size: 0.92rem;
            color: #213a5e; vertical-align: middle;
        }
        .am-left { text-align: left !important; }

        /* â”€â”€ Badges â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
        .am-badge {
            display: inline-flex; align-items: center; gap: 0.3rem;
            padding: 0.32rem 0.75rem; border-radius: 999px;
            font-size: 0.78rem; font-weight: 700; letter-spacing: 0.03em;
        }
        .am-badge-primary { background: #eef4ff; color: #1248a8; border: 1.5px solid #cfe0fb; }
        .am-badge-success { background: #e6f6ea; color: #16794b; border: 1.5px solid #bfe8ce; }
        .am-badge-warning { background: #fff7e8; color: #9a6200; border: 1.5px solid #f6d28b; }
        .am-badge-neutral { background: #f3f5f8; color: #7a8ea8; border: 1.5px solid #dde4ee; }
        .am-badge-teacher { background: #e9f1ff; color: #1248a8; border-color: #bfd5fb; }
        .am-badge-student { background: #eefbf3; color: #1e8b55; border-color: #cbeed9; }

        /* â”€â”€ Pagination â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
        .am-pagination {
            display: flex; gap: 0.3rem; list-style: none;
            margin: 0; padding: 0; justify-content: flex-end;
        }
        .am-pagination .am-page-item .am-page-link {
            display: inline-flex; align-items: center; justify-content: center;
            min-width: 32px; height: 32px; border-radius: 7px;
            font-size: 0.83rem; font-weight: 600; cursor: pointer;
            border: 1.5px solid #dce8f8; color: #1a6ef5; background: #fff;
            transition: all 0.13s; padding: 0 0.65rem; text-decoration: none;
        }
        .am-pagination .am-page-item .am-page-link:hover { background: #eef4ff; border-color: #9cc2fc; }
        .am-pagination .am-page-item.active .am-page-link {
            background: #1a6ef5; border-color: #1a6ef5; color: #fff;
        }
        .am-pagination .am-page-item.disabled .am-page-link {
            background: #f8fbff; border-color: #e2ebf8; color: #9ab0c8;
            cursor: not-allowed; pointer-events: none;
        }

        /* â”€â”€ Empty state â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
        .am-empty { text-align: center; padding: 2.5rem 1.5rem; color: #9ab0c8; }
        .am-empty i { font-size: 2.2rem; display: block; margin-bottom: 0.6rem; opacity: 0.5; }
        .am-empty p { margin: 0; font-size: 0.95rem; }

        /* â”€â”€ Filter bar (Archive tab) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
        .am-filter-bar {
            padding: 1rem 1.2rem;
            display: flex; flex-wrap: wrap; align-items: end; gap: 0.9rem;
            background: #fff;
        }
        .am-filter-group {
            display: flex; flex-direction: column; gap: 0.4rem;
            min-width: 180px; flex: 1 1 220px;
        }
        .am-filter-group.search-group { flex: 2 1 320px; }
        .am-filter-label {
            font-size: 0.78rem; font-weight: 700; color: #3b5e96;
            text-transform: uppercase; letter-spacing: 0.05em;
        }
        .am-filter-control {
            border-radius: 10px; border: 1.5px solid #c8daf8;
            min-height: 42px; font-size: 0.9rem; color: #213a5e;
            padding: 0.45rem 0.85rem; background: #fff; outline: none;
            transition: border-color 0.15s, box-shadow 0.15s;
        }
        .am-filter-control:focus {
            border-color: #1a6ef5; box-shadow: 0 0 0 3px rgba(26,110,245,0.12);
        }

        /* â”€â”€ Archive-specific styles â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
        .archive-name { font-weight: 700; color: #132f62; margin-bottom: 0.1rem; }
        .archive-subtext { color: #7f96b8; font-size: 0.79rem; line-height: 1.35; }
        .archive-reason-badge {
            display: inline-flex; align-items: center; gap: 0.35rem;
            padding: 0.28rem 0.65rem; border-radius: 999px;
            font-size: 0.76rem; font-weight: 700; background: #f4f7fb;
            color: #6a84a9; border: 1.5px solid #e0e8f4; max-width: 240px;
        }
        .archive-reason-badge span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .archive-date { white-space: nowrap; font-weight: 600; color: #355787; }
        .archive-actions { display: flex; gap: 0.5rem; justify-content: center; flex-wrap: nowrap; }

        /* â”€â”€ Action wrap (Accounts tab) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
        .action-wrap {
            display: flex; justify-content: center; align-items: center;
            gap: .45rem; flex-wrap: nowrap;
        }

        /* â”€â”€ Mobile cards â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
        .am-mobile-card {
            background: #fff; border: 1.5px solid #dce8f8;
            border-radius: 14px; overflow: hidden;
            box-shadow: 0 1px 6px rgba(18,72,168,0.05);
        }
        .am-mobile-card + .am-mobile-card { margin-top: 0.75rem; }
        .am-mobile-card-header {
            display: flex; align-items: flex-start; justify-content: space-between;
            gap: 0.75rem; padding: 0.85rem 1rem;
            border-bottom: 1px solid #edf3fc; background: #f9fbff;
        }
        .am-mobile-card-title { font-weight: 700; color: #132f62; font-size: 0.95rem; }
        .am-mobile-card-body { padding: 0.95rem 1rem; }
        .am-mobile-meta { display: grid; gap: 0.55rem; margin-bottom: 0.9rem; }
        .am-mobile-meta-item { font-size: 0.84rem; color: #4f678d; line-height: 1.4; }
        .am-mobile-meta-item strong { color: #244675; }
        .am-mobile-actions { display: grid; gap: 0.55rem; }

        /* â”€â”€ Modal â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
        .am-modal .modal-content {
            border: 0; border-radius: 16px;
            box-shadow: 0 8px 32px rgba(18,72,168,0.16); overflow: hidden;
        }
        .am-modal .modal-header {
            background: #f4f8ff; border-bottom: 1px solid #dce8f8;
            padding: 1rem 1.25rem;
        }
        .am-modal .modal-title { font-size: 1rem; font-weight: 700; color: #132f62; }
        .am-modal .modal-body { background: #fff; padding: 1.2rem; }
        .am-modal .modal-footer {
            padding: 0.9rem 1.2rem; border-top: 1px solid #e8f0fb; background: #fafcff;
        }
        .am-modal .form-label { font-size: 0.82rem; font-weight: 700; color: #3b5e96; margin-bottom: 0.35rem; }
        .am-modal .form-control,
        .am-modal .form-select {
            border-radius: 10px; border: 1.5px solid #c8daf8;
            font-size: 0.9rem; color: #213a5e; min-height: 42px;
            padding: 0.42rem 0.85rem;
        }
        .am-view-grid {
            display: grid; grid-template-columns: repeat(2, minmax(0,1fr)); gap: 1rem;
        }
        .am-view-card {
            border: 1px solid #dce8f8; border-radius: 12px;
            background: #fff; padding: 0.95rem 1rem;
        }
        .am-view-label { color: #7a93b8; font-size: 0.76rem; font-weight: 700; margin-bottom: 0.35rem; text-transform: uppercase; letter-spacing: 0.05em; }
        .am-view-value { color: #132f62; font-size: 0.93rem; font-weight: 600; word-break: break-word; }

        /* â”€â”€ Footer note â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
        .am-footer-note { font-size: 0.82rem; color: #7a93b8; }

        @media (max-width:767px) {
            .am-page-header { padding: 1.1rem 1.2rem; border-radius: 14px; }
            .am-tabs { width: 100%; }
            .am-tab-btn { flex: 1; justify-content: center; }
            .am-view-grid { grid-template-columns: 1fr; }
            .action-wrap { flex-wrap: wrap; }
            .am-card-footer { justify-content: center; flex-wrap: wrap; }
            .am-pagination { justify-content: center; }
        }
    </style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3">

                <!-- Page Header -->
                <div class="am-page-header">
                    <div>
                        <h3><i class="bi bi-person-gear me-2"></i>Account & Archive Management</h3>
                        <p>Manage teacher accounts and view archived users</p>
                    </div>
                    <div class="d-flex gap-2 align-items-center flex-wrap">
                        <div class="am-chip" id="accountDirectoryChip">
                            <i class="bi <?= $defaultTab === 'archive' ? 'bi-archive-fill' : 'bi-person-badge' ?>" id="accountDirectoryIcon"></i>
                                <span id="accountDirectoryText"><?= $defaultTab === 'archive' ? 'Archive Directory' : 'Account Directory' ?></span>
                        </div>
                    </div>
                </div>

                <!-- Tabbed Card -->
                <div class="am-card">
                    <div class="am-tabs">
                        <button class="am-tab-btn <?= $defaultTab === 'accounts' ? 'active' : '' ?>" id="tab-accounts" onclick="switchTab('accounts')">
                            <i class="bi bi-diagram-3"></i> Manage Accounts
                        </button>
                        <button class="am-tab-btn <?= $defaultTab === 'archive' ? 'active' : '' ?>" id="tab-archive" onclick="switchTab('archive')">
                            <i class="bi bi-archive"></i> Archive
                        </button>
                    </div>

                <!-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
                     TAB: MANAGE ACCOUNTS
                â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• -->
                <div id="pane-accounts" <?= $defaultTab !== 'accounts' ? 'style="display:none"' : '' ?>>
                    <div class="am-card-header">
                        <div>
                            <p class="am-card-title">Account List</p>
                            <p class="am-card-subtitle">Showing teacher accounts only. Admin accounts are hidden.</p>
                        </div>
                        <button class="btn-am btn-am-primary" onclick="openAddModal()">
                            <i class="bi bi-plus-circle"></i> New Account
                        </button>
                    </div>
                    <div class="am-card-body">
                        <div class="d-none d-md-block">
                            <table class="am-table">
                                <thead>
                                    <tr>
                                        <th style="width:50px;">#</th>
                                        <th>Teacher ID</th>
                                        <th>Name</th>
                                        <th>Username</th>
                                        <th>Role</th>
                                        <th>Password Status</th>
                                        <th>Status</th>
                                        <th>Created</th>
                                        <th style="width:220px;">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="accountTableBody">
                                    <tr>
                                        <td colspan="9">
                                            <div class="am-empty">
                                                <i class="bi bi-hourglass-split"></i>
                                                <p>Loading accounts…</p>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="d-block d-md-none p-3" id="accountCardView"></div>
                    </div>
                    <div class="am-card-footer">
                        <div class="am-footer-note" id="accountCountText"></div>
                        <ul class="am-pagination" id="accountPagination"></ul>
                    </div>
                </div>

                <!-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
                     TAB: ARCHIVE
                â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• -->
                <div id="pane-archive" <?= $defaultTab !== 'archive' ? 'style="display:none"' : '' ?>>

                    <!-- Filter Bar -->
                    <div class="am-filter-bar">
                        <div class="am-filter-group">
                            <label for="roleFilter" class="am-filter-label">Role Filter</label>
                            <select id="roleFilter" class="am-filter-control">
                                <option value="all">All</option>
                                <option value="teacher">Teacher</option>
                                <option value="student">Student</option>
                            </select>
                        </div>
                        <div class="am-filter-group search-group">
                            <label for="searchInput" class="am-filter-label">Search</label>
                            <input type="text" id="searchInput" class="am-filter-control" placeholder="Search by name, email, LRN, or employee ID">
                        </div>
                        <div class="am-filter-group" style="flex: 0 0 auto; min-width: 140px;">
                            <label class="am-filter-label">&nbsp;</label>
                            <button type="button" class="btn-am btn-am-light w-100" id="clearFiltersBtn">
                                <i class="bi bi-x-circle me-1"></i> Clear
                            </button>
                        </div>
                    </div>

                    <div class="am-card-header" style="border-top:1px solid #e8f0fb;">
                        <div>
                            <p class="am-card-title">Archived Accounts</p>
                            <p class="am-card-subtitle">Only soft-deleted users appear here. Restore to reactivate.</p>
                        </div>
                    </div>
                    <div class="am-card-body">
                        <div class="d-none d-md-block">
                            <table class="am-table" id="archiveTable">
                                <thead>
                                    <tr>
                                        <th style="width:64px; text-align:center;">#</th>
                                        <th>Name</th>
                                        <th>Email / LRN</th>
                                        <th style="width:130px; text-align:center;">Role</th>
                                        <th style="width:180px; text-align:center;">Archived Date</th>
                                        <th style="width:180px; text-align:center;">Reason</th>
                                        <th style="width:220px; text-align:center;">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="tableBody">
                                    <tr>
                                        <td colspan="7">
                                            <div class="am-empty">
                                                <i class="bi bi-hourglass-split"></i>
                                                <p>Loading archived accounts...</p>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="d-block d-md-none p-3" id="cardView"></div>
                    </div>
                    <div class="am-card-footer">
                        <ul class="am-pagination" id="pagination"></ul>
                    </div>
                </div>

                </div><!-- /.am-card (outer tabbed card) -->

            </div>
        </div>
    </main>

    <?php require_once("includes/footer.php"); ?>
</div>

<!-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
     MODAL: Add Account (from Manage Accounts)
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• -->
<div class="modal fade am-modal" id="addAccountModal" tabindex="-1" data-bs-backdrop="false">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-person-plus me-2"></i>Create New Account</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="teacherDbIdInput">
                <div class="mb-3">
                    <label class="form-label">Select Teacher <span class="text-danger">*</span></label>
                    <select id="teacherIdInput" class="form-select" onchange="onTeacherSelect()">
                        <option value="">— Loading teachers… —</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Teacher Information</label>
                    <div class="row g-2">
                        <div class="col-md-6">
                            <input type="text" id="fnameInput" class="form-control" placeholder="First Name" readonly>
                        </div>
                        <div class="col-md-6">
                            <input type="text" id="lnameInput" class="form-control" placeholder="Last Name" readonly>
                        </div>
                        <div class="col-md-6">
                            <input type="text" id="dateHiredInput" class="form-control" placeholder="Date Hired" readonly>
                        </div>
                        <div class="col-md-6">
                            <input type="text" id="emailInput" class="form-control" placeholder="Email Address" readonly>
                        </div>
                    </div>
                </div>
                <div class="mb-1">
                    <label class="form-label">Generated Credentials</label>
                    <div class="row g-2">
                        <div class="col-12">
                            <input type="text" id="usernameInput" class="form-control" placeholder="Username will be auto-generated" readonly>
                        </div>
                    </div>
                    <div class="mt-2 text-muted" style="font-size:.82rem;">
                        <i class="bi bi-envelope me-1"></i>
                        The temporary password will be sent to the teacher's email upon account creation.
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-am btn-am-light" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn-am btn-am-primary" id="btnCreateAccount" onclick="createAccount()" disabled>
                    <i class="bi bi-check-circle me-1"></i> Save &amp; Send Email
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Success Modal -->
<div class="modal fade am-modal" id="successModal" tabindex="-1" data-bs-backdrop="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-check-circle-fill text-success me-2"></i>Account Created</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="am-view-card mb-3">
                    <div class="am-view-label">Username</div>
                    <div class="am-view-value" id="newUsername" style="font-family:monospace;">—</div>
                </div>
                <div id="successMessage" style="font-size:.87rem;color:#5a7299;">
                    <i class="bi bi-envelope-check me-1"></i> Temporary password sent via email.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-am btn-am-light" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- View Modal -->
<div class="modal fade am-modal" id="viewModal" tabindex="-1" data-bs-backdrop="false">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-person-circle me-2"></i>Account Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="viewModalBody">
                <div class="am-empty"><span class="spinner-border spinner-border-sm me-1"></span>Loading…</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-am btn-am-light" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="./js/sweet-alerts.js"></script>
<script>
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// SHARED HELPERS
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
function esc(v) {
    return String(v ?? '')
        .replace(/&/g,'&amp;')
        .replace(/</g,'&lt;')
        .replace(/>/g,'&gt;')
        .replace(/"/g,'&quot;')
        .replace(/'/g,'&#039;');
}

function showAlert(msg, type) {
    const map = {
        success: { title:'Success', color:'green', icon:'bi bi-check-circle-fill' },
        danger:  { title:'Error',   color:'red',    icon:'bi bi-exclamation-octagon-fill' },
        warning: { title:'Warning', color:'yellow', icon:'bi bi-exclamation-triangle-fill' },
        info:    { title:'Info',    color:'blue',   icon:'bi bi-info-circle-fill' }
    };
    const c = map[type] || map.success;
    iziToast.show({
        title: c.title, message: msg, color: c.color, icon: c.icon,
        iconColor: '#fff', theme: 'light', position: 'topRight',
        timeout: 4000, progressBar: true, close: true, pauseOnHover: true,
        transitionIn: 'fadeInDown', transitionOut: 'fadeOutUp'
    });
}

function confirmAction(msg, onYes) {
    iziToast.question({
        timeout: 20000, close: false, overlay: true, displayMode: 'once',
        zindex: 9999, title: 'Confirm', message: msg,
        position: 'center', color: 'blue',
        buttons: [
            ['<button><b>Yes</b></button>', function(instance, toast) {
                instance.hide({ transitionOut: 'fadeOut' }, toast);
                onYes();
            }, true],
            ['<button>No</button>', function(instance, toast) {
                instance.hide({ transitionOut: 'fadeOut' }, toast);
            }]
        ]
    });
}

async function apiCall(url, opts) {
    const response = await fetch(url, opts || {});
    const text = await response.text();
    try { return JSON.parse(text); }
    catch (e) { console.error('Bad JSON from', url, text); throw new Error('Invalid server response.'); }
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// TAB SWITCHING
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
function switchTab(name) {
    ['accounts', 'archive'].forEach(t => {
        document.getElementById(`tab-${t}`).classList.toggle('active', t === name);
        document.getElementById(`pane-${t}`).style.display = t === name ? '' : 'none';
    });
    updateAccountDirectoryLabel(name);
    if (name === 'accounts') fetchAccounts(1);
    if (name === 'archive') loadArchived();
}

function updateAccountDirectoryLabel(name) {
    const icon = document.getElementById('accountDirectoryIcon');
    const text = document.getElementById('accountDirectoryText');
    if (!icon || !text) return;

    const isArchive = name === 'archive';
    icon.className = isArchive ? 'bi bi-archive-fill' : 'bi bi-person-badge';
            text.textContent = isArchive ? 'Archive Directory' : 'Academic Year Directory';
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// ACCOUNTS TAB
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
let currentAccountPage = 1;
let totalAccounts = 0;
const rowsPerPage = 5;

function isAdminAccount(acc) {
    return Number(acc.role_id || 0) === 1 ||
           String(acc.role || '').toLowerCase() === 'admin' ||
           String(acc.username || '').toLowerCase() === 'admin';
}

function passwordStatusBadge(acc) {
    const v = String(acc.must_change_password ?? '');
    if (v === '1') return '<span class="am-badge am-badge-warning">Default Password</span>';
    if (v === '0') return '<span class="am-badge am-badge-success">Changed Password</span>';
    return '<span class="am-badge am-badge-neutral">Unknown</span>';
}

function updateAccountCount(page, listLength) {
    const countEl = document.getElementById('accountCountText');
    if (!countEl) return;
    if (totalAccounts === 0) {
        countEl.textContent = 'No accounts to display.';
        return;
    }
    const start = ((page - 1) * rowsPerPage) + 1;
    const end = start + listLength - 1;
    countEl.textContent = `Showing ${start}-${end} of ${totalAccounts} accounts`;
}

async function fetchAccounts(page = 1) {
    currentAccountPage = page;
    try {
        const json = await apiCall(`api/accounts/list.php?p=${page}`);
        const list = (json.data || json.accounts || []).filter(function(acc) {
            return !isAdminAccount(acc);
        });
        totalAccounts = Number(json.total || list.length || 0);
        const tbody = document.getElementById('accountTableBody');
        const cardView = document.getElementById('accountCardView');
        const pagination = document.getElementById('accountPagination');

        updateAccountCount(page, list.length);

        if (!list.length) {
            const empty = `<div class="am-empty"><i class="bi bi-people"></i><p>No teacher accounts found.</p></div>`;
            tbody.innerHTML = `<tr><td colspan="9">${empty}</td></tr>`;
            cardView.innerHTML = empty;
            pagination.innerHTML = '';
            return;
        }

        const offset = (page - 1) * rowsPerPage;

        tbody.innerHTML = list.map(function(acc, i) {
            const active = String(acc.status || 'Active').toLowerCase() === 'active';
            const statusText = String(acc.status || 'Active');
            return `
                <tr>
                    <td>${offset + i + 1}</td>
                    <td>${esc(acc.teacher_id || acc.reference_id || 'N/A')}</td>
                    <td class="am-left">${esc(acc.name || 'N/A')}</td>
                    <td>${esc(acc.username || '')}</td>
                    <td><span class="am-badge am-badge-primary">${esc(acc.role || 'Teacher')}</span></td>
                    <td>${passwordStatusBadge(acc)}</td>
                    <td><span class="am-badge ${active ? 'am-badge-success' : 'am-badge-warning'}">${esc(statusText)}</span></td>
                    <td style="font-size:.83rem;color:#6b84a2;">${esc(acc.created || acc.created_at || 'N/A')}</td>
                    <td>
                        <div class="action-wrap">
                            <button class="btn-am btn-am-info btn-am-sm" onclick="viewAccount(${Number(acc.id)})">
                                <i class="bi bi-eye"></i> View
                            </button>
                            <button class="btn-am ${active ? 'btn-am-danger' : 'btn-am-success'} btn-am-sm"
                                    onclick='toggleStatus(${Number(acc.id)}, ${JSON.stringify(statusText)})'>
                                <i class="bi ${active ? 'bi-person-dash' : 'bi-person-check'}"></i>
                                ${active ? 'Disable' : 'Enable'}
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');

        // Mobile cards for accounts
        cardView.innerHTML = list.map(function(acc, i) {
            const active = String(acc.status || 'Active').toLowerCase() === 'active';
            const statusText = String(acc.status || 'Active');
            return `
                <div class="am-mobile-card">
                    <div class="am-mobile-card-header">
                        <div>
                            <div class="am-mobile-card-title">${offset + i + 1}. ${esc(acc.name || 'N/A')}</div>
                            <div class="archive-subtext">${esc(acc.username || '')}</div>
                        </div>
                        <span class="am-badge ${active ? 'am-badge-success' : 'am-badge-warning'}">${esc(statusText)}</span>
                    </div>
                    <div class="am-mobile-card-body">
                        <div class="am-mobile-meta">
                            <div class="am-mobile-meta-item"><strong>Teacher ID:</strong> ${esc(acc.teacher_id || acc.reference_id || 'N/A')}</div>
                            <div class="am-mobile-meta-item"><strong>Role:</strong> ${esc(acc.role || 'Teacher')}</div>
                            <div class="am-mobile-meta-item"><strong>Password:</strong> ${passwordStatusBadge(acc)}</div>
                            <div class="am-mobile-meta-item"><strong>Created:</strong> ${esc(acc.created || acc.created_at || 'N/A')}</div>
                        </div>
                        <div class="am-mobile-actions">
                            <button class="btn-am btn-am-info w-100" onclick="viewAccount(${Number(acc.id)})">
                                <i class="bi bi-eye"></i> View
                            </button>
                            <button class="btn-am ${active ? 'btn-am-danger' : 'btn-am-success'} w-100"
                                    onclick='toggleStatus(${Number(acc.id)}, ${JSON.stringify(statusText)})'>
                                <i class="bi ${active ? 'bi-person-dash' : 'bi-person-check'}"></i>
                                ${active ? 'Disable' : 'Enable'}
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        const pages = Number(json.pages || 1);
        let paginationHtml = '';
        paginationHtml += `
            <li class="am-page-item ${page <= 1 ? 'disabled' : ''}">
                <a class="am-page-link" onclick="${page > 1 ? `fetchAccounts(${page - 1})` : 'return false;'}">Previous</a>
            </li>`;
        for (let n = 1; n <= pages; n++) {
            paginationHtml += `
                <li class="am-page-item ${n === page ? 'active' : ''}">
                    <a class="am-page-link" onclick="fetchAccounts(${n})">${n}</a>
                </li>`;
        }
        paginationHtml += `
            <li class="am-page-item ${page >= pages ? 'disabled' : ''}">
                <a class="am-page-link" onclick="${page < pages ? `fetchAccounts(${page + 1})` : 'return false;'}">Next</a>
            </li>`;
        pagination.innerHTML = paginationHtml;
    } catch (e) {
        document.getElementById('accountTableBody').innerHTML = `
            <tr><td colspan="9"><div class="am-empty"><i class="bi bi-exclamation-octagon"></i><p>${esc(e.message)}</p></div></td></tr>`;
        document.getElementById('accountCardView').innerHTML = `<div class="am-empty"><i class="bi bi-exclamation-octagon"></i><p>${esc(e.message)}</p></div>`;
        document.getElementById('accountPagination').innerHTML = '';
        document.getElementById('accountCountText').textContent = '';
    }
}

function toggleStatus(userId, current) {
    const newStatus = String(current).toLowerCase() === 'active' ? 'Inactive' : 'Active';
    confirmAction('Mark this account as <strong>' + newStatus + '</strong>?', async function() {
        try {
            const json = await apiCall('api/accounts/update.php', {
                method: 'POST', headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ id: userId, status: newStatus })
            });
            if (json.success !== false) {
                showAlert('Account marked as ' + newStatus + '.', 'success');
                fetchAccounts(currentAccountPage);
            } else {
                showAlert(json.error || 'Update failed.', 'danger');
            }
        } catch (e) { showAlert(e.message, 'danger'); }
    });
}

async function loadTeacherDropdown() {
    const sel = document.getElementById('teacherIdInput');
    sel.innerHTML = '<option value="">— Loading… —</option>';
    try {
        const json = await apiCall('api/teacher/ids.php');
        const teachers = json.teachers || [];
        if (!teachers.length) {
            sel.innerHTML = '<option value="">— No teachers found —</option>';
            return;
        }
        sel.innerHTML = '<option value="">— Select a Teacher —</option>';
        teachers.forEach(function(t) {
            const option = document.createElement('option');
            option.value = t.teacher_id || '';
            option.textContent = (t.teacher_id || '') + ' — ' + (t.full_name || '');
            option.dataset.dbId = t.id || '';
            option.dataset.teacherId = t.teacher_id || '';
            option.dataset.fname = t.fname || '';
            option.dataset.lname = t.lname || '';
            option.dataset.email = t.email || '';
            option.dataset.dateHired = t.date_hired || '';
            sel.appendChild(option);
        });
    } catch (e) {
        sel.innerHTML = '<option value="">— Error loading —</option>';
        showAlert('Failed to load teacher list.', 'danger');
    }
}

function buildUsername(lname, teacherId) {
    return String(lname || '').toLowerCase().replace(/ /g, '') +
           String(teacherId || '').toLowerCase().trim();
}

function clearTeacherFields() {
    document.getElementById('teacherDbIdInput').value = '';
    document.getElementById('fnameInput').value = '';
    document.getElementById('lnameInput').value = '';
    document.getElementById('dateHiredInput').value = '';
    document.getElementById('emailInput').value = '';
    document.getElementById('usernameInput').value = '';
    document.getElementById('btnCreateAccount').disabled = true;
}

function onTeacherSelect() {
    const sel = document.getElementById('teacherIdInput');
    const opt = sel.options[sel.selectedIndex];
    clearTeacherFields();
    if (!opt || !opt.value) return;
    const dbId = opt.dataset.dbId || '';
    const fname = opt.dataset.fname || '';
    const lname = opt.dataset.lname || '';
    const teacherId = opt.dataset.teacherId || '';
    const email = opt.dataset.email || '';
    const dateHired = opt.dataset.dateHired || '';
    document.getElementById('teacherDbIdInput').value = dbId;
    document.getElementById('fnameInput').value = fname;
    document.getElementById('lnameInput').value = lname;
    document.getElementById('dateHiredInput').value = dateHired;
    document.getElementById('emailInput').value = email;
    document.getElementById('usernameInput').value = buildUsername(lname, teacherId);
    if (dbId) { document.getElementById('btnCreateAccount').disabled = false; }
    else { showAlert('Could not get teacher DB ID.', 'warning'); }
}

function resetAddForm() {
    document.getElementById('teacherIdInput').value = '';
    clearTeacherFields();
}

function openAddModal() {
    resetAddForm();
    loadTeacherDropdown();
    bootstrap.Modal.getOrCreateInstance(document.getElementById('addAccountModal')).show();
}

async function createAccount() {
    const dbId = document.getElementById('teacherDbIdInput').value.trim();
    const username = document.getElementById('usernameInput').value.trim();
    if (!dbId) { showAlert('Please select a teacher first.', 'warning'); return; }
    const btn = document.getElementById('btnCreateAccount');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Creating…';
    try {
        const json = await apiCall('api/accounts/create.php', {
            method: 'POST', headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ teacher_db_id: parseInt(dbId, 10), username: username })
        });
        if (json.success !== false) {
            const modal = bootstrap.Modal.getInstance(document.getElementById('addAccountModal'));
            if (modal) modal.hide();
            document.getElementById('newUsername').textContent = json.username || username;
            document.getElementById('successMessage').innerHTML =
                '<i class="bi bi-envelope-check me-1"></i>' + esc(json.message || 'Temporary password sent via email.');
            bootstrap.Modal.getOrCreateInstance(document.getElementById('successModal')).show();
            showAlert('Account created successfully.', 'success');
            fetchAccounts(1);
            resetAddForm();
        } else { showAlert(json.error || 'Creation failed.', 'danger'); }
    } catch (e) { showAlert('Failed: ' + e.message, 'danger'); }
    finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-check-circle me-1"></i> Save &amp; Send Email';
    }
}

// âš¡ FIXED viewAccount – now accepts multiple response structures
async function viewAccount(userId) {
    const body = document.getElementById('viewModalBody');
    body.innerHTML = '<div class="am-empty"><span class="spinner-border spinner-border-sm me-1"></span>Loading…</div>';
    bootstrap.Modal.getOrCreateInstance(document.getElementById('viewModal')).show();

    try {
        const json = await apiCall('api/accounts/view.php?id=' + encodeURIComponent(userId));

        // Try to get the account object from various possible keys
        const account = json.data || json.account || json.user || json;

        // If it's just a string or still no data, show error
        if (!account || typeof account !== 'object' || Object.keys(account).length === 0) {
            body.innerHTML = '<div class="am-empty"><i class="bi bi-exclamation-circle"></i><p>Account not found or invalid response.</p></div>';
            return;
        }

        const active = String(account.status || 'Active').toLowerCase() === 'active';
        const pwStatus = String(account.must_change_password ?? '') === '1'
            ? '<span class="am-badge am-badge-warning">Still Default Password</span>'
            : String(account.must_change_password ?? '') === '0'
            ? '<span class="am-badge am-badge-success">Already Changed</span>'
            : '<span class="am-badge am-badge-neutral">Unknown</span>';

        body.innerHTML = `
            <div class="am-view-grid">
                <div class="am-view-card"><div class="am-view-label">User ID</div><div class="am-view-value">${esc(account.id)}</div></div>
                <div class="am-view-card"><div class="am-view-label">Teacher ID</div><div class="am-view-value">${esc(account.teacher_id || account.reference_id || 'N/A')}</div></div>
                <div class="am-view-card"><div class="am-view-label">Name</div><div class="am-view-value">${esc(account.name || 'N/A')}</div></div>
                <div class="am-view-card"><div class="am-view-label">Username</div><div class="am-view-value" style="font-family:monospace;">${esc(account.username || '')}</div></div>
                <div class="am-view-card"><div class="am-view-label">Role</div><div class="am-view-value"><span class="am-badge am-badge-primary">${esc(account.role || 'Teacher')}</span></div></div>
                <div class="am-view-card"><div class="am-view-label">Status</div><div class="am-view-value"><span class="am-badge ${active ? 'am-badge-success' : 'am-badge-warning'}">${esc(account.status || 'Active')}</span></div></div>
                <div class="am-view-card"><div class="am-view-label">Password Status</div><div class="am-view-value">${pwStatus}</div></div>
                <div class="am-view-card"><div class="am-view-label">Created</div><div class="am-view-value">${esc(account.created || account.created_at || 'N/A')}</div></div>
            </div>`;
    } catch (e) {
        body.innerHTML = '<div class="am-empty"><i class="bi bi-exclamation-circle"></i><p>' + esc(e.message) + '</p></div>';
        showAlert(e.message, 'danger');
    }
}

document.getElementById('addAccountModal').addEventListener('hidden.bs.modal', resetAddForm);

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// ARCHIVE TAB
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
let currentPage = 1;
let currentRole = 'all';
let currentSearch = '';
let searchDebounceTimer = null;

function updateArchiveCount(total = 0) {
    const countEl = document.getElementById('archiveCountText');
    if (countEl) countEl.textContent = Number(total) || 0;
}

function formatDate(value) {
    if (!value) return '—';
    const normalized = String(value).replace('T', ' ');
    return normalized.length >= 16 ? normalized.slice(0, 16) : normalized;
}

function getNormalizedAccount(item) {
    const role = String(item.role || item.user_type || '').toLowerCase();
    const firstName = item.first_name || item.firstname || '';
    const middleName = item.middle_name || item.middlename || '';
    const lastName = item.last_name || item.lastname || '';
    const fullName = item.full_name || item.name ||
        [firstName, middleName, lastName].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
    return {
        id: item.id || item.account_id || item.user_id || '',
        name: fullName || 'Unnamed Account',
        email: item.email || '',
        role: role === 'teacher' ? 'teacher' : (role === 'student' ? 'student' : ''),
        roleLabel: role === 'teacher' ? 'Teacher' : (role === 'student' ? 'Student' : '—'),
        lrn: item.lrn || item.student_lrn || '',
        employeeId: item.employee_id || item.employee_no || item.teacher_no || '',
        archivedAt: item.archived_at || item.date_archived || item.deleted_at || '',
        reason: item.archive_reason || item.reason || ''
    };
}

async function loadArchived(page = 1, role = currentRole, search = currentSearch) {
    currentPage = page; currentRole = role; currentSearch = search;
    const params = new URLSearchParams();
    params.set('page', page);
    if (role && role !== 'all') params.set('role', role);
    if (search && search.trim() !== '') params.set('search', search.trim());
    try {
        const data = await apiCall(`api/archive/read.php?${params.toString()}`);
        renderArchive(
            data.accounts || data.users || [],
            data.page || page,
            data.pages || 1,
            data.total_count ?? data.total ?? 0
        );
    } catch (error) { showAlert(error.message, 'danger'); }
}

function renderArchive(list, page, pages, totalCount = 0) {
    const tableBody = document.getElementById('tableBody');
    const cardView = document.getElementById('cardView');
    const pagination = document.getElementById('pagination');
    updateArchiveCount(totalCount);

    if (!Array.isArray(list) || !list.length) {
        const emptyHtml = `<div class="am-empty"><i class="bi bi-archive"></i><p>No archived accounts found.</p></div>`;
        tableBody.innerHTML = `<tr><td colspan="7">${emptyHtml}</td></tr>`;
        cardView.innerHTML = emptyHtml;
        pagination.innerHTML = '';
        return;
    }

    const offset = (page - 1) * 10;

    tableBody.innerHTML = list.map((rawItem, index) => {
        const item = getNormalizedAccount(rawItem);
        const roleBadgeClass = item.role === 'student' ? 'am-badge-student' : 'am-badge-teacher';
        const roleIcon = item.role === 'student' ? 'bi bi-mortarboard-fill' : 'bi bi-easel-fill';
        const identifierHtml = `
            <div>${esc(item.email || '—')}</div>
            <div class="archive-subtext">
                ${item.role === 'student'
                    ? `LRN: ${esc(item.lrn || '—')}`
                    : `Employee ID: ${esc(item.employeeId || '—')}`}
            </div>`;
        const reasonHtml = item.reason
            ? `<span class="archive-reason-badge" title="${esc(item.reason)}"><i class="bi bi-chat-left-text"></i><span>${esc(item.reason)}</span></span>`
            : `<span class="archive-subtext">—</span>`;
        return `
            <tr>
                <td style="text-align:center;"><span style="color:#a0b4cc; font-size:0.82rem; font-weight:600;">${offset + index + 1}</span></td>
                <td><div class="archive-name">${esc(item.name)}</div></td>
                <td>${identifierHtml}</td>
                <td style="text-align:center;">
                    <span class="am-badge ${roleBadgeClass}"><i class="${roleIcon}"></i> ${esc(item.roleLabel)}</span>
                </td>
                <td style="text-align:center;"><span class="archive-date">${esc(formatDate(item.archivedAt))}</span></td>
                <td style="text-align:center;">${reasonHtml}</td>
                <td style="text-align:center;">
                    <div class="archive-actions">
                        <button class="btn-am btn-am-activate" onclick="restoreUser('${esc(item.id)}', '${esc(item.role)}')">
                            <i class="bi bi-arrow-repeat me-1"></i> Restore
                        </button>
                        <button class="btn-am btn-am-delete" onclick="deleteUserPermanently('${esc(item.id)}', '${esc(item.role)}')">
                            <i class="bi bi-trash3 me-1"></i> Delete
                        </button>
                    </div>
                </td>
            </tr>`;
    }).join('');

    cardView.innerHTML = list.map((rawItem, index) => {
        const item = getNormalizedAccount(rawItem);
        const roleBadgeClass = item.role === 'student' ? 'am-badge-student' : 'am-badge-teacher';
        const roleIcon = item.role === 'student' ? 'bi bi-mortarboard-fill' : 'bi bi-easel-fill';
        return `
            <div class="am-mobile-card">
                <div class="am-mobile-card-header">
                    <div>
                        <div class="am-mobile-card-title">${offset + index + 1}. ${esc(item.name)}</div>
                        <div class="archive-subtext">${esc(item.email || '—')}</div>
                    </div>
                    <span class="am-badge ${roleBadgeClass}"><i class="${roleIcon}"></i> ${esc(item.roleLabel)}</span>
                </div>
                <div class="am-mobile-card-body">
                    <div class="am-mobile-meta">
                        <div class="am-mobile-meta-item"><strong>${item.role === 'student' ? 'LRN' : 'Employee ID'}:</strong> ${esc(item.role === 'student' ? (item.lrn || '—') : (item.employeeId || '—'))}</div>
                        <div class="am-mobile-meta-item"><strong>Archived Date:</strong> ${esc(formatDate(item.archivedAt))}</div>
                        <div class="am-mobile-meta-item"><strong>Reason:</strong> ${esc(item.reason || '—')}</div>
                    </div>
                    <div class="am-mobile-actions">
                        <button class="btn-am btn-am-activate w-100" onclick="restoreUser('${esc(item.id)}', '${esc(item.role)}')">
                            <i class="bi bi-arrow-repeat me-1"></i> Restore
                        </button>
                        <button class="btn-am btn-am-delete w-100" onclick="deleteUserPermanently('${esc(item.id)}', '${esc(item.role)}')">
                            <i class="bi bi-trash3 me-1"></i> Delete Permanently
                        </button>
                    </div>
                </div>
            </div>`;
    }).join('');

    pagination.innerHTML = Array.from({ length: pages }, (_, idx) => {
        const pageNumber = idx + 1;
        return `
            <li class="am-page-item ${pageNumber === page ? 'active' : ''}">
                <a class="am-page-link" onclick="loadArchived(${pageNumber}, currentRole, currentSearch)">${pageNumber}</a>
            </li>`;
    }).join('');
}

function restoreUser(id, role) {
    iziToast.question({
        timeout: 20000, close: false, overlay: true, displayMode: 'once',
        id: 'restore-account-confirm', zindex: 9999, title: 'Confirm Restore',
        message: 'Are you sure you want to restore this archived account?',
        position: 'center', color: 'blue', icon: 'bi bi-arrow-repeat',
        buttons: [
            ['<button><b>Yes</b></button>', async function (instance, toast) {
                instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');
                try {
                    const res = await apiCall('api/archive/restore.php', {
                        method: 'POST', headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id, role })
                    });
                    if (res.success) {
                        showAlert(res.message || 'Archived account restored successfully.', 'success');
                        loadArchived(currentPage, currentRole, currentSearch);
                    } else { showAlert(res.error || res.message || 'Restore failed.', 'danger'); }
                } catch (error) { showAlert(error.message, 'danger'); }
            }, true],
            ['<button>No</button>', function (instance, toast) {
                instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');
                showAlert('Restore cancelled.', 'info');
            }]
        ]
    });
}

function deleteUserPermanently(id, role) {
    iziToast.question({
        timeout: 25000, close: false, overlay: true, displayMode: 'once',
        id: 'delete-account-confirm', zindex: 9999, title: 'Permanent Delete',
        message: 'This action is irreversible. Are you sure you want to permanently delete this account?',
        position: 'center', color: 'red', icon: 'bi bi-exclamation-octagon-fill',
        buttons: [
            ['<button><b>Delete</b></button>', async function (instance, toast) {
                instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');
                try {
                    const res = await apiCall('api/archive/delete.php', {
                        method: 'POST', headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id, role })
                    });
                    if (res.success) {
                        showAlert(res.message || 'Archived account permanently deleted.', 'success');
                        loadArchived(currentPage, currentRole, currentSearch);
                    } else { showAlert(res.error || res.message || 'Delete failed.', 'danger'); }
                } catch (error) { showAlert(error.message, 'danger'); }
            }, true],
            ['<button>Cancel</button>', function (instance, toast) {
                instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');
                showAlert('Permanent delete cancelled.', 'info');
            }]
        ]
    });
}

document.getElementById('roleFilter').addEventListener('change', function () {
    currentRole = this.value;
    loadArchived(1, currentRole, currentSearch);
});

document.getElementById('searchInput').addEventListener('input', function () {
    const value = this.value;
    clearTimeout(searchDebounceTimer);
    searchDebounceTimer = setTimeout(() => {
        currentSearch = value.trim();
        loadArchived(1, currentRole, currentSearch);
    }, 500);
});

document.getElementById('clearFiltersBtn').addEventListener('click', function () {
    document.getElementById('roleFilter').value = 'all';
    document.getElementById('searchInput').value = '';
    currentRole = 'all'; currentSearch = '';
    loadArchived(1, currentRole, currentSearch);
});

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// INIT
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
const defaultTab = '<?= $defaultTab ?>';
if (defaultTab === 'archive') {
    loadArchived();
} else {
    fetchAccounts(1);
}
</script>
</body>
</html>
