<?php
require_once 'includes/auth.php';
requireAdmin();
require_once __DIR__ . '/api/shared/db_connect.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Manage Accounts</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">

    <style>
        body {
            background: #f3f7fd;
        }

        .ay-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }

        .ay-page-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 0.2rem;
        }

        .ay-page-header p {
            margin: 0;
            font-size: 0.88rem;
            opacity: 0.85;
        }

        .ay-active-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            background: rgba(255,255,255,0.15);
            border: 1.5px solid rgba(255,255,255,0.3);
            border-radius: 999px;
            padding: 0.45rem 1rem;
            font-size: 0.88rem;
            font-weight: 700;
            color: #fff;
            white-space: nowrap;
        }

        .ay-card {
            background: #fff;
            border: 1px solid #dce8f8;
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18,72,168,0.06);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }

        .ay-card-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid #e8f0fb;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
            background: #fff;
        }

        .ay-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: #132f62;
            margin: 0 0 0.15rem;
        }

        .ay-card-subtitle {
            font-size: 0.8rem;
            color: #7a93b8;
            margin: 0;
        }

        .ay-card-body {
            padding: 0;
        }

        .ay-card-footer {
            padding: 0.75rem 1.2rem;
            border-top: 1px solid #e8f0fb;
            background: #fafcff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 0.75rem;
            flex-wrap: wrap;
        }

        .ay-footer-note {
            font-size: 0.82rem;
            color: #7a93b8;
        }

        .btn-ay {
            font-weight: 600;
            font-size: 0.82rem;
            border-radius: 8px;
            padding: 0.42rem 0.9rem;
            cursor: pointer;
            transition: all 0.15s;
            border: 1.5px solid transparent;
            line-height: 1.4;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: .35rem;
            white-space: nowrap;
        }

        .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            border-color: transparent;
            box-shadow: 0 2px 8px rgba(26,110,245,0.2);
        }

        .btn-ay-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
        }

        .btn-ay-info {
            background: #eef4ff;
            color: #1248a8;
            border-color: #cfe0fb;
        }

        .btn-ay-info:hover {
            background: #dfeaff;
            color: #0f3d90;
            border-color: #b8d0fa;
        }

        .btn-ay-danger {
            background: #fff0f1;
            color: #b42318;
            border-color: #f5b5ba;
        }

        .btn-ay-danger:hover {
            background: #ffe2e4;
            color: #9a1e14;
            border-color: #eb8f97;
        }

        .btn-ay-success {
            background: #e6f6ea;
            color: #16794b;
            border-color: #bfe8ce;
        }

        .btn-ay-success:hover {
            background: #d7f0df;
            color: #12643e;
            border-color: #a6ddba;
        }

        .btn-ay-light {
            background: #fff;
            color: #1248a8;
            border-color: #b8d0fa;
        }

        .btn-ay-light:hover {
            background: #eef4ff;
            border-color: #8db5f7;
            color: #0f3d90;
        }

        .btn-ay-sm {
            padding: 0.28rem 0.65rem;
            font-size: 0.78rem;
        }

        .action-wrap {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: .45rem;
            flex-wrap: nowrap;
        }

        .ay-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
        }

        .ay-table thead th {
            background: #f4f8ff;
            color: #3b5e96;
            font-size: 0.73rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 0.85rem 1rem;
            border-bottom: 1.5px solid #dce8f8;
            white-space: nowrap;
            text-align: center;
        }

        .ay-table tbody tr:not(:last-child) td {
            border-bottom: 1px solid #f0f5fc;
        }

        .ay-table tbody tr:hover td {
            background: #f7fbff;
        }

        .ay-table tbody td {
            padding: 0.9rem 1rem;
            font-size: 0.92rem;
            color: #213a5e;
            vertical-align: middle;
            text-align: center;
        }

        .ay-left {
            text-align: left !important;
        }

        .ay-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.3rem 0.75rem;
            border-radius: 999px;
            font-size: 0.76rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }

        .ay-badge-primary {
            background: #eef4ff;
            color: #1248a8;
            border: 1.5px solid #cfe0fb;
        }

        .ay-badge-success {
            background: #e6f6ea;
            color: #16794b;
            border: 1.5px solid #bfe8ce;
        }

        .ay-badge-warning {
            background: #fff7e8;
            color: #9a6200;
            border: 1.5px solid #f6d28b;
        }

        .ay-badge-neutral {
            background: #f3f5f8;
            color: #7a8ea8;
            border: 1.5px solid #dde4ee;
        }

        .ay-pagination {
            display: flex;
            gap: 0.3rem;
            list-style: none;
            margin: 0;
            padding: 0;
            justify-content: flex-end;
            align-items: center;
            flex-wrap: wrap;
        }

        .ay-pagination .ay-page-item .ay-page-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
            border-radius: 7px;
            font-size: 0.83rem;
            font-weight: 600;
            cursor: pointer;
            border: 1.5px solid #dce8f8;
            color: #1a6ef5;
            background: #fff;
            transition: all 0.13s;
            padding: 0 0.65rem;
            text-decoration: none;
        }

        .ay-pagination .ay-page-item .ay-page-link:hover {
            background: #eef4ff;
            border-color: #9cc2fc;
        }

        .ay-pagination .ay-page-item.active .ay-page-link {
            background: #1a6ef5;
            border-color: #1a6ef5;
            color: #fff;
        }

        .ay-pagination .ay-page-item.disabled .ay-page-link {
            background: #f8fbff;
            border-color: #e2ebf8;
            color: #9ab0c8;
            cursor: not-allowed;
            pointer-events: none;
        }

        .ay-empty {
            text-align: center;
            padding: 2.4rem 1.5rem;
            color: #9ab0c8;
        }

        .ay-empty i {
            font-size: 2.2rem;
            display: block;
            margin-bottom: 0.6rem;
            opacity: 0.5;
        }

        .ay-empty p {
            margin: 0;
            font-size: 0.95rem;
        }

        .ay-modal .modal-content {
            border: 0;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(18,72,168,0.16);
            overflow: hidden;
        }

        .ay-modal .modal-header {
            background: #f4f8ff;
            border-bottom: 1px solid #dce8f8;
            padding: 1rem 1.25rem;
        }

        .ay-modal .modal-title {
            font-size: 1rem;
            font-weight: 700;
            color: #132f62;
        }

        .ay-modal .modal-body {
            background: #fff;
            padding: 1.2rem;
        }

        .ay-modal .modal-footer {
            padding: 0.9rem 1.2rem;
            border-top: 1px solid #e8f0fb;
            background: #fafcff;
        }

        .ay-modal .form-label {
            font-size: 0.82rem;
            font-weight: 700;
            color: #3b5e96;
            margin-bottom: 0.35rem;
        }

        .ay-modal .form-control,
        .ay-modal .form-select {
            border-radius: 10px;
            border: 1.5px solid #c8daf8;
            font-size: 0.9rem;
            color: #213a5e;
            min-height: 42px;
            padding: 0.42rem 0.85rem;
        }

        .ay-view-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0,1fr));
            gap: 1rem;
        }

        .ay-view-card {
            border: 1px solid #dce8f8;
            border-radius: 12px;
            background: #fff;
            padding: 0.95rem 1rem;
        }

        .ay-view-label {
            color: #7a93b8;
            font-size: 0.76rem;
            font-weight: 700;
            margin-bottom: 0.35rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .ay-view-value {
            color: #132f62;
            font-size: 0.93rem;
            font-weight: 600;
            word-break: break-word;
        }

        @media (max-width:767px) {
            .ay-page-header {
                padding: 1.1rem 1.2rem;
                border-radius: 14px;
            }

            .ay-view-grid {
                grid-template-columns: 1fr;
            }

            .action-wrap {
                flex-wrap: wrap;
            }

            .ay-card-footer {
                justify-content: center;
            }

            .ay-pagination {
                justify-content: center;
            }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3">

                <div class="ay-page-header">
                    <div>
                        <h3><i class="bi bi-diagram-3 me-2"></i>Manage Accounts</h3>
                        <p>Manage teacher account.</p>
                    </div>
                    <div class="ay-active-chip">
                        <i class="bi bi-person-badge"></i> Account Directory
                    </div>
                </div>

                <div class="ay-card">
                    <div class="ay-card-header">
                        <div>
                            <p class="ay-card-title">Account List</p>
                            <p class="ay-card-subtitle">Showing teacher accounts only. Admin accounts are hidden.</p>
                        </div>
                        <button class="btn-ay btn-ay-primary" onclick="openAddModal()">
                            <i class="bi bi-plus-circle"></i> New Account
                        </button>
                    </div>

                    <div class="ay-card-body">
                        <table class="ay-table">
                            <thead>
                                <tr>
                                    <th style="width:50px;">#</th>
                                    <th>Teacher ID</th>
                                    <th>Name</th>
                                    <th>Username</th>
                                    <th>Role</th>
                                    <th>Password Status</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                    <th style="width:220px;">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="accountTableBody">
                                <tr>
                                    <td colspan="9">
                                        <div class="ay-empty">
                                            <i class="bi bi-hourglass-split"></i>
                                            <p>Loading accounts…</p>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="ay-card-footer">
                        <div class="ay-footer-note" id="accountCountText"></div>
                        <ul class="ay-pagination" id="pagination"></ul>
                    </div>
                </div>

            </div>
        </div>
    </main>

    <?php require_once("includes/footer.php"); ?>
</div>

<div class="modal fade ay-modal" id="addAccountModal" tabindex="-1" data-bs-backdrop="false">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-person-plus me-2"></i>Create New Account</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <input type="hidden" id="teacherDbIdInput">

                <div class="mb-3">
                    <label class="form-label">Select Teacher <span class="text-danger">*</span></label>
                    <select id="teacherIdInput" class="form-select" onchange="onTeacherSelect()">
                        <option value="">— Loading teachers… —</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Teacher Information</label>

                    <div class="row g-2">
                        <div class="col-md-6">
                            <input type="text" id="fnameInput" class="form-control" placeholder="First Name" readonly>
                        </div>
                        <div class="col-md-6">
                            <input type="text" id="lnameInput" class="form-control" placeholder="Last Name" readonly>
                        </div>
                        <div class="col-md-6">
                            <input type="text" id="dateHiredInput" class="form-control" placeholder="Date Hired" readonly>
                        </div>
                        <div class="col-md-6">
                            <input type="text" id="emailInput" class="form-control" placeholder="Email Address" readonly>
                        </div>
                    </div>
                </div>

                <div class="mb-1">
                    <label class="form-label">Generated Credentials</label>

                    <div class="row g-2">
                        <div class="col-12">
                            <input type="text" id="usernameInput" class="form-control" placeholder="Username will be auto-generated" readonly>
                        </div>
                    </div>

                    <div class="mt-2 text-muted" style="font-size:.82rem;">
                        <i class="bi bi-envelope me-1"></i>
                        The temporary password will be sent to the teacher's email upon account creation.
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn-ay btn-ay-light" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn-ay btn-ay-primary" id="btnCreateAccount" onclick="createAccount()" disabled>
                    <i class="bi bi-check-circle me-1"></i> Save &amp; Send Email
                </button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade ay-modal" id="successModal" tabindex="-1" data-bs-backdrop="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-check-circle-fill text-success me-2"></i>Account Created</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="ay-view-card mb-3">
                    <div class="ay-view-label">Username</div>
                    <div class="ay-view-value" id="newUsername" style="font-family:monospace;">—</div>
                </div>
                <div id="successMessage" style="font-size:.87rem;color:#5a7299;">
                    <i class="bi bi-envelope-check me-1"></i> Temporary password sent via email.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-ay btn-ay-light" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade ay-modal" id="viewModal" tabindex="-1" data-bs-backdrop="false">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-person-circle me-2"></i>Account Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="viewModalBody">
                <div class="ay-empty"><span class="spinner-border spinner-border-sm me-1"></span>Loading…</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-ay btn-ay-light" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>

<script>
let currentPage = 1;
let totalAccounts = 0;
const rowsPerPage = 5;

function esc(v) {
    return String(v ?? '')
        .replace(/&/g,'&amp;')
        .replace(/</g,'&lt;')
        .replace(/>/g,'&gt;')
        .replace(/"/g,'&quot;')
        .replace(/'/g,'&#039;');
}

function showAlert(msg, type) {
    const map = {
        success: { title:'Success', color:'green', icon:'bi bi-check-circle-fill' },
        danger:  { title:'Error', color:'red', icon:'bi bi-exclamation-octagon-fill' },
        warning: { title:'Warning', color:'yellow', icon:'bi bi-exclamation-triangle-fill' },
        info:    { title:'Info', color:'blue', icon:'bi bi-info-circle-fill' }
    };

    const c = map[type] || map.success;

    iziToast.show({
        title: c.title,
        message: msg,
        color: c.color,
        icon: c.icon,
        iconColor: '#fff',
        theme: 'light',
        position: 'topRight',
        timeout: 4000,
        progressBar: true,
        close: true,
        pauseOnHover: true,
        transitionIn: 'fadeInDown',
        transitionOut: 'fadeOutUp'
    });
}

function confirmAction(msg, onYes) {
    iziToast.question({
        timeout: 20000,
        close: false,
        overlay: true,
        displayMode: 'once',
        zindex: 9999,
        title: 'Confirm',
        message: msg,
        position: 'center',
        color: 'blue',
        buttons: [
            ['<button><b>Yes</b></button>', function(instance, toast) {
                instance.hide({ transitionOut: 'fadeOut' }, toast);
                onYes();
            }, true],
            ['<button>No</button>', function(instance, toast) {
                instance.hide({ transitionOut: 'fadeOut' }, toast);
            }]
        ]
    });
}

async function apiCall(url, opts) {
    const response = await fetch(url, opts || {});
    const text = await response.text();

    try {
        return JSON.parse(text);
    } catch (e) {
        console.error('Bad JSON from', url, text);
        throw new Error('Invalid server response.');
    }
}

function isAdminAccount(acc) {
    return Number(acc.role_id || 0) === 1 ||
           String(acc.role || '').toLowerCase() === 'admin' ||
           String(acc.username || '').toLowerCase() === 'admin';
}

function passwordStatusBadge(acc) {
    const v = String(acc.must_change_password ?? '');
    if (v === '1') return '<span class="ay-badge ay-badge-warning">Default Password</span>';
    if (v === '0') return '<span class="ay-badge ay-badge-success">Changed Password</span>';
    return '<span class="ay-badge ay-badge-neutral">Unknown</span>';
}

function updateAccountCount(page, listLength) {
    const countEl = document.getElementById('accountCountText');

    if (!countEl) return;

    if (totalAccounts === 0) {
        countEl.textContent = 'No accounts to display.';
        return;
    }

    const start = ((page - 1) * rowsPerPage) + 1;
    const end = start + listLength - 1;

    countEl.textContent = `Showing ${start}-${end} of ${totalAccounts} accounts`;
}

async function fetchAccounts(page = 1) {
    currentPage = page;

    try {
        const json = await apiCall(`api/accounts/list.php?p=${page}`);
        const list = (json.data || json.accounts || []).filter(function(acc) {
            return !isAdminAccount(acc);
        });

        totalAccounts = Number(json.total || list.length || 0);

        const tbody = document.getElementById('accountTableBody');
        const pagination = document.getElementById('pagination');

        updateAccountCount(page, list.length);

        if (!list.length) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="9">
                        <div class="ay-empty">
                            <i class="bi bi-people"></i>
                            <p>No teacher accounts found.</p>
                        </div>
                    </td>
                </tr>
            `;
            pagination.innerHTML = '';
            return;
        }

        const offset = (page - 1) * rowsPerPage;

        tbody.innerHTML = list.map(function(acc, i) {
            const active = String(acc.status || 'Active').toLowerCase() === 'active';
            const statusText = String(acc.status || 'Active');

            return `
                <tr>
                    <td>${offset + i + 1}</td>
                    <td>${esc(acc.teacher_id || acc.reference_id || 'N/A')}</td>
                    <td class="ay-left">${esc(acc.name || 'N/A')}</td>
                    <td>${esc(acc.username || '')}</td>
                    <td><span class="ay-badge ay-badge-primary">${esc(acc.role || 'Teacher')}</span></td>
                    <td>${passwordStatusBadge(acc)}</td>
                    <td><span class="ay-badge ${active ? 'ay-badge-success' : 'ay-badge-warning'}">${esc(statusText)}</span></td>
                    <td style="font-size:.83rem;color:#6b84a2;">${esc(acc.created || acc.created_at || 'N/A')}</td>
                    <td>
                        <div class="action-wrap">
                            <button class="btn-ay btn-ay-info btn-ay-sm" onclick="viewAccount(${Number(acc.id)})">
                                <i class="bi bi-eye"></i> View
                            </button>
                            <button class="btn-ay ${active ? 'btn-ay-danger' : 'btn-ay-success'} btn-ay-sm"
                                    onclick='toggleStatus(${Number(acc.id)}, ${JSON.stringify(statusText)})'>
                                <i class="bi ${active ? 'bi-person-dash' : 'bi-person-check'}"></i>
                                ${active ? 'Disable' : 'Enable'}
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');

        const pages = Number(json.pages || 1);
        let paginationHtml = '';

        paginationHtml += `
            <li class="ay-page-item ${page <= 1 ? 'disabled' : ''}">
                <a class="ay-page-link" onclick="${page > 1 ? `fetchAccounts(${page - 1})` : 'return false;'}">Previous</a>
            </li>
        `;

        for (let n = 1; n <= pages; n++) {
            paginationHtml += `
                <li class="ay-page-item ${n === page ? 'active' : ''}">
                    <a class="ay-page-link" onclick="fetchAccounts(${n})">${n}</a>
                </li>
            `;
        }

        paginationHtml += `
            <li class="ay-page-item ${page >= pages ? 'disabled' : ''}">
                <a class="ay-page-link" onclick="${page < pages ? `fetchAccounts(${page + 1})` : 'return false;'}">Next</a>
            </li>
        `;

        pagination.innerHTML = paginationHtml;
    } catch (e) {
        document.getElementById('accountTableBody').innerHTML = `
            <tr>
                <td colspan="9">
                    <div class="ay-empty">
                        <i class="bi bi-exclamation-octagon"></i>
                        <p>${esc(e.message)}</p>
                    </div>
                </td>
            </tr>
        `;
        document.getElementById('pagination').innerHTML = '';
        document.getElementById('accountCountText').textContent = '';
    }
}

function toggleStatus(userId, current) {
    const newStatus = String(current).toLowerCase() === 'active' ? 'Inactive' : 'Active';

    confirmAction('Mark this account as <strong>' + newStatus + '</strong>?', async function() {
        try {
            const json = await apiCall('api/accounts/update.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ id: userId, status: newStatus })
            });

            if (json.success !== false) {
                showAlert('Account marked as ' + newStatus + '.', 'success');
                fetchAccounts(currentPage);
            } else {
                showAlert(json.error || 'Update failed.', 'danger');
            }
        } catch (e) {
            showAlert(e.message, 'danger');
        }
    });
}

async function loadTeacherDropdown() {
    const sel = document.getElementById('teacherIdInput');
    sel.innerHTML = '<option value="">— Loading… —</option>';

    try {
        const json = await apiCall('api/teacher/ids.php');
        const teachers = json.teachers || [];

        if (!teachers.length) {
            sel.innerHTML = '<option value="">— No teachers found —</option>';
            return;
        }

        sel.innerHTML = '<option value="">— Select a Teacher —</option>';

        teachers.forEach(function(t) {
            const option = document.createElement('option');
            option.value = t.teacher_id || '';
            option.textContent = (t.teacher_id || '') + ' — ' + (t.full_name || '');

            option.dataset.dbId = t.id || '';
            option.dataset.teacherId = t.teacher_id || '';
            option.dataset.fname = t.fname || '';
            option.dataset.lname = t.lname || '';
            option.dataset.email = t.email || '';
            option.dataset.dateHired = t.date_hired || '';

            sel.appendChild(option);
        });
    } catch (e) {
        sel.innerHTML = '<option value="">— Error loading —</option>';
        showAlert('Failed to load teacher list.', 'danger');
    }
}

function buildUsername(lname, teacherId) {
    return String(lname || '').toLowerCase().replace(/ /g, '') +
           String(teacherId || '').toLowerCase().trim();
}

function clearTeacherFields() {
    document.getElementById('teacherDbIdInput').value = '';
    document.getElementById('fnameInput').value = '';
    document.getElementById('lnameInput').value = '';
    document.getElementById('dateHiredInput').value = '';
    document.getElementById('emailInput').value = '';
    document.getElementById('usernameInput').value = '';
    document.getElementById('btnCreateAccount').disabled = true;
}

function onTeacherSelect() {
    const sel = document.getElementById('teacherIdInput');
    const opt = sel.options[sel.selectedIndex];

    clearTeacherFields();

    if (!opt || !opt.value) {
        return;
    }

    const dbId = opt.dataset.dbId || '';
    const fname = opt.dataset.fname || '';
    const lname = opt.dataset.lname || '';
    const teacherId = opt.dataset.teacherId || '';
    const email = opt.dataset.email || '';
    const dateHired = opt.dataset.dateHired || '';

    document.getElementById('teacherDbIdInput').value = dbId;
    document.getElementById('fnameInput').value = fname;
    document.getElementById('lnameInput').value = lname;
    document.getElementById('dateHiredInput').value = dateHired;
    document.getElementById('emailInput').value = email;
    document.getElementById('usernameInput').value = buildUsername(lname, teacherId);

    if (dbId) {
        document.getElementById('btnCreateAccount').disabled = false;
    } else {
        showAlert('Could not get teacher DB ID.', 'warning');
    }
}

function resetAddForm() {
    document.getElementById('teacherIdInput').value = '';
    clearTeacherFields();
}

function openAddModal() {
    resetAddForm();
    loadTeacherDropdown();
    bootstrap.Modal.getOrCreateInstance(document.getElementById('addAccountModal')).show();
}

async function createAccount() {
    const dbId = document.getElementById('teacherDbIdInput').value.trim();
    const username = document.getElementById('usernameInput').value.trim();

    if (!dbId) {
        showAlert('Please select a teacher first.', 'warning');
        return;
    }

    const btn = document.getElementById('btnCreateAccount');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Creating…';

    try {
        const json = await apiCall('api/accounts/create.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                teacher_db_id: parseInt(dbId, 10),
                username: username
            })
        });

        if (json.success !== false) {
            const modal = bootstrap.Modal.getInstance(document.getElementById('addAccountModal'));
            if (modal) modal.hide();

            document.getElementById('newUsername').textContent = json.username || username;
            document.getElementById('successMessage').innerHTML =
                '<i class="bi bi-envelope-check me-1"></i>' + esc(json.message || 'Temporary password sent via email.');

            bootstrap.Modal.getOrCreateInstance(document.getElementById('successModal')).show();
            showAlert('Account created successfully.', 'success');
            fetchAccounts(1);
            resetAddForm();
        } else {
            showAlert(json.error || 'Creation failed.', 'danger');
        }
    } catch (e) {
        showAlert('Failed: ' + e.message, 'danger');
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-check-circle me-1"></i> Save &amp; Send Email';
    }
}

async function viewAccount(userId) {
    const body = document.getElementById('viewModalBody');
    body.innerHTML = '<div class="ay-empty"><span class="spinner-border spinner-border-sm me-1"></span>Loading…</div>';
    bootstrap.Modal.getOrCreateInstance(document.getElementById('viewModal')).show();

    try {
        const json = await apiCall('api/accounts/view.php?id=' + encodeURIComponent(userId));

        if (json.success === false || !json.data) {
            body.innerHTML = '<div class="ay-empty"><i class="bi bi-exclamation-circle"></i><p>Account not found.</p></div>';
            return;
        }

        const a = json.data;
        const active = String(a.status || 'Active').toLowerCase() === 'active';
        const pwStatus = String(a.must_change_password ?? '') === '1'
            ? '<span class="ay-badge ay-badge-warning">Still Default Password</span>'
            : String(a.must_change_password ?? '') === '0'
            ? '<span class="ay-badge ay-badge-success">Already Changed</span>'
            : '<span class="ay-badge ay-badge-neutral">Unknown</span>';

        body.innerHTML = `
            <div class="ay-view-grid">
                <div class="ay-view-card">
                    <div class="ay-view-label">User ID</div>
                    <div class="ay-view-value">${esc(a.id)}</div>
                </div>
                <div class="ay-view-card">
                    <div class="ay-view-label">Teacher ID</div>
                    <div class="ay-view-value">${esc(a.teacher_id || a.reference_id || 'N/A')}</div>
                </div>
                <div class="ay-view-card">
                    <div class="ay-view-label">Name</div>
                    <div class="ay-view-value">${esc(a.name || 'N/A')}</div>
                </div>
                <div class="ay-view-card">
                    <div class="ay-view-label">Username</div>
                    <div class="ay-view-value" style="font-family:monospace;">${esc(a.username || '')}</div>
                </div>
                <div class="ay-view-card">
                    <div class="ay-view-label">Role</div>
                    <div class="ay-view-value"><span class="ay-badge ay-badge-primary">${esc(a.role || 'Teacher')}</span></div>
                </div>
                <div class="ay-view-card">
                    <div class="ay-view-label">Status</div>
                    <div class="ay-view-value"><span class="ay-badge ${active ? 'ay-badge-success' : 'ay-badge-warning'}">${esc(a.status || 'Active')}</span></div>
                </div>
                <div class="ay-view-card">
                    <div class="ay-view-label">Password Status</div>
                    <div class="ay-view-value">${pwStatus}</div>
                </div>
                <div class="ay-view-card">
                    <div class="ay-view-label">Created</div>
                    <div class="ay-view-value">${esc(a.created || a.created_at || 'N/A')}</div>
                </div>
            </div>
        `;
    } catch (e) {
        body.innerHTML = '<div class="ay-empty"><i class="bi bi-exclamation-circle"></i><p>' + esc(e.message) + '</p></div>';
        showAlert(e.message, 'danger');
    }
}

document.getElementById('addAccountModal').addEventListener('hidden.bs.modal', resetAddForm);

fetchAccounts(1);
</script>
</body>
</html>