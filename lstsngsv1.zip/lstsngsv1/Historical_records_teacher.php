<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/api/shared/db_connect.php';

$yearId = (string) ($_GET['year_id'] ?? '');
$type = ($_GET['type'] ?? 'students') === 'teachers' ? 'teachers' : 'students';
$isTeacher = $type === 'teachers';
$yearLabel = '';
$records = [];

if (ctype_digit($yearId) && (int) $yearId > 0) {
    try {
        $yearStmt = $pdo->prepare('SELECT year_label FROM tblacademicyear WHERE id = ? LIMIT 1');
        $yearStmt->execute([(int) $yearId]);
        $yearLabel = (string) ($yearStmt->fetchColumn() ?: $yearLabel);

        if ($isTeacher) {
            $stmt = $pdo->query("SELECT teacher_id AS number, CONCAT_WS(' ', fname, NULLIF(mname, ''), lname) AS name, email, COALESCE(is_active, 1) AS is_active FROM tblteacher ORDER BY lname, fname LIMIT 50");
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $records[] = ['initials' => strtoupper(substr(preg_replace('/[^A-Za-z]/', '', $row['name']), 0, 2)), 'name' => $row['name'], 'number' => $row['number'] ?: '—', 'level' => '—', 'section' => '—', 'adviser' => $row['email'] ?: 'Teacher', 'status' => (int) $row['is_active'] ? 'Active' : 'Archived'];
            }
        } else {
            $stmt = $pdo->prepare("SELECT s.id, s.lrn AS number, CONCAT_WS(' ', s.fname, NULLIF(s.mname, ''), s.lname) AS name, COALESCE(gl.grade_level_name, '—') AS level, COALESCE(sec.section_name, '—') AS section, COALESCE(e.enrollment_status, sa.status, 'Archived') AS status FROM tblstudents s LEFT JOIN tblstudent_archive sa ON sa.student_id = s.id AND sa.academic_year_id = ? LEFT JOIN tblenrollment e ON e.student_id = s.id AND e.academic_year_id = ? LEFT JOIN tblgradelevel gl ON gl.id = COALESCE(sa.grade_level_id, e.grade_level_id, s.grade_level_id) LEFT JOIN tblsectionstudent ss ON ss.student_id = s.id AND ss.academic_year_id = ? LEFT JOIN tblsection sec ON sec.id = ss.section_id WHERE sa.academic_year_id IS NOT NULL OR e.academic_year_id IS NOT NULL ORDER BY s.lname, s.fname LIMIT 50");
            $stmt->execute([(int) $yearId, (int) $yearId, (int) $yearId]);
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $records[] = ['id' => (int) $row['id'], 'initials' => strtoupper(substr(preg_replace('/[^A-Za-z]/', '', $row['name']), 0, 2)), 'name' => $row['name'], 'number' => $row['number'] ?: '—', 'level' => $row['level'], 'section' => $row['section'], 'adviser' => '—', 'status' => ucfirst(strtolower($row['status']))];
            }
        }
    } catch (Throwable $e) {
        $records = [];
    }
}

$recordCount = count($records);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>STSN Grading System | Faculty Historical Records</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="./css/historical-records.css">

    <style>
        /* ============================================================
           DARK MODE OVERRIDES FOR .hr-* CLASSES
           ============================================================ */
        [data-bs-theme="dark"] .hr-archive-page {
            background: transparent !important;
        }

        /* ---------- Filter strip (search + selects) ---------- */
        [data-bs-theme="dark"] .hr-user-filters {
            background: #2D2D2D !important;
            border: 1px solid #3a3a3a !important;
            border-radius: 10px;
            padding: 10px 12px;
            box-shadow: none !important;
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }

        /* Select dropdowns inside the strip */
        [data-bs-theme="dark"] .hr-user-filters select {
            background: #3a3a3a !important;
            color: #e4e6e8 !important;
            border: 1px solid #4a5a6e !important;
            border-radius: 8px;
            padding: 8px 12px;
            font-size: .88rem;
            outline: none;
            box-shadow: none !important;
            min-width: 130px;
        }
        [data-bs-theme="dark"] .hr-user-filters select:focus {
            border-color: #1a6ef5 !important;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, .15) !important;
        }
        [data-bs-theme="dark"] .hr-user-filters select option {
            background: #2D2D2D !important;
            color: #e4e6e8 !important;
        }

        /* Search input wrapper */
        [data-bs-theme="dark"] .hr-user-search {
            background: #3a3a3a !important;
            border: 1px solid #4a5a6e !important;
            border-radius: 8px;
            color: #e4e6e8 !important;
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            box-shadow: none !important;
            outline: none !important;
            flex: 1;
            min-width: 220px;
        }
        [data-bs-theme="dark"] .hr-user-search:focus-within {
            background: #3a3a3a !important;
            border-color: #1a6ef5 !important;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, .15) !important;
            outline: none !important;
        }
        [data-bs-theme="dark"] .hr-user-search i {
            color: #adb5bd !important;
        }

        /* The input itself — totally flat */
        [data-bs-theme="dark"] .hr-user-search input,
        [data-bs-theme="dark"] .hr-user-search input[type="search"] {
            background: transparent !important;
            background-color: transparent !important;
            border: 0 !important;
            border-radius: 0 !important;
            outline: 0 !important;
            box-shadow: none !important;
            -webkit-appearance: none !important;
            appearance: none !important;
            color: #e4e6e8 !important;
            flex: 1;
            min-width: 0;
            padding: 0 !important;
            margin: 0 !important;
        }
        [data-bs-theme="dark"] .hr-user-search input:focus,
        [data-bs-theme="dark"] .hr-user-search input:active {
            background: transparent !important;
            border: 0 !important;
            box-shadow: none !important;
            outline: 0 !important;
        }
        [data-bs-theme="dark"] .hr-user-search input[type="search"]::-webkit-search-decoration,
        [data-bs-theme="dark"] .hr-user-search input[type="search"]::-webkit-search-cancel-button,
        [data-bs-theme="dark"] .hr-user-search input[type="search"]::-webkit-search-results-button,
        [data-bs-theme="dark"] .hr-user-search input[type="search"]::-webkit-search-results-decoration {
            -webkit-appearance: none;
            appearance: none;
        }
        [data-bs-theme="dark"] .hr-user-search input::placeholder {
            color: #8b939a !important;
            opacity: 1 !important;
        }

        /* ---------- Table card ---------- */
        [data-bs-theme="dark"] .hr-user-table-card {
            background: #2D2D2D !important;
            border: 1px solid #3a3a3a !important;
            border-radius: 10px;
            overflow: hidden !important;
            box-shadow: none !important;
        }

        /* ---------- Table ---------- */
        [data-bs-theme="dark"] .hr-user-table {
            background: #2D2D2D !important;
            color: #e4e6e8 !important;
            width: 100%;
            border-collapse: collapse;
        }
        [data-bs-theme="dark"] .hr-user-table thead th {
            background: #2D2D2D !important;
            color: #ffffff !important;
            border-bottom: 1px solid #3a3a3a !important;
            font-weight: 700;
            letter-spacing: .06em;
            text-transform: uppercase;
            padding: 12px 14px;
        }
        [data-bs-theme="dark"] .hr-user-table tbody td {
            background: transparent !important;
            color: #e4e6e8 !important;
            border-bottom: 1px solid #3a3a3a !important;
            padding: 12px 14px;
            vertical-align: middle;
        }
        [data-bs-theme="dark"] .hr-user-table tbody tr:hover td {
            background: #343434 !important;
        }
        [data-bs-theme="dark"] .hr-user-table tbody strong {
            color: #ffffff !important;
        }

        /* ---------- Avatar circle ---------- */
        [data-bs-theme="dark"] .hr-user-avatar {
            background: #1e2a3d !important;
            color: #8ab4f8 !important;
            border: 1px solid #2d4366 !important;
        }

        /* ---------- Status badges ---------- */
        [data-bs-theme="dark"] .hr-user-status {
            background: #1e2a3d !important;
            color: #8ab4f8 !important;
            border: 1px solid #2d4366 !important;
        }
        [data-bs-theme="dark"] .hr-user-status.success {
            background: #17351f !important;
            color: #6ee7a0 !important;
            border-color: #2b5c38 !important;
        }
        [data-bs-theme="dark"] .hr-user-status.warning {
            background: #3a2f14 !important;
            color: #ffcc66 !important;
            border-color: #5c4820 !important;
        }
        [data-bs-theme="dark"] .hr-user-status.info {
            background: #1e2a3d !important;
            color: #8ab4f8 !important;
            border-color: #2d4366 !important;
        }

        /* ---------- "View Record" link button ---------- */
        [data-bs-theme="dark"] .hr-user-view {
            background: #3a3a3a !important;
            color: #8ab4f8 !important;
            border: 1px solid #4a5a6e !important;
            padding: 5px 12px;
            border-radius: 6px;
            text-decoration: none;
            display: inline-block;
            font-size: .85rem;
            font-weight: 600;
        }
        [data-bs-theme="dark"] .hr-user-view:hover {
            background: #4a4a4a !important;
            border-color: #6a7a8e !important;
            color: #8ab4f8 !important;
        }

        /* ---------- Footer strip ---------- */
        [data-bs-theme="dark"] .hr-user-table-footer {
            background: transparent !important;
            border-top: 1px solid #3a3a3a !important;
            color: #adb5bd !important;
            padding: 10px 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        [data-bs-theme="dark"] .hr-user-table-footer span,
        [data-bs-theme="dark"] .hr-user-table-footer i {
            color: #adb5bd !important;
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once __DIR__ . '/includes/header.php'; ?>
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3 hr-archive-page">
                <div class="page-header">
                    <div>
                        <h3><i class="bi bi-<?= $isTeacher ? 'people' : 'mortarboard' ?>-fill me-2"></i>Faculty Historical Records</h3>
                        <p><?= htmlspecialchars($yearLabel) ?> Academic Year — archived faculty records</p>
                    </div>
                </div>

                <?php require_once __DIR__ . '/includes/breadcrumb.php'; renderBreadcrumb([
                    ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door'],
                    ['label' => 'Archive', 'href' => 'historical_records.php', 'icon' => 'bi bi-archive'],
                    ['label' => 'Academic Years', 'href' => 'historical_selection.php?year_id=' . rawurlencode($yearId), 'icon' => 'bi bi-calendar3'],
                    ['label' => $yearLabel, 'href' => 'historical_selection.php?year_id=' . rawurlencode($yearId)],
                    ['label' => 'Faculty', 'icon' => 'bi bi-people']
                ]); ?>

                <form class="hr-user-filters" method="get">
                    <input type="hidden" name="year_id" value="<?= htmlspecialchars($yearId) ?>">
                    <input type="hidden" name="type" value="<?= $isTeacher ? 'teachers' : 'students' ?>">
                    <select aria-label="Filter by level"><option>All Levels</option><option>Grade 7</option><option>Grade 8</option><option>Grade 9</option><option>Grade 10</option><option>Grade 11</option><option>Grade 12</option></select>
                    <select aria-label="Filter by section"><option>All Sections</option><option>Rizal</option><option>Bonifacio</option><option>Aguinaldo</option></select>
                    <select aria-label="Filter by status"><option>All Status</option><option>Enrolled</option><option>Graduated</option><option>Transferred</option></select>
                    <label class="hr-user-search"><i class="bi bi-search"></i><input type="search" name="search" placeholder="<?= $isTeacher ? 'Teacher name or number...' : 'Student name or number...' ?>"></label>
                </form>

                <section class="hr-user-table-card">
                    <div class="table-responsive">
                        <table class="hr-user-table">
                            <thead><tr><th><?= $isTeacher ? 'TEACHER' : 'STUDENT' ?></th><th><?= $isTeacher ? 'TEACHER NO.' : 'STUDENT NO.' ?></th><th>LEVEL</th><th>SECTION</th><th><?= $isTeacher ? 'SUBJECT' : 'ADVISER' ?></th><th>STATUS</th><th>ACTIONS</th></tr></thead>
                            <tbody>
                            <?php foreach ($records as $record): ?>
                                <tr>
                                    <td><span class="hr-user-avatar"><?= htmlspecialchars($record['initials']) ?></span><strong><?= htmlspecialchars($record['name']) ?></strong></td>
                                    <td><?= htmlspecialchars($record['number']) ?></td><td><?= htmlspecialchars($record['level']) ?></td><td><?= htmlspecialchars($record['section']) ?></td><td><?= htmlspecialchars($record['adviser']) ?></td>
                                    <td><span class="hr-user-status <?= strtolower($record['status']) === 'enrolled' || strtolower($record['status']) === 'active' ? 'success' : (strtolower($record['status']) === 'transferred' ? 'warning' : 'info') ?>"><?= htmlspecialchars($record['status']) ?></span></td>
                                    <td><a class="hr-user-view" href="<?= $isTeacher ? '#' : 'student_record.php?year_id=' . rawurlencode($yearId) . '&student_id=' . (int) ($record['id'] ?? 0) ?>">View Record</a></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <footer class="hr-user-table-footer"><span>Showing <?= count($records) ?> of <?= $recordCount ?> <?= strtolower($isTeacher ? 'teacher' : 'student') ?> records</span><span><i class="bi bi-lock"></i> Read-only archive</span></footer>
                </section>
            </div>
        </div>
    </main>
    <?php require_once __DIR__ . '/includes/footer.php'; ?>
</div>
<script src="./vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
</body>
</html>