<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/api/shared/db_connect.php';
require_once __DIR__ . '/includes/archive_engine.php';
ensureProfileArchiveSchema($pdo);

$yearId = (string) ($_GET['year_id'] ?? '');
$isTeacher = true;
$yearLabel = '';
$records = [];
$search = trim((string) ($_GET['search'] ?? ''));
$yearIsActive = false;

if (ctype_digit($yearId) && (int) $yearId > 0) {
    try {
        $yearStmt = $pdo->prepare('SELECT year_label, is_active, archived_at FROM tblacademicyear WHERE id = ? LIMIT 1');
        $yearStmt->execute([(int) $yearId]);
        $selectedYear = $yearStmt->fetch(PDO::FETCH_ASSOC) ?: null;
        $yearLabel = (string) ($selectedYear['year_label'] ?? $yearLabel);
        $yearIsActive = $selectedYear
            && (int) $selectedYear['is_active'] === 1
            && empty($selectedYear['archived_at']);

        $query = "
            SELECT
                t.teacher_id AS number,
                t.id,
                CONCAT_WS(' ', t.fname, NULLIF(t.mname, ''), t.lname) AS name,
                t.email,
                GROUP_CONCAT(DISTINCT gl.grade_level_name ORDER BY gl.grade_level_name SEPARATOR ', ') AS level,
                GROUP_CONCAT(DISTINCT sec.section_name ORDER BY sec.section_name SEPARATOR ', ') AS section,
                COALESCE(t.is_active, 1) AS is_active,
                EXISTS (
                    SELECT 1
                    FROM tblprofile_archive pa
                    WHERE pa.profile_type = 'TEACHER'
                      AND pa.profile_id = t.id
                      AND pa.academic_year_id = sa.academic_year_id
                      AND pa.restored_at IS NULL
                ) AS profile_archived
            FROM tblsectionadviser sa
            INNER JOIN tblteacher t ON t.id = sa.teacher_id
            LEFT JOIN tblsection sec ON sec.id = sa.section_id
            LEFT JOIN tblgradelevel gl ON gl.id = sec.grade_level_id
            WHERE sa.academic_year_id = :year_id";
        $params = [':year_id' => (int) $yearId];

        if ($search !== '') {
            $query .= " AND (t.teacher_id LIKE :teacher_id_search OR t.fname LIKE :first_name_search OR t.lname LIKE :last_name_search OR t.email LIKE :email_search)";
            $searchValue = '%' . $search . '%';
            $params[':teacher_id_search'] = $searchValue;
            $params[':first_name_search'] = $searchValue;
            $params[':last_name_search'] = $searchValue;
            $params[':email_search'] = $searchValue;
        }

        $query .= "
            GROUP BY t.id, t.teacher_id, t.fname, t.mname, t.lname, t.email, t.is_active
            ORDER BY t.lname, t.fname
            LIMIT 50";

        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $records[] = [
                'id' => (int) $row['id'],
                'initials' => strtoupper(substr(preg_replace('/[^A-Za-z]/', '', $row['name']), 0, 2)),
                'name' => $row['name'],
                'number' => $row['number'] ?: '—',
                'level' => $row['level'] ?: '—',
                'section' => $row['section'] ?: '—',
                'adviser' => $row['email'] ?: '—',
                'status' => !empty($row['profile_archived'])
                    ? 'Archived Profile'
                    : ($yearIsActive ? 'Current Year' : 'Archived'),
                'profile_archived' => !empty($row['profile_archived']),
            ];
        }
    } catch (Throwable $e) {
        error_log('[Historical_records_teacher] Failed to load faculty archive: ' . $e->getMessage());
        $records = [];
    }
}

$recordCount = count($records);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>STSN Grading System | Faculty Historical Records</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="./css/historical-records.css">

    <style>
        /* ============================================================
           DARK MODE OVERRIDES FOR .hr-* CLASSES
           ============================================================ */
        [data-bs-theme="dark"] .hr-archive-page {
            background: transparent !important;
        }

        /* ---------- Filter strip (search + selects) ---------- */
        [data-bs-theme="dark"] .hr-user-filters {
            background: #2D2D2D !important;
            border: 1px solid #3a3a3a !important;
            border-radius: 10px;
            padding: 10px 12px;
            box-shadow: none !important;
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }

        /* Select dropdowns inside the strip */
        [data-bs-theme="dark"] .hr-user-filters select {
            background: #3a3a3a !important;
            color: #e4e6e8 !important;
            border: 1px solid #4a5a6e !important;
            border-radius: 8px;
            padding: 8px 12px;
            font-size: .88rem;
            outline: none;
            box-shadow: none !important;
            min-width: 130px;
        }
        [data-bs-theme="dark"] .hr-user-filters select:focus {
            border-color: #1a6ef5 !important;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, .15) !important;
        }
        [data-bs-theme="dark"] .hr-user-filters select option {
            background: #2D2D2D !important;
            color: #e4e6e8 !important;
        }

        /* Search input wrapper */
        [data-bs-theme="dark"] .hr-user-search {
            background: #3a3a3a !important;
            border: 1px solid #4a5a6e !important;
            border-radius: 8px;
            color: #e4e6e8 !important;
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            box-shadow: none !important;
            outline: none !important;
            flex: 1;
            min-width: 220px;
        }
        [data-bs-theme="dark"] .hr-user-search:focus-within {
            background: #3a3a3a !important;
            border-color: #1a6ef5 !important;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, .15) !important;
            outline: none !important;
        }
        [data-bs-theme="dark"] .hr-user-search i {
            color: #adb5bd !important;
        }

        /* The input itself — totally flat */
        [data-bs-theme="dark"] .hr-user-search input,
        [data-bs-theme="dark"] .hr-user-search input[type="search"] {
            background: transparent !important;
            background-color: transparent !important;
            border: 0 !important;
            border-radius: 0 !important;
            outline: 0 !important;
            box-shadow: none !important;
            -webkit-appearance: none !important;
            appearance: none !important;
            color: #e4e6e8 !important;
            flex: 1;
            min-width: 0;
            padding: 0 !important;
            margin: 0 !important;
        }
        [data-bs-theme="dark"] .hr-user-search input:focus,
        [data-bs-theme="dark"] .hr-user-search input:active {
            background: transparent !important;
            border: 0 !important;
            box-shadow: none !important;
            outline: 0 !important;
        }
        [data-bs-theme="dark"] .hr-user-search input[type="search"]::-webkit-search-decoration,
        [data-bs-theme="dark"] .hr-user-search input[type="search"]::-webkit-search-cancel-button,
        [data-bs-theme="dark"] .hr-user-search input[type="search"]::-webkit-search-results-button,
        [data-bs-theme="dark"] .hr-user-search input[type="search"]::-webkit-search-results-decoration {
            -webkit-appearance: none;
            appearance: none;
        }
        [data-bs-theme="dark"] .hr-user-search input::placeholder {
            color: #8b939a !important;
            opacity: 1 !important;
        }

        /* ---------- Table card ---------- */
        [data-bs-theme="dark"] .hr-user-table-card {
            background: #2D2D2D !important;
            border: 1px solid #3a3a3a !important;
            border-radius: 10px;
            overflow: hidden !important;
            box-shadow: none !important;
        }

        /* ---------- Table ---------- */
        [data-bs-theme="dark"] .hr-user-table {
            background: #2D2D2D !important;
            color: #e4e6e8 !important;
            width: 100%;
            border-collapse: collapse;
        }
        [data-bs-theme="dark"] .hr-user-table thead th {
            background: #2D2D2D !important;
            color: #ffffff !important;
            border-bottom: 1px solid #3a3a3a !important;
            font-weight: 700;
            letter-spacing: .06em;
            text-transform: uppercase;
            padding: 12px 14px;
        }
        [data-bs-theme="dark"] .hr-user-table tbody td {
            background: transparent !important;
            color: #e4e6e8 !important;
            border-bottom: 1px solid #3a3a3a !important;
            padding: 12px 14px;
            vertical-align: middle;
        }
        [data-bs-theme="dark"] .hr-user-table tbody tr:hover td {
            background: #343434 !important;
        }
        [data-bs-theme="dark"] .hr-user-table tbody strong {
            color: #ffffff !important;
        }

        /* ---------- Avatar circle ---------- */
        [data-bs-theme="dark"] .hr-user-avatar {
            background: #1e2a3d !important;
            color: #8ab4f8 !important;
            border: 1px solid #2d4366 !important;
        }

        /* ---------- Status badges ---------- */
        [data-bs-theme="dark"] .hr-user-status {
            background: #1e2a3d !important;
            color: #8ab4f8 !important;
            border: 1px solid #2d4366 !important;
        }
        [data-bs-theme="dark"] .hr-user-status.success {
            background: #17351f !important;
            color: #6ee7a0 !important;
            border-color: #2b5c38 !important;
        }
        [data-bs-theme="dark"] .hr-user-status.warning {
            background: #3a2f14 !important;
            color: #ffcc66 !important;
            border-color: #5c4820 !important;
        }
        [data-bs-theme="dark"] .hr-user-status.info {
            background: #1e2a3d !important;
            color: #8ab4f8 !important;
            border-color: #2d4366 !important;
        }

        /* ---------- "View Record" link button ---------- */
        [data-bs-theme="dark"] .hr-user-view {
            background: #3a3a3a !important;
            color: #8ab4f8 !important;
            border: 1px solid #4a5a6e !important;
            padding: 5px 12px;
            border-radius: 6px;
            text-decoration: none;
            display: inline-block;
            font-size: .85rem;
            font-weight: 600;
        }
        [data-bs-theme="dark"] .hr-user-view:hover {
            background: #4a4a4a !important;
            border-color: #6a7a8e !important;
            color: #8ab4f8 !important;
        }

        /* ---------- Footer strip ---------- */
        [data-bs-theme="dark"] .hr-user-table-footer {
            background: transparent !important;
            border-top: 1px solid #3a3a3a !important;
            color: #adb5bd !important;
            padding: 10px 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        [data-bs-theme="dark"] .hr-user-table-footer span,
        [data-bs-theme="dark"] .hr-user-table-footer i {
            color: #adb5bd !important;
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once __DIR__ . '/includes/header.php'; ?>
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3 hr-archive-page stsn-anim-fade-in-up">
                <div class="page-header">
                    <div>
                        <h3><i class="bi bi-people-fill me-2"></i>Faculty Historical Records</h3>
                        <p><?= htmlspecialchars($yearLabel) ?> Academic Year — <?= $yearIsActive ? 'current-year records' : 'archived year records' ?></p>
                    </div>
                </div>

                <?php require_once __DIR__ . '/includes/breadcrumb.php'; renderBreadcrumb([
                    ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door'],
                    ['label' => 'Archive', 'href' => 'historical_records.php', 'icon' => 'bi bi-archive'],
                    ['label' => 'Academic Years', 'href' => 'historical_selection.php?year_id=' . rawurlencode($yearId), 'icon' => 'bi bi-calendar3'],
                    ['label' => $yearLabel, 'href' => 'historical_selection.php?year_id=' . rawurlencode($yearId)],
                    ['label' => 'Faculty', 'icon' => 'bi bi-people']
                ]); ?>

                <form class="hr-user-filters" method="get">
                    <input type="hidden" name="year_id" value="<?= htmlspecialchars($yearId) ?>">
                    <input type="hidden" name="type" value="<?= $isTeacher ? 'teachers' : 'students' ?>">
                    <select aria-label="Filter by level"><option>All Levels</option><option>Grade 7</option><option>Grade 8</option><option>Grade 9</option><option>Grade 10</option><option>Grade 11</option><option>Grade 12</option></select>
                    <select aria-label="Filter by section"><option>All Sections</option><option>Rizal</option><option>Bonifacio</option><option>Aguinaldo</option></select>
                    <select aria-label="Filter by status"><option>All Status</option><option>Enrolled</option><option>Graduated</option><option>Transferred</option></select>
                    <label class="hr-user-search"><i class="bi bi-search"></i><input type="search" name="search" placeholder="<?= $isTeacher ? 'Teacher name or number...' : 'Student name or number...' ?>"></label>
                </form>

                <section class="hr-user-table-card">
                    <div class="table-responsive">
                        <table class="hr-user-table">
                            <thead><tr><th>TEACHER</th><th>TEACHER NO.</th><th>LEVEL</th><th>SECTION</th><th>EMAIL</th><th>STATUS</th><th>ACTIONS</th></tr></thead>
                            <tbody>
                            <?php foreach ($records as $record): ?>
                                <tr>
                                    <td><span class="hr-user-avatar"><?= htmlspecialchars($record['initials']) ?></span><strong><?= htmlspecialchars($record['name']) ?></strong></td>
                                    <td><?= htmlspecialchars($record['number']) ?></td><td><?= htmlspecialchars($record['level']) ?></td><td><?= htmlspecialchars($record['section']) ?></td><td><?= htmlspecialchars($record['adviser']) ?></td>
                                    <td>
                                        <span class="badge hr-user-status <?= $record['profile_archived'] ? 'success' : ($yearIsActive ? 'info' : 'success') ?>">
                                            <i class="bi <?= $record['profile_archived'] || !$yearIsActive ? 'bi-archive-fill' : 'bi-calendar-check' ?> me-1"></i><?= htmlspecialchars($record['status']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($record['profile_archived']): ?>
                                            <button type="button" class="hr-user-view" onclick="restoreArchivedTeacher(<?= (int) $record['id'] ?>)">Restore</button>
                                        <?php else: ?>
                                            <span class="hr-user-view">Historical</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <footer class="hr-user-table-footer"><span>Showing <?= count($records) ?> of <?= $recordCount ?> faculty records</span><span><i class="bi bi-lock"></i> Read-only academic-year records<?= in_array(true, array_column($records, 'profile_archived'), true) ? ' · Archived profiles can be restored' : '' ?></span></footer>
                </section>
            </div>
        </div>
    </main>
    <?php require_once __DIR__ . '/includes/footer.php'; ?>
</div>
<script src="./vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script>
    async function restoreArchivedTeacher(id) {
        if (!window.confirm('Restore this faculty profile to the active modules?')) return;
        try {
            const response = await fetch('api/teacher/delete.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id, new_state: 1 })
            });
            const data = await response.json();
            if (!response.ok || !data.success) throw new Error(data.error || data.message || 'Restore failed.');
            window.location.reload();
        } catch (error) {
            window.alert(error.message);
        }
    }
</script>
</body>
</html>