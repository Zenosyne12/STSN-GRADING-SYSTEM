<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/api/shared/db_connect.php';
require_once __DIR__ . '/api/shared/grade_workflow.php';

// Fallback archive check — DISABLED on this environment.
// Auto-archive/cron will be moved to Render later. Manual archiving
// (api/archive/manage.php) and includes/archive_engine.php stay intact.
// To re-enable: restore the block that calls checkAutoArchive($pdo) here.

requireAdmin();
ensureGradeWorkflowSchema($pdo);

function dashboardCount(PDO $pdo, string $sql, array $params = []): int
{
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (int) $stmt->fetchColumn();
}

function dashboardValue(PDO $pdo, string $sql, array $params = []): float
{
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (float) ($stmt->fetchColumn() ?: 0);
}

$activeYear = $pdo->query("SELECT id, year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1")->fetch(PDO::FETCH_ASSOC) ?: null;
$activeYearId = $activeYear ? (int) $activeYear['id'] : null;
$activeYearLabel = $activeYear['year_label'] ?? 'All school years';
$yearFilter = $activeYearId ? ' AND g.academic_year_id = :academic_year_id' : '';
$yearParams = $activeYearId ? [':academic_year_id' => $activeYearId] : [];
$gradeLevelEnrollmentFilter = $activeYearId ? 'AND e.academic_year_id = :enrollment_year_id' : '';
$gradeLevelGradeFilter = $activeYearId ? 'AND g.academic_year_id = :grade_year_id' : '';
$gradeLevelParams = $activeYearId
    ? [':enrollment_year_id' => $activeYearId, ':grade_year_id' => $activeYearId]
    : [];

$totalTeachers = dashboardCount($pdo, "SELECT COUNT(*) FROM tblteacher WHERE COALESCE(is_active, 1) = 1");
$totalStudents = dashboardCount($pdo, "SELECT COUNT(*) FROM tblstudents WHERE COALESCE(is_active, 1) = 1");
$totalSubjects = dashboardCount($pdo, "SELECT COUNT(*) FROM tblsubjects WHERE COALESCE(is_active, 1) = 1");
$totalSections = dashboardCount($pdo, "SELECT COUNT(*) FROM tblsection WHERE COALESCE(is_active, 1) = 1");

$averageGrade = dashboardValue(
    $pdo,
    "SELECT AVG(g.final_grade)
     FROM tblgrades g
     WHERE g.final_grade > 0
       AND " . officialGradeExistsSql('g') . "
       {$yearFilter}",
    $yearParams
);
$passedGrades = dashboardCount(
    $pdo,
    "SELECT COUNT(*)
     FROM tblgrades g
     WHERE g.final_grade >= 75
       AND " . officialGradeExistsSql('g') . "
       {$yearFilter}",
    $yearParams
);
$recordedGrades = dashboardCount(
    $pdo,
    "SELECT COUNT(*)
     FROM tblgrades g
     WHERE g.final_grade > 0
       AND " . officialGradeExistsSql('g') . "
       {$yearFilter}",
    $yearParams
);
$passRate = $recordedGrades > 0 ? ($passedGrades / $recordedGrades) * 100 : 0;
$gradedStudents = dashboardCount(
    $pdo,
    "SELECT COUNT(DISTINCT g.student_id)
     FROM tblgrades g
     WHERE g.final_grade > 0
       AND " . officialGradeExistsSql('g') . "
       {$yearFilter}",
    $yearParams
);

$gradeLevelSql = "
    SELECT
        gl.grade_level_name,
        ROUND(AVG(g.final_grade), 2) AS average_grade,
        COUNT(DISTINCT g.student_id) AS student_count,
        COUNT(g.id) AS grade_count
    FROM tblgrades g
    INNER JOIN tblstudents st ON st.id = g.student_id
    LEFT JOIN tblenrollment e
        ON e.student_id = st.id
       {$gradeLevelEnrollmentFilter}
       AND COALESCE(e.is_active, 1) = 1
    LEFT JOIN tblsection sec ON sec.id = g.section_id
    INNER JOIN tblgradelevel gl
        ON gl.id = COALESCE(e.grade_level_id, st.grade_level_id, sec.grade_level_id)
    WHERE g.final_grade > 0
      AND " . officialGradeExistsSql('g') . "
      {$gradeLevelGradeFilter}
    GROUP BY gl.id, gl.grade_level_name, gl.sort_order
    ORDER BY gl.sort_order ASC, gl.id ASC
";
$gradeStmt = $pdo->prepare($gradeLevelSql);
$gradeStmt->execute($gradeLevelParams);
$gradeLevelPerformance = $gradeStmt->fetchAll(PDO::FETCH_ASSOC);

$chartLabels = array_column($gradeLevelPerformance, 'grade_level_name');
$chartAverages = array_map(static fn($row) => (float) $row['average_grade'], $gradeLevelPerformance);
$chartStudentCounts = array_map(static fn($row) => (int) $row['student_count'], $gradeLevelPerformance);
?>
<!doctype html>
<html lang="en">


<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>STSN Grading System | Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <meta name="color-scheme" content="light dark" />
  <meta name="theme-color" content="#007bff" media="(prefers-color-scheme: light)" />
  <meta name="theme-color" content="#1a1a1a" media="(prefers-color-scheme: dark)" />
  <meta name="title" content="STSN | Dashboard" />
  <meta name="author" content="G" />
  <meta name="description"
    content="STSN Grading System - A modern and accessible Bootstrap 5-based grading and student management platform for Schools. Secure, fast, and WCAG 2.1 AA compliant." />
  <meta name="keywords"
    content="STSN, STSN Grading System, school grading system, student information system, bootstrap 5 admin dashboard, grading dashboard, student records, class management, teacher tools, accessible admin panel" />


  <meta name="supported-color-schemes" content="light dark" />
  <link rel="preload" href="./css/adminlte.css" as="style" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
    integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
    onload="this.media='all'" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
    crossorigin="anonymous" />
  

  
  <link rel="stylesheet" href="./css/adminlte.css" />
  
  <style>
    .dashboard-metric {
      min-height: 104px;
    }

    .dashboard-metric .info-box-number {
      font-size: 1.55rem;
      line-height: 1.1;
    }

    .analytics-card {
      border: 1px solid rgba(0, 0, 0, .075);
      box-shadow: 0 0.125rem 0.5rem rgba(33, 37, 41, .05);
    }

    .analytics-value {
      font-size: 2rem;
      font-weight: 700;
      line-height: 1;
    }

    .analytics-label {
      color: #6c757d;
      font-size: .875rem;
      margin-top: .35rem;
    }

    #grade-level-performance-chart {
      min-height: 360px;
    }

    .table-dashboard td,
    .table-dashboard th {
      vertical-align: middle;
    }
  </style>

</head>

<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">
  
  <div class="app-wrapper">
    <?php
    require_once("includes/header.php");
    require_once("includes/sidebar.php");
    ?>

    
    <main class="app-main">
      
      <div class="app-content-header">
      </div>
      <div class="app-content">
        <div class="container-fluid">

          <?php if (!empty($_SESSION['archive_notice'])): ?>
          <div class="alert alert-info alert-dismissible fade show" role="alert"
               style="border-radius:12px;">
              <i class="bi bi-archive-fill me-2"></i>
              <?= htmlspecialchars($_SESSION['archive_notice']) ?>
              <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
          </div>
          <?php unset($_SESSION['archive_notice']); ?>
          <?php endif; ?>

          <?php require_once __DIR__ . '/includes/breadcrumb.php'; renderBreadcrumb([['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'], ['label' => 'Dashboard', 'icon' => 'bi bi-speedometer2']]); ?>
          <div class="row">
            <div class="col-12 col-sm-6 col-md-3">
              <div class="info-box dashboard-metric">
                <span class="info-box-icon text-bg-primary shadow-sm">
                  <i class="bi bi-mortarboard-fill"></i>
                </span>
                <div class="info-box-content">
                  <span class="info-box-text">Total Teachers</span>
                  <span class="info-box-number"><?= number_format($totalTeachers) ?></span>
                  <span class="text-secondary small">Active faculty records</span>
                </div>
              </div>
            </div>

            <div class="col-12 col-sm-6 col-md-3">
              <div class="info-box dashboard-metric">
                <span class="info-box-icon text-bg-success shadow-sm">
                  <i class="bi bi-people-fill"></i>
                </span>
                <div class="info-box-content">
                  <span class="info-box-text">Total Students</span>
                  <span class="info-box-number"><?= number_format($totalStudents) ?></span>
                  <span class="text-secondary small">Active learner records</span>
                </div>
              </div>
            </div>

            <div class="col-12 col-sm-6 col-md-3">
              <div class="info-box dashboard-metric">
                <span class="info-box-icon text-bg-warning shadow-sm">
                  <i class="bi bi-book-half"></i>
                </span>
                <div class="info-box-content">
                  <span class="info-box-text">Total Subjects</span>
                  <span class="info-box-number"><?= number_format($totalSubjects) ?></span>
                  <span class="text-secondary small">Active subject offerings</span>
                </div>
              </div>
            </div>

            <div class="col-12 col-sm-6 col-md-3">
              <div class="info-box dashboard-metric">
                <span class="info-box-icon text-bg-danger shadow-sm">
                  <i class="bi bi-clipboard-data-fill"></i>
                </span>
                <div class="info-box-content">
                  <span class="info-box-text">Total Sections</span>
                  <span class="info-box-number"><?= number_format($totalSections) ?></span>
                  <span class="text-secondary small">Active class sections</span>
                </div>
              </div>
            </div>
          </div>
          

          <div class="row">
            <div class="col-12 col-md-4">
              <div class="card analytics-card mb-4">
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-between">
                    <div>
                      <div class="analytics-value text-primary"><?= number_format($averageGrade, 2) ?></div>
                      <div class="analytics-label">Average Grade</div>
                    </div>
                    <span class="badge text-bg-primary"><?= htmlspecialchars($activeYearLabel) ?></span>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 col-md-4">
              <div class="card analytics-card mb-4">
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-between">
                    <div>
                      <div class="analytics-value text-success"><?= number_format($passRate, 1) ?>%</div>
                      <div class="analytics-label">Finalized Passing Entries</div>
                    </div>
                    <i class="bi bi-graph-up-arrow fs-2 text-success"></i>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 col-md-4">
              <div class="card analytics-card mb-4">
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-between">
                    <div>
                      <div class="analytics-value text-info"><?= number_format($gradedStudents) ?></div>
                      <div class="analytics-label">Students With Finalized Grades</div>
                    </div>
                    <i class="bi bi-person-check-fill fs-2 text-info"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>

          
          <div class="row">
            <div class="col-md-12">
              <div class="card mb-4">
                <div class="card-header">
                  <h5 class="card-title mb-0">Finalized Student Performance by Grade Level</h5>
                  <div class="card-tools">
                    <span class="badge text-bg-light me-2"><?= htmlspecialchars($activeYearLabel) ?></span>
                    <button type="button" class="btn btn-tool" data-lte-toggle="card-collapse">
                      <i class="bi bi-dash-lg"></i>
                    </button>
                  </div>
                </div>
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-8">
                      <p class="text-center"><strong>Adviser-submitted grades grouped by grade level</strong></p>
                      <?php if ($gradeLevelPerformance): ?>
                        <div id="grade-level-performance-chart"></div>
                      <?php else: ?>
                        <div class="text-center text-secondary py-5">
                          <i class="bi bi-bar-chart-line fs-1 d-block mb-2"></i>
                          No finalized grade data is available yet.
                        </div>
                      <?php endif; ?>
                    </div>
                    <div class="col-md-4">
                      <p class="text-center"><strong>Grade Level Summary</strong></p>
                      <div class="table-responsive">
                        <table class="table table-sm table-hover table-dashboard mb-0">
                          <thead>
                            <tr>
                              <th>Grade Level</th>
                              <th class="text-end">Average</th>
                              <th class="text-end">Students</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php if ($gradeLevelPerformance): ?>
                              <?php foreach ($gradeLevelPerformance as $level): ?>
                                <tr>
                                  <td><?= htmlspecialchars($level['grade_level_name']) ?></td>
                                  <td class="text-end fw-semibold"><?= number_format((float) $level['average_grade'], 2) ?></td>
                                  <td class="text-end"><?= number_format((int) $level['student_count']) ?></td>
                                </tr>
                              <?php endforeach; ?>
                            <?php else: ?>
                              <tr>
                                <td colspan="3" class="text-center text-secondary py-4">No finalized grade data</td>
                              </tr>
                            <?php endif; ?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
                

              </div>
              
            </div>
            
          </div>
          
        </div>
        
      </div>
      
    </main>
    
    <?php
    require_once("includes/footer.php");
    ?>
  </div>
  
  
  
  <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
    crossorigin="anonymous"></script>
  
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    crossorigin="anonymous"></script>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>
  
  <script src="./js/adminlte.js"></script>
  
  <script>
    const SELECTOR_SIDEBAR_WRAPPER = '.sidebar-wrapper';
    const Default = {
      scrollbarTheme: 'os-theme-light',
      scrollbarAutoHide: 'leave',
      scrollbarClickScroll: true,
    };
    document.addEventListener('DOMContentLoaded', function () {
      const sidebarWrapper = document.querySelector(SELECTOR_SIDEBAR_WRAPPER);
      if (sidebarWrapper && OverlayScrollbarsGlobal?.OverlayScrollbars !== undefined) {
        OverlayScrollbarsGlobal.OverlayScrollbars(sidebarWrapper, {
          scrollbars: {
            theme: Default.scrollbarTheme,
            autoHide: Default.scrollbarAutoHide,
            clickScroll: Default.scrollbarClickScroll,
          },
        });
      }
    });
  </script>
  
  
  
  <script src="https://cdn.jsdelivr.net/npm/apexcharts@3.37.1/dist/apexcharts.min.js"></script>

  <script>
    const gradeLevelLabels = <?= json_encode($chartLabels, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?>;
    const gradeLevelAverages = <?= json_encode($chartAverages, JSON_NUMERIC_CHECK) ?>;
    const gradeLevelStudentCounts = <?= json_encode($chartStudentCounts, JSON_NUMERIC_CHECK) ?>;
    const gradeLevelChartEl = document.querySelector('#grade-level-performance-chart');

    if (gradeLevelChartEl) {
      const gradeLevelOptions = {
        series: [{
          name: 'Average Grade',
          data: gradeLevelAverages
        }],
        chart: {
          height: 360,
          type: 'bar',
          toolbar: { show: false }
        },
        colors: ['#0d6efd'],
        plotOptions: {
          bar: {
            borderRadius: 5,
            columnWidth: '52%',
            dataLabels: { position: 'top' }
          }
        },
        dataLabels: {
          enabled: true,
          formatter: (value) => Number(value).toFixed(2),
          offsetY: -20,
          style: {
            fontSize: '12px',
            colors: ['#495057']
          }
        },
        xaxis: {
          categories: gradeLevelLabels,
          labels: { rotate: -35, trim: true }
        },
        yaxis: {
          min: 0,
          max: 100,
          title: { text: 'Average Final Grade' },
          labels: {
            formatter: (value) => Number(value).toFixed(0)
          }
        },
        tooltip: {
          y: {
            formatter: (value, context) => {
              const count = gradeLevelStudentCounts[context.dataPointIndex] || 0;
              return `${Number(value).toFixed(2)} average from ${count} student${count === 1 ? '' : 's'}`;
            }
          }
        }
      };

      new ApexCharts(gradeLevelChartEl, gradeLevelOptions).render();
    }
  </script>
  
</body>


</html>
