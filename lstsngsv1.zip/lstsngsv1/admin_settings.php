<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/api/shared/db_connect.php';
require_once __DIR__ . '/api/shared/settings_schema.php';
require_once __DIR__ . '/includes/theme_head.php';

requireLogin();
if (!isAdminSession() && !isSuperAdminSession()) {
    redirectTo('/lstsngsv1/login.php');
}
stsnEnsureSettingsSchema($pdo);

$adminId = (int) ($_SESSION['user_id'] ?? 0);
$adminData = [];
$activeAcademicYear = '';

if ($adminId > 0 && isset($pdo)) {
  try {
    $stmt = $pdo->prepare("
            SELECT u.id, u.username, u.role_id, u.status, u.created_at, u.updated_at, u.must_change_password, u.theme_preference, u.show_section_prompt, u.password_changed_at, r.role_name
            FROM tblusers u
            LEFT JOIN tblrole r ON r.id = u.role_id
            WHERE u.id = ? AND u.role_id = 1
            LIMIT 1
        ");
    $stmt->execute([$adminId]);
    $adminData = $stmt->fetch(PDO::FETCH_ASSOC);
  } catch (PDOException $e) {
    error_log("Admin Profile DB Error: " . $e->getMessage());
  }
}

try {
  $activeAcademicYear = (string) ($pdo->query("SELECT year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1")->fetchColumn() ?: '');
} catch (PDOException $e) {
  $activeAcademicYear = '';
}

function e($str)
{
  return htmlspecialchars($str ?? '-');
}
?>
<!doctype html>
<html lang="en">

<head>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
  <meta charset="utf-8">
  <title>My Profile | STSN Grading System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="./css/adminlte.css">

  <style>
    .profile-hero-card {
      background: linear-gradient(135deg, #0b3d91 0%, #1457b8 52%, #1d75e8 100%);
      border-radius: 12px;
      padding: 2rem;
      color: #fff;
      position: relative;
      overflow: hidden;
      margin-bottom: 1.5rem;
    }

    .profile-hero-card::before {
      content: '';
      position: absolute;
      top: -50%;
      right: -10%;
      width: 400px;
      height: 400px;
      background: rgba(255, 255, 255, 0.03);
      border-radius: 50%;
    }

    .profile-avatar {
      width: 90px;
      height: 90px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.15);
      border: 3px solid rgba(255, 255, 255, 0.3);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 36px;
      font-weight: 800;
      color: #fff;
      position: relative;
    }


    .profile-name {
      font-size: 1.5rem;
      font-weight: 700;
      margin-bottom: 0.25rem;
    }

    .profile-role {
      font-size: 0.9rem;
      opacity: 0.85;
      display: flex;
      align-items: center;
      gap: 0.4rem;
    }

    .profile-academic-year {
      margin-top: 0.3rem;
      font-size: 0.82rem;
      opacity: 0.85;
      display: flex;
      align-items: center;
      gap: 0.35rem;
    }

    .profile-account-created {
      margin-top: 0.2rem;
      font-size: 0.78rem;
      opacity: 0.78;
    }

    .profile-meta {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
      margin-top: 1rem;
    }

    .profile-meta-chip {
      background: rgba(255, 255, 255, 0.12);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 999px;
      padding: 0.35rem 0.85rem;
      font-size: 0.8rem;
      color: #fff;
      display: inline-flex;
      align-items: center;
      gap: 0.35rem;
    }

    .info-card {
      border: none;
      border-radius: 12px;
      box-shadow: 0 2px 12px rgba(0, 0, 0, 0.06);
      height: 100%;
    }

    .info-card .card-header {
      background: transparent;
      border-bottom: 1px solid #e9ecef;
      padding: 1rem 1.25rem;
    }

    .info-card .card-header h5 {
      font-size: 1rem;
      font-weight: 700;
      color: #0A2F44;
      margin: 0;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    .info-card .card-header h5 i {
      color: #C5A028;
    }

    .info-card .card-header small {
      color: #6c757d;
      font-size: 0.82rem;
    }

    .info-card .card-body {
      padding: 0;
    }

    .field-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0.85rem 1.25rem;
      border-bottom: 1px solid #f0f2f5;
      gap: 1rem;
    }

    .field-row:last-child {
      border-bottom: none;
    }

    .field-label {
      font-size: 0.78rem;
      color: #6c757d;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.04em;
      flex-shrink: 0;
    }

    .field-value {
      font-size: 0.92rem;
      color: #1E2A3E;
      font-weight: 500;
      text-align: right;
    }

    .field-value.muted {
      color: #6c757d;
    }

    .badge-pill {
      display: inline-flex;
      align-items: center;
      gap: 0.3rem;
      padding: 0.25rem 0.65rem;
      border-radius: 999px;
      font-size: 0.75rem;
      font-weight: 700;
    }

    .badge-success {
      background: rgba(25, 135, 84, 0.1);
      color: #198754;
    }

    .badge-danger {
      background: rgba(220, 53, 69, 0.1);
      color: #dc3545;
    }

    .badge-warning {
      background: rgba(245, 158, 11, 0.1);
      color: #b96f00;
    }

    .edit-card {
      border: none;
      border-radius: 12px;
      box-shadow: 0 2px 12px rgba(0, 0, 0, 0.06);
      height: 100%;
    }

    .edit-card .card-header {
      background: transparent;
      border-bottom: 1px solid #e9ecef;
      padding: 0.85rem 1.1rem;
    }

    .edit-card .card-header h5 {
      font-size: 0.95rem;
      font-weight: 700;
      color: #0A2F44;
      margin: 0;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    .edit-card .card-header h5 i {
      color: #C5A028;
    }

    .edit-card .card-header small {
      font-size: 0.78rem;
    }

    .edit-card .card-body {
      padding: 1.1rem !important;
    }

    .form-label-custom {
      font-size: 0.78rem;
      color: #6c757d;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.04em;
      margin-bottom: 0.4rem;
    }

    .form-control-custom {
      border: 1px solid #e9ecef;
      border-radius: 10px;
      padding: 0.55rem 0.85rem;
      font-size: 0.9rem;
      transition: border-color 0.15s, box-shadow 0.15s;
    }

    .form-control-custom:focus {
      border-color: #0A2F44;
      box-shadow: 0 0 0 3px rgba(10, 47, 68, 0.08);
    }

    .pw-wrap {
      position: relative;
    }

    .pw-wrap .form-control-custom {
      padding-right: 2.5rem;
    }

    .toggle-pw {
      position: absolute;
      right: 0.6rem;
      top: 50%;
      transform: translateY(-50%);
      background: none;
      border: none;
      color: #6c757d;
      cursor: pointer;
      padding: 0.25rem;
      font-size: 14px;
    }

    .toggle-pw:hover {
      color: #0A2F44;
    }

    /* ★ Save Changes button — blue like the primary buttons */
    .btn-save {
      background: linear-gradient(130deg, #1a6ef5, #1248a8);
      color: #fff;
      border: none;
      border-radius: 10px;
      padding: 0.55rem 1.1rem;
      font-weight: 600;
      font-size: 0.88rem;
      box-shadow: 0 2px 8px rgba(26, 110, 245, 0.2);
      transition: background 0.15s, box-shadow 0.15s;
    }

    .btn-save:hover {
      background: linear-gradient(130deg, #1560d8, #103d90);
      color: #fff;
      box-shadow: 0 2px 10px rgba(26, 110, 245, 0.3);
    }

    .btn-cancel {
      background: #f8f9fa;
      color: #6c757d;
      border: 1px solid #e9ecef;
      border-radius: 10px;
      padding: 0.6rem 1.2rem;
      font-weight: 600;
      font-size: 0.9rem;
    }

    .btn-cancel:hover {
      background: #e9ecef;
    }

    .section-divider {
      font-size: 0.75rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: #6c757d;
      display: flex;
      align-items: center;
      gap: 0.65rem;
      margin: 1.5rem 1.25rem 1rem;
    }

    .section-divider::after {
      content: '';
      flex: 1;
      height: 1px;
      background: #e9ecef;
    }

    /* ============================================================
       Change Password Modal — Bulletproof blue gradient header
       Uses a ::before pseudo-element so no external theme rule
       (adminlte.css / bootstrap dark mode) can strip the gradient.
       ============================================================ */
    #changePasswordModal .modal-content {
      border-radius: 14px;
      border: none;
      overflow: hidden;
      background: var(--bs-body-bg, #fff);
    }

    #changePasswordModal .modal-header {
      position: relative;
      z-index: 0;
      color: #fff !important;
      border-bottom: 0 !important;
      background-color: #0b3d91 !important;
      overflow: hidden;
      border-top-left-radius: 14px;
      border-top-right-radius: 14px;
      padding: 1rem 1.25rem;
    }
    #changePasswordModal .modal-header::before {
      content: "";
      position: absolute;
      inset: 0;
      z-index: -1;
      background: linear-gradient(135deg, #0b3d91 0%, #1457b8 52%, #1d75e8 100%);
      pointer-events: none;
    }
    #changePasswordModal .modal-header > * {
      position: relative;
      z-index: 1;
    }
    #changePasswordModal .modal-title,
    #changePasswordModal .modal-header i {
      color: #fff !important;
    }
    #changePasswordModal .modal-header .btn-close {
      filter: invert(1) grayscale(100%) brightness(200%) !important;
      opacity: 1 !important;
      background-color: transparent;
      border-radius: 50%;
    }

    #changePasswordModal .modal-footer {
      background: #eef4fb;
      border-top: 1px solid #d9e8f8;
    }

    #changePasswordModal .btn-ay-primary {
      background: linear-gradient(130deg, #1a6ef5, #1248a8);
      border-color: transparent;
      color: #fff;
    }

    #changePasswordModal .btn-ay-outline {
      border-color: #b8d0fa;
      color: #1248a8;
      background: #fff;
    }

    /* Dark mode tweaks for the change password modal body/footer */
    [data-bs-theme="dark"] #changePasswordModal .modal-content {
      background: #2D2D2D;
      color: #e4e6e8;
    }
    [data-bs-theme="dark"] #changePasswordModal .modal-body {
      background: #2D2D2D;
      color: #e4e6e8;
    }
    [data-bs-theme="dark"] #changePasswordModal .modal-footer {
      background: #262626;
      border-top-color: #3a3a3a;
    }
    [data-bs-theme="dark"] #changePasswordModal .form-label {
      color: #ffffff;
    }
    [data-bs-theme="dark"] #changePasswordModal .form-control {
      background: #3a3a3a;
      color: #e4e6e8;
      border-color: #4a5a6e;
    }
    [data-bs-theme="dark"] #changePasswordModal .form-text,
    [data-bs-theme="dark"] #changePasswordModal #strengthText {
      color: #adb5bd !important;
    }

    .is-invalid {
      border-color: #dc3545 !important;
    }

    .invalid-feedback {
      color: #dc3545;
      font-size: 0.8rem;
      margin-top: 0.25rem;
      display: none;
    }

    .is-invalid~.invalid-feedback {
      display: block;
    }
  </style>
</head>

<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">
  <div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
      <div class="app-content">
        <div class="container-fluid">

          <div class="profile-hero-card">
            <div class="row align-items-center">
              <div class="col-auto">
                <div class="profile-avatar">
                  <?php
                  $initials = '';
                  $username = $adminData['username'] ?? '';
                  if (!empty($username)) {
                    $parts = preg_split('/[.\s_-]+/', $username);
                    foreach ($parts as $part) {
                      if (!empty($part))
                        $initials .= strtoupper(substr($part, 0, 1));
                    }
                  }
                  ?>
                  <span id="avatarInitials"><?php echo substr($initials, 0, 2) ?: 'A'; ?></span>
                </div>
              </div>
              <div class="col">
                <div class="profile-name"><?php echo e($adminData['username'] ?? 'Administrator'); ?></div>
                <div class="profile-role">
                  <i class="bi bi-shield-check"></i>
                  <?php echo e($adminData['role_name'] ?? 'System Administrator'); ?>
                </div>
                <?php if ($activeAcademicYear !== ''): ?>
                  <div class="profile-academic-year">
                    S.Y. <?php echo e($activeAcademicYear); ?>
                  </div>
                <?php endif; ?>
                <?php if (!empty($adminData['created_at'])): ?>
                  <div class="profile-account-created">
                    Account created <?php echo date('F j, Y g:i A', strtotime($adminData['created_at'])); ?>
                  </div>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <?php require_once __DIR__ . '/includes/breadcrumb.php';
          renderBreadcrumb([['label' => 'System Settings', 'href' => 'admin_settings.php', 'icon' => 'bi bi-gear-fill'], ['label' => 'Settings', 'icon' => 'bi bi-sliders2']]); ?>

          <div class="row g-4">

            <!-- Account Security -->
            <div class="col-md-6">
              <div class="card edit-card">
                <div class="card-header">
                  <h5><i class="bi bi-shield-lock"></i> Account Security</h5>
                  <small>Manage your secure password.</small>
                </div>
                <div class="card-body d-flex align-items-center">
                  <button type="button" class="btn"
                          style="background: linear-gradient(130deg, #1a6ef5, #1248a8); color: #fff; font-weight: 600; border: none; border-radius: 8px; padding: 0.5rem 1.1rem; box-shadow: 0 2px 8px rgba(26,110,245,0.2); display: inline-flex; align-items: center; gap: 0.4rem; transition: all 0.15s ease;"
                          onmouseover="this.style.background='linear-gradient(130deg, #1560d8, #103d90)'"
                          onmouseout="this.style.background='linear-gradient(130deg, #1a6ef5, #1248a8)'"
                          data-bs-toggle="modal" data-bs-target="#changePasswordModal">
                    <i class="bi bi-key"></i> Change Password
                  </button>
                </div>
              </div>
            </div>

            <!-- Section Management -->
            <div class="col-md-6">
              <div class="card edit-card">
                <div class="card-header">
                  <h5><i class="bi bi-diagram-3"></i> Section Management</h5>
                  <small>Auto-assign new students and manage section capacities.</small>
                </div>
                <div class="card-body">
                  <div class="row g-2 align-items-end">
                    <div class="col-12">
                      <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" role="switch" id="autoAssignEnabled">
                        <label class="form-check-label" for="autoAssignEnabled" style="font-size:.9rem;">Enable Auto-Sectioning</label>
                      </div>
                    </div>
                    <div class="col-md-7">
                      <label class="form-label-custom">Max Capacity (all sections)</label>
                      <input type="number" min="10" max="100" class="form-control form-control-custom" id="defaultMaxCapacity" value="40">
                    </div>
                    <div class="col-md-5">
                      <button type="button" class="btn btn-save w-100" id="btnSaveSectionConfig"><i class="bi bi-check-lg"></i> Save Changes</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </main>

    <?php require_once("includes/footer.php"); ?>
  </div>

  <div class="modal fade ay-modal" id="changePasswordModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"><i class="bi bi-lock me-2"></i>Change Password</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <form id="changePasswordForm">
          <div class="modal-body">
            <div class="mb-3">
              <label class="form-label">Current Password <span class="text-danger">*</span></label>
              <div class="input-group">
                <input type="password" class="form-control" id="currentPasswordModal" required>
                <button type="button" class="btn btn-outline-secondary" onclick="togglePassword('currentPasswordModal', this)"><i class="bi bi-eye"></i></button>
              </div>
              <small class="text-danger" id="currentPwError" style="display:none;">Incorrect password</small>
            </div>
            <div class="mb-3">
              <label class="form-label">New Password <span class="text-danger">*</span></label>
              <div class="input-group">
                <input type="password" class="form-control" id="newPasswordModal" required>
                <button type="button" class="btn btn-outline-secondary" onclick="togglePassword('newPasswordModal', this)"><i class="bi bi-eye"></i></button>
              </div>
              <small class="form-text">Min 8 characters, must include uppercase, lowercase, and number</small>
              <div class="mt-2">
                <div class="progress" style="height: 5px;"><div id="passwordStrength" class="progress-bar" style="width: 0%"></div></div>
                <small id="strengthText" style="color: #999;">Strength: None</small>
              </div>
            </div>
            <div class="mb-3">
              <label class="form-label">Confirm Password <span class="text-danger">*</span></label>
              <div class="input-group">
                <input type="password" class="form-control" id="confirmPasswordModal" required>
                <button type="button" class="btn btn-outline-secondary" onclick="togglePassword('confirmPasswordModal', this)"><i class="bi bi-eye"></i></button>
              </div>
              <small class="text-danger" id="confirmPwError" style="display:none;">Passwords don't match</small>
            </div>
            <div id="changePasswordErrors" style="display:none;"></div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-ay btn-ay-outline" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-ay btn-ay-primary" id="btnChangePassword"><i class="bi bi-check me-1"></i>Save New Password</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <div class="modal fade ay-modal" id="capacityModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"><i class="bi bi-sliders me-2"></i>Edit Section Capacity</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="capacitySectionId">
          <p><strong id="sectionNameDisplay">Topaz</strong></p>
          <div class="mb-3">
            <label class="form-label">Max Capacity <span class="text-danger">*</span></label>
            <input type="number" class="form-control" id="maxCapacityInput" min="10" max="100" value="40" required>
            <small class="form-text">Minimum 10, Maximum 100</small>
          </div>
          <div class="alert alert-info">
            <i class="bi bi-info-circle me-2"></i>
            <span id="occupancyInfo">Currently <strong>0 of 40</strong> students</span>
          </div>
          <div id="capacityWarning" class="alert alert-warning" style="display:none;"><i class="bi bi-exclamation-triangle me-2"></i>Reducing capacity below current enrollment. Existing students will remain assigned.</div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-ay btn-ay-outline" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-ay btn-ay-primary" id="btnSaveCapacity"><i class="bi bi-save me-1"></i>Save Capacity</button>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="./js/adminlte.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>
  <script src="./js/theme.js"></script>
  <script src="./js/admin-settings.js"></script>
  <script src="./js/auto-section.js"></script>
  <script>
    async function loadSystemStats() {
      try {
        const res = await fetch('api/profile/stats.php');
        const data = await res.json();
        if (data.success) {
          const ids = ['totalTeachers', 'totalStudents', 'totalSubjects', 'totalSections', 'activeYear', 'activeQuarter'];
          ids.forEach(id => {
            const el = document.getElementById(id);
            if (!el) return;
            if (id === 'totalTeachers') el.textContent = data.teachers ?? '—';
            if (id === 'totalStudents') el.textContent = data.students ?? '—';
            if (id === 'totalSubjects') el.textContent = data.subjects ?? '—';
            if (id === 'totalSections') el.textContent = data.sections ?? '—';
            if (id === 'activeYear')    el.textContent = data.active_year ?? '—';
            if (id === 'activeQuarter') el.textContent = data.active_quarter ?? '—';
          });
        }
      } catch (e) {
        console.error('Stats load failed:', e);
      }
    }
    loadSystemStats();

    function togglePassword(inputId, btn) {
      const input = document.getElementById(inputId);
      const icon = btn.querySelector('i');
      if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('bi-eye');
        icon.classList.add('bi-eye-slash');
      } else {
        input.type = 'password';
        icon.classList.remove('bi-eye-slash');
        icon.classList.add('bi-eye');
      }
    }

    const urlParams = new URLSearchParams(window.location.search);
    const successMsg = urlParams.get('success');
    const errorMsg = urlParams.get('error');

    if (successMsg) {
      iziToast.success({
        title: 'Success',
        message: decodeURIComponent(successMsg),
        position: 'topRight',
        timeout: 4000
      });
      window.history.replaceState({}, document.title, window.location.pathname);
    }
    if (errorMsg) {
      iziToast.error({
        title: 'Error',
        message: decodeURIComponent(errorMsg),
        position: 'topRight',
        timeout: 5000
      });
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  </script>
</body>

</html>