<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/api/shared/db_connect.php';
require_once __DIR__ . '/includes/archive_engine.php';
ensureProfileArchiveSchema($pdo);

$yearId = (string) ($_GET['year_id'] ?? '');
$yearLabel = '';
$records = [];
$search = trim((string) ($_GET['search'] ?? ''));
$yearIsActive = false;
$gradeLevels = $pdo->query("
    SELECT id, grade_level_name
    FROM tblgradelevel
    ORDER BY sort_order ASC, id ASC
")->fetchAll(PDO::FETCH_ASSOC);
$clusters = $pdo->query("
    SELECT DISTINCT strand
    FROM tblsection
    WHERE strand IS NOT NULL AND TRIM(strand) <> ''
    ORDER BY strand ASC
")->fetchAll(PDO::FETCH_COLUMN);
$gradeId = (string) ($_GET['grade_id'] ?? '');
$gradeId = ctype_digit($gradeId) && (int) $gradeId > 0 ? (int) $gradeId : 0;
$cluster = trim((string) ($_GET['cluster_id'] ?? ''));
$selectedGradeLabel = '';
foreach ($gradeLevels as $gradeLevel) {
    if ((int) $gradeLevel['id'] === $gradeId) {
        $selectedGradeLabel = (string) $gradeLevel['grade_level_name'];
        break;
    }
}
$showClusterFilter = (bool) preg_match('/Grade\s*1[12]/i', $selectedGradeLabel);

if (ctype_digit($yearId) && (int) $yearId > 0) {
    try {
        $yearStmt = $pdo->prepare('SELECT year_label, is_active, archived_at FROM tblacademicyear WHERE id = ? LIMIT 1');
        $yearStmt->execute([(int) $yearId]);
        $selectedYear = $yearStmt->fetch(PDO::FETCH_ASSOC) ?: null;
        $yearLabel = (string) ($selectedYear['year_label'] ?? '');
        $yearIsActive = $selectedYear
            && (int) $selectedYear['is_active'] === 1
            && empty($selectedYear['archived_at']);

        $query = "
            SELECT
                s.id,
                s.lrn AS number,
                CONCAT_WS(' ', s.fname, NULLIF(s.mname, ''), s.lname) AS name,
                COALESCE(GROUP_CONCAT(DISTINCT gl.grade_level_name ORDER BY gl.grade_level_name SEPARATOR ', '), '—') AS level,
                COALESCE(GROUP_CONCAT(DISTINCT sec.section_name ORDER BY sec.section_name SEPARATOR ', '), '—') AS section,
                COALESCE(GROUP_CONCAT(
                    DISTINCT NULLIF(TRIM(CONCAT_WS(' ', t.fname, t.lname)), '')
                    ORDER BY t.lname, t.fname SEPARATOR ', '
                ), '-') AS adviser_name,
                EXISTS (
                    SELECT 1
                    FROM tblprofile_archive pa
                    WHERE pa.profile_type = 'STUDENT'
                      AND pa.profile_id = s.id
                      AND pa.academic_year_id = cohort.academic_year_id
                      AND pa.restored_at IS NULL
                ) AS profile_archived
            FROM (
                SELECT student_id, academic_year_id
                FROM tblsectionstudent
                WHERE academic_year_id = :section_source_year
                UNION
                SELECT student_id, academic_year_id
                FROM tblenrollment
                WHERE academic_year_id = :enrollment_source_year
                UNION
                SELECT student_id, academic_year_id
                FROM tblstudent_archive
                WHERE academic_year_id = :archive_source_year
            ) cohort
            INNER JOIN tblstudents s ON s.id = cohort.student_id
            LEFT JOIN (
                SELECT sa_latest.*
                FROM tblstudent_archive sa_latest
                INNER JOIN (
                    SELECT student_id, academic_year_id, MAX(id) AS id
                    FROM tblstudent_archive
                    GROUP BY student_id, academic_year_id
                ) latest ON latest.id = sa_latest.id
            ) sa ON sa.student_id = s.id AND sa.academic_year_id = cohort.academic_year_id
            LEFT JOIN tblenrollment e
                ON e.student_id = s.id AND e.academic_year_id = cohort.academic_year_id
            LEFT JOIN tblgradelevel gl ON gl.id = COALESCE(sa.grade_level_id, e.grade_level_id, s.grade_level_id)
            LEFT JOIN tblsectionstudent ss
                ON ss.student_id = s.id AND ss.academic_year_id = cohort.academic_year_id
            LEFT JOIN tblsection sec ON sec.id = ss.section_id
            LEFT JOIN tblsectionadviser adviser
                ON adviser.section_id = ss.section_id
               AND adviser.academic_year_id = ss.academic_year_id
            LEFT JOIN tblteacher t ON t.id = adviser.teacher_id
            WHERE cohort.academic_year_id = :selected_year";

        $params = [
            ':section_source_year' => (int) $yearId,
            ':enrollment_source_year' => (int) $yearId,
            ':archive_source_year' => (int) $yearId,
            ':selected_year' => (int) $yearId,
        ];

        if ($gradeId > 0) {
            $query .= " AND COALESCE(sa.grade_level_id, e.grade_level_id, sec.grade_level_id, s.grade_level_id) = :gradeId";
            $params[':gradeId'] = $gradeId;
        }

        if ($showClusterFilter && $cluster !== '') {
            $query .= " AND sec.strand = :cluster";
            $params[':cluster'] = $cluster;
        }

        if ($search !== '') {
            $query .= " AND (s.lrn LIKE :search OR s.fname LIKE :search OR s.lname LIKE :search OR CONCAT_WS(' ', s.fname, s.lname) LIKE :search)";
            $params[':search'] = '%' . $search . '%';
        }

        $query .= "
            GROUP BY s.id, s.lrn, s.fname, s.mname, s.lname
            ORDER BY s.lname, s.fname
            LIMIT 50";

        $stmt = $pdo->prepare($query);
        $stmt->execute($params);

        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $records[] = [
                'id' => (int) $row['id'],
                'initials' => strtoupper(substr(preg_replace('/[^A-Za-z]/', '', (string) $row['name']), 0, 2)),
                'name' => $row['name'],
                'number' => $row['number'] ?: '—',
                'level' => $row['level'],
                'section' => $row['section'],
                'adviser' => (string) ($row['adviser_name'] ?? '-'),
                'status' => !empty($row['profile_archived'])
                    ? 'Archived Profile'
                    : ($yearIsActive ? 'Current Year' : 'Archived'),
                'profile_archived' => !empty($row['profile_archived']),
            ];
        }
    } catch (Throwable $e) {
        error_log('[Historical_records_student] Failed to load student archive: ' . $e->getMessage());
        $records = [];
    }
}

$recordCount = count($records);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>STSN Grading System | Historical Students</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="./css/historical-records.css">

    <style>
        /* ============================================================
           DARK MODE OVERRIDES FOR .hr-* CLASSES
           ============================================================ */
        [data-bs-theme="dark"] .hr-archive-page {
            background: transparent !important;
        }

        /* ---------- Search / Filter strip ---------- */
        [data-bs-theme="dark"] .hr-user-filters {
            background: #2D2D2D !important;
            border: 1px solid #3a3a3a !important;
            border-radius: 10px;
            padding: 10px 12px;
            box-shadow: none !important;
        }

        /* Search input wrapper — flat, no inner shadow */
        [data-bs-theme="dark"] .hr-user-search {
            background: #3a3a3a !important;
            border: 1px solid #4a5a6e !important;
            border-radius: 8px;
            color: #e4e6e8 !important;
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            box-shadow: none !important;
            outline: none !important;
        }

        /* Kill the browser's default inner focus ring / inset shadow on the wrapper */
        [data-bs-theme="dark"] .hr-user-search:focus,
        [data-bs-theme="dark"] .hr-user-search:focus-within {
            background: #3a3a3a !important;
            border-color: #1a6ef5 !important;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, .15) !important;
            outline: none !important;
        }

        [data-bs-theme="dark"] .hr-user-search i {
            color: #adb5bd !important;
        }

        /* Input itself — fully transparent, no borders, no shadows */
        [data-bs-theme="dark"] .hr-user-search input,
        [data-bs-theme="dark"] .hr-user-search input[type="search"] {
            background: transparent !important;
            background-color: transparent !important;
            border: 0 !important;
            border-radius: 0 !important;
            outline: 0 !important;
            box-shadow: none !important;
            -webkit-appearance: none !important;
            appearance: none !important;
            color: #e4e6e8 !important;
            flex: 1;
            min-width: 0;
            padding: 0 !important;
            margin: 0 !important;
        }

        /* Kill Bootstrap's .form-control:focus inset shadow */
        [data-bs-theme="dark"] .hr-user-search input:focus,
        [data-bs-theme="dark"] .hr-user-search input:active {
            background: transparent !important;
            border: 0 !important;
            box-shadow: none !important;
            outline: 0 !important;
        }

        /* Kill the native "x" clear button styling on search inputs in webkit */
        [data-bs-theme="dark"] .hr-user-search input[type="search"]::-webkit-search-decoration,
        [data-bs-theme="dark"] .hr-user-search input[type="search"]::-webkit-search-cancel-button,
        [data-bs-theme="dark"] .hr-user-search input[type="search"]::-webkit-search-results-button,
        [data-bs-theme="dark"] .hr-user-search input[type="search"]::-webkit-search-results-decoration {
            -webkit-appearance: none;
            appearance: none;
        }

        [data-bs-theme="dark"] .hr-user-search input::placeholder {
            color: #8b939a !important;
            opacity: 1 !important;
        }

        /* ---------- Table card ---------- */
        [data-bs-theme="dark"] .hr-user-table-card {
            background: #2D2D2D !important;
            border: 1px solid #3a3a3a !important;
            border-radius: 10px;
            overflow: hidden !important;
            box-shadow: none !important;
        }

        /* ---------- Table ---------- */
        [data-bs-theme="dark"] .hr-user-table {
            background: #2D2D2D !important;
            color: #e4e6e8 !important;
            width: 100%;
            border-collapse: collapse;
        }
        [data-bs-theme="dark"] .hr-user-table thead th {
            background: #2D2D2D !important;
            color: #ffffff !important;
            border-bottom: 1px solid #3a3a3a !important;
            font-weight: 700;
            letter-spacing: .06em;
            text-transform: uppercase;
            padding: 12px 14px;
        }
        [data-bs-theme="dark"] .hr-user-table tbody td {
            background: transparent !important;
            color: #e4e6e8 !important;
            border-bottom: 1px solid #3a3a3a !important;
            padding: 12px 14px;
            vertical-align: middle;
        }
        [data-bs-theme="dark"] .hr-user-table tbody tr:hover td {
            background: #343434 !important;
        }
        [data-bs-theme="dark"] .hr-user-table tbody strong {
            color: #ffffff !important;
        }

        /* ---------- Avatar circle (initials) ---------- */
        [data-bs-theme="dark"] .hr-user-avatar {
            background: #1e2a3d !important;
            color: #8ab4f8 !important;
            border: 1px solid #2d4366 !important;
        }

        /* ---------- Status badges ---------- */
        [data-bs-theme="dark"] .hr-user-status {
            background: #1e2a3d !important;
            color: #8ab4f8 !important;
            border: 1px solid #2d4366 !important;
        }
        [data-bs-theme="dark"] .hr-user-status.success {
            background: #17351f !important;
            color: #6ee7a0 !important;
            border-color: #2b5c38 !important;
        }
        [data-bs-theme="dark"] .hr-user-status.warning {
            background: #3a2f14 !important;
            color: #ffcc66 !important;
            border-color: #5c4820 !important;
        }
        [data-bs-theme="dark"] .hr-user-status.info {
            background: #1e2a3d !important;
            color: #8ab4f8 !important;
            border-color: #2d4366 !important;
        }

        /* ---------- "View Record" link button ---------- */
        [data-bs-theme="dark"] .hr-user-view {
            background: #3a3a3a !important;
            color: #8ab4f8 !important;
            border: 1px solid #4a5a6e !important;
            padding: 5px 12px;
            border-radius: 6px;
            text-decoration: none;
            display: inline-block;
            font-size: .85rem;
            font-weight: 600;
        }
        [data-bs-theme="dark"] .hr-user-view:hover {
            background: #4a4a4a !important;
            border-color: #6a7a8e !important;
            color: #8ab4f8 !important;
        }

        /* ---------- Footer strip ---------- */
        [data-bs-theme="dark"] .hr-user-table-footer {
            background: transparent !important;
            border-top: 1px solid #3a3a3a !important;
            color: #adb5bd !important;
            padding: 10px 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        [data-bs-theme="dark"] .hr-user-table-footer span,
        [data-bs-theme="dark"] .hr-user-table-footer i {
            color: #adb5bd !important;
        }

        .hr-user-filters {
            display: flex;
            flex-wrap: wrap;
            align-items: flex-start;
            gap: 0.5rem;
            margin-bottom: 1rem;
        }

        .hr-user-filter-select {
            width: 220px;
            max-width: 100%;
        }

        #clusterFilterWrap {
            flex: 0 0 0;
            width: 0;
            max-width: 220px;
            max-height: 0;
            opacity: 0;
            overflow: hidden;
            transition: flex-basis 0.35s ease, width 0.35s ease,
                max-height 0.35s ease, opacity 0.35s ease, margin 0.35s ease;
            margin-top: 0;
        }

        #clusterFilterWrap.show {
            flex-basis: 100%;
            width: 100%;
            max-width: 100%;
            max-height: 80px;
            opacity: 1;
            margin-top: 0.25rem;
        }

        #clusterFilterWrap select {
            width: 220px;
            max-width: 100%;
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once __DIR__ . '/includes/header.php'; ?>
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3 hr-archive-page stsn-anim-fade-in-up">
                <div class="page-header">
                    <div>
                        <h3><i class="bi bi-mortarboard-fill me-2"></i>Student Historical Records</h3>
                        <p><?= htmlspecialchars($yearLabel) ?> Academic Year — <?= $yearIsActive ? 'current-year records' : 'archived year records' ?></p>
                    </div>
                </div>

                <?php require_once __DIR__ . '/includes/breadcrumb.php'; renderBreadcrumb([
                    ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door'],
                    ['label' => 'Archive', 'href' => 'historical_records.php', 'icon' => 'bi bi-archive'],
                    ['label' => 'Academic Years', 'href' => 'historical_selection.php?year_id=' . rawurlencode($yearId), 'icon' => 'bi bi-calendar3'],
                    ['label' => $yearLabel, 'href' => 'historical_selection.php?year_id=' . rawurlencode($yearId)],
                    ['label' => 'Students', 'icon' => 'bi bi-people']
                ]); ?>

                <form class="hr-user-filters" id="studentFilters" method="get">
                    <input type="hidden" name="year_id" value="<?= htmlspecialchars($yearId) ?>">
                    <label class="hr-user-search"><i class="bi bi-search"></i><input type="search" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Student name or number..."></label>
                    <select id="gradeFilter" name="grade_id" class="form-select hr-user-filter-select" onchange="onGradeChange()">
                        <option value="">All Grades</option>
                        <?php foreach ($gradeLevels as $gradeLevel): ?>
                            <option value="<?= (int) $gradeLevel['id'] ?>" <?= (int) $gradeLevel['id'] === $gradeId ? 'selected' : '' ?>>
                                <?= htmlspecialchars($gradeLevel['grade_level_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div id="clusterFilterWrap" class="<?= $showClusterFilter ? 'show' : '' ?>">
                        <select id="clusterFilter" name="cluster_id" class="form-select" onchange="onClusterChange()">
                            <option value="">All Clusters</option>
                            <?php foreach ($clusters as $clusterOption): ?>
                                <option value="<?= htmlspecialchars((string) $clusterOption) ?>" <?= $clusterOption === $cluster ? 'selected' : '' ?>>
                                    <?= htmlspecialchars((string) $clusterOption) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </form>

                <section class="hr-user-table-card">
                    <div class="table-responsive">
                        <table class="hr-user-table">
                            <thead>
                                <tr>
                                    <th>STUDENT</th>
                                    <th>STUDENT NO.</th>
                                    <th>LEVEL</th>
                                    <th>SECTION</th>
                                    <th>ADVISER</th>
                                    <th>STATUS</th>
                                    <th>ACTIONS</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($records as $record): ?>
                                <tr>
                                    <td><span class="hr-user-avatar"><?= htmlspecialchars($record['initials']) ?></span><strong><?= htmlspecialchars($record['name']) ?></strong></td>
                                    <td><?= htmlspecialchars($record['number']) ?></td>
                                    <td><?= htmlspecialchars($record['level']) ?></td>
                                    <td><?= htmlspecialchars($record['section']) ?></td>
                                    <td><?= htmlspecialchars($record['adviser']) ?></td>
                                    <td>
                                        <span class="badge hr-user-status <?= $record['profile_archived'] ? 'success' : ($yearIsActive ? 'info' : 'success') ?>">
                                            <i class="bi <?= $record['profile_archived'] || !$yearIsActive ? 'bi-archive-fill' : 'bi-calendar-check' ?> me-1"></i><?= htmlspecialchars($record['status']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($record['profile_archived']): ?>
                                            <button type="button" class="hr-user-view" onclick="restoreArchivedStudent(<?= (int) $record['id'] ?>)">Restore</button>
                                        <?php else: ?>
                                            <a class="hr-user-view" href="student_record.php?year_id=<?= rawurlencode($yearId) ?>&student_id=<?= (int) ($record['id'] ?? 0) ?>">View Record</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <footer class="hr-user-table-footer"><span>Showing <?= count($records) ?> of <?= $recordCount ?> student records</span><span><i class="bi bi-lock"></i> Read-only academic-year records<?= in_array(true, array_column($records, 'profile_archived'), true) ? ' · Archived profiles can be restored' : '' ?></span></footer>
                </section>
            </div>
        </div>
    </main>
    <?php require_once __DIR__ . '/includes/footer.php'; ?>
</div>
<script src="./vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script>
    async function restoreArchivedStudent(id) {
        if (!window.confirm('Restore this student profile to the active modules?')) return;
        try {
            const response = await fetch(`api/student/toggle.php?id=${encodeURIComponent(id)}`);
            const data = await response.json();
            if (!response.ok || !data.success) throw new Error(data.error || data.message || 'Restore failed.');
            window.location.reload();
        } catch (error) {
            window.alert(error.message);
        }
    }

    function onGradeChange() {
        const gradeSelect = document.getElementById('gradeFilter');
        const clusterWrap = document.getElementById('clusterFilterWrap');
        const clusterSelect = document.getElementById('clusterFilter');
        const gradeLabel = gradeSelect.options[gradeSelect.selectedIndex]?.text || '';
        const isSHS = /Grade\s*1[12]/i.test(gradeLabel);

        if (isSHS) {
            clusterWrap.classList.add('show');
        } else {
            clusterWrap.classList.remove('show');
            clusterSelect.value = '';
        }

        window.setTimeout(() => document.getElementById('studentFilters').submit(), 350);
    }

    function onClusterChange() {
        document.getElementById('studentFilters').submit();
    }
</script>
</body>
</html>