<?php
require_once 'includes/auth.php';
requireAdmin();
require_once __DIR__ . '/api/shared/db_connect.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$edit = ($id > 0);

if ($edit) {
    $stmt = $pdo->prepare('SELECT * FROM vwStudentInfo WHERE id = ?');
    $stmt->execute([$id]);
    $old = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$old) {
        header('Location: student.php');
        exit;
    }
} else {
    $old = [];
}

$grades = $pdo->query('SELECT id, grade_level_name FROM tblGradeLevel ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
$countries = $pdo->query('SELECT id, country_name FROM tblCountry ORDER BY country_name')->fetchAll(PDO::FETCH_ASSOC);
$regions = $pdo->query('SELECT id, region_name, country_id FROM tblRegion ORDER BY region_name')->fetchAll(PDO::FETCH_ASSOC);
$provinces = $pdo->query('SELECT id, province_name, region_id FROM tblProvince ORDER BY province_name')->fetchAll(PDO::FETCH_ASSOC);
$cities = $pdo->query('SELECT id, city_name, province_id FROM tblCity ORDER BY city_name')->fetchAll(PDO::FETCH_ASSOC);
$barangays = $pdo->query('SELECT id, barangay_name, city_id FROM tblBarangay ORDER BY barangay_name')->fetchAll(PDO::FETCH_ASSOC);

$oldCountry = $old['country_id'] ?? '';
$oldRegion = $old['region_id'] ?? '';
$oldProvince = $old['province_id'] ?? '';
$oldCity = $old['city_id'] ?? '';
$oldBarangay = $old['barangay_id'] ?? '';
$oldStrand = $old['strand'] ?? '';

$toastType = null;
$toastMessage = '';

if (isset($_GET['duplicate'])) {
    $toastType = 'danger';
    $toastMessage = 'LRN already exists!';
} elseif (isset($_GET['error'])) {
    $toastType = 'danger';
    $toastMessage = (string) $_GET['error'];
} elseif (isset($_GET['msg'])) {
    $toastType = 'success';
    $toastMessage = (string) $_GET['msg'];
}

function v(array $a, string $k): string
{
    return htmlspecialchars($a[$k] ?? '', ENT_QUOTES, 'UTF-8');
}

function sel(array $a, string $k, $v): string
{
    return (($a[$k] ?? '') == $v) ? 'selected' : '';
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>STSN | <?= $edit ? 'Edit' : 'Add' ?> Student</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        html,
        body {
            background: #f3f7fd;
            overflow-x: hidden;
        }

        .app-wrapper,
        .app-main,
        .app-content {
            overflow-x: hidden !important;
        }

        .container-fluid {
            max-width: 100%;
        }

        .sf-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 0.95rem 1.25rem;
            color: #fff;
            margin-bottom: 0.8rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
        }

        .sf-header h3 {
            font-size: 1.08rem;
            font-weight: 700;
            margin: 0 0 0.12rem;
            line-height: 1.2;
        }

        .sf-header p {
            margin: 0;
            font-size: 0.8rem;
            opacity: 0.88;
            line-height: 1.25;
        }

        .sf-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            background: rgba(255, 255, 255, 0.15);
            border: 1.5px solid rgba(255, 255, 255, 0.3);
            border-radius: 999px;
            padding: 0.38rem 0.85rem;
            font-size: 0.8rem;
            font-weight: 700;
            color: #fff;
            white-space: nowrap;
        }

        .sf-card {
            background: #fff;
            border: 1px solid #dce8f8;
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18, 72, 168, 0.06);
            overflow: hidden;
            margin-bottom: 0.8rem;
        }

        .sf-card-head {
            padding: 0.72rem 1rem;
            border-bottom: 1px solid #e8f0fb;
            display: flex;
            align-items: center;
            gap: 0.65rem;
            background: #fff;
        }

        .sf-card-icon {
            width: 34px;
            height: 34px;
            border-radius: 10px;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.9rem;
        }

        .icon-blue {
            background: #eef4ff;
            color: #1248a8;
        }

        .icon-green {
            background: #e8fbf1;
            color: #0f6c45;
        }

        .icon-purple {
            background: #f3ebff;
            color: #6a1ea8;
        }

        .sf-card-title {
            font-size: 0.88rem;
            font-weight: 700;
            color: #132f62;
            margin: 0 0 0.06rem;
            line-height: 1.15;
        }

        .sf-card-subtitle {
            font-size: 0.72rem;
            color: #7a93b8;
            margin: 0;
            line-height: 1.15;
        }

        .sf-card-body {
            padding: 0.85rem 1rem;
        }

        .sf-card-foot {
            padding: 0.68rem 1rem;
            border-top: 1px solid #e8f0fb;
            background: #fafcff;
            display: flex;
            justify-content: flex-end;
            gap: 0.5rem;
            flex-wrap: wrap;
        }

        .sf-top-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0.8rem;
            margin-bottom: 0.8rem;
        }

        .sf-top-row .sf-card {
            margin-bottom: 0;
        }

        .sf-label {
            font-size: 0.73rem;
            font-weight: 700;
            color: #3b5e96;
            margin-bottom: 0.22rem;
            display: block;
            line-height: 1.1;
        }

        .sf-label .req {
            color: #e05252;
            margin-left: 2px;
        }

        .sf-input,
        .sf-select {
            display: block;
            width: 100%;
            border-radius: 9px;
            border: 1.5px solid #c8daf8;
            padding: 0.38rem 0.72rem;
            font-size: 0.84rem;
            color: #213a5e;
            background: #fff;
            transition: border-color 0.15s, box-shadow 0.15s;
            min-height: 36px;
            box-sizing: border-box;
        }

        .sf-input:focus,
        .sf-select:focus {
            border-color: #1a6ef5;
            outline: none;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.1);
        }

        .sf-input.err,
        .sf-select.err {
            border-color: #e05252;
            box-shadow: 0 0 0 3px rgba(224, 82, 82, 0.1);
        }

        .sf-note {
            font-size: 0.68rem;
            color: #9ab0c8;
            margin-top: 0.18rem;
            line-height: 1.15;
        }

        .g2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0.6rem;
        }

        .g3 {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 0.6rem;
        }

        .sf-hr {
            border: 0;
            border-top: 1px solid #e8f0fb;
            margin: 0.58rem 0;
        }

        .sf-val {
            background: #fff0f0;
            border: 1.5px solid #f7b8b8;
            border-radius: 12px;
            padding: 0.65rem 0.9rem;
            margin-bottom: 0.7rem;
            display: none;
        }

        .sf-val.show {
            display: block;
        }

        .sf-val-title {
            font-size: 0.8rem;
            font-weight: 700;
            color: #c0392b;
            margin-bottom: 0.25rem;
        }

        .sf-val-list {
            margin: 0;
            padding-left: 1.05rem;
            font-size: 0.78rem;
            color: #c0392b;
        }

        .sf-alert {
            border-radius: 12px;
            padding: 0.6rem 0.9rem;
            margin-bottom: 0.7rem;
            font-size: 0.82rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.45rem;
        }

        .sf-alert.ok {
            background: #e6f7ed;
            color: #0a6b47;
            border: 1.5px solid #a0dfc8;
        }

        .sf-alert.err {
            background: #fff0f0;
            color: #c0392b;
            border: 1.5px solid #f7b8b8;
        }

        .btn-sf {
            font-weight: 600;
            font-size: 0.8rem;
            border-radius: 8px;
            padding: 0.42rem 0.9rem;
            cursor: pointer;
            transition: all 0.14s;
            border: 1.5px solid transparent;
            line-height: 1.35;
            display: inline-flex;
            align-items: center;
            gap: 0.28rem;
            text-decoration: none;
        }

        .btn-sf-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            box-shadow: 0 2px 8px rgba(26, 110, 245, 0.2);
        }

        .btn-sf-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
        }

        .btn-sf-outline {
            background: #fff;
            color: #1a6ef5;
            border-color: #dce8f8;
        }

        .btn-sf-outline:hover {
            background: #eef4ff;
            border-color: #9cc2fc;
        }

        .sf-hidden {
            display: none !important;
            z`
        }

        @media (max-width: 991px) {
            .sf-top-row {
                grid-template-columns: 1fr;
            }

            .g3 {
                grid-template-columns: 1fr 1fr;
            }
        }

        @media (max-width: 640px) {
            .sf-header {
                padding: 0.9rem 1rem;
                border-radius: 14px;
            }

            .g2,
            .g3 {
                grid-template-columns: 1fr;
            }

            .sf-card-foot {
                flex-direction: column;
            }

            .sf-card-foot .btn-sf {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <div class="app-wrapper">
        <?php require_once("includes/header.php"); ?>
        <?php require_once("includes/sidebar.php"); ?>

        <main class="app-main">
            <div class="app-content">
                <div class="container-fluid py-2">

                    <div class="sf-header">
                        <div>
                            <h3><i
                                    class="bi bi-person-<?= $edit ? 'gear' : 'plus' ?> me-2"></i><?= $edit ? 'Edit Student' : 'Add New Student' ?>
                            </h3>
                            <p><?= $edit
                                ? 'Update student record for ' . htmlspecialchars(trim(($old['fname'] ?? '') . ' ' . ($old['lname'] ?? '')))
                                : 'Fill in all required fields to register a new student.' ?>
                            </p>
                        </div>
                        <span class="sf-chip">
                            <i class="bi bi-person-vcard-fill"></i>
                            <?= $edit ? 'Edit Mode' : 'New Registration' ?>
                        </span>
                    </div>

                    <?php if (isset($_GET['msg'])): ?>
                    <div class="sf-alert ok"><i
                            class="bi bi-check-circle-fill"></i><?= htmlspecialchars($_GET['msg']) ?></div>
                    <?php endif; ?>

                    <?php if (isset($_GET['error'])): ?>
                    <div class="sf-alert err"><i
                            class="bi bi-exclamation-triangle-fill"></i><?= htmlspecialchars($_GET['error']) ?></div>
                    <?php endif; ?>

                    <?php if (isset($_GET['duplicate'])): ?>
                    <div class="sf-alert err"><i class="bi bi-exclamation-triangle-fill"></i>LRN already exists. Please
                        check and try again.</div>
                    <?php endif; ?>

                    <form method="post" action="api/student/save.php" id="sfForm" novalidate>
                        <input type="hidden" name="id" value="<?= $id ?>">

                        <div class="sf-val" id="sfVal">
                            <div class="sf-val-title"><i class="bi bi-exclamation-triangle-fill me-1"></i>Please
                                complete the required fields:</div>
                            <ul class="sf-val-list" id="sfValList"></ul>
                        </div>

                        <div class="sf-top-row">

                            <div class="sf-card">
                                <div class="sf-card-head">
                                    <div class="sf-card-icon icon-blue"><i class="bi bi-person-badge"></i></div>
                                    <div>
                                        <p class="sf-card-title">Student Information</p>
                                        <p class="sf-card-subtitle">Personal details and academic placement</p>
                                    </div>
                                </div>

                                <div class="sf-card-body">
                                    <div class="g2" style="margin-bottom:.6rem;">
                                        <div>
                                            <label class="sf-label">LRN <span class="req">*</span></label>
                                            <input class="sf-input" type="text" name="lrn" required maxlength="12"
                                                placeholder="12-digit LRN" value="<?= v($old, 'lrn') ?>">
                                        </div>

                                        <div>
                                            <label class="sf-label">Grade Level <span class="req">*</span></label>
                                            <select class="sf-select" name="grade_level_id" id="gradeLevelSelect"
                                                required>
                                                <option value="">Select Grade</option>
                                                <?php foreach ($grades as $g): ?>
                                                <option value="<?= $g['id'] ?>" <?= sel($old, 'grade_level_id', $g['id']) ?>>
                                                    <?= htmlspecialchars($g['grade_level_name']) ?>
                                                </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="g2 sf-hidden" id="strandWrap" style="margin-bottom:.6rem;">
                                        <div>
                                            <label class="sf-label">Strand <span class="req">*</span></label>
                                            <select class="sf-select" name="strand" id="strandSelect">
                                                <option value="">Select Strand</option>
                                                <option value="ABM" <?= ($oldStrand === 'ABM') ? 'selected' : '' ?>>ABM
                                                </option>
                                                <option value="GAS" <?= ($oldStrand === 'GAS') ? 'selected' : '' ?>>GAS
                                                </option>
                                                <option value="STEAM" <?= ($oldStrand === 'STEAM') ? 'selected' : '' ?>>
                                                    STEM</option>
                                                <option value="HUMSS" <?= ($oldStrand === 'HUMSS') ? 'selected' : '' ?>>
                                                    HUMSS</option>
                                            </select>
                                            <div class="sf-note">This is only required for Grade 11 and Grade 12.</div>
                                        </div>
                                    </div>

                                    <hr class="sf-hr">

                                    <div class="g3" style="margin-bottom:.6rem;">
                                        <div>
                                            <label class="sf-label">First Name <span class="req">*</span></label>
                                            <input class="sf-input" type="text" name="fname" required
                                                value="<?= v($old, 'fname') ?>">
                                        </div>

                                        <div>
                                            <label class="sf-label">Middle Name</label>
                                            <input class="sf-input" type="text" name="mname"
                                                value="<?= v($old, 'mname') ?>">
                                        </div>

                                        <div>
                                            <label class="sf-label">Last Name <span class="req">*</span></label>
                                            <input class="sf-input" type="text" name="lname" required
                                                value="<?= v($old, 'lname') ?>">
                                        </div>
                                    </div>

                                    <div class="g3">
                                        <div>
                                            <label class="sf-label">Birthdate <span class="req">*</span></label>
                                            <input class="sf-input" type="date" name="birthdate" required
                                                value="<?= v($old, 'birthdate') ?>">
                                        </div>

                                        <div>
                                            <label class="sf-label">Sex <span class="req">*</span></label>
                                            <select class="sf-select" name="gender" required>
                                                <option value="">Select</option>
                                                <option value="Male" <?= sel($old, 'gender', 'Male') ?>>Male</option>
                                                <option value="Female" <?= sel($old, 'gender', 'Female') ?>>Female
                                                </option>
                                            </select>
                                        </div>

                                        <div>
                                            <label class="sf-label">Citizenship</label>
                                            <input class="sf-input" type="text" name="citizenship"
                                                placeholder="e.g. Filipino" value="<?= v($old, 'citizenship') ?>">
                                        </div>
                                    </div>

                                    <!-- â”€â”€ NEW Email Field â”€â”€ -->
                                    <div style="margin-top:0.6rem;">
                                        <label class="sf-label">Email</label>
                                        <input class="sf-input" type="email" name="email"
                                            placeholder="email@example.com" value="<?= v($old, 'email') ?>">
                                        <div class="sf-note">Optional. Used for notifications and communication.</div>
                                    </div>
                                </div>
                            </div>

                            <div class="sf-card">
                                <div class="sf-card-head">
                                    <div class="sf-card-icon icon-green"><i class="bi bi-people-fill"></i></div>
                                    <div>
                                        <p class="sf-card-title">Parents / Guardian</p>
                                        <p class="sf-card-subtitle">Contact information for parents or legal guardian
                                        </p>
                                    </div>
                                </div>

                                <div class="sf-card-body">
                                    <div class="g2" style="margin-bottom:.6rem;">
                                        <div>
                                            <label class="sf-label">Father's Name <span class="req">*</span></label>
                                            <input class="sf-input" type="text" name="fathers_name" required
                                                value="<?= v($old, 'fathers_name') ?>">
                                        </div>

                                        <div>
                                            <label class="sf-label">Father's Contact <span class="req">*</span></label>
                                            <input class="sf-input" type="text" name="fathers_contact_num" required
                                                placeholder="09XXXXXXXXX" value="<?= v($old, 'fathers_contact_num') ?>">
                                        </div>

                                        <div>
                                            <label class="sf-label">Mother's Name <span class="req">*</span></label>
                                            <input class="sf-input" type="text" name="mothers_name" required
                                                value="<?= v($old, 'mothers_name') ?>">
                                        </div>

                                        <div>
                                            <label class="sf-label">Mother's Contact <span class="req">*</span></label>
                                            <input class="sf-input" type="text" name="mothers_contact_num" required
                                                placeholder="09XXXXXXXXX" value="<?= v($old, 'mothers_contact_num') ?>">
                                        </div>
                                    </div>

                                    <hr class="sf-hr">

                                    <div class="g2">
                                        <div>
                                            <label class="sf-label">Guardian Name <span class="req">*</span></label>
                                            <input class="sf-input" type="text" name="guardian_name" required
                                                value="<?= v($old, 'guardian_name') ?>">
                                        </div>

                                        <div>
                                            <label class="sf-label">Guardian Contact <span class="req">*</span></label>
                                            <input class="sf-input" type="text" name="guardian_contact_num" required
                                                placeholder="09XXXXXXXXX"
                                                value="<?= v($old, 'guardian_contact_num') ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="sf-card">
                            <div class="sf-card-head">
                                <div class="sf-card-icon icon-purple"><i class="bi bi-geo-alt-fill"></i></div>
                                <div>
                                    <p class="sf-card-title">Address Info</p>
                                    <p class="sf-card-subtitle">Complete the full home location for the student record
                                    </p>
                                </div>
                            </div>

                            <div class="sf-card-body">
                                <div class="g3" style="margin-bottom:.55rem;">
                                    <div>
                                        <label class="sf-label">Street / House No. <span class="req">*</span></label>
                                        <input class="sf-input" type="text" name="street_name" required
                                            value="<?= v($old, 'street_name') ?>">
                                    </div>

                                    <div>
                                        <label class="sf-label">Country <span class="req">*</span></label>
                                        <select class="sf-select" id="country" name="country_id" required>
                                            <option value="">Select Country</option>
                                            <?php foreach ($countries as $c): ?>
                                            <option value="<?= $c['id'] ?>" <?= $oldCountry == $c['id'] ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($c['country_name']) ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>

                                    <div>
                                        <label class="sf-label">Region <span class="req">*</span></label>
                                        <select class="sf-select" id="region" name="region_id" required>
                                            <option value="">Select Region</option>
                                        </select>
                                    </div>

                                    <div>
                                        <label class="sf-label">Province <span class="req">*</span></label>
                                        <select class="sf-select" id="province" name="province_id" required>
                                            <option value="">Select Province</option>
                                        </select>
                                    </div>

                                    <div>
                                        <label class="sf-label">City / Municipality <span class="req">*</span></label>
                                        <select class="sf-select" id="city" name="city_id" required>
                                            <option value="">Select City</option>
                                        </select>
                                    </div>

                                    <div>
                                        <label class="sf-label">Barangay <span class="req">*</span></label>
                                        <select class="sf-select" id="barangay" name="barangay_id" required>
                                            <option value="">Select Barangay</option>
                                        </select>
                                    </div>
                                </div>

                                <div style="max-width:280px;">
                                    <label class="sf-label">Postal Code</label>
                                    <input class="sf-input" type="text" name="postal_code" placeholder="e.g. 1105"
                                        value="<?= v($old, 'postal_code') ?>">
                                    <div class="sf-note">Optional, but helpful for complete records.</div>
                                </div>
                            </div>

                            <div class="sf-card-foot">
                                <a href="student.php" class="btn-sf btn-sf-outline">
                                    <i class="bi bi-arrow-left"></i> Cancel
                                </a>
                                <button type="submit" class="btn-sf btn-sf-primary">
                                    <i class="bi bi-floppy2-fill"></i>
                                    <?= $edit ? 'Update Student' : 'Save Student' ?>
                                </button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </main>

        <?php require_once("includes/footer.php"); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./js/adminlte.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script src="./js/sweet-alerts.js"></script>
    <script>
        const regions = <?= json_encode($regions) ?>;
        const provinces = <?= json_encode($provinces) ?>;
        const cities = <?= json_encode($cities) ?>;
        const barangays = <?= json_encode($barangays) ?>;

        const initialToastType = <?= json_encode($toastType) ?>;
        const initialToastMessage = <?= json_encode($toastMessage) ?>;

        function showAlert(message, type = 'success') {
            AppAlerts.showToast(message, type);
        }

        function fill(select, list, nameField, placeholder, preSel = null) {
            const current = select.value;
            select.innerHTML = `<option value="">${placeholder}</option>`;

            list.forEach(item => {
                const opt = document.createElement('option');
                opt.value = item.id;
                opt.textContent = item[nameField];

                if (String(opt.value) === String(current) || String(opt.value) === String(preSel)) {
                    opt.selected = true;
                }

                select.appendChild(opt);
            });
        }

        function isSeniorHighGrade(selectEl) {
            if (!selectEl || !selectEl.value) return false;

            const selectedOption = selectEl.options[selectEl.selectedIndex];
            const selectedValue = String(selectEl.value).trim();
            const selectedText = String(selectedOption ? selectedOption.textContent : '').trim().toLowerCase();

            return selectedValue === '12' || selectedValue === '13' || selectedText === 'grade 11' || selectedText === 'grade 12';
        }

        function toggleStrandField() {
            const gradeSelect = document.getElementById('gradeLevelSelect');
            const strandWrap = document.getElementById('strandWrap');
            const strandSelect = document.getElementById('strandSelect');

            if (!gradeSelect || !strandWrap || !strandSelect) return;

            if (isSeniorHighGrade(gradeSelect)) {
                strandWrap.classList.remove('sf-hidden');
                strandSelect.setAttribute('required', 'required');
            } else {
                strandWrap.classList.add('sf-hidden');
                strandSelect.removeAttribute('required');
                strandSelect.value = '';
                strandSelect.classList.remove('err');
            }
        }

        document.addEventListener('DOMContentLoaded', () => {
            const form = document.getElementById('sfForm');
            const box = document.getElementById('sfVal');
            const list = document.getElementById('sfValList');

            const elCountry = document.getElementById('country');
            const elRegion = document.getElementById('region');
            const elProvince = document.getElementById('province');
            const elCity = document.getElementById('city');
            const elBarangay = document.getElementById('barangay');
            const gradeLevelSelect = document.getElementById('gradeLevelSelect');

            if (initialToastType && initialToastMessage) {
                showAlert(initialToastMessage, initialToastType);
            }

            if (+elCountry.value) {
                fill(elRegion, regions.filter(r => String(r.country_id) === String(elCountry.value)), 'region_name', 'Select Region', <?= json_encode($oldRegion) ?>);

                if (elRegion.value || <?= json_encode((string) $oldRegion) ?>) {
                    fill(elProvince, provinces.filter(p => String(p.region_id) === String(elRegion.value || <?= json_encode((string) $oldRegion) ?>)), 'province_name', 'Select Province', <?= json_encode($oldProvince) ?>);
                }

                if (elProvince.value || <?= json_encode((string) $oldProvince) ?>) {
                    fill(elCity, cities.filter(c => String(c.province_id) === String(elProvince.value || <?= json_encode((string) $oldProvince) ?>)), 'city_name', 'Select City', <?= json_encode($oldCity) ?>);
                }

                if (elCity.value || <?= json_encode((string) $oldCity) ?>) {
                    fill(elBarangay, barangays.filter(b => String(b.city_id) === String(elCity.value || <?= json_encode((string) $oldCity) ?>)), 'barangay_name', 'Select Barangay', <?= json_encode($oldBarangay) ?>);
                }
            }

            elCountry.addEventListener('change', () => {
                fill(elRegion, regions.filter(r => String(r.country_id) === String(elCountry.value)), 'region_name', 'Select Region');
                elProvince.innerHTML = '<option value="">Select Province</option>';
                elCity.innerHTML = '<option value="">Select City</option>';
                elBarangay.innerHTML = '<option value="">Select Barangay</option>';
            });

            elRegion.addEventListener('change', () => {
                fill(elProvince, provinces.filter(p => String(p.region_id) === String(elRegion.value)), 'province_name', 'Select Province');
                elCity.innerHTML = '<option value="">Select City</option>';
                elBarangay.innerHTML = '<option value="">Select Barangay</option>';
            });

            elProvince.addEventListener('change', () => {
                fill(elCity, cities.filter(c => String(c.province_id) === String(elProvince.value)), 'city_name', 'Select City');
                elBarangay.innerHTML = '<option value="">Select Barangay</option>';
            });

            elCity.addEventListener('change', () => {
                fill(elBarangay, barangays.filter(b => String(b.city_id) === String(elCity.value)), 'barangay_name', 'Select Barangay');
            });

            if (gradeLevelSelect) {
                toggleStrandField();
                gradeLevelSelect.addEventListener('change', toggleStrandField);
            }

            form.addEventListener('submit', function (e) {
                toggleStrandField();

                const requiredFields = [...this.querySelectorAll('[required]')].filter(el => {
                    return !el.closest('.sf-hidden');
                });

                const missing = requiredFields.filter(el => !String(el.value).trim());

                requiredFields.forEach(el => {
                    if (String(el.value).trim()) {
                        el.classList.remove('err');
                    } else {
                        el.classList.add('err');
                    }
                });

                if (missing.length) {
                    e.preventDefault();

                    list.innerHTML = missing.map(el => {
                        const label = el.closest('div')?.querySelector('.sf-label')?.textContent?.replace('*', '').trim() || el.name;
                        return `<li>${label}</li>`;
                    }).join('');

                    box.classList.add('show');
                    box.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    showAlert('Please complete the required fields first.', 'warning');
                } else {
                    box.classList.remove('show');
                    list.innerHTML = '';
                }
            });

            form.addEventListener('input', function (e) {
                if (String(e.target.value).trim()) {
                    e.target.classList.remove('err');
                }
            });

            form.addEventListener('change', function (e) {
                if (String(e.target.value).trim()) {
                    e.target.classList.remove('err');
                }
            });
        });
    </script>
</body>

</html>


