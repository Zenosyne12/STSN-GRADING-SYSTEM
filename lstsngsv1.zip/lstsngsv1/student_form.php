<?php
require_once 'includes/auth.php';
requireAdmin();
require_once __DIR__ . '/api/shared/db_connect.php';

$id   = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$edit = ($id > 0);

if ($edit) {
    $stmt = $pdo->prepare('SELECT * FROM tblstudents WHERE id = ?');
    $stmt->execute([$id]);
    $old = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$old) {
        header('Location: Student.php');
        exit;
    }

    $addrStmt = $pdo->prepare("
        SELECT
            s.barangay_id,
            s.postal_code,
            COALESCE(s.city_id, b.city_id) AS city_id,
            COALESCE(s.province_id, c.province_id) AS province_id,
            COALESCE(p.region_id, s.region_id) AS region_id,
            COALESCE(r.country_id, s.country_id) AS country_id
        FROM tblstudents s
        LEFT JOIN tblbarangay b ON b.id = s.barangay_id
        LEFT JOIN tblcity c ON c.id = COALESCE(s.city_id, b.city_id)
        LEFT JOIN tblprovince p ON p.id = COALESCE(s.province_id, c.province_id)
        LEFT JOIN tblregion r ON r.id = COALESCE(s.region_id, p.region_id)
        WHERE s.id = ?
        LIMIT 1
    ");
    $addrStmt->execute([$id]);
    $savedAddress = $addrStmt->fetch(PDO::FETCH_ASSOC);

    if ($savedAddress) {
        foreach (['country_id', 'region_id', 'province_id', 'city_id', 'barangay_id'] as $addressField) {
            if (!empty($savedAddress[$addressField])) {
                $old[$addressField] = $savedAddress[$addressField];
            }
        }
    }

    $clusterStmt = $pdo->prepare('SELECT cluster_id FROM tblstudents WHERE id = ? LIMIT 1');
    $clusterStmt->execute([$id]);
    $old['cluster_id'] = $clusterStmt->fetchColumn() ?: '';
} else {
    $old = [];
}

$grades    = $pdo->query('SELECT id, grade_level_name FROM tblGradeLevel ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
$clusters  = $pdo->query('SELECT id, cluster_name, track FROM tblclusters WHERE is_active = 1 ORDER BY cluster_name')->fetchAll(PDO::FETCH_ASSOC);
$countries = $pdo->query('SELECT id, country_name FROM tblCountry ORDER BY country_name')->fetchAll(PDO::FETCH_ASSOC);

$oldCountry  = $old['country_id']  ?? '';
$oldRegion   = $old['region_id']   ?? '';
$oldProvince = $old['province_id'] ?? '';
$oldCity     = $old['city_id']     ?? '';
$oldBarangay = $old['barangay_id'] ?? '';
$oldStrand   = $old['strand'] ?? '';
if ($oldStrand === 'Technical-Professional (Tech-Pro)') {
    $oldStrand = 'Tech-Pro';
}

$toastType = null;
$toastMessage = '';

if (isset($_GET['duplicate'])) {
    $toastType = 'danger';
    $toastMessage = 'LRN already exists!';
} elseif (isset($_GET['error'])) {
    $toastType = 'danger';
    $toastMessage = (string) $_GET['error'];
} elseif (isset($_GET['warning'])) {
    $toastType = 'warning';
    $toastMessage = (string) $_GET['warning'];
} elseif (isset($_GET['msg'])) {
    $toastType = 'success';
    $toastMessage = (string) $_GET['msg'];
}

function v(array $a, string $k): string
{
    return htmlspecialchars($a[$k] ?? '', ENT_QUOTES, 'UTF-8');
}

function sel(array $a, string $k, $v): string
{
    return (($a[$k] ?? '') == $v) ? 'selected' : '';
}

function tableColumnExists(PDO $pdo, string $tableName, string $columnName): bool
{
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = ?
          AND COLUMN_NAME = ?
    ");
    $stmt->execute([$tableName, $columnName]);
    return (int) $stmt->fetchColumn() > 0;
}
?>
<!doctype html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
    <meta charset="utf-8">
    <title>STSN | <?= $edit ? 'Edit' : 'Add' ?> Student</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        /* ============================================================
           THEME VARIABLES (Light & Dark)
           ============================================================ */
        :root,
        [data-bs-theme="light"] {
            --sf-page-bg: #f3f7fd;
            --sf-card-bg: #ffffff;
            --sf-card-soft: #fafcff;
            --sf-border: #dce8f8;
            --sf-border-soft: #e8f0fb;
            --sf-text: #213a5e;
            --sf-text-strong: #132f62;
            --sf-text-muted: #7a93b8;
            --sf-text-dim: #9ab0c8;
            --sf-label: #3b5e96;
            --sf-input-bg: #ffffff;
            --sf-input-border: #c8daf8;
            --sf-input-text: #213a5e;
            --sf-input-placeholder: #9ab0c8;
            --sf-head-bg: #ffffff;
            --sf-shadow: rgba(18, 72, 168, 0.06);

            --sf-icon-blue-bg: #eef4ff;
            --sf-icon-blue-text: #1248a8;
            --sf-icon-green-bg: #e8fbf1;
            --sf-icon-green-text: #0f6c45;
            --sf-icon-purple-bg: #f3ebff;
            --sf-icon-purple-text: #6a1ea8;

            --sf-btn-outline-bg: #ffffff;
            --sf-btn-outline-text: #1a6ef5;
            --sf-btn-outline-border: #dce8f8;
            --sf-btn-outline-hover-bg: #eef4ff;
            --sf-btn-outline-hover-border: #9cc2fc;

            --sf-req: #e05252;
        }

        [data-bs-theme="dark"] {
            --sf-page-bg: #1a1a1a;
            --sf-card-bg: #2D2D2D;
            --sf-card-soft: #262626;
            --sf-border: #3a3a3a;
            --sf-border-soft: #3a3a3a;
            --sf-text: #e4e6e8;
            --sf-text-strong: #ffffff;
            --sf-text-muted: #adb5bd;
            --sf-text-dim: #8b939a;
            --sf-label: #ffffff;
            --sf-input-bg: #3a3a3a;
            --sf-input-border: #4a5a6e;
            --sf-input-text: #e4e6e8;
            --sf-input-placeholder: #adb5bd;
            --sf-head-bg: #2D2D2D;
            --sf-shadow: rgba(0, 0, 0, 0.35);

            --sf-icon-blue-bg: #1e2a3d;
            --sf-icon-blue-text: #8ab4f8;
            --sf-icon-green-bg: #17351f;
            --sf-icon-green-text: #6ee7a0;
            --sf-icon-purple-bg: #2d1e42;
            --sf-icon-purple-text: #c4b5fd;

            --sf-btn-outline-bg: #3a3a3a;
            --sf-btn-outline-text: #8ab4f8;
            --sf-btn-outline-border: #4a5a6e;
            --sf-btn-outline-hover-bg: #4a4a4a;
            --sf-btn-outline-hover-border: #6a7a8e;

            --sf-req: #ff8b9e;
        }

        /* ============================================================
           BASE
           ============================================================ */
        html, body {
            min-height: 100%;
            margin: 0;
            background: var(--sf-page-bg);
            overflow-x: hidden;
            color: var(--sf-text);
        }

        body {
            font-family: "Source Sans 3", sans-serif;
        }

        .app-wrapper,
        .app-main,
        .app-content {
            overflow-x: hidden !important;
        }

        /* <main tabindex="-1"> was showing a white focus outline around the
           whole content area. It is not an interactive element, so hide it. */
        .app-main:focus,
        .app-main:focus-visible,
        #main:focus,
        #main:focus-visible {
            outline: none !important;
        }

        [data-bs-theme="dark"] .app-main,
        [data-bs-theme="dark"] .app-content {
            background: var(--sf-page-bg) !important;
        }

        .container-fluid {
            max-width: 100%;
        }

        /* ============================================================
           SIDEBAR FIX v2 (stretch to full viewport height + scroll)
           ============================================================ */
        /* Outer sidebar = fixed full-viewport-height container */
        .app-sidebar,
        .main-sidebar,
        .custom-sidebar,
        .sidebar-wrapper {
            box-sizing: border-box !important;
        }

        /* Sidebar override removed — broke breadcrumb clicks by overlapping
           .app-main with the fixed sidebar (the fixed <aside> left the grid
           flow, collapsing the 250px column so content sat underneath it).
           AdminLTE grid layout now applies. Flex/scroll behaviour is kept;
           position/top/left/bottom/height/z-index were dropped. */
        .app-sidebar,
        .main-sidebar,
        .custom-sidebar {
            max-height: 100vh !important;
            max-height: 100dvh !important;
            display: flex !important;
            flex-direction: column !important;
            overflow: hidden !important;   /* stop body from scrolling sidebar */
            padding-bottom: 0 !important;
        }

        /* The scrollable wrapper INSIDE the sidebar */
        .app-sidebar > .sidebar-wrapper,
        .main-sidebar > .sidebar-wrapper,
        .custom-sidebar > .sidebar-wrapper {
            flex: 1 1 auto !important;
            min-height: 0 !important;
            height: auto !important;
            max-height: none !important;
            overflow-y: auto !important;
            overflow-x: hidden !important;
            padding-bottom: 90px !important;   /* breathing room at bottom */
            display: flex !important;
            flex-direction: column !important;
            scrollbar-width: thin;
            scrollbar-color: rgba(140, 160, 190, .45) transparent;
            align-self: stretch !important;
        }

        /* Brand stays fixed at top */
        .app-sidebar .sidebar-brand,
        .main-sidebar .sidebar-brand,
        .custom-sidebar .sidebar-brand {
            flex: 0 0 auto !important;
        }

        /* Menu fills remaining space; scrolls if too tall */
        .app-sidebar .sidebar-menu,
        .main-sidebar .sidebar-menu,
        .custom-sidebar .sidebar-menu,
        .app-sidebar .sidebar-wrapper nav,
        .main-sidebar .sidebar-wrapper nav {
            flex: 1 1 auto !important;
            min-height: 0 !important;
        }

        /* Custom scrollbar (Webkit) */
        .app-sidebar > .sidebar-wrapper::-webkit-scrollbar,
        .main-sidebar > .sidebar-wrapper::-webkit-scrollbar,
        .custom-sidebar > .sidebar-wrapper::-webkit-scrollbar {
            width: 6px;
        }
        .app-sidebar > .sidebar-wrapper::-webkit-scrollbar-track,
        .main-sidebar > .sidebar-wrapper::-webkit-scrollbar-track,
        .custom-sidebar > .sidebar-wrapper::-webkit-scrollbar-track {
            background: transparent;
        }
        .app-sidebar > .sidebar-wrapper::-webkit-scrollbar-thumb,
        .main-sidebar > .sidebar-wrapper::-webkit-scrollbar-thumb,
        .custom-sidebar > .sidebar-wrapper::-webkit-scrollbar-thumb {
            background: rgba(140, 160, 190, .45);
            border-radius: 10px;
        }
        .app-sidebar > .sidebar-wrapper::-webkit-scrollbar-thumb:hover,
        .main-sidebar > .sidebar-wrapper::-webkit-scrollbar-thumb:hover,
        .custom-sidebar > .sidebar-wrapper::-webkit-scrollbar-thumb:hover {
            background: rgba(140, 160, 190, .75);
        }

        /* Dark mode sidebar colors */
        [data-bs-theme="dark"] .app-sidebar,
        [data-bs-theme="dark"] .sidebar-wrapper,
        [data-bs-theme="dark"] .main-sidebar,
        [data-bs-theme="dark"] .custom-sidebar {
            background-color: #2D2D2D !important;
            color: #e4e6e8 !important;
        }

        [data-bs-theme="dark"] .sidebar-wrapper a,
        [data-bs-theme="dark"] .sidebar-wrapper .nav-link,
        [data-bs-theme="dark"] .sidebar-wrapper .sidebar-brand-text {
            color: #e4e6e8 !important;
        }

        [data-bs-theme="dark"] .sidebar-wrapper .nav-link:hover,
        [data-bs-theme="dark"] .sidebar-wrapper .nav-link.active {
            background-color: #3a3a3a !important;
            color: #ffffff !important;
        }

        /* ============================================================
           PAGE HEADER (keep gradient)
           ============================================================ */
        .sf-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: .75rem;
            flex-shrink: 0;
        }

        .sf-header-row { display: flex; align-items: flex-start; gap: .7rem; }
        .sf-header-icon { width: 30px; height: 30px; border-radius: 10px; background: rgba(255,255,255,.16); display:flex; align-items:center; justify-content:center; flex-shrink:0; }
        .sf-header-close { margin-left:auto; color:#fff; border:0; background:transparent; font-size:1rem; padding:.1rem .2rem; cursor:pointer; }

        .sf-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 0.2rem;
            line-height: 1.2;
            letter-spacing: .01em;
        }

        .sf-header p {
            margin: 0;
            font-size: .88rem;
            opacity: .85;
            line-height: 1.25;
        }

        /* .sf-breadcrumb removed — unused (header uses .sf-header styling). */

        .sf-step {
            display: none;
            width: 100%;
        }
        .sf-step.active {
            display: block;
        }

        /* ============================================================
           CARDS
           ============================================================ */
        .sf-card {
            background: var(--sf-card-bg);
            border: 1px solid var(--sf-border);
            border-radius: 16px;
            box-shadow: 0 2px 12px var(--sf-shadow);
            overflow: hidden;
            margin-bottom: 0;
        }

        .sf-card-head {
            padding: 0.72rem 1rem;
            border-bottom: 1px solid var(--sf-border-soft);
            display: flex;
            align-items: center;
            gap: 0.65rem;
            background: var(--sf-head-bg);
        }

        .sf-card-icon {
            width: 34px;
            height: 34px;
            border-radius: 10px;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.9rem;
        }

        .icon-blue { background: var(--sf-icon-blue-bg); color: var(--sf-icon-blue-text); }
        .icon-green { background: var(--sf-icon-green-bg); color: var(--sf-icon-green-text); }
        .icon-purple { background: var(--sf-icon-purple-bg); color: var(--sf-icon-purple-text); }

        .sf-card-title {
            font-size: 0.88rem;
            font-weight: 700;
            color: var(--sf-text-strong);
            margin: 0 0 0.06rem;
            line-height: 1.15;
        }

        .sf-card-subtitle {
            font-size: 0.72rem;
            color: var(--sf-text-muted);
            margin: 0;
            line-height: 1.15;
        }

        .sf-card-body {
            padding: 0.85rem 1rem;
            background: var(--sf-card-bg);
        }

        .sf-card-foot {
            padding: 0.68rem 1rem;
            border-top: 1px solid var(--sf-border-soft);
            background: var(--sf-card-soft);
            display: flex;
            justify-content: flex-end;
            gap: 0.5rem;
            flex-wrap: wrap;
        }

        .sf-card { margin-bottom:.8rem; }
        .sf-required-note { padding:0 .95rem .55rem; color:var(--sf-text-dim); font-size:.68rem; flex-shrink:0; }
        .sf-required-note span { color:var(--sf-req); font-weight:700; }
        .sf-step-count { margin-left:auto; color:var(--sf-text-dim); font-size:.68rem; }

        /* ============================================================
           FORM LABELS & INPUTS
           ============================================================ */
        .sf-label {
            font-size: 0.73rem;
            font-weight: 700;
            color: var(--sf-label);
            margin-bottom: 0.22rem;
            display: block;
            line-height: 1.1;
        }

        .sf-label .req { color: var(--sf-req); margin-left: 2px; }

        .sf-input,
        .sf-select {
            display: block;
            width: 100%;
            border-radius: 9px;
            border: 1.5px solid var(--sf-input-border);
            padding: 0.38rem 0.72rem;
            font-size: 0.84rem;
            color: var(--sf-input-text);
            background: var(--sf-input-bg);
            transition: border-color 0.15s, box-shadow 0.15s;
            min-height: 36px;
            box-sizing: border-box;
        }

        .sf-input::placeholder { color: var(--sf-input-placeholder); opacity: 1; }

        .sf-input:focus,
        .sf-select:focus {
            border-color: #1a6ef5;
            outline: none;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.1);
        }

        .sf-select option { background: var(--sf-input-bg); color: var(--sf-input-text); }

        /* Native date/time picker icon.
           Let the browser draw the icon in the right colour for the active
           theme: dark icon in light mode, WHITE icon in dark mode.
           The old `filter: invert(1)` flipped it twice (Bootstrap already
           sets color-scheme: dark), which turned the icon black. */
        .sf-input[type="date"],
        .sf-input[type="time"] {
            color-scheme: light;
        }

        [data-bs-theme="dark"] .sf-input[type="date"],
        [data-bs-theme="dark"] .sf-input[type="time"] {
            color-scheme: dark;
        }

        .sf-input[type="date"]::-webkit-calendar-picker-indicator,
        .sf-input[type="time"]::-webkit-calendar-picker-indicator {
            filter: none;
            opacity: 1;
            cursor: pointer;
        }

        .sf-input.is-invalid,
        .sf-select.is-invalid {
            border-color: #dc3545 !important;
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12' width='12' height='12' fill='none' stroke='%23dc3545'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3e%3ccircle cx='6' cy='8.2' r='.6' fill='%23dc3545' stroke='none'/%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 0.75rem center;
            background-size: 16px 16px;
            padding-right: 2.5rem;
        }

        .sf-select.is-invalid { background-position: right 2rem center; }

        .sf-input.is-valid,
        .sf-select.is-valid {
            border-color: var(--sf-input-border) !important;
            background-image: none;
            padding-right: 0.72rem;
        }

        .sf-select.is-valid { background-position: right 0.72rem center; }

        .invalid-feedback {
            display: none;
            width: 100%;
            margin-top: 0.25rem;
            font-size: 0.75rem;
            color: #dc3545;
            font-weight: 600;
        }

        .invalid-feedback.show { display: block; animation: shake 0.4s ease-in-out; }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-4px); }
            75% { transform: translateX(4px); }
        }

        .sf-note {
            font-size: 0.68rem;
            color: var(--sf-text-muted);
            margin-top: 0.18rem;
            line-height: 1.15;
        }

        /* ============================================================
           GRID
           ============================================================ */
        .g2 { display: grid; grid-template-columns: 1fr 1fr; gap: 0.6rem; }
        .g3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 0.6rem; }
        .sf-hr { border: 0; border-top: 1px solid var(--sf-border-soft); margin: 0.58rem 0; }

        /* ============================================================
           BUTTONS
           ============================================================ */
        .btn-sf {
            font-weight: 600;
            font-size: 0.8rem;
            border-radius: 8px;
            padding: 0.42rem 0.9rem;
            cursor: pointer;
            transition: all 0.14s;
            border: 1.5px solid transparent;
            line-height: 1.35;
            display: inline-flex;
            align-items: center;
            gap: 0.28rem;
            text-decoration: none;
        }

        .btn-sf-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            box-shadow: 0 2px 8px rgba(26, 110, 245, 0.2);
        }

        .btn-sf-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
        }

        .btn-sf-outline {
            background: var(--sf-btn-outline-bg);
            color: var(--sf-btn-outline-text);
            border-color: var(--sf-btn-outline-border);
        }

        .btn-sf-outline:hover {
            background: var(--sf-btn-outline-hover-bg);
            border-color: var(--sf-btn-outline-hover-border);
            color: var(--sf-btn-outline-text);
        }

        .sf-back-btn { min-width:68px; }

        /* ============================================================
           BREADCRUMB
           ============================================================ */
        .student-breadcrumb {
            font-size: 0.76rem;
            color: var(--sf-text-muted);
            margin-bottom: 0.45rem;
            line-height: 1.1;
        }

        .student-breadcrumb a { color: #1a6ef5; text-decoration: none; }
        .student-breadcrumb a:hover { text-decoration: underline; }

        .sf-hidden { display: none !important; }

        .sf-shs-field-reveal > div {
            animation: sf-shs-field-pop-in 280ms cubic-bezier(0.22, 1, 0.36, 1) both;
        }

        .sf-shs-field-reveal > div:nth-child(2) {
            animation-delay: 100ms;
        }

        @keyframes sf-shs-field-pop-in {
            from {
                opacity: 0;
                transform: translateY(8px) scale(.98);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        /* ============================================================
           LAYOUT
           ============================================================ */
        /* .sf-top-row (fixed 600px grey wrapper) removed — the wizard panels
           now size to their own content, so there is no empty grey box. */
        .sf-card-foot { display:flex; justify-content:flex-end; gap:.5rem; flex-wrap:wrap; }

        /* ============================================================
           FOOTER (dark mode)
           ============================================================ */
        [data-bs-theme="dark"] .app-footer,
        [data-bs-theme="dark"] footer.main-footer {
            background: #2D2D2D !important;
            color: #adb5bd !important;
            border-top-color: #3a3a3a !important;
        }

        [data-bs-theme="dark"] .stsn-year-chip {
            background: #1e2a3d !important;
            color: #8ab4f8 !important;
            border-color: #2d4366 !important;
        }

        /* ============================================================
           RESPONSIVE
           ============================================================ */
        @media (max-width: 991px) {
            .g3 { grid-template-columns: 1fr 1fr; }
        }

        @media (max-width: 640px) {
            .g2, .g3 { grid-template-columns: 1fr; }
            .sf-card-foot { flex-direction: column; }
            .sf-card-foot .btn-sf { width: 100%; justify-content: center; }
        }
        /* ============================================================
           WIZARD (3-step) — nav buttons
           ============================================================ */
        /* Stepper styles removed — wizard now navigates via Next/Cancel only. */

        .wizard-nav {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            gap: 0.65rem;
            padding: 1rem 1.25rem 0;
            border-top: 1px solid #eef2f7;
            margin-top: 1rem;
        }

        .btn-wizard-cancel {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            padding: 0.65rem 1.3rem;
            border-radius: 10px;
            font-family: inherit;
            font-size: 0.88rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.15s;
            background: #fff;
            color: #6b7280;
            border: 1.5px solid #e5e7eb;
            text-decoration: none;
        }
        .btn-wizard-cancel:hover {
            background: #fef2f2;
            color: #dc2626;
            border-color: #fecaca;
        }

        .btn-wizard-next, .btn-wizard-save {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            padding: 0.65rem 1.3rem;
            border-radius: 10px;
            font-family: inherit;
            font-size: 0.88rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.15s;
            border: none;
        }
        .btn-wizard-next, .btn-wizard-save {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            box-shadow: 0 2px 8px rgba(26,110,245,0.25);
        }
        .btn-wizard-next:hover, .btn-wizard-save:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(26,110,245,0.3);
        }

        /* ============================================================
           WIZARD PANEL TRANSITIONS
           ============================================================ */
        @keyframes sfSlideInRight {
            from {
                opacity: 0;
                transform: translateX(20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        @keyframes sfSlideInLeft {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .sf-step.active.sf-slide-right {
            animation: sfSlideInRight 0.28s cubic-bezier(.22, 1, .36, 1) both;
        }
        .sf-step.active.sf-slide-left {
            animation: sfSlideInLeft 0.28s cubic-bezier(.22, 1, .36, 1) both;
        }

        /* ============================================================
           DARK MODE OVERRIDES (wizard nav + icons)
           ============================================================ */
        [data-bs-theme="dark"] .btn-wizard-cancel {
            background: #2D2D2D;
            color: #e2e8f0;
            border-color: #4a5a6e;
        }
        [data-bs-theme="dark"] .btn-wizard-cancel:hover {
            background: #3a2a2a;
            color: #f87171;
            border-color: #7f1d1d;
        }

        [data-bs-theme="dark"] .btn-wizard-next,
        [data-bs-theme="dark"] .btn-wizard-save {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
        }

        [data-bs-theme="dark"] .wizard-nav {
            border-top-color: #3a3a3a;
        }

        /* Cards in dark mode */
        [data-bs-theme="dark"] .sf-card {
            background: #1f1f1f;
            border-color: #3a3a3a;
        }
        [data-bs-theme="dark"] .sf-card-head {
            background: #262626;
            border-bottom-color: #3a3a3a;
        }
        [data-bs-theme="dark"] .sf-card-body input,
        [data-bs-theme="dark"] .sf-card-body select,
        [data-bs-theme="dark"] .sf-card-body textarea {
            background: #2D2D2D;
            color: #e4e6e8;
            border-color: #4a5a6e;
        }
        [data-bs-theme="dark"] .sf-card-title,
        [data-bs-theme="dark"] .sf-card-subtitle {
            color: #e4e6e8;
        }

        /* Fix icon colors that look washed out */
        [data-bs-theme="dark"] .sf-card-head .icon-blue {
            background: #1e3a8a;
            color: #93c5fd;
        }
        [data-bs-theme="dark"] .sf-card-head .icon-green {
            background: #14532d;
            color: #86efac;
        }
        [data-bs-theme="dark"] .sf-card-head .icon-purple {
            background: #4c1d95;
            color: #c4b5fd;
        }

        /* Breadcrumb in dark mode */
        [data-bs-theme="dark"] .stsn-breadcrumb {
            background: #1f1f1f;
            border-color: #3a3a3a;
        }
        [data-bs-theme="dark"] .stsn-breadcrumb a {
            color: #93c5fd;
        }
        [data-bs-theme="dark"] .stsn-breadcrumb .bc-active {
            color: #e4e6e8;
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>
    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-2">
    <header class="sf-header stsn-anim-fade-in-up">
        <div class="sf-header-row">
            <div>
                <h3><i class="bi bi-person-<?= $edit ? 'gear' : 'plus' ?> me-2"></i><?= $edit ? 'Edit Student' : 'Add New Student' ?></h3>
                <p><?= $edit ? 'Update student record for ' . htmlspecialchars(trim(($old['fname'] ?? '') . ' ' . ($old['lname'] ?? ''))) : 'Fill in all required fields to register a new student.' ?></p>
            </div>
        </div>
    </header>
    <div class="stsn-anim-fade-in-up stsn-anim-delay-100">
        <?php require_once __DIR__ . '/includes/breadcrumb.php'; renderBreadcrumb([['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'], ['label' => 'Students', 'href' => 'Student.php', 'icon' => 'bi bi-people-fill'], ['label' => $edit ? 'Edit Student' : 'Add Student', 'icon' => $edit ? 'bi bi-person-gear' : 'bi bi-person-plus-fill']]); ?>
    </div>
                <form method="post" action="api/student/save.php" id="sfForm" novalidate>
                    <input type="hidden" name="id" value="<?= $id ?>">

                    <!-- Stepper removed — user navigates via Next/Cancel only -->

                    <!-- .sf-top-row wrapper removed (it was the fixed-height grey box) -->
                    <div class="sf-step wizard-panel active" data-step="1">
                        <div class="sf-card stsn-anim-fade-in-up stsn-anim-delay-200">
                            <div class="sf-card-head">
                                <div class="sf-card-icon icon-blue"><i class="bi bi-person-badge"></i></div>
                                <div>
                                    <p class="sf-card-title">Student Information</p>
                                    <p class="sf-card-subtitle">Personal details and academic placement</p>
                                </div>
                            </div>

                            <div class="sf-card-body">
                                <div class="g2" style="margin-bottom:.6rem;">
                                    <div>
                                        <label class="sf-label">LRN <span class="req">*</span></label>
                                        <input class="sf-input" type="text" name="lrn" id="lrn" required maxlength="12" placeholder="12-digit LRN" value="<?= v($old, 'lrn') ?>">
                                        <div class="invalid-feedback" id="feedback-lrn">LRN is required (12 digits).</div>
                                    </div>

                                    <div>
                                        <label class="sf-label">Grade Level <span class="req">*</span></label>
                                        <select class="sf-select" name="grade_level_id" id="gradeLevelSelect" required>
                                            <option value="">Select Grade</option>
                                            <?php foreach ($grades as $g): ?>
                                                <option value="<?= $g['id'] ?>" <?= sel($old, 'grade_level_id', $g['id']) ?>>
                                                    <?= htmlspecialchars($g['grade_level_name']) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="invalid-feedback" id="feedback-grade_level_id">Please select a grade level.</div>
                                    </div>
                                </div>

                                <div class="g2 sf-hidden" id="shsFields" style="margin-bottom:.6rem;">
                                    <div>
                                        <label class="sf-label">Track <span class="req">*</span></label>
                                        <select class="sf-select" name="strand" id="strandSelect">
                                            <option value="">Select Track</option>
                                            <option value="Academic" <?= ($oldStrand === 'Academic') ? 'selected' : '' ?>>Academic Track</option>
                                            <option value="Tech-Pro" <?= ($oldStrand === 'Tech-Pro') ? 'selected' : '' ?>>Tech-Pro</option>
                                        </select>
                                        <div class="invalid-feedback" id="feedback-strand">Track is required for Senior High.</div>
                                        <div class="sf-note">This is only required for Grade 11 and Grade 12.</div>
                                    </div>
                                    <div>
                                        <label class="sf-label">Cluster <span class="req">*</span></label>
                                        <select class="sf-select" name="cluster_id" id="clusterSelect">
                                            <option value="">Select Cluster</option>
                                            <?php foreach ($clusters as $cluster): ?>
                                                <option value="<?= (int) $cluster['id'] ?>" data-track="<?= htmlspecialchars($cluster['track'] ?? '', ENT_QUOTES, 'UTF-8') ?>" <?= (int) ($old['cluster_id'] ?? 0) === (int) $cluster['id'] ? 'selected' : '' ?>>
                                                    <?= htmlspecialchars($cluster['cluster_name']) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="invalid-feedback" id="feedback-cluster_id">Cluster is required for Senior High.</div>
                                        <div class="sf-note">Select the student's SHS cluster.</div>
                                    </div>
                                </div>

                                <hr class="sf-hr">

                                <div class="g3" style="margin-bottom:.6rem;">
                                    <div>
                                        <label class="sf-label">First Name <span class="req">*</span></label>
                                        <input class="sf-input" type="text" name="fname" id="fname" required value="<?= v($old, 'fname') ?>">
                                        <div class="invalid-feedback" id="feedback-fname">First name is required.</div>
                                    </div>

                                    <div>
                                        <label class="sf-label">Middle Name</label>
                                        <input class="sf-input" type="text" name="mname" value="<?= v($old, 'mname') ?>">
                                    </div>

                                    <div>
                                        <label class="sf-label">Last Name <span class="req">*</span></label>
                                        <input class="sf-input" type="text" name="lname" id="lname" required value="<?= v($old, 'lname') ?>">
                                        <div class="invalid-feedback" id="feedback-lname">Last name is required.</div>
                                    </div>
                                </div>

                                <div class="g3">
                                    <div>
                                        <label class="sf-label">Birthdate <span class="req">*</span></label>
                                        <input class="sf-input" type="date" name="birthdate" id="birthdate" required value="<?= v($old, 'birthdate') ?>">
                                        <div class="invalid-feedback" id="feedback-birthdate">Birthdate is required.</div>
                                    </div>

                                    <div>
                                        <label class="sf-label">Sex <span class="req">*</span></label>
                                        <select class="sf-select" name="gender" id="gender" required>
                                            <option value="">Select</option>
                                            <option value="Male" <?= sel($old, 'gender', 'Male') ?>>Male</option>
                                            <option value="Female" <?= sel($old, 'gender', 'Female') ?>>Female</option>
                                        </select>
                                        <div class="invalid-feedback" id="feedback-gender">Please select sex.</div>
                                    </div>

                                    <div>
                                        <label class="sf-label">Citizenship</label>
                                        <input class="sf-input" type="text" name="citizenship" placeholder="e.g. Filipino" value="<?= v($old, 'citizenship') ?>">
                                    </div>
                                </div>

                                <div style="margin-top:.6rem;max-width:420px;">
                                    <label class="sf-label">Email</label>
                                    <input class="sf-input" type="email" name="email" placeholder="e.g. student@email.com" value="<?= v($old, 'email') ?>">
                                    <div class="sf-note">Optional. Enter a valid email format.</div>
                                </div>
                            </div>
                        </div>

                        <div class="wizard-nav stsn-anim-fade-in-up stsn-anim-delay-300">
                            <a href="Student.php" class="btn-wizard-cancel">
                                <i class="bi bi-x-lg"></i> Cancel
                            </a>
                            <button type="button" class="btn-wizard-next" onclick="wizardNext(1)">
                                Next: Parents / Guardian <i class="bi bi-arrow-right"></i>
                            </button>
                        </div>
                    </div>

                    <div class="sf-step wizard-panel" data-step="2">
                        <div class="sf-card">
                            <div class="sf-card-head">
                                <div class="sf-card-icon icon-green"><i class="bi bi-people-fill"></i></div>
                                <div>
                                    <p class="sf-card-title">Parents / Guardian</p>
                                    <p class="sf-card-subtitle">Contact information for parents or legal guardian</p>
                                </div>
                            </div>

                            <div class="sf-card-body">
                                <div class="g2" style="margin-bottom:.6rem;">
                                    <div>
                                        <label class="sf-label">Father's Name <span class="req">*</span></label>
                                        <input class="sf-input" type="text" name="fathers_name" id="fathers_name" required value="<?= v($old, 'fathers_name') ?>">
                                        <div class="invalid-feedback" id="feedback-fathers_name">Father's name is required.</div>
                                    </div>

                                    <div>
                                        <label class="sf-label">Father's Contact <span class="req">*</span></label>
                                        <input class="sf-input" type="text" name="fathers_contact_num" id="fathers_contact_num" required placeholder="09XXXXXXXXX" value="<?= v($old, 'fathers_contact_num') ?>">
                                        <div class="invalid-feedback" id="feedback-fathers_contact_num">Father's contact is required.</div>
                                    </div>

                                    <div>
                                        <label class="sf-label">Mother's Name <span class="req">*</span></label>
                                        <input class="sf-input" type="text" name="mothers_name" id="mothers_name" required value="<?= v($old, 'mothers_name') ?>">
                                        <div class="invalid-feedback" id="feedback-mothers_name">Mother's name is required.</div>
                                    </div>

                                    <div>
                                        <label class="sf-label">Mother's Contact <span class="req">*</span></label>
                                        <input class="sf-input" type="text" name="mothers_contact_num" id="mothers_contact_num" required placeholder="09XXXXXXXXX" value="<?= v($old, 'mothers_contact_num') ?>">
                                        <div class="invalid-feedback" id="feedback-mothers_contact_num">Mother's contact is required.</div>
                                    </div>
                                </div>

                                <hr class="sf-hr">

                                <div class="g2">
                                    <div>
                                        <label class="sf-label">Guardian Name <span class="req">*</span></label>
                                        <input class="sf-input" type="text" name="guardian_name" id="guardian_name" required value="<?= v($old, 'guardian_name') ?>">
                                        <div class="invalid-feedback" id="feedback-guardian_name">Guardian name is required.</div>
                                    </div>

                                    <div>
                                        <label class="sf-label">Guardian Contact <span class="req">*</span></label>
                                        <input class="sf-input" type="text" name="guardian_contact_num" id="guardian_contact_num" required placeholder="09XXXXXXXXX" value="<?= v($old, 'guardian_contact_num') ?>">
                                        <div class="invalid-feedback" id="feedback-guardian_contact_num">Guardian contact is required.</div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="wizard-nav">
                            <a href="Student.php" class="btn-wizard-cancel">
                                <i class="bi bi-x-lg"></i> Cancel
                            </a>
                            <button type="button" class="btn-wizard-next" onclick="wizardNext(2)">
                                Next: Address Info <i class="bi bi-arrow-right"></i>
                            </button>
                        </div>
                    </div>

                    <div class="sf-step wizard-panel" data-step="3">
                        <div class="sf-card">
                            <div class="sf-card-head">
                            <div class="sf-card-icon icon-purple"><i class="bi bi-geo-alt-fill"></i></div>
                            <div>
                                <p class="sf-card-title">Address Info</p>
                                <p class="sf-card-subtitle">Complete the full home location for the student record</p>
                            </div>
                        </div>

                        <div class="sf-card-body">
                            <div class="g3" style="margin-bottom:.55rem;">
                                <div>
                                    <label class="sf-label">Street / House No. <span class="req">*</span></label>
                                    <input class="sf-input" type="text" name="street_name" id="street_name" required value="<?= v($old, 'street_name') ?>">
                                    <div class="invalid-feedback" id="feedback-street_name">Street/House No. is required.</div>
                                </div>

                                <div>
                                    <label class="sf-label">Country <span class="req">*</span></label>
                                    <select class="sf-select" id="country" name="country_id" required>
                                        <option value="">Select Country</option>
                                        <?php foreach ($countries as $c): ?>
                                            <option value="<?= $c['id'] ?>" <?= $oldCountry == $c['id'] ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($c['country_name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="invalid-feedback" id="feedback-country_id">Please select a country.</div>
                                </div>

                                <div>
                                    <label class="sf-label">Region <span class="req">*</span></label>
                                    <select class="sf-select" id="region" name="region_id" required>
                                        <option value="">Select Region</option>
                                    </select>
                                    <div class="invalid-feedback" id="feedback-region_id">Please select a region.</div>
                                </div>

                                <div>
                                    <label class="sf-label">Province <span class="req">*</span></label>
                                    <select class="sf-select" id="province" name="province_id" required>
                                        <option value="">Select Province</option>
                                    </select>
                                    <div class="invalid-feedback" id="feedback-province_id">Please select a province.</div>
                                </div>

                                <div>
                                    <label class="sf-label">City / Municipality <span class="req">*</span></label>
                                    <select class="sf-select" id="city" name="city_id" required>
                                        <option value="">Select City</option>
                                    </select>
                                    <div class="invalid-feedback" id="feedback-city_id">Please select a city.</div>
                                </div>

                                <div>
                                    <label class="sf-label">Barangay <span class="req">*</span></label>
                                    <select class="sf-select" id="barangay" name="barangay_id" required>
                                        <option value="">Select Barangay</option>
                                    </select>
                                    <div class="invalid-feedback" id="feedback-barangay_id">Please select a barangay.</div>
                                </div>
                            </div>

                            <div style="max-width:280px;">
                                <label class="sf-label">Postal Code <span class="req">*</span></label>
                                <input class="sf-input" type="text" name="postal_code" id="postal_code" placeholder="e.g. 1105" value="<?= v($old, 'postal_code') ?>" maxlength="4" pattern="\d{4}" inputmode="numeric" required>
                                <div class="invalid-feedback" id="feedback-postal_code">Please enter a valid 4-digit postal code.</div>
                                <div class="sf-note" id="postal_lookup_note">Postal code follows the selected barangay.</div>
                            </div>
                        </div>

                    </div>

                    <div class="wizard-nav">
                        <a href="Student.php" class="btn-wizard-cancel">
                            <i class="bi bi-x-lg"></i> Cancel
                        </a>
                        <button type="submit" class="btn-wizard-save" id="saveStudentBtn">
                            <i class="bi bi-check-circle-fill"></i> <?= $edit ? 'Update Student' : 'Save Student' ?>
                        </button>
                    </div>
                    </div>

                </form>
            </div>
        </div>
    </main>
    <?php require_once("includes/footer.php"); ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>

<script>
const initialToastType = <?= json_encode($toastType) ?>;
const initialToastMessage = <?= json_encode($toastMessage) ?>;

function showAlert(message, type = 'success') {
    const config = {
        success: { title: 'Success', color: 'blue', icon: 'bi bi-check-circle-fill' },
        danger: { title: 'Error', color: 'red', icon: 'bi bi-exclamation-octagon-fill' },
        warning: { title: 'Warning', color: 'yellow', icon: 'bi bi-exclamation-triangle-fill' },
        info: { title: 'Info', color: 'blue', icon: 'bi bi-info-circle-fill' }
    };
    const selected = config[type] || config.success;
    iziToast.show({
        title: selected.title,
        message: message,
        color: selected.color,
        icon: selected.icon,
        iconColor: '#fff',
        theme: 'light',
        position: 'topRight',
        timeout: 4000,
        progressBar: true,
        close: true,
        pauseOnHover: true,
        drag: true,
        transitionIn: 'fadeInDown',
        transitionOut: 'fadeOutUp',
        maxWidth: 420
    });
}

function showValidationToast(missingFields) {
    const fieldsList = missingFields.map(label => `• ${label}`).join('<br>');
    iziToast.show({
        title: 'Required Fields Missing',
        message: `Please complete the following required fields:<br><br><strong>${fieldsList}</strong>`,
        color: 'red',
        icon: 'bi bi-exclamation-triangle-fill',
        iconColor: '#fff',
        theme: 'light',
        position: 'topRight',
        timeout: 6000,
        progressBar: true,
        close: true,
        pauseOnHover: true,
        drag: true,
        transitionIn: 'fadeInDown',
        transitionOut: 'fadeOutUp',
        maxWidth: 380,
        layout: 2,
        balloon: false,
        closeOnClick: true,
        displayMode: 2
    });
}

function fill(select, list, nameField, placeholder, preSel = null) {
    const current = select.value;
    const selectedValue = preSel !== null && preSel !== undefined && String(preSel) !== '' ? preSel : current;
    select.innerHTML = `<option value="">${placeholder}</option>`;

    list.forEach(item => {
        const opt = document.createElement('option');
        opt.value = item.id;
        opt.textContent = item[nameField] || item.name || '';
        if (String(opt.value) === String(selectedValue)) {
            opt.selected = true;
        }
        select.appendChild(opt);
    });
}

function uniqueValues(list, field) {
    return [...new Set(list.map(item => String(item[field] ?? '')).filter(Boolean))];
}

function normalizePostalInput(value) {
    return String(value || '').replace(/\D+/g, '').slice(0, 4);
}

function setPostalNote(message = '') {
    const note = document.getElementById('postal_lookup_note');
    if (note) note.textContent = message || 'Postal code follows the selected barangay.';
}

function locationLabel(match) {
   return [match.barangay_name, match.city_name, match.province_name].filter(Boolean).join(', ');
}

function isSeniorHighGrade(selectEl) {
    if (!selectEl || !selectEl.value) return false;
    const selectedOption = selectEl.options[selectEl.selectedIndex];
    const selectedText = String(selectedOption ? selectedOption.textContent : '').trim();
    return /^Grade\s*1[12]$/i.test(selectedText);
}

function toggleStrandField() {
    const gradeSelect = document.getElementById('gradeLevelSelect');
    const shsFields = document.getElementById('shsFields');
    const strandSelect = document.getElementById('strandSelect');
    const clusterSelect = document.getElementById('clusterSelect');
    if (!gradeSelect || !shsFields || !strandSelect || !clusterSelect) return;

    if (isSeniorHighGrade(gradeSelect)) {
        const wasHidden = shsFields.classList.contains('sf-hidden');
        shsFields.classList.remove('sf-hidden');
        if (wasHidden) {
            void shsFields.offsetWidth;
            shsFields.classList.add('sf-shs-field-reveal');
        }
        strandSelect.setAttribute('required', 'required');
        clusterSelect.setAttribute('required', 'required');
    } else {
        shsFields.classList.remove('sf-shs-field-reveal');
        shsFields.classList.add('sf-hidden');
        strandSelect.removeAttribute('required');
        clusterSelect.removeAttribute('required');
        strandSelect.value = '';
        clusterSelect.value = '';
        clearFieldValidation(strandSelect);
        clearFieldValidation(clusterSelect);
    }
}

function showFieldError(field, show = true) {
    const feedback = document.getElementById('feedback-' + field.name);
    if (show) {
        field.classList.add('is-invalid');
        field.classList.remove('is-valid');
        if (feedback) feedback.classList.add('show');
    } else {
        field.classList.remove('is-invalid');
        field.classList.add('is-valid');
        if (feedback) feedback.classList.remove('show');
    }
}

function clearFieldValidation(field) {
    field.classList.remove('is-invalid', 'is-valid');
    const feedback = document.getElementById('feedback-' + field.name);
    if (feedback) feedback.classList.remove('show');
}

function validateField(field) {
    if (field.closest('.sf-hidden')) {
        clearFieldValidation(field);
        return true;
    }
    if (!field.required && !field.value.trim()) {
        clearFieldValidation(field);
        return true;
    }
    let isValid = field.value.trim() !== '';
    if (field.name === 'postal_code') {
        isValid = /^\d{4}$/.test(field.value.trim());
    }
    if (field.required) {
        if (isValid) {
            showFieldError(field, false);
            return true;
        } else {
            showFieldError(field, true);
            return false;
        }
    }
    return true;
}

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('sfForm');
    const elCountry = document.getElementById('country');
    const elRegion = document.getElementById('region');
    const elProvince = document.getElementById('province');
    const elCity = document.getElementById('city');
    const elBarangay = document.getElementById('barangay');
    const elPostalCode = document.getElementById('postal_code');
    const gradeLevelSelect = document.getElementById('gradeLevelSelect');
    let isApplyingAddress = false;
    let postalLookupTimer = null;
    let postalLookupSeq = 0;
    let selectedBarangayNeedsPostal = false;
    const addressOptionCache = new Map();

    async function loadAddressOptions(level, parentId, select, nameField, placeholder, selectedId = null) {
        if (!parentId) {
            select.innerHTML = `<option value="">${placeholder}</option>`;
            return [];
        }
        const cacheKey = `${level}:${parentId}`;
        let cached = addressOptionCache.get(cacheKey);
        let items;
        let source;
        if (cached) {
            ({ items, source } = cached);
        } else {
            const params = new URLSearchParams({ level, parent_id: String(parentId) });
            const response = await fetch(`api/location/hierarchy.php?${params.toString()}`, {
                headers: { 'Accept': 'application/json' }
            });
            const result = await response.json();
            if (!response.ok || !result.success || !Array.isArray(result.items)) {
                throw new Error(result.error || 'Unable to load address options.');
            }
            items = result.items;
            source = result.source || 'local_cache';
            addressOptionCache.set(cacheKey, { items, source });
        }
        fill(select, items, nameField, placeholder, selectedId);
        if (source === 'local_cache') {
            setPostalNote('Using locally available address options.');
        }
        return items;
    }

    function fillBarangayChoices(list, placeholder = 'Select Barangay', preSel = null, includeLocation = false) {
        const current = elBarangay.value;
        const selectedValue = preSel !== null && preSel !== undefined && String(preSel) !== '' ? preSel : current;
        elBarangay.innerHTML = `<option value="">${placeholder}</option>`;
        list.forEach(item => {
            const opt = document.createElement('option');
            opt.value = item.id || item.barangay_id;
            opt.textContent = includeLocation ? locationLabel(item) : (item.barangay_name || item.name || '');
            if (String(opt.value) === String(selectedValue)) {
                opt.selected = true;
            }
            elBarangay.appendChild(opt);
        });
    }

    async function fillAddressHierarchy(row, selectedBarangayId = null) {
        isApplyingAddress = true;
        elCountry.value = row.country_id || '';
        try {
            await loadAddressOptions('REGION', elCountry.value, elRegion, 'region_name', 'Select Region', row.region_id);
            await loadAddressOptions('PROVINCE', row.region_id, elProvince, 'province_name', 'Select Province', row.province_id);
            await loadAddressOptions('CITY', row.province_id, elCity, 'city_name', 'Select City', row.city_id);
            const barangays = await loadAddressOptions('BARANGAY', row.city_id, elBarangay, 'barangay_name', 'Select Barangay', selectedBarangayId || row.barangay_id);
            if (selectedBarangayId || row.barangay_id) {
                elBarangay.value = String(selectedBarangayId || row.barangay_id);
            }
            elPostalCode.value = normalizePostalInput(row.postal_code || '');
            if (elPostalCode.value) showFieldError(elPostalCode, false);
            if (barangays.some(item => !item.postal_code)) {
                setPostalNote('Some PSGC barangays have no postal code in the local cache; enter the 4-digit code manually.');
            }
        } finally {
            isApplyingAddress = false;
        }
    }

    async function fetchAddressLookup(params) {
        const response = await fetch(`api/location/postal_lookup.php?${params.toString()}`, {
            headers: { 'Accept': 'application/json' }
        });
        if (!response.ok) throw new Error('Lookup request failed.');
        return response.json();
    }

    async function applyPostalMatches(matches) {
        if (!matches.length) return;
        const selectedMatch = matches.find(match => String(match.barangay_id) === String(elBarangay.value));
        const row = selectedMatch || matches[0];
        const countryIds = uniqueValues(matches, 'country_id');
        const regionIds = uniqueValues(matches, 'region_id');
        const provinceIds = uniqueValues(matches, 'province_id');
        const cityIds = uniqueValues(matches, 'city_id');
        const selectedBarangayId = matches.length === 1 ? matches[0].barangay_id : (selectedMatch ? selectedMatch.barangay_id : null);
        isApplyingAddress = true;
        try {
            elCountry.value = countryIds.length === 1 ? row.country_id : '';
            if (elCountry.value) {
                await loadAddressOptions('REGION', elCountry.value, elRegion, 'region_name', 'Select Region', regionIds.length === 1 ? row.region_id : null);
            } else {
                elRegion.innerHTML = '<option value="">Select Region</option>';
            }
            if (regionIds.length === 1) {
                await loadAddressOptions('PROVINCE', row.region_id, elProvince, 'province_name', 'Select Province', provinceIds.length === 1 ? row.province_id : null);
            } else {
                elProvince.innerHTML = '<option value="">Select Province</option>';
            }
            if (provinceIds.length === 1) {
                await loadAddressOptions('CITY', row.province_id, elCity, 'city_name', 'Select City', cityIds.length === 1 ? row.city_id : null);
            } else {
                elCity.innerHTML = '<option value="">Select City</option>';
            }
            fillBarangayChoices(matches, 'Select Matching Barangay', selectedBarangayId, cityIds.length > 1 || provinceIds.length > 1);
            elPostalCode.value = normalizePostalInput(row.postal_code || '');
            selectedBarangayNeedsPostal = !row.postal_code;
            showFieldError(elPostalCode, false);
            setPostalNote(matches.length > 1 ? 'Multiple barangays match this postal code.' : 'Postal code matched.');
        } finally {
            isApplyingAddress = false;
        }
    }

    async function lookupPostalCode(postalCode) {
        const requestSeq = ++postalLookupSeq;
        const params = new URLSearchParams({ postal_code: postalCode });
        try {
            const data = await fetchAddressLookup(params);
            if (requestSeq !== postalLookupSeq) return;
            if (!data.success || !Array.isArray(data.matches) || data.matches.length === 0) {
                showFieldError(elPostalCode, true);
                setPostalNote(data.error || 'Postal code was not found.');
                return;
            }
            await applyPostalMatches(data.matches);
        } catch (error) {
            if (requestSeq === postalLookupSeq) {
                showFieldError(elPostalCode, true);
                setPostalNote('Postal code lookup failed.');
            }
        }
    }

    async function lookupBarangay(barangayId) {
        if (!barangayId) return;
        const params = new URLSearchParams({ barangay_id: barangayId });
        try {
            const data = await fetchAddressLookup(params);
            if (!data.success || !Array.isArray(data.matches) || data.matches.length !== 1) {
                return;
            }
            await fillAddressHierarchy(data.matches[0], data.matches[0].barangay_id);
            selectedBarangayNeedsPostal = !data.matches[0].postal_code;
            setPostalNote(data.matches[0].postal_code
                ? 'Postal code matched the selected barangay.'
                : 'Postal code is not listed; enter the correct 4-digit code.');
        } catch (error) {
            console.error('Unable to load selected barangay:', error);
            setPostalNote('Unable to load the selected barangay address details.');
        }
    }

    function updatePostalFromSelection() {
        if (isApplyingAddress) return;
        if (elBarangay.value) {
            lookupBarangay(elBarangay.value);
            return;
        }
        selectedBarangayNeedsPostal = false;
        elPostalCode.value = '';
        clearFieldValidation(elPostalCode);
        setPostalNote('Select a barangay to set the postal code.');
    }

    if (initialToastType && initialToastMessage) {
        showAlert(initialToastMessage, initialToastType);
    }

    async function initializeAddress() {
        try {
            const oldBarangayId = <?= json_encode((string) $oldBarangay) ?>;
            if (oldBarangayId) {
                await lookupBarangay(oldBarangayId);
            } else if (+elCountry.value) {
                await loadAddressOptions(
                    'REGION', elCountry.value, elRegion, 'region_name', 'Select Region',
                    <?= json_encode((string) $oldRegion) ?>
                );
                if (elRegion.value) {
                    await loadAddressOptions(
                        'PROVINCE', elRegion.value, elProvince, 'province_name', 'Select Province',
                        <?= json_encode((string) $oldProvince) ?>
                    );
                }
                if (elProvince.value) {
                    await loadAddressOptions(
                        'CITY', elProvince.value, elCity, 'city_name', 'Select City',
                        <?= json_encode((string) $oldCity) ?>
                    );
                }
                if (elCity.value) {
                    await loadAddressOptions('BARANGAY', elCity.value, elBarangay, 'barangay_name', 'Select Barangay');
                }
                if (elPostalCode.value) {
                    await lookupPostalCode(normalizePostalInput(elPostalCode.value));
                }
            } else {
                updatePostalFromSelection();
            }
        } catch (error) {
            console.error('Unable to initialize address options:', error);
            showAlert(error.message || 'Unable to load address options.', 'warning');
        }
    }
    initializeAddress();

    elCountry.addEventListener('change', async () => {
        try {
            await loadAddressOptions('REGION', elCountry.value, elRegion, 'region_name', 'Select Region');
        } catch (error) {
            showAlert(error.message || 'Unable to load regions.', 'warning');
        }
        elProvince.innerHTML = '<option value="">Select Province</option>';
        elCity.innerHTML = '<option value="">Select City</option>';
        elBarangay.innerHTML = '<option value="">Select Barangay</option>';
        clearFieldValidation(elRegion);
        clearFieldValidation(elProvince);
        clearFieldValidation(elCity);
        clearFieldValidation(elBarangay);
        updatePostalFromSelection();
    });

    elRegion.addEventListener('change', async () => {
        try {
            await loadAddressOptions('PROVINCE', elRegion.value, elProvince, 'province_name', 'Select Province');
        } catch (error) {
            showAlert(error.message || 'Unable to load provinces.', 'warning');
        }
        elCity.innerHTML = '<option value="">Select City</option>';
        elBarangay.innerHTML = '<option value="">Select Barangay</option>';
        clearFieldValidation(elProvince);
        clearFieldValidation(elCity);
        clearFieldValidation(elBarangay);
        if (elRegion.value) validateField(elRegion);
        updatePostalFromSelection();
    });

    elProvince.addEventListener('change', async () => {
        try {
            await loadAddressOptions('CITY', elProvince.value, elCity, 'city_name', 'Select City');
        } catch (error) {
            showAlert(error.message || 'Unable to load cities and municipalities.', 'warning');
        }
        elBarangay.innerHTML = '<option value="">Select Barangay</option>';
        clearFieldValidation(elCity);
        clearFieldValidation(elBarangay);
        if (elProvince.value) validateField(elProvince);
        updatePostalFromSelection();
    });

    elCity.addEventListener('change', async () => {
        try {
            await loadAddressOptions('BARANGAY', elCity.value, elBarangay, 'barangay_name', 'Select Barangay');
        } catch (error) {
            showAlert(error.message || 'Unable to load barangays.', 'warning');
        }
        clearFieldValidation(elBarangay);
        if (elCity.value) validateField(elCity);
        updatePostalFromSelection();
    });

    elBarangay.addEventListener('change', () => {
        if (elBarangay.value) {
            lookupBarangay(elBarangay.value);
            validateField(elBarangay);
        } else {
            updatePostalFromSelection();
        }
    });

    elPostalCode.addEventListener('input', () => {
        const normalized = normalizePostalInput(elPostalCode.value);
        if (elPostalCode.value !== normalized) {
            elPostalCode.value = normalized;
        }
        window.clearTimeout(postalLookupTimer);
        if (normalized.length === 0) {
            clearFieldValidation(elPostalCode);
            setPostalNote('Select a barangay to set the postal code.');
            return;
        }
        if (normalized.length < 4) {
            clearFieldValidation(elPostalCode);
            setPostalNote('Enter a 4-digit postal code.');
            return;
        }
        if (selectedBarangayNeedsPostal && elBarangay.value) {
            showFieldError(elPostalCode, false);
            setPostalNote('Postal code is not listed; the 4-digit code will be saved with this student.');
            return;
        }
        postalLookupTimer = window.setTimeout(() => lookupPostalCode(normalized), 250);
    });

    elPostalCode.addEventListener('blur', () => {
        const normalized = normalizePostalInput(elPostalCode.value);
        elPostalCode.value = normalized;
        if (selectedBarangayNeedsPostal && elBarangay.value) {
            showFieldError(elPostalCode, normalized.length !== 4);
            setPostalNote(normalized.length === 4
                ? 'Postal code will be saved with this student.'
                : 'Postal code must be exactly 4 digits.');
            return;
        }
        if (normalized.length === 4) {
            lookupPostalCode(normalized);
        } else {
            showFieldError(elPostalCode, true);
            setPostalNote('Postal code must be exactly 4 digits.');
        }
    });

    if (gradeLevelSelect) {
        toggleStrandField();
        gradeLevelSelect.addEventListener('change', () => {
            toggleStrandField();
            validateField(gradeLevelSelect);
        });
    }

    form.querySelectorAll('input, select').forEach(field => {
        // Blur validation disabled — wizard validates on Next/Submit only
        field.addEventListener('input', () => {
            if (field.classList.contains('is-invalid')) {
                validateField(field);
            }
        });
        field.addEventListener('change', () => {
            if (field.classList.contains('is-invalid')) {
                validateField(field);
            }
        });
    });

    form.addEventListener('submit', function (e) {
        toggleStrandField();
        const requiredFields = [...this.querySelectorAll('[required]')].filter(el => {
            return !el.closest('.sf-hidden');
        });
        let hasErrors = false;
        const missingFields = [];
        requiredFields.forEach(field => {
            const isValid = validateField(field);
            if (!isValid) {
                hasErrors = true;
                const label = field.closest('div')?.querySelector('.sf-label')?.textContent?.replace('*', '').trim() || field.name;
                missingFields.push(label);
            }
        });
        if (hasErrors) {
            e.preventDefault();
            showValidationToast(missingFields);
            const firstInvalid = form.querySelector('.is-invalid');
            if (firstInvalid) {
                firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
                firstInvalid.focus();
            }
        }
    });
});
</script>

<script>
/* ============================================================
   STUDENT FORM — 3-STEP WIZARD
   Reuses the existing .sf-step panels (now .wizard-panel).
   Integrates with the existing custom validators:
     validateField() / showFieldError() / clearFieldValidation()
   ============================================================ */
let currentStep = 1;
const totalWizardSteps = 3;

function wizardGoTo(targetStep, skipScroll) {
    // Only require validation when going FORWARD. Going backward (or a stepper
    // jump) is allowed freely.
    if (targetStep > currentStep && !validateStep(currentStep)) {
        return;
    }

    // Hide all panels
    document.querySelectorAll('.sf-step.wizard-panel').forEach(p => {
        p.style.display = 'none';
        p.classList.remove('active', 'sf-slide-right', 'sf-slide-left');
    });

    // Show target panel (with slide direction)
    const panel = document.querySelector('.sf-step[data-step="' + targetStep + '"]');
    if (panel) {
        // Determine slide direction
        panel.classList.remove('sf-slide-right', 'sf-slide-left');
        if (targetStep > currentStep) {
            panel.classList.add('sf-slide-right');
        } else if (targetStep < currentStep) {
            panel.classList.add('sf-slide-left');
        }

        panel.style.display = 'block';
        panel.classList.add('active');
    }

    currentStep = targetStep;

    // Scroll to the top of the form — only on manual step changes.
    if (!skipScroll) {
        const formTop = document.querySelector('#sfForm');
        if (formTop) formTop.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

function validateStep(step) {
    // Only validate [required] fields within this panel using the existing validator.
    const panel = document.querySelector('.sf-step[data-step="' + step + '"]');
    if (!panel) return true;

    let firstInvalid = null;
    panel.querySelectorAll('[required]').forEach(field => {
        const ok = (typeof validateField === 'function') ? validateField(field) : true;
        if (!ok && !firstInvalid) firstInvalid = field;
    });

    if (firstInvalid) {
        firstInvalid.focus();
        firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return false;
    }
    return true;
}

function wizardNext(fromStep) {
    // wizardGoTo() performs the forward validation for the current step.
    if (fromStep < totalWizardSteps) wizardGoTo(fromStep + 1);
}

// Initialize: show step 1 only — WITHOUT scrolling the page on load.
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.sf-step.wizard-panel').forEach(p => {
        p.style.display = 'none';
        p.classList.remove('active', 'sf-slide-right', 'sf-slide-left');
    });
    const panel = document.querySelector('.sf-step[data-step="1"]');
    if (panel) {
        panel.style.display = 'block';
        panel.classList.add('active');
    }
    currentStep = 1;
});

(function () {
    const trackSelect = document.getElementById('strandSelect');
    const clusterSelect = document.getElementById('clusterSelect');
    if (!trackSelect || !clusterSelect) return;

    const allOptions = Array.from(clusterSelect.querySelectorAll('option'));

    function filterClusters() {
        const selectedTrack = trackSelect.value;
        const currentValue = clusterSelect.value;

        allOptions.forEach(function (option) {
            if (option.value === '') {
                option.hidden = false;
                option.disabled = false;
                return;
            }
            const matches = selectedTrack === '' || (option.dataset.track || '') === selectedTrack;
            option.hidden = !matches;
            option.disabled = !matches;
        });

        if (currentValue) {
            const currentOption = allOptions.find(option => option.value === currentValue);
            if (currentOption && currentOption.hidden) {
                clusterSelect.value = '';
            }
        }

        const placeholder = allOptions.find(option => option.value === '');
        if (placeholder) {
            placeholder.textContent = selectedTrack === '' ? '— Select Track first —' : 'Select Cluster';
        }
    }

    filterClusters();
    trackSelect.addEventListener('change', filterClusters);
})();
</script>
</body>
</html>