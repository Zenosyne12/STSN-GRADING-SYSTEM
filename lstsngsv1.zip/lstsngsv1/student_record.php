<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/api/shared/db_connect.php';
require_once __DIR__ . '/includes/archive_engine.php';
ensureProfileArchiveSchema($pdo);

function historicalRecordEscape($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

$yearId = filter_var($_GET['year_id'] ?? null, FILTER_VALIDATE_INT);
$studentId = filter_var($_GET['student_id'] ?? null, FILTER_VALIDATE_INT);
$yearId = $yearId !== false && $yearId !== null && $yearId > 0 ? $yearId : 0;
$studentId = $studentId !== false && $studentId !== null && $studentId > 0 ? $studentId : 0;

$student = null;
$terms = [];
$grades = [];
$archiveActor = '—';
$loadError = '';

try {
    if ($yearId <= 0 || $studentId <= 0) {
        http_response_code(400);
        throw new InvalidArgumentException('A valid academic year and student are required.');
    }

    $studentStmt = $pdo->prepare("
        SELECT
            s.id,
            s.lrn,
            s.fname,
            s.mname,
            s.lname,
            s.birthdate,
            s.gender,
            s.citizenship,
            s.email,
            s.fathers_name,
            s.fathers_contact_num,
            s.mothers_name,
            s.mothers_contact_num,
            s.guardian_name,
            s.guardian_contact_num,
            s.street_name,
            s.postal_code,
            s.is_active AS student_is_active,
            ay.id AS academic_year_id,
            ay.year_label,
            ay.term_structure,
            ay.is_active AS year_is_active,
            ay.archived_at AS year_archived_at,
            sa.grade_level_id AS archived_grade_level_id,
            sa.final_average AS archived_final_average,
            sa.status AS archived_status,
            sa.archived_at AS student_archived_at,
            sa.archived_by AS student_archived_by,
            e.grade_level_id AS enrollment_grade_level_id,
            e.enrollment_status,
            gl.grade_level_name,
            GROUP_CONCAT(DISTINCT sec.section_name ORDER BY sec.section_name SEPARATOR ', ') AS section_names,
            GROUP_CONCAT(
                DISTINCT NULLIF(TRIM(CONCAT_WS(' ', adviser.fname, adviser.lname)), '')
                ORDER BY adviser.lname, adviser.fname SEPARATOR ', '
            ) AS adviser_names,
            b.barangay_name,
            city.city_name,
            province.province_name,
            region.region_name,
            country.country_name,
            pa.archived_at AS profile_archived_at,
            pa.archived_by AS profile_archived_by
        FROM tblstudents s
        INNER JOIN tblacademicyear ay ON ay.id = :year_id
        LEFT JOIN (
            SELECT student_id, academic_year_id, MAX(id) AS id
            FROM tblstudent_archive
            GROUP BY student_id, academic_year_id
        ) latest_sa ON latest_sa.student_id = s.id AND latest_sa.academic_year_id = ay.id
        LEFT JOIN tblstudent_archive sa ON sa.id = latest_sa.id
        LEFT JOIN (
            SELECT enrollment_latest.*
            FROM tblenrollment enrollment_latest
            INNER JOIN (
                SELECT student_id, academic_year_id, MAX(id) AS id
                FROM tblenrollment
                GROUP BY student_id, academic_year_id
            ) latest_enrollment
                ON latest_enrollment.id = enrollment_latest.id
        ) e ON e.student_id = s.id AND e.academic_year_id = ay.id
        LEFT JOIN tblsectionstudent ss ON ss.student_id = s.id AND ss.academic_year_id = ay.id
        LEFT JOIN tblsection sec ON sec.id = ss.section_id
        LEFT JOIN tblsection latest_sec
            ON latest_sec.id = (
                SELECT ss_latest.section_id
                FROM tblsectionstudent ss_latest
                WHERE ss_latest.student_id = s.id
                  AND ss_latest.academic_year_id = ay.id
                ORDER BY ss_latest.id DESC
                LIMIT 1
            )
        LEFT JOIN tblsectionadviser section_adviser
            ON section_adviser.section_id = sec.id AND section_adviser.academic_year_id = ay.id
        LEFT JOIN tblteacher adviser ON adviser.id = section_adviser.teacher_id
        LEFT JOIN tblgradelevel gl ON gl.id = COALESCE(
            sa.grade_level_id,
            e.grade_level_id,
            latest_sec.grade_level_id,
            s.grade_level_id
        )
        LEFT JOIN tblbarangay b ON b.id = s.barangay_id
        LEFT JOIN tblcity city ON city.id = COALESCE(s.city_id, b.city_id)
        LEFT JOIN tblprovince province ON province.id = COALESCE(s.province_id, city.province_id)
        LEFT JOIN tblregion region ON region.id = COALESCE(s.region_id, province.region_id)
        LEFT JOIN tblcountry country ON country.id = COALESCE(s.country_id, region.country_id)
        LEFT JOIN tblprofile_archive pa
            ON pa.profile_type = 'STUDENT'
           AND pa.profile_id = s.id
           AND pa.academic_year_id = ay.id
           AND pa.restored_at IS NULL
        WHERE s.id = :student_id
          AND EXISTS (
              SELECT 1
              FROM (
                  SELECT student_id, academic_year_id FROM tblsectionstudent
                  UNION
                  SELECT student_id, academic_year_id FROM tblenrollment
                  UNION
                  SELECT student_id, academic_year_id FROM tblstudent_archive
              ) year_students
              WHERE year_students.student_id = s.id
                AND year_students.academic_year_id = ay.id
          )
        GROUP BY
            s.id, s.lrn, s.fname, s.mname, s.lname, s.birthdate, s.gender,
            s.citizenship, s.email, s.fathers_name, s.fathers_contact_num,
            s.mothers_name, s.mothers_contact_num, s.guardian_name,
            s.guardian_contact_num, s.street_name, s.postal_code, s.is_active,
            ay.id, ay.year_label, ay.term_structure, ay.is_active, ay.archived_at,
            sa.grade_level_id, sa.final_average, sa.status,
            sa.archived_at, sa.archived_by, e.grade_level_id, e.enrollment_status,
            gl.grade_level_name, b.barangay_name,
            city.city_name, province.province_name, region.region_name,
            country.country_name, pa.archived_at, pa.archived_by
        LIMIT 1
    ");
    $studentStmt->execute([':year_id' => $yearId, ':student_id' => $studentId]);
    $student = $studentStmt->fetch(PDO::FETCH_ASSOC) ?: null;

    if (!$student) {
        http_response_code(404);
        throw new DomainException('No student record exists for the selected academic year.');
    }

    $termStmt = $pdo->prepare("
        SELECT quarter_number, quarter_label
        FROM tblquarters
        WHERE academic_year_id = ?
        ORDER BY quarter_number
    ");
    $termStmt->execute([$yearId]);
    $terms = $termStmt->fetchAll(PDO::FETCH_ASSOC);
    if ($terms === []) {
        $termCount = match (strtolower((string) $student['term_structure'])) {
            'trimester' => 3,
            'semestral' => 2,
            'quarterly' => 4,
            default => 0,
        };
        for ($termNumber = 1; $termNumber <= $termCount; $termNumber++) {
            $terms[] = [
                'quarter_number' => $termNumber,
                'quarter_label' => $termNumber . ($termNumber === 1 ? 'st' : ($termNumber === 2 ? 'nd' : ($termNumber === 3 ? 'rd' : 'th'))) . ' Term',
            ];
        }
    }

    $gradeStmt = $pdo->prepare("
        SELECT
            g.id,
            g.subject_id,
            g.quarter,
            g.final_grade,
            g.initial_grade,
            g.remarks,
            g.status,
            g.rating_code,
            g.grading_mode,
            g.updated_at,
            sub.subject_code,
            sub.subject_name
        FROM tblgrades g
        LEFT JOIN tblsubjects sub ON sub.id = g.subject_id
        WHERE g.student_id = ?
          AND g.academic_year_id = ?
        ORDER BY sub.subject_name, g.subject_id, g.quarter, g.id
    ");
    $gradeStmt->execute([$studentId, $yearId]);

    foreach ($gradeStmt->fetchAll(PDO::FETCH_ASSOC) as $gradeRow) {
        $subjectId = (int) $gradeRow['subject_id'];
        if (!isset($grades[$subjectId])) {
            $grades[$subjectId] = [
                'subject_code' => (string) ($gradeRow['subject_code'] ?? ''),
                'subject_name' => (string) ($gradeRow['subject_name'] ?? ''),
                'terms' => [],
                'updated_at' => null,
            ];
        }

        $termNumber = (int) $gradeRow['quarter'];
        $grades[$subjectId]['terms'][$termNumber] = $gradeRow;
        if ($gradeRow['updated_at'] && (
            !$grades[$subjectId]['updated_at']
            || $gradeRow['updated_at'] > $grades[$subjectId]['updated_at']
        )) {
            $grades[$subjectId]['updated_at'] = $gradeRow['updated_at'];
        }
    }

    $archivedBy = $student['student_archived_by'] ?: $student['profile_archived_by'];
    if (!$archivedBy && $student['year_archived_at']) {
        $yearActorStmt = $pdo->prepare("
            SELECT COALESCE(NULLIF(TRIM(CONCAT_WS(' ', t.fname, t.lname)), ''), u.username) AS actor_name
            FROM tblacademicyear ay
            LEFT JOIN tblusers u ON u.id = ay.archived_by
            LEFT JOIN tblteacher t ON t.id = u.reference_id AND u.role_id = 2
            WHERE ay.id = ?
            LIMIT 1
        ");
        $yearActorStmt->execute([$yearId]);
        $archiveActor = (string) ($yearActorStmt->fetchColumn() ?: '—');
    } elseif ($archivedBy) {
        $actorStmt = $pdo->prepare("
            SELECT COALESCE(NULLIF(TRIM(CONCAT_WS(' ', t.fname, t.lname)), ''), u.username) AS actor_name
            FROM tblusers u
            LEFT JOIN tblteacher t ON t.id = u.reference_id AND u.role_id = 2
            WHERE u.id = ?
            LIMIT 1
        ");
        $actorStmt->execute([(int) $archivedBy]);
        $archiveActor = (string) ($actorStmt->fetchColumn() ?: '—');
    }
} catch (Throwable $e) {
    if (!($e instanceof InvalidArgumentException) && http_response_code() < 400) {
        http_response_code(500);
    }
    if (!($e instanceof InvalidArgumentException) && !($e instanceof DomainException)) {
        error_log('[student_record] Failed to load historical student record: ' . $e->getMessage());
    }
    $loadError = $e instanceof InvalidArgumentException || $e instanceof DomainException
        ? $e->getMessage()
        : 'The student record could not be loaded. Please try again or contact an administrator.';
}

$fullName = $student
    ? trim(implode(' ', array_filter([
        $student['fname'],
        $student['mname'],
        $student['lname'],
    ], static fn($part) => trim((string) $part) !== '')))
    : 'Student Record';
$yearLabel = (string) ($student['year_label'] ?? '');
$gradeLevel = (string) ($student['grade_level_name'] ?? '—');
$sectionNames = (string) ($student['section_names'] ?? '—');
$adviserNames = (string) ($student['adviser_names'] ?? '—');
$isProfileArchived = !empty($student['profile_archived_at']);
$yearIsActive = $student
    && (int) $student['year_is_active'] === 1
    && empty($student['year_archived_at']);
$recordStatus = $student
    ? ($isProfileArchived
        ? 'Archived Profile'
        : ($yearIsActive ? 'Current Year' : (string) ($student['archived_status'] ?: 'Archived')))
    : 'Unavailable';
$address = implode(', ', array_filter([
    (string) ($student['street_name'] ?? ''),
    (string) ($student['barangay_name'] ?? ''),
    (string) ($student['city_name'] ?? ''),
    (string) ($student['province_name'] ?? ''),
    (string) ($student['region_name'] ?? ''),
    (string) ($student['country_name'] ?? ''),
], static fn($part) => trim($part) !== ''));

$breadcrumbTrail = [
    ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door'],
    ['label' => 'Archive', 'href' => 'historical_records.php', 'icon' => 'bi bi-archive'],
    ['label' => 'Academic Years', 'href' => 'historical_selection.php?year_id=' . $yearId, 'icon' => 'bi bi-calendar3'],
    ['label' => $yearLabel, 'href' => 'historical_selection.php?year_id=' . $yearId],
    ['label' => 'Students', 'href' => 'Historical_records_student.php?year_id=' . $yearId, 'icon' => 'bi bi-people'],
    ['label' => $fullName, 'icon' => 'bi bi-person'],
];
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>STSN Grading System | <?= historicalRecordEscape($fullName) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="./css/historical-records.css">
    <style>
        .hr-record-layout { grid-template-columns: minmax(260px, .8fr) minmax(0, 1.7fr); }
        .hr-record-info-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: .8rem 1rem; }
        .hr-record-info-grid .hr-record-field { margin: 0; min-width: 0; }
        .hr-record-panel .hr-record-info { padding: 1rem; }
        .hr-record-field-wide { grid-column: 1 / -1; }
        .hr-performance-card { min-width: 0; }
        .hr-performance-card .table-responsive { overflow-x: auto; }
        .hr-performance-card table { min-width: 680px; }
        .hr-grade-status { display: block; font-size: .65rem; font-weight: 600; margin-top: .15rem; }
        .hr-grade-status.finalized, .hr-grade-status.approved, .hr-grade-status.approved_by_adviser { color: #008b5b; }
        .hr-grade-status.draft, .hr-grade-status.pending_adviser, .hr-grade-status.submitted_to_adviser { color: #a46a00; }
        .hr-record-error { background: #fff0f0; border: 1px solid #f5c6cb; border-radius: 10px; color: #9f1d24; padding: 1rem 1.2rem; }
        [data-bs-theme="dark"] .hr-record-error { background: #3a1f24; border-color: #5c2d35; color: #ffb4be; }
        [data-bs-theme="dark"] .hr-grade-status.finalized,
        [data-bs-theme="dark"] .hr-grade-status.approved,
        [data-bs-theme="dark"] .hr-grade-status.approved_by_adviser { color: #6ee7a0; }
        [data-bs-theme="dark"] .hr-grade-status.draft,
        [data-bs-theme="dark"] .hr-grade-status.pending_adviser,
        [data-bs-theme="dark"] .hr-grade-status.submitted_to_adviser { color: #ffcc66; }
        [data-bs-theme="dark"] .hr-record-panel,
        [data-bs-theme="dark"] .hr-performance-card,
        [data-bs-theme="dark"] .hr-record-metadata { background: #2d2d2d; border-color: #414141; }
        [data-bs-theme="dark"] .hr-record-panel-title,
        [data-bs-theme="dark"] .hr-performance-card header { background: #353535; border-color: #454545; color: #e6e6e6; }
        [data-bs-theme="dark"] .hr-record-field span,
        [data-bs-theme="dark"] .hr-record-metadata h2,
        [data-bs-theme="dark"] .hr-performance-card header strong,
        [data-bs-theme="dark"] .hr-performance-card table { color: #e6e6e6; }
        [data-bs-theme="dark"] .hr-performance-card header span,
        [data-bs-theme="dark"] .hr-record-field small { color: #aeb7c2; }
        [data-bs-theme="dark"] .hr-performance-card th,
        [data-bs-theme="dark"] .hr-performance-card td { border-color: #454545; }
        [data-bs-theme="dark"] .hr-student-title h1 { color: #e6e6e6; }
        [data-bs-theme="dark"] .hr-student-title p { color: #aeb7c2; }
        @media (max-width: 767.98px) {
            .hr-record-info-grid { grid-template-columns: 1fr; }
            .hr-record-field-wide { grid-column: auto; }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once __DIR__ . '/includes/header.php'; ?>
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3 hr-archive-page stsn-anim-fade-in-up">
                <?php if ($loadError !== ''): ?>
                    <section class="hr-record-error" role="alert"><?= historicalRecordEscape($loadError) ?></section>
                <?php else: ?>
                    <section class="hr-archive-header">
                        <div class="hr-archive-heading">
                            <span class="hr-archive-icon"><i class="bi bi-mortarboard-fill"></i></span>
                            <div>
                                <h1>Student Historical Records</h1>
                                <p><?= historicalRecordEscape($yearLabel) ?> Academic Year — read-only student record</p>
                            </div>
                        </div>
                    </section>

                    <?php require_once __DIR__ . '/includes/breadcrumb.php'; renderBreadcrumb($breadcrumbTrail); ?>

                    <section class="hr-student-title">
                        <div>
                            <h1><?= historicalRecordEscape($fullName) ?></h1>
                            <p>Academic Year <?= historicalRecordEscape($yearLabel) ?> — <?= historicalRecordEscape($gradeLevel) ?> · <?= historicalRecordEscape($sectionNames) ?></p>
                        </div>
                        <div class="hr-student-title-badges">
                            <span><?= historicalRecordEscape($recordStatus) ?></span>
                            <span><i class="bi bi-lock-fill"></i> Read-Only</span>
                        </div>
                    </section>

                    <div class="hr-record-layout">
                        <aside class="hr-record-panel">
                            <div class="hr-record-panel-title">Student Information</div>
                            <div class="hr-record-info">
                                <div class="hr-record-info-grid">
                                    <div class="hr-record-field"><small>Student Name</small><span><?= historicalRecordEscape($fullName) ?></span></div>
                                    <div class="hr-record-field"><small>Student Number</small><span><?= historicalRecordEscape($student['lrn'] ?: '—') ?></span></div>
                                    <div class="hr-record-field"><small>Birthdate</small><span><?= $student['birthdate'] ? historicalRecordEscape(date('M j, Y', strtotime($student['birthdate']))) : '—' ?></span></div>
                                    <div class="hr-record-field"><small>Gender</small><span><?= historicalRecordEscape($student['gender'] ?: '—') ?></span></div>
                                    <div class="hr-record-field"><small>Grade Level</small><span><?= historicalRecordEscape($gradeLevel) ?></span></div>
                                    <div class="hr-record-field"><small>Section</small><span><?= historicalRecordEscape($sectionNames) ?></span></div>
                                    <div class="hr-record-field hr-record-field-wide"><small>Adviser</small><span><?= historicalRecordEscape($adviserNames) ?></span></div>
                                    <div class="hr-record-field hr-record-field-wide"><small>Email</small><span><?= historicalRecordEscape($student['email'] ?: '—') ?></span></div>
                                    <div class="hr-record-field hr-record-field-wide"><small>Address</small><span><?= historicalRecordEscape($address !== '' ? $address : '—') ?></span></div>
                                    <div class="hr-record-field"><small>Postal Code</small><span><?= historicalRecordEscape($student['postal_code'] ?: '—') ?></span></div>
                                    <div class="hr-record-field"><small>Citizenship</small><span><?= historicalRecordEscape($student['citizenship'] ?: '—') ?></span></div>
                                    <div class="hr-record-field hr-record-field-wide"><small>Father</small><span><?= historicalRecordEscape($student['fathers_name'] ?: '—') ?><?= !empty($student['fathers_contact_num']) ? ' · ' . historicalRecordEscape($student['fathers_contact_num']) : '' ?></span></div>
                                    <div class="hr-record-field hr-record-field-wide"><small>Mother</small><span><?= historicalRecordEscape($student['mothers_name'] ?: '—') ?><?= !empty($student['mothers_contact_num']) ? ' · ' . historicalRecordEscape($student['mothers_contact_num']) : '' ?></span></div>
                                    <div class="hr-record-field hr-record-field-wide"><small>Guardian</small><span><?= historicalRecordEscape($student['guardian_name'] ?: '—') ?><?= !empty($student['guardian_contact_num']) ? ' · ' . historicalRecordEscape($student['guardian_contact_num']) : '' ?></span></div>
                                </div>
                            </div>
                        </aside>

                        <div>
                            <section class="hr-performance-card">
                                <header>
                                    <strong>Academic Performance</strong>
                                    <span><?= historicalRecordEscape($yearLabel) ?> · <?= count($terms) ?> terms</span>
                                </header>
                                <?php if ($grades === []): ?>
                                    <div class="hr-record-empty">
                                        <i class="bi bi-journal-x"></i>
                                        <p>No grade records were found for this student in this academic year.</p>
                                    </div>
                                <?php else: ?>
                                    <div class="table-responsive">
                                        <table>
                                            <thead>
                                                <tr>
                                                    <th>Subject</th>
                                                    <?php foreach ($terms as $term): ?>
                                                        <th><?= historicalRecordEscape($term['quarter_label'] ?: ('Term ' . $term['quarter_number'])) ?></th>
                                                    <?php endforeach; ?>
                                                    <th>General Average</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php foreach ($grades as $subjectId => $subject): ?>
                                                <tr>
                                                    <td>
                                                        <?= historicalRecordEscape($subject['subject_name'] ?: ('Subject #' . $subjectId)) ?>
                                                        <?php if ($subject['subject_code'] !== ''): ?><small class="hr-muted"><?= historicalRecordEscape($subject['subject_code']) ?></small><?php endif; ?>
                                                    </td>
                                                    <?php foreach ($terms as $term):
                                                        $termNumber = (int) $term['quarter_number'];
                                                        $grade = $subject['terms'][$termNumber] ?? null;
                                                        $isDescriptive = $grade && $grade['grading_mode'] === 'DESCRIPTIVE';
                                                        $displayGrade = !$grade
                                                            ? '—'
                                                            : ($isDescriptive
                                                                ? ($grade['rating_code'] ?: '—')
                                                                : (($grade['final_grade'] !== null && (float) $grade['final_grade'] > 0)
                                                                    ? number_format((float) $grade['final_grade'], 0)
                                                                    : '—'));
                                                    ?>
                                                        <td>
                                                            <?= historicalRecordEscape($displayGrade) ?>
                                                            <?php if ($grade && $grade['status']): ?>
                                                                <small class="hr-grade-status <?= historicalRecordEscape($grade['status']) ?>"><?= historicalRecordEscape(ucwords(str_replace('_', ' ', $grade['status']))) ?></small>
                                                            <?php endif; ?>
                                                        </td>
                                                    <?php endforeach; ?>
                                                </tr>
                                            <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php endif; ?>
                            </section>

                            <section class="hr-record-metadata">
                                <h2>Record Metadata</h2>
                                <div class="hr-record-info">
                                    <div class="hr-record-field"><small>Academic Year</small><span><?= historicalRecordEscape($yearLabel) ?></span></div>
                                    <div class="hr-record-field"><small>Record Status</small><span><?= historicalRecordEscape($recordStatus) ?></span></div>
                                    <div class="hr-record-field"><small>Saved Year-End Average</small><span><?= $student['archived_final_average'] !== null ? historicalRecordEscape(number_format((float) $student['archived_final_average'], 2)) : '—' ?></span></div>
                                    <div class="hr-record-field"><small>Year Archive Date</small><span><?= $student['year_archived_at'] ? historicalRecordEscape(date('M j, Y', strtotime($student['year_archived_at']))) : '—' ?></span></div>
                                    <div class="hr-record-field"><small>Profile Archive Date</small><span><?= $student['profile_archived_at'] ? historicalRecordEscape(date('M j, Y', strtotime($student['profile_archived_at']))) : '—' ?></span></div>
                                    <div class="hr-record-field"><small>Student Record Archive Date</small><span><?= $student['student_archived_at'] ? historicalRecordEscape(date('M j, Y', strtotime($student['student_archived_at']))) : '—' ?></span></div>
                                    <div class="hr-record-field"><small>Archived By</small><span><?= historicalRecordEscape($archiveActor) ?></span></div>
                                    <div class="hr-record-field"><small>Last Grade Update</small><span>
                                        <?php
                                            $updatedGrades = array_filter(array_column($grades, 'updated_at'));
                                            $lastGradeUpdate = $updatedGrades ? max($updatedGrades) : null;
                                            echo $lastGradeUpdate ? historicalRecordEscape(date('M j, Y', strtotime($lastGradeUpdate))) : '—';
                                        ?>
                                    </span></div>
                                </div>
                            </section>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
    <?php require_once __DIR__ . '/includes/footer.php'; ?>
</div>
<script src="./vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
</body>
</html>
