<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/api/shared/db_connect.php';

$yearId = (string) ($_GET['year_id'] ?? 'demo');
$studentId = (int) ($_GET['student_id'] ?? 0);
$student = [
    'name' => 'Juan Dela Cruz',
    'number' => '2024-001',
    'level' => 'Grade 10',
    'section' => 'St. Joseph',
    'adviser' => 'Ms. Elena Reyes',
    'year' => '2024-2025',
    'date_finalized' => 'Jun 28, 2025',
    'date_archived' => 'Aug 12, 2025',
    'archive_reference' => 'ARC-2025-001',
];

$grades = [
    ['subject' => 'English', 'q1' => 88, 'q2' => 90, 'q3' => 87, 'q4' => 91, 'final' => 89],
    ['subject' => 'Mathematics', 'q1' => 85, 'q2' => 83, 'q3' => 86, 'q4' => 88, 'final' => 86],
    ['subject' => 'Science', 'q1' => 90, 'q2' => 92, 'q3' => 89, 'q4' => 91, 'final' => 91],
    ['subject' => 'Filipino', 'q1' => 87, 'q2' => 85, 'q3' => 88, 'q4' => 89, 'final' => 87],
    ['subject' => 'Araling Panlipunan', 'q1' => 92, 'q2' => 91, 'q3' => 93, 'q4' => 90, 'final' => 92],
    ['subject' => 'MAPEH', 'q1' => 88, 'q2' => 90, 'q3' => 91, 'q4' => 89, 'final' => 90],
    ['subject' => 'TLE / TVE', 'q1' => 91, 'q2' => 93, 'q3' => 90, 'q4' => 94, 'final' => 92],
    ['subject' => 'Values Education', 'q1' => 89, 'q2' => 88, 'q3' => 90, 'q4' => 91, 'final' => 90],
];

if ($yearId !== 'demo' && $studentId > 0) {
    try {
        $stmt = $pdo->prepare("SELECT s.lrn AS number, CONCAT_WS(' ', s.fname, NULLIF(s.mname, ''), s.lname) AS name, COALESCE(gl.grade_level_name, '—') AS level, COALESCE(sec.section_name, '—') AS section, '—' AS adviser, ay.year_label AS year FROM tblstudents s JOIN tblacademicyear ay ON ay.id = ? LEFT JOIN tblstudent_archive sa ON sa.student_id = s.id AND sa.academic_year_id = ay.id LEFT JOIN tblenrollment e ON e.student_id = s.id AND e.academic_year_id = ay.id LEFT JOIN tblgradelevel gl ON gl.id = COALESCE(sa.grade_level_id, e.grade_level_id, s.grade_level_id) LEFT JOIN tblsectionstudent ss ON ss.student_id = s.id AND ss.academic_year_id = ay.id LEFT JOIN tblsection sec ON sec.id = ss.section_id WHERE s.id = ? LIMIT 1");
        $stmt->execute([(int) $yearId, $studentId]);
        $dbStudent = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($dbStudent) {
            $student = array_merge($student, $dbStudent);
        }
    } catch (Throwable $e) {
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>STSN Grading System | <?= htmlspecialchars($student['name']) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="./css/historical-records.css">
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once __DIR__ . '/includes/header.php'; ?>
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>
    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3 hr-archive-page">
                <section class="hr-archive-header">
                    <div class="hr-archive-heading">
                        <span class="hr-archive-icon"><i class="bi bi-mortarboard-fill"></i></span>
                        <div>
                            <h1>Student Historical Records</h1>
                            <p><?= htmlspecialchars($student['year']) ?> Academic Year — archived student records</p>
                        </div>
                    </div>
                </section>

                <?php require_once __DIR__ . '/includes/breadcrumb.php'; renderBreadcrumb([
                    ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door'],
                    ['label' => 'Archive', 'href' => 'historical_records.php', 'icon' => 'bi bi-archive'],
                    ['label' => 'Academic Years', 'href' => 'historical_selection.php?year_id=' . rawurlencode($yearId), 'icon' => 'bi bi-calendar3'],
                    ['label' => $student['year'], 'href' => 'historical_selection.php?year_id=' . rawurlencode($yearId)],
                    ['label' => 'Students', 'icon' => 'bi bi-people']
                ]); ?>

                <section class="hr-student-title">
                    <div><h1><?= htmlspecialchars($student['name']) ?></h1><p>Academic Year <?= htmlspecialchars($student['year']) ?> — <?= htmlspecialchars($student['level']) ?> · <?= htmlspecialchars($student['section']) ?></p></div>
                    <div class="hr-student-title-badges"><span>Archived</span><span><i class="bi bi-lock-fill"></i> Read-Only</span></div>
                </section>

                <div class="hr-student-layout">
                    <aside class="hr-student-info">
                        <h2>Student Information</h2>
                        <dl>
                            <dt>Student Name</dt><dd><?= htmlspecialchars($student['name']) ?></dd>
                            <dt>Student Number</dt><dd><?= htmlspecialchars($student['number']) ?></dd>
                            <dt>Grade Level</dt><dd><?= htmlspecialchars($student['level']) ?></dd>
                            <dt>Section</dt><dd><?= htmlspecialchars($student['section']) ?></dd>
                            <dt>Adviser</dt><dd><?= htmlspecialchars($student['adviser']) ?></dd>
                            <dt>Academic Year</dt><dd><?= htmlspecialchars($student['year']) ?></dd>
                            <dt>Record Status</dt><dd><span class="hr-student-archived">Archived</span></dd>
                        </dl>
                    </aside>

                    <div class="hr-student-main">
                        <section class="hr-performance-card">
                            <header><strong>Academic Performance</strong><span>Academic Year <?= htmlspecialchars($student['year']) ?></span></header>
                            <div class="table-responsive"><table><thead><tr><th>Subject</th><th>Q1</th><th>Q2</th><th>Q3</th><th>Q4</th><th>Final</th><th>Remarks</th></tr></thead><tbody>
                            <?php foreach ($grades as $grade): ?><tr><td><?= htmlspecialchars($grade['subject']) ?></td><td><?= $grade['q1'] ?></td><td><?= $grade['q2'] ?></td><td><?= $grade['q3'] ?></td><td><?= $grade['q4'] ?></td><td class="final-grade"><?= $grade['final'] ?></td><td class="passed">Passed</td></tr><?php endforeach; ?>
                            <tr class="average-row"><td colspan="5">General Average</td><td>90</td><td class="passed">Passed</td></tr>
                            </tbody></table></div>
                        </section>
                        <section class="hr-record-metadata"><h2>Record Metadata</h2><div><dl><dt>Date Finalized</dt><dd><?= htmlspecialchars($student['date_finalized']) ?></dd></dl><dl><dt>Date Archived</dt><dd><?= htmlspecialchars($student['date_archived']) ?></dd></dl><dl><dt>Archived By</dt><dd>Administrator</dd></dl><dl><dt>Record Status</dt><dd><span class="hr-student-archived">Archived</span></dd></dl><dl><dt>Last Verification</dt><dd><?= htmlspecialchars($student['date_archived']) ?></dd></dl><dl><dt>Archive Reference</dt><dd><?= htmlspecialchars($student['archive_reference']) ?></dd></dl></div></section>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <?php require_once __DIR__ . '/includes/footer.php'; ?>
</div>
<script src="./vendor/bootstrap/js/bootstrap.bundle.min.js"></script><script src="./js/adminlte.js"></script>
</body>
</html>
