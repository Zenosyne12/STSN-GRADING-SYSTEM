<?php
session_start();
header('Content-Type: application/json');
error_reporting(0);
ini_set('display_errors', 0);

// Check if db_connect exists
$dbPath = __DIR__ . '/../shared/db_connecr.php';
if (!file_exists($dbPath)) {
    $dbPath = __DIR__ . '/../shared/db_connect.php';
}

if (!file_exists($dbPath)) {
    echo json_encode(['success' => false, 'message' => 'Database configuration not found']);
    exit;
}

require_once $dbPath;

$teacherId = $_SESSION['teacher_id'] ?? null;
$sectionId = $_GET['section_id'] ?? null;

if (!$teacherId) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

if (!$sectionId) {
    echo json_encode(['success' => false, 'message' => 'Missing section_id']);
    exit;
}

try {
    // Check if table exists (using tblsectionstudent)
    $checkTable = $pdo->query("SHOW TABLES LIKE 'tblsectionstudent'");
    if ($checkTable->rowCount() === 0) {
        echo json_encode(['success' => false, 'message' => 'Student table (tblsectionstudent) not found']);
        exit;
    }

    // Get students from tblsectionstudent
    $stmt = $pdo->prepare("
        SELECT 
            ss.id as enrollment_id,
            ss.section_id,
            ss.student_id,
            ss.academic_year_id,
            ss.is_active,
            ss.created_at,
            ss.updated_at,
            CONCAT(s.lname, ', ', s.fname, ' ', COALESCE(s.mname, '')) as student_name,
            s.lrn as student_no,
            s.gender,
            s.fathers_contact_num as contact_no,
            ay.year_label as academic_year
        FROM tblsectionstudent ss
        JOIN tblstudents s ON s.id = ss.student_id
        LEFT JOIN tblacademicyear ay ON ay.id = ss.academic_year_id
        WHERE ss.section_id = ? AND ss.is_active = 1
        ORDER BY s.lname ASC, s.fname ASC
    ");
    $stmt->execute([$sectionId]);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get section info (without assuming grade_level column)
    $sectionStmt = $pdo->prepare("
        SELECT s.*
        FROM tblsection s
        WHERE s.id = ?
    ");
    $sectionStmt->execute([$sectionId]);
    $section = $sectionStmt->fetch(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'data' => $students,
        'section' => $section,
        'count' => count($students)
    ]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>