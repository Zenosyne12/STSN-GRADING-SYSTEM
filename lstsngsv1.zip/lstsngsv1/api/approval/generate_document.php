<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();
require_once __DIR__ . '/../../api/shared/db_connect.php';

$roleId = (int)($_SESSION['role_id'] ?? 0);
if (!in_array($roleId, [1, 2, 4], true)) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$instanceId = (int)($input['instance_id'] ?? 0);

if ($instanceId <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid instance']);
    exit;
}

try {
    // Verify instance exists and is COMPLETED
    $iStmt = $pdo->prepare("
        SELECT i.*, 
               s.section_name, s.id AS sec_id,
               sub.subject_name, sub.id AS sub_id,
               ay.year_label, ay.id AS year_id,
               t.term_label, t.id AS term_id
        FROM tblworkflow_instance i
        JOIN tblsection s ON s.id = i.section_id
        JOIN tblsubjects sub ON sub.id = i.subject_id
        JOIN tblacademicyear ay ON ay.id = i.academic_year_id
        LEFT JOIN tblconfig_terms t ON t.id = i.term_id
        WHERE i.id = ? LIMIT 1
    ");
    $iStmt->execute([$instanceId]);
    $instance = $iStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$instance) {
        echo json_encode(['success' => false, 'error' => 'Instance not found']);
        exit;
    }
    
    if (!in_array($instance['status'], ['COMPLETED', 'FINALIZED', 'APPROVED'], true)) {
        echo json_encode(['success' => false, 'error' => 'Submission not yet fully approved']);
        exit;
    }
    
    // Check if document already exists
    $exStmt = $pdo->prepare("
        SELECT document_id FROM tblapproval_documents 
        WHERE instance_id = ? AND is_revoked = 0 
        LIMIT 1
    ");
    $exStmt->execute([$instanceId]);
    $existing = $exStmt->fetchColumn();
    
    if ($existing) {
        echo json_encode([
            'success' => true,
            'document_id' => $existing,
            'is_existing' => true
        ]);
        exit;
    }
    
    // Generate new document ID
    $year = date('Y');
    $seqStmt = $pdo->query("
        SELECT COUNT(*) + 1 FROM tblapproval_documents 
        WHERE YEAR(generated_at) = YEAR(CURDATE())
    ");
    $seq = (int)$seqStmt->fetchColumn();
    $documentId = 'APP-' . $year . '-' . str_pad($seq, 4, '0', STR_PAD_LEFT);
    
    // Generate verification hash
    $hashData = $instanceId . '|' . $documentId . '|' . date('Y-m-d H:i:s');
    $verificationHash = hash('sha256', $hashData);
    
    // Insert record
    $insStmt = $pdo->prepare("
        INSERT INTO tblapproval_documents
            (document_id, instance_id, section_id, subject_id, term_id,
             academic_year_id, generated_by, verification_hash)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $insStmt->execute([
        $documentId,
        $instanceId,
        (int)$instance['section_id'],
        (int)$instance['subject_id'],
        $instance['term_id'] ? (int)$instance['term_id'] : null,
        (int)$instance['academic_year_id'],
        (int)($_SESSION['user_id'] ?? 0),
        $verificationHash
    ]);
    
    echo json_encode([
        'success' => true,
        'document_id' => $documentId,
        'verification_hash' => $verificationHash
    ]);
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
