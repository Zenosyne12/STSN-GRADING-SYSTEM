<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../login/teacher_auth.php';
require_once __DIR__ . '/../../includes/workflow_engine.php';

$teacherId = (int)($_SESSION['teacher_id'] ?? 0);
if ($teacherId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$instanceId = (int)($input['instance_id'] ?? 0);

if ($instanceId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid instance']);
    exit;
}

try {
    // Verify this instance belongs to this teacher and is REJECTED
    $check = $pdo->prepare("
        SELECT id, template_id, current_step_order
        FROM tblworkflow_instance
        WHERE id = ? AND teacher_id = ? AND status = 'REJECTED'
        LIMIT 1
    ");
    $check->execute([$instanceId, $teacherId]);
    $instance = $check->fetch(PDO::FETCH_ASSOC);

    if (!$instance) {
        echo json_encode(['success' => false, 'message' => 'Submission not found or not returnable']);
        exit;
    }

    // Resolve actor position for the action log (matches advance.php behaviour).
    $actorRole = (int)($_SESSION['role_id'] ?? 2);
    $actorPos  = 'Teacher';
    try {
        $posStmt = $pdo->prepare("SELECT position FROM tblteacher WHERE id = ?");
        $posStmt->execute([$teacherId]);
        $actorPos = $posStmt->fetchColumn() ?: 'Teacher';
    } catch (Throwable $e) {
        $actorPos = 'Teacher';
    }

    // Reset to IN_PROGRESS and move to next step (Adviser = step 2)
    $pdo->beginTransaction();

    $upd = $pdo->prepare("
        UPDATE tblworkflow_instance
        SET status = 'IN_PROGRESS',
            current_step_order = 2,
            submitted_at = NOW()
        WHERE id = ?
    ");
    $upd->execute([$instanceId]);

    // Log SUBMITTED action (wfLogAction signature: pdo, instanceId, stepOrder,
    // actorUserId, actorRoleId, actorPosition, action, remarks).
    if (function_exists('wfLogAction')) {
        wfLogAction($pdo, $instanceId, 1, $teacherId, $actorRole, $actorPos, 'SUBMITTED', 'Resubmitted after return');
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Resubmitted successfully. Sent to Adviser.'
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
