<?php
/**
 * api/workflow/save_template.php
 * Persist the complete step list for a per-year workflow template.
 * Super Admin only. JSON in / JSON out.
 *
 * NOTE: tblworkflow_step.action_type is an ENUM NOT NULL (no default), so it is
 * derived from the chosen position. There is a UNIQUE KEY
 * uq_template_step (template_id, step_order) — existing rows are first parked on
 * negative temp orders (two-pass) so a reorder can never collide mid-update.
 */
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/auth.php';
requireSuperAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

$ALLOWED_POSITIONS = ['Teacher', 'Adviser', 'Subject Coordinator', 'Principal', 'Registrar'];

/** Map a workflow position to the step's action_type enum value. */
function wfActionTypeForPosition(string $position): string
{
    switch ($position) {
        case 'Teacher':             return 'ENCODE';
        case 'Principal':           return 'APPROVE';
        case 'Registrar':           return 'PUBLISH';
        case 'Adviser':             return 'REVIEW';
        case 'Subject Coordinator': return 'REVIEW';
        default:                    return 'REVIEW';
    }
}

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = [];
}

$templateId = (int)($input['template_id'] ?? 0);
$steps      = $input['steps'] ?? [];

if ($templateId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Missing template_id.']);
    exit;
}
if (!is_array($steps) || count($steps) === 0) {
    echo json_encode(['success' => false, 'message' => 'No steps provided.']);
    exit;
}
if (count($steps) > 6) {
    echo json_encode(['success' => false, 'message' => 'Maximum of 6 steps allowed.']);
    exit;
}

$firstStepIsTeacher = false;
foreach ($steps as $s) {
    if (!is_array($s)) {
        continue;
    }
    if ((int)($s['step_order'] ?? 0) === 1 && trim((string)($s['required_position'] ?? '')) === 'Teacher') {
        $firstStepIsTeacher = true;
        break;
    }
}
if (!$firstStepIsTeacher) {
    echo json_encode(['success' => false, 'message' => 'Step 1 must be Teacher Encoding.']);
    exit;
}

try {
    // Template must exist.
    $tplStmt = $pdo->prepare('SELECT id FROM tblworkflow_template WHERE id = ? LIMIT 1');
    $tplStmt->execute([$templateId]);
    if (!$tplStmt->fetchColumn()) {
        echo json_encode(['success' => false, 'message' => 'Template not found.']);
        exit;
    }

    $pdo->beginTransaction();

    // Existing step ids for this template.
    $exStmt = $pdo->prepare('SELECT id FROM tblworkflow_step WHERE template_id = ? ORDER BY step_order ASC');
    $exStmt->execute([$templateId]);
    $existingIds = array_map('intval', $exStmt->fetchAll(PDO::FETCH_COLUMN));
    $existingSet = array_fill_keys($existingIds, true);

    // Pass 1 — park every existing step on a unique NEGATIVE order so the
    // UNIQUE KEY uq_template_step (template_id, step_order) cannot collide
    // while the positive 1..N sequence is rewritten below.
    $park = $pdo->prepare('UPDATE tblworkflow_step SET step_order = ? WHERE id = ? AND template_id = ?');
    foreach ($existingIds as $i => $sid) {
        $park->execute([-($i + 1), $sid, $templateId]);
    }

    $upd = $pdo->prepare(
        'UPDATE tblworkflow_step
            SET step_order = ?, step_label = ?, required_position = ?,
                action_type = ?, allow_mark_checked = ?, can_reject = ?, is_required = 1
          WHERE id = ? AND template_id = ?'
    );
    $ins = $pdo->prepare(
        'INSERT INTO tblworkflow_step
            (template_id, step_order, step_label, required_position, action_type,
             allow_mark_checked, can_reject, is_required, deadline_rule)
         VALUES (?, ?, ?, ?, ?, ?, ?, 1, \'NONE\')'
    );

    $kept  = [];
    $order = 0;
    foreach ($steps as $s) {
        if (!is_array($s)) {
            continue;
        }
        $label = trim((string)($s['step_label'] ?? ''));
        $pos   = trim((string)($s['required_position'] ?? ''));
        if ($label === '' || $pos === '') {
            continue;
        }
        if (!in_array($pos, $ALLOWED_POSITIONS, true)) {
            continue;
        }
        if (mb_strlen($label) > 50) {
            $label = mb_substr($label, 0, 50);
        }

        $order++;
        $checked = !empty($s['allow_mark_checked']) ? 1 : 0;
        $reject  = !empty($s['can_reject']) ? 1 : 0;
        $atype   = wfActionTypeForPosition($pos);
        $stepId  = (int)($s['step_id'] ?? 0);

        if ($stepId > 0 && isset($existingSet[$stepId])) {
            $upd->execute([$order, $label, $pos, $atype, $checked, $reject, $stepId, $templateId]);
            $kept[$stepId] = true;
        } else {
            $ins->execute([$templateId, $order, $label, $pos, $atype, $checked, $reject]);
        }
    }

    if ($order === 0) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => 'No valid steps to save.']);
        exit;
    }

    // Delete steps that were removed in the UI (existed before, absent now).
    $del = $pdo->prepare('DELETE FROM tblworkflow_step WHERE id = ? AND template_id = ?');
    foreach ($existingIds as $sid) {
        if (!isset($kept[$sid])) {
            $del->execute([$sid, $templateId]);
        }
    }

    $pdo->commit();
    echo json_encode(['success' => true, 'message' => 'Workflow saved.', 'step_count' => $order]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(['success' => false, 'message' => 'Save failed: ' . $e->getMessage()]);
}
