<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();
require_once __DIR__ . '/../../api/shared/db_connect.php';

$sectionId = (int)($_GET['section_id'] ?? 0);
$subjectId = (int)($_GET['subject_id'] ?? 0);

if ($sectionId <= 0) {
    echo json_encode(['success' => false, 'error' => 'Missing section_id']);
    exit;
}

try {
    $sql = "
        SELECT id FROM tblworkflow_instance
        WHERE section_id = ?
          AND status IN ('COMPLETED', 'FINALIZED', 'APPROVED')
    ";
    $params = [$sectionId];
    
    if ($subjectId > 0) {
        $sql .= " AND subject_id = ?";
        $params[] = $subjectId;
    }
    
    $sql .= " ORDER BY id DESC LIMIT 1";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $instanceId = (int)$stmt->fetchColumn();
    
    if ($instanceId > 0) {
        echo json_encode(['success' => true, 'instance_id' => $instanceId]);
    } else {
        echo json_encode(['success' => false, 'error' => 'No approved instance found']);
    }
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
