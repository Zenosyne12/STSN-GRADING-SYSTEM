<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { echo json_encode(['success'=>false,'message'=>'Missing id']); exit; }

try {
    $stmt = $pdo->prepare("SELECT i.*, s.section_name, gl.grade_level_name, sub.subject_name, q.term_label AS quarter_label, q.term_number AS quarter_number, tch.fname, tch.lname, (SELECT MAX(step_order) FROM tblworkflow_step WHERE template_id=i.template_id) AS max_step, (SELECT step_label FROM tblworkflow_step WHERE template_id=i.template_id AND step_order=i.current_step_order LIMIT 1) AS step_label FROM tblworkflow_instance i LEFT JOIN tblsection s ON s.id=i.section_id LEFT JOIN tblgradelevel gl ON gl.id=s.grade_level_id LEFT JOIN tblsubjects sub ON sub.id=i.subject_id LEFT JOIN tblconfig_terms q ON q.id=i.term_id LEFT JOIN tblteacher tch ON tch.id=i.teacher_id WHERE i.id=?");
    $stmt->execute([$id]);
    $meta = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$meta) { echo json_encode(['success'=>false,'message'=>'Not found']); exit; }

    $gStmt = $pdo->prepare("SELECT st.lname, st.fname, st.lrn, g.ww_total, g.pt_total, g.qa_total, g.initial_grade, g.final_grade, g.remarks FROM tblgrades g INNER JOIN tblstudents st ON st.id=g.student_id WHERE g.section_id=? AND g.subject_id=? AND g.quarter=? AND g.academic_year_id=? ORDER BY st.lname, st.fname");
    $gStmt->execute([$meta['section_id'], $meta['subject_id'], $meta['quarter_number'], $meta['academic_year_id']]);
    $grades = $gStmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch full workflow chain (all steps + their actions)
    $chainStmt = $pdo->prepare("SELECT ws.step_order, ws.step_label, ws.required_position, ws.action_type, l.actor_user_id, l.actor_position, l.action, l.remarks, l.acted_at, t.fname AS teacher_fname, t.lname AS teacher_lname FROM tblworkflow_step ws LEFT JOIN tblworkflow_action_log l ON l.instance_id = ? AND l.step_order = ws.step_order LEFT JOIN tblteacher t ON t.id = l.actor_user_id WHERE ws.template_id = ? ORDER BY ws.step_order ASC");
    $chainStmt->execute([$id, (int)$meta['template_id']]);
    $chainRows = $chainStmt->fetchAll(PDO::FETCH_ASSOC);

    $chain = [];
    $currentStep = (int)$meta['current_step_order'];
    foreach ($chainRows as $row) {
        $stepOrder = (int)$row['step_order'];
        $status = 'pending';
        if ($row['acted_at']) {
            $status = 'done';
        } elseif ($stepOrder === $currentStep) {
            $status = 'current';
        }
        $chain[] = [
            'step_order'        => $stepOrder,
            'step_label'        => $row['step_label'],
            'required_position' => $row['required_position'],
            'actor_name'        => trim(($row['teacher_fname'] ?? '') . ' ' . ($row['teacher_lname'] ?? '')),
            'actor_position'    => $row['actor_position'] ?? $row['required_position'],
            'action'            => $row['action'],
            'acted_at'          => $row['acted_at'],
            'remarks'           => $row['remarks'],
            'status'            => $status,
        ];
    }

    echo json_encode(['success'=>true,'meta'=>['subject'=>$meta['subject_name'],'section'=>($meta['grade_level_name']??'').' - '.($meta['section_name']??''),'term'=>$meta['quarter_label']??'Term','submitter'=>trim(($meta['fname']??'').' '.($meta['lname']??'')),'step_label'=>$meta['step_label'],'step_order'=>(int)$meta['current_step_order'],'max_step'=>(int)$meta['max_step'],'status'=>$meta['status']],'students'=>array_map(fn($g)=>['name'=>trim($g['lname'].', '.$g['fname']),'lrn'=>$g['lrn'],'ww'=>(float)$g['ww_total'],'pt'=>(float)$g['pt_total'],'qa'=>(float)$g['qa_total'],'initial'=>(float)$g['initial_grade'],'final'=>(float)$g['final_grade'],'remarks'=>$g['remarks']], $grades),'chain'=>$chain]);
} catch (Throwable $e) {
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
