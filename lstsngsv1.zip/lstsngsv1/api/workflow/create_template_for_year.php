<?php
/**
 * api/workflow/create_template_for_year.php
 * Create the per-year workflow template for an academic year by either
 * copying the most recent template or seeding the default 5-step chain.
 * Super Admin only. JSON in / JSON out.
 *
 * NOTE: tblworkflow_step.action_type is an ENUM NOT NULL (no default), so it is
 * always supplied explicitly.
 */
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/auth.php';
requireSuperAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = [];
}

$yearId = (int)($input['academic_year_id'] ?? 0);
$mode   = (($input['mode'] ?? 'empty') === 'copy') ? 'copy' : 'empty';

if ($yearId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Missing academic_year_id.']);
    exit;
}

try {
    // Validate the academic year.
    $yStmt = $pdo->prepare('SELECT year_label FROM tblacademicyear WHERE id = ? LIMIT 1');
    $yStmt->execute([$yearId]);
    $yearLabel = $yStmt->fetchColumn();
    if ($yearLabel === false) {
        echo json_encode(['success' => false, 'message' => 'Academic year not found.']);
        exit;
    }

    // One template per year.
    $exists = $pdo->prepare('SELECT id FROM tblworkflow_template WHERE academic_year_id = ? LIMIT 1');
    $exists->execute([$yearId]);
    if ($exists->fetchColumn()) {
        echo json_encode(['success' => false, 'message' => 'A workflow template already exists for this year.']);
        exit;
    }

    $pdo->beginTransaction();

    // Create the template bound to this year.
    $insT = $pdo->prepare(
        'INSERT INTO tblworkflow_template (academic_year_id, template_name, is_default, is_active)
         VALUES (?, ?, 0, 1)'
    );
    $insT->execute([$yearId, 'Workflow for ' . $yearLabel]);
    $newTemplateId = (int)$pdo->lastInsertId();

    $insS = $pdo->prepare(
        'INSERT INTO tblworkflow_step
            (template_id, step_order, step_label, required_position, action_type,
             allow_mark_checked, can_reject, is_required, deadline_rule)
         VALUES (?, ?, ?, ?, ?, ?, ?, 1, \'NONE\')'
    );

    if ($mode === 'copy') {
        // Most recent OTHER template (prefer the active one).
        $srcStmt = $pdo->prepare(
            'SELECT id FROM tblworkflow_template
              WHERE id <> ?
              ORDER BY is_active DESC, id DESC
              LIMIT 1'
        );
        $srcStmt->execute([$newTemplateId]);
        $srcTplId = (int)$srcStmt->fetchColumn();

        if ($srcTplId > 0) {
            $srcSteps = $pdo->prepare(
                'SELECT step_order, step_label, required_position, action_type,
                        allow_mark_checked, can_reject
                   FROM tblworkflow_step
                  WHERE template_id = ?
                  ORDER BY step_order ASC'
            );
            $srcSteps->execute([$srcTplId]);
            foreach ($srcSteps->fetchAll(PDO::FETCH_ASSOC) as $s) {
                $insS->execute([
                    $newTemplateId,
                    (int)$s['step_order'],
                    (string)$s['step_label'],
                    (string)$s['required_position'],
                    (string)$s['action_type'],
                    (int)$s['allow_mark_checked'],
                    (int)$s['can_reject'],
                ]);
            }
        }
    }

    // If copying produced nothing (or mode = 'empty'), seed the default 5-step chain.
    $cntStmt = $pdo->prepare('SELECT COUNT(*) FROM tblworkflow_step WHERE template_id = ?');
    $cntStmt->execute([$newTemplateId]);
    if ((int)$cntStmt->fetchColumn() === 0) {
        $defaults = [
            [1, 'Teacher Encoding',   'Teacher',             'ENCODE',  0, 1],
            [2, 'Adviser Review',     'Adviser',             'REVIEW',  0, 1],
            [3, 'Coordinator Review', 'Subject Coordinator', 'REVIEW',  1, 1],
            [4, 'Principal Approval', 'Principal',           'APPROVE', 0, 1],
            [5, 'Registrar Publish',  'Registrar',           'PUBLISH', 0, 1],
        ];
        foreach ($defaults as $d) {
            $insS->execute([$newTemplateId, $d[0], $d[1], $d[2], $d[3], $d[4], $d[5]]);
        }
    }

    $pdo->commit();
    echo json_encode(['success' => true, 'template_id' => $newTemplateId, 'mode' => $mode]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(['success' => false, 'message' => 'Create failed: ' . $e->getMessage()]);
}
