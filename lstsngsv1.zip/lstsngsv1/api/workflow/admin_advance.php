<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../../includes/workflow_engine.php';

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$instanceId = (int)($input['instance_id'] ?? 0);
$action = strtoupper($input['action'] ?? 'APPROVED');
$remarks = trim($input['remarks'] ?? '');

if (!$instanceId) { echo json_encode(['success'=>false,'message'=>'Missing instance_id']); exit; }
if (!in_array($action,['APPROVED','REJECTED'],true)) { echo json_encode(['success'=>false,'message'=>'Invalid action']); exit; }

$actorId = (int)($_SESSION['user_id'] ?? $_SESSION['teacher_id'] ?? 0);
$actorRole = 1;
$actorPos = 'Registrar';

try {
    if (!function_exists('advanceWorkflow')) { echo json_encode(['success'=>false,'message'=>'Engine not loaded']); exit; }
    $r = advanceWorkflow($pdo, ['instance_id'=>$instanceId,'actor_user_id'=>$actorId,'actor_role_id'=>$actorRole,'actor_position'=>$actorPos,'action'=>$action,'remarks'=>$remarks]);
    $r['message'] = $r['success'] ? ($action==='APPROVED' ? 'Published successfully. Workflow completed.' : 'Returned to Teacher.') : ($r['message'] ?? 'Failed');
    if ($r['success'] && ($r['legacy_sync'] ?? true) === false) {
        $r['message'] .= ' (Warning: legacy grade finalize failed.)';
    }
    echo json_encode($r);
} catch (Throwable $e) {
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
