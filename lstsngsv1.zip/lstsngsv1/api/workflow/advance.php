<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../login/teacher_auth.php';
require_once __DIR__ . '/../../includes/workflow_engine.php';

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$instanceId = (int)($input['instance_id'] ?? 0);
$action     = strtoupper($input['action'] ?? 'APPROVED');
$remarks    = trim($input['remarks'] ?? '');

if (!$instanceId) { echo json_encode(['success'=>false,'message'=>'Missing instance_id']); exit; }
if (!in_array($action,['APPROVED','REJECTED'],true)) {
    echo json_encode(['success'=>false,'message'=>'Invalid action']); exit;
}

// tblteacher.position holds the workflow position
// (Adviser, Principal, Subject Coordinator, Teacher).
$actorId   = (int)($_SESSION['teacher_id'] ?? $_SESSION['user_id'] ?? 0);
$actorRole = (int)($_SESSION['role_id'] ?? 2);
$actorPos = 'Teacher';
try {
    $p = $pdo->prepare("SELECT position FROM tblteacher WHERE id = ?");
    $p->execute([$actorId]);
    $actorPos = $p->fetchColumn() ?: '';
    if ($actorPos === '' || $actorPos === null) {
        $actorPos = ($actorRole === 1) ? 'Registrar' : 'Teacher';
    }
} catch (Throwable $e) {
    $actorPos = ($actorRole === 1) ? 'Registrar' : 'Teacher';
}

try {
    if (!function_exists('advanceWorkflow')) {
        echo json_encode(['success'=>false,'message'=>'Engine not loaded']); exit;
    }
    $r = advanceWorkflow($pdo, [
        'instance_id'=>$instanceId,
        'actor_user_id'=>$actorId,
        'actor_role_id'=>$actorRole,
        'actor_position'=>$actorPos,
        'action'=>$action,
        'remarks'=>$remarks
    ]);
    $r['message'] = $r['success']
        ? ($action==='APPROVED'
            ? 'Approved. Moved to next step.'
            : 'Returned to Teacher.')
        : ($r['message'] ?? 'Failed');
    echo json_encode($r);
} catch (Throwable $e) {
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
