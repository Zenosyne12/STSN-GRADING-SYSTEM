<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();
require_once __DIR__ . '/../../api/shared/db_connect.php';

$userId = (int)($_SESSION['user_id'] ?? 0);
if ($userId <= 0) {
    echo json_encode(['success' => false, 'error' => 'Not authenticated']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$sectionId = (int)($input['section_id'] ?? 0);
$subjectId = (int)($input['subject_id'] ?? 0);
$termId    = (int)($input['term_id'] ?? 0);
$yearId    = (int)($input['academic_year_id'] ?? 0);
$checked   = !empty($input['checked']);

if ($sectionId <= 0 || $subjectId <= 0 || $yearId <= 0) {
    echo json_encode(['success' => false, 'error' => 'Missing required fields']);
    exit;
}

try {
    if ($checked) {
        $stmt = $pdo->prepare("
            INSERT INTO tblworkflow_review_checks
                (user_id, section_id, subject_id, term_id, academic_year_id)
            VALUES (?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE checked_at = CURRENT_TIMESTAMP
        ");
        $stmt->execute([$userId, $sectionId, $subjectId, $termId ?: null, $yearId]);
        echo json_encode(['success' => true, 'checked' => true]);
    } else {
        $stmt = $pdo->prepare("
            DELETE FROM tblworkflow_review_checks
            WHERE user_id = ? AND section_id = ? AND subject_id = ?
              AND (term_id <=> ?) AND academic_year_id = ?
        ");
        $stmt->execute([$userId, $sectionId, $subjectId, $termId ?: null, $yearId]);
        echo json_encode(['success' => true, 'checked' => false]);
    }
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
