<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();
require_once __DIR__ . '/../../api/shared/db_connect.php';

$userId = (int)($_SESSION['user_id'] ?? 0);
$yearId = (int)($_GET['academic_year_id'] ?? 0);
$termId = (int)($_GET['term_id'] ?? 0);

try {
    $sql = "SELECT section_id, subject_id, term_id, academic_year_id, checked_at
            FROM tblworkflow_review_checks
            WHERE user_id = ?";
    $params = [$userId];

    if ($yearId > 0) {
        $sql .= " AND academic_year_id = ?";
        $params[] = $yearId;
    }
    if ($termId > 0) {
        $sql .= " AND term_id = ?";
        $params[] = $termId;
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    echo json_encode(['success' => true, 'checks' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'checks' => [], 'error' => $e->getMessage()]);
}
