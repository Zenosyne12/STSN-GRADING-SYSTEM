<?php
header('Content-Type: application/json');
require_once '../shared/db_connect.php';

$data = json_decode(file_get_contents('php://input'), true);

try {
    $id = $data['id'] ?? null;

    if (!$id) {
        throw new Exception('Quarter ID is required');
    }

    // Check if quarter is active
    $checkStmt = $pdo->prepare("SELECT is_active FROM tblquarters WHERE id = ?");
    $checkStmt->execute([$id]);
    $quarter = $checkStmt->fetch(PDO::FETCH_ASSOC);

    if ($quarter && $quarter['is_active']) {
        throw new Exception('Cannot delete active quarter');
    }

    $stmt = $pdo->prepare("DELETE FROM tblquarters WHERE id = ?");
    $stmt->execute([$id]);

    echo json_encode([
        'success' => true,
        'message' => 'Quarter deleted successfully'
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>