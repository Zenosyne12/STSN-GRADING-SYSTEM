<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../shared/db_connect.php';

$academicYearId = isset($_GET['academic_year_id']) ? (int)$_GET['academic_year_id'] : 0;

if (!$academicYearId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Academic year ID required']);
    exit;
}

try {
    $stmt = $pdo->prepare("
        SELECT 
            id,
            quarter_name,
            start_date,
            end_date,
            is_active,
            is_current
        FROM tblquarters
        WHERE academic_year_id = ?
        ORDER BY start_date ASC
    ");
    $stmt->execute([$academicYearId]);
    $quarters = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'quarters' => $quarters,
        'count' => count($quarters)
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>