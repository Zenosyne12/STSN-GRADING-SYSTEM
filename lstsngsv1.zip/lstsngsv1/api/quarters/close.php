<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../shared/db_connect.php';

try {
    $data     = json_decode(file_get_contents('php://input'), true);
    $id       = isset($data['id'])        ? (int)$data['id']       : 0;
    $isClosed = isset($data['is_closed']) ? (int)$data['is_closed'] : 1;

    if (!$id) throw new Exception('Quarter ID is required.');

    $pdo->beginTransaction();

    if ($isClosed) {
        // Archiving: deactivate first, then mark closed
        $pdo->prepare("UPDATE tblquarters SET is_active = 0, is_closed = 1 WHERE id = ?")->execute([$id]);
        $action = 'archived';
    } else {
        // Restoring: just unclose it (leave inactive — admin activates manually)
        $pdo->prepare("UPDATE tblquarters SET is_closed = 0 WHERE id = ?")->execute([$id]);
        $action = 'restored';
    }

    $pdo->commit();

    echo json_encode(['success' => true, 'message' => "Quarter {$action} successfully."]);

} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}