<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../shared/db_connect.php';

try {
    $data     = json_decode(file_get_contents('php://input'), true);
    $id       = isset($data['id'])        ? (int)$data['id']       : 0;
    $isActive = isset($data['is_active']) ? (int)$data['is_active'] : 0;

    if (!$id) throw new Exception('Quarter ID is required.');

    // Load quarter with year info
    $stmt = $pdo->prepare("
        SELECT q.*, ay.is_active AS year_active, ay.year_label
        FROM   tblquarters q
        JOIN   tblacademicyear ay ON ay.id = q.academic_year_id
        WHERE  q.id = ?
    ");
    $stmt->execute([$id]);
    $quarter = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$quarter) throw new Exception('Quarter not found.');

    if ((int)$quarter['is_closed'] === 1) {
        throw new Exception('Cannot activate an archived quarter. Restore it first.');
    }

    if ($isActive && !(int)$quarter['year_active']) {
        throw new Exception('Cannot activate a quarter for an inactive academic year.');
    }

    $pdo->beginTransaction();

    if ($isActive) {
        // Deactivate all quarters globally — only one active at a time
        $pdo->exec("UPDATE tblquarters SET is_active = 0");
    }

    $pdo->prepare("UPDATE tblquarters SET is_active = ? WHERE id = ?")->execute([$isActive, $id]);

    $pdo->commit();

    $action = $isActive ? 'activated' : 'deactivated';
    echo json_encode([
        'success' => true,
        'message' => "{$quarter['quarter_label']} Quarter, S.Y. {$quarter['year_label']} {$action} successfully.",
    ]);

} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}