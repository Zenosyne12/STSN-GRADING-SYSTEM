<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../shared/db_connect.php';

try {
    $viewYearId = isset($_GET['view_year_id']) ? (int)$_GET['view_year_id'] : null;

    // Resolve viewing year
    if (!$viewYearId) {
        $viewYearId = (int)$pdo->query(
            "SELECT COALESCE(id,0) FROM tblacademicyear WHERE is_active = 1 LIMIT 1"
        )->fetchColumn();
    }

    $yearStmt = $pdo->prepare("SELECT id, year_label, is_active FROM tblacademicyear WHERE id = ?");
    $yearStmt->execute([$viewYearId]);
    $viewingYear = $yearStmt->fetch(PDO::FETCH_ASSOC);

    if (!$viewingYear) {
        $viewingYear = $pdo->query(
            "SELECT id, year_label, is_active FROM tblacademicyear ORDER BY year_label DESC LIMIT 1"
        )->fetch(PDO::FETCH_ASSOC);
        $viewYearId  = $viewingYear['id'] ?? null;
    }

    // Quarters for this year
    $qStmt = $pdo->prepare("
        SELECT q.*, ay.year_label, ay.is_active AS year_is_active
        FROM   tblquarters q
        JOIN   tblacademicyear ay ON ay.id = q.academic_year_id
        WHERE  q.academic_year_id = ?
        ORDER  BY q.quarter_number ASC
    ");
    $qStmt->execute([$viewYearId]);
    $quarters = $qStmt->fetchAll(PDO::FETCH_ASSOC);

    // Global active quarter
    $activeQuarter = $pdo->query("
        SELECT q.*, ay.year_label
        FROM   tblquarters q
        JOIN   tblacademicyear ay ON ay.id = q.academic_year_id
        WHERE  q.is_active = 1
        LIMIT  1
    ")->fetch(PDO::FETCH_ASSOC) ?: null;

    // All years for navigator
    $allYears = $pdo->query(
        "SELECT id, year_label, is_active FROM tblacademicyear ORDER BY year_label DESC"
    )->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success'        => true,
        'quarters'       => $quarters,
        'viewing_year'   => $viewingYear,
        'active_quarter' => $activeQuarter,
        'all_years'      => $allYears,
        'page'           => 1,
        'pages'          => 1,
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to load quarters: ' . $e->getMessage()]);
}