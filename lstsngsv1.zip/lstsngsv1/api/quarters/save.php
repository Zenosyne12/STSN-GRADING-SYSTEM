<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../shared/db_connect.php';

try {
    $data      = json_decode(file_get_contents('php://input'), true);
    $id        = isset($data['id'])         ? (int)$data['id']    : 0;
    $startDate = isset($data['start_date']) ? $data['start_date'] : null;
    $endDate   = isset($data['end_date'])   ? $data['end_date']   : null;

    if (!$id) throw new Exception('Quarter ID is required.');

    // Validate dates if provided
    if ($startDate !== null && $startDate !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $startDate)) {
        throw new Exception('Invalid start date format.');
    }
    if ($endDate !== null && $endDate !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $endDate)) {
        throw new Exception('Invalid end date format.');
    }

    // Sanitize empty strings to NULL
    $startDate = ($startDate === '') ? null : $startDate;
    $endDate   = ($endDate   === '') ? null : $endDate;

    if ($startDate && $endDate && $endDate < $startDate) {
        throw new Exception('End date cannot be earlier than start date.');
    }

    $stmt = $pdo->prepare("UPDATE tblquarters SET start_date = ?, end_date = ? WHERE id = ?");
    $stmt->execute([$startDate, $endDate, $id]);

    echo json_encode(['success' => true, 'message' => 'Quarter dates updated successfully.']);

} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}