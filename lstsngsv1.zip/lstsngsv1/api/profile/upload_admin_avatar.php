<?php
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();

$userId = (int) ($_SESSION['user_id'] ?? 0);
$file = $_FILES['avatar'] ?? null;

if ($userId < 1 || !$file || $file['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please choose a valid image.']);
    exit;
}

if ($file['size'] > 5 * 1024 * 1024) {
    http_response_code(413);
    echo json_encode(['success' => false, 'message' => 'The image must be 5 MB or smaller.']);
    exit;
}

$imageInfo = @getimagesize($file['tmp_name']);
$allowedTypes = [
    IMAGETYPE_JPEG => 'jpg',
    IMAGETYPE_PNG => 'png',
    IMAGETYPE_WEBP => 'webp',
];
$imageType = $imageInfo[2] ?? 0;

if (!$imageInfo || !isset($allowedTypes[$imageType])) {
    http_response_code(415);
    echo json_encode(['success' => false, 'message' => 'Only JPG, PNG, and WebP images are allowed.']);
    exit;
}

$uploadDirectory = dirname(__DIR__, 2) . '/assets/img';
if (!is_dir($uploadDirectory) && !mkdir($uploadDirectory, 0755, true)) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'The image folder is unavailable.']);
    exit;
}

$baseName = 'admin_avatar_' . $userId;
foreach (array_values($allowedTypes) as $extension) {
    $oldFile = $uploadDirectory . '/' . $baseName . '.' . $extension;
    if (is_file($oldFile)) {
        unlink($oldFile);
    }
}

$extension = $allowedTypes[$imageType];
$targetFile = $uploadDirectory . '/' . $baseName . '.' . $extension;
if (!move_uploaded_file($file['tmp_name'], $targetFile)) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'The image could not be saved.']);
    exit;
}

$relativeUrl = 'assets/img/' . $baseName . '.' . $extension;
echo json_encode([
    'success' => true,
    'url' => $relativeUrl . '?v=' . filemtime($targetFile),
]);
