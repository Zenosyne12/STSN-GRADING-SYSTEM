<?php
session_start();

require_once __DIR__ . '/../../api/shared/db_connect.php';

$response = ['success' => false, 'message' => ''];

// Check if user is logged in as teacher
if (!isset($_SESSION['teacher_id']) && !isset($_SESSION['username'])) {
    header('Location: ../../pages/Profile.php?error=' . urlencode('Unauthorized access.'));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../../pages/Profile.php?error=' . urlencode('Invalid request method.'));
    exit;
}

try {
    if (!isset($pdo)) {
        throw new Exception('Database connection not available.');
    }

    $teacherId = $_POST['teacher_id'] ?? '';
    $fname = trim($_POST['fname'] ?? '');
    $lname = trim($_POST['lname'] ?? '');
    $mname = trim($_POST['mname'] ?? '');
    $contactNo = trim($_POST['contact_no'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    // Validate required fields
    if (empty($fname) || empty($lname)) {
        header('Location: ../../pages/Profile.php?error=' . urlencode('First name and last name are required.'));
        exit;
    }

    // Get teacher record by teacher_id string (e.g., 'T00005')
    $stmt = $pdo->prepare("SELECT id FROM tblteacher WHERE teacher_id = ? LIMIT 1");
    $stmt->execute([$teacherId]);
    $teacher = $stmt->fetch(PDO::FETCH_ASSOC);

    // Fallback: try by integer id if string lookup fails
    if (!$teacher && is_numeric($teacherId)) {
        $stmt2 = $pdo->prepare("SELECT id FROM tblteacher WHERE id = ? LIMIT 1");
        $stmt2->execute([(int)$teacherId]);
        $teacher = $stmt2->fetch(PDO::FETCH_ASSOC);
    }

    if (!$teacher) {
        header('Location: ../../pages/Profile.php?error=' . urlencode('Teacher record not found.'));
        exit;
    }

    $teacherDbId = $teacher['id'];

    // Update teacher info
    $updateStmt = $pdo->prepare("
        UPDATE tblteacher 
        SET fname = ?, lname = ?, mname = ?, contact_no = ?, email = ?
        WHERE id = ?
    ");
    $updateStmt->execute([$fname, $lname, $mname, $contactNo, $email, $teacherDbId]);

    // Handle password change
    if (!empty($newPassword)) {
        if ($newPassword !== $confirmPassword) {
            header('Location: ../../pages/Profile.php?error=' . urlencode('New password and confirm password do not match.'));
            exit;
        }

        if (strlen($newPassword) < 6) {
            header('Location: ../../pages/Profile.php?error=' . urlencode('Password must be at least 6 characters long.'));
            exit;
        }

        // Get user record
        $userStmt = $pdo->prepare("
            SELECT id, password_hash FROM tblusers 
            WHERE reference_id = ? AND role_id = 2 
            LIMIT 1
        ");
        $userStmt->execute([$teacherDbId]);
        $user = $userStmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // Verify current password
            if (!empty($currentPassword)) {
                if (!password_verify($currentPassword, $user['password_hash'])) {
                    header('Location: ../../pages/Profile.php?error=' . urlencode('Current password is incorrect.'));
                    exit;
                }
            }

            // Update password
            $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
            $pwStmt = $pdo->prepare("
                UPDATE tblusers 
                SET password_hash = ?, must_change_password = 0, updated_at = NOW()
                WHERE id = ?
            ");
            $pwStmt->execute([$newHash, $user['id']]);
        }
    }

    // Update session
    $_SESSION['teacher_name'] = trim($fname . ' ' . $mname . ' ' . $lname);

    // Redirect with success message
    header('Location: ../../pages/Profile.php?success=' . urlencode('Profile updated successfully.'));
    exit;

} catch (PDOException $e) {
    error_log("Profile Update Error: " . $e->getMessage());
    header('Location: ../../pages/Profile.php?error=' . urlencode('Database error occurred. Please try again.'));
    exit;
} catch (Exception $e) {
    error_log("Profile Update Error: " . $e->getMessage());
    header('Location: ../../pages/Profile.php?error=' . urlencode('Error: ' . $e->getMessage()));
    exit;
}