<?php
/**
 * api/profile/update_admin.php
 * Updates admin profile: username, password.
 */
ob_start();
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
ob_end_clean();

$rootUrl = rtrim(dirname(dirname(dirname($_SERVER['SCRIPT_NAME']))), '/');

function redirectBack(bool $success, string $msg): void
{
    global $rootUrl;
    $param = $success ? 'success' : 'error';
    header("Location: {$rootUrl}/admin-profile.php?{$param}=" . urlencode($msg));
    exit;
}

$userId = (int) ($_POST['user_id'] ?? 0);
$username = trim($_POST['username'] ?? '');
$currentPassword = $_POST['current_password'] ?? '';
$newPassword = $_POST['new_password'] ?? '';
$confirmPassword = $_POST['confirm_password'] ?? '';

if (!$userId) {
    redirectBack(false, 'User ID is required.');
}

if (empty($username)) {
    redirectBack(false, 'Username is required.');
}

try {
    // Check if username is taken by another user
    $checkStmt = $pdo->prepare("SELECT id FROM tblusers WHERE username = ? AND id != ? LIMIT 1");
    $checkStmt->execute([$username, $userId]);
    if ($checkStmt->fetch()) {
        redirectBack(false, 'Username is already taken.');
    }

    // If password change requested
    if ($newPassword || $confirmPassword) {
        if (empty($currentPassword)) {
            redirectBack(false, 'Current password is required to change password.');
        }
        if ($newPassword !== $confirmPassword) {
            redirectBack(false, 'New password and confirmation do not match.');
        }
        if (strlen($newPassword) < 6) {
            redirectBack(false, 'New password must be at least 6 characters.');
        }

        // Verify current password
        $pwStmt = $pdo->prepare("SELECT password_hash FROM tblusers WHERE id = ? LIMIT 1");
        $pwStmt->execute([$userId]);
        $user = $pwStmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            redirectBack(false, 'User not found.');
        }

        if (!password_verify($currentPassword, $user['password_hash'])) {
            redirectBack(false, 'Current password is incorrect.');
        }

        // Update with new password
        $newHash = password_hash($newPassword, PASSWORD_BCRYPT);
        $updateStmt = $pdo->prepare("
            UPDATE tblusers
            SET username = ?, password_hash = ?, must_change_password = 0, updated_at = NOW()
            WHERE id = ? AND role_id = 1
        ");
        $updateStmt->execute([$username, $newHash, $userId]);

        redirectBack(true, 'Profile and password updated successfully.');
    } else {
        // Update without password change
        $updateStmt = $pdo->prepare("
            UPDATE tblusers
            SET username = ?, updated_at = NOW()
            WHERE id = ? AND role_id = 1
        ");
        $updateStmt->execute([$username, $userId]);

        redirectBack(true, 'Profile updated successfully.');
    }

} catch (PDOException $e) {
    error_log("[Profile Update] ERROR: " . $e->getMessage());
    redirectBack(false, 'Database error: ' . $e->getMessage());
}