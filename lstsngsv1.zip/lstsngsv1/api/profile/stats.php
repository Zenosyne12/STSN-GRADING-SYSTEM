<?php
/**
 * api/profile/stats.php
 * Returns system statistics for admin profile overview.
 */
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

try {
    $stats = [
        'success' => true,
        'teachers' => 0,
        'students' => 0,
        'subjects' => 0,
        'sections' => 0,
        'active_year' => '—',
        'active_quarter' => '—'
    ];

    // Count teachers
    try {
        $stmt = $pdo->query("SELECT COUNT(*) FROM tblteacher WHERE is_active = 1");
        $stats['teachers'] = (int) $stmt->fetchColumn();
    } catch (PDOException $e) {
        $stats['teachers'] = '—';
    }

    // Count students
    try {
        $stmt = $pdo->query("SELECT COUNT(*) FROM tblstudents WHERE is_active = 1");
        $stats['students'] = (int) $stmt->fetchColumn();
    } catch (PDOException $e) {
        $stats['students'] = '—';
    }

    // Count subjects
    try {
        $stmt = $pdo->query("SELECT COUNT(*) FROM tblsubjects WHERE is_active = 1");
        $stats['subjects'] = (int) $stmt->fetchColumn();
    } catch (PDOException $e) {
        $stats['subjects'] = '—';
    }

    // Count sections
    try {
        $stmt = $pdo->query("SELECT COUNT(*) FROM tblsection WHERE is_active = 1");
        $stats['sections'] = (int) $stmt->fetchColumn();
    } catch (PDOException $e) {
        $stats['sections'] = '—';
    }

    // Active school year
    try {
        $stmt = $pdo->query("SELECT year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
        $year = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($year) {
            $stats['active_year'] = $year['year_label'];
        }
    } catch (PDOException $e) {
        $stats['active_year'] = '—';
    }

    // Active quarter
    try {
        $stmt = $pdo->query("SELECT quarter_label FROM tblquarters WHERE is_active = 1 LIMIT 1");
        $quarter = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($quarter) {
            $stats['active_quarter'] = $quarter['quarter_label'];
        }
    } catch (PDOException $e) {
        $stats['active_quarter'] = '—';
    }

    echo json_encode($stats);

} catch (Throwable $e) {
    error_log("Stats API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to load statistics.']);
}