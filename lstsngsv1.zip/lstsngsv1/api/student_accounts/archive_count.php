<?php
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM tblusers WHERE role_id = 3 AND status = 'Inactive'");
    echo json_encode([
        'success' => true,
        'count' => (int) $stmt->fetchColumn()
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
