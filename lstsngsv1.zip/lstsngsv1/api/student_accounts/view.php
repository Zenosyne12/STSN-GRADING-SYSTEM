<?php
header("Content-Type: application/json");
require_once '../../api/shared/db_connect.php';

$id = intval($_GET['id'] ?? 0);
if (!$id) { echo json_encode(['success' => false, 'error' => 'Missing id']); exit; }

$stmt = $pdo->prepare("
    SELECT u.id, u.username, u.status, u.must_change_password, u.created_at,
           s.lrn, s.fname, s.lname, gl.grade_level_name as grade_level,
           CONCAT(s.fname, ' ', s.lname) as full_name
    FROM tblusers u
    JOIN tblstudents s ON s.id = u.reference_id
    JOIN tblgradelevel gl ON gl.id = s.grade_level_id
    WHERE u.id = ? AND u.role_id = 3
");
$stmt->execute([$id]);
$data = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$data) { echo json_encode(['success' => false, 'error' => 'Not found']); exit; }

echo json_encode(['success' => true, 'data' => $data]);