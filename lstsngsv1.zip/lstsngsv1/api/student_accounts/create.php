<?php
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/account_credentials.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$studentId = (int)($data['student_id'] ?? 0);

if ($studentId <= 0) {
    echo json_encode(['success' => false, 'error' => 'Missing student record.']);
    exit;
}

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare('
        SELECT id, fname, mname, lname, lrn, email, birthdate, is_active
        FROM tblstudents
        WHERE id = ?
        LIMIT 1
    ');
    $stmt->execute([$studentId]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        throw new Exception('Student not found.');
    }
    if ((int)($student['is_active'] ?? 0) !== 1) {
        throw new Exception('Cannot create an account for an inactive student.');
    }

    $credentials = stsnCreateStudentAccount($pdo, $studentId, $student);
    $pdo->commit();

    $emailSent = false;
    try {
        $emailSent = stsnSendCredentialsEmail(
            $credentials['email'],
            $credentials['full_name'],
            $credentials['username'],
            $credentials['temporary_password']
        );
    } catch (Throwable $mailError) {
        $emailSent = false;
    }

    echo json_encode([
        'success' => true,
        'username' => $credentials['username'],
        'email_sent' => $emailSent,
        'message' => $emailSent
            ? 'Student record and mobile account created successfully. Credentials sent to email.'
            : 'Account created successfully, but email sending failed. Please resend credentials.',
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
