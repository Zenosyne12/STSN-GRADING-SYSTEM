<?php
header("Content-Type: application/json");
require_once '../../api/shared/db_connect.php';
require_once __DIR__ . '/../../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// ── PHPMailer helper ──────────────────────────────────────────────────────────
function createMailer() {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'hechanova919@gmail.com';
    $mail->Password   = 'rbjslxdcytllregd';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;
    $mail->Timeout    = 12;
    $mail->SMTPKeepAlive = false;
    $mail->CharSet    = 'UTF-8';
    $mail->SMTPAutoTLS = true;
    $mail->SMTPOptions = [
        'ssl' => [
            'verify_peer'       => false,
            'verify_peer_name'  => false,
            'allow_self_signed' => true,
        ],
    ];
    $mail->setFrom($mail->Username, 'STSN Grading System');
    $mail->addReplyTo($mail->Username, 'STSN Grading System');
    $mail->isHTML(true);
    return $mail;
}

// ── Input ─────────────────────────────────────────────────────────────────────
$data       = json_decode(file_get_contents("php://input"), true);
$student_id = intval($data['student_id'] ?? 0);
$username   = trim($data['username'] ?? '');

if (!$student_id || !$username) {
    echo json_encode(['success' => false, 'error' => 'Missing data']);
    exit;
}

// ── Check duplicate ───────────────────────────────────────────────────────────
$check = $pdo->prepare("
    SELECT id FROM tblusers
    WHERE username = ? OR (reference_id = ? AND role_id = 3)
");
$check->execute([$username, $student_id]);
if ($check->fetch()) {
    echo json_encode(['success' => false, 'error' => 'Account already exists for this student.']);
    exit;
}

// ── Get student info ──────────────────────────────────────────────────────────
$stu = $pdo->prepare("SELECT fname, lname, lrn, email, birthdate FROM tblstudents WHERE id = ?");
$stu->execute([$student_id]);
$student = $stu->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    echo json_encode(['success' => false, 'error' => 'Student not found.']);
    exit;
}

// ── Generate temporary password ───────────────────────────────────────────────
$tempPassword = 'STSN@' . rand(1000, 9999);
$hash         = password_hash($tempPassword, PASSWORD_BCRYPT);

// ── Insert account ────────────────────────────────────────────────────────────
$insert = $pdo->prepare("
    INSERT INTO tblusers (username, password_hash, role_id, reference_id, status, must_change_password)
    VALUES (?, ?, 3, ?, 'Active', 1)
");
$insert->execute([$username, $hash, $student_id]);

// ── Send email if student has an email ───────────────────────────────────────
$emailSent    = false;
$emailError   = null;
$studentEmail = trim($student['email'] ?? '');
$fullName     = trim($student['fname'] . ' ' . $student['lname']);

if ($studentEmail !== '') {
    try {
        $mail = createMailer();
        $mail->addAddress($studentEmail, $fullName);
        $mail->Subject = 'Your STSN Grading System Account';
        $mail->Body    = '
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: Arial, sans-serif; background: #f3f7fd; margin: 0; padding: 0; }
    .wrap { max-width: 520px; margin: 30px auto; background: #fff; border-radius: 14px;
            border: 1px solid #dce8f8; overflow: hidden; }
    .head { background: linear-gradient(130deg, #1248a8, #1a6ef5); padding: 28px 32px; color: #fff; }
    .head h2 { margin: 0 0 4px; font-size: 1.2rem; }
    .head p  { margin: 0; font-size: 0.85rem; opacity: .85; }
    .body { padding: 28px 32px; color: #213a5e; font-size: 0.95rem; line-height: 1.6; }
    .creds { background: #f4f8ff; border: 1.5px solid #c8daf8; border-radius: 10px;
             padding: 16px 20px; margin: 18px 0; }
    .creds p { margin: 4px 0; font-size: 0.92rem; }
    .creds strong { color: #1248a8; }
    .pw { font-size: 1.3rem; font-weight: 700; color: #1248a8; letter-spacing: 2px; }
    .note { font-size: 0.8rem; color: #7a93b8; margin-top: 18px; }
    .foot { background: #f4f8ff; padding: 14px 32px; text-align: center;
            font-size: 0.78rem; color: #9ab0c8; border-top: 1px solid #e8f0fb; }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="head">
      <h2>STSN Grading System</h2>
      <p>St. Theresa\'s School of Novaliches</p>
    </div>
    <div class="body">
      <p>Hello, <strong>' . htmlspecialchars($fullName) . '</strong>!</p>
      <p>Your mobile app account has been created. Use the credentials below to log in:</p>
      <div class="creds">
        <p><strong>Username:</strong> ' . htmlspecialchars($username) . '</p>
        <p><strong>Temporary Password:</strong></p>
        <p class="pw">' . htmlspecialchars($tempPassword) . '</p>
      </div>
      <p>Please <strong>change your password</strong> after your first login.</p>
      <p class="note">If you did not expect this email, please contact your school administrator immediately.</p>
    </div>
    <div class="foot">STSN Grading System &mdash; St. Theresa\'s School of Novaliches</div>
  </div>
</body>
</html>';

        $mail->AltBody = "Hello $fullName,\n\nYour STSN mobile account has been created.\n\nUsername: $username\nTemporary Password: $tempPassword\n\nPlease change your password after your first login.\n\nSTSN Grading System";

        $mail->send();
        $emailSent = true;

    } catch (Exception $e) {
        $emailError = $mail->ErrorInfo;
    }
}

// ── Response ──────────────────────────────────────────────────────────────────
echo json_encode([
    'success'       => true,
    'username'      => $username,
    'temp_password' => $tempPassword,
    'email_sent'    => $emailSent,
    'email_error'   => $emailError,
    'message'       => $emailSent
        ? "Account created and password sent to $studentEmail."
        : ($studentEmail === ''
            ? "Account created. No email on record — please give the password manually: $tempPassword"
            : "Account created but email failed to send. Password: $tempPassword")
]);