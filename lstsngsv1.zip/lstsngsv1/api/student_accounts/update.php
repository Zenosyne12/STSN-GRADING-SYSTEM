<?php
header("Content-Type: application/json");
require_once '../../api/shared/db_connect.php';

$data = json_decode(file_get_contents("php://input"), true);
$id = intval($data['id'] ?? 0);
$status = $data['status'] ?? '';

if (!$id || !in_array($status, ['Active', 'Inactive'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid data']);
    exit;
}

$stmt = $pdo->prepare("UPDATE tblusers SET status = ? WHERE id = ? AND role_id = 3");
$stmt->execute([$status, $id]);

echo json_encode(['success' => true, 'message' => "Account status updated to $status"]);