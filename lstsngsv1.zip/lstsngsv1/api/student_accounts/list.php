<?php
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$rowsPerPage = 10;
$offset = ($page - 1) * $rowsPerPage;

try {
    $countQuery = "
        SELECT COUNT(*)
        FROM tblusers u
        JOIN tblstudents s ON s.id = u.reference_id
        LEFT JOIN tblgradelevel gl ON gl.id = s.grade_level_id
        WHERE u.role_id = 3 AND u.status = 'Active'
    ";
    $dataQuery = "
        SELECT 
            u.id,
            u.reference_id AS student_id,
            s.lrn,
            CONCAT(COALESCE(s.fname,''), ' ', COALESCE(s.mname,''), ' ', COALESCE(s.lname,'')) AS full_name,
            gl.grade_level_name AS grade_level,
            u.username,
            u.must_change_password,
            u.status,
            u.created_at
        FROM tblusers u
        JOIN tblstudents s ON s.id = u.reference_id
        LEFT JOIN tblgradelevel gl ON gl.id = s.grade_level_id
        WHERE u.role_id = 3 AND u.status = 'Active'
    ";

    if ($search) {
        $searchTerm = '%' . $search . '%';
        $countQuery .= " AND (s.lrn LIKE ? OR s.fname LIKE ? OR s.lname LIKE ? OR u.username LIKE ?)";
        $dataQuery .= " AND (s.lrn LIKE ? OR s.fname LIKE ? OR s.lname LIKE ? OR u.username LIKE ?)";
        
        $stmtCount = $pdo->prepare($countQuery);
        $stmtCount->execute([$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
        $stmtData = $pdo->prepare($dataQuery . " ORDER BY u.id DESC LIMIT ? OFFSET ?");
        $stmtData->bindValue(1, $searchTerm, PDO::PARAM_STR);
        $stmtData->bindValue(2, $searchTerm, PDO::PARAM_STR);
        $stmtData->bindValue(3, $searchTerm, PDO::PARAM_STR);
        $stmtData->bindValue(4, $searchTerm, PDO::PARAM_STR);
        $stmtData->bindValue(5, $rowsPerPage, PDO::PARAM_INT);
        $stmtData->bindValue(6, $offset, PDO::PARAM_INT);
    } else {
        $stmtCount = $pdo->query($countQuery);
        $stmtData = $pdo->prepare($dataQuery . " ORDER BY u.id DESC LIMIT ? OFFSET ?");
        $stmtData->bindValue(1, $rowsPerPage, PDO::PARAM_INT);
        $stmtData->bindValue(2, $offset, PDO::PARAM_INT);
    }
    $stmtData->execute();

    $totalCount = intval($stmtCount->fetchColumn());
    $data = $stmtData->fetchAll(PDO::FETCH_ASSOC);
    $totalPages = ceil($totalCount / $rowsPerPage);

    echo json_encode([
        'success' => true,
        'data' => $data,
        'page' => $page,
        'pages' => max(1, $totalPages),
        'total' => $totalCount
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
