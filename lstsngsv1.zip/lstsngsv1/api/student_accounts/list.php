<?php
header("Content-Type: application/json");
require_once '../../api/shared/db_connect.php';

$page = max(1, intval($_GET['page'] ?? 1));
$search = trim($_GET['search'] ?? '');
$limit = 10;
$offset = ($page - 1) * $limit;

$where = "u.role_id = 3";
$params = [];

if ($search) {
    $where .= " AND (s.lrn LIKE ? OR s.fname LIKE ? OR s.lname LIKE ?)";
    $like = "%$search%";
    $params = array_merge($params, [$like, $like, $like]);
}

$total = $pdo->prepare("SELECT COUNT(*) FROM tblusers u JOIN tblstudents s ON s.id = u.reference_id WHERE $where");
$total->execute($params);
$totalCount = $total->fetchColumn();

$stmt = $pdo->prepare("
    SELECT u.id, u.username, u.status, u.must_change_password, u.created_at,
           s.lrn, s.fname, s.lname, gl.grade_level_name as grade_level,
           CONCAT(s.fname, ' ', s.lname) as full_name
    FROM tblusers u
    JOIN tblstudents s ON s.id = u.reference_id
    JOIN tblgradelevel gl ON gl.id = s.grade_level_id
    WHERE $where
    ORDER BY u.created_at DESC
    LIMIT $limit OFFSET $offset
");
$stmt->execute($params);
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    'success' => true,
    'data' => $data,
    'total' => $totalCount,
    'pages' => ceil($totalCount / $limit)
]);