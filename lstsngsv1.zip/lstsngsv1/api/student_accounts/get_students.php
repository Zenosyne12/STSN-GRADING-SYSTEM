<?php
header("Content-Type: application/json");
require_once '../../api/shared/db_connect.php';

// Only students WITHOUT existing mobile accounts
$stmt = $pdo->query("
    SELECT s.id, s.lrn, s.fname, s.lname, s.birthdate,
           gl.grade_level_name as grade_level,
           CONCAT(s.fname, ' ', s.lname) as full_name
    FROM tblstudents s
    JOIN tblgradelevel gl ON gl.id = s.grade_level_id
    WHERE s.is_active = 1
    AND s.id NOT IN (SELECT reference_id FROM tblusers WHERE role_id = 3 AND reference_id IS NOT NULL)
    ORDER BY s.lname, s.fname
");
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(['success' => true, 'students' => $students]);