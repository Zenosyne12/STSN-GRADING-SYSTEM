<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

function respond($success, $message = '')
{
    echo json_encode([
        'success' => $success,
        'message' => $message
    ]);
    exit;
}

try {
    $deadlineId = isset($_POST['deadline_id']) ? (int) $_POST['deadline_id'] : 0;
    $recipientType = isset($_POST['recipient_type']) ? trim($_POST['recipient_type']) : 'all';

    if ($deadlineId <= 0) {
        throw new Exception('Invalid deadline id.');
    }

    $stmt = $pdo->prepare("
        SELECT id, title, school_year, quarter, due_at, deadline_type, applicable_to
        FROM tbldeadlines
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->execute([$deadlineId]);
    $deadline = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$deadline) {
        throw new Exception('Deadline not found.');
    }

    $message = 'Reminder: ' . $deadline['title'] . ' is due on ' . date('M d, Y h:i A', strtotime($deadline['due_at'])) . '.';

    $sentCount = 0;

    if ($recipientType === 'teacher' || $recipientType === 'all') {
        $sectionIds = [];
        if (!empty($deadline['applicable_to'])) {
            $decoded = json_decode($deadline['applicable_to'], true);
            if (is_array($decoded)) {
                $sectionIds = array_map('intval', $decoded);
            }
        }

        $teacherSql = "
            SELECT DISTINCT t.id AS teacher_id
            FROM teacher_subject_sections tss
            INNER JOIN tblteacher t ON t.id = tss.teacher_id
            WHERE 1 = 1
        ";
        $params = [];

        if (!empty($sectionIds)) {
            $in = implode(',', array_fill(0, count($sectionIds), '?'));
            $teacherSql .= " AND tss.section_id IN ($in)";
            $params = $sectionIds;
        }

        $teacherStmt = $pdo->prepare($teacherSql);
        $teacherStmt->execute($params);
        $teachers = $teacherStmt->fetchAll(PDO::FETCH_COLUMN);

        $insert = $pdo->prepare("
            INSERT INTO system_notifications
            (user_id, user_type, title, message, created_at)
            VALUES
            (?, 'teacher', ?, ?, NOW())
        ");

        foreach ($teachers as $teacherId) {
            $insert->execute([(int) $teacherId, 'Deadline Reminder', $message]);
            $sentCount++;
        }
    }

    if ($recipientType === 'adviser' || $recipientType === 'all') {
        $adviserStmt = $pdo->query("
            SELECT DISTINCT adviser_id
            FROM tblsection
            WHERE adviser_id IS NOT NULL AND adviser_id > 0
        ");
        $advisers = $adviserStmt->fetchAll(PDO::FETCH_COLUMN);

        $insert = $pdo->prepare("
            INSERT INTO system_notifications
            (user_id, user_type, title, message, created_at)
            VALUES
            (?, 'adviser', ?, ?, NOW())
        ");

        foreach ($advisers as $adviserId) {
            $insert->execute([(int) $adviserId, 'Deadline Reminder', $message]);
            $sentCount++;
        }
    }

    respond(true, 'Reminder(s) queued: ' . $sentCount);
} catch (Throwable $e) {
    respond(false, $e->getMessage());
}