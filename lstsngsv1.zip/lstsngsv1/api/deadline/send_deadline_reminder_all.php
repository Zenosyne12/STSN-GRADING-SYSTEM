<?php
header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user_id']) && empty($_SESSION['teacher_id']) && empty($_SESSION['admin_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Not authenticated.'
    ]);
    exit;
}

$required = false;
$searchPaths = [
    __DIR__ . '/../shared/db_connect.php',
    __DIR__ . '/../../shared/db_connect.php',
    __DIR__ . '/../db_connect.php',
    __DIR__ . '/db_connect.php',
    dirname(__DIR__) . '/shared/db_connect.php',
    dirname(dirname(__DIR__)) . '/shared/db_connect.php',
];

foreach ($searchPaths as $path) {
    if (file_exists($path)) {
        try {
            require_once $path;
            $required = true;
            break;
        } catch (Throwable $e) {
            continue;
        }
    }
}

if (!$required || !isset($pdo) || !($pdo instanceof PDO)) {
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed.'
    ]);
    exit;
}

function respond($success, $message = '')
{
    echo json_encode(['success' => $success, 'message' => $message]);
    exit;
}

try {
    $deadlineId    = isset($_POST['deadline_id'])    ? (int)$_POST['deadline_id']      : 0;
    $recipientType = isset($_POST['recipient_type']) ? trim($_POST['recipient_type'])   : 'all';

    if ($deadlineId <= 0) throw new Exception('Invalid deadline id.');

    $stmt = $pdo->prepare("
        SELECT id, quarter, school_year, teacher_deadline, adviser_deadline
        FROM tbldeadlines
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->execute([$deadlineId]);
    $deadline = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$deadline) throw new Exception('Deadline not found.');

    $sentCount = 0;

    
    if (in_array($recipientType, ['teacher', 'all'], true) && !empty($deadline['teacher_deadline'])) {
        $title   = 'Q' . (int)$deadline['quarter'] . ' Teacher Submission';
        $dueAt   = $deadline['teacher_deadline'];
        $message = 'Reminder: ' . $title . ' is due on ' . date('M d, Y h:i A', strtotime($dueAt)) . '.';

        $teacherStmt = $pdo->query("
            SELECT DISTINCT teacher_id FROM tblsection_teacher_subject WHERE is_active = 1
        ");
        $teachers = $teacherStmt->fetchAll(PDO::FETCH_COLUMN);

        $insert = $pdo->prepare("
            INSERT INTO system_notifications (title, message, type, created_at)
            VALUES (?, ?, ?, NOW())
        ");
        foreach ($teachers as $tid) {
            $insert->execute([$title, $message, 'teacher:' . (int)$tid]);
            $sentCount++;
        }
    }

    
    if (in_array($recipientType, ['adviser', 'all'], true) && !empty($deadline['adviser_deadline'])) {
        $title   = 'Q' . (int)$deadline['quarter'] . ' Adviser Submission';
        $dueAt   = $deadline['adviser_deadline'];
        $message = 'Reminder: ' . $title . ' is due on ' . date('M d, Y h:i A', strtotime($dueAt)) . '.';

        $adviserStmt = $pdo->query("
            SELECT DISTINCT sa.teacher_id
            FROM tblsectionadviser sa
            INNER JOIN tblacademicyear ay ON ay.id = sa.academic_year_id
            WHERE ay.is_active = 1
        ");
        $advisers = $adviserStmt->fetchAll(PDO::FETCH_COLUMN);

        $insert = $pdo->prepare("
            INSERT INTO system_notifications (title, message, type, created_at)
            VALUES (?, ?, ?, NOW())
        ");
        foreach ($advisers as $aid) {
            $insert->execute([$title, $message, 'adviser:' . (int)$aid]);
            $sentCount++;
        }
    }

    respond(true, 'Reminder(s) queued: ' . $sentCount);
} catch (Throwable $e) {
    error_log('[send_deadline_reminder_all ERROR] ' . $e->getMessage());
    respond(false, $e->getMessage());
}