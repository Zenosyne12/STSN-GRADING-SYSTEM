<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

function respond($success, $message = '', $rows = [])
{
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'rows' => $rows
    ]);
    exit;
}

function buildDeadlineRow($baseId, $schoolYear, $quarter, $type, $dueAt)
{
    $label = $type === 'teacher' ? 'Teacher' : 'Adviser';

    return [
        'id' => $baseId . '_' . $type,
        'deadline_id' => (int)$baseId,
        'title' => 'Q' . (int)$quarter . ' ' . $label . ' Submission',
        'deadline_type' => $label,
        'school_year' => $schoolYear,
        'quarter' => (int)$quarter,
        'due_at' => $dueAt,
        'due_at_display' => !empty($dueAt) ? date('M d, Y h:i A', strtotime($dueAt)) : '-',
        'applicable_to_display' => $type === 'teacher' ? 'Teachers / Sections' : 'Advisers',
        'compliance_display' => '0/0 submitted',
        'status' => (!empty($dueAt) && strtotime($dueAt) < time()) ? 'Closed' : 'Open'
    ];
}

try {
    $schoolYear = isset($_GET['school_year']) ? trim($_GET['school_year']) : '';
    $quarter = isset($_GET['quarter']) ? (int)$_GET['quarter'] : 0;

    $sql = "
        SELECT id, school_year, quarter, teacher_deadline, adviser_deadline
        FROM tbldeadlines
        WHERE 1 = 1
    ";

    $params = [];

    if ($schoolYear !== '') {
        $sql .= " AND school_year = :school_year";
        $params[':school_year'] = $schoolYear;
    }

    if ($quarter > 0) {
        $sql .= " AND quarter = :quarter";
        $params[':quarter'] = $quarter;
    }

    $sql .= " ORDER BY quarter ASC, id DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $rows = [];

    foreach ($items as $item) {
        if (!empty($item['teacher_deadline'])) {
            $rows[] = buildDeadlineRow(
                $item['id'],
                $item['school_year'],
                $item['quarter'],
                'teacher',
                $item['teacher_deadline']
            );
        }

        if (!empty($item['adviser_deadline'])) {
            $rows[] = buildDeadlineRow(
                $item['id'],
                $item['school_year'],
                $item['quarter'],
                'adviser',
                $item['adviser_deadline']
            );
        }
    }

    respond(true, 'Deadline list loaded.', $rows);
} catch (Throwable $e) {
    respond(false, $e->getMessage());
}