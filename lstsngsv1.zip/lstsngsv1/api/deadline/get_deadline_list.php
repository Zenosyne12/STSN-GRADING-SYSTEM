<?php



header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user_id']) && empty($_SESSION['teacher_id']) && empty($_SESSION['admin_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Not authenticated. Please log in.',
        'rows' => []
    ]);
    exit;
}

$required = false;
$searchPaths = [
    __DIR__ . '/../shared/db_connect.php',
    __DIR__ . '/../../shared/db_connect.php',
    __DIR__ . '/../db_connect.php',
    __DIR__ . '/db_connect.php',
    dirname(__DIR__) . '/shared/db_connect.php',
    dirname(dirname(__DIR__)) . '/shared/db_connect.php',
];

foreach ($searchPaths as $path) {
    if (file_exists($path)) {
        try {
            require_once $path;
            $required = true;
            break;
        } catch (Throwable $e) {
            continue;
        }
    }
}

if (!$required || !isset($pdo) || !($pdo instanceof PDO)) {
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed.',
        'rows' => []
    ]);
    exit;
}

function respond($success, $message = '', $rows = [])
{
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'rows'    => $rows
    ]);
    exit;
}


$lockScript = __DIR__ . '/process_deadline_locks.php';
if (file_exists($lockScript)) {
    require_once $lockScript;
}

function getTeacherCompliance(PDO $pdo, $schoolYear, $quarter)
{
    $assignedStmt = $pdo->prepare("
        SELECT COUNT(*) FROM (
            SELECT DISTINCT sts.teacher_id, sts.section_id, sts.subject_id
            FROM tblsection_teacher_subject sts
            WHERE sts.is_active = 1
            UNION
            SELECT DISTINCT sc.teacher_id, sc.section_id, sc.subject_id
            FROM tblschedule sc
            WHERE sc.is_active = 1 AND sc.school_year = ?
        ) x
    ");
    $assignedStmt->execute([$schoolYear]);
    $total = (int)$assignedStmt->fetchColumn();

    $submittedStmt = $pdo->prepare("
        SELECT COUNT(*) FROM (
            SELECT DISTINCT teacher_id, section_id, subject_id
            FROM tblteacher_submissions
            WHERE school_year = ? AND quarter = ?
        ) x
    ");
    $submittedStmt->execute([$schoolYear, $quarter]);
    $submitted = (int)$submittedStmt->fetchColumn();

    return [$submitted, $total];
}

function getAdviserCompliance(PDO $pdo, $schoolYear, $quarter)
{
    $assignedStmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM tblsectionadviser sa
        INNER JOIN tblacademicyear ay ON ay.id = sa.academic_year_id
        WHERE ay.year_label = ?
    ");
    $assignedStmt->execute([$schoolYear]);
    $total = (int)$assignedStmt->fetchColumn();

    $submittedStmt = $pdo->prepare("
        SELECT COUNT(*) FROM (
            SELECT DISTINCT teacher_id, section_id
            FROM tbladviser_submissions
            WHERE school_year = ? AND quarter = ?
        ) x
    ");
    $submittedStmt->execute([$schoolYear, $quarter]);
    $submitted = (int)$submittedStmt->fetchColumn();

    return [$submitted, $total];
}

function getAttendanceCompliance(PDO $pdo, $schoolYear, $quarter)
{
    
    $submittedStmt = $pdo->prepare("
        SELECT COUNT(DISTINCT section_id) 
        FROM tblattendance 
        WHERE school_year = ? AND quarter = ?
    ");
    $submittedStmt->execute([$schoolYear, $quarter]);
    $submitted = (int)$submittedStmt->fetchColumn();

    $totalStmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM tblsectionadviser sa
        INNER JOIN tblacademicyear ay ON ay.id = sa.academic_year_id
        WHERE ay.year_label = ?
    ");
    $totalStmt->execute([$schoolYear]);
    $total = (int)$totalStmt->fetchColumn();

    return [$submitted, $total];
}

function buildDeadlineRow($baseId, $schoolYear, $quarter, $type, $dueAt, $submittedCount, $totalCount, $lockCount = 0)
{
    $labelMap = [
        'teacher'    => 'Teacher',
        'adviser'    => 'Adviser',
        'attendance' => 'Attendance'
    ];
    $label    = $labelMap[$type] ?? ucfirst($type);
    $isOverdue = !empty($dueAt) && strtotime($dueAt) < time();

    return [
        'id'                   => $baseId . '_' . $type,
        'deadline_id'          => (int)$baseId,
        'title'                => 'Q' . (int)$quarter . ' ' . $label . ' Submission',
        'deadline_type'        => $label,
        'school_year'          => $schoolYear,
        'quarter'              => (int)$quarter,
        'due_at'               => $dueAt,
        'due_at_display'       => !empty($dueAt) ? date('M d, Y h:i A', strtotime($dueAt)) : '—',
        'applicable_to_display'=> $type === 'attendance' ? 'Advisers' : ($type === 'teacher' ? 'Teachers' : 'Advisers'),
        'compliance_display'   => $submittedCount . '/' . $totalCount . ' submitted',
        'status'               => $isOverdue ? 'Closed' : 'Open',
        'is_overdue'           => $isOverdue,
        'locked_count'         => $lockCount,
    ];
}

try {
    $schoolYear = isset($_GET['school_year']) ? trim($_GET['school_year']) : '';
    $quarter    = isset($_GET['quarter'])     ? (int)$_GET['quarter']     : 0;

    $sql    = "SELECT id, school_year, quarter, teacher_deadline, adviser_deadline, attendance_deadline FROM tbldeadlines WHERE 1=1";
    $params = [];

    if ($schoolYear !== '') {
        $sql .= " AND school_year = :school_year";
        $params[':school_year'] = $schoolYear;
    }
    if ($quarter > 0) {
        $sql .= " AND quarter = :quarter";
        $params[':quarter'] = $quarter;
    }

    $sql .= " ORDER BY quarter ASC, id DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $rows = [];
    foreach ($items as $item) {
        if (!empty($item['teacher_deadline'])) {
            [$submitted, $total] = getTeacherCompliance($pdo, $item['school_year'], (int)$item['quarter']);
            $rows[] = buildDeadlineRow(
                $item['id'], $item['school_year'], $item['quarter'],
                'teacher', $item['teacher_deadline'], $submitted, $total
            );
        }
        if (!empty($item['adviser_deadline'])) {
            [$submitted, $total] = getAdviserCompliance($pdo, $item['school_year'], (int)$item['quarter']);
            $rows[] = buildDeadlineRow(
                $item['id'], $item['school_year'], $item['quarter'],
                'adviser', $item['adviser_deadline'], $submitted, $total
            );
        }
        if (!empty($item['attendance_deadline'])) {
            [$submitted, $total] = getAttendanceCompliance($pdo, $item['school_year'], (int)$item['quarter']);
            $rows[] = buildDeadlineRow(
                $item['id'], $item['school_year'], $item['quarter'],
                'attendance', $item['attendance_deadline'], $submitted, $total
            );
        }
    }

    respond(true, 'Deadline list loaded.', $rows);
} catch (Throwable $e) {
    error_log('[get_deadline_list ERROR] ' . $e->getMessage());
    respond(false, $e->getMessage());
}