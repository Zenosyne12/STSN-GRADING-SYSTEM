<?php



$calledDirectly = (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? ''));
date_default_timezone_set('Asia/Manila');

function dlLog($msg) {
    error_log("[DEADLINE_LOCK] " . $msg);
}


$required = false;
$searchPaths = [
    __DIR__ . '/../shared/db_connect.php',
    __DIR__ . '/../../shared/db_connect.php',
    __DIR__ . '/../db_connect.php',
    __DIR__ . '/db_connect.php',
    dirname(__DIR__) . '/shared/db_connect.php',
    dirname(dirname(__DIR__)) . '/shared/db_connect.php',
];

foreach ($searchPaths as $path) {
    if (file_exists($path)) {
        try {
            require_once $path;
            $required = true;
            dlLog("Loaded db_connect.php from: " . $path);
            break;
        } catch (Throwable $e) {
            dlLog("Failed to load from " . $path . ": " . $e->getMessage());
            continue;
        }
    }
}

if (!$required) {
    $err = 'db_connect.php NOT FOUND. Searched: ' . implode(', ', $searchPaths);
    dlLog("FATAL: " . $err);
    if ($calledDirectly) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => $err,
            'locked' => 0
        ]);
        exit;
    }
    return;
}

if (!isset($pdo) || !($pdo instanceof PDO)) {
    $err = 'Database connection ($pdo) not available.';
    dlLog("FATAL: " . $err);
    if ($calledDirectly) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => $err,
            'locked' => 0
        ]);
        exit;
    }
    return;
}

function lockRespond($success, $message = '', $data = []) {
    header('Content-Type: application/json');
    echo json_encode(['success' => $success, 'message' => $message, 'data' => $data]);
    exit;
}

$totalLocked = 0;
$processedDeadlines = 0;

try {
    $now = date('Y-m-d H:i:s');
    dlLog("Starting lock pass at " . $now);

    $sql = "SELECT id, quarter, school_year, teacher_deadline, adviser_deadline, attendance_deadline 
            FROM tbldeadlines 
            WHERE (teacher_deadline IS NOT NULL AND teacher_deadline <= :now)
               OR (adviser_deadline IS NOT NULL AND adviser_deadline <= :now)
               OR (attendance_deadline IS NOT NULL AND attendance_deadline <= :now)";
    
    $deadlineStmt = $pdo->prepare($sql);
    $deadlineStmt->execute([':now' => $now]);
    
    if (!$deadlineStmt) {
        $errInfo = $pdo->errorInfo();
        throw new Exception('Failed to query deadlines: ' . implode(' | ', $errInfo));
    }
    
    $deadlines = $deadlineStmt->fetchAll(PDO::FETCH_ASSOC);
    $processedDeadlines = count($deadlines);
    dlLog("Found {$processedDeadlines} expired deadlines");

    foreach ($deadlines as $deadline) {
        $deadlineId  = (int)$deadline['id'];
        $quarter     = (int)$deadline['quarter'];
        $schoolYear  = $deadline['school_year'];
        
        dlLog("Processing deadline #{$deadlineId} Q{$quarter} {$schoolYear}");

        
        if (!empty($deadline['teacher_deadline']) && strtotime($deadline['teacher_deadline']) <= time()) {
            dlLog("Teacher deadline expired: " . $deadline['teacher_deadline']);
            
            $assignSql = "
                SELECT DISTINCT sts.teacher_id, sts.section_id, sts.subject_id
                FROM tblsection_teacher_subject sts
                WHERE sts.is_active = 1
                UNION
                SELECT DISTINCT sc.teacher_id, sc.section_id, sc.subject_id
                FROM tblschedule sc
                WHERE sc.is_active = 1 AND sc.school_year = ?
            ";
            $assignStmt = $pdo->prepare($assignSql);
            $assignStmt->execute([$schoolYear]);
            $assignments = $assignStmt->fetchAll(PDO::FETCH_ASSOC);
            dlLog("Found " . count($assignments) . " teacher assignments");

            $subStmt = $pdo->prepare("
                SELECT DISTINCT teacher_id, section_id, subject_id
                FROM tblteacher_submissions
                WHERE school_year = ? AND quarter = ?
            ");
            $subStmt->execute([$schoolYear, $quarter]);
            $submitted = $subStmt->fetchAll(PDO::FETCH_ASSOC);
            
            $submittedKeys = [];
            foreach ($submitted as $s) {
                $submittedKeys[$s['teacher_id'] . '-' . $s['section_id'] . '-' . $s['subject_id']] = true;
            }
            dlLog("Found " . count($submitted) . " already submitted");

            $insertLock = $pdo->prepare("
                INSERT INTO tbldeadline_locks
                    (teacher_id, section_id, subject_id, quarter, school_year, deadline_id, is_locked, locked_since)
                SELECT
                    :teacher_id, :section_id, :subject_id, :quarter, :school_year, :deadline_id, 1, :locked_since
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM tbldeadline_locks
                    WHERE teacher_id = :teacher_id_check
                      AND section_id = :section_id_check
                      AND subject_id = :subject_id_check
                      AND quarter = :quarter_check
                      AND school_year = :school_year_check
                )
            ");

            $newLocks = 0;
            foreach ($assignments as $a) {
                $key = $a['teacher_id'] . '-' . $a['section_id'] . '-' . $a['subject_id'];
                if (!isset($submittedKeys[$key])) {
                    $insertLock->execute([
                        ':teacher_id'  => (int)$a['teacher_id'],
                        ':section_id'  => (int)$a['section_id'],
                        ':subject_id'  => (int)$a['subject_id'],
                        ':quarter'     => $quarter,
                        ':school_year' => $schoolYear,
                        ':deadline_id' => $deadlineId,
                        ':locked_since'=> $now,
                        ':teacher_id_check'  => (int)$a['teacher_id'],
                        ':section_id_check'  => (int)$a['section_id'],
                        ':subject_id_check'  => (int)$a['subject_id'],
                        ':quarter_check'     => $quarter,
                        ':school_year_check' => $schoolYear,
                    ]);
                    if ($insertLock->rowCount() > 0) $newLocks++;
                }
            }
            $totalLocked += $newLocks;
            dlLog("Inserted {$newLocks} new teacher locks");
        }

        
        if (!empty($deadline['adviser_deadline']) && strtotime($deadline['adviser_deadline']) <= time()) {
            dlLog("Adviser deadline expired: " . $deadline['adviser_deadline']);

            $advStmt = $pdo->prepare("
                SELECT sa.teacher_id, sa.section_id
                FROM tblsectionadviser sa
                INNER JOIN tblacademicyear ay ON ay.id = sa.academic_year_id
                WHERE ay.year_label = ?
            ");
            $advStmt->execute([$schoolYear]);
            $advisers = $advStmt->fetchAll(PDO::FETCH_ASSOC);
            dlLog("Found " . count($advisers) . " advisers");

            $advSubStmt = $pdo->prepare("
                SELECT DISTINCT teacher_id, section_id
                FROM tbladviser_submissions
                WHERE school_year = ? AND quarter = ?
            ");
            $advSubStmt->execute([$schoolYear, $quarter]);
            $advSubmitted = $advSubStmt->fetchAll(PDO::FETCH_ASSOC);

            $advSubmittedKeys = [];
            foreach ($advSubmitted as $s) {
                $advSubmittedKeys[$s['teacher_id'] . '-' . $s['section_id']] = true;
            }
            dlLog("Found " . count($advSubmitted) . " already submitted advisers");

            $insertAdvLock = $pdo->prepare("
                INSERT INTO tbldeadline_locks
                    (teacher_id, section_id, subject_id, quarter, school_year, deadline_id, is_locked, locked_since)
                SELECT
                    :teacher_id, :section_id, 0, :quarter, :school_year, :deadline_id, 1, :locked_since
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM tbldeadline_locks
                    WHERE teacher_id = :teacher_id_check
                      AND section_id = :section_id_check
                      AND subject_id = 0
                      AND quarter = :quarter_check
                      AND school_year = :school_year_check
                )
            ");

            $newLocks = 0;
            foreach ($advisers as $a) {
                $key = $a['teacher_id'] . '-' . $a['section_id'];
                if (!isset($advSubmittedKeys[$key])) {
                    $insertAdvLock->execute([
                        ':teacher_id'  => (int)$a['teacher_id'],
                        ':section_id'  => (int)$a['section_id'],
                        ':quarter'     => $quarter,
                        ':school_year' => $schoolYear,
                        ':deadline_id' => $deadlineId,
                        ':locked_since'=> $now,
                        ':teacher_id_check'  => (int)$a['teacher_id'],
                        ':section_id_check'  => (int)$a['section_id'],
                        ':quarter_check'     => $quarter,
                        ':school_year_check' => $schoolYear,
                    ]);
                    if ($insertAdvLock->rowCount() > 0) $newLocks++;
                }
            }
            $totalLocked += $newLocks;
            dlLog("Inserted {$newLocks} new adviser locks");
        }

        
        if (!empty($deadline['attendance_deadline']) && strtotime($deadline['attendance_deadline']) <= time()) {
            dlLog("Attendance deadline expired: " . $deadline['attendance_deadline']);

            $advStmt = $pdo->prepare("
                SELECT sa.teacher_id, sa.section_id
                FROM tblsectionadviser sa
                INNER JOIN tblacademicyear ay ON ay.id = sa.academic_year_id
                WHERE ay.year_label = ?
            ");
            $advStmt->execute([$schoolYear]);
            $advisers = $advStmt->fetchAll(PDO::FETCH_ASSOC);
            dlLog("Found " . count($advisers) . " advisers for attendance lock");

            
            $attSubStmt = $pdo->prepare("
                SELECT DISTINCT section_id
                FROM tblattendance
                WHERE school_year = ? AND quarter = ?
            ");
            $attSubStmt->execute([$schoolYear, $quarter]);
            $attSubmittedSections = $attSubStmt->fetchAll(PDO::FETCH_COLUMN);
            $attSubmittedMap = array_flip($attSubmittedSections);
            dlLog("Found " . count($attSubmittedSections) . " sections with attendance");

            
            $insertAttLock = $pdo->prepare("
                INSERT INTO tbldeadline_locks
                    (teacher_id, section_id, subject_id, quarter, school_year, deadline_id, is_locked, locked_since)
                SELECT
                    :teacher_id, :section_id, -1, :quarter, :school_year, :deadline_id, 1, :locked_since
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM tbldeadline_locks
                    WHERE teacher_id = :teacher_id_check
                      AND section_id = :section_id_check
                      AND subject_id = -1
                      AND quarter = :quarter_check
                      AND school_year = :school_year_check
                )
            ");

            $newLocks = 0;
            foreach ($advisers as $a) {
                if (!isset($attSubmittedMap[$a['section_id']])) {
                    $insertAttLock->execute([
                        ':teacher_id'  => (int)$a['teacher_id'],
                        ':section_id'  => (int)$a['section_id'],
                        ':quarter'     => $quarter,
                        ':school_year' => $schoolYear,
                        ':deadline_id' => $deadlineId,
                        ':locked_since'=> $now,
                        ':teacher_id_check'  => (int)$a['teacher_id'],
                        ':section_id_check'  => (int)$a['section_id'],
                        ':quarter_check'     => $quarter,
                        ':school_year_check' => $schoolYear,
                    ]);
                    if ($insertAttLock->rowCount() > 0) $newLocks++;
                }
            }
            $totalLocked += $newLocks;
            dlLog("Inserted {$newLocks} new attendance locks");
        }
    }

    dlLog("Lock pass complete. Total new locks: {$totalLocked}");

    if ($calledDirectly) {
        lockRespond(true, "Lock pass complete. New locks inserted: {$totalLocked}.", [
            'locked' => $totalLocked,
            'deadlines_processed' => $processedDeadlines,
            'timestamp' => $now
        ]);
    }

} catch (Throwable $e) {
    $errMsg = $e->getMessage();
    $trace = $e->getTraceAsString();
    dlLog("ERROR: " . $errMsg);
    
    if ($calledDirectly) {
        lockRespond(false, $errMsg, [
            'locked' => 0,
            'error_detail' => $trace
        ]);
    }
}