<?php

$required = false;
$possiblePaths = [
    __DIR__ . '/../login/teacher_auth.php',
    __DIR__ . '/../../login/teacher_auth.php',
    __DIR__ . '/../shared/db_connect.php',
    __DIR__ . '/../../shared/db_connect.php',
];

foreach ($possiblePaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $required = true;
        break;
    }
}

if (!$required) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Required file (teacher_auth.php or db_connect.php) not found.',
        'data' => []
    ]);
    exit;
}

header('Content-Type: application/json');

function respond($success, $message = '', $data = [])
{
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}

try {
    if (!isset($pdo) || !($pdo instanceof PDO)) {
        throw new Exception('Database connection not available.');
    }

    $teacherId = (int)($_SESSION['teacher_id'] ?? 0);
    if ($teacherId <= 0) {
        throw new Exception('Invalid teacher session.');
    }

    $activeYearStmt = $pdo->query("SELECT id, year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
    $activeYear = $activeYearStmt ? $activeYearStmt->fetch(PDO::FETCH_ASSOC) : null;
    if (!$activeYear) {
        respond(true, 'No active school year found.', [
            'year_label' => '',
            'quarter_number' => null,
            'quarter_label' => '',
            'teacher_deadline' => null,
            'adviser_deadline' => null,
            'is_adviser' => false,
            'reminders' => []
        ]);
    }

    $quarterStmt = $pdo->prepare("
        SELECT quarter_number, quarter_label
        FROM tblquarters
        WHERE academic_year_id = ? AND is_active = 1
        LIMIT 1
    ");
    $quarterStmt->execute([(int)$activeYear['id']]);
    $activeQuarter = $quarterStmt->fetch(PDO::FETCH_ASSOC);
    $quarterNumber = (int)($activeQuarter['quarter_number'] ?? 0);

    $deadlineRow = null;
    if ($quarterNumber > 0) {
        $deadlineStmt = $pdo->prepare("
            SELECT teacher_deadline, adviser_deadline
            FROM tbldeadlines
            WHERE school_year = ? AND quarter = ?
            LIMIT 1
        ");
        $deadlineStmt->execute([$activeYear['year_label'], $quarterNumber]);
        $deadlineRow = $deadlineStmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    $adviserStmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM tblsectionadviser
        WHERE teacher_id = ? AND academic_year_id = ?
    ");
    $adviserStmt->execute([$teacherId, (int)$activeYear['id']]);
    $isAdviser = ((int)$adviserStmt->fetchColumn()) > 0;

    $notificationTypes = ['teacher:' . $teacherId];
    if ($isAdviser) {
        $notificationTypes[] = 'adviser:' . $teacherId;
    }

    $placeholders = implode(',', array_fill(0, count($notificationTypes), '?'));
    $notifStmt = $pdo->prepare("
        SELECT id, title, message, type, created_at
        FROM system_notifications
        WHERE type IN ($placeholders)
        ORDER BY created_at DESC
        LIMIT 8
    ");
    $notifStmt->execute($notificationTypes);
    $notifications = $notifStmt->fetchAll(PDO::FETCH_ASSOC);

    $reminders = array_map(static function ($n) {
        return [
            'id' => (int)$n['id'],
            'title' => $n['title'],
            'message' => $n['message'],
            'type' => $n['type'],
            'created_at' => $n['created_at'],
            'created_at_display' => !empty($n['created_at']) ? date('M d, Y h:i A', strtotime($n['created_at'])) : '-'
        ];
    }, $notifications);

    $teacherDeadline = $deadlineRow['teacher_deadline'] ?? null;
    $adviserDeadline = $deadlineRow['adviser_deadline'] ?? null;

    respond(true, 'Teacher deadline feed loaded.', [
        'year_label' => $activeYear['year_label'],
        'quarter_number' => $quarterNumber > 0 ? $quarterNumber : null,
        'quarter_label' => $activeQuarter['quarter_label'] ?? '',
        'teacher_deadline' => $teacherDeadline,
        'teacher_deadline_display' => $teacherDeadline ? date('M d, Y h:i A', strtotime($teacherDeadline)) : '',
        'adviser_deadline' => $adviserDeadline,
        'adviser_deadline_display' => $adviserDeadline ? date('M d, Y h:i A', strtotime($adviserDeadline)) : '',
        'is_adviser' => $isAdviser,
        'teacher_overdue' => $teacherDeadline ? (strtotime($teacherDeadline) < time()) : false,
        'adviser_overdue' => $adviserDeadline ? (strtotime($adviserDeadline) < time()) : false,
        'reminders' => $reminders
    ]);
} catch (Throwable $e) {
    error_log('[get_teacher_deadline_feed ERROR] ' . $e->getMessage());
    respond(false, $e->getMessage());
}