<?php
header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user_id']) && empty($_SESSION['teacher_id']) && empty($_SESSION['admin_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Not authenticated.',
        'rows' => []
    ]);
    exit;
}

$required = false;
$searchPaths = [
    __DIR__ . '/../shared/db_connect.php',
    __DIR__ . '/../../shared/db_connect.php',
    __DIR__ . '/../db_connect.php',
    __DIR__ . '/db_connect.php',
    dirname(__DIR__) . '/shared/db_connect.php',
    dirname(dirname(__DIR__)) . '/shared/db_connect.php',
];

foreach ($searchPaths as $path) {
    if (file_exists($path)) {
        try {
            require_once $path;
            $required = true;
            break;
        } catch (Throwable $e) {
            continue;
        }
    }
}

if (!$required || !isset($pdo) || !($pdo instanceof PDO)) {
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed.',
        'rows' => []
    ]);
    exit;
}

function respond($success, $message = '', $rows = [])
{
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'rows'    => $rows
    ]);
    exit;
}

try {
    
    $lockScript = __DIR__ . '/process_deadline_locks.php';
    if (file_exists($lockScript)) {
        require_once $lockScript;
    }

    $stmt = $pdo->query("
        SELECT
            l.id,
            l.section_id,
            l.subject_id,
            l.teacher_id,
            l.quarter,
            l.school_year,
            l.deadline_id,
            l.locked_since,
            s.section_name,
            sub.subject_name,
            CONCAT(t.fname, ' ', t.lname) AS teacher_name,
            CONCAT('Q', l.quarter, ' ',
                CASE 
                    WHEN l.subject_id = 0 THEN 'Adviser'
                    WHEN l.subject_id = -1 THEN 'Attendance'
                    ELSE 'Teacher'
                END,
                ' Submission') AS deadline_title
        FROM (
            SELECT
                MAX(id) AS id,
                teacher_id,
                section_id,
                subject_id,
                quarter,
                school_year,
                MAX(deadline_id) AS deadline_id,
                MIN(locked_since) AS locked_since
            FROM tbldeadline_locks
            WHERE is_locked = 1
            GROUP BY teacher_id, section_id, subject_id, quarter, school_year
        ) l
        LEFT JOIN tblsection  s   ON s.id   = l.section_id
        LEFT JOIN tblsubjects sub ON sub.id  = l.subject_id
        LEFT JOIN tblteacher  t   ON t.id    = l.teacher_id
        ORDER BY l.locked_since DESC, l.id DESC
    ");

    if (!$stmt) {
        throw new Exception('Query failed: ' . implode(', ', $pdo->errorInfo()));
    }

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $formatted = [];
    foreach ($rows as $row) {
        $formatted[] = [
            'id'             => (int)$row['id'],
            'teacher_id'     => (int)$row['teacher_id'],
            'teacher_name'   => $row['teacher_name'],
            'section_name'   => $row['section_name'] ?? '—',
            'subject_name'   => $row['subject_name'] ?? '—',
            'quarter'        => (int)$row['quarter'],
            'school_year'    => $row['school_year'],
            'deadline_title' => $row['deadline_title'],
            'locked_since'   => $row['locked_since']
                ? date('M d, Y h:i A', strtotime($row['locked_since']))
                : '—',
        ];
    }

    respond(true, count($formatted) . ' locked entry/entries found.', $formatted);
} catch (Throwable $e) {
    error_log('[get_locked_entries ERROR] ' . $e->getMessage());
    respond(false, $e->getMessage());
}