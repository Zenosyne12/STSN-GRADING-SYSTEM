<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

function respond($success, $message = '', $rows = [])
{
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'rows' => $rows
    ]);
    exit;
}

try {
    /*
        ADJUST THIS TO MATCH YOUR ACTUAL LOCK TABLE.

        Assumed table:
        - tbldeadline_locks
          columns: id, user_id, user_type, section_id, deadline_id, locked_since, is_locked
    */

    $stmt = $pdo->query("
        SELECT
            l.id,
            l.user_id,
            l.user_type,
            l.section_id,
            l.deadline_id,
            l.locked_since,
            d.title AS deadline_title,
            s.section_name,
            CASE
                WHEN l.user_type = 'teacher' THEN (
                    SELECT CONCAT(t.firstname, ' ', t.lastname)
                    FROM tblteacher t
                    WHERE t.id = l.user_id
                    LIMIT 1
                )
                ELSE (
                    SELECT CONCAT(t.firstname, ' ', t.lastname)
                    FROM tblteacher t
                    WHERE t.id = l.user_id
                    LIMIT 1
                )
            END AS user_name
        FROM tbldeadline_locks l
        LEFT JOIN tbldeadlines d ON d.id = l.deadline_id
        LEFT JOIN tblsection s ON s.id = l.section_id
        WHERE l.is_locked = 1
        ORDER BY l.locked_since DESC, l.id DESC
    ");

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $formatted = [];
    foreach ($rows as $row) {
        $formatted[] = [
            'id' => (int) $row['id'],
            'user_id' => (int) $row['user_id'],
            'user_type' => $row['user_type'],
            'user_name' => $row['user_name'],
            'deadline_title' => $row['deadline_title'],
            'section_name' => $row['section_name'],
            'locked_since' => $row['locked_since'] ? date('M d, Y h:i A', strtotime($row['locked_since'])) : '-'
        ];
    }

    respond(true, 'Locked entries loaded.', $formatted);
} catch (Throwable $e) {
    respond(false, $e->getMessage());
}