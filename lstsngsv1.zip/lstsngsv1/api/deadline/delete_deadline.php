<?php
header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user_id']) && empty($_SESSION['teacher_id']) && empty($_SESSION['admin_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Not authenticated.'
    ]);
    exit;
}

$required = false;
$searchPaths = [
    __DIR__ . '/../shared/db_connect.php',
    __DIR__ . '/../../shared/db_connect.php',
    __DIR__ . '/../db_connect.php',
    __DIR__ . '/db_connect.php',
    dirname(__DIR__) . '/shared/db_connect.php',
    dirname(dirname(__DIR__)) . '/shared/db_connect.php',
];

foreach ($searchPaths as $path) {
    if (file_exists($path)) {
        try {
            require_once $path;
            $required = true;
            break;
        } catch (Throwable $e) {
            continue;
        }
    }
}

if (!$required || !isset($pdo) || !($pdo instanceof PDO)) {
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed.'
    ]);
    exit;
}

function respond($success, $message = '')
{
    echo json_encode(['success' => $success, 'message' => $message]);
    exit;
}

try {
    $rawId = isset($_POST['deadline_id']) ? trim($_POST['deadline_id']) : '';
    $deadlineType = '';

    if (strpos($rawId, '_') !== false) {
        [$baseId, $typePart] = explode('_', $rawId, 2);
        $deadlineId = (int)$baseId;
        $deadlineType = strtolower(trim($typePart));
    } else {
        $deadlineId = (int)$rawId;
    }

    if ($deadlineId <= 0) throw new Exception('Invalid deadline id.');

    $validTypes = ['teacher', 'adviser', 'attendance'];
    
    if (in_array($deadlineType, $validTypes, true)) {
        $columnMap = [
            'teacher'    => 'teacher_deadline',
            'adviser'    => 'adviser_deadline',
            'attendance' => 'attendance_deadline'
        ];
        $column = $columnMap[$deadlineType];
        
        
        $otherCols = array_diff($validTypes, [$deadlineType]);
        $otherNullChecks = [];
        foreach ($otherCols as $ot) {
            $otherNullChecks[] = $columnMap[$ot] . ' IS NULL';
        }
        $otherNullSql = implode(' AND ', $otherNullChecks);

        $stmt = $pdo->prepare("UPDATE tbldeadlines SET {$column} = NULL WHERE id = ?");
        $stmt->execute([$deadlineId]);

        $cleanup = $pdo->prepare("DELETE FROM tbldeadlines WHERE id = ? AND {$otherNullSql}");
        $cleanup->execute([$deadlineId]);
    } else {
        $stmt = $pdo->prepare("DELETE FROM tbldeadlines WHERE id = ?");
        $stmt->execute([$deadlineId]);
    }

    respond(true, 'Deadline deleted successfully.');
} catch (Throwable $e) {
    error_log('[delete_deadline ERROR] ' . $e->getMessage());
    respond(false, $e->getMessage());
}