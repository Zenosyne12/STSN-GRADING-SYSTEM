<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

function respond($success, $message = '')
{
    echo json_encode([
        'success' => $success,
        'message' => $message
    ]);
    exit;
}

try {
    $deadlineId = isset($_POST['deadline_id']) ? (int) $_POST['deadline_id'] : 0;

    if ($deadlineId <= 0) {
        throw new Exception('Invalid deadline id.');
    }

    $stmt = $pdo->prepare("DELETE FROM tbldeadlines WHERE id = ?");
    $stmt->execute([$deadlineId]);

    respond(true, 'Deadline deleted successfully.');
} catch (Throwable $e) {
    respond(false, $e->getMessage());
}