<?php
header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user_id']) && empty($_SESSION['teacher_id']) && empty($_SESSION['admin_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Not authenticated.'
    ]);
    exit;
}

$required = false;
$searchPaths = [
    __DIR__ . '/../shared/db_connect.php',
    __DIR__ . '/../../shared/db_connect.php',
    __DIR__ . '/../db_connect.php',
    __DIR__ . '/db_connect.php',
    dirname(__DIR__) . '/shared/db_connect.php',
    dirname(dirname(__DIR__)) . '/shared/db_connect.php',
];

foreach ($searchPaths as $path) {
    if (file_exists($path)) {
        try {
            require_once $path;
            $required = true;
            break;
        } catch (Throwable $e) {
            continue;
        }
    }
}

if (!$required || !isset($pdo) || !($pdo instanceof PDO)) {
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed.'
    ]);
    exit;
}

function respond($success, $message = '')
{
    echo json_encode([
        'success' => $success,
        'message' => $message
    ]);
    exit;
}

try {
    $rawId       = isset($_POST['id'])            ? trim($_POST['id'])                        : '';
    $schoolYear  = isset($_POST['school_year'])   ? trim($_POST['school_year'])               : '';
    $quarter     = isset($_POST['quarter'])       ? (int)$_POST['quarter']                   : 0;
    $deadlineType= isset($_POST['deadline_type']) ? strtolower(trim($_POST['deadline_type'])): '';
    $dueDate     = isset($_POST['due_date'])      ? trim($_POST['due_date'])                  : '';
    $dueTime     = isset($_POST['due_time'])      ? trim($_POST['due_time'])                  : '';

    if ($schoolYear === '') throw new Exception('School year is required.');
    if (!in_array($quarter, [1, 2, 3, 4], true)) throw new Exception('Invalid quarter.');
    if (!in_array($deadlineType, ['teacher', 'adviser'], true)) throw new Exception('Invalid deadline type.');
    if ($dueDate === '' || $dueTime === '') throw new Exception('Due date and time are required.');

    $dueAt  = $dueDate . ' ' . $dueTime . ':00';
    $column = $deadlineType === 'teacher' ? 'teacher_deadline' : 'adviser_deadline';

    
    $baseId = 0;
    if ($rawId !== '' && strpos($rawId, '_') !== false) {
        [$base] = explode('_', $rawId, 2);
        $baseId = (int)$base;
    } elseif ($rawId !== '') {
        $baseId = (int)$rawId;
    }

    
    if ($baseId > 0) {
        $stmt = $pdo->prepare("
            UPDATE tbldeadlines
            SET school_year = :school_year,
                quarter     = :quarter,
                {$column}   = :due_at
            WHERE id = :id
        ");
        $stmt->execute([
            ':school_year' => $schoolYear,
            ':quarter'     => $quarter,
            ':due_at'      => $dueAt,
            ':id'          => $baseId,
        ]);
        respond(true, 'Deadline updated successfully.');
    }

    
    $check = $pdo->prepare("
        SELECT id FROM tbldeadlines
        WHERE school_year = ? AND quarter = ?
        LIMIT 1
    ");
    $check->execute([$schoolYear, $quarter]);
    $existingId = $check->fetchColumn();

    if ($existingId) {
        $stmt = $pdo->prepare("
            UPDATE tbldeadlines SET {$column} = :due_at WHERE id = :id
        ");
        $stmt->execute([':due_at' => $dueAt, ':id' => $existingId]);
        respond(true, 'Deadline saved successfully.');
    }

    
    $teacherDeadline = $deadlineType === 'teacher' ? $dueAt : null;
    $adviserDeadline = $deadlineType === 'adviser' ? $dueAt : null;

    $stmt = $pdo->prepare("
        INSERT INTO tbldeadlines (school_year, quarter, teacher_deadline, adviser_deadline)
        VALUES (:school_year, :quarter, :teacher_deadline, :adviser_deadline)
    ");
    $stmt->execute([
        ':school_year'      => $schoolYear,
        ':quarter'          => $quarter,
        ':teacher_deadline' => $teacherDeadline,
        ':adviser_deadline' => $adviserDeadline,
    ]);

    respond(true, 'Deadline created successfully.');
} catch (Throwable $e) {
    error_log('[save_deadline ERROR] ' . $e->getMessage());
    respond(false, $e->getMessage());
}