<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

function respond($success, $message = '')
{
    echo json_encode([
        'success' => $success,
        'message' => $message
    ]);
    exit;
}

try {
    $rawId = isset($_POST['id']) ? trim($_POST['id']) : '';
    $schoolYear = isset($_POST['school_year']) ? trim($_POST['school_year']) : '';
    $quarter = isset($_POST['quarter']) ? (int)$_POST['quarter'] : 0;
    $deadlineType = isset($_POST['deadline_type']) ? strtolower(trim($_POST['deadline_type'])) : '';
    $dueDate = isset($_POST['due_date']) ? trim($_POST['due_date']) : '';
    $dueTime = isset($_POST['due_time']) ? trim($_POST['due_time']) : '';

    if ($schoolYear === '') {
        throw new Exception('School year is required.');
    }

    if (!in_array($quarter, [1, 2, 3, 4], true)) {
        throw new Exception('Invalid quarter.');
    }

    if (!in_array($deadlineType, ['teacher', 'adviser'], true)) {
        throw new Exception('Invalid deadline type.');
    }

    if ($dueDate === '' || $dueTime === '') {
        throw new Exception('Due date and time are required.');
    }

    $dueAt = $dueDate . ' ' . $dueTime . ':00';

    $baseId = 0;
    if ($rawId !== '' && strpos($rawId, '_') !== false) {
        [$base, $ignoreType] = explode('_', $rawId, 2);
        $baseId = (int)$base;
    }

    $column = $deadlineType === 'teacher' ? 'teacher_deadline' : 'adviser_deadline';

    if ($baseId > 0) {
        $sql = "UPDATE tbldeadlines SET school_year = :school_year, quarter = :quarter, {$column} = :due_at WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':school_year' => $schoolYear,
            ':quarter' => $quarter,
            ':due_at' => $dueAt,
            ':id' => $baseId
        ]);

        respond(true, 'Deadline updated successfully.');
    }

    $check = $pdo->prepare("SELECT id FROM tbldeadlines WHERE school_year = ? AND quarter = ? LIMIT 1");
    $check->execute([$schoolYear, $quarter]);
    $existingId = $check->fetchColumn();

    if ($existingId) {
        $sql = "UPDATE tbldeadlines SET {$column} = :due_at WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':due_at' => $dueAt,
            ':id' => $existingId
        ]);

        respond(true, 'Deadline saved successfully.');
    }

    $teacherDeadline = null;
    $adviserDeadline = null;

    if ($deadlineType === 'teacher') {
        $teacherDeadline = $dueAt;
    } else {
        $adviserDeadline = $dueAt;
    }

    $stmt = $pdo->prepare("
        INSERT INTO tbldeadlines (school_year, quarter, teacher_deadline, adviser_deadline)
        VALUES (:school_year, :quarter, :teacher_deadline, :adviser_deadline)
    ");
    $stmt->execute([
        ':school_year' => $schoolYear,
        ':quarter' => $quarter,
        ':teacher_deadline' => $teacherDeadline,
        ':adviser_deadline' => $adviserDeadline
    ]);

    respond(true, 'Deadline created successfully.');
} catch (Throwable $e) {
    respond(false, $e->getMessage());
}