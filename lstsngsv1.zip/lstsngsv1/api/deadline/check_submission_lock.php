<?php

if (!function_exists('checkSubmissionLock')) {

    function ensureSubmissionLock(
        PDO $pdo,
        int $teacherId,
        int $sectionId,
        int $subjectId,
        int $quarter,
        string $schoolYear
    ): void {
        $existingStmt = $pdo->prepare("
            SELECT id
            FROM tbldeadline_locks
            WHERE teacher_id = ?
              AND section_id = ?
              AND subject_id = ?
              AND quarter = ?
              AND school_year = ?
              AND is_locked = 1
            LIMIT 1
        ");
        $existingStmt->execute([$teacherId, $sectionId, $subjectId, $quarter, $schoolYear]);

        if ($existingStmt->fetch()) {
            return;
        }

        $insertStmt = $pdo->prepare("
            INSERT INTO tbldeadline_locks
                (teacher_id, section_id, subject_id, quarter, school_year, locked_at, is_locked)
            VALUES
                (:teacher_id, :section_id, :subject_id, :quarter, :school_year, NOW(), 1)
        ");
        $insertStmt->execute([
            ':teacher_id'  => $teacherId,
            ':section_id'  => $sectionId,
            ':subject_id'  => $subjectId,
            ':quarter'     => $quarter,
            ':school_year' => $schoolYear,
        ]);
    }

    function hasSubmissionUnlock(
        PDO $pdo,
        int $teacherId,
        int $sectionId,
        int $subjectId,
        int $quarter,
        string $schoolYear
    ): bool {
        $stmt = $pdo->prepare("
            SELECT 1
            FROM tbldeadline_locks
            WHERE teacher_id = ?
              AND section_id = ?
              AND subject_id = ?
              AND quarter = ?
              AND school_year = ?
              AND is_locked = 0
            LIMIT 1
        ");
        $stmt->execute([$teacherId, $sectionId, $subjectId, $quarter, $schoolYear]);
        return (bool)$stmt->fetchColumn();
    }

    function checkSubmissionLock(
        PDO    $pdo,
        int    $teacherId,
        int    $sectionId,
        int    $subjectId,
        int    $quarter,
        string $schoolYear,
        string $role = 'teacher'
    ): void {
        date_default_timezone_set('Asia/Manila');

        $lockScript = __DIR__ . '/process_deadline_locks.php';
        if (file_exists($lockScript)) {
            require_once $lockScript;
        }

        $deadlineCol = $role === 'teacher' ? 'teacher_deadline' : 'adviser_deadline';
        $lockSubjectId = $role === 'teacher' ? $subjectId : 0;

        $deadlineStmt = $pdo->prepare("
            SELECT {$deadlineCol} AS due_at
            FROM tbldeadlines
            WHERE school_year = ? AND quarter = ?
              AND {$deadlineCol} IS NOT NULL
            LIMIT 1
        ");
        $deadlineStmt->execute([$schoolYear, $quarter]);
        $dl = $deadlineStmt->fetch(PDO::FETCH_ASSOC);

        if ($dl && !empty($dl['due_at']) && strtotime($dl['due_at']) <= time()) {
            if (hasSubmissionUnlock($pdo, $teacherId, $sectionId, $lockSubjectId, $quarter, $schoolYear)) {
                return;
            }

            ensureSubmissionLock(
                $pdo,
                $teacherId,
                $sectionId,
                $lockSubjectId,
                $quarter,
                $schoolYear
            );

            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'The submission deadline has already passed ('
                    . date('M d, Y h:i A', strtotime($dl['due_at']))
                    . '). Please contact the administrator to unlock your submission.',
            ]);
            exit;
        }

        $lockStmt = $pdo->prepare("
            SELECT id FROM tbldeadline_locks
            WHERE teacher_id  = ?
              AND section_id  = ?
              AND subject_id  = ?
              AND quarter     = ?
              AND school_year = ?
              AND is_locked   = 1
            LIMIT 1
        ");
        $lockStmt->execute([$teacherId, $sectionId, $lockSubjectId, $quarter, $schoolYear]);

        if ($lockStmt->fetch()) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Your submission is locked because the deadline has passed. Please contact the administrator to unlock it.',
            ]);
            exit;
        }
    }
}