<?php
header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user_id']) && empty($_SESSION['teacher_id']) && empty($_SESSION['admin_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Not authenticated.'
    ]);
    exit;
}

$required = false;
$searchPaths = [
    __DIR__ . '/../shared/db_connect.php',
    __DIR__ . '/../../shared/db_connect.php',
    __DIR__ . '/../db_connect.php',
    __DIR__ . '/db_connect.php',
    dirname(__DIR__) . '/shared/db_connect.php',
    dirname(dirname(__DIR__)) . '/shared/db_connect.php',
];

foreach ($searchPaths as $path) {
    if (file_exists($path)) {
        try {
            require_once $path;
            $required = true;
            break;
        } catch (Throwable $e) {
            continue;
        }
    }
}

if (!$required || !isset($pdo) || !($pdo instanceof PDO)) {
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed.'
    ]);
    exit;
}

function respond($success, $message = '')
{
    echo json_encode(['success' => $success, 'message' => $message]);
    exit;
}

try {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

    if ($id <= 0) throw new Exception('Invalid locked entry id.');

    
    $fetch = $pdo->prepare("
        SELECT l.teacher_id, l.section_id, l.subject_id, l.quarter, l.school_year,
               CONCAT(t.fname, ' ', t.lname) AS teacher_name
        FROM tbldeadline_locks l
        LEFT JOIN tblteacher t ON t.id = l.teacher_id
        WHERE l.id = ?
        LIMIT 1
    ");
    $fetch->execute([$id]);
    $lock = $fetch->fetch(PDO::FETCH_ASSOC);

    if (!$lock) throw new Exception('Lock record not found.');

    
    $stmt = $pdo->prepare("
        UPDATE tbldeadline_locks
        SET is_locked = 0
        WHERE teacher_id = ?
          AND section_id = ?
          AND subject_id = ?
          AND quarter = ?
          AND school_year = ?
          AND is_locked = 1
    ");
    $stmt->execute([
        (int)$lock['teacher_id'],
        (int)$lock['section_id'],
        (int)$lock['subject_id'],
        (int)$lock['quarter'],
        $lock['school_year']
    ]);

    
    $lockType = (int)$lock['subject_id'] === -1 ? 'Attendance' : 
                ((int)$lock['subject_id'] === 0 ? 'Adviser' : 'Teacher');
    
    
    $title   = 'Q' . (int)$lock['quarter'] . ' ' . $lockType . ' Submission Unlocked';
    $message = 'Your ' . strtolower($lockType) . ' submission for Q' . (int)$lock['quarter'] . ' (' . $lock['school_year'] . ') has been unlocked by the admin. You may now re-submit.';

    $notif = $pdo->prepare("
        INSERT INTO system_notifications (title, message, type, created_at)
        VALUES (?, ?, ?, NOW())
    ");
    $notif->execute([$title, $message, 'teacher:' . (int)$lock['teacher_id']]);

    respond(true, 'Entry unlocked and teacher notified.');
} catch (Throwable $e) {
    error_log('[unlock_locked_entry ERROR] ' . $e->getMessage());
    respond(false, $e->getMessage());
}