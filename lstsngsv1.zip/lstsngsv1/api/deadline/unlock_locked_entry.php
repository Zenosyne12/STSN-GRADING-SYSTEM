<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

function respond($success, $message = '')
{
    echo json_encode([
        'success' => $success,
        'message' => $message
    ]);
    exit;
}

try {
    $id = isset($_POST['id']) ? (int) $_POST['id'] : 0;

    if ($id <= 0) {
        throw new Exception('Invalid locked entry id.');
    }

    /*
        Adjust if your lock table uses a different name or unlock logic.
    */
    $stmt = $pdo->prepare("
        UPDATE tbldeadline_locks
        SET is_locked = 0
        WHERE id = ?
    ");
    $stmt->execute([$id]);

    respond(true, 'Locked entry unlocked successfully.');
} catch (Throwable $e) {
    respond(false, $e->getMessage());
}