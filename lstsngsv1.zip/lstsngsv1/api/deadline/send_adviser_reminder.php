<?php
header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user_id']) && empty($_SESSION['teacher_id']) && empty($_SESSION['admin_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Not authenticated.'
    ]);
    exit;
}

$required = false;
$searchPaths = [
    __DIR__ . '/../shared/db_connect.php',
    __DIR__ . '/../../shared/db_connect.php',
    __DIR__ . '/../db_connect.php',
    __DIR__ . '/db_connect.php',
    dirname(__DIR__) . '/shared/db_connect.php',
    dirname(dirname(__DIR__)) . '/shared/db_connect.php',
];

foreach ($searchPaths as $path) {
    if (file_exists($path)) {
        try {
            require_once $path;
            $required = true;
            break;
        } catch (Throwable $e) {
            continue;
        }
    }
}

if (!$required || !isset($pdo) || !($pdo instanceof PDO)) {
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed.'
    ]);
    exit;
}

function respond($success, $message = '')
{
    echo json_encode(['success' => $success, 'message' => $message]);
    exit;
}

try {
    $deadlineId = isset($_POST['deadline_id']) ? (int)$_POST['deadline_id'] : 0;
    $adviserId  = isset($_POST['adviser_id'])  ? (int)$_POST['adviser_id']  : 0;

    if ($deadlineId <= 0 || $adviserId <= 0) throw new Exception('Invalid request.');

    $stmt = $pdo->prepare("
        SELECT quarter, school_year, adviser_deadline
        FROM tbldeadlines
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->execute([$deadlineId]);
    $deadline = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$deadline) throw new Exception('Deadline not found.');

    $title   = 'Q' . (int)$deadline['quarter'] . ' Adviser Submission';
    $dueAt   = $deadline['adviser_deadline'];
    $message = 'Reminder: ' . $title . ' is due on ' . date('M d, Y h:i A', strtotime($dueAt)) . '.';

    $insert = $pdo->prepare("
        INSERT INTO system_notifications (title, message, type, created_at)
        VALUES (?, ?, ?, NOW())
    ");
    $insert->execute([$title, $message, 'adviser:' . $adviserId]);

    respond(true, 'Adviser reminder sent successfully.');
} catch (Throwable $e) {
    error_log('[send_adviser_reminder ERROR] ' . $e->getMessage());
    respond(false, $e->getMessage());
}