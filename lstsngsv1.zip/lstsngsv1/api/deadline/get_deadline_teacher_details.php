<?php
header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user_id']) && empty($_SESSION['teacher_id']) && empty($_SESSION['admin_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Not authenticated.',
        'rows' => []
    ]);
    exit;
}

$required = false;
$searchPaths = [
    __DIR__ . '/../shared/db_connect.php',
    __DIR__ . '/../../shared/db_connect.php',
    __DIR__ . '/../db_connect.php',
    __DIR__ . '/db_connect.php',
    dirname(__DIR__) . '/shared/db_connect.php',
    dirname(dirname(__DIR__)) . '/shared/db_connect.php',
];

foreach ($searchPaths as $path) {
    if (file_exists($path)) {
        try {
            require_once $path;
            $required = true;
            break;
        } catch (Throwable $e) {
            continue;
        }
    }
}

if (!$required || !isset($pdo) || !($pdo instanceof PDO)) {
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed.',
        'rows' => []
    ]);
    exit;
}

function respond($success, $message = '', $rows = [])
{
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'rows'    => $rows
    ]);
    exit;
}

try {
    $deadlineId = isset($_GET['deadline_id']) ? (int)$_GET['deadline_id'] : 0;

    if ($deadlineId <= 0) {
        throw new Exception('Invalid deadline id.');
    }

    
    $dlStmt = $pdo->prepare("
        SELECT school_year, quarter, teacher_deadline
        FROM tbldeadlines
        WHERE id = ?
        LIMIT 1
    ");
    $dlStmt->execute([$deadlineId]);
    $deadline = $dlStmt->fetch(PDO::FETCH_ASSOC);

    if (!$deadline) {
        throw new Exception('Deadline not found.');
    }

    $schoolYear = $deadline['school_year'];
    $quarter    = (int)$deadline['quarter'];

    
    
    $assignStmt = $pdo->prepare("
        SELECT DISTINCT
            t.id AS teacher_id,
            CONCAT(t.fname, ' ', COALESCE(t.mname, ''), ' ', t.lname) AS teacher_name,
            s.id AS section_id,
            s.section_name,
            sub.id AS subject_id,
            sub.subject_name
        FROM (
            SELECT DISTINCT teacher_id, section_id, subject_id
            FROM tblsection_teacher_subject
            WHERE is_active = 1
            UNION
            SELECT DISTINCT teacher_id, section_id, subject_id
            FROM tblschedule
            WHERE is_active = 1 AND school_year = ?
        ) assignments
        INNER JOIN tblteacher t ON t.id = assignments.teacher_id
        INNER JOIN tblsection s ON s.id = assignments.section_id
        INNER JOIN tblsubjects sub ON sub.id = assignments.subject_id
        ORDER BY teacher_name ASC, s.section_name ASC, sub.subject_name ASC
    ");
    $assignStmt->execute([$schoolYear]);
    $assignments = $assignStmt->fetchAll(PDO::FETCH_ASSOC);

    
    $subStmt = $pdo->prepare("
        SELECT DISTINCT
            teacher_id,
            section_id,
            subject_id,
            submitted_at
        FROM tblteacher_submissions
        WHERE school_year = ? AND quarter = ?
    ");
    $subStmt->execute([$schoolYear, $quarter]);
    $submissions = $subStmt->fetchAll(PDO::FETCH_ASSOC);

    
    $subMap = [];
    foreach ($submissions as $sub) {
        $key = $sub['teacher_id'] . '-' . $sub['section_id'] . '-' . $sub['subject_id'];
        $subMap[$key] = $sub['submitted_at'];
    }

    
    $rows = [];
    foreach ($assignments as $a) {
        $key       = $a['teacher_id'] . '-' . $a['section_id'] . '-' . $a['subject_id'];
        $submitted = isset($subMap[$key]);
        $subAt     = $submitted ? $subMap[$key] : null;

        $rows[] = [
            'teacher_id'           => (int)$a['teacher_id'],
            'teacher_name'         => trim(preg_replace('/\s+/', ' ', $a['teacher_name'])),
            'section_id'           => (int)$a['section_id'],
            'section_name'         => $a['section_name'],
            'subject_id'           => (int)$a['subject_id'],
            'subject_name'         => $a['subject_name'],
            'status_label'         => $submitted ? 'Submitted' : 'Not Submitted',
            'submitted_at'         => $subAt,
            'submitted_at_display' => $subAt ? date('M d, Y h:i A', strtotime($subAt)) : '-',
        ];
    }

    respond(true, 'Teacher compliance loaded.', $rows);
} catch (Throwable $e) {
    error_log('[get_deadline_teacher_details ERROR] ' . $e->getMessage());
    respond(false, $e->getMessage());
}