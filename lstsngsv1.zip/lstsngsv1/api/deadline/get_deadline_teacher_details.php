<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

function respond($success, $message = '', $rows = [])
{
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'rows' => $rows
    ]);
    exit;
}

try {
    $deadlineId = isset($_GET['deadline_id']) ? (int) $_GET['deadline_id'] : 0;

    if ($deadlineId <= 0) {
        throw new Exception('Invalid deadline id.');
    }

    $deadlineStmt = $pdo->prepare("
        SELECT id, school_year, quarter, deadline_type, applicable_to
        FROM tbldeadlines
        WHERE id = ?
        LIMIT 1
    ");
    $deadlineStmt->execute([$deadlineId]);
    $deadline = $deadlineStmt->fetch(PDO::FETCH_ASSOC);

    if (!$deadline) {
        throw new Exception('Deadline not found.');
    }

    $sectionIds = [];
    if (!empty($deadline['applicable_to'])) {
        $decoded = json_decode($deadline['applicable_to'], true);
        if (is_array($decoded)) {
            $sectionIds = array_map('intval', $decoded);
        }
    }

    /*
        ADJUST THIS QUERY TO MATCH YOUR ACTUAL TEACHER ASSIGNMENT TABLE.

        Assumed tables:
        - tblteacher t
        - teacher_subject_sections tss  (teacher_id, section_id)
        - tblsection s
    */

    $teacherSql = "
        SELECT DISTINCT
            t.id AS teacher_id,
            CONCAT(t.firstname, ' ', t.lastname) AS teacher_name,
            s.id AS section_id,
            s.section_name
        FROM teacher_subject_sections tss
        INNER JOIN tblteacher t ON t.id = tss.teacher_id
        INNER JOIN tblsection s ON s.id = tss.section_id
        WHERE 1 = 1
    ";

    $teacherParams = [];

    if (!empty($sectionIds)) {
        $in = implode(',', array_fill(0, count($sectionIds), '?'));
        $teacherSql .= " AND s.id IN ($in)";
        $teacherParams = array_merge($teacherParams, $sectionIds);
    }

    $teacherSql .= " ORDER BY teacher_name ASC, s.section_name ASC";

    $teacherStmt = $pdo->prepare($teacherSql);
    $teacherStmt->execute($teacherParams);
    $teachers = $teacherStmt->fetchAll(PDO::FETCH_ASSOC);

    $submissionStmt = $pdo->prepare("
        SELECT
            ts.teacher_id,
            ts.section_id,
            MIN(ts.submitted_at) AS submitted_at
        FROM teacher_submissions ts
        WHERE ts.school_year = ?
          AND ts.quarter = ?
        GROUP BY ts.teacher_id, ts.section_id
    ");
    $submissionStmt->execute([$deadline['school_year'], $deadline['quarter']]);
    $submissions = $submissionStmt->fetchAll(PDO::FETCH_ASSOC);

    $submissionMap = [];
    foreach ($submissions as $sub) {
        $key = $sub['teacher_id'] . '-' . $sub['section_id'];
        $submissionMap[$key] = $sub;
    }

    $rows = [];
    foreach ($teachers as $teacher) {
        $key = $teacher['teacher_id'] . '-' . $teacher['section_id'];
        $submitted = isset($submissionMap[$key]);
        $submittedAt = $submitted ? $submissionMap[$key]['submitted_at'] : null;

        $rows[] = [
            'teacher_id' => (int) $teacher['teacher_id'],
            'teacher_name' => $teacher['teacher_name'],
            'section_id' => (int) $teacher['section_id'],
            'section_name' => $teacher['section_name'],
            'status_label' => $submitted ? 'Submitted' : 'Not Submitted',
            'submitted_at' => $submittedAt,
            'submitted_at_display' => $submittedAt ? date('M d, Y h:i A', strtotime($submittedAt)) : '-'
        ];
    }

    respond(true, 'Teacher compliance loaded.', $rows);
} catch (Throwable $e) {
    respond(false, $e->getMessage());
}