<?php
header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user_id']) && empty($_SESSION['teacher_id']) && empty($_SESSION['admin_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Not authenticated.',
        'rows' => []
    ]);
    exit;
}

$required = false;
$searchPaths = [
    __DIR__ . '/../shared/db_connect.php',
    __DIR__ . '/../../shared/db_connect.php',
    __DIR__ . '/../db_connect.php',
    __DIR__ . '/db_connect.php',
    dirname(__DIR__) . '/shared/db_connect.php',
    dirname(dirname(__DIR__)) . '/shared/db_connect.php',
];

foreach ($searchPaths as $path) {
    if (file_exists($path)) {
        try {
            require_once $path;
            $required = true;
            break;
        } catch (Throwable $e) {
            continue;
        }
    }
}

if (!$required || !isset($pdo) || !($pdo instanceof PDO)) {
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed.',
        'rows' => []
    ]);
    exit;
}

function respond($success, $message = '', $rows = [])
{
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'rows'    => $rows
    ]);
    exit;
}

try {
    $deadlineId = isset($_GET['deadline_id']) ? (int)$_GET['deadline_id'] : 0;

    if ($deadlineId <= 0) {
        throw new Exception('Invalid deadline id.');
    }

    $deadlineStmt = $pdo->prepare("
        SELECT id, school_year, quarter, adviser_deadline
        FROM tbldeadlines
        WHERE id = ?
        LIMIT 1
    ");
    $deadlineStmt->execute([$deadlineId]);
    $deadline = $deadlineStmt->fetch(PDO::FETCH_ASSOC);

    if (!$deadline) {
        throw new Exception('Deadline not found.');
    }

    if (empty($deadline['adviser_deadline'])) {
        respond(true, 'No adviser deadline is configured for this record.', []);
    }

    $adviserStmt = $pdo->prepare("
        SELECT
            sa.teacher_id                         AS adviser_id,
            CONCAT(t.fname, ' ', t.lname)         AS adviser_name,
            s.id                                  AS section_id,
            s.section_name
        FROM tblsectionadviser sa
        INNER JOIN tblteacher t ON t.id  = sa.teacher_id
        INNER JOIN tblsection s ON s.id  = sa.section_id
        INNER JOIN tblacademicyear ay ON ay.id = sa.academic_year_id
        WHERE ay.year_label = ?
        ORDER BY adviser_name ASC, s.section_name ASC
    ");
    $adviserStmt->execute([$deadline['school_year']]);
    $advisers = $adviserStmt->fetchAll(PDO::FETCH_ASSOC);

    $submissionStmt = $pdo->prepare("
        SELECT
            teacher_id   AS adviser_id,
            section_id,
            MIN(submitted_at) AS submitted_at
        FROM tbladviser_submissions
        WHERE school_year = ?
          AND quarter     = ?
        GROUP BY teacher_id, section_id
    ");
    $submissionStmt->execute([$deadline['school_year'], $deadline['quarter']]);
    $submissions = $submissionStmt->fetchAll(PDO::FETCH_ASSOC);

    $submissionMap = [];
    foreach ($submissions as $sub) {
        $key = $sub['adviser_id'] . '-' . $sub['section_id'];
        $submissionMap[$key] = $sub;
    }

    $rows = [];
    foreach ($advisers as $adviser) {
        $key         = $adviser['adviser_id'] . '-' . $adviser['section_id'];
        $submitted   = isset($submissionMap[$key]);
        $submittedAt = $submitted ? $submissionMap[$key]['submitted_at'] : null;

        $rows[] = [
            'adviser_id'          => (int)$adviser['adviser_id'],
            'adviser_name'        => $adviser['adviser_name'],
            'section_id'          => (int)$adviser['section_id'],
            'section_name'        => $adviser['section_name'],
            'status_label'        => $submitted ? 'Submitted' : 'Not Submitted',
            'submitted_at'        => $submittedAt,
            'submitted_at_display'=> $submittedAt ? date('M d, Y h:i A', strtotime($submittedAt)) : '-',
        ];
    }

    respond(true, 'Adviser compliance loaded.', $rows);
} catch (Throwable $e) {
    error_log('[get_deadline_adviser_details ERROR] ' . $e->getMessage());
    respond(false, $e->getMessage());
}
