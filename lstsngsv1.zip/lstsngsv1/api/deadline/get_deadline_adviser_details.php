<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

function respond($success, $message = '', $rows = [])
{
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'rows' => $rows
    ]);
    exit;
}

try {
    $deadlineId = isset($_GET['deadline_id']) ? (int) $_GET['deadline_id'] : 0;

    if ($deadlineId <= 0) {
        throw new Exception('Invalid deadline id.');
    }

    $deadlineStmt = $pdo->prepare("
        SELECT id, school_year, quarter
        FROM tbldeadlines
        WHERE id = ?
        LIMIT 1
    ");
    $deadlineStmt->execute([$deadlineId]);
    $deadline = $deadlineStmt->fetch(PDO::FETCH_ASSOC);

    if (!$deadline) {
        throw new Exception('Deadline not found.');
    }

    /*
        ADJUST THIS QUERY TO MATCH YOUR ACTUAL ADVISER SETUP.

        Assumed:
        - tblsection has adviser_id
        - tblteacher stores adviser names too
    */
    $adviserStmt = $pdo->query("
        SELECT
            s.id AS section_id,
            s.section_name,
            t.id AS adviser_id,
            CONCAT(t.firstname, ' ', t.lastname) AS adviser_name
        FROM tblsection s
        INNER JOIN tblteacher t ON t.id = s.adviser_id
        ORDER BY adviser_name ASC, s.section_name ASC
    ");
    $advisers = $adviserStmt->fetchAll(PDO::FETCH_ASSOC);

    $submissionStmt = $pdo->prepare("
        SELECT
            teacher_id AS adviser_id,
            section_id,
            MIN(submitted_at) AS submitted_at
        FROM tbladviser_submissions
        WHERE school_year = ?
          AND quarter = ?
        GROUP BY teacher_id, section_id
    ");
    $submissionStmt->execute([$deadline['school_year'], $deadline['quarter']]);
    $submissions = $submissionStmt->fetchAll(PDO::FETCH_ASSOC);

    $submissionMap = [];
    foreach ($submissions as $sub) {
        $key = $sub['adviser_id'] . '-' . $sub['section_id'];
        $submissionMap[$key] = $sub;
    }

    $rows = [];
    foreach ($advisers as $adviser) {
        $key = $adviser['adviser_id'] . '-' . $adviser['section_id'];
        $submitted = isset($submissionMap[$key]);
        $submittedAt = $submitted ? $submissionMap[$key]['submitted_at'] : null;

        $rows[] = [
            'adviser_id' => (int) $adviser['adviser_id'],
            'adviser_name' => $adviser['adviser_name'],
            'section_id' => (int) $adviser['section_id'],
            'section_name' => $adviser['section_name'],
            'status_label' => $submitted ? 'Submitted' : 'Not Submitted',
            'submitted_at' => $submittedAt,
            'submitted_at_display' => $submittedAt ? date('M d, Y h:i A', strtotime($submittedAt)) : '-'
        ];
    }

    respond(true, 'Adviser compliance loaded.', $rows);
} catch (Throwable $e) {
    respond(false, $e->getMessage());
}