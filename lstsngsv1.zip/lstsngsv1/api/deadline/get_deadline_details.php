<?php
header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user_id']) && empty($_SESSION['teacher_id']) && empty($_SESSION['admin_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Not authenticated.',
        'row' => null
    ]);
    exit;
}

$required = false;
$searchPaths = [
    __DIR__ . '/../shared/db_connect.php',
    __DIR__ . '/../../shared/db_connect.php',
    __DIR__ . '/../db_connect.php',
    __DIR__ . '/db_connect.php',
    dirname(__DIR__) . '/shared/db_connect.php',
    dirname(dirname(__DIR__)) . '/shared/db_connect.php',
];

foreach ($searchPaths as $path) {
    if (file_exists($path)) {
        try {
            require_once $path;
            $required = true;
            break;
        } catch (Throwable $e) {
            continue;
        }
    }
}

if (!$required || !isset($pdo) || !($pdo instanceof PDO)) {
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed.',
        'row' => null
    ]);
    exit;
}

function respond($success, $message = '', $row = null)
{
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'row'     => $row
    ]);
    exit;
}

function getApplicableSectionIds(PDO $pdo, int $deadlineId): array
{
    $tableStmt = $pdo->query("SHOW TABLES LIKE 'tbldeadline_sections'");
    if (!$tableStmt || !$tableStmt->fetchColumn()) {
        return [];
    }

    $stmt = $pdo->prepare("SELECT section_id FROM tbldeadline_sections WHERE deadline_id = ? ORDER BY section_id");
    $stmt->execute([$deadlineId]);
    return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
}

try {
    $rawId = isset($_GET['deadline_id']) ? trim($_GET['deadline_id']) : '';
    $forcedType = isset($_GET['deadline_type']) ? strtolower(trim($_GET['deadline_type'])) : '';

    if ($rawId === '') {
        throw new Exception('Invalid deadline id.');
    }
    $baseId = 0;
    $type = '';
    if (strpos($rawId, '_') !== false) {
        [$basePart, $typePart] = explode('_', $rawId, 2);
        $baseId = (int)$basePart;
        $type = strtolower(trim($typePart));
    } else {
        $baseId = (int)$rawId;
    }
    if ($baseId <= 0) {
        throw new Exception('Invalid deadline id.');
    }
    if (in_array($forcedType, ['teacher', 'adviser'], true)) {
        $type = $forcedType;
    }

    $stmt = $pdo->prepare("
        SELECT id, school_year, quarter, teacher_deadline, adviser_deadline
        FROM tbldeadlines
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->execute([$baseId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        throw new Exception('Deadline not found.');
    }

    if (!in_array($type, ['teacher', 'adviser'], true)) {
        if (!empty($row['teacher_deadline'])) $type = 'teacher';
        elseif (!empty($row['adviser_deadline'])) $type = 'adviser';
        else $type = 'teacher';
    }

    $dueAt = $type === 'teacher' ? $row['teacher_deadline'] : $row['adviser_deadline'];

    if (!$dueAt) {
        throw new Exception('Selected deadline type has no saved due date.');
    }

    respond(true, 'Deadline loaded.', [
        'id'                  => $baseId . '_' . $type,
        'base_id'             => (int)$baseId,
        'deadline_type'       => ucfirst($type),
        'title'               => 'Q' . (int)$row['quarter'] . ' ' . ucfirst($type) . ' Submission',
        'school_year'         => $row['school_year'],
        'quarter'             => (int)$row['quarter'],
        'due_at'              => $dueAt,
        'due_date'            => date('Y-m-d', strtotime($dueAt)),
        'due_time'            => date('H:i',   strtotime($dueAt)),
        'applicable_sections' => $type === 'teacher' ? getApplicableSectionIds($pdo, $baseId) : [],
    ]);
} catch (Throwable $e) {
    error_log('[get_deadline_details ERROR] ' . $e->getMessage());
    respond(false, $e->getMessage());
}
