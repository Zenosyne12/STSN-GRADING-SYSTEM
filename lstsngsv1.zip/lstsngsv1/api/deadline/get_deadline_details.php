<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

function respond($success, $message = '', $row = null)
{
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'row' => $row
    ]);
    exit;
}

try {
    $rawId = isset($_GET['deadline_id']) ? trim($_GET['deadline_id']) : '';

    if ($rawId === '' || strpos($rawId, '_') === false) {
        throw new Exception('Invalid deadline id.');
    }

    [$baseId, $type] = explode('_', $rawId, 2);
    $baseId = (int)$baseId;
    $type = strtolower(trim($type));

    if ($baseId <= 0 || !in_array($type, ['teacher', 'adviser'], true)) {
        throw new Exception('Invalid deadline id.');
    }

    $stmt = $pdo->prepare("
        SELECT id, school_year, quarter, teacher_deadline, adviser_deadline
        FROM tbldeadlines
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->execute([$baseId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        throw new Exception('Deadline not found.');
    }

    $dueAt = $type === 'teacher' ? $row['teacher_deadline'] : $row['adviser_deadline'];

    if (!$dueAt) {
        throw new Exception('Selected deadline type has no saved due date.');
    }

    respond(true, 'Deadline loaded.', [
        'id' => $baseId . '_' . $type,
        'base_id' => (int)$baseId,
        'deadline_type' => ucfirst($type),
        'title' => 'Q' . (int)$row['quarter'] . ' ' . ucfirst($type) . ' Submission',
        'school_year' => $row['school_year'],
        'quarter' => (int)$row['quarter'],
        'due_at' => $dueAt,
        'due_date' => date('Y-m-d', strtotime($dueAt)),
        'due_time' => date('H:i', strtotime($dueAt)),
        'applicable_sections' => []
    ]);
} catch (Throwable $e) {
    respond(false, $e->getMessage());
}