<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

function respond($success, $message = '')
{
    echo json_encode([
        'success' => $success,
        'message' => $message
    ]);
    exit;
}

try {
    $deadlineId = isset($_POST['deadline_id']) ? (int) $_POST['deadline_id'] : 0;
    $teacherId = isset($_POST['teacher_id']) ? (int) $_POST['teacher_id'] : 0;

    if ($deadlineId <= 0 || $teacherId <= 0) {
        throw new Exception('Invalid request.');
    }

    $stmt = $pdo->prepare("
        SELECT title, school_year, quarter, due_at
        FROM tbldeadlines
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->execute([$deadlineId]);
    $deadline = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$deadline) {
        throw new Exception('Deadline not found.');
    }

    /*
        Adjust columns to match system_notifications.
    */
    $insert = $pdo->prepare("
        INSERT INTO system_notifications
        (user_id, user_type, title, message, created_at)
        VALUES
        (?, 'teacher', ?, ?, NOW())
    ");

    $message = 'Reminder: ' . $deadline['title'] . ' is due on ' . date('M d, Y h:i A', strtotime($deadline['due_at'])) . '.';
    $insert->execute([$teacherId, 'Deadline Reminder', $message]);

    respond(true, 'Teacher reminder sent successfully.');
} catch (Throwable $e) {
    respond(false, $e->getMessage());
}