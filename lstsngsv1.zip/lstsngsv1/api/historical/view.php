<?php
ob_start();
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/grade_workflow.php';
ob_end_clean();

header('Content-Type: application/json');

$studentId = (int) ($_GET['student_id'] ?? 0);
$yearId    = (int) ($_GET['year_id'] ?? 0);

if (!$studentId || !$yearId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'student_id and year_id are required.']);
    exit;
}

try {
    ensureGradeWorkflowSchema($pdo);

    $stStmt = $pdo->prepare("
        SELECT id, lrn, fname, mname, lname, gender, grade_level_id
        FROM tblstudents
        WHERE id = ?
        LIMIT 1
    ");
    $stStmt->execute([$studentId]);
    $student = $stStmt->fetch(PDO::FETCH_ASSOC);
    if (!$student) {
        echo json_encode(['success' => false, 'error' => 'Student not found.']);
        exit;
    }

    $fullName = trim(preg_replace('/\s+/', ' ', implode(' ', array_filter([
        $student['fname'] ?? '',
        $student['mname'] ?? '',
        $student['lname'] ?? '',
    ]))));

    $yearStmt = $pdo->prepare("SELECT id, year_label, is_active FROM tblacademicyear WHERE id = ? LIMIT 1");
    $yearStmt->execute([$yearId]);
    $year = $yearStmt->fetch(PDO::FETCH_ASSOC);

    $archive = null;
    try {
        $arStmt = $pdo->prepare("SELECT * FROM tblstudent_archive WHERE student_id = ? AND academic_year_id = ? LIMIT 1");
        $arStmt->execute([$studentId, $yearId]);
        $archive = $arStmt->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) {
        $archive = null;
    }

    $enrollment = null;
    try {
        $enStmt = $pdo->prepare("
            SELECT e.grade_level_id, e.enrollment_status, gl.grade_level_name
            FROM tblenrollment e
            LEFT JOIN tblgradelevel gl ON gl.id = e.grade_level_id
            WHERE e.student_id = ? AND e.academic_year_id = ?
            LIMIT 1
        ");
        $enStmt->execute([$studentId, $yearId]);
        $enrollment = $enStmt->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) {
        $enrollment = null;
    }

    $section = null;
    try {
        $ssStmt = $pdo->prepare("
            SELECT ss.section_id, s.section_name,
                   TRIM(CONCAT(COALESCE(t.fname,''), ' ', COALESCE(t.lname,''))) AS adviser_name,
                   gl.grade_level_name, gl.id AS grade_level_id
            FROM tblsectionstudent ss
            JOIN tblsection s ON s.id = ss.section_id
            LEFT JOIN tblsectionadviser sa ON sa.section_id = ss.section_id AND sa.academic_year_id = ?
            LEFT JOIN tblteacher t ON t.id = sa.teacher_id
            LEFT JOIN tblgradelevel gl ON gl.id = s.grade_level_id
            WHERE ss.student_id = ? AND ss.academic_year_id = ?
            LIMIT 1
        ");
        $ssStmt->execute([$yearId, $studentId, $yearId]);
        $section = $ssStmt->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) {
        $section = null;
    }

    $gradeLevelId = (int) ($archive['grade_level_id'] ?? $enrollment['grade_level_id'] ?? $section['grade_level_id'] ?? $student['grade_level_id'] ?? 0);
    $gradeLevelName = $enrollment['grade_level_name'] ?? $section['grade_level_name'] ?? '';
    if ($gradeLevelName === '' && $gradeLevelId) {
        $glStmt = $pdo->prepare("SELECT grade_level_name FROM tblgradelevel WHERE id = ? LIMIT 1");
        $glStmt->execute([$gradeLevelId]);
        $gradeLevelName = (string) $glStmt->fetchColumn();
    }

    $subjects = [];
    if ($gradeLevelId) {
        $subStmt = $pdo->prepare("
            SELECT id, subject_name, subject_code, subject_type
            FROM tblsubjects
            WHERE grade_level_id = ?
            ORDER BY subject_type, subject_name
        ");
        $subStmt->execute([$gradeLevelId]);
        $subjects = $subStmt->fetchAll(PDO::FETCH_ASSOC);
    }

    $quStmt = $pdo->prepare("
        SELECT id, quarter_number, quarter_label
        FROM tblquarters
        WHERE academic_year_id = ?
        ORDER BY quarter_number
    ");
    $quStmt->execute([$yearId]);
    $quarters = $quStmt->fetchAll(PDO::FETCH_ASSOC);

    $grStmt = $pdo->prepare("
        SELECT subject_id, quarter, final_grade, remarks
        FROM tblgrades
        WHERE student_id = ? AND academic_year_id = ?
        ORDER BY subject_id, quarter
    ");
    $grStmt->execute([$studentId, $yearId]);
    $rawGrades = $grStmt->fetchAll(PDO::FETCH_ASSOC);

    $gradeIndex = [];
    foreach ($rawGrades as $row) {
        $gradeIndex[(int) $row['subject_id']][(int) $row['quarter']] = $row;
    }

    $subjectRows = [];
    $overallSum = 0;
    $overallCnt = 0;
    foreach ($subjects as $sub) {
        $subId = (int) $sub['id'];
        $qGrades = $gradeIndex[$subId] ?? [];
        $qData = [];
        $subSum = 0;
        $subCnt = 0;
        foreach ($quarters as $q) {
            $qNum = (int) $q['quarter_number'];
            if (isset($qGrades[$qNum]) && (int) $qGrades[$qNum]['final_grade'] > 0) {
                $fg = (int) $qGrades[$qNum]['final_grade'];
                $qData[] = [
                    'quarter_number' => $qNum,
                    'quarter_label'  => $q['quarter_label'],
                    'final_grade'    => $fg,
                    'remarks'        => $qGrades[$qNum]['remarks'],
                ];
                $subSum += $fg;
                $subCnt++;
            } else {
                $qData[] = [
                    'quarter_number' => $qNum,
                    'quarter_label'  => $q['quarter_label'],
                    'final_grade'    => null,
                    'remarks'        => null,
                ];
            }
        }
        $subAvg = $subCnt ? round($subSum / $subCnt, 2) : null;
        if ($subAvg !== null) {
            $overallSum += $subAvg;
            $overallCnt++;
        }
        $subjectRows[] = [
            'subject_name'    => $sub['subject_name'],
            'subject_type'    => $sub['subject_type'] ?? '',
            'quarter_grades'  => $qData,
            'subject_average' => $subAvg,
        ];
    }

    $generalAverage = $archive['final_average'] !== null && $archive['final_average'] !== ''
        ? round((float) $archive['final_average'], 2)
        : ($overallCnt ? round($overallSum / $overallCnt, 2) : null);

    echo json_encode([
        'success' => true,
        'student' => [
            'id' => (int) $student['id'],
            'lrn' => $student['lrn'],
            'full_name' => $fullName,
            'gender' => $student['gender'],
            'grade_level' => $gradeLevelName ?: '—',
            'section_name' => $section['section_name'] ?? '—',
            'adviser_name' => trim((string) ($section['adviser_name'] ?? '')) ?: '—',
            'status' => $archive['status'] ?? ($enrollment['enrollment_status'] ?? 'ARCHIVED'),
        ],
        'year' => $year,
        'quarters' => $quarters,
        'subjects' => $subjectRows,
        'general_average' => $generalAverage,
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
