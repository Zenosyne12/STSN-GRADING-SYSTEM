<?php
ob_start();
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
ob_end_clean();

header('Content-Type: application/json');

function hrTableExists(PDO $pdo, string $table): bool
{
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
    ");
    $stmt->execute([$table]);
    return (int) $stmt->fetchColumn() > 0;
}

try {
    $page      = max(1, (int) ($_GET['p'] ?? 1));
    $limit     = 10;
    $offset    = ($page - 1) * $limit;
    $yearId    = trim((string) ($_GET['year_id'] ?? ''));
    $search    = trim((string) ($_GET['search'] ?? ''));
    $gradeId   = trim((string) ($_GET['grade_id'] ?? ''));
    $sectionId = trim((string) ($_GET['section_id'] ?? ''));
    $status    = strtoupper(trim((string) ($_GET['status'] ?? '')));

    $allYears = $pdo->query("
        SELECT id, year_label, is_active, start_date, end_date
        FROM tblacademicyear
        ORDER BY year_label DESC
    ")->fetchAll(PDO::FETCH_ASSOC);

    $activeYear = null;
    foreach ($allYears as $year) {
        if ((int) $year['is_active'] === 1) {
            $activeYear = $year;
            break;
        }
    }

    if ($yearId === '' || $yearId === '0') {
        $inactive = array_values(array_filter($allYears, static fn($y) => (int) $y['is_active'] !== 1));
        $yearId = (string) (($inactive[0]['id'] ?? $activeYear['id'] ?? ($allYears[0]['id'] ?? 0)));
    }

    $yearId = (int) $yearId;
    $selectedYear = null;
    foreach ($allYears as $year) {
        if ((int) $year['id'] === $yearId) {
            $selectedYear = $year;
            break;
        }
    }

    $hasArchive = hrTableExists($pdo, 'tblstudent_archive');
    $hasSectionStudent = hrTableExists($pdo, 'tblsectionstudent');
    $hasEnrollment = hrTableExists($pdo, 'tblenrollment');

    $unionParts = [];
    $unionParams = [];
    if ($hasSectionStudent) {
        $unionParts[] = "SELECT student_id, academic_year_id FROM tblsectionstudent WHERE academic_year_id = ?";
        $unionParams[] = $yearId;
    }
    if ($hasEnrollment) {
        $unionParts[] = "SELECT student_id, academic_year_id FROM tblenrollment WHERE academic_year_id = ?";
        $unionParams[] = $yearId;
    }
    if ($hasArchive) {
        $unionParts[] = "SELECT student_id, academic_year_id FROM tblstudent_archive WHERE academic_year_id = ?";
        $unionParams[] = $yearId;
    }

    $gradeLevels = $pdo->query("
        SELECT id, grade_level_name FROM tblgradelevel ORDER BY sort_order ASC, id ASC
    ")->fetchAll(PDO::FETCH_ASSOC);

    $sections = [];
    if ($hasSectionStudent && $yearId) {
        $secStmt = $pdo->prepare("
            SELECT DISTINCT sec.id, sec.section_name
            FROM tblsectionstudent ss
            JOIN tblsection sec ON sec.id = ss.section_id
            WHERE ss.academic_year_id = ?
            ORDER BY sec.section_name ASC
        ");
        $secStmt->execute([$yearId]);
        $sections = $secStmt->fetchAll(PDO::FETCH_ASSOC);
    }

    if (!$unionParts || !$yearId) {
        echo json_encode([
            'success' => true,
            'records' => [],
            'page' => 1,
            'pages' => 1,
            'total' => 0,
            'all_years' => $allYears,
            'grade_levels' => $gradeLevels,
            'sections' => $sections,
            'selected_year' => $selectedYear,
        ]);
        exit;
    }

    $srcSql = implode(' UNION ', $unionParts);

    $where = ['src.academic_year_id = ?'];
    $params = array_merge($unionParams, [$yearId]);

    if ($search !== '') {
        $where[] = '(
            LOWER(s.lrn) LIKE ?
            OR LOWER(s.fname) LIKE ?
            OR LOWER(s.mname) LIKE ?
            OR LOWER(s.lname) LIKE ?
            OR LOWER(CONCAT_WS(\' \', s.fname, NULLIF(s.mname, \'\'), s.lname)) LIKE ?
        )';
        $like = '%' . mb_strtolower($search, 'UTF-8') . '%';
        array_push($params, $like, $like, $like, $like, $like);
    }

    $archiveJoin = $hasArchive
        ? 'LEFT JOIN tblstudent_archive sa ON sa.student_id = src.student_id AND sa.academic_year_id = src.academic_year_id'
        : 'LEFT JOIN (SELECT NULL AS id, NULL AS student_id, NULL AS academic_year_id, NULL AS grade_level_id, NULL AS status, NULL AS final_average) sa ON 1=0';
    $enrollJoin = $hasEnrollment
        ? 'LEFT JOIN tblenrollment e ON e.student_id = src.student_id AND e.academic_year_id = src.academic_year_id'
        : 'LEFT JOIN (SELECT NULL AS student_id, NULL AS academic_year_id, NULL AS grade_level_id, NULL AS enrollment_status) e ON 1=0';
    $sectionJoin = $hasSectionStudent
        ? 'LEFT JOIN tblsectionstudent ss ON ss.student_id = src.student_id AND ss.academic_year_id = src.academic_year_id'
        : 'LEFT JOIN (SELECT NULL AS student_id, NULL AS academic_year_id, NULL AS section_id) ss ON 1=0';

    if ($gradeId !== '' && $gradeId !== 'all') {
        $where[] = 'COALESCE(sa.grade_level_id, e.grade_level_id, sec.grade_level_id, s.grade_level_id) = ?';
        $params[] = (int) $gradeId;
    }
    if ($sectionId !== '' && $sectionId !== 'all') {
        $where[] = 'sec.id = ?';
        $params[] = (int) $sectionId;
    }
    if ($status !== '' && $status !== 'ALL') {
        $where[] = "UPPER(COALESCE(sa.status, e.enrollment_status, 'ARCHIVED')) = ?";
        $params[] = $status;
    }

    $whereStr = implode(' AND ', $where);
    $fromSql = "
        FROM ($srcSql) src
        JOIN tblstudents s ON s.id = src.student_id
        $archiveJoin
        $enrollJoin
        $sectionJoin
        LEFT JOIN tblsection sec ON sec.id = ss.section_id
        LEFT JOIN tblsectionadviser sad ON sad.section_id = sec.id AND sad.academic_year_id = src.academic_year_id
        LEFT JOIN tblteacher t ON t.id = sad.teacher_id
        LEFT JOIN tblgradelevel gl ON gl.id = COALESCE(sa.grade_level_id, e.grade_level_id, sec.grade_level_id, s.grade_level_id)
        WHERE $whereStr
    ";

    $countStmt = $pdo->prepare("SELECT COUNT(DISTINCT s.id) $fromSql");
    $countStmt->execute($params);
    $total = (int) $countStmt->fetchColumn();
    $pages = max(1, (int) ceil($total / $limit));
    if ($page > $pages) {
        $page = $pages;
        $offset = ($page - 1) * $limit;
    }

    $listSql = "
        SELECT
            s.id AS student_id,
            s.lrn,
            s.fname,
            s.mname,
            s.lname,
            MAX(gl.grade_level_name) AS grade_level_name,
            MAX(sec.section_name) AS section_name,
            MAX(TRIM(CONCAT(COALESCE(t.fname, ''), ' ', COALESCE(t.lname, '')))) AS adviser_name,
            MAX(COALESCE(sa.status, e.enrollment_status, 'ARCHIVED')) AS status,
            MAX(sa.id) AS archive_id,
            MAX(sa.final_average) AS final_average,
            MAX(src.academic_year_id) AS academic_year_id
        $fromSql
        GROUP BY s.id, s.lrn, s.fname, s.mname, s.lname
        ORDER BY s.lname ASC, s.fname ASC
        LIMIT $limit OFFSET $offset
    ";
    $listStmt = $pdo->prepare($listSql);
    $listStmt->execute($params);
    $records = $listStmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'records' => $records,
        'page' => $page,
        'pages' => $pages,
        'total' => $total,
        'all_years' => $allYears,
        'grade_levels' => $gradeLevels,
        'sections' => $sections,
        'selected_year' => $selectedYear,
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
