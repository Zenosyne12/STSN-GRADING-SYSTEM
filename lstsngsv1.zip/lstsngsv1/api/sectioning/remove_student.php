<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = (int)($data['id'] ?? 0);

    if ($id <= 0) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'Bad ID'
        ]);
        exit;
    }

    $stmt = $pdo->prepare("DELETE FROM tblsectionstudent WHERE id = ?");
    $stmt->execute([$id]);

    echo json_encode([
        'success' => $stmt->rowCount() > 0
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}