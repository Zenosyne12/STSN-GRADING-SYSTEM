<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = (int)($data['id'] ?? 0);

    if ($id <= 0) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'Bad ID'
        ]);
        exit;
    }

    $removedRow = null;
    try {
        $rmFetch = $pdo->prepare("SELECT section_id, student_id FROM tblsectionstudent WHERE id = ? LIMIT 1");
        $rmFetch->execute([$id]);
        $removedRow = $rmFetch->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) {}

    $stmt = $pdo->prepare("DELETE FROM tblsectionstudent WHERE id = ?");
    $stmt->execute([$id]);

    try {
        if ($stmt->rowCount() > 0) {
            $secId = (int)($removedRow['section_id'] ?? 0);
            $stuId = (int)($removedRow['student_id'] ?? 0);
            logActivity($pdo, 'Sections', 'UPDATE', 'section', $secId ?: null,
                'Removed student from section');
        }
    } catch (Throwable $e) {}

    echo json_encode([
        'success' => $stmt->rowCount() > 0
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}