<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $gradeLevelId = (int)($_GET['grade_level_id'] ?? 0);
    $excludeSectionId = (int)($_GET['exclude_section_id'] ?? 0);

    if ($gradeLevelId <= 0) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'Grade level ID is required'
        ]);
        exit;
    }

    $sql = "
        SELECT
            s.id,
            s.section_name,
            s.is_active,
            COUNT(DISTINCT ss.student_id) AS total_students
        FROM tblsection s
        LEFT JOIN tblsectionstudent ss
            ON ss.section_id = s.id
           AND ss.is_active = 1
        WHERE s.grade_level_id = ?
          AND s.is_active = 1
    ";

    $params = [$gradeLevelId];

    if ($excludeSectionId > 0) {
        $sql .= " AND s.id != ?";
        $params[] = $excludeSectionId;
    }

    $sql .= "
        GROUP BY s.id, s.section_name, s.is_active
        ORDER BY s.section_name ASC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    echo json_encode([
        'success' => true,
        'sections' => $stmt->fetchAll(PDO::FETCH_ASSOC)
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>