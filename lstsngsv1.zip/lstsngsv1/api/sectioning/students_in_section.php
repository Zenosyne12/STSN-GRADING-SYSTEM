<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $sectionId = (int)($_GET['section_id'] ?? 0);
    $academicYearId = (int)($_GET['academic_year_id'] ?? 0);
    $search = trim($_GET['s'] ?? '');

    if ($sectionId <= 0 || $academicYearId <= 0) {
        echo json_encode(['students' => []]);
        exit;
    }

    $colsStmt = $pdo->query("SHOW COLUMNS FROM tblstudents");
    $columns = $colsStmt->fetchAll(PDO::FETCH_COLUMN);

    $fnameCol = in_array('fname', $columns, true) ? 'fname' : (in_array('firstname', $columns, true) ? 'firstname' : null);
    $mnameCol = in_array('mname', $columns, true) ? 'mname' : (in_array('middlename', $columns, true) ? 'middlename' : null);
    $lnameCol = in_array('lname', $columns, true) ? 'lname' : (in_array('lastname', $columns, true) ? 'lastname' : null);

    $studentNoCol = null;
    foreach (['student_no', 'lrn', 'school_id'] as $candidate) {
        if (in_array($candidate, $columns, true)) {
            $studentNoCol = $candidate;
            break;
        }
    }

    $sexCol = null;
    foreach (['sex', 'gender', 'student_gender'] as $candidate) {
        if (in_array($candidate, $columns, true)) {
            $sexCol = $candidate;
            break;
        }
    }

    if (!$fnameCol || !$lnameCol) {
        throw new Exception('Could not detect student name columns in tblstudents');
    }

    $studentIdentifierExpr = $studentNoCol ? "st.`$studentNoCol`" : "st.id";
    $middleExpr = $mnameCol ? "
        CASE
            WHEN COALESCE(st.`$mnameCol`, '') = '' THEN ''
            ELSE CONCAT(' ', LEFT(st.`$mnameCol`, 1), '.')
        END
    " : "''";

    $sexExpr = $sexCol ? "st.`$sexCol`" : "NULL";

    $sql = "
        SELECT
            ss.id AS section_student_id,
            st.id,
            $studentIdentifierExpr AS student_identifier,
            CONCAT(
                st.`$lnameCol`,
                ', ',
                st.`$fnameCol`,
                $middleExpr
            ) AS full_name,
            $sexExpr AS sex
        FROM tblsectionstudent ss
        INNER JOIN tblstudents st ON st.id = ss.student_id
        WHERE ss.section_id = :section_id
          AND ss.academic_year_id = :academic_year_id
          AND ss.is_active = 1
    ";

    $params = [
        ':section_id' => $sectionId,
        ':academic_year_id' => $academicYearId
    ];

    if ($search !== '') {
        $sql .= " AND (
            st.`$lnameCol` LIKE :s
            OR st.`$fnameCol` LIKE :s";

        if ($mnameCol) {
            $sql .= " OR st.`$mnameCol` LIKE :s";
        }

        if ($studentNoCol) {
            $sql .= " OR st.`$studentNoCol` LIKE :s";
        }

        if ($sexCol) {
            $sql .= " OR st.`$sexCol` LIKE :s";
        }

        $sql .= ")";
        $params[':s'] = "%{$search}%";
    }

    $sql .= " ORDER BY st.`$lnameCol` ASC, st.`$fnameCol` ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    echo json_encode([
        'students' => $stmt->fetchAll(PDO::FETCH_ASSOC)
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'students' => [],
        'error' => $e->getMessage()
    ]);
}
?>