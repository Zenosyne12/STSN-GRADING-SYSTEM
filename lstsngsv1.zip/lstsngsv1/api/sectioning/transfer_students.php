<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $sourceSectionId = (int)($data['source_section_id'] ?? 0);
    $targetSectionId = (int)($data['target_section_id'] ?? 0);
    $academicYearId = (int)($data['academic_year_id'] ?? 0);
    $studentIds = $data['student_ids'] ?? [];

    if ($sourceSectionId <= 0 || $targetSectionId <= 0 || $academicYearId <= 0) {
        http_response_code(422);
        echo json_encode([
            'success' => false,
            'error' => 'Source section, target section, and academic year are required'
        ]);
        exit;
    }

    if (empty($studentIds) || !is_array($studentIds)) {
        http_response_code(422);
        echo json_encode([
            'success' => false,
            'error' => 'No students selected for transfer'
        ]);
        exit;
    }

    // Verify both sections have the same grade level
    $verifyStmt = $pdo->prepare("
        SELECT grade_level_id FROM tblsection WHERE id IN (?, ?)
    ");
    $verifyStmt->execute([$sourceSectionId, $targetSectionId]);
    $gradeLevels = $verifyStmt->fetchAll(PDO::FETCH_COLUMN);
    
    if (count($gradeLevels) !== 2 || $gradeLevels[0] !== $gradeLevels[1]) {
        http_response_code(422);
        echo json_encode([
            'success' => false,
            'error' => 'Sections must have the same grade level for transfer'
        ]);
        exit;
    }

    // Begin transaction
    $pdo->beginTransaction();
    
    $transferred = 0;
    $errors = [];

    foreach ($studentIds as $sectionStudentId) {
        $id = (int)$sectionStudentId;
        
        try {
            // Get student_id from section_student record
            $getStudent = $pdo->prepare("
                SELECT student_id FROM tblsectionstudent 
                WHERE id = ? AND section_id = ? AND academic_year_id = ? AND is_active = 1
            ");
            $getStudent->execute([$id, $sourceSectionId, $academicYearId]);
            $studentId = $getStudent->fetchColumn();
            
            if (!$studentId) {
                $errors[] = "Student record $id not found";
                continue;
            }
            
            // Check if student already exists in target section
            $checkDup = $pdo->prepare("
                SELECT id FROM tblsectionstudent 
                WHERE student_id = ? AND section_id = ? AND academic_year_id = ? AND is_active = 1
            ");
            $checkDup->execute([$studentId, $targetSectionId, $academicYearId]);
            if ($checkDup->fetch()) {
                $errors[] = "Student already exists in target section";
                continue;
            }
            
            // Deactivate from source section
            $deactivate = $pdo->prepare("
                UPDATE tblsectionstudent 
                SET is_active = 0, updated_at = NOW() 
                WHERE id = ?
            ");
            $deactivate->execute([$id]);
            
            // Insert into target section
            $insert = $pdo->prepare("
                INSERT INTO tblsectionstudent (section_id, student_id, academic_year_id, is_active, created_at, updated_at)
                VALUES (?, ?, ?, 1, NOW(), NOW())
            ");
            $insert->execute([$targetSectionId, $studentId, $academicYearId]);
            
            $transferred++;
            
        } catch (Exception $e) {
            $errors[] = "Error transferring student $id: " . $e->getMessage();
        }
    }
    
    // Commit transaction
    $pdo->commit();

    echo json_encode([
        'success' => true,
        'transferred_count' => $transferred,
        'errors' => $errors,
        'message' => "Successfully transferred $transferred student(s)"
    ]);

} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}