<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $sectionId = (int)($_GET['section_id'] ?? 0);

    if ($sectionId <= 0) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'Invalid section ID'
        ]);
        exit;
    }

    $stmt = $pdo->prepare("
        SELECT
            t.id AS teacher_id,
            CONCAT(
                COALESCE(t.fname, ''),
                CASE
                    WHEN COALESCE(t.fname, '') <> '' AND COALESCE(t.lname, '') <> '' THEN ' '
                    ELSE ''
                END,
                COALESCE(t.lname, '')
            ) AS teacher_name
        FROM tblsectionadviser sa
        LEFT JOIN tblteacher t ON t.id = sa.teacher_id
        WHERE sa.section_id = ?
        ORDER BY sa.id DESC
        LIMIT 1
    ");
    $stmt->execute([$sectionId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'teacher_id' => $row['teacher_id'] ?? null,
        'teacher_name' => $row['teacher_name'] ?? ''
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>