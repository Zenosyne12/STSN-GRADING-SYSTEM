<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $search = trim($_GET['s'] ?? '');
    $gradeLevelId = isset($_GET['grade_level_id']) ? (int)($_GET['grade_level_id'] ?? 0) : 0;

    $sql = "
        SELECT
            s.id,
            s.section_name,
            s.is_active,
            s.grade_level_id,
            g.grade_level_name,
            COALESCE(MAX(CONCAT(t.fname, ' ', t.lname)), '-') AS adviser_name,
            COUNT(DISTINCT CASE WHEN ss.is_active = 1 THEN ss.student_id END) AS total_students
        FROM tblsection s
        LEFT JOIN tblgradelevel g
            ON g.id = s.grade_level_id
        LEFT JOIN tblsectionstudent ss
            ON ss.section_id = s.id
        LEFT JOIN tblsectionadviser sa
            ON sa.section_id = s.id
        LEFT JOIN tblteacher t
            ON t.id = sa.teacher_id
    ";

    $params = [];
    $whereConditions = [];

    if ($search !== '') {
        $whereConditions[] = "(
            s.section_name LIKE :s
            OR g.grade_level_name LIKE :s
            OR CONCAT(t.fname, ' ', t.lname) LIKE :s
        )";
        $params[':s'] = "%{$search}%";
    }

    if ($gradeLevelId > 0) {
        $whereConditions[] = "s.grade_level_id = :grade_level_id";
        $params[':grade_level_id'] = $gradeLevelId;
    }

    if (!empty($whereConditions)) {
        $sql .= " WHERE " . implode(" AND ", $whereConditions);
    }

    $sql .= "
        GROUP BY
            s.id,
            s.section_name,
            s.is_active,
            s.grade_level_id,
            g.grade_level_name
        ORDER BY s.grade_level_id ASC, s.section_name ASC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    echo json_encode([
        'success' => true,
        'sections' => $stmt->fetchAll(PDO::FETCH_ASSOC)
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'sections' => [],
        'error' => $e->getMessage()
    ]);
}
?>