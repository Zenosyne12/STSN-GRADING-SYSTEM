<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $data = json_decode(file_get_contents('php://input'), true);

    $sectionId = (int)($data['section_id'] ?? 0);
    $studentId = (int)($data['student_id'] ?? 0);
    $academicYearId = (int)($data['academic_year_id'] ?? 0);

    if ($sectionId <= 0 || $studentId <= 0 || $academicYearId <= 0) {
        http_response_code(422);
        echo json_encode([
            'success' => false,
            'error' => 'Section, student, and academic year are required'
        ]);
        exit;
    }

    $dup = $pdo->prepare("
        SELECT id
        FROM tblsectionstudent
        WHERE student_id = ?
          AND academic_year_id = ?
          AND is_active = 1
        LIMIT 1
    ");
    $dup->execute([$studentId, $academicYearId]);

    if ($dup->fetch()) {
        http_response_code(422);
        echo json_encode([
            'success' => false,
            'error' => 'Student is already assigned to a section for this academic year'
        ]);
        exit;
    }

    $stmt = $pdo->prepare("
        INSERT INTO tblsectionstudent (section_id, student_id, academic_year_id, is_active)
        VALUES (?, ?, ?, 1)
    ");
    $stmt->execute([$sectionId, $studentId, $academicYearId]);

    echo json_encode(['success' => true]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}