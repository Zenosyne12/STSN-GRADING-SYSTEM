<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : (isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0);

    if ($id <= 0) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'Invalid section ID: ' . ($id ?: 'empty')
        ]);
        exit;
    }

    $stmt = $pdo->prepare("
        SELECT
            s.id,
            s.section_name,
            s.grade_level_id,
            s.is_active,
            s.max_capacity,
            g.grade_level_name,
            COALESCE(s.max_capacity, 40) AS max_capacity,
            (
                SELECT COUNT(*)
                FROM tblsectionstudent ss
                WHERE ss.section_id = s.id
                  AND ss.is_active = 1
                  AND ss.academic_year_id = (
                      SELECT ay.id
                      FROM tblacademicyear ay
                      WHERE ay.is_active = 1
                      ORDER BY ay.id DESC
                      LIMIT 1
                  )
            ) AS current_count,
            (
                SELECT ay.id
                FROM tblacademicyear ay
                WHERE ay.is_active = 1
                ORDER BY ay.id DESC
                LIMIT 1
            ) AS default_academic_year_id
        FROM tblsection s
        LEFT JOIN tblgradelevel g ON g.id = s.grade_level_id
        WHERE s.id = ?
        LIMIT 1
    ");
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'error' => 'Section not found with ID: ' . $id
        ]);
        exit;
    }

    echo json_encode([
        'success' => true,
        'data' => $row
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>