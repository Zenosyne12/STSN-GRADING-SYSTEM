<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once '../../api/shared/db_connect.php';
require_once '../../api/shared/auth_middleware.php';
require_once '../../api/shared/grade_workflow.php';

function ensureGradeReleasesTable(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS tblgrade_releases (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            section_id INT NOT NULL,
            academic_year_id INT NOT NULL,
            quarter TINYINT NOT NULL,
            sent_by INT DEFAULT NULL,
            sent_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_grade_release (section_id, academic_year_id, quarter),
            KEY idx_grade_release_lookup (section_id, academic_year_id, quarter)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
}

$requested_student_id = intval($_GET['student_id'] ?? 0);
$student_id = $requested_student_id > 0 ? $requested_student_id : $authStudentId;
$quarter = intval($_GET['quarter'] ?? 0);
$academic_year_id = intval($_GET['academic_year_id'] ?? 0);

if ($student_id !== $authStudentId) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'You can only view your own grades.']);
    exit;
}

if (!$academic_year_id) {
    $ayStmt = $pdo->query("SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
    $academic_year_id = (int)($ayStmt->fetchColumn() ?: 0);
}

if (!$student_id) {
    echo json_encode(['success' => false, 'error' => 'Missing student_id']);
    exit;
}

if (!$academic_year_id) {
    echo json_encode(['success' => false, 'error' => 'No active academic year found']);
    exit;
}

ensureGradeReleasesTable($pdo);
ensureGradeWorkflowSchema($pdo);

$sectionStmt = $pdo->prepare("
    SELECT DISTINCT section_id
    FROM tblsectionstudent
    WHERE student_id = ?
      AND academic_year_id = ?
      AND is_active = 1
");
$sectionStmt->execute([$student_id, $academic_year_id]);
$studentSectionIds = array_map('intval', $sectionStmt->fetchAll(PDO::FETCH_COLUMN));

if (!$studentSectionIds) {
    $sectionStmt = $pdo->prepare("
        SELECT DISTINCT section_id
        FROM tblgrades
        WHERE student_id = ?
          AND academic_year_id = ?
    ");
    $sectionStmt->execute([$student_id, $academic_year_id]);
    $studentSectionIds = array_map('intval', $sectionStmt->fetchAll(PDO::FETCH_COLUMN));
}

$released_quarters = [];
if ($studentSectionIds) {
    $sectionPlaceholders = implode(',', array_fill(0, count($studentSectionIds), '?'));
    $releaseStmt = $pdo->prepare("
        SELECT DISTINCT quarter
        FROM tblgrade_releases
        WHERE academic_year_id = ?
          AND section_id IN ($sectionPlaceholders)
        ORDER BY quarter
    ");
    $releaseStmt->execute(array_merge([$academic_year_id], $studentSectionIds));
    $released_quarters = array_map('intval', $releaseStmt->fetchAll(PDO::FETCH_COLUMN));
}

$query = "
    SELECT 
        g.id,
        g.quarter,
        g.final_grade,
        g.remarks,
        g.initial_grade,
        sub.subject_name,
        ay.year_label as academic_year
    FROM tblgrades g
    JOIN tblsubjects sub ON sub.id = g.subject_id
    JOIN tblacademicyear ay ON ay.id = g.academic_year_id
    WHERE g.student_id = ?
      AND g.academic_year_id = ?
      AND g.status IN ('approved', 'approved_by_adviser', 'finalized')
      AND g.final_grade > 0
      AND " . officialGradeExistsSql('g') . "
      AND EXISTS (
          SELECT 1
          FROM tblgrade_releases gr
          WHERE gr.section_id = g.section_id
            AND gr.academic_year_id = g.academic_year_id
            AND gr.quarter = g.quarter
      )
";

$params = [$student_id, $academic_year_id];

if ($quarter > 0) {
    $query .= " AND g.quarter = ?";
    $params[] = $quarter;
}

$query .= " ORDER BY sub.subject_name, g.quarter";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$grades = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total = 0;
$count = 0;
foreach ($grades as $g) {
    if ($g['final_grade'] > 0) {
        $total += $g['final_grade'];
        $count++;
    }
}
$average = $count > 0 ? round($total / $count, 2) : 0;

$academicYearStmt = $pdo->prepare("SELECT year_label FROM tblacademicyear WHERE id = ? LIMIT 1");
$academicYearStmt->execute([$academic_year_id]);
$academicYear = (string)($academicYearStmt->fetchColumn() ?: '');

echo json_encode([
    'success' => true,
    'grades' => $grades,
    'released_quarters' => $released_quarters,
    'academic_year' => $academicYear,
    'overall_average' => $average,
    'total_subjects' => $count
]);
