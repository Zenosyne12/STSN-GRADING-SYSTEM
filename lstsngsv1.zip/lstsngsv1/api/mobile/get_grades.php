<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

require_once '../../api/shared/db_connect.php';

$student_id = intval($_GET['student_id'] ?? 0);
$quarter = intval($_GET['quarter'] ?? 0);
$academic_year_id = intval($_GET['academic_year_id'] ?? 1);

if (!$student_id) {
    echo json_encode(['success' => false, 'error' => 'Missing student_id']);
    exit;
}

$query = "
    SELECT 
        g.id,
        g.quarter,
        g.final_grade,
        g.remarks,
        g.initial_grade,
        sub.subject_name,
        ay.year_label as academic_year
    FROM tblgrades g
    JOIN tblsubjects sub ON sub.id = g.subject_id
    JOIN tblacademicyear ay ON ay.id = g.academic_year_id
    WHERE g.student_id = ? AND g.academic_year_id = ?
";

$params = [$student_id, $academic_year_id];

if ($quarter > 0) {
    $query .= " AND g.quarter = ?";
    $params[] = $quarter;
}

$query .= " ORDER BY sub.subject_name, g.quarter";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$grades = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total = 0;
$count = 0;
foreach ($grades as $g) {
    if ($g['final_grade'] > 0) {
        $total += $g['final_grade'];
        $count++;
    }
}
$average = $count > 0 ? round($total / $count, 2) : 0;

echo json_encode([
    'success' => true,
    'grades' => $grades,
    'overall_average' => $average,
    'total_subjects' => $count
]);