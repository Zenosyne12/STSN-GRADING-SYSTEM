<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

require_once '../../api/shared/db_connect.php';

$data     = json_decode(file_get_contents("php://input"), true);
$username = trim($data['username'] ?? '');
$password = trim($data['password'] ?? '');

if (!$username || !$password) {
    echo json_encode(['success' => false, 'error' => 'Missing credentials']);
    exit;
}

$stmt = $pdo->prepare("
    SELECT u.*, s.fname, s.lname, s.mname, s.lrn, s.gender, s.grade_level_id
    FROM tblusers u
    JOIN tblstudents s ON s.id = u.reference_id
    WHERE u.username = ? AND u.role_id = 3 AND u.status = 'Active'
");
$stmt->execute([$username]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user || !password_verify($password, $user['password_hash'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid username or password']);
    exit;
}

// ── Generate token ────────────────────────────────────────────────────────────
$token   = bin2hex(random_bytes(32)); // 64-char random token
$expires = date('Y-m-d H:i:s', strtotime('+30 days'));

$upd = $pdo->prepare("
    UPDATE tblusers SET token = ?, token_expires = ? WHERE id = ?
");
$upd->execute([$token, $expires, $user['id']]);

// ── Response ──────────────────────────────────────────────────────────────────
echo json_encode([
    'success'             => true,
    'token'               => $token,
    'user_id'             => $user['id'],
    'student_id'          => $user['reference_id'],
    'lrn'                 => $user['lrn'],
    'name'                => trim($user['fname'] . ' ' . $user['lname']),
    'fname'               => $user['fname'],
    'mname'               => $user['mname'],
    'lname'               => $user['lname'],
    'grade_level_id'      => $user['grade_level_id'],
    'must_change_password'=> (bool) $user['must_change_password'],
    'username'            => $user['username'],
]);