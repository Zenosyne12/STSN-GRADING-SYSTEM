<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once '../../api/shared/db_connect.php';
require_once '../../api/shared/PasswordValidator.php';

$data            = json_decode(file_get_contents("php://input"), true);
$resetToken      = trim($data['reset_token'] ?? '');
$newPassword     = trim($data['new_password'] ?? '');
$confirmPassword = trim($data['confirm_password'] ?? '');

if (!$resetToken || !$newPassword || !$confirmPassword) {
    echo json_encode(['success' => false, 'error' => 'All fields are required.']);
    exit;
}

if ($newPassword !== $confirmPassword) {
    echo json_encode(['success' => false, 'error' => 'Passwords do not match.']);
    exit;
}

$validation = PasswordValidator::validate($newPassword);
if (!$validation['valid']) {
    echo json_encode(['success' => false, 'error' => implode(' ', $validation['errors'])]);
    exit;
}


$stmt = $pdo->prepare("
    SELECT id FROM tblusers
    WHERE token = ? AND token_expires > NOW() AND status = 'Active' AND role_id = 3
    LIMIT 1
");
$stmt->execute([$resetToken]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo json_encode(['success' => false, 'error' => 'Reset session expired. Please start over.']);
    exit;
}


$newHash = PasswordValidator::hash($newPassword);
$upd = $pdo->prepare("
    UPDATE tblusers
    SET password_hash = ?, must_change_password = 0, token = NULL, token_expires = NULL
    WHERE id = ?
    LIMIT 1
");
$upd->execute([$newHash, $user['id']]);

echo json_encode(['success' => true, 'message' => 'Password reset successfully! Please log in with your new password.']);
