<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once '../../api/shared/db_connect.php';

$data    = json_decode(file_get_contents("php://input"), true);
$userId  = intval($data['user_id'] ?? 0);
$code    = trim($data['code'] ?? '');

if (!$userId || !$code) {
    echo json_encode(['success' => false, 'error' => 'Missing data.']);
    exit;
}

$codeHash = hash('sha256', $code);

$stmt = $pdo->prepare("
    SELECT id FROM tblusers
    WHERE id = ? AND token = ? AND token_expires > NOW() AND status = 'Active' AND role_id = 3
    LIMIT 1
");
$stmt->execute([$userId, $codeHash]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo json_encode(['success' => false, 'error' => 'Invalid or expired code. Please try again.']);
    exit;
}


$resetToken = bin2hex(random_bytes(32));
$expires    = date('Y-m-d H:i:s', strtotime('+5 minutes'));

$upd = $pdo->prepare("UPDATE tblusers SET token = ?, token_expires = ? WHERE id = ?");
$upd->execute([$resetToken, $expires, $userId]);

echo json_encode([
    'success'      => true,
    'reset_token'  => $resetToken,
    'message'      => 'Code verified successfully.',
]);