<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once '../../api/shared/db_connect.php';
require_once __DIR__ . '/../../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function createMailer() {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'hechanova919@gmail.com';
    $mail->Password   = 'rbjslxdcytllregd';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;
    $mail->Timeout    = 12;
    $mail->CharSet    = 'UTF-8';
    $mail->SMTPOptions = ['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true]];
    $mail->setFrom($mail->Username, 'STSN Grading System');
    $mail->isHTML(true);
    return $mail;
}

$data     = json_decode(file_get_contents("php://input"), true);
$username = trim($data['username'] ?? '');

if (!$username) {
    echo json_encode(['success' => false, 'error' => 'Please enter your username.']);
    exit;
}


$stmt = $pdo->prepare("
    SELECT u.id, u.username, s.fname, s.lname, s.email
    FROM tblusers u
    JOIN tblstudents s ON s.id = u.reference_id
    WHERE (u.username = ? OR s.email = ?) AND u.role_id = 3 AND u.status = 'Active'
    LIMIT 1
");
$stmt->execute([$username, $username]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo json_encode(['success' => false, 'error' => 'Username not found or account is inactive.']);
    exit;
}

$email = trim($user['email'] ?? '');
if (!$email) {
    echo json_encode(['success' => false, 'error' => 'No email address on record. Please contact your school administrator.']);
    exit;
}


$code    = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
$expires = date('Y-m-d H:i:s', strtotime('+10 minutes'));


$codeHash = hash('sha256', $code);
$upd = $pdo->prepare("UPDATE tblusers SET token = ?, token_expires = ? WHERE id = ?");
$upd->execute([$codeHash, $expires, $user['id']]);


$fullName = trim($user['fname'] . ' ' . $user['lname']);
try {
    $mail = createMailer();
    $mail->addAddress($email, $fullName);
    $mail->Subject = 'STSN Password Reset Code';
    $mail->Body = '
<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="font-family:Arial,sans-serif;background:#f3f7fd;margin:0;padding:0;">
  <div style="max-width:480px;margin:30px auto;background:#fff;border-radius:14px;border:1px solid #dce8f8;overflow:hidden;">
    <div style="background:linear-gradient(130deg,#6B1A1A,#a02020);padding:24px 28px;color:#fff;">
      <h2 style="margin:0 0 4px;font-size:1.1rem;">STSN Grading System</h2>
      <p style="margin:0;font-size:0.82rem;opacity:.85;">St. Theresa\'s School of Novaliches</p>
    </div>
    <div style="padding:24px 28px;color:#213a5e;">
      <p>Hello, <strong>' . htmlspecialchars($fullName) . '</strong>!</p>
      <p>Use this code to reset your password. It expires in <strong>10 minutes</strong>.</p>
      <div style="text-align:center;margin:24px 0;">
        <div style="background:#f4f8ff;border:2px solid #6B1A1A;border-radius:12px;padding:18px;display:inline-block;">
          <span style="font-size:2.2rem;font-weight:900;letter-spacing:10px;color:#6B1A1A;">' . $code . '</span>
        </div>
      </div>
      <p style="font-size:0.82rem;color:#7a93b8;">If you did not request this, please ignore this email or contact your school administrator.</p>
    </div>
    <div style="background:#f4f8ff;padding:12px 28px;text-align:center;font-size:0.75rem;color:#9ab0c8;border-top:1px solid #e8f0fb;">
      STSN Grading System &mdash; St. Theresa\'s School of Novaliches
    </div>
  </div>
</body></html>';
    $mail->AltBody = "Hello $fullName,\n\nYour password reset code is: $code\n\nThis code expires in 10 minutes.\n\nSTSN Grading System";
    $mail->send();

    
    $parts    = explode('@', $email);
    $masked   = substr($parts[0], 0, 2) . str_repeat('*', max(2, strlen($parts[0]) - 2)) . '@' . $parts[1];

    echo json_encode([
        'success'       => true,
        'message'       => "Verification code sent to $masked",
        'masked_email'  => $masked,
        'user_id'       => $user['id'],
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Failed to send email. Please try again or contact admin.']);
}
