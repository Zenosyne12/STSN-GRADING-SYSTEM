<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once '../../api/shared/db_connect.php';
require_once '../../api/shared/auth_middleware.php';

// $authStudentId is set by auth_middleware — no need for $_GET['student_id']
$stmt = $pdo->prepare("
    SELECT 
        s.*,
        gl.grade_level_name,
        e.enrollment_status,
        ay.year_label as academic_year,
        sec.section_name
    FROM tblstudents s
    LEFT JOIN tblgradelevel gl ON gl.id = s.grade_level_id
    LEFT JOIN tblenrollment e ON e.student_id = s.id AND e.is_active = 1
    LEFT JOIN tblacademicyear ay ON ay.id = e.academic_year_id
    LEFT JOIN tblsectionstudent ss ON ss.student_id = s.id
    LEFT JOIN tblsection sec ON sec.id = ss.section_id
    WHERE s.id = ?
    LIMIT 1
");
$stmt->execute([$authStudentId]);
$profile = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$profile) {
    echo json_encode(['success' => false, 'error' => 'Student not found']);
    exit;
}

echo json_encode([
    'success' => true,
    'profile' => [
        'id'                => $profile['id'],
        'lrn'               => $profile['lrn'],
        'full_name'         => trim($profile['fname'] . ' ' . ($profile['mname'] ? $profile['mname'][0] . '. ' : '') . $profile['lname']),
        'fname'             => $profile['fname'],
        'mname'             => $profile['mname'],
        'lname'             => $profile['lname'],
        'gender'            => $profile['gender'],
        'birthdate'         => $profile['birthdate'],
        'email'             => $profile['email'] ?? null,
        'grade_level'       => $profile['grade_level_name'],
        'section'           => $profile['section_name'] ?? 'N/A',
        'enrollment_status' => $profile['enrollment_status'] ?? 'N/A',
        'academic_year'     => $profile['academic_year'] ?? 'N/A',
    ]
]);