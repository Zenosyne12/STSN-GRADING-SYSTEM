<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once '../../api/shared/db_connect.php';
require_once '../../api/shared/auth_middleware.php';
require_once '../../api/shared/PasswordValidator.php';

$data            = json_decode(file_get_contents("php://input"), true);
$currentPassword = trim($data['current_password'] ?? '');
$newPassword     = trim($data['new_password'] ?? '');
$confirmPassword = trim($data['confirm_password'] ?? '');

if (!$currentPassword || !$newPassword || !$confirmPassword) {
    echo json_encode(['success' => false, 'error' => 'All fields are required.']);
    exit;
}

if ($newPassword !== $confirmPassword) {
    echo json_encode(['success' => false, 'error' => 'New passwords do not match.']);
    exit;
}

$validation = PasswordValidator::validate($newPassword);
if (!$validation['valid']) {
    echo json_encode(['success' => false, 'error' => implode(' ', $validation['errors'])]);
    exit;
}

$stmt = $pdo->prepare("SELECT password_hash FROM tblusers WHERE id = ? AND status = 'Active' LIMIT 1");
$stmt->execute([$authUserId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo json_encode(['success' => false, 'error' => 'User not found.']);
    exit;
}

if (!password_verify($currentPassword, $user['password_hash'])) {
    echo json_encode(['success' => false, 'error' => 'Current password is incorrect.']);
    exit;
}

if ($currentPassword === $newPassword) {
    echo json_encode(['success' => false, 'error' => 'New password must be different from current password.']);
    exit;
}

$newHash = PasswordValidator::hash($newPassword);
$update  = $pdo->prepare("UPDATE tblusers SET password_hash = ?, must_change_password = 0 WHERE id = ? LIMIT 1");
$update->execute([$newHash, $authUserId]);

echo json_encode(['success' => true, 'message' => 'Password changed successfully!']);
