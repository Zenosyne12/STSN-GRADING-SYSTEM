<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

function respond(bool $success, string $message, array $extra = []): void
{
    echo json_encode(array_merge(['success' => $success, 'message' => $message], $extra));
    exit;
}

try {
    $input    = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) throw new Exception('Invalid request payload.');

    $id       = isset($input['id'])        ? (int)$input['id']        : 0;
    $isActive = isset($input['is_active']) ? (int)$input['is_active'] : -1;

    if ($id <= 0)                           throw new Exception('Invalid academic year id.');
    if (!in_array($isActive, [0, 1], true)) throw new Exception('Invalid active state.');

    // Load target year
    $stmt = $pdo->prepare("SELECT id, year_label, is_active FROM tblacademicyear WHERE id = ? LIMIT 1");
    $stmt->execute([$id]);
    $year = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$year) throw new Exception('Academic year not found.');

    // ── DEACTIVATE ────────────────────────────────────────────────────────────
    if ($isActive === 0) {
        $activeCount = (int)$pdo->query("SELECT COUNT(*) FROM tblacademicyear WHERE is_active = 1")->fetchColumn();
        if ((int)$year['is_active'] === 1 && $activeCount <= 1) {
            respond(false, 'You cannot deactivate the only active academic year.');
        }
        $pdo->prepare("UPDATE tblacademicyear SET is_active = 0 WHERE id = ?")->execute([$id]);
        respond(true, 'Academic year deactivated successfully.');
    }

    // ── ACTIVATE ──────────────────────────────────────────────────────────────
    $pdo->beginTransaction();

    // Remember currently active year before switching
    $oldYearId = (int)$pdo->query(
        "SELECT COALESCE(id, 0) FROM tblacademicyear WHERE is_active = 1 LIMIT 1"
    )->fetchColumn();

    // Deactivate all, then activate target
    $pdo->exec("UPDATE tblacademicyear SET is_active = 0");
    $pdo->prepare("UPDATE tblacademicyear SET is_active = 1 WHERE id = ?")->execute([$id]);

    // Also deactivate the active quarter of the old year when switching years
    if ($oldYearId && $oldYearId !== $id) {
        $pdo->exec("UPDATE tblquarters SET is_active = 0 WHERE is_active = 1");
    }

    // ── AUTO-ARCHIVE & AUTO-PROMOTE ───────────────────────────────────────────
    $promoted = 0;
    $retained = 0;
    $skipped  = 0;
    $archived = 0;

    if ($oldYearId && $oldYearId !== $id) {

        // Only run if new year has no enrollments yet
        $alreadySeeded = (int)$pdo->query(
            "SELECT COUNT(*) FROM tblenrollment WHERE academic_year_id = {$id}"
        )->fetchColumn();

        if ($alreadySeeded === 0) {

            // ── STEP 1: Archive all active enrollments from the old year ──────
            //
            // For each enrollment in the old year that is still active:
            //   - Determine the correct archive status based on enrollment_status
            //   - Skip if already archived for this student + year
            //   - Insert into tblstudent_archive
            //   - Mark enrollment as inactive
            //
            $oldEnrollStmt = $pdo->prepare("
                SELECT
                    e.id            AS enrollment_id,
                    e.student_id,
                    e.grade_level_id,
                    e.enrollment_status,
                    gl.sort_order,
                    gl.is_last
                FROM tblenrollment e
                JOIN tblGradeLevel gl ON gl.id = e.grade_level_id
                WHERE e.academic_year_id = ?
                  AND e.is_active        = 1
            ");
            $oldEnrollStmt->execute([$oldYearId]);
            $oldEnrollments = $oldEnrollStmt->fetchAll(PDO::FETCH_ASSOC);

            // Check which student+year combos are already archived (skip duplicates)
            $existingArchiveStmt = $pdo->prepare("
                SELECT student_id FROM tblstudent_archive
                WHERE academic_year_id = ?
            ");
            $existingArchiveStmt->execute([$oldYearId]);
            $alreadyArchived = array_column(
                $existingArchiveStmt->fetchAll(PDO::FETCH_ASSOC),
                'student_id'
            );
            $alreadyArchived = array_flip($alreadyArchived); // for O(1) lookup

            $insertArchive = $pdo->prepare("
                INSERT INTO tblstudent_archive
                    (student_id, academic_year_id, grade_level_id, final_average, status, archived_by)
                VALUES (?, ?, ?, NULL, ?, NULL)
            ");

            $markInactive = $pdo->prepare("
                UPDATE tblenrollment
                SET is_active = 0, enrollment_status = ?
                WHERE id = ?
            ");

            foreach ($oldEnrollments as $e) {
                // Skip if this student + old year is already in the archive
                if (isset($alreadyArchived[$e['student_id']])) {
                    continue;
                }

                // Determine archive status
                $rawStatus = $e['enrollment_status'];

                // Already a terminal status — keep it as-is
                $terminalStatuses = ['DROPPED', 'TRANSFERRED', 'GRADUATED', 'RETAINED'];
                if (in_array($rawStatus, $terminalStatuses, true)) {
                    $archiveStatus = $rawStatus;
                } elseif ((int)$e['is_last'] === 1) {
                    // Last grade level (e.g. Grade 12) → Graduated
                    $archiveStatus = 'GRADUATED';
                } else {
                    // Normal active enrollment → being promoted
                    $archiveStatus = 'PROMOTED';
                }

                // Insert archive record
                $insertArchive->execute([
                    $e['student_id'],
                    $oldYearId,
                    $e['grade_level_id'],
                    $archiveStatus,
                ]);

                // Update enrollment status to match archive status, mark inactive
                $markInactive->execute([$archiveStatus, $e['enrollment_id']]);

                $archived++;
            }

            // ── STEP 2: Promote students into the new year ────────────────────
            //
            // Re-fetch enrollments (statuses may have changed above) for promotion logic.
            //
            $enrollStmt = $pdo->prepare("
                SELECT
                    e.student_id,
                    e.grade_level_id,
                    e.enrollment_status,
                    gl.sort_order,
                    gl.is_last
                FROM tblenrollment e
                JOIN tblGradeLevel gl ON gl.id = e.grade_level_id
                WHERE e.academic_year_id = ?
                  AND e.is_active        = 0
                  AND e.enrollment_status NOT IN ('DROPPED','TRANSFERRED','GRADUATED')
            ");
            $enrollStmt->execute([$oldYearId]);
            $enrollments = $enrollStmt->fetchAll(PDO::FETCH_ASSOC);

            // Pre-fetch all grade levels sorted by sort_order for fast lookup
            $allGrades = $pdo->query(
                "SELECT id, sort_order, is_last FROM tblGradeLevel ORDER BY sort_order ASC"
            )->fetchAll(PDO::FETCH_ASSOC);

            // Build sort_order → id map
            $gradeByOrder = [];
            foreach ($allGrades as $g) {
                $gradeByOrder[(int)$g['sort_order']] = (int)$g['id'];
            }

            $insertStmt = $pdo->prepare("
                INSERT IGNORE INTO tblenrollment
                    (student_id, academic_year_id, grade_level_id, enrollment_status, is_active)
                VALUES (?, ?, ?, 'ENROLLED', 1)
            ");

            foreach ($enrollments as $e) {
                $isRetained = $e['enrollment_status'] === 'RETAINED';
                $isLast     = (int)$e['is_last'] === 1;

                if ($isLast && !$isRetained) {
                    // Already handled as GRADUATED in archive step — skip enrollment
                    $skipped++;
                    continue;
                }

                if ($isRetained) {
                    $newGradeId = (int)$e['grade_level_id'];
                    $retained++;
                } else {
                    $nextOrder  = (int)$e['sort_order'] + 1;
                    $newGradeId = $gradeByOrder[$nextOrder] ?? 0;
                    if (!$newGradeId) { $skipped++; continue; }
                    $promoted++;
                }

                $insertStmt->execute([$e['student_id'], $id, $newGradeId]);
            }
        }
    }

    $pdo->commit();

    $msg = "Academic year \"{$year['year_label']}\" activated successfully.";
    if ($archived)  $msg .= " Archived: {$archived} records from previous year.";
    if ($promoted)  $msg .= " Promoted: {$promoted}.";
    if ($retained)  $msg .= " Retained: {$retained}.";
    if ($skipped)   $msg .= " Graduated/Skipped: {$skipped}.";

    respond(true, $msg, [
        'archived' => $archived,
        'promoted' => $promoted,
        'retained' => $retained,
        'skipped'  => $skipped,
    ]);

} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    respond(false, $e->getMessage());
}