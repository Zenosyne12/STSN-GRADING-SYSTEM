<?php
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();
if (!in_array((int) ($_SESSION['role_id'] ?? 0), [1, 4], true)) {
    jsonAuthError(403, 'Administrator access is required.');
}
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/promotion_service.php';

header('Content-Type: application/json');

function respond(bool $success, string $message, array $extra = []): void
{
    echo json_encode(array_merge(['success' => $success, 'message' => $message], $extra));
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) {
        throw new InvalidArgumentException('Invalid request payload.');
    }

    $yearId = isset($input['id']) ? (int) $input['id'] : 0;
    $isActive = isset($input['is_active']) ? (int) $input['is_active'] : -1;
    if ($yearId <= 0 || !in_array($isActive, [0, 1], true)) {
        throw new InvalidArgumentException('Invalid academic year or active state.');
    }

    $yearStmt = $pdo->prepare("
        SELECT id, year_label, is_active, archived_at
        FROM tblacademicyear
        WHERE id = ?
        LIMIT 1
    ");
    $yearStmt->execute([$yearId]);
    $year = $yearStmt->fetch(PDO::FETCH_ASSOC);
    if (!$year || $year['archived_at'] !== null) {
        throw new RuntimeException('Academic year not found or archived.');
    }

    if ($isActive === 0) {
        $activeCount = (int) $pdo->query("SELECT COUNT(*) FROM tblacademicyear WHERE is_active = 1")->fetchColumn();
        if ((int) $year['is_active'] === 1 && $activeCount <= 1) {
            respond(false, 'You cannot deactivate the only active academic year.');
        }
        $pdo->prepare("UPDATE tblacademicyear SET is_active = 0 WHERE id = ?")->execute([$yearId]);
        respond(true, 'Academic year deactivated successfully.');
    }

    if ((int) $year['is_active'] === 1) {
        respond(false, 'Academic year is already active.');
    }

    $oldYearId = (int) $pdo->query(
        "SELECT id FROM tblacademicyear WHERE is_active = 1 AND archived_at IS NULL LIMIT 1"
    )->fetchColumn();
    if ($oldYearId === $yearId) {
        respond(false, 'Academic year is already active.');
    }

    if ($oldYearId > 0) {
        ensurePromotionSchema($pdo);
    }

    $pdo->beginTransaction();
    $promotion = [
        'promoted' => 0,
        'retained' => 0,
        'graduated' => 0,
        'pending_review' => 0,
        'dropped' => 0,
        'transferred' => 0,
        'archived' => 0,
    ];

    if ($oldYearId > 0) {
        $preview = previewAcademicYearPromotion($pdo, $oldYearId, $yearId);
        $promotion = $preview['summary'] + ['archived' => 0];
        if ($promotion['pending_review'] > 0) {
            storePromotionClassifications($pdo, $oldYearId, $preview);
            $pdo->commit();
            respond(false, 'Promotion review is required before activating this academic year.', [
                'pending_review' => $promotion['pending_review'],
                'redirect' => 'Promotion-Review.php?old_year_id=' . $oldYearId . '&new_year_id=' . $yearId,
            ]);
        }
    }

    $pdo->exec("UPDATE tblacademicyear SET is_active = 0 WHERE is_active = 1");
    $pdo->prepare("UPDATE tblacademicyear SET is_active = 1 WHERE id = ?")->execute([$yearId]);
    $pdo->exec("UPDATE tblconfig_terms SET is_active = 0 WHERE is_active = 1");

    if ($oldYearId > 0) {
        $pdo->exec("UPDATE tblquarters SET is_active = 0 WHERE is_active = 1");
        $promotion = runAcademicYearPromotion(
            $pdo,
            $oldYearId,
            $yearId,
            (int) ($_SESSION['user_id'] ?? 0) ?: null
        );
        if ($promotion['pending_review'] > 0) {
            throw new RuntimeException('Promotion review became pending during activation.');
        }
    }

    $pdo->commit();

    $message = 'Academic year "' . $year['year_label'] . '" activated successfully.';
    foreach (['promoted', 'retained', 'graduated', 'dropped', 'transferred'] as $key) {
        if (!empty($promotion[$key])) {
            $message .= ' ' . ucfirst($key) . ': ' . (int) $promotion[$key] . '.';
        }
    }

    respond(true, $message, $promotion);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    respond(false, $e->getMessage());
}
