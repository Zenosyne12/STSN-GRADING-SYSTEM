<?php
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();
if (!in_array((int) ($_SESSION['role_id'] ?? 0), [1, 4], true)) {
    jsonAuthError(403, 'Administrator access is required.');
}
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

try {
    $yearId = filter_input(INPUT_GET, 'academic_year_id', FILTER_VALIDATE_INT);
    if (!$yearId || $yearId < 1) {
        throw new InvalidArgumentException('A valid academic_year_id is required.');
    }
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM tblenrollment
        WHERE academic_year_id = ? AND is_active = 1
          AND promotion_decision = 'PENDING_REVIEW'
    ");
    $stmt->execute([$yearId]);
    echo json_encode(['success' => true, 'pending_count' => (int) $stmt->fetchColumn()]);
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
