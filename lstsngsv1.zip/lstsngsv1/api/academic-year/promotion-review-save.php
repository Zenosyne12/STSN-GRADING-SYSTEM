<?php
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();
if (!in_array((int) ($_SESSION['role_id'] ?? 0), [1, 4], true)) {
    jsonAuthError(403, 'Administrator access is required.');
}
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

try {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) {
        throw new InvalidArgumentException('Invalid request payload.');
    }
    $yearId = filter_var($input['academic_year_id'] ?? null, FILTER_VALIDATE_INT);
    $reviewMode = ($input['mode'] ?? 'newyear') === 'archive' ? 'archive' : 'newyear';
    $decisions = $input['decisions'] ?? null;
    $reviewedBy = (int) ($_SESSION['user_id'] ?? 0);

    if (!$yearId || $yearId < 1 || !is_array($decisions) || $decisions === []) {
        throw new InvalidArgumentException('Academic year and at least one decision are required.');
    }
    if ($reviewedBy < 1) {
        throw new RuntimeException('The current user could not be identified.');
    }

    $validated = [];
    foreach ($decisions as $item) {
        if (!is_array($item)) {
            throw new InvalidArgumentException('Each decision must include an enrollment_id and decision.');
        }
        $enrollmentId = filter_var($item['enrollment_id'] ?? null, FILTER_VALIDATE_INT);
        $decision = strtoupper(trim((string) ($item['decision'] ?? '')));
        if (!$enrollmentId || $enrollmentId < 1 || !in_array($decision, ['PROMOTED', 'RETAINED'], true)) {
            throw new InvalidArgumentException('Invalid enrollment ID or review decision.');
        }
        if (isset($validated[$enrollmentId])) {
            throw new InvalidArgumentException('Duplicate enrollment decisions are not allowed.');
        }
        $validated[$enrollmentId] = $decision;
    }

    $pdo->beginTransaction();
    $yearStmt = $pdo->prepare('SELECT is_active, archived_at FROM tblacademicyear WHERE id = ? LIMIT 1');
    $yearStmt->execute([$yearId]);
    $year = $yearStmt->fetch(PDO::FETCH_ASSOC);
    $validYear = $reviewMode === 'archive'
        ? $year && (int) $year['is_active'] === 0 && $year['archived_at'] !== null
        : $year && (int) $year['is_active'] === 1 && $year['archived_at'] === null;
    if (!$validYear) {
        throw new RuntimeException($reviewMode === 'archive'
            ? 'Promotion reviews can only be saved for an archived academic year.'
            : 'Promotion reviews can only be saved for the currently active academic year.');
    }

    $enrollmentStateFilter = $reviewMode === 'archive' ? '' : ' AND is_active = 1';
    $update = $pdo->prepare("
        UPDATE tblenrollment
        SET promotion_decision = ?, reviewed_by = ?, reviewed_at = NOW()
        WHERE id = ? AND academic_year_id = ?{$enrollmentStateFilter}
          AND promotion_decision = 'PENDING_REVIEW'
    ");
    $savedDecision = $pdo->prepare("
        SELECT promotion_decision
        FROM tblenrollment
        WHERE id = ? AND academic_year_id = ?{$enrollmentStateFilter}
        LIMIT 1
    ");
    $updateArchiveStatus = $reviewMode === 'archive'
        ? $pdo->prepare("
            UPDATE tblstudent_archive sa
            JOIN tblenrollment e
              ON e.student_id = sa.student_id
             AND e.academic_year_id = sa.academic_year_id
            SET sa.status = ?
            WHERE e.id = ? AND e.academic_year_id = ?
        ")
        : null;
    foreach ($validated as $enrollmentId => $decision) {
        $update->execute([$decision, $reviewedBy, $enrollmentId, $yearId]);
        if ($update->rowCount() !== 1) {
            if ($reviewMode !== 'archive') {
                throw new RuntimeException("Enrollment {$enrollmentId} is not awaiting review for this year.");
            }
            $savedDecision->execute([$enrollmentId, $yearId]);
            if ($savedDecision->fetchColumn() !== $decision) {
                throw new RuntimeException("Enrollment {$enrollmentId} is not awaiting this review decision.");
            }
        }
        if ($updateArchiveStatus) {
            $updateArchiveStatus->execute([$decision, $enrollmentId, $yearId]);
        }
    }

    $pendingStmt = $pdo->prepare("
        SELECT COUNT(*) FROM tblenrollment
        WHERE academic_year_id = ?{$enrollmentStateFilter}
          AND promotion_decision = 'PENDING_REVIEW'
    ");
    $pendingStmt->execute([$yearId]);
    $remaining = (int) $pendingStmt->fetchColumn();
    $pdo->commit();

    echo json_encode(['success' => true, 'remaining_pending' => $remaining]);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
