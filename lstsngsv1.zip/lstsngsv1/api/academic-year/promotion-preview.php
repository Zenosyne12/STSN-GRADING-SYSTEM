<?php
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();
if (!in_array((int) ($_SESSION['role_id'] ?? 0), [1, 4], true)) {
    jsonAuthError(403, 'Administrator access is required.');
}
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/promotion_service.php';

header('Content-Type: application/json');

try {
    $mode = ($_GET['mode'] ?? 'newyear') === 'archive' ? 'archive' : 'newyear';
    if ($mode === 'archive') {
        $oldYearId = filter_input(INPUT_GET, 'academic_year_id', FILTER_VALIDATE_INT);
        if (!$oldYearId || $oldYearId < 1) {
            throw new InvalidArgumentException('A valid academic_year_id is required.');
        }
        $yearStmt = $pdo->prepare("
            SELECT id
            FROM tblacademicyear
            WHERE id = ? AND is_active = 0 AND archived_at IS NOT NULL
            LIMIT 1
        ");
        $yearStmt->execute([$oldYearId]);
        if (!$yearStmt->fetchColumn()) {
            throw new InvalidArgumentException('The selected year is not archived and available for promotion review.');
        }
        $newYearId = null;
    } else {
        $oldYearId = filter_input(INPUT_GET, 'old_year_id', FILTER_VALIDATE_INT);
        $newYearId = filter_input(INPUT_GET, 'new_year_id', FILTER_VALIDATE_INT);
        if (!$oldYearId || !$newYearId || $oldYearId === $newYearId) {
            throw new InvalidArgumentException('Valid old_year_id and new_year_id are required.');
        }

        $yearStmt = $pdo->prepare("
            SELECT id, is_active, archived_at
            FROM tblacademicyear
            WHERE id IN (?, ?)
        ");
        $yearStmt->execute([$oldYearId, $newYearId]);
        $years = $yearStmt->fetchAll(PDO::FETCH_UNIQUE | PDO::FETCH_ASSOC);
        if (count($years) !== 2 || (int) $years[$oldYearId]['is_active'] !== 1
            || $years[$oldYearId]['archived_at'] !== null
            || (int) $years[$newYearId]['is_active'] !== 0 || $years[$newYearId]['archived_at'] !== null) {
            throw new InvalidArgumentException('The selected years are not a valid active-to-inactive promotion pair.');
        }
    }

    $preview = previewAcademicYearPromotion(
        $pdo,
        (int) $oldYearId,
        $newYearId ? (int) $newYearId : null,
        $mode === 'archive'
    );
    $pendingStudents = array_values(array_map(
        static function (array $student): array {
            return [
                'enrollment_id' => $student['enrollment_id'],
                'student_name' => $student['student_name'],
                'grade_level' => $student['grade_level'],
                'failed_count' => $student['failed_count'],
                'failed_subjects' => implode(', ', $student['failed_subjects']),
            ];
        },
        array_filter($preview['students'], static fn(array $student): bool => $student['decision'] === 'PENDING_REVIEW')
    ));

    echo json_encode([
        'success' => true,
        'summary' => $preview['summary'],
        'pending_students' => $pendingStudents,
    ]);
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
