<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
    $year = $stmt ? $stmt->fetchColumn() : '';

    echo json_encode([
        'success' => true,
        'year_label' => $year ?: ''
    ]);
} catch (Throwable $e) {
    echo json_encode([
        'success' => false,
        'year_label' => '',
        'message' => $e->getMessage()
    ]);
}