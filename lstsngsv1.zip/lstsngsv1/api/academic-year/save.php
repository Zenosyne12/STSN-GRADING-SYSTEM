<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

function respond(bool $success, string $message, array $extra = []): void
{
    echo json_encode(array_merge(['success' => $success, 'message' => $message], $extra));
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!is_array($input)) {
        throw new Exception('Invalid request payload.');
    }

    $id        = isset($input['id']) && $input['id'] !== '' ? (int)$input['id'] : 0;
    $yearLabel = isset($input['year_label']) ? trim($input['year_label']) : '';

    if ($yearLabel === '') {
        throw new Exception('Academic year is required.');
    }

    // Validate format: YYYY-YYYY
    if (!preg_match('/^\d{4}-\d{4}$/', $yearLabel)) {
        throw new Exception('Invalid year format. Expected YYYY-YYYY.');
    }

    if ($id > 0) {
        // Update
        $check = $pdo->prepare("SELECT COUNT(*) FROM tblacademicyear WHERE year_label = ? AND id <> ?");
        $check->execute([$yearLabel, $id]);
        if ((int)$check->fetchColumn() > 0) {
            throw new Exception('Academic year already exists.');
        }

        $pdo->prepare("UPDATE tblacademicyear SET year_label = ? WHERE id = ?")
            ->execute([$yearLabel, $id]);

        respond(true, 'Academic year updated successfully.');
    }

    // Insert
    $check = $pdo->prepare("SELECT COUNT(*) FROM tblacademicyear WHERE year_label = ?");
    $check->execute([$yearLabel]);
    if ((int)$check->fetchColumn() > 0) {
        throw new Exception('Academic year already exists.');
    }

    $pdo->prepare("INSERT INTO tblacademicyear (year_label, is_active) VALUES (?, 0)")
        ->execute([$yearLabel]);

    $newId = (int)$pdo->lastInsertId();

    // Auto-create 4 quarters for the new year
    $quarterLabels = ['1st', '2nd', '3rd', '4th'];
    $insertQ = $pdo->prepare("
        INSERT INTO tblquarters (academic_year_id, quarter_number, quarter_label, is_active, is_closed)
        VALUES (?, ?, ?, 0, 0)
    ");
    foreach ($quarterLabels as $num => $label) {
        $insertQ->execute([$newId, $num + 1, $label]);
    }

    respond(true, 'Academic year added successfully. 4 quarters have been created.');
} catch (Throwable $e) {
    respond(false, $e->getMessage());
}