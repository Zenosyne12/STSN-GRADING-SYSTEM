<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

function respond(bool $success, string $message, array $extra = []): void
{
    echo json_encode(array_merge(['success' => $success, 'message' => $message], $extra));
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!is_array($input)) {
        throw new Exception('Invalid request payload.');
    }

    $id            = isset($input['id']) && $input['id'] !== '' ? (int)$input['id'] : 0;
    $yearLabel     = isset($input['year_label']) ? trim($input['year_label']) : '';
    $startDate     = isset($input['start_date']) ? trim($input['start_date']) : '';
    $endDate       = isset($input['end_date']) ? trim($input['end_date']) : '';
    $termStructure = isset($input['term_structure']) ? trim($input['term_structure']) : 'trimester';

    // Validation
    if ($yearLabel === '') {
        throw new Exception('Academic year is required.');
    }

    if (!preg_match('/^\d{4}-\d{4}$/', $yearLabel)) {
        throw new Exception('Invalid year format. Expected YYYY-YYYY.');
    }

    if ($startDate === '') {
        throw new Exception('Start date is required.');
    }

    if ($endDate === '') {
        throw new Exception('End date is required.');
    }

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $startDate)) {
        throw new Exception('Invalid start date format. Expected YYYY-MM-DD.');
    }

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $endDate)) {
        throw new Exception('Invalid end date format. Expected YYYY-MM-DD.');
    }

    if ($endDate < $startDate) {
        throw new Exception('End date cannot be earlier than start date.');
    }

    $allowed = ['trimester', 'semestral'];
    if (!in_array($termStructure, $allowed)) {
        throw new Exception('Invalid term structure. Must be trimester or semestral.');
    }

    // UPDATE existing year
    if ($id > 0) {
        $check = $pdo->prepare("SELECT COUNT(*) FROM tblacademicyear WHERE year_label = ? AND id <> ?");
        $check->execute([$yearLabel, $id]);
        if ((int)$check->fetchColumn() > 0) {
            throw new Exception('Academic year already exists.');
        }

        $pdo->prepare("
            UPDATE tblacademicyear 
            SET year_label = ?, start_date = ?, end_date = ?, term_structure = ? 
            WHERE id = ?
        ")->execute([$yearLabel, $startDate, $endDate, $termStructure, $id]);

        respond(true, 'Academic year updated successfully.');
    }

    // CREATE new year
    $check = $pdo->prepare("SELECT COUNT(*) FROM tblacademicyear WHERE year_label = ?");
    $check->execute([$yearLabel]);
    if ((int)$check->fetchColumn() > 0) {
        throw new Exception('Academic year already exists.');
    }

    $pdo->prepare("
        INSERT INTO tblacademicyear (year_label, start_date, end_date, term_structure, is_active) 
        VALUES (?, ?, ?, ?, 0)
    ")->execute([$yearLabel, $startDate, $endDate, $termStructure]);

    $newId = (int)$pdo->lastInsertId();

    // Create grading periods based on term structure
    $insertQ = $pdo->prepare("
        INSERT INTO tblquarters (academic_year_id, quarter_number, quarter_label, is_active, is_closed)
        VALUES (?, ?, ?, 0, 0)
    ");

    if ($termStructure === 'quarterly') {
        $quarterLabels = ['1st', '2nd', '3rd', '4th'];
    } elseif ($termStructure === 'trimester') {
        $quarterLabels = ['1st', '2nd', '3rd'];
    } else { // semestral
        $quarterLabels = ['1st', '2nd'];
    }

    foreach ($quarterLabels as $num => $label) {
        $insertQ->execute([$newId, $num + 1, $label]);
    }

    $periodCount = count($quarterLabels);
    respond(true, "Academic year added successfully. $periodCount grading period(s) have been created.");

} catch (Throwable $e) {
    respond(false, $e->getMessage());
}