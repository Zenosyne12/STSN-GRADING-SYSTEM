<?php
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/promotion_service.php';
header('Content-Type: application/json');

function respond(bool $success, string $message, array $extra = []): void
{
    echo json_encode(array_merge(['success' => $success, 'message' => $message], $extra));
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!is_array($input)) {
        throw new Exception('Invalid request payload.');
    }

    $id            = isset($input['id']) && $input['id'] !== '' ? (int)$input['id'] : 0;
    $yearLabel     = isset($input['year_label']) ? trim($input['year_label']) : '';
    $termStructure = isset($input['term_structure']) ? trim($input['term_structure']) : 'trimester';

    // Validation
    if ($yearLabel === '') {
        throw new Exception('Academic year is required.');
    }

    if (!preg_match('/^\d{4}-\d{4}$/', $yearLabel)) {
        throw new Exception('Invalid year format. Expected YYYY-YYYY.');
    }

    $allowed = ['quarterly', 'trimester', 'semestral'];
    if (!in_array($termStructure, $allowed)) {
        throw new Exception('Invalid term structure. Must be quarterly, trimester, or semestral.');
    }

    // UPDATE existing year
    if ($id > 0) {
        $check = $pdo->prepare("SELECT COUNT(*) FROM tblacademicyear WHERE year_label = ? AND id <> ?");
        $check->execute([$yearLabel, $id]);
        if ((int)$check->fetchColumn() > 0) {
            throw new Exception('Academic year already exists.');
        }

        $pdo->prepare("
            UPDATE tblacademicyear 
            SET year_label = ?, term_structure = ? 
            WHERE id = ?
        ")->execute([$yearLabel, $termStructure, $id]);

        respond(true, 'Academic year updated successfully.');
    }

    // CREATE new year
    $check = $pdo->prepare("SELECT COUNT(*) FROM tblacademicyear WHERE year_label = ?");
    $check->execute([$yearLabel]);
    if ((int)$check->fetchColumn() > 0) {
        throw new Exception('Academic year already exists.');
    }

    $sourceYearId = (int) $pdo->query("
        SELECT id
        FROM tblacademicyear
        WHERE is_active = 1 AND archived_at IS NULL
        LIMIT 1
    ")->fetchColumn();

    if ($sourceYearId === 0) {
        $sourceYearId = (int) $pdo->query("
            SELECT ay.id
            FROM tblacademicyear ay
            WHERE ay.is_active = 0 AND ay.archived_at IS NOT NULL
              AND EXISTS (
                  SELECT 1 FROM tblenrollment e
                  WHERE e.academic_year_id = ay.id AND e.is_active = 1
              )
            ORDER BY ay.id DESC
            LIMIT 1
        ")->fetchColumn();
    }

    if ($sourceYearId > 0) {
        ensurePromotionSchema($pdo);
    }

    $pdo->beginTransaction();
    $pdo->exec("UPDATE tblacademicyear SET is_active = 0 WHERE is_active = 1");
    $pdo->exec("UPDATE tblquarters SET is_active = 0 WHERE is_active = 1");
    $pdo->exec("UPDATE tblconfig_terms SET is_active = 0 WHERE is_active = 1");
    $pdo->prepare("
        INSERT INTO tblacademicyear (year_label, term_structure, is_active, curriculum_status)
        VALUES (?, ?, 1, 'NONE')
    ")->execute([$yearLabel, $termStructure]);

    $newId = (int)$pdo->lastInsertId();

    // Create grading terms based on term structure
    $termLabelsByStructure = [
        'quarterly' => ['1st Term', '2nd Term', '3rd Term', '4th Term'],
        'trimester' => ['1st Term', '2nd Term', '3rd Term'],
        'semestral' => ['1st Term', '2nd Term'],
    ];
    $termTypesByStructure = [
        'quarterly' => 'QUARTER',
        'trimester' => 'TRIMESTER',
        'semestral' => 'SEMESTER',
    ];
    $termLabels = $termLabelsByStructure[$termStructure];
    $insertTerm = $pdo->prepare("
        INSERT INTO tblconfig_terms
            (academic_year_id, term_number, term_label, term_type, is_active, is_closed)
        VALUES (?, ?, ?, ?, 0, 0)
    ");

    foreach ($termLabels as $num => $label) {
        $insertTerm->execute([$newId, $num + 1, $label, $termTypesByStructure[$termStructure]]);
    }

    if ($sourceYearId > 0) {
        runAcademicYearPromotion(
            $pdo,
            $sourceYearId,
            $newId,
            (int) ($_SESSION['user_id'] ?? 0) ?: null
        );
    }

    $periodCount = count($termLabels);
    $pdo->commit();
    respond(true, "Academic year added successfully. $periodCount grading term(s) have been created.");

} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    respond(false, $e->getMessage());
}