<?php
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();
if (!in_array((int) ($_SESSION['role_id'] ?? 0), [1, 4], true)) {
    jsonAuthError(403, 'Administrator access is required.');
}
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

try {
    $stmt = $pdo->query("
        SELECT
          COUNT(*) AS cnt,
          COALESCE(SUM(CASE WHEN curriculum_status = 'NONE' THEN 1 ELSE 0 END), 0) AS none_cnt
        FROM tblacademicyear
        WHERE is_active = 1 AND archived_at IS NULL
    ");
    $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    $hasActiveYear = ((int) ($row['cnt'] ?? 0)) > 0;
    $noneCount = (int) ($row['none_cnt'] ?? 0);
    $curriculumNone = $hasActiveYear && $noneCount > 0;
    $needsSetup = (!$hasActiveYear) || $curriculumNone;
    echo json_encode([
        'success' => true,
        'has_active_year' => $hasActiveYear,
        'needs_setup' => $needsSetup,
        'curriculum_none' => $curriculumNone,
    ]);
} catch (Throwable $e) {
    error_log('[academic-year] Active status check failed: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'has_active_year' => true,
        'needs_setup' => false,
        'curriculum_none' => false,
        'message' => 'Unable to check the active academic year status.',
    ]);
}
