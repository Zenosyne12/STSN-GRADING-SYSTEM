<?php
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

$id   = intval($_GET['id'] ?? 0);
$stmt = $pdo->prepare('DELETE FROM tblAcademicYear WHERE id = ?');
$stmt->execute([$id]);

echo json_encode(['success' => $stmt->rowCount() > 0]);