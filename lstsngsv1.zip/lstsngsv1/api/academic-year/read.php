<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $page   = isset($_GET['p']) ? max(1, (int)$_GET['p']) : 1;
    $limit  = 10;
    $offset = ($page - 1) * $limit;

    // Optional: return all years (used by year navigator dropdowns)
    $returnAll = isset($_GET['all']) && $_GET['all'] == '1';

    $total = (int)$pdo->query("SELECT COUNT(*) FROM tblacademicyear")->fetchColumn();
    $pages = max(1, (int)ceil($total / $limit));

    $stmt = $pdo->prepare("
        SELECT id, year_label, is_active, created_at
        FROM tblacademicyear
        ORDER BY year_label DESC
        LIMIT :lim OFFSET :off
    ");
    $stmt->bindValue(':lim',  $limit,  PDO::PARAM_INT);
    $stmt->bindValue(':off',  $offset, PDO::PARAM_INT);
    $stmt->execute();
    $years = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $activeYear = (string)$pdo->query(
        "SELECT year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1"
    )->fetchColumn();

    $allYears = [];
    if ($returnAll) {
        $allYears = $pdo->query(
            "SELECT id, year_label, is_active FROM tblacademicyear ORDER BY year_label DESC"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    echo json_encode([
        'success'     => true,
        'years'       => $years,
        'page'        => $page,
        'pages'       => $pages,
        'total'       => $total,
        'active_year' => $activeYear,
        'all_years'   => $allYears,
    ]);
} catch (Throwable $e) {
    echo json_encode([
        'success'     => false,
        'years'       => [],
        'page'        => 1,
        'pages'       => 1,
        'total'       => 0,
        'active_year' => '',
        'all_years'   => [],
        'message'     => $e->getMessage(),
    ]);
}