<?php

require_once __DIR__ . '/../shared/grade_workflow.php';

function ayTableExists(PDO $pdo, string $table): bool
{
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
    ");
    $stmt->execute([$table]);
    return (int)$stmt->fetchColumn() > 0;
}

function ayColumnExists(PDO $pdo, string $table, string $column): bool
{
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?
    ");
    $stmt->execute([$table, $column]);
    return (int)$stmt->fetchColumn() > 0;
}

function ayAddColumnIfMissing(PDO $pdo, string $table, string $column, string $definition): void
{
    if (!ayColumnExists($pdo, $table, $column)) {
        $pdo->exec("ALTER TABLE {$table} ADD COLUMN {$column} {$definition}");
    }
}

function ensurePromotionSchema(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS tblstudent_archive (
            id INT NOT NULL AUTO_INCREMENT,
            student_id INT NOT NULL,
            academic_year_id INT NOT NULL,
            grade_level_id INT NOT NULL,
            final_average DECIMAL(5,2) DEFAULT NULL,
            status ENUM('PROMOTED','RETAINED','DROPPED','TRANSFERRED','GRADUATED') NOT NULL,
            archived_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            archived_by INT DEFAULT NULL,
            PRIMARY KEY (id),
            KEY fk_archive_student (student_id),
            KEY fk_archive_year (academic_year_id),
            KEY fk_archive_grade (grade_level_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");

    ayAddColumnIfMissing($pdo, 'tblstudent_archive', 'section_id', 'INT NULL AFTER grade_level_id');
    ayAddColumnIfMissing($pdo, 'tblstudent_archive', 'final_grades_json', 'LONGTEXT NULL AFTER final_average');
    ayAddColumnIfMissing($pdo, 'tblstudent_archive', 'attendance_json', 'LONGTEXT NULL AFTER final_grades_json');
    ayAddColumnIfMissing($pdo, 'tblstudent_archive', 'character_evaluation_json', 'LONGTEXT NULL AFTER attendance_json');
    ayAddColumnIfMissing($pdo, 'tblstudent_archive', 'final_status', "VARCHAR(20) NULL AFTER character_evaluation_json");
    ayAddColumnIfMissing($pdo, 'tblstudent_archive', 'promotion_date', 'DATETIME NULL AFTER final_status');
    ayAddColumnIfMissing($pdo, 'tblstudent_archive', 'next_academic_year_id', 'INT NULL AFTER promotion_date');
    ayAddColumnIfMissing($pdo, 'tblstudent_archive', 'promoted_grade_level_id', 'INT NULL AFTER next_academic_year_id');

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS tblpromotion_runs (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            from_academic_year_id INT NOT NULL,
            to_academic_year_id INT NOT NULL,
            promoted_count INT NOT NULL DEFAULT 0,
            retained_count INT NOT NULL DEFAULT 0,
            graduated_count INT NOT NULL DEFAULT 0,
            archived_count INT NOT NULL DEFAULT 0,
            pending_section_count INT NOT NULL DEFAULT 0,
            run_by INT DEFAULT NULL,
            run_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            notes TEXT DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_promotion_year_pair (from_academic_year_id, to_academic_year_id),
            KEY idx_promotion_to_year (to_academic_year_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
}

function loadStudentYearSnapshot(PDO $pdo, int $studentId, int $academicYearId): array
{
    ensureGradeWorkflowSchema($pdo);

    $gradesStmt = $pdo->prepare("
        SELECT g.student_id, g.section_id, g.subject_id, g.quarter, g.initial_grade, g.final_grade, g.remarks,
               s.subject_code, s.subject_name
        FROM tblgrades g
        LEFT JOIN tblsubjects s ON s.id = g.subject_id
        WHERE g.student_id = ? AND g.academic_year_id = ?
          AND " . officialGradeExistsSql('g') . "
        ORDER BY g.subject_id, g.quarter
    ");
    $gradesStmt->execute([$studentId, $academicYearId]);
    $grades = $gradesStmt->fetchAll(PDO::FETCH_ASSOC);

    $subjectTotals = [];
    foreach ($grades as $row) {
        $fg = (float)($row['final_grade'] ?? 0);
        if ($fg <= 0) {
            continue;
        }
        $sid = (int)$row['subject_id'];
        if (!isset($subjectTotals[$sid])) {
            $subjectTotals[$sid] = ['total' => 0, 'count' => 0];
        }
        $subjectTotals[$sid]['total'] += $fg;
        $subjectTotals[$sid]['count']++;
    }

    $subjectFinals = [];
    foreach ($subjectTotals as $sid => $item) {
        if ($item['count'] > 0) {
            $subjectFinals[] = $item['total'] / $item['count'];
        }
    }

    $finalAverage = count($subjectFinals) ? round(array_sum($subjectFinals) / count($subjectFinals), 2) : null;
    $finalStatus = ($finalAverage !== null && $finalAverage >= 75) ? 'Passed' : 'Failed';

    $attendance = [];
    if (ayTableExists($pdo, 'tblattendance_records')) {
        $attendanceStmt = $pdo->prepare("
            SELECT month_number, month_name, school_days, days_present, days_absent
            FROM tblattendance_records
            WHERE student_id = ? AND academic_year_id = ?
            ORDER BY month_number
        ");
        $attendanceStmt->execute([$studentId, $academicYearId]);
        $attendance = $attendanceStmt->fetchAll(PDO::FETCH_ASSOC);
    }

    return [
        'grades' => $grades,
        'attendance' => $attendance,
        'character_evaluation' => [],
        'final_average' => $finalAverage,
        'final_status' => $finalStatus
    ];
}

function previewAcademicYearPromotion(PDO $pdo, int $oldYearId, ?int $newYearId, bool $includeInactive = false): array
{
    if ($oldYearId <= 0 || ($newYearId !== null && ($newYearId <= 0 || $oldYearId === $newYearId))) {
        throw new InvalidArgumentException('Valid academic years are required.');
    }

    $enrollmentStmt = $pdo->prepare("
        SELECT e.id AS enrollment_id, e.student_id, e.grade_level_id, e.enrollment_status,
               e.promotion_decision, e.failed_subject_count,
               gl.grade_level_name, gl.sort_order, gl.is_last,
               s.fname, s.mname, s.lname
        FROM tblenrollment e
        JOIN tblstudents s ON s.id = e.student_id
        JOIN tblgradelevel gl ON gl.id = e.grade_level_id
        WHERE e.academic_year_id = ?
        " . ($includeInactive ? '' : 'AND e.is_active = 1') . "
        ORDER BY gl.sort_order, s.lname, s.fname
    ");
    $enrollmentStmt->execute([$oldYearId]);
    $enrollments = $enrollmentStmt->fetchAll(PDO::FETCH_ASSOC);

    $gradeRows = $pdo->query("
        SELECT id, grade_level_name, sort_order, is_last
        FROM tblgradelevel
        ORDER BY sort_order ASC, id ASC
    ")->fetchAll(PDO::FETCH_ASSOC);
    $nextGradeById = [];
    foreach ($gradeRows as $index => $gradeRow) {
        $nextGradeById[(int) $gradeRow['id']] = isset($gradeRows[$index + 1])
            ? $gradeRows[$index + 1]
            : null;
    }

    $subjectAveragesStmt = $pdo->prepare("
        SELECT g.student_id, g.subject_id,
               COALESCE(sub.subject_name, CONCAT('Subject #', g.subject_id)) AS subject_name,
               AVG(g.final_grade) AS subject_average
        FROM tblgrades g
        LEFT JOIN tblsubjects sub ON sub.id = g.subject_id
        WHERE g.academic_year_id = ?
          AND g.final_grade IS NOT NULL
          AND g.final_grade > 0
        GROUP BY g.student_id, g.subject_id, sub.subject_name
        ORDER BY g.student_id, subject_name
    ");
    $subjectAveragesStmt->execute([$oldYearId]);
    $subjectAveragesByStudent = [];
    foreach ($subjectAveragesStmt->fetchAll(PDO::FETCH_ASSOC) as $subjectAverage) {
        $subjectAveragesByStudent[(int) $subjectAverage['student_id']][] = $subjectAverage;
    }

    $summary = [
        'promoted' => 0,
        'retained' => 0,
        'graduated' => 0,
        'pending_review' => 0,
        'dropped' => 0,
        'transferred' => 0,
    ];
    $students = [];
    foreach ($enrollments as $enrollment) {
        $studentId = (int) $enrollment['student_id'];
        $subjectAverages = $subjectAveragesByStudent[$studentId] ?? [];
        $failedSubjects = array_values(array_filter(
            $subjectAverages,
            static fn(array $subject): bool => (float) $subject['subject_average'] < 75
        ));
        $failedCount = count($failedSubjects);
        $finalAverage = count($subjectAverages)
            ? round(array_sum(array_map(
                static fn(array $subject): float => (float) $subject['subject_average'],
                $subjectAverages
            )) / count($subjectAverages), 2)
            : null;
        $status = strtoupper((string) $enrollment['enrollment_status']);

        if (in_array($status, ['DROPPED', 'TRANSFERRED'], true)) {
            $decision = $status;
        } elseif ($failedCount === 0) {
            $decision = 'PROMOTED';
        } elseif ($failedCount >= 3) {
            $decision = 'RETAINED';
        } else {
            $storedDecision = (string) ($enrollment['promotion_decision'] ?? '');
            $decision = in_array($storedDecision, ['PROMOTED', 'RETAINED'], true)
                ? $storedDecision
                : 'PENDING_REVIEW';
        }

        $nextGrade = null;
        if ($decision === 'PROMOTED') {
            $nextGrade = $nextGradeById[(int) $enrollment['grade_level_id']] ?? null;
            if ((int) ($enrollment['is_last'] ?? 0) === 1) {
                $decision = 'GRADUATED';
            } elseif ($newYearId !== null && !$nextGrade) {
                throw new RuntimeException('No next grade level is configured for ' . $enrollment['grade_level_name'] . '.');
            }
        }

        if (!array_key_exists(strtolower($decision), $summary)) {
            throw new RuntimeException('Unsupported promotion decision: ' . $decision);
        }
        $summary[strtolower($decision)]++;

        $students[] = [
            'enrollment_id' => (int) $enrollment['enrollment_id'],
            'student_id' => $studentId,
            'student_name' => trim(implode(' ', array_filter([
                $enrollment['fname'],
                $enrollment['mname'],
                $enrollment['lname'],
            ], static fn($part) => (string) $part !== ''))),
            'grade_level' => (string) $enrollment['grade_level_name'],
            'grade_level_id' => (int) $enrollment['grade_level_id'],
            'next_grade_level_id' => $nextGrade ? (int) $nextGrade['id'] : null,
            'is_last' => (int) ($enrollment['is_last'] ?? 0) === 1,
            'failed_count' => $failedCount,
            'failed_subjects' => array_column($failedSubjects, 'subject_name'),
            'final_average' => $finalAverage,
            'decision' => $decision,
        ];
    }

    return ['summary' => $summary, 'students' => $students];
}

function storePromotionClassifications(PDO $pdo, int $oldYearId, array $preview, bool $includeInactive = false): void
{
    $activeFilter = $includeInactive ? '' : ' AND is_active = 1';
    $update = $pdo->prepare("
        UPDATE tblenrollment
        SET promotion_decision = ?, failed_subject_count = ?
        WHERE id = ? AND academic_year_id = ?{$activeFilter}
    ");
    $exists = $pdo->prepare("
        SELECT 1
        FROM tblenrollment
        WHERE id = ? AND academic_year_id = ?{$activeFilter}
        LIMIT 1
    ");

    foreach ($preview['students'] as $student) {
        $update->execute([
            $student['decision'],
            $student['failed_count'],
            $student['enrollment_id'],
            $oldYearId,
        ]);
        if ($update->rowCount() !== 1) {
            $exists->execute([$student['enrollment_id'], $oldYearId]);
        }
        if ($update->rowCount() !== 1 && !$exists->fetchColumn()) {
            throw new RuntimeException('A promotion review enrollment changed while it was being classified.');
        }
    }
}

function runAcademicYearPromotion(PDO $pdo, int $oldYearId, int $newYearId, ?int $adminId = null): array
{
    $preview = previewAcademicYearPromotion($pdo, $oldYearId, $newYearId);
    $summary = $preview['summary'];
    if ($summary['pending_review'] > 0) {
        return $summary + ['archived' => 0, 'already_ran' => false];
    }

    $runCheck = $pdo->prepare("
        SELECT promoted_count, retained_count, graduated_count, archived_count, pending_section_count
        FROM tblpromotion_runs
        WHERE from_academic_year_id = ? AND to_academic_year_id = ?
        LIMIT 1
    ");
    $runCheck->execute([$oldYearId, $newYearId]);
    $existingRun = $runCheck->fetch(PDO::FETCH_ASSOC);
    if ($existingRun) {
        return $summary + [
            'archived' => (int) $existingRun['archived_count'],
            'already_ran' => true,
            'pending_section' => (int) $existingRun['pending_section_count'],
        ];
    }

    $updateOldEnrollment = $pdo->prepare("
        UPDATE tblenrollment
        SET promotion_decision = ?, failed_subject_count = ?, is_active = 0,
            enrollment_status = CASE WHEN ? = 'GRADUATED' THEN 'GRADUATED' ELSE enrollment_status END
        WHERE id = ?
    ");
    $insertArchive = $pdo->prepare("
        INSERT INTO tblstudent_archive
            (student_id, academic_year_id, grade_level_id, final_average, status, archived_by)
        VALUES (?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE status = VALUES(status), final_average = VALUES(final_average)
    ");
    $existingNewEnrollment = $pdo->prepare("
        SELECT id FROM tblenrollment
        WHERE student_id = ? AND academic_year_id = ?
        LIMIT 1
    ");
    $updateNewEnrollment = $pdo->prepare("
        UPDATE tblenrollment
        SET grade_level_id = ?, enrollment_status = ?, is_active = 1
        WHERE id = ?
    ");
    $insertNewEnrollment = $pdo->prepare("
        INSERT INTO tblenrollment
            (student_id, academic_year_id, grade_level_id, enrollment_status, is_active)
        VALUES (?, ?, ?, ?, 1)
    ");
    $updateStudent = $pdo->prepare("
        UPDATE tblstudents
        SET grade_level_id = ?,
            strand = CASE WHEN ? = 1 THEN NULL ELSE strand END,
            cluster_id = CASE WHEN ? = 1 THEN NULL ELSE cluster_id END,
            is_active = CASE WHEN ? = 1 THEN 0 ELSE is_active END
        WHERE id = ?
    ");
    $archiveExists = $pdo->prepare("
        SELECT id FROM tblstudent_archive
        WHERE student_id = ? AND academic_year_id = ?
        LIMIT 1
    ");
    $archiveUpdate = $pdo->prepare("
        UPDATE tblstudent_archive
        SET final_average = ?, status = ?, archived_by = ?
        WHERE id = ?
    ");
    $archived = 0;
    foreach ($preview['students'] as $student) {
        $decision = $student['decision'];
        $updateOldEnrollment->execute([
            $decision,
            $student['failed_count'],
            $decision,
            $student['enrollment_id'],
        ]);

        $archiveExists->execute([$student['student_id'], $oldYearId]);
        $existingArchive = $archiveExists->fetchColumn();
        if ($existingArchive) {
            $archiveUpdate->execute([
                $student['final_average'],
                $decision,
                $adminId,
                (int) $existingArchive,
            ]);
        } else {
            $insertArchive->execute([
                $student['student_id'],
                $oldYearId,
                $student['grade_level_id'],
                $student['final_average'],
                $decision,
                $adminId,
            ]);
        }
        $archived++;

        if ($decision === 'GRADUATED') {
            $updateStudent->execute([
                $student['grade_level_id'],
                0,
                0,
                1,
                $student['student_id'],
            ]);
            continue;
        }

        if (in_array($decision, ['DROPPED', 'TRANSFERRED'], true)) {
            continue;
        }

        $isPromoted = $decision === 'PROMOTED';
        $newGradeId = $isPromoted
            ? (int) $student['next_grade_level_id']
            : $student['grade_level_id'];
        $isGradeTenToEleven = $isPromoted
            && strcasecmp($student['grade_level'], 'Grade 10') === 0
            && (int) ($student['next_grade_level_id'] ?? 0) > 0;

        $existingNewEnrollment->execute([$student['student_id'], $newYearId]);
        $existingNewEnrollmentId = $existingNewEnrollment->fetchColumn();
        $newEnrollmentStatus = $decision === 'RETAINED' ? 'RETAINED' : 'ENROLLED';
        if ($existingNewEnrollmentId) {
            $updateNewEnrollment->execute([
                $newGradeId,
                $newEnrollmentStatus,
                (int) $existingNewEnrollmentId,
            ]);
        } else {
            $insertNewEnrollment->execute([
                $student['student_id'],
                $newYearId,
                $newGradeId,
                $newEnrollmentStatus,
            ]);
        }

        $updateStudent->execute([
            $newGradeId,
            $isGradeTenToEleven ? 1 : 0,
            $isGradeTenToEleven ? 1 : 0,
            0,
            $student['student_id'],
        ]);
    }

    $pendingSectionStmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM tblenrollment e
        LEFT JOIN tblsectionstudent ss
               ON ss.student_id = e.student_id
              AND ss.academic_year_id = e.academic_year_id
              AND ss.is_active = 1
        WHERE e.academic_year_id = ?
          AND e.is_active = 1
          AND e.enrollment_status IN ('ENROLLED','RETAINED')
          AND ss.id IS NULL
    ");
    $pendingSectionStmt->execute([$newYearId]);
    $pendingSection = (int) $pendingSectionStmt->fetchColumn();

    $insertRun = $pdo->prepare("
        INSERT INTO tblpromotion_runs
            (from_academic_year_id, to_academic_year_id, promoted_count, retained_count,
             graduated_count, archived_count, pending_section_count, run_by, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $insertRun->execute([
        $oldYearId,
        $newYearId,
        $summary['promoted'],
        $summary['retained'],
        $summary['graduated'],
        $archived,
        $pendingSection,
        $adminId,
        'Automatic promotion during academic year activation.',
    ]);

    return $summary + [
        'archived' => $archived,
        'pending_section' => $pendingSection,
        'already_ran' => false,
    ];
}

function getPromotionDashboardStats(PDO $pdo): array
{
    ensurePromotionSchema($pdo);

    $activeYear = $pdo->query("SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    $activeYearId = $activeYear ? (int)$activeYear['id'] : 0;

    $latestRun = $pdo->query("
        SELECT *
        FROM tblpromotion_runs
        ORDER BY run_at DESC, id DESC
        LIMIT 1
    ")->fetch(PDO::FETCH_ASSOC) ?: [];

    $archiveCount = (int)$pdo->query("SELECT COUNT(*) FROM tblstudent_archive")->fetchColumn();

    $pendingSection = 0;
    if ($activeYearId) {
        $pendingStmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM tblenrollment e
            LEFT JOIN tblsectionstudent ss
                   ON ss.student_id = e.student_id
                  AND ss.academic_year_id = e.academic_year_id
                  AND ss.is_active = 1
            WHERE e.academic_year_id = ?
              AND e.is_active = 1
              AND e.enrollment_status IN ('ENROLLED','RETAINED')
              AND ss.id IS NULL
        ");
        $pendingStmt->execute([$activeYearId]);
        $pendingSection = (int)$pendingStmt->fetchColumn();
    }

    return [
        'promoted' => (int)($latestRun['promoted_count'] ?? 0),
        'retained' => (int)($latestRun['retained_count'] ?? 0),
        'graduated' => (int)($latestRun['graduated_count'] ?? 0),
        'archived' => $archiveCount,
        'pending_section' => $pendingSection
    ];
}

?>
