<?php

require_once __DIR__ . '/../shared/grade_workflow.php';

function ayTableExists(PDO $pdo, string $table): bool
{
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
    ");
    $stmt->execute([$table]);
    return (int)$stmt->fetchColumn() > 0;
}

function ayColumnExists(PDO $pdo, string $table, string $column): bool
{
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?
    ");
    $stmt->execute([$table, $column]);
    return (int)$stmt->fetchColumn() > 0;
}

function ayAddColumnIfMissing(PDO $pdo, string $table, string $column, string $definition): void
{
    if (!ayColumnExists($pdo, $table, $column)) {
        $pdo->exec("ALTER TABLE {$table} ADD COLUMN {$column} {$definition}");
    }
}

function ensurePromotionSchema(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS tblstudent_archive (
            id INT NOT NULL AUTO_INCREMENT,
            student_id INT NOT NULL,
            academic_year_id INT NOT NULL,
            grade_level_id INT NOT NULL,
            final_average DECIMAL(5,2) DEFAULT NULL,
            status ENUM('PROMOTED','RETAINED','DROPPED','TRANSFERRED','GRADUATED') NOT NULL,
            archived_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            archived_by INT DEFAULT NULL,
            PRIMARY KEY (id),
            KEY fk_archive_student (student_id),
            KEY fk_archive_year (academic_year_id),
            KEY fk_archive_grade (grade_level_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");

    ayAddColumnIfMissing($pdo, 'tblstudent_archive', 'section_id', 'INT NULL AFTER grade_level_id');
    ayAddColumnIfMissing($pdo, 'tblstudent_archive', 'final_grades_json', 'LONGTEXT NULL AFTER final_average');
    ayAddColumnIfMissing($pdo, 'tblstudent_archive', 'attendance_json', 'LONGTEXT NULL AFTER final_grades_json');
    ayAddColumnIfMissing($pdo, 'tblstudent_archive', 'character_evaluation_json', 'LONGTEXT NULL AFTER attendance_json');
    ayAddColumnIfMissing($pdo, 'tblstudent_archive', 'final_status', "VARCHAR(20) NULL AFTER character_evaluation_json");
    ayAddColumnIfMissing($pdo, 'tblstudent_archive', 'promotion_date', 'DATETIME NULL AFTER final_status');
    ayAddColumnIfMissing($pdo, 'tblstudent_archive', 'next_academic_year_id', 'INT NULL AFTER promotion_date');
    ayAddColumnIfMissing($pdo, 'tblstudent_archive', 'promoted_grade_level_id', 'INT NULL AFTER next_academic_year_id');

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS tblpromotion_runs (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            from_academic_year_id INT NOT NULL,
            to_academic_year_id INT NOT NULL,
            promoted_count INT NOT NULL DEFAULT 0,
            retained_count INT NOT NULL DEFAULT 0,
            graduated_count INT NOT NULL DEFAULT 0,
            archived_count INT NOT NULL DEFAULT 0,
            pending_section_count INT NOT NULL DEFAULT 0,
            run_by INT DEFAULT NULL,
            run_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            notes TEXT DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_promotion_year_pair (from_academic_year_id, to_academic_year_id),
            KEY idx_promotion_to_year (to_academic_year_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
}

function loadStudentYearSnapshot(PDO $pdo, int $studentId, int $academicYearId): array
{
    ensureGradeWorkflowSchema($pdo);

    $gradesStmt = $pdo->prepare("
        SELECT g.student_id, g.section_id, g.subject_id, g.quarter, g.initial_grade, g.final_grade, g.remarks,
               s.subject_code, s.subject_name
        FROM tblgrades g
        LEFT JOIN tblsubjects s ON s.id = g.subject_id
        WHERE g.student_id = ? AND g.academic_year_id = ?
          AND " . officialGradeExistsSql('g') . "
        ORDER BY g.subject_id, g.quarter
    ");
    $gradesStmt->execute([$studentId, $academicYearId]);
    $grades = $gradesStmt->fetchAll(PDO::FETCH_ASSOC);

    $subjectTotals = [];
    foreach ($grades as $row) {
        $fg = (float)($row['final_grade'] ?? 0);
        if ($fg <= 0) {
            continue;
        }
        $sid = (int)$row['subject_id'];
        if (!isset($subjectTotals[$sid])) {
            $subjectTotals[$sid] = ['total' => 0, 'count' => 0];
        }
        $subjectTotals[$sid]['total'] += $fg;
        $subjectTotals[$sid]['count']++;
    }

    $subjectFinals = [];
    foreach ($subjectTotals as $sid => $item) {
        if ($item['count'] > 0) {
            $subjectFinals[] = $item['total'] / $item['count'];
        }
    }

    $finalAverage = count($subjectFinals) ? round(array_sum($subjectFinals) / count($subjectFinals), 2) : null;
    $finalStatus = ($finalAverage !== null && $finalAverage >= 75) ? 'Passed' : 'Failed';

    $attendance = [];
    if (ayTableExists($pdo, 'tblattendance_records')) {
        $attendanceStmt = $pdo->prepare("
            SELECT month_number, month_name, school_days, days_present, days_absent
            FROM tblattendance_records
            WHERE student_id = ? AND academic_year_id = ?
            ORDER BY month_number
        ");
        $attendanceStmt->execute([$studentId, $academicYearId]);
        $attendance = $attendanceStmt->fetchAll(PDO::FETCH_ASSOC);
    }

    return [
        'grades' => $grades,
        'attendance' => $attendance,
        'character_evaluation' => [],
        'final_average' => $finalAverage,
        'final_status' => $finalStatus
    ];
}

function runAcademicYearPromotion(PDO $pdo, int $oldYearId, int $newYearId, ?int $adminId = null): array
{
    ensurePromotionSchema($pdo);

    if (!$oldYearId || !$newYearId || $oldYearId === $newYearId) {
        return ['archived' => 0, 'promoted' => 0, 'retained' => 0, 'graduated' => 0, 'skipped' => 0, 'already_ran' => false];
    }

    $runCheck = $pdo->prepare("
        SELECT promoted_count, retained_count, graduated_count, archived_count, pending_section_count
        FROM tblpromotion_runs
        WHERE from_academic_year_id = ? AND to_academic_year_id = ?
        LIMIT 1
    ");
    $runCheck->execute([$oldYearId, $newYearId]);
    $existingRun = $runCheck->fetch(PDO::FETCH_ASSOC);
    if ($existingRun) {
        return [
            'archived' => (int)$existingRun['archived_count'],
            'promoted' => (int)$existingRun['promoted_count'],
            'retained' => (int)$existingRun['retained_count'],
            'graduated' => (int)$existingRun['graduated_count'],
            'skipped' => 0,
            'pending_section' => (int)$existingRun['pending_section_count'],
            'already_ran' => true
        ];
    }

    $gradeRows = $pdo->query("SELECT id, sort_order, is_last FROM tblgradelevel ORDER BY sort_order ASC")->fetchAll(PDO::FETCH_ASSOC);
    $nextGradeById = [];
    foreach ($gradeRows as $index => $row) {
        $nextGradeById[(int)$row['id']] = null;
        if ((int)$row['is_last'] !== 1 && isset($gradeRows[$index + 1])) {
            $nextGradeById[(int)$row['id']] = (int)$gradeRows[$index + 1]['id'];
        }
    }

    $enrollStmt = $pdo->prepare("
        SELECT e.id AS enrollment_id, e.student_id, e.grade_level_id, e.enrollment_status,
               gl.is_last,
               ss.section_id
        FROM tblenrollment e
        LEFT JOIN tblgradelevel gl ON gl.id = e.grade_level_id
        LEFT JOIN tblsectionstudent ss
               ON ss.student_id = e.student_id
              AND ss.academic_year_id = e.academic_year_id
              AND ss.is_active = 1
        WHERE e.academic_year_id = ?
          AND e.is_active = 1
          AND e.enrollment_status NOT IN ('DROPPED','TRANSFERRED','GRADUATED')
        GROUP BY e.id
        ORDER BY e.student_id
    ");
    $enrollStmt->execute([$oldYearId]);
    $enrollments = $enrollStmt->fetchAll(PDO::FETCH_ASSOC);

    $archiveCheck = $pdo->prepare("
        SELECT id FROM tblstudent_archive
        WHERE student_id = ? AND academic_year_id = ?
        LIMIT 1
    ");
    $insertArchive = $pdo->prepare("
        INSERT INTO tblstudent_archive
            (student_id, academic_year_id, grade_level_id, section_id, final_average,
             final_grades_json, attendance_json, character_evaluation_json,
             status, final_status, promotion_date, next_academic_year_id, promoted_grade_level_id, archived_by)
        VALUES
            (:student_id, :academic_year_id, :grade_level_id, :section_id, :final_average,
             :final_grades_json, :attendance_json, :character_evaluation_json,
             :status, :final_status, NOW(), :next_academic_year_id, :promoted_grade_level_id, :archived_by)
    ");
    $newEnrollCheck = $pdo->prepare("
        SELECT id FROM tblenrollment
        WHERE student_id = ? AND academic_year_id = ?
        LIMIT 1
    ");
    $insertEnrollment = $pdo->prepare("
        INSERT INTO tblenrollment
            (student_id, academic_year_id, grade_level_id, enrollment_status, is_active)
        VALUES
            (?, ?, ?, 'ENROLLED', 1)
    ");
    $updateStudentGrade = $pdo->prepare("UPDATE tblstudents SET grade_level_id = ? WHERE id = ?");

    $archived = 0;
    $promoted = 0;
    $retained = 0;
    $graduated = 0;
    $skipped = 0;

    foreach ($enrollments as $enrollment) {
        $studentId = (int)$enrollment['student_id'];
        $oldGradeId = (int)$enrollment['grade_level_id'];
        $snapshot = loadStudentYearSnapshot($pdo, $studentId, $oldYearId);
        $isPassed = $snapshot['final_status'] === 'Passed';
        $isLast = (int)($enrollment['is_last'] ?? 0) === 1;

        $newGradeId = $oldGradeId;
        $archiveStatus = 'RETAINED';
        if ($isPassed && $isLast) {
            $archiveStatus = 'GRADUATED';
            $newGradeId = 0;
        } elseif ($isPassed) {
            $nextGradeId = $nextGradeById[$oldGradeId] ?? null;
            if ($nextGradeId) {
                $archiveStatus = 'PROMOTED';
                $newGradeId = $nextGradeId;
            }
        }

        $archiveCheck->execute([$studentId, $oldYearId]);
        if (!$archiveCheck->fetch()) {
            $insertArchive->execute([
                ':student_id' => $studentId,
                ':academic_year_id' => $oldYearId,
                ':grade_level_id' => $oldGradeId,
                ':section_id' => $enrollment['section_id'] ? (int)$enrollment['section_id'] : null,
                ':final_average' => $snapshot['final_average'],
                ':final_grades_json' => json_encode($snapshot['grades'], JSON_UNESCAPED_UNICODE),
                ':attendance_json' => json_encode($snapshot['attendance'], JSON_UNESCAPED_UNICODE),
                ':character_evaluation_json' => json_encode($snapshot['character_evaluation'], JSON_UNESCAPED_UNICODE),
                ':status' => $archiveStatus,
                ':final_status' => $snapshot['final_status'],
                ':next_academic_year_id' => $newYearId,
                ':promoted_grade_level_id' => $newGradeId ?: null,
                ':archived_by' => $adminId
            ]);
            $archived++;
        }

        if ($archiveStatus === 'GRADUATED') {
            $graduated++;
            continue;
        }

        $newEnrollCheck->execute([$studentId, $newYearId]);
        if ($newEnrollCheck->fetch()) {
            $skipped++;
        } else {
            $insertEnrollment->execute([$studentId, $newYearId, $newGradeId]);
            if ($archiveStatus === 'PROMOTED') {
                $promoted++;
            } else {
                $retained++;
            }
        }
        $updateStudentGrade->execute([$newGradeId, $studentId]);
    }

    $pendingStmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM tblenrollment e
        LEFT JOIN tblsectionstudent ss
               ON ss.student_id = e.student_id
              AND ss.academic_year_id = e.academic_year_id
              AND ss.is_active = 1
        WHERE e.academic_year_id = ?
          AND e.is_active = 1
          AND e.enrollment_status IN ('ENROLLED','RETAINED')
          AND ss.id IS NULL
    ");
    $pendingStmt->execute([$newYearId]);
    $pendingSection = (int)$pendingStmt->fetchColumn();

    $insertRun = $pdo->prepare("
        INSERT INTO tblpromotion_runs
            (from_academic_year_id, to_academic_year_id, promoted_count, retained_count,
             graduated_count, archived_count, pending_section_count, run_by, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $insertRun->execute([
        $oldYearId,
        $newYearId,
        $promoted,
        $retained,
        $graduated,
        $archived,
        $pendingSection,
        $adminId,
        'Automatic promotion during academic year activation.'
    ]);

    return [
        'archived' => $archived,
        'promoted' => $promoted,
        'retained' => $retained,
        'graduated' => $graduated,
        'skipped' => $skipped,
        'pending_section' => $pendingSection,
        'already_ran' => false
    ];
}

function getPromotionDashboardStats(PDO $pdo): array
{
    ensurePromotionSchema($pdo);

    $activeYear = $pdo->query("SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    $activeYearId = $activeYear ? (int)$activeYear['id'] : 0;

    $latestRun = $pdo->query("
        SELECT *
        FROM tblpromotion_runs
        ORDER BY run_at DESC, id DESC
        LIMIT 1
    ")->fetch(PDO::FETCH_ASSOC) ?: [];

    $archiveCount = (int)$pdo->query("SELECT COUNT(*) FROM tblstudent_archive")->fetchColumn();

    $pendingSection = 0;
    if ($activeYearId) {
        $pendingStmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM tblenrollment e
            LEFT JOIN tblsectionstudent ss
                   ON ss.student_id = e.student_id
                  AND ss.academic_year_id = e.academic_year_id
                  AND ss.is_active = 1
            WHERE e.academic_year_id = ?
              AND e.is_active = 1
              AND e.enrollment_status IN ('ENROLLED','RETAINED')
              AND ss.id IS NULL
        ");
        $pendingStmt->execute([$activeYearId]);
        $pendingSection = (int)$pendingStmt->fetchColumn();
    }

    return [
        'promoted' => (int)($latestRun['promoted_count'] ?? 0),
        'retained' => (int)($latestRun['retained_count'] ?? 0),
        'graduated' => (int)($latestRun['graduated_count'] ?? 0),
        'archived' => $archiveCount,
        'pending_section' => $pendingSection
    ];
}

?>
