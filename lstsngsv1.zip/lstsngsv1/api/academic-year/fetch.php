<?php
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

$id   = intval($_GET['id'] ?? 0);
$stmt = $pdo->prepare('SELECT id, year_label, is_active
                       FROM tblAcademicYear
                       WHERE id = ?');
$stmt->execute([$id]);
echo json_encode($stmt->fetch(PDO::FETCH_ASSOC) ?: []);