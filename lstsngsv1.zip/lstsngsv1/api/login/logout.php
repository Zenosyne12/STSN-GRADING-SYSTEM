<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../shared/db_connect.php';

// Log the logout before the session is cleared
try {
    $logoutUserId   = (int)($_SESSION['user_id'] ?? $_SESSION['teacher_id'] ?? 0);
    $logoutUserName = (string)($_SESSION['username'] ?? $_SESSION['teacher_name'] ?? '');
    if ($logoutUserId > 0 || $logoutUserName !== '') {
        logActivity($pdo, 'Auth', 'LOGOUT', 'user', $logoutUserId ?: null, 'Signed out');
    }
} catch (Throwable $e) {}

$_SESSION = [];

if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'] ?? '/',
        $params['domain'] ?? '',
        $params['secure'] ?? false,
        $params['httponly'] ?? true
    );
}

session_destroy();

header('Location: /lstsngsv1/login.php');
exit;
