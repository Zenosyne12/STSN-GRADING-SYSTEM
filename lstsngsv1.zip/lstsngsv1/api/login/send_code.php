<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_start();
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/phpmailer.php';
require_once __DIR__ . '/../shared/PasswordValidator.php';
require_once __DIR__ . '/../shared/CSRFToken.php';
require_once __DIR__ . '/../shared/password_reset_store.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: /lstsngsv1/forgot_password.php");
    exit;
}

header('Content-Type: application/json');


$csrfToken = $_POST['_csrf_token'] ?? '';
if (!CSRFToken::verify($csrfToken)) {
    echo json_encode(['success' => false, 'error' => 'Invalid security token']);
    exit;
}


$username = trim($_POST['username'] ?? '');

if (empty($username)) {
    echo json_encode(['success' => false, 'error' => 'Please type the username']);
    exit;
}


if (!filter_var($username, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'error' => 'Please enter your registered Gmail/email username.']);
    exit;
}


$ipAddress = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$rateKey = 'forgot_attempts_' . md5($ipAddress);
$isLocalhost = in_array($ipAddress, ['127.0.0.1', '::1'], true);

if (!isset($_SESSION[$rateKey])) {
    $_SESSION[$rateKey] = ['count' => 0, 'time' => time()];
}

$rateData = $_SESSION[$rateKey];


if (time() - $rateData['time'] > 900) {
    $_SESSION[$rateKey] = ['count' => 0, 'time' => time()];
    $rateData = $_SESSION[$rateKey];
}


if (!$isLocalhost && $rateData['count'] >= 5) {
    echo json_encode([
        'success' => false, 
        'error' => 'Too many attempts. Try again in 15 minutes.'
    ]);
    exit;
}


try {
    ensurePasswordResetTable($pdo);

    $query = "
        SELECT u.id, u.username, u.role_id,
               t.id AS teacher_id, t.email AS teacher_email, t.fname AS teacher_fname, t.lname AS teacher_lname,
               s.id AS student_id, s.email AS student_email, s.fname AS student_fname, s.lname AS student_lname
        FROM tblusers u
        LEFT JOIN tblteacher t ON u.role_id = 2 AND t.id = u.reference_id
        LEFT JOIN tblstudents s ON u.role_id = 3 AND s.id = u.reference_id
        WHERE (u.username = ? OR t.email = ? OR s.email = ?) AND u.status = 'Active'
        LIMIT 1
    ";

    $stmt = $pdo->prepare($query);
    $stmt->execute([$username, $username, $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode([
            'success' => false,
            'error' => 'Username not found or inactive.'
        ]);
        error_log("Forgot password attempt for non-existent/inactive user: {$username}");
        exit;
    }

    
    $email = null;

    if ((int)$user['role_id'] === 2) {
        $email = $user['teacher_email'] ?? null;
    } elseif ((int)$user['role_id'] === 3) {
        $email = $user['student_email'] ?? null;
    }

    if (empty($email)) {
        echo json_encode([
            'success' => false,
            'error' => 'No email address is saved for this account.'
        ]);
        error_log("No email for user: {$username}");
        exit;
    }

    
    
    $letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $code = '';
    
    
    for ($i = 0; $i < 4; $i++) {
        $code .= $letters[rand(0, strlen($letters) - 1)];
    }
    
    
    for ($i = 0; $i < 4; $i++) {
        $code .= rand(0, 9);
    }

    
    
    $cleanup = $pdo->prepare("
        DELETE FROM tblpassword_resets 
        WHERE user_id = ? AND used = 0
    ");
    $cleanup->execute([$user['id']]);

    $insert = $pdo->prepare("
        INSERT INTO tblpassword_resets (user_id, token_hash, expires_at, used)
        VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE), 0)
    ");
    
    $codeHash = hash('sha256', $code);
    $insert->execute([$user['id'], $codeHash]);

    
    $emailSent = false;
    $mailError = '';
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        try {
            $mailer = createMailer();
            $mailer->clearAddresses();
            
            $userName = 'User';
            if ((int)$user['role_id'] === 2) {
                $userName = trim(($user['teacher_fname'] ?? '') . ' ' . ($user['teacher_lname'] ?? ''));
            } elseif ((int)$user['role_id'] === 3) {
                $userName = trim(($user['student_fname'] ?? '') . ' ' . ($user['student_lname'] ?? ''));
            }

            $mailer->addAddress($email, $userName);
            $safeUserName = htmlspecialchars($userName, ENT_QUOTES, 'UTF-8');
            $safeCode = htmlspecialchars($code, ENT_QUOTES, 'UTF-8');
            $verifyUrl = 'http://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . '/lstsngsv1/verify_code.php';
            $safeVerifyUrl = htmlspecialchars($verifyUrl, ENT_QUOTES, 'UTF-8');

            $logoPath = dirname(__DIR__, 2) . '/assets/img/stsn logo.png';
            if (is_file($logoPath)) {
                $mailer->addEmbeddedImage($logoPath, 'stsn-school-logo', 'stsn-logo.png', 'base64', 'image/png');
            }
            $schoolPhotoPath = dirname(__DIR__, 2) . '/assets/img/stsnschool.jpg';
            if (is_file($schoolPhotoPath)) {
                $mailer->addEmbeddedImage($schoolPhotoPath, 'stsn-school-photo', 'stsnschool.jpg', 'base64', 'image/jpeg');
            }
            $lockIconPath = dirname(__DIR__, 2) . '/assets/img/email-lock.svg';
            if (is_file($lockIconPath)) {
                $mailer->addEmbeddedImage($lockIconPath, 'stsn-lock-icon', 'email-lock.svg', 'base64', 'image/svg+xml');
            }

            $mailer->Subject = 'Your Password Reset Code - STSN Grading System';
            $mailer->Body = <<<HTML
<!doctype html>
<html lang="en">
<body style="margin:0;padding:0;background:#f3f4f6;font-family:Segoe UI,Arial,sans-serif;color:#1f2937;">
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="width:100%;background:#f3f4f6;">
        <tr>
            <td align="center" style="padding:24px 12px;">
                <table role="presentation" width="600" cellspacing="0" cellpadding="0" border="0" style="width:100%;max-width:600px;background:#ffffff;">
                    <tr>
                        <td style="padding:30px;background-color:#800000;background-image:linear-gradient(rgba(128,0,0,.82),rgba(86,0,0,.88)),url(cid:stsn-school-photo);background-position:center;background-size:cover;color:#ffffff;">
                            <div style="width:58px;height:58px;padding:6px;border-radius:50%;background:#ffffff;">
                                <img src="cid:stsn-school-logo" width="58" height="58" alt="St. Theresa's National School logo" style="display:block;width:58px;height:58px;border:0;">
                            </div>
                            <div style="margin-top:16px;font-size:18px;font-weight:700;line-height:1.35;">St. Theresa's School of Novaliches, Inc.</div>
                            <div style="margin-top:18px;font-size:24px;font-weight:700;line-height:1.25;">Password Reset Code</div>
                            <div style="margin-top:8px;font-size:16px;line-height:1.5;color:#f8dfe3;">Secure your account</div>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:38px 30px 32px;">
                            <p style="margin:0 0 22px;font-size:16px;font-weight:600;line-height:1.5;">Hello {$safeUserName},</p>
                            <p style="margin:0 0 28px;font-size:14px;line-height:1.6;color:#4b5563;">You requested a password reset. Use the verification code below to continue.</p>

                            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="width:100%;background:#f3f4f6;border:1px solid #e5e7eb;border-radius:12px;">
                                <tr>
                                    <td style="padding:24px;text-align:center;">
                                        <div style="margin-bottom:10px;font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#6b7280;"><img src="cid:stsn-lock-icon" width="14" height="14" alt="" style="display:inline-block;width:14px;height:14px;vertical-align:-2px;border:0;">&nbsp; Password Reset Code</div>
                                        <div style="font-family:Courier New,monospace;font-size:28px;font-weight:700;letter-spacing:3px;line-height:1.4;color:#800000;word-break:break-all;">{$safeCode}</div>
                                    </td>
                                </tr>
                            </table>

                            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="width:100%;margin-top:22px;background:#f5e6e8;border-radius:8px;">
                                <tr>
                                    <td style="padding:14px 16px;font-size:13px;font-weight:500;line-height:1.6;color:#6b1f2a;"><img src="cid:stsn-lock-icon" width="14" height="14" alt="" style="display:inline-block;width:14px;height:14px;vertical-align:-2px;border:0;">&nbsp; This code expires in 10 minutes.<br><span style="font-weight:400;">If you did not request this, please ignore this email.</span></td>
                                </tr>
                            </table>

                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="margin:28px auto 0;">
                                <tr>
                                    <td align="center" style="border-radius:8px;background:#800000;">
                                        <a href="{$safeVerifyUrl}" style="display:inline-block;padding:14px 32px;border-radius:8px;color:#ffffff;font-size:14px;font-weight:700;text-decoration:none;">Enter Reset Code</a>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
HTML;

            $mailer->AltBody = "Hello {$userName},\n\nYour password reset code is: {$code}\n\nThis code expires in 10 minutes.\nIf you did not request this, please ignore this email.\n\nEnter the code at: {$verifyUrl}";
            
            $emailSent = $mailer->send();
            if (!$emailSent) {
                $mailError = $mailer->ErrorInfo;
                error_log("Email send failed for {$email}: " . $mailError);
            }
        } catch (Exception $e) {
            $mailError = $e->getMessage();
            error_log("Email exception for {$email}: " . $mailError);
        }
    } else {
        $mailError = 'Invalid recipient email';
        error_log("Invalid recipient email for username {$username}: {$email}");
    }

    if (!$emailSent) {
        echo json_encode([
            'success' => false,
            'error' => 'Unable to send verification email right now. Please try again in a moment.',
            'debug' => $mailError,
        ]);
        exit;
    }

    
    $_SESSION[$rateKey]['count']++;

    
    echo json_encode([
        'success' => true,
        'message' => 'Code sent! Check your email. Code expires in 10 minutes.',
        'user_id' => $user['id']
    ]);

    error_log("Password reset code sent for user: {$username}");

} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $response = [
        'success' => false,
        'error' => 'Database error while requesting reset code.'
    ];
    if ($isLocalhost) {
        $response['debug'] = $e->getMessage();
    }
    echo json_encode($response);
} catch (Exception $e) {
    error_log("Unexpected error: " . $e->getMessage());
    $response = [
        'success' => false,
        'error' => 'Unexpected error while requesting reset code.'
    ];
    if ($isLocalhost) {
        $response['debug'] = $e->getMessage();
    }
    echo json_encode($response);
}

?>
