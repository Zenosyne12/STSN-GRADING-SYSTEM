<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_start();
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/phpmailer.php';
require_once __DIR__ . '/../shared/PasswordValidator.php';
require_once __DIR__ . '/../shared/CSRFToken.php';
require_once __DIR__ . '/../shared/password_reset_store.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: /lstsngsv1/forgot_password.php");
    exit;
}

header('Content-Type: application/json');

// ==== CSRF VALIDATION ====
$csrfToken = $_POST['_csrf_token'] ?? '';
if (!CSRFToken::verify($csrfToken)) {
    echo json_encode(['success' => false, 'error' => 'Invalid security token']);
    exit;
}

// ==== INPUT VALIDATION ====
$username = trim($_POST['username'] ?? '');

if (empty($username)) {
    echo json_encode(['success' => false, 'error' => 'Please type the username']);
    exit;
}

// Username format validation
if (!preg_match('/^[a-zA-Z0-9_\-]{3,50}$/', $username)) {
    echo json_encode(['success' => false, 'error' => 'Invalid username format']);
    exit;
}

// ==== RATE LIMITING ====
$ipAddress = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$rateKey = 'forgot_attempts_' . md5($ipAddress);
$isLocalhost = in_array($ipAddress, ['127.0.0.1', '::1'], true);

if (!isset($_SESSION[$rateKey])) {
    $_SESSION[$rateKey] = ['count' => 0, 'time' => time()];
}

$rateData = $_SESSION[$rateKey];

// Reset if 15 mins passed
if (time() - $rateData['time'] > 900) {
    $_SESSION[$rateKey] = ['count' => 0, 'time' => time()];
    $rateData = $_SESSION[$rateKey];
}

// Max 5 attempts (skip lock during localhost development/testing)
if (!$isLocalhost && $rateData['count'] >= 5) {
    echo json_encode([
        'success' => false, 
        'error' => 'Too many attempts. Try again in 15 minutes.'
    ]);
    exit;
}

// ==== FIND USER ====
try {
    ensurePasswordResetTable($pdo);

    $query = "
        SELECT u.id, u.username, u.role_id,
               t.id AS teacher_id, t.email AS teacher_email, t.fname, t.lname
        FROM tblusers u
        LEFT JOIN tblteacher t ON u.role_id = 2 AND t.id = u.reference_id
        WHERE u.username = ? AND u.status = 'Active'
        LIMIT 1
    ";

    $stmt = $pdo->prepare($query);
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode([
            'success' => false,
            'error' => 'Username not found or inactive.'
        ]);
        error_log("Forgot password attempt for non-existent/inactive user: {$username}");
        exit;
    }

    // Get email only (SMS is disabled)
    $email = null;

    if ((int)$user['role_id'] === 2) {
        $email = $user['teacher_email'] ?? null;
    }

    if (empty($email)) {
        echo json_encode([
            'success' => false,
            'error' => 'No email address is saved for this account.'
        ]);
        error_log("No email for user: {$username}");
        exit;
    }

    // ==== GENERATE RANDOM CODE ====
    // Format: 4 letters + 3-4 numbers = "ABC12345"
    $letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $code = '';
    
    // Add 4 random letters
    for ($i = 0; $i < 4; $i++) {
        $code .= $letters[rand(0, strlen($letters) - 1)];
    }
    
    // Add 4 random numbers
    for ($i = 0; $i < 4; $i++) {
        $code .= rand(0, 9);
    }

    // ==== STORE CODE IN DATABASE ====
    // Invalidate prior unused codes so only the latest code works.
    $cleanup = $pdo->prepare("
        DELETE FROM tblpassword_resets 
        WHERE user_id = ? AND used = 0
    ");
    $cleanup->execute([$user['id']]);

    $insert = $pdo->prepare("
        INSERT INTO tblpassword_resets (user_id, token_hash, expires_at, used)
        VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE), 0)
    ");
    // Store code as hash for security
    $codeHash = hash('sha256', $code);
    $insert->execute([$user['id'], $codeHash]);

    // ==== SEND EMAIL ====
    $emailSent = false;
    $mailError = '';
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        try {
            $mailer = createMailer();
            $mailer->clearAddresses();
            
            $userName = 'User';
            if ((int)$user['role_id'] === 2) {
                $userName = trim(($user['fname'] ?? '') . ' ' . ($user['lname'] ?? ''));
            }

            $mailer->addAddress($email, $userName);
            $mailer->Subject = 'Your Password Reset Code - STSN Grading System';
            $mailer->Body = "
                <html>
                <body style='font-family: Arial, sans-serif; padding: 20px; color: #333;'>
                    <h2 style='color: #9e112d; border-bottom: 2px solid #9e112d; padding-bottom: 10px;'>
                        🔐 Password Reset Code
                    </h2>
                    <p>Hello <strong>{$userName}</strong>,</p>
                    <p>You requested a password reset. Use this code to reset your password:</p>
                    
                    <div style='text-align: center; margin: 30px 0;'>
                        <div style='background: #f0f0f0; padding: 20px; border-radius: 10px; font-size: 28px; font-weight: bold; letter-spacing: 2px; color: #9e112d;'>
                            {$code}
                        </div>
                    </div>

                    <p style='background: #fff8eb; padding: 15px; border-left: 4px solid #ffc107;'>
                        <strong>⏱️ This code expires in 10 minutes</strong><br>
                        If you didn't request this, please ignore this email.
                    </p>

                    <p style='color: #666; font-size: 0.9rem; margin-top: 30px;'>
                        STSN Grading System<br>
                        St. Theresa's School of Novaliches
                    </p>
                </body>
                </html>
            ";

            $mailer->AltBody = "Your password reset code is: {$code}\n\nThis code expires in 10 minutes.\n\nIf you didn't request this, please ignore.";
            
            $emailSent = $mailer->send();
            if (!$emailSent) {
                $mailError = $mailer->ErrorInfo;
                error_log("Email send failed for {$email}: " . $mailError);
            }
        } catch (Exception $e) {
            $mailError = $e->getMessage();
            error_log("Email exception for {$email}: " . $mailError);
        }
    } else {
        $mailError = 'Invalid recipient email';
        error_log("Invalid recipient email for username {$username}: {$email}");
    }

    if (!$emailSent) {
        echo json_encode([
            'success' => false,
            'error' => 'Unable to send verification email right now. Please try again in a moment.',
            'debug' => $mailError,
        ]);
        exit;
    }

    // Count only successful send requests in rate limiting.
    $_SESSION[$rateKey]['count']++;

    // ==== SUCCESS ====
    echo json_encode([
        'success' => true,
        'message' => 'Code sent! Check your email. Code expires in 10 minutes.',
        'user_id' => $user['id']
    ]);

    error_log("Password reset code sent for user: {$username}");

} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $response = [
        'success' => false,
        'error' => 'Database error while requesting reset code.'
    ];
    if ($isLocalhost) {
        $response['debug'] = $e->getMessage();
    }
    echo json_encode($response);
} catch (Exception $e) {
    error_log("Unexpected error: " . $e->getMessage());
    $response = [
        'success' => false,
        'error' => 'Unexpected error while requesting reset code.'
    ];
    if ($isLocalhost) {
        $response['debug'] = $e->getMessage();
    }
    echo json_encode($response);
}

?>