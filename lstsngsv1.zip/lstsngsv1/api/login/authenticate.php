<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../shared/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /lstsngsv1/login.php');
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($username === '' || $password === '') {
    $_SESSION['login_error'] = 'Username and password are required.';
    header('Location: /lstsngsv1/login.php');
    exit;
}

$sql = "
    SELECT id, username, password_hash, reference_id, role_id, status, must_change_password
    FROM tblusers
    WHERE username = ?
    LIMIT 1
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$username]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    $_SESSION['login_error'] = 'Invalid username or password.';
    header('Location: /lstsngsv1/login.php');
    exit;
}

if (isset($user['status']) && strtolower((string) $user['status']) !== 'active') {
    $_SESSION['login_error'] = 'Your account is inactive.';
    header('Location: /lstsngsv1/login.php');
    exit;
}

$storedPassword = (string) ($user['password_hash'] ?? '');
$validPassword = false;

if ($storedPassword !== '') {
    $info = password_get_info($storedPassword);

    if (!empty($info['algo'])) {
        $validPassword = password_verify($password, $storedPassword);
    } else {
        $validPassword = hash_equals($storedPassword, $password);
    }
}

if (!$validPassword) {
    $_SESSION['login_error'] = 'Invalid username or password.';
    header('Location: /lstsngsv1/login.php');
    exit;
}

$teacher = null;

if ((int) ($user['role_id'] ?? 0) === 2) {
    if (empty($user['reference_id'])) {
        $_SESSION['login_error'] = 'Teacher account is not linked to a teacher profile.';
        header('Location: /lstsngsv1/login.php');
        exit;
    }

    $teacherSql = "
        SELECT id, teacher_id, fname, mname, lname, email, is_active
        FROM tblteacher
        WHERE id = ?
        LIMIT 1
    ";

    $teacherStmt = $pdo->prepare($teacherSql);
    $teacherStmt->execute([(int) $user['reference_id']]);
    $teacher = $teacherStmt->fetch(PDO::FETCH_ASSOC);

    if (!$teacher) {
        $_SESSION['login_error'] = 'Linked teacher profile was not found.';
        header('Location: /lstsngsv1/login.php');
        exit;
    }

    if ((int) ($teacher['is_active'] ?? 0) !== 1) {
        $_SESSION['login_error'] = 'Your teacher profile is inactive.';
        header('Location: /lstsngsv1/login.php');
        exit;
    }
}

$_SESSION = [];
session_regenerate_id(true);

$_SESSION['user_id'] = (int) $user['id'];
$_SESSION['reference_id'] = isset($user['reference_id']) ? (int) $user['reference_id'] : null;
$_SESSION['role_id'] = isset($user['role_id']) ? (int) $user['role_id'] : null;
$_SESSION['username'] = $user['username'];
$_SESSION['must_change_password'] = isset($user['must_change_password']) ? (int) $user['must_change_password'] : 0;

unset($_SESSION['teacher_id'], $_SESSION['teacher_name'], $_SESSION['teacher_email'], $_SESSION['teacher_code']);

if ($_SESSION['must_change_password'] === 1) {
    header('Location: /lstsngsv1/change-password.php');
    exit;
}

if ((int) ($user['role_id'] ?? 0) === 2 && $teacher) {
    $teacherFullName = trim(
        ($teacher['fname'] ?? '') . ' ' .
        ($teacher['mname'] ?? '') . ' ' .
        ($teacher['lname'] ?? '')
    );

    $_SESSION['teacher_id'] = (int) $teacher['id'];
    $_SESSION['teacher_code'] = $teacher['teacher_id'] ?? '';
    $_SESSION['teacher_name'] = preg_replace('/\s+/', ' ', $teacherFullName);
    $_SESSION['teacher_email'] = $teacher['email'] ?? '';

    header('Location: /lstsngsv1/pages/Dashboard.php');
    exit;
}

header('Location: /lstsngsv1/Dashboard.php');
exit;