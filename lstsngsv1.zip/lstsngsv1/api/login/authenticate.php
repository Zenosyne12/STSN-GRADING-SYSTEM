<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../shared/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /lstsngsv1/login.php');
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($username === '' || $password === '') {
    $_SESSION['login_error'] = 'Username and password are required.';
    header('Location: /lstsngsv1/login.php');
    exit;
}

$sql = "
    SELECT u.id, u.username, u.password_hash, u.reference_id, u.role_id, u.status, u.must_change_password,
           t.email AS teacher_email,
           s.email AS student_email
    FROM tblusers u
    LEFT JOIN tblteacher t ON u.role_id = 2 AND t.id = u.reference_id
    LEFT JOIN tblstudents s ON u.role_id = 3 AND s.id = u.reference_id
    WHERE u.username = ?
       OR (u.role_id = 2 AND t.email = ?)
       OR (u.role_id = 3 AND s.email = ?)
    LIMIT 1
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$username, $username, $username]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    $_SESSION['login_error'] = 'Invalid username or password.';
    try {
        logActivity($pdo, 'Auth', 'LOGIN', 'user', null, 'Failed sign-in attempt');
    } catch (Throwable $e) {}
    header('Location: /lstsngsv1/login.php');
    exit;
}

if (isset($user['status']) && strtolower((string) $user['status']) !== 'active') {
    $_SESSION['login_error'] = 'Your account is inactive.';
    try {
        logActivity($pdo, 'Auth', 'LOGIN', 'user', null, 'Failed sign-in attempt');
    } catch (Throwable $e) {}
    header('Location: /lstsngsv1/login.php');
    exit;
}

$storedPassword = (string) ($user['password_hash'] ?? '');
$validPassword = false;

if ($storedPassword !== '') {
    $info = password_get_info($storedPassword);

    if (!empty($info['algo'])) {
        $validPassword = password_verify($password, $storedPassword);
    } else {
        $validPassword = hash_equals($storedPassword, $password);
    }
}

if (!$validPassword) {
    $_SESSION['login_error'] = 'Invalid username or password.';
    try {
        logActivity($pdo, 'Auth', 'LOGIN', 'user', null, 'Failed sign-in attempt');
    } catch (Throwable $e) {}
    header('Location: /lstsngsv1/login.php');
    exit;
}

$loginEmail = '';
if ((int)($user['role_id'] ?? 0) === 2) {
    $loginEmail = trim((string)($user['teacher_email'] ?? ''));
} elseif ((int)($user['role_id'] ?? 0) === 3) {
    $loginEmail = trim((string)($user['student_email'] ?? ''));
}

if ($loginEmail !== '' && filter_var($loginEmail, FILTER_VALIDATE_EMAIL) && strcasecmp((string)$user['username'], $loginEmail) !== 0) {
    $checkUsername = $pdo->prepare("SELECT id FROM tblusers WHERE username = ? AND id <> ? LIMIT 1");
    $checkUsername->execute([$loginEmail, (int)$user['id']]);
    if (!$checkUsername->fetch(PDO::FETCH_ASSOC)) {
        $syncUsername = $pdo->prepare("UPDATE tblusers SET username = ? WHERE id = ?");
        $syncUsername->execute([$loginEmail, (int)$user['id']]);
        $user['username'] = $loginEmail;
    }
}

$teacher = null;

if ((int) ($user['role_id'] ?? 0) === 2) {
    if (empty($user['reference_id'])) {
        $_SESSION['login_error'] = 'Teacher account is not linked to a teacher profile.';
        header('Location: /lstsngsv1/login.php');
        exit;
    }

    $teacherSql = "
        SELECT id, teacher_id, fname, mname, lname, email, is_active
        FROM tblteacher
        WHERE id = ?
        LIMIT 1
    ";

    $teacherStmt = $pdo->prepare($teacherSql);
    $teacherStmt->execute([(int) $user['reference_id']]);
    $teacher = $teacherStmt->fetch(PDO::FETCH_ASSOC);

    if (!$teacher) {
        $_SESSION['login_error'] = 'Linked teacher profile was not found.';
        header('Location: /lstsngsv1/login.php');
        exit;
    }

    if ((int) ($teacher['is_active'] ?? 0) !== 1) {
        $_SESSION['login_error'] = 'Your teacher profile is inactive.';
        header('Location: /lstsngsv1/login.php');
        exit;
    }
}

$_SESSION = [];
session_regenerate_id(true);

$_SESSION['user_id'] = (int) $user['id'];
$_SESSION['reference_id'] = isset($user['reference_id']) ? (int) $user['reference_id'] : null;
$_SESSION['role_id'] = isset($user['role_id']) ? (int) $user['role_id'] : null;
$_SESSION['username'] = $user['username'];
$_SESSION['must_change_password'] = isset($user['must_change_password']) ? (int) $user['must_change_password'] : 0;

try {
    logActivity($pdo, 'Auth', 'LOGIN', 'user', (int) $user['id'], 'Signed in');
} catch (Throwable $e) {}

try {
    require_once __DIR__ . '/../shared/settings_schema.php';
    stsnEnsureSettingsSchema($pdo);
    $themeStmt = $pdo->prepare('SELECT theme_preference FROM tblusers WHERE id = ? LIMIT 1');
    $themeStmt->execute([(int) $user['id']]);
    $loginTheme = (string) ($themeStmt->fetchColumn() ?: 'light');
    if (!in_array($loginTheme, ['dark', 'light'], true)) {
        $loginTheme = 'light';
    }
    $_SESSION['theme_preference'] = $loginTheme;
    setcookie('stsn_theme', $loginTheme, [
        'expires' => time() + 60 * 60 * 24 * 365,
        'path' => '/',
        'httponly' => false,
        'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
} catch (Throwable $e) {
    $_SESSION['theme_preference'] = 'light';
}

unset($_SESSION['teacher_id'], $_SESSION['teacher_name'], $_SESSION['teacher_email'], $_SESSION['teacher_code']);

if ($_SESSION['must_change_password'] === 1) {
    header('Location: /lstsngsv1/change-password.php');
    exit;
}

// Route to correct dashboard based on role
$role_id = (int) ($user['role_id'] ?? 0);

if ($role_id === 2 && $teacher) {
    // TEACHER - redirect to teacher dashboard
    $teacherFullName = trim(
        ($teacher['fname'] ?? '') . ' ' .
        ($teacher['mname'] ?? '') . ' ' .
        ($teacher['lname'] ?? '')
    );

    $_SESSION['teacher_id'] = (int) $teacher['id'];
    $_SESSION['teacher_code'] = $teacher['teacher_id'] ?? '';
    $_SESSION['teacher_name'] = preg_replace('/\s+/', ' ', $teacherFullName);
    $_SESSION['teacher_email'] = $teacher['email'] ?? '';

    header('Location: /lstsngsv1/pages/Dashboard.php');
    exit;
}

if ($role_id === 1) {
    // ADMIN - redirect to admin dashboard
    header('Location: /lstsngsv1/Dashboard.php');
    exit;
}

if ($role_id === 4) {
    // SUPER ADMIN - redirect to super admin dashboard
    header('Location: /lstsngsv1/SuperAdmin/Dashboard.php');
    exit;
}

if ($role_id === 3) {
    // STUDENT - redirect to student dashboard
    header('Location: /lstsngsv1/pages/Dashboard.php');
    exit;
}

// DEFAULT - redirect to main dashboard
header('Location: /lstsngsv1/Dashboard.php');
exit;
