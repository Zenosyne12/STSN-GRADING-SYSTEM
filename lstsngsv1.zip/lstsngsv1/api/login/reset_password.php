<?php
session_start();
require_once __DIR__ . '/api/shared/CSRFToken.php';

// Check if code was verified
if (!isset($_SESSION['code_verified']) || !isset($_SESSION['reset_user_id'])) {
    header("Location: forgot_password.php");
    exit;
}

$csrfToken = CSRFToken::generate();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - STSN Grading System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="css/login.css">

    <style>
        :root {
            --maroon: #9e112d;
            --maroon-dark: #7d0d24;
            --navy: #173b67;
            --text: #2b2b2b;
            --muted: #777;
            --border: #e6d9dc;
            --input-bg: rgba(255, 255, 255, 0.92);
            --danger-bg: #fff1f3;
            --danger-border: #f3c3cb;
            --danger-text: #8a1830;
            --success-color: #198754;
        }
        * { box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; }
        
        .main-wrapper {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }
        .password-card {
            width: 100%;
            max-width: 430px;
            background: rgba(255, 255, 255, 0.96);
            border-radius: 22px;
            padding: 30px 26px 24px;
            box-shadow: 0 22px 60px rgba(0, 0, 0, 0.22);
            border: 1px solid rgba(255, 255, 255, 0.45);
            backdrop-filter: blur(6px);
        }
        .brand {
            text-align: center;
            margin-bottom: 20px;
        }
        .brand-logo {
            width: 76px; height: 76px;
            margin: 0 auto 14px;
            border-radius: 18px;
            background: linear-gradient(145deg, #fff, #f7efef);
            border: 1px solid var(--border);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 10px 22px rgba(158, 17, 45, 0.08);
        }
        .brand-logo img {
            width: 50px; height: 50px;
            object-fit: contain;
        }
        .brand h1 {
            margin: 0;
            font-size: 1.9rem;
            font-weight: 700;
            color: var(--maroon);
            line-height: 1.1;
        }
        .brand p {
            margin: 8px auto 0;
            max-width: 300px;
            font-size: .93rem;
            color: var(--muted);
        }
        .school-name {
            margin-top: 10px;
            font-size: .8rem;
            font-weight: 700;
            color: var(--navy);
            text-transform: uppercase;
            letter-spacing: .04em;
        }
        
        .alert-box {
            display: flex;
            gap: 10px;
            align-items: flex-start;
            border-radius: 14px;
            padding: 12px 13px;
            margin-bottom: 16px;
            font-size: .88rem;
        }
        .alert-error {
            background: var(--danger-bg);
            border: 1px solid var(--danger-border);
            color: var(--danger-text);
        }
        
        .hint-box {
            background: #fff8eb;
            border: 1px solid #f1dfb6;
            color: #7a5d23;
            border-radius: 14px;
            padding: 12px 13px;
            margin-bottom: 18px;
            font-size: .84rem;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-size: .9rem;
            font-weight: 700;
            color: #56494b;
        }
        .input-wrap {
            position: relative;
        }
        .input-icon {
            position: absolute;
            top: 50%; left: 14px;
            transform: translateY(-50%);
            color: #9a8d8f;
            font-size: .95rem;
        }
        .form-control {
            width: 100%;
            height: 54px;
            border: 1px solid var(--border);
            border-radius: 15px;
            background: var(--input-bg);
            padding: 0 44px 0 42px;
            font-family: inherit;
            font-size: .95rem;
            color: var(--text);
            outline: none;
            transition: .18s ease;
        }
        .form-control:focus {
            border-color: rgba(158, 17, 45, .45);
            box-shadow: 0 0 0 4px rgba(158, 17, 45, 0.08);
            background: #fff;
        }
        
        .toggle-password {
            position: absolute;
            top: 50%; right: 13px;
            transform: translateY(-50%);
            background: transparent;
            border: none;
            color: #988b8d;
            cursor: pointer;
            padding: 0;
            font-size: 1rem;
        }
        
        .helper-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            flex-wrap: wrap;
            margin: 6px 0 18px;
        }
        .show-pass {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: .88rem;
            color: var(--muted);
            user-select: none;
        }
        .show-pass input {
            width: 16px; height: 16px;
            accent-color: var(--maroon);
        }
        .match-text {
            min-height: 18px;
            font-size: .82rem;
            font-weight: 600;
        }
        .match-ok { color: var(--success-color); }
        .match-bad { color: var(--maroon); }
        
        /* Password strength indicator */
        .strength-box {
            background: #f9f9f9;
            border: 1px solid #e0e0e0;
            border-radius: 12px;
            padding: 12px;
            margin-bottom: 15px;
            display: none;
        }
        .strength-box.show {
            display: block;
        }
        .strength-title {
            font-size: 0.8rem;
            font-weight: 700;
            color: #333;
            margin-bottom: 8px;
        }
        .strength-meter {
            width: 100%;
            height: 6px;
            background: #e0e0e0;
            border-radius: 3px;
            overflow: hidden;
            margin-bottom: 8px;
        }
        .strength-bar {
            height: 100%;
            background: var(--danger-text);
            width: 0%;
            transition: width 0.3s, background 0.3s;
        }
        .strength-bar.weak { background: #dc3545; width: 33%; }
        .strength-bar.fair { background: #ff9800; width: 66%; }
        .strength-bar.strong { background: var(--success-color); width: 100%; }
        
        .strength-label {
            font-size: 0.75rem;
            font-weight: 600;
        }
        .strength-label.weak { color: #dc3545; }
        .strength-label.fair { color: #ff9800; }
        .strength-label.strong { color: var(--success-color); }
        
        .requirements {
            font-size: 0.8rem;
            margin-top: 8px;
        }
        .requirement {
            display: flex;
            align-items: center;
            gap: 6px;
            margin: 4px 0;
            color: #999;
        }
        .requirement.met {
            color: var(--success-color);
        }
        .requirement.unmet {
            color: var(--danger-text);
        }
        
        .submit-btn {
            width: 100%;
            height: 54px;
            border: none;
            border-radius: 15px;
            background: linear-gradient(135deg, var(--maroon), var(--maroon-dark));
            color: #fff;
            font-family: inherit;
            font-size: .94rem;
            font-weight: 700;
            letter-spacing: .02em;
            cursor: pointer;
            box-shadow: 0 14px 28px rgba(158, 17, 45, 0.22);
            transition: .18s ease;
        }
        .submit-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        .submit-btn:hover:not(:disabled) {
            transform: translateY(-1px);
            box-shadow: 0 16px 32px rgba(158, 17, 45, 0.26);
        }
        
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: var(--maroon);
            text-decoration: none;
            font-weight: 600;
            font-size: .9rem;
        }
        
        @media (max-width: 480px) {
            .main-wrapper { padding: 16px; }
            .password-card { padding: 24px 18px 20px; }
            .brand h1 { font-size: 1.65rem; }
        }
    </style>
</head>
<body>
    <div class="main-wrapper">
        <div class="password-card">
            <div class="brand">
                <div class="brand-logo">
                    <img src="assets/img/stsn logo.png" alt="STSN Logo">
                </div>
                <h1>Reset Password</h1>
                <p>Enter your new password</p>
                <div class="school-name">St. Theresa's School of Novaliches</div>
            </div>

            <div id="errorBox" class="alert-box alert-error" style="display: none;">
                <i class="bi bi-exclamation-octagon-fill"></i>
                <div id="errorMessage"></div>
            </div>

            <div class="hint-box">
                <i class="bi bi-shield-check me-2"></i>
                Password must be strong: 8+ chars, uppercase, lowercase, number, special character.
            </div>

            <form id="resetForm">
                <input type="hidden" name="_csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">

                <div class="form-group">
                    <label class="form-label" for="new_password">New Password</label>
                    <div class="input-wrap">
                        <i class="bi bi-lock-fill input-icon"></i>
                        <input
                            type="password"
                            class="form-control"
                            name="new_password"
                            id="new_password"
                            placeholder="Enter new password"
                            required
                            minlength="8"
                            maxlength="128"
                            autofocus
                        >
                        <button type="button" class="toggle-password" data-target="new_password">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>

                    <!-- Strength Indicator -->
                    <div class="strength-box" id="strengthBox">
                        <div class="strength-title">Password Strength</div>
                        <div class="strength-meter">
                            <div class="strength-bar" id="strengthBar"></div>
                        </div>
                        <div class="strength-label" id="strengthLabel"></div>
                        
                        <div class="requirements">
                            <div class="requirement" id="req-length">
                                <i class="bi bi-circle-fill"></i> At least 8 characters
                            </div>
                            <div class="requirement" id="req-upper">
                                <i class="bi bi-circle-fill"></i> One uppercase letter (A-Z)
                            </div>
                            <div class="requirement" id="req-lower">
                                <i class="bi bi-circle-fill"></i> One lowercase letter (a-z)
                            </div>
                            <div class="requirement" id="req-number">
                                <i class="bi bi-circle-fill"></i> One number (0-9)
                            </div>
                            <div class="requirement" id="req-special">
                                <i class="bi bi-circle-fill"></i> One special character (!@#$%^&* etc)
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="confirm_password">Confirm Password</label>
                    <div class="input-wrap">
                        <i class="bi bi-shield-check input-icon"></i>
                        <input
                            type="password"
                            class="form-control"
                            name="confirm_password"
                            id="confirm_password"
                            placeholder="Confirm new password"
                            required
                            minlength="8"
                            maxlength="128"
                        >
                        <button type="button" class="toggle-password" data-target="confirm_password">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                </div>

                <div class="helper-row">
                    <label class="show-pass">
                        <input type="checkbox" id="showAllPass">
                        <span>Show password</span>
                    </label>
                    <div id="matchText" class="match-text"></div>
                </div>

                <button type="submit" class="submit-btn" id="submitBtn" disabled>
                    RESET PASSWORD <i class="bi bi-arrow-right ms-1"></i>
                </button>
            </form>

            <a href="forgot_password.php" class="back-link">
                <i class="bi bi-arrow-left me-2"></i>Start over
            </a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const newPassword = document.getElementById('new_password');
            const confirmPassword = document.getElementById('confirm_password');
            const showAllPass = document.getElementById('showAllPass');
            const matchText = document.getElementById('matchText');
            const submitBtn = document.getElementById('submitBtn');
            const form = document.getElementById('resetForm');
            const strengthBox = document.getElementById('strengthBox');
            const errorBox = document.getElementById('errorBox');
            const errorMessage = document.getElementById('errorMessage');

            const requirements = {
                length: { elem: document.getElementById('req-length'), regex: /.{8,}/, met: false },
                upper: { elem: document.getElementById('req-upper'), regex: /[A-Z]/, met: false },
                lower: { elem: document.getElementById('req-lower'), regex: /[a-z]/, met: false },
                number: { elem: document.getElementById('req-number'), regex: /[0-9]/, met: false },
                special: { elem: document.getElementById('req-special'), regex: /[!@#$%^&*()_\-+=\[\]{};:\'",.<>?\/\\|`~]/, met: false }
            };

            function checkPasswordStrength(password) {
                let metCount = 0;

                for (const [key, req] of Object.entries(requirements)) {
                    req.met = req.regex.test(password);
                    metCount += req.met ? 1 : 0;

                    if (req.elem) {
                        req.elem.classList.remove('met', 'unmet');
                        req.elem.classList.add(req.met ? 'met' : 'unmet');
                    }
                }

                return metCount;
            }

            function updateStrengthIndicator(password) {
                const strengthBar = document.getElementById('strengthBar');
                const strengthLabel = document.getElementById('strengthLabel');
                const metCount = checkPasswordStrength(password);

                if (password.length === 0) {
                    strengthBox.classList.remove('show');
                    return;
                }

                strengthBox.classList.add('show');
                strengthBar.className = 'strength-bar';
                strengthLabel.className = 'strength-label';

                if (metCount < 3) {
                    strengthBar.classList.add('weak');
                    strengthLabel.classList.add('weak');
                    strengthLabel.textContent = 'Weak';
                } else if (metCount < 5) {
                    strengthBar.classList.add('fair');
                    strengthLabel.classList.add('fair');
                    strengthLabel.textContent = 'Fair';
                } else {
                    strengthBar.classList.add('strong');
                    strengthLabel.classList.add('strong');
                    strengthLabel.textContent = 'Strong';
                }
            }

            function updateMatchStatus() {
                const a = newPassword.value;
                const b = confirmPassword.value;

                matchText.textContent = '';
                matchText.className = 'match-text';

                if (!a || !b) return;

                if (a === b) {
                    matchText.textContent = '✓ Passwords match';
                    matchText.classList.add('match-ok');
                } else {
                    matchText.textContent = '✗ Passwords do not match';
                    matchText.classList.add('match-bad');
                }
            }

            function updateSubmitButton() {
                const allMet = Object.values(requirements).every(req => req.met);
                const passwordsMatch = newPassword.value === confirmPassword.value;
                submitBtn.disabled = !(allMet && passwordsMatch && newPassword.value.length > 0);
            }

            // Event listeners
            newPassword.addEventListener('input', function () {
                updateStrengthIndicator(this.value);
                updateMatchStatus();
                updateSubmitButton();
            });

            confirmPassword.addEventListener('input', function () {
                updateMatchStatus();
                updateSubmitButton();
            });

            showAllPass.addEventListener('change', function () {
                const type = this.checked ? 'text' : 'password';
                newPassword.type = type;
                confirmPassword.type = type;

                document.querySelectorAll('.toggle-password i').forEach(icon => {
                    icon.className = this.checked ? 'bi bi-eye-slash' : 'bi bi-eye';
                });
            });

            document.querySelectorAll('.toggle-password').forEach(button => {
                button.addEventListener('click', function () {
                    const target = document.getElementById(this.dataset.target);
                    const icon = this.querySelector('i');
                    const show = target.type === 'password';

                    target.type = show ? 'text' : 'password';
                    icon.className = show ? 'bi bi-eye-slash' : 'bi bi-eye';

                    if (newPassword.type === 'text' && confirmPassword.type === 'text') {
                        showAllPass.checked = true;
                    } else if (newPassword.type === 'password' && confirmPassword.type === 'password') {
                        showAllPass.checked = false;
                    }
                });
            });

            // Form submission
            form.addEventListener('submit', function (e) {
                e.preventDefault();

                const allMet = Object.values(requirements).every(req => req.met);
                if (!allMet || newPassword.value !== confirmPassword.value) {
                    errorMessage.textContent = 'Please meet all password requirements';
                    errorBox.style.display = 'flex';
                    return;
                }

                submitBtn.disabled = true;
                submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Resetting...';

                // Submit to API
                fetch('api/login/do_reset_password.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'new_password=' + encodeURIComponent(newPassword.value) +
                          '&_csrf_token=' + encodeURIComponent(document.querySelector('input[name="_csrf_token"]').value)
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        // Redirect to login
                        window.location.href = 'login.php?success=password_reset';
                    } else {
                        errorMessage.textContent = data.error || 'Error resetting password';
                        errorBox.style.display = 'flex';
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = 'RESET PASSWORD <i class="bi bi-arrow-right ms-1"></i>';
                    }
                })
                .catch(err => {
                    errorMessage.textContent = 'Error resetting password. Please try again.';
                    errorBox.style.display = 'flex';
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = 'RESET PASSWORD <i class="bi bi-arrow-right ms-1"></i>';
                });
            });
        });
    </script>
</body>
</html>