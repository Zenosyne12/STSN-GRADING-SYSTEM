<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../shared/db_connect.php';

requireTeacher();

$teacherId = (int) ($_SESSION['teacher_id'] ?? 0);
$referenceId = (int) ($_SESSION['reference_id'] ?? 0);

if ($teacherId <= 0 || $referenceId <= 0 || $teacherId !== $referenceId) {
    $_SESSION = [];
    session_destroy();
    header('Location: /lstsngsv1/login.php');
    exit;
}

$stmt = $pdo->prepare("
    SELECT id, teacher_id, fname, mname, lname, email, is_active
    FROM tblteacher
    WHERE id = ?
    LIMIT 1
");
$stmt->execute([$teacherId]);
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$teacher) {
    $_SESSION = [];
    session_destroy();
    header('Location: /lstsngsv1/login.php');
    exit;
}

if ((int) ($teacher['is_active'] ?? 0) !== 1) {
    $_SESSION = [];
    session_destroy();
    header('Location: /lstsngsv1/login.php');
    exit;
}

$teacherFullName = trim(
    ($teacher['fname'] ?? '') . ' ' .
    ($teacher['mname'] ?? '') . ' ' .
    ($teacher['lname'] ?? '')
);

$_SESSION['teacher_id'] = (int) $teacher['id'];
$_SESSION['teacher_code'] = $teacher['teacher_id'] ?? '';
$_SESSION['teacher_name'] = trim(preg_replace('/\s+/', ' ', $teacherFullName));
$_SESSION['teacher_email'] = $teacher['email'] ?? '';

/* =====================================================================
   POSITION + ASSIGNMENT BASED ACCESS CONTROL (sidebar + page guards)
   ===================================================================== */

/**
 * Teacher position: 'Teacher', 'Adviser', 'Subject Coordinator',
 * 'Principal' or 'Registrar'.
 */
function getTeacherPosition(PDO $pdo, int $teacherId): string
{
    static $cache = [];
    if (array_key_exists($teacherId, $cache)) {
        return $cache[$teacherId];
    }
    $stmt = $pdo->prepare("SELECT position FROM tblteacher WHERE id = ? LIMIT 1");
    $stmt->execute([$teacherId]);
    $cache[$teacherId] = (string) ($stmt->fetchColumn() ?: 'Teacher');
    return $cache[$teacherId];
}

/** True when the teacher has any advisory assignment (tblsectionadviser). */
function isTeacherAdviser(PDO $pdo, int $teacherId): bool
{
    static $cache = [];
    if (array_key_exists($teacherId, $cache)) {
        return $cache[$teacherId];
    }
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM tblsectionadviser WHERE teacher_id = ?");
    $stmt->execute([$teacherId]);
    $cache[$teacherId] = ((int) $stmt->fetchColumn() > 0);
    return $cache[$teacherId];
}

/** True when a position may approve / review grade submissions. */
function isTeacherApprover(string $position): bool
{
    return in_array($position, ['Adviser', 'Subject Coordinator', 'Principal'], true);
}

/**
 * True when the teacher is assigned to a Kindergarten section, by schedule
 * or adviser assignment (grade_level_code 0).
 * NOTE: tblgradelevel.grade_level_code is numeric (0 = Kinder), not 'K'.
 */
function isTeacherK3(PDO $pdo, int $teacherId): bool
{
    static $cache = [];
    if (array_key_exists($teacherId, $cache)) {
        return $cache[$teacherId];
    }
    $result = false;
    try {
        $stmt = $pdo->prepare("
            SELECT (
                (SELECT COUNT(*)
                   FROM tblschedule sch
                   JOIN tblsection s     ON s.id = sch.section_id
                   JOIN tblgradelevel gl ON gl.id = s.grade_level_id
                  WHERE sch.teacher_id = ?
                    AND sch.is_active = 1
                    AND gl.grade_level_code = 0)
              + (SELECT COUNT(*)
                   FROM tblsectionadviser sa
                   JOIN tblsection s     ON s.id = sa.section_id
                   JOIN tblgradelevel gl ON gl.id = s.grade_level_id
                  WHERE sa.teacher_id = ?
                    AND gl.grade_level_code = 0)
            ) AS k3_count
        ");
        $stmt->execute([$teacherId, $teacherId]);
        $result = ((int) $stmt->fetchColumn() > 0);
    } catch (Throwable $e) {
        $result = false;
    }
    $cache[$teacherId] = $result;
    return $result;
}

/** Deny access: set a flash message and bounce back to the dashboard. */
function stsnDenyAccess(string $message): void
{
    $_SESSION['flash_error'] = $message;
    header('Location: Dashboard.php');
    exit;
}

/** Guard: Adviser only (server-side; the sidebar already hides the link). */
function requireAdviser(): void
{
    global $pdo;
    if (!($pdo instanceof PDO)) {
        require_once __DIR__ . '/../shared/db_connect.php';
    }
    $teacherId = (int) ($_SESSION['teacher_id'] ?? 0);
    if (!isTeacherAdviser($pdo, $teacherId)) {
        stsnDenyAccess('Access denied: Adviser only.');
    }
}

/** Guard: Approver only (Adviser / Subject Coordinator / Principal). */
function requireApprover(): void
{
    global $pdo;
    if (!($pdo instanceof PDO)) {
        require_once __DIR__ . '/../shared/db_connect.php';
    }
    $teacherId = (int) ($_SESSION['teacher_id'] ?? 0);
    $position  = getTeacherPosition($pdo, $teacherId);
    if (!isTeacherApprover($position) && !isTeacherAdviser($pdo, $teacherId)) {
        stsnDenyAccess('Access denied: Approver only.');
    }
}

/** Guard: K-3 assignment required. */
function requireK3(): void
{
    global $pdo;
    if (!($pdo instanceof PDO)) {
        require_once __DIR__ . '/../shared/db_connect.php';
    }
    $teacherId = (int) ($_SESSION['teacher_id'] ?? 0);
    if (!isTeacherK3($pdo, $teacherId)) {
        stsnDenyAccess('Access denied: K-3 teachers only.');
    }
}