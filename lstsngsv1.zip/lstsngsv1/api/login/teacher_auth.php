<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../shared/db_connect.php';

requireTeacher();

$teacherId = (int) ($_SESSION['teacher_id'] ?? 0);
$referenceId = (int) ($_SESSION['reference_id'] ?? 0);

if ($teacherId <= 0 || $referenceId <= 0 || $teacherId !== $referenceId) {
    $_SESSION = [];
    session_destroy();
    header('Location: /lstsngsv1/login.php');
    exit;
}

$stmt = $pdo->prepare("
    SELECT id, teacher_id, fname, mname, lname, email, is_active
    FROM tblteacher
    WHERE id = ?
    LIMIT 1
");
$stmt->execute([$teacherId]);
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$teacher) {
    $_SESSION = [];
    session_destroy();
    header('Location: /lstsngsv1/login.php');
    exit;
}

if ((int) ($teacher['is_active'] ?? 0) !== 1) {
    $_SESSION = [];
    session_destroy();
    header('Location: /lstsngsv1/login.php');
    exit;
}

$teacherFullName = trim(
    ($teacher['fname'] ?? '') . ' ' .
    ($teacher['mname'] ?? '') . ' ' .
    ($teacher['lname'] ?? '')
);

$_SESSION['teacher_id'] = (int) $teacher['id'];
$_SESSION['teacher_code'] = $teacher['teacher_id'] ?? '';
$_SESSION['teacher_name'] = trim(preg_replace('/\s+/', ' ', $teacherFullName));
$_SESSION['teacher_email'] = $teacher['email'] ?? '';