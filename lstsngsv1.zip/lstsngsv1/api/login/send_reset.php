<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_start();
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/phpmailer.php';
require_once __DIR__ . '/../../api/shared/PasswordValidator.php';
require_once __DIR__ . '/../../api/shared/CSRFToken.php';
require_once __DIR__ . '/../shared/password_reset_store.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: /lstsngsv1/forgot_password.php");
    exit;
}


$csrfToken = $_POST['_csrf_token'] ?? '';
if (!CSRFToken::verify($csrfToken)) {
    $_SESSION['reset_error'] = 'Invalid security token. Please try again.';
    header("Location: /lstsngsv1/forgot_password.php");
    exit;
}


$username = trim($_POST['username'] ?? '');


if (empty($username)) {
    $_SESSION['reset_error'] = 'Username is required.';
    header("Location: /lstsngsv1/forgot_password.php");
    exit;
}


if (!filter_var($username, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['reset_error'] = 'Please enter your registered Gmail/email username.';
    header("Location: /lstsngsv1/forgot_password.php");
    exit;
}



$ipAddress = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$rateKey = 'reset_attempts_' . md5($ipAddress);

if (!isset($_SESSION[$rateKey])) {
    $_SESSION[$rateKey] = ['count' => 0, 'time' => time()];
}

$rateData = $_SESSION[$rateKey];


if (time() - $rateData['time'] > 900) {
    $_SESSION[$rateKey] = ['count' => 0, 'time' => time()];
    $rateData = $_SESSION[$rateKey];
}


if ($rateData['count'] >= 5) {
    $_SESSION['reset_error'] = 'Too many reset requests. Please try again in 15 minutes.';
    header("Location: /lstsngsv1/forgot_password.php");
    exit;
}


$_SESSION[$rateKey]['count']++;


$_SESSION['reset_message'] = 'If that username exists, a password reset link has been sent to the associated email. The link expires in 1 hour.';
header("Location: /lstsngsv1/forgot_password.php");


try {
    ensurePasswordResetTable($pdo);

    
    $query = "
        SELECT u.id, u.username, u.role_id, NULL AS admin_email,
               t.email AS teacher_email, t.fname AS teacher_fname, t.lname AS teacher_lname,
               s.email AS student_email, s.fname AS student_fname, s.lname AS student_lname
        FROM tblusers u
        LEFT JOIN tblteacher t ON u.role_id = 2 AND t.id = u.reference_id
        LEFT JOIN tblstudents s ON u.role_id = 3 AND s.id = u.reference_id
        WHERE (u.username = ? OR t.email = ? OR s.email = ?) AND u.status = 'Active'
        LIMIT 1
    ";

    $stmt = $pdo->prepare($query);
    $stmt->execute([$username, $username, $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        
        error_log("Password reset attempted for non-existent username: {$username} from IP: {$ipAddress}");
        exit;
    }

    
    $email = null;
    $userName = '';

    if ((int)$user['role_id'] === 1) {
        
        $email = $user['admin_email'];
        $userName = 'Admin';
    } elseif ((int)$user['role_id'] === 2) {
        
        $email = $user['teacher_email'];
        $userName = trim(($user['teacher_fname'] ?? '') . ' ' . ($user['teacher_lname'] ?? ''));
    } elseif ((int)$user['role_id'] === 3) {
        $email = $user['student_email'];
        $userName = trim(($user['student_fname'] ?? '') . ' ' . ($user['student_lname'] ?? ''));
    }

    if (empty($email)) {
        error_log("Password reset attempt for user without email: {$username}");
        exit;
    }

    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        error_log("Invalid email format stored for user: {$username}");
        exit;
    }

    
    $cleanup = $pdo->prepare("
        DELETE FROM tblpassword_resets 
        WHERE user_id = ? AND used = 0 AND expires_at < NOW()
    ");
    $cleanup->execute([$user['id']]);

    
    $token = bin2hex(random_bytes(32)); 
    $tokenHash = hash('sha256', $token); 
    
    $insert = $pdo->prepare("
        INSERT INTO tblpassword_resets (user_id, token_hash, expires_at, used)
        VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR), 0)
    ");
    $insert->execute([$user['id'], $tokenHash]);

    
    $resetLink = "https://" . $_SERVER['HTTP_HOST'] . "/lstsngsv1/reset_password.php?token=" . urlencode($token);

    $mail = createMailer();
    $mail->addAddress($email, $userName);
    $mail->Subject = 'Password Reset Request - STSN Grading System';

    $mail->Body = "
        <html>
        <body style='font-family: Arial, sans-serif; padding: 20px; color: #333;'>
            <h2 style='color: #9e112d; border-bottom: 2px solid #9e112d; padding-bottom: 10px;'>
                <i>🔐</i> Password Reset Request
            </h2>
            <p>Hello <strong>{$userName}</strong>,</p>
            <p>You requested a password reset for your account. Click the button below to set a new password:</p>
            
            <div style='text-align: center; margin: 30px 0;'>
                <a href='{$resetLink}' 
                   style='background: #9e112d; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; font-weight: bold;'>
                    RESET PASSWORD
                </a>
            </div>

            <p style='background: #f9f9f9; padding: 10px; border-left: 3px solid #ffc107; margin: 20px 0;'>
                <strong>⏱️ This link expires in 1 hour</strong><br>
                If you didn't request this reset, please ignore this email and contact your administrator.
            </p>

            <p style='color: #666; font-size: 0.9rem; margin-top: 30px;'>
                If the button doesn't work, copy this link:<br>
                <code style='background: #f0f0f0; padding: 5px 10px; display: block; word-break: break-all; margin: 10px 0;'>{$resetLink}</code>
            </p>

            <hr style='border: none; border-top: 1px solid #ddd; margin: 30px 0;'>
            <p style='color: #999; font-size: 0.85rem;'>
                STSN Grading System<br>
                St. Theresa's School of Novaliches
            </p>
        </body>
        </html>
    ";

    $mail->AltBody = "
        Password Reset Request

        Hello {$userName},

        Click here to reset your password (expires in 1 hour):
        {$resetLink}

        If you didn't request this, please ignore this email.

        STSN Administration
    ";

    if (!$mail->send()) {
        error_log("Email send failed for password reset: " . $mail->ErrorInfo);
    }

} catch (Exception $e) {
    error_log("Password reset error: " . $e->getMessage());
}

exit;
?>
