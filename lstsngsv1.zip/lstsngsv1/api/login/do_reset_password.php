<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_start();
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/PasswordValidator.php';
require_once __DIR__ . '/../shared/CSRFToken.php';
require_once __DIR__ . '/../shared/password_reset_store.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

header('Content-Type: application/json');

// ==== CHECK SESSION ====
if (!isset($_SESSION['code_verified']) || !isset($_SESSION['reset_user_id']) || !isset($_SESSION['reset_id'])) {
    echo json_encode(['success' => false, 'error' => 'Session expired. Start over.']);
    exit;
}

// ==== CSRF VALIDATION ====
$csrfToken = $_POST['_csrf_token'] ?? '';
if (!CSRFToken::verify($csrfToken)) {
    echo json_encode(['success' => false, 'error' => 'Invalid security token']);
    exit;
}

// ==== INPUT VALIDATION ====
$newPassword = $_POST['new_password'] ?? '';

// Validate password strength
$validation = PasswordValidator::validate($newPassword);
if (!$validation['valid']) {
    echo json_encode([
        'success' => false,
        'error' => 'Password too weak: ' . implode(', ', $validation['errors'])
    ]);
    exit;
}

try {
    ensurePasswordResetTable($pdo);

    $user_id = $_SESSION['reset_user_id'];
    $reset_id = $_SESSION['reset_id'];

    // ==== VERIFY RESET RECORD STILL EXISTS AND IS UNUSED ====
    $stmt = $pdo->prepare("
        SELECT id, used, expires_at
        FROM tblpassword_resets
        WHERE id = ? AND user_id = ? AND used = 0 AND expires_at > NOW()
        LIMIT 1
    ");
    $stmt->execute([$reset_id, $user_id]);
    $resetRecord = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$resetRecord) {
        echo json_encode(['success' => false, 'error' => 'Code has expired. Request a new one.']);
        exit;
    }

    // ==== HASH AND UPDATE PASSWORD ====
    $passwordHash = PasswordValidator::hash($newPassword);

    $update = $pdo->prepare("
        UPDATE tblusers
        SET password_hash = ?, must_change_password = 0, updated_at = NOW()
        WHERE id = ?
    ");
    $update->execute([$passwordHash, $user_id]);

    // ==== MARK CODE AS USED ====
    $markUsed = $pdo->prepare("
        UPDATE tblpassword_resets
        SET used = 1
        WHERE id = ?
    ");
    $markUsed->execute([$reset_id]);

    // ==== CLEANUP OLD RESET RECORDS ====
    $cleanup = $pdo->prepare("
        DELETE FROM tblpassword_resets
        WHERE user_id = ? AND (expires_at < NOW() OR used = 1)
    ");
    $cleanup->execute([$user_id]);

    // ==== CLEAR SESSION ====
    unset($_SESSION['code_verified']);
    unset($_SESSION['reset_user_id']);
    unset($_SESSION['reset_id']);

    echo json_encode([
        'success' => true,
        'message' => 'Password reset successfully! Redirecting to login...'
    ]);

    error_log("Password reset successfully for user_id: {$user_id}");

} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Error resetting password. Please try again.'
    ]);
} catch (Exception $e) {
    error_log("Unexpected error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'An error occurred. Please try again.'
    ]);
}

?>