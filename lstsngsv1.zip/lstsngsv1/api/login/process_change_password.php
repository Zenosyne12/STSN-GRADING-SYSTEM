<?php
session_start();
require_once __DIR__ . '/../shared/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /lstsngsv1/login.php');
    exit;
}

if (!isset($_SESSION['user_id'])) {
    header('Location: /lstsngsv1/login.php');
    exit;
}

$newPassword = trim($_POST['new_password'] ?? '');
$confirmPassword = trim($_POST['confirm_password'] ?? '');

if ($newPassword === '' || $confirmPassword === '') {
    header('Location: /lstsngsv1/change-password.php?error=' . urlencode('Both password fields are required.'));
    exit;
}

if (strlen($newPassword) < 6) {
    header('Location: /lstsngsv1/change-password.php?error=' . urlencode('Password must be at least 6 characters long.'));
    exit;
}

if ($newPassword !== $confirmPassword) {
    header('Location: /lstsngsv1/change-password.php?error=' . urlencode('Passwords do not match.'));
    exit;
}

try {
    $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);

    $update = $pdo->prepare("
        UPDATE tblusers
        SET password_hash = ?, must_change_password = 0
        WHERE id = ? AND status = 'Active'
        LIMIT 1
    ");
    $update->execute([$passwordHash, (int) $_SESSION['user_id']]);

    if ($update->rowCount() < 1) {
        header('Location: /lstsngsv1/change-password.php?error=' . urlencode('Unable to update password. Please try again.'));
        exit;
    }

    $_SESSION['must_change_password'] = 0;
    header('Location: /lstsngsv1/login.php?success=password_changed');
    exit;
} catch (Throwable $e) {
    error_log('process_change_password error: ' . $e->getMessage());
    header('Location: /lstsngsv1/change-password.php?error=' . urlencode('Server error while changing password.'));
    exit;
}