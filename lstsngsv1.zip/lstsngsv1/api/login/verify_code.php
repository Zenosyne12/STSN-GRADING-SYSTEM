<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_start();
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/CSRFToken.php';
require_once __DIR__ . '/../shared/password_reset_store.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

header('Content-Type: application/json');
$ipAddress = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$isLocalhost = in_array($ipAddress, ['127.0.0.1', '::1'], true);

// ==== CSRF VALIDATION ====
$csrfToken = $_POST['_csrf_token'] ?? '';
if (!CSRFToken::verify($csrfToken)) {
    echo json_encode(['success' => false, 'error' => 'Invalid security token']);
    exit;
}

// ==== INPUT VALIDATION ====
$user_id = (int)($_POST['user_id'] ?? 0);
$code = trim($_POST['code'] ?? '');
$normalizedCode = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $code));

if ($user_id <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid user ID']);
    exit;
}

if (empty($normalizedCode) || strlen($normalizedCode) !== 8) {
    echo json_encode(['success' => false, 'error' => 'Invalid code format']);
    exit;
}

try {
    ensurePasswordResetTable($pdo);

    // ==== FIND AND VALIDATE CODE ====
    $codeHash = hash('sha256', $normalizedCode);
    $stmt = $pdo->prepare("
        SELECT id, user_id, token_hash, expires_at, used
        FROM tblpassword_resets
        WHERE token_hash = ? AND used = 0 AND expires_at > NOW()
        ORDER BY created_at DESC
        LIMIT 1
    ");
    $stmt->execute([$codeHash]);
    $record = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$record) {
        $response = ['success' => false, 'error' => 'Invalid code'];
        if ($isLocalhost) {
            $countStmt = $pdo->prepare("
                SELECT COUNT(*) AS total
                FROM tblpassword_resets
                WHERE used = 0 AND expires_at > NOW()
            ");
            $countStmt->execute();
            $activeTotal = (int)($countStmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0);
            $response['debug'] = 'No hash match in active codes. Active records: ' . $activeTotal . ', code: ' . $normalizedCode;
        }
        echo json_encode($response);
        error_log("Invalid code/no hash match for code: {$normalizedCode}");
        exit;
    }

    $user_id = (int)$record['user_id'];

    // ==== CODE IS VALID - MARK FOR NEXT STEP ====
    // Store reset_id in session so password reset page can use it
    $_SESSION['reset_id'] = $record['id'];
    $_SESSION['reset_user_id'] = $user_id;
    $_SESSION['code_verified'] = true;

    echo json_encode([
        'success' => true,
        'message' => 'Code verified! You can now reset your password.'
    ]);

    error_log("Code verified successfully for user_id: {$user_id}");

} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $response = [
        'success' => false,
        'error' => 'Error verifying code. Please try again.'
    ];
    if ($isLocalhost) {
        $response['debug'] = $e->getMessage();
    }
    echo json_encode($response);
} catch (Exception $e) {
    error_log("Unexpected error: " . $e->getMessage());
    $response = [
        'success' => false,
        'error' => 'An error occurred. Please try again.'
    ];
    if ($isLocalhost) {
        $response['debug'] = $e->getMessage();
    }
    echo json_encode($response);
}

?>