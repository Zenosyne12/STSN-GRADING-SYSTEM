<?php
declare(strict_types=1);

header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/grade_workflow.php';

if (empty($_SESSION['user_id']) && empty($_SESSION['admin_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated.']);
    exit;
}

function dashRespond(bool $success, array $payload = [], string $message = ''): void
{
    echo json_encode(array_merge([
        'success' => $success,
        'message' => $message,
        'generated_at' => date('Y-m-d H:i:s'),
    ], $payload), JSON_NUMERIC_CHECK);
    exit;
}

function dashTableExists(PDO $pdo, string $table): bool
{
    static $cache = [];
    if (isset($cache[$table])) {
        return $cache[$table];
    }
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = :table_name
    ");
    $stmt->execute([':table_name' => $table]);
    return $cache[$table] = ((int) $stmt->fetchColumn() > 0);
}

function dashColumnExists(PDO $pdo, string $table, string $column): bool
{
    static $cache = [];
    $key = $table . '.' . $column;
    if (isset($cache[$key])) {
        return $cache[$key];
    }
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = :table_name
          AND COLUMN_NAME = :column_name
    ");
    $stmt->execute([':table_name' => $table, ':column_name' => $column]);
    return $cache[$key] = ((int) $stmt->fetchColumn() > 0);
}

function dashCount(PDO $pdo, string $sql, array $params = []): int
{
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (int) $stmt->fetchColumn();
}

function dashRows(PDO $pdo, string $sql, array $params = []): array
{
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function dashOne(PDO $pdo, string $sql, array $params = []): ?array
{
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function dashPercent(int|float $part, int|float $total): float
{
    return $total > 0 ? round(((float) $part / (float) $total) * 100, 1) : 0.0;
}

function dashAssignmentsSql(bool $filterScheduleYear = true): string
{
    $scheduleWhere = $filterScheduleYear ? "AND sc.school_year = :school_year" : "";
    return "
        SELECT DISTINCT sts.teacher_id, sts.section_id, sts.subject_id
        FROM tblsection_teacher_subject sts
        WHERE COALESCE(sts.is_active, 1) = 1
        UNION
        SELECT DISTINCT sc.teacher_id, sc.section_id, sc.subject_id
        FROM tblschedule sc
        WHERE COALESCE(sc.is_active, 1) = 1 {$scheduleWhere}
    ";
}

function dashDeadlineRows(PDO $pdo, string $schoolYear, int $quarter, int $totalAssignments, int $submittedAssignments, int $totalAdvisers, int $submittedAdvisers): array
{
    if (!dashTableExists($pdo, 'tbldeadlines')) {
        return [];
    }

    $select = ['id', 'school_year', 'quarter'];
    foreach (['teacher_deadline', 'adviser_deadline', 'attendance_deadline'] as $column) {
        if (dashColumnExists($pdo, 'tbldeadlines', $column)) {
            $select[] = $column;
        }
    }

    $rows = dashRows(
        $pdo,
        "SELECT " . implode(', ', $select) . "
         FROM tbldeadlines
         WHERE school_year = :school_year
         ORDER BY quarter ASC, id DESC
         LIMIT 8",
        [':school_year' => $schoolYear]
    );

    $mapped = [];
    foreach ($rows as $row) {
        $defs = [
            ['type' => 'Grade Submission', 'column' => 'teacher_deadline', 'done' => $submittedAssignments, 'total' => $totalAssignments],
            ['type' => 'Report Card Finalization', 'column' => 'adviser_deadline', 'done' => $submittedAdvisers, 'total' => $totalAdvisers],
            ['type' => 'Attendance Encoding', 'column' => 'attendance_deadline', 'done' => 0, 'total' => $totalAdvisers],
            ['type' => 'Character Evaluation', 'column' => 'adviser_deadline', 'done' => 0, 'total' => $totalAdvisers],
        ];

        foreach ($defs as $def) {
            if (empty($row[$def['column']])) {
                continue;
            }
            $due = strtotime((string) $row[$def['column']]);
            $seconds = $due ? $due - time() : 0;
            $mapped[] = [
                'id' => (int) $row['id'],
                'type' => $def['type'],
                'quarter' => (int) $row['quarter'],
                'due_at' => $row[$def['column']],
                'due_display' => date('M d, Y h:i A', $due),
                'seconds_remaining' => $seconds,
                'status' => $seconds < 0 ? 'Overdue' : ($seconds <= 86400 ? 'Due Soon' : 'Open'),
                'completion' => dashPercent((int) $def['done'], (int) $def['total']),
            ];
        }
    }

    return $mapped;
}

try {
    ensureGradeWorkflowSchema($pdo);

    $activeYear = dashOne($pdo, "SELECT id, year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
    $activeYearId = (int) ($activeYear['id'] ?? 0);
    $schoolYear = (string) ($activeYear['year_label'] ?? '');

    $activeQuarter = dashOne(
        $pdo,
        "SELECT quarter_number, quarter_label
         FROM tblquarters
         WHERE academic_year_id = :year_id AND is_active = 1
         ORDER BY quarter_number ASC
         LIMIT 1",
        [':year_id' => $activeYearId]
    );
    $quarter = (int) ($activeQuarter['quarter_number'] ?? 1);

    $totalStudents = dashCount($pdo, "SELECT COUNT(*) FROM tblstudents WHERE COALESCE(is_active, 1) = 1");
    $totalTeachers = dashCount($pdo, "SELECT COUNT(*) FROM tblteacher WHERE COALESCE(is_active, 1) = 1");
    $totalSections = dashCount($pdo, "SELECT COUNT(*) FROM tblsection WHERE COALESCE(is_active, 1) = 1");
    $totalSubjects = dashCount($pdo, "SELECT COUNT(*) FROM tblsubjects WHERE COALESCE(is_active, 1) = 1");

    $assignmentParams = [':school_year' => $schoolYear];
    $assignmentsSql = dashAssignmentsSql();
    $totalAssignments = dashCount($pdo, "SELECT COUNT(*) FROM ({$assignmentsSql}) a", $assignmentParams);
    $submittedAssignments = dashCount(
        $pdo,
        "SELECT COUNT(*) FROM (
            SELECT DISTINCT teacher_id, section_id, subject_id
            FROM tblteacher_submissions
            WHERE school_year = :school_year AND quarter = :quarter
        ) s",
        [':school_year' => $schoolYear, ':quarter' => $quarter]
    );

    $totalAdvisers = dashCount(
        $pdo,
        "SELECT COUNT(*)
         FROM tblsectionadviser sa
         WHERE sa.academic_year_id = :year_id",
        [':year_id' => $activeYearId]
    );
    $submittedAdvisers = dashCount(
        $pdo,
        "SELECT COUNT(*) FROM (
            SELECT DISTINCT teacher_id, section_id
            FROM tbladviser_submissions
            WHERE school_year = :school_year
              AND quarter = :quarter
              AND " . officialAdviserSubmissionSql('tbladviser_submissions') . "
        ) s",
        [':school_year' => $schoolYear, ':quarter' => $quarter]
    );

    $attendanceSubmitted = 0;
    if (dashTableExists($pdo, 'tblattendance_records')) {
        $attendanceSubmitted = dashCount(
            $pdo,
            "SELECT COUNT(DISTINCT section_id)
             FROM tblattendance_records
             WHERE academic_year_id = :year_id",
            [':year_id' => $activeYearId]
        );
    }

    $characterSubmitted = 0;
    if (dashTableExists($pdo, 'tbldeportment_records')) {
        $characterSubmitted = dashCount(
            $pdo,
            "SELECT COUNT(DISTINCT section_id)
             FROM tbldeportment_records
             WHERE academic_year_id = :year_id AND quarter = :quarter",
            [':year_id' => $activeYearId, ':quarter' => $quarter]
        );
    }

    $studentAverages = dashRows(
        $pdo,
        "SELECT g.student_id, AVG(NULLIF(g.final_grade, 0)) AS avg_grade
         FROM tblgrades g
         WHERE g.academic_year_id = :year_id
           AND " . officialGradeExistsSql('g') . "
         GROUP BY g.student_id",
        [':year_id' => $activeYearId]
    );

    $honors = [
        'with_highest_honors' => 0,
        'with_high_honors' => 0,
        'with_honors' => 0,
        'no_honors' => 0,
    ];
    foreach ($studentAverages as $avgRow) {
        $avg = (float) ($avgRow['avg_grade'] ?? 0);
        if ($avg >= 98) {
            $honors['with_highest_honors']++;
        } elseif ($avg >= 95) {
            $honors['with_high_honors']++;
        } elseif ($avg >= 90) {
            $honors['with_honors']++;
        } else {
            $honors['no_honors']++;
        }
    }
    $honorStudents = $honors['with_highest_honors'] + $honors['with_high_honors'] + $honors['with_honors'];

    $failingStudentIds = dashRows(
        $pdo,
        "SELECT DISTINCT g.student_id
         FROM tblgrades g
         WHERE g.academic_year_id = :year_id
           AND " . officialGradeExistsSql('g') . "
           AND (g.final_grade < 75 OR g.final_grade = 0 OR g.remarks = 'Failed')",
        [':year_id' => $activeYearId]
    );
    $atRiskIds = array_fill_keys(array_map('intval', array_column($failingStudentIds, 'student_id')), true);

    if (dashTableExists($pdo, 'tblattendance_records')) {
        $lowAttendance = dashRows(
            $pdo,
            "SELECT student_id
             FROM tblattendance_records
             WHERE academic_year_id = :year_id
             GROUP BY student_id
             HAVING SUM(days_present) / NULLIF(SUM(school_days), 0) < .80",
            [':year_id' => $activeYearId]
        );
        foreach ($lowAttendance as $row) {
            $atRiskIds[(int) $row['student_id']] = true;
        }
    }

    $gradeLevelProgress = dashRows(
        $pdo,
        "SELECT
            gl.grade_level_name,
            COUNT(DISTINCT CONCAT(a.teacher_id, '-', a.section_id, '-', a.subject_id)) AS total_count,
            COUNT(DISTINCT CONCAT(ts.teacher_id, '-', ts.section_id, '-', ts.subject_id)) AS submitted_count
         FROM ({$assignmentsSql}) a
         INNER JOIN tblsection sec ON sec.id = a.section_id
         INNER JOIN tblgradelevel gl ON gl.id = sec.grade_level_id
         LEFT JOIN tblteacher_submissions ts
           ON ts.teacher_id = a.teacher_id
          AND ts.section_id = a.section_id
          AND ts.subject_id = a.subject_id
          AND ts.school_year = :school_year_sub
          AND ts.quarter = :quarter
         GROUP BY gl.id, gl.grade_level_name, gl.sort_order
         ORDER BY gl.sort_order ASC",
        [
            ':school_year' => $schoolYear,
            ':school_year_sub' => $schoolYear,
            ':quarter' => $quarter,
        ]
    );
    foreach ($gradeLevelProgress as &$row) {
        $row['percent'] = dashPercent((int) $row['submitted_count'], (int) $row['total_count']);
        $row['pending_count'] = max(0, (int) $row['total_count'] - (int) $row['submitted_count']);
    }
    unset($row);

    $subjectMonitoring = dashRows(
        $pdo,
        "SELECT
            sub.subject_name,
            COUNT(DISTINCT CONCAT(a.teacher_id, '-', a.section_id)) AS total_count,
            COUNT(DISTINCT CONCAT(ts.teacher_id, '-', ts.section_id)) AS submitted_count
         FROM ({$assignmentsSql}) a
         INNER JOIN tblsubjects sub ON sub.id = a.subject_id
         LEFT JOIN tblteacher_submissions ts
           ON ts.teacher_id = a.teacher_id
          AND ts.section_id = a.section_id
          AND ts.subject_id = a.subject_id
          AND ts.school_year = :school_year_sub
          AND ts.quarter = :quarter
         GROUP BY sub.id, sub.subject_name
         ORDER BY submitted_count ASC, sub.subject_name ASC
         LIMIT 10",
        [
            ':school_year' => $schoolYear,
            ':school_year_sub' => $schoolYear,
            ':quarter' => $quarter,
        ]
    );

    $adviserCompletion = dashRows(
        $pdo,
        "SELECT
            sec.section_name,
            gl.grade_level_name,
            CONCAT(t.fname, ' ', t.lname) AS adviser_name,
            CASE
                WHEN ads.id IS NULL THEN 'Pending'
                ELSE CONCAT('Submitted ', DATE_FORMAT(ads.submitted_at, '%b %d, %Y'))
            END AS status
         FROM tblsectionadviser sa
         INNER JOIN tblsection sec ON sec.id = sa.section_id
         INNER JOIN tblgradelevel gl ON gl.id = sec.grade_level_id
         INNER JOIN tblteacher t ON t.id = sa.teacher_id
         LEFT JOIN tbladviser_submissions ads
          ON ads.teacher_id = sa.teacher_id
         AND ads.section_id = sa.section_id
         AND ads.school_year = :school_year
         AND ads.quarter = :quarter
         AND " . officialAdviserSubmissionSql('ads') . "
         WHERE sa.academic_year_id = :year_id
         ORDER BY status ASC, gl.sort_order ASC, sec.section_name ASC
         LIMIT 8",
        [':school_year' => $schoolYear, ':quarter' => $quarter, ':year_id' => $activeYearId]
    );

    $averageByGrade = dashRows(
        $pdo,
        "SELECT gl.grade_level_name AS label, ROUND(AVG(NULLIF(g.final_grade, 0)), 2) AS value
         FROM tblgrades g
         INNER JOIN tblsection sec ON sec.id = g.section_id
         INNER JOIN tblgradelevel gl ON gl.id = sec.grade_level_id
         WHERE g.academic_year_id = :year_id
           AND " . officialGradeExistsSql('g') . "
         GROUP BY gl.id, gl.grade_level_name, gl.sort_order
         ORDER BY gl.sort_order ASC",
        [':year_id' => $activeYearId]
    );
    $passFail = dashOne(
        $pdo,
        "SELECT
            COUNT(DISTINCT CASE WHEN final_grade >= 75 THEN student_id END) AS passing,
            COUNT(DISTINCT CASE WHEN final_grade < 75 AND final_grade > 0 THEN student_id END) AS failing
         FROM tblgrades
         WHERE academic_year_id = :year_id
           AND " . officialGradeExistsSql('tblgrades') . "",
        [':year_id' => $activeYearId]
    ) ?: ['passing' => 0, 'failing' => 0];
    $subjectPerformance = dashRows(
        $pdo,
        "SELECT sub.subject_name AS label, ROUND(AVG(NULLIF(g.final_grade, 0)), 2) AS value
         FROM tblgrades g
         INNER JOIN tblsubjects sub ON sub.id = g.subject_id
         WHERE g.academic_year_id = :year_id
           AND " . officialGradeExistsSql('g') . "
         GROUP BY sub.id, sub.subject_name
         ORDER BY value DESC, sub.subject_name ASC
         LIMIT 10",
        [':year_id' => $activeYearId]
    );
    $quarterTrend = dashRows(
        $pdo,
        "SELECT CONCAT('Q', g.quarter) AS label, ROUND(AVG(NULLIF(g.final_grade, 0)), 2) AS value
         FROM tblgrades g
         WHERE g.academic_year_id = :year_id
           AND " . officialGradeExistsSql('g') . "
         GROUP BY g.quarter
         ORDER BY g.quarter ASC",
        [':year_id' => $activeYearId]
    );
    $strandPerformance = dashRows(
        $pdo,
        "SELECT COALESCE(NULLIF(sec.strand, ''), NULLIF(st.strand, ''), 'Non-SHS') AS label,
                ROUND(AVG(NULLIF(g.final_grade, 0)), 2) AS value
         FROM tblgrades g
         INNER JOIN tblstudents st ON st.id = g.student_id
         INNER JOIN tblsection sec ON sec.id = g.section_id
         WHERE g.academic_year_id = :year_id
           AND " . officialGradeExistsSql('g') . "
         GROUP BY label
         ORDER BY value DESC",
        [':year_id' => $activeYearId]
    );
    $honorDistribution = dashRows(
        $pdo,
        "SELECT
            gl.grade_level_name AS label,
            SUM(CASE WHEN student_avg.avg_grade >= 90 THEN 1 ELSE 0 END) AS value
         FROM (
            SELECT g.student_id, g.section_id, AVG(NULLIF(g.final_grade, 0)) AS avg_grade
            FROM tblgrades g
            WHERE g.academic_year_id = :year_id
              AND " . officialGradeExistsSql('g') . "
            GROUP BY g.student_id, g.section_id
         ) student_avg
         INNER JOIN tblsection sec ON sec.id = student_avg.section_id
         INNER JOIN tblgradelevel gl ON gl.id = sec.grade_level_id
         GROUP BY gl.id, gl.grade_level_name, gl.sort_order
         ORDER BY gl.sort_order ASC",
        [':year_id' => $activeYearId]
    );

    $sectionRanking = dashRows(
        $pdo,
        "SELECT
            sec.section_name,
            gl.grade_level_name,
            ROUND(AVG(NULLIF(g.final_grade, 0)), 2) AS average_grade,
            COUNT(DISTINCT CASE WHEN student_avg.avg_grade >= 90 THEN student_avg.student_id END) AS honor_count
         FROM tblsection sec
         INNER JOIN tblgradelevel gl ON gl.id = sec.grade_level_id
         LEFT JOIN tblgrades g ON g.section_id = sec.id AND g.academic_year_id = :year_id AND " . officialGradeExistsSql('g') . "
         LEFT JOIN (
            SELECT student_id, section_id, AVG(NULLIF(final_grade, 0)) AS avg_grade
            FROM tblgrades g2
            WHERE academic_year_id = :year_id2
              AND " . officialGradeExistsSql('g2') . "
            GROUP BY student_id, section_id
         ) student_avg ON student_avg.section_id = sec.id
         WHERE COALESCE(sec.is_active, 1) = 1
         GROUP BY sec.id, sec.section_name, gl.grade_level_name, gl.sort_order
         HAVING average_grade IS NOT NULL
         ORDER BY average_grade DESC, honor_count DESC
         LIMIT 8",
        [':year_id' => $activeYearId, ':year_id2' => $activeYearId]
    );
    foreach ($sectionRanking as $idx => &$row) {
        $row['rank'] = $idx + 1;
    }
    unset($row);

    $teacherWorkload = dashRows(
        $pdo,
        "SELECT
            t.id AS teacher_id,
            CONCAT(t.fname, ' ', t.lname) AS teacher_name,
            COUNT(DISTINCT CONCAT(a.section_id, '-', a.subject_id)) AS subject_load,
            GROUP_CONCAT(DISTINCT adv.section_name ORDER BY adv.section_name SEPARATOR ', ') AS advisory_class,
            COUNT(DISTINCT ts.id) AS submitted_count,
            COUNT(DISTINCT CONCAT(a.section_id, '-', a.subject_id)) - COUNT(DISTINCT ts.id) AS pending_count
         FROM tblteacher t
         LEFT JOIN ({$assignmentsSql}) a ON a.teacher_id = t.id
         LEFT JOIN tblteacher_submissions ts
           ON ts.teacher_id = t.id
          AND ts.section_id = a.section_id
          AND ts.subject_id = a.subject_id
          AND ts.school_year = :school_year_sub
          AND ts.quarter = :quarter
         LEFT JOIN tblsectionadviser sa ON sa.teacher_id = t.id AND sa.academic_year_id = :year_id
         LEFT JOIN tblsection adv ON adv.id = sa.section_id
         WHERE COALESCE(t.is_active, 1) = 1
         GROUP BY t.id, t.fname, t.lname
         ORDER BY pending_count DESC, subject_load DESC, teacher_name ASC
         LIMIT 12",
        [
            ':school_year' => $schoolYear,
            ':school_year_sub' => $schoolYear,
            ':quarter' => $quarter,
            ':year_id' => $activeYearId,
        ]
    );

    $recentActivities = [];
    $recentActivities = array_merge($recentActivities, dashRows(
        $pdo,
        "SELECT 'Teacher grade submission' AS type,
                CONCAT(CONCAT(t.fname, ' ', t.lname), ' submitted ', sub.subject_name, ' for ', sec.section_name) AS description,
                ts.submitted_at AS happened_at
         FROM tblteacher_submissions ts
         INNER JOIN tblteacher t ON t.id = ts.teacher_id
         INNER JOIN tblsubjects sub ON sub.id = ts.subject_id
         INNER JOIN tblsection sec ON sec.id = ts.section_id
         WHERE ts.school_year = :school_year
         ORDER BY ts.submitted_at DESC
         LIMIT 8",
        [':school_year' => $schoolYear]
    ));
    $recentActivities = array_merge($recentActivities, dashRows(
        $pdo,
        "SELECT 'Adviser submission' AS type,
                CONCAT(CONCAT(t.fname, ' ', t.lname), ' submitted advisory records for ', sec.section_name) AS description,
                ads.submitted_at AS happened_at
         FROM tbladviser_submissions ads
         INNER JOIN tblteacher t ON t.id = ads.teacher_id
         INNER JOIN tblsection sec ON sec.id = ads.section_id
         WHERE ads.school_year = :school_year
           AND " . officialAdviserSubmissionSql('ads') . "
         ORDER BY ads.submitted_at DESC
         LIMIT 8",
        [':school_year' => $schoolYear]
    ));
    if (dashTableExists($pdo, 'tblattendance_records')) {
        $recentActivities = array_merge($recentActivities, dashRows(
            $pdo,
            "SELECT 'Attendance update' AS type,
                    CONCAT(sec.section_name, ' attendance imported for ', ar.month_name) AS description,
                    MAX(ar.imported_at) AS happened_at
             FROM tblattendance_records ar
             INNER JOIN tblsection sec ON sec.id = ar.section_id
             WHERE ar.academic_year_id = :year_id
             GROUP BY ar.section_id, ar.month_number, ar.month_name
             ORDER BY happened_at DESC
             LIMIT 6",
            [':year_id' => $activeYearId]
        ));
    }
    if (dashTableExists($pdo, 'tbldeportment_records')) {
        $recentActivities = array_merge($recentActivities, dashRows(
            $pdo,
            "SELECT 'Character evaluation update' AS type,
                    CONCAT(sec.section_name, ' character ratings updated for Q', dr.quarter) AS description,
                    MAX(dr.updated_at) AS happened_at
             FROM tbldeportment_records dr
             INNER JOIN tblsection sec ON sec.id = dr.section_id
             WHERE dr.academic_year_id = :year_id
             GROUP BY dr.section_id, dr.quarter
             ORDER BY happened_at DESC
             LIMIT 6",
            [':year_id' => $activeYearId]
        ));
    }
    $recentActivities = array_merge($recentActivities, dashRows(
        $pdo,
        "SELECT title AS type, message AS description, created_at AS happened_at
         FROM system_notifications
         ORDER BY created_at DESC
         LIMIT 8"
    ));
    usort($recentActivities, static fn($a, $b) => strtotime((string) ($b['happened_at'] ?? '')) <=> strtotime((string) ($a['happened_at'] ?? '')));
    $recentActivities = array_slice($recentActivities, 0, 12);

    $atRiskRows = dashRows(
        $pdo,
        "SELECT
            st.id,
            st.lrn,
            CONCAT(st.fname, ' ', st.lname) AS student_name,
            gl.grade_level_name,
            ROUND(AVG(NULLIF(g.final_grade, 0)), 2) AS average_grade,
            SUM(CASE WHEN g.final_grade < 75 OR g.final_grade = 0 OR g.remarks = 'Failed' THEN 1 ELSE 0 END) AS failing_entries
         FROM tblstudents st
         LEFT JOIN tblgrades g ON g.student_id = st.id AND g.academic_year_id = :year_id AND " . officialGradeExistsSql('g') . "
         LEFT JOIN tblenrollment e ON e.student_id = st.id AND e.academic_year_id = :year_id2
         LEFT JOIN tblgradelevel gl ON gl.id = COALESCE(e.grade_level_id, st.grade_level_id)
         WHERE st.id IN (" . (count($atRiskIds) ? implode(',', array_map('intval', array_keys($atRiskIds))) : '0') . ")
         GROUP BY st.id, st.lrn, st.fname, st.lname, gl.grade_level_name
         ORDER BY failing_entries DESC, average_grade ASC
         LIMIT 10",
        [':year_id' => $activeYearId, ':year_id2' => $activeYearId]
    );

    $deadlineRows = dashDeadlineRows($pdo, $schoolYear, $quarter, $totalAssignments, $submittedAssignments, $totalAdvisers, $submittedAdvisers);

    $alerts = [];
    $pendingSubmissions = max(0, $totalAssignments - $submittedAssignments);
    if ($pendingSubmissions > 0) {
        $alerts[] = ['level' => 'warning', 'title' => 'Pending grade submissions', 'message' => $pendingSubmissions . ' teacher loads still need submission.'];
    }
    if (count($atRiskIds) > 0) {
        $alerts[] = ['level' => 'danger', 'title' => 'Students at risk', 'message' => count($atRiskIds) . ' students have failing, incomplete, or low-attendance signals.'];
    }
    foreach ($deadlineRows as $deadline) {
        if (in_array($deadline['status'], ['Due Soon', 'Overdue'], true)) {
            $alerts[] = [
                'level' => $deadline['status'] === 'Overdue' ? 'danger' : 'info',
                'title' => $deadline['status'] . ': ' . $deadline['type'],
                'message' => 'Q' . $deadline['quarter'] . ' deadline is ' . strtolower($deadline['status']) . ' on ' . $deadline['due_display'] . '.',
            ];
        }
    }
    if (dashTableExists($pdo, 'system_notifications')) {
        $notificationRows = dashRows($pdo, "SELECT title, message FROM system_notifications ORDER BY created_at DESC LIMIT 3");
        foreach ($notificationRows as $row) {
            $alerts[] = ['level' => 'secondary', 'title' => $row['title'], 'message' => $row['message']];
        }
    }
    $alerts = array_slice($alerts, 0, 8);

    dashRespond(true, [
        'context' => [
            'active_year_id' => $activeYearId,
            'active_year_label' => $schoolYear ?: 'No active academic year',
            'active_quarter' => $quarter,
            'active_quarter_label' => $activeQuarter['quarter_label'] ?? ('Q' . $quarter),
        ],
        'summary' => [
            'total_students' => $totalStudents,
            'total_teachers' => $totalTeachers,
            'total_sections' => $totalSections,
            'total_subjects' => $totalSubjects,
            'active_academic_year' => $schoolYear ?: 'Not set',
            'honor_students' => $honorStudents,
            'students_at_risk' => count($atRiskIds),
            'pending_grade_submissions' => $pendingSubmissions,
            'completed_grade_submissions' => $submittedAssignments,
            'attendance_completion' => dashPercent($attendanceSubmitted, $totalAdvisers),
            'character_evaluation_completion' => dashPercent($characterSubmitted, $totalAdvisers),
        ],
        'submission' => [
            'grade_levels' => $gradeLevelProgress,
            'subjects' => $subjectMonitoring,
            'advisers' => $adviserCompletion,
            'teacher_completion' => dashPercent($submittedAssignments, $totalAssignments),
            'adviser_completion' => dashPercent($submittedAdvisers, $totalAdvisers),
        ],
        'honors' => [
            'counts' => $honors,
            'distribution' => $honorDistribution,
        ],
        'charts' => [
            'average_by_grade' => $averageByGrade,
            'pass_fail' => $passFail,
            'subject_performance' => $subjectPerformance,
            'quarter_trend' => $quarterTrend,
            'strand_performance' => $strandPerformance,
        ],
        'activities' => $recentActivities,
        'deadlines' => $deadlineRows,
        'at_risk' => [
            'count' => count($atRiskIds),
            'rows' => $atRiskRows,
        ],
        'section_ranking' => $sectionRanking,
        'teacher_workload' => $teacherWorkload,
        'alerts' => $alerts,
    ]);
} catch (Throwable $e) {
    error_log('[dashboard analytics] ' . $e->getMessage());
    dashRespond(false, [], 'Dashboard analytics failed: ' . $e->getMessage());
}
