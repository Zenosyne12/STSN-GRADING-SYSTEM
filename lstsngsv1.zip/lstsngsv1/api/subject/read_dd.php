<?php
require_once '../shared/db_connect.php';
$stmt=$db->query("SELECT id, subject_name FROM tblsubjects WHERE 1");
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
?>