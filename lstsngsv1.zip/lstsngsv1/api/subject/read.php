<?php
require_once __DIR__.'/../shared/db_connect.php';
header('Content-Type: application/json');

$search = isset($_GET['s']) ? trim($_GET['s']) : '';
$page   = max(1, (int)($_GET['p'] ?? 1));
$limit  = 10;
$offset = ($page - 1) * $limit;

$where  = '';
$params = [];
if ($search !== '') {
    $where = " WHERE subject_code LIKE :s OR subject_name LIKE :s OR description LIKE :s ";
    $params['s'] = "%$search%";
}

/* ----------  COUNT  ---------- */
$cnt = $pdo->prepare("SELECT COUNT(*) FROM tblsubjects $where");
$cnt->execute($params);
$total = (int)$cnt->fetchColumn();
$pages = max(1, ceil($total / $limit));

/* ----------  ROWS  ---------- */
$sql = "SELECT id, subject_code, subject_name, description, is_active
        FROM tblsubjects
        $where
        ORDER BY id DESC
        LIMIT $offset,$limit";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);

echo json_encode([
    'subjects' => $stmt->fetchAll(PDO::FETCH_ASSOC),
    'page'  => $page,
    'pages' => $pages,
    'total' => $total
]);