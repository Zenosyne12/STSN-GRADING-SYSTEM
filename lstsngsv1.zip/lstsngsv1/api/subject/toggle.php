<?php
require_once __DIR__.'/../shared/db_connect.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$id   = (int)($data['id'] ?? 0);

if (!$id) { http_response_code(400); exit(json_encode(['success'=>false,'error'=>'Bad ID'])); }

/* flip 0↔1 exactly like teacher toggle */
$stmt = $pdo->prepare("UPDATE tblsubjects SET is_active = 1 - is_active WHERE id = ?");
$stmt->execute([$id]);

echo json_encode(['success' => $stmt->rowCount() > 0]);