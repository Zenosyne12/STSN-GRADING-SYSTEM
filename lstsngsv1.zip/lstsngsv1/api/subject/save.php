<?php
require_once __DIR__.'/../shared/db_connect.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

$ay   = intval($data['ay_id']      ?? 0);
$teach= intval($data['teacher_id'] ?? 0);
$subj = intval($data['subject_id'] ?? 0);
$sect = intval($data['section_id'] ?? 0);
$adv  = !empty($data['isAdvisory']) ? 1 : 0;
$id   = intval($data['id']         ?? 0);

if (!$ay || !$teach || !$subj || !$sect) { http_response_code(422); echo json_encode(['error'=>'Required fields missing']); exit; }

try {
    if ($id) {
        $stmt = $pdo->prepare("UPDATE tblteacher_assignment
                               SET ay_id=?, teacher_id=?, subject_id=?, section_id=?, isAdvisory=?
                               WHERE id=?");
        $stmt->execute([$ay,$teach,$subj,$sect,$adv,$id]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO tblteacher_assignment
                                     (ay_id, teacher_id, subject_id, section_id, isAdvisory)
                              VALUES (?,?,?,?,?)");
        $stmt->execute([$ay,$teach,$subj,$sect,$adv]);
        $id = $pdo->lastInsertId();
    }
    echo json_encode(['success'=>true, 'id'=>$id]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error'=>$e->getMessage()]);
}
?>