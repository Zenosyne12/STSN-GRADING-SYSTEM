<?php
/**
 * api/archive/manage.php
 * STSN Grading System — manual archive / restore trigger (Admin UI).
 *
 * POST JSON: { action: 'archive'|'restore', year_id: int, reason: string }
 *
 * Auth: requireAdmin() (role_id = 1). SuperAdmins use the dedicated
 * SuperAdmin pages; this endpoint is the Admin-side trigger.
 */

header('Content-Type: application/json; charset=utf-8');

function archJsonOut(array $payload): void
{
    echo json_encode($payload);
    exit;
}

function archJsonError(string $error, int $httpCode = 400): void
{
    http_response_code($httpCode);
    archJsonOut(['success' => false, 'error' => $error]);
}

try {
    require_once __DIR__ . '/../../includes/auth.php';
    requireAdmin();

    require_once __DIR__ . '/../shared/db_connect.php';
    require_once __DIR__ . '/../../includes/archive_engine.php';

    $raw    = file_get_contents('php://input');
    $data   = json_decode((string)$raw, true);
    $action = strtolower(trim((string)($data['action'] ?? '')));
    $yearId = (int)($data['year_id'] ?? 0);
    $reason = trim((string)($data['reason'] ?? ''));
    $adminId = (int)($_SESSION['user_id'] ?? 0);

    if (!in_array($action, ['archive', 'restore'], true)) {
        archJsonError("Invalid action. Expected 'archive' or 'restore'.");
    }
    if ($yearId <= 0) {
        archJsonError('A valid year_id is required.');
    }

    if ($action === 'archive') {
        $stmt = $pdo->prepare("SELECT year_label, is_active FROM tblacademicyear WHERE id = ? LIMIT 1");
        $stmt->execute([$yearId]);
        $year = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$year) {
            archJsonError('School year not found.', 404);
        }
        if ((int)$year['is_active'] !== 1) {
            archJsonError('Only the currently active school year can be archived.');
        }
        if (mb_strlen($reason) < 10) {
            archJsonError('A reason of at least 10 characters is required.');
        }

        $result = archiveYear($pdo, $yearId, $reason, $adminId, 'MANUAL');
        if (!$result['success']) {
            archJsonError('Archive failed: ' . $result['message'], 500);
        }

        archJsonOut([
            'success'        => true,
            'message'        => 'School year archived. ' . $result['archived_count'] . ' student record(s) stored.',
            'archived_count' => $result['archived_count'],
        ]);
    }

    // ---- action = restore ----
    $stmt = $pdo->prepare("SELECT year_label FROM tblacademicyear WHERE id = ? LIMIT 1");
    $stmt->execute([$yearId]);
    $year = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$year) {
        archJsonError('School year not found.', 404);
    }
    $yearLabel = (string)$year['year_label'];

    $pdo->beginTransaction();
    try {
        // Deactivate every other active year, then re-activate the target
        $deactivate = $pdo->prepare("
            UPDATE tblacademicyear SET is_active = 0
            WHERE is_active = 1 AND id <> ?
        ");
        $deactivate->execute([$yearId]);

        $activate = $pdo->prepare("UPDATE tblacademicyear SET is_active = 1 WHERE id = ?");
        $activate->execute([$yearId]);

        // Audit trail. Isolated: a log schema mismatch must not roll back the restore.
        try {
            $logStmt = $pdo->prepare("
                INSERT INTO tblworkflow_action_log
                    (instance_id, step_order, actor_user_id, actor_role_id,
                     actor_position, action, remarks, acted_at)
                VALUES (0, 1, ?, 1, 'Admin', 'RESTORE', ?, NOW())
            ");
            $logStmt->execute([$adminId, 'Restored school year ' . $yearLabel . ' to active. Reason: ' . $reason]);
        } catch (Throwable $logErr) {
            error_log('[archive/manage] RESTORE log write failed: ' . $logErr->getMessage());
        }

        $pdo->commit();
    } catch (Throwable $txErr) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $txErr;
    }

    archJsonOut([
        'success' => true,
        'message' => 'School year ' . $yearLabel . ' restored as the active year.',
    ]);
} catch (Throwable $e) {
    archJsonError('Unexpected server error: ' . $e->getMessage(), 500);
}
