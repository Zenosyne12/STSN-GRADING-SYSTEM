<?php
/**
 * api/archive/manage.php
 * STSN Grading System — manual archive / restore trigger (Admin UI).
 *
 * POST JSON: { action: 'archive'|'restore', year_id: int, reason: string }
 *
 * Auth: requireAdmin() (role_id = 1). SuperAdmins use the dedicated
 * SuperAdmin pages; this endpoint is the Admin-side trigger.
 */

header('Content-Type: application/json; charset=utf-8');

function archJsonOut(array $payload): void
{
    echo json_encode($payload);
    exit;
}

function archJsonError(string $error, int $httpCode = 400): void
{
    http_response_code($httpCode);
    archJsonOut(['status' => 'error', 'success' => false, 'message' => $error, 'error' => $error]);
}

try {
    require_once __DIR__ . '/../../includes/auth.php';
    requireAdmin();

    require_once __DIR__ . '/../shared/db_connect.php';
    require_once __DIR__ . '/../../includes/archive_engine.php';
    require_once __DIR__ . '/../academic-year/promotion_service.php';

    $raw    = file_get_contents('php://input');
    $data   = json_decode((string)$raw, true);
    if (!is_array($data)) {
        archJsonError('Invalid request payload.');
    }
    $action = strtolower(trim((string)($data['action'] ?? '')));
    $yearId = (int)($data['year_id'] ?? 0);
    $reason = trim((string)($data['reason'] ?? ''));
    $adminId = (int)($_SESSION['user_id'] ?? 0);

    if (!in_array($action, ['archive', 'restore'], true)) {
        archJsonError("Invalid action. Expected 'archive' or 'restore'.");
    }
    if ($yearId <= 0) {
        archJsonError('A valid year_id is required.');
    }

    if ($action === 'archive') {
        $stmt = $pdo->prepare("SELECT year_label, is_active, archived_at FROM tblacademicyear WHERE id = ? LIMIT 1");
        $stmt->execute([$yearId]);
        $year = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$year) {
            archJsonError('School year not found.', 404);
        }
        if ((int)$year['is_active'] !== 1) {
            archJsonError('Only the currently active school year can be archived.');
        }
        if ($year['archived_at'] !== null) {
            archJsonError('This school year is already archived.');
        }
        if (mb_strlen($reason) < 10) {
            archJsonError('A reason of at least 10 characters is required.');
        }

        ensurePromotionSchema($pdo);
        $result = archiveYear($pdo, $yearId, $reason, $adminId, 'MANUAL');
        if (!$result['success']) {
            archJsonError('Archive failed: ' . $result['message'], 500);
        }

        $pdo->beginTransaction();
        try {
            $preview = previewAcademicYearPromotion($pdo, $yearId, null, true);
            $existingPendingStmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM tblenrollment
                WHERE academic_year_id = ?
                  AND promotion_decision = 'PENDING_REVIEW'
            ");
            $existingPendingStmt->execute([$yearId]);
            $existingPendingCount = (int) $existingPendingStmt->fetchColumn();

            if ($existingPendingCount > 0) {
                $pendingCount = $existingPendingCount;
            } else {
                storePromotionClassifications($pdo, $yearId, $preview, true);
                $pendingCount = (int) ($preview['summary']['pending_review'] ?? 0);
            }
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }

        $archiveMessage = 'School year archived. ' . $result['archived_count'] . ' student record(s) stored.';
        if ($pendingCount > 0) {
            archJsonOut([
                'status' => 'success',
                'success' => true,
                'message' => $archiveMessage . ' ' . $pendingCount . ' student(s) need promotion review.',
                'archived_count' => $result['archived_count'],
                'pending_review' => $pendingCount,
                'redirect' => 'Promotion-Review.php?mode=archive&academic_year_id=' . $yearId,
            ]);
        }

        archJsonOut([
            'status' => 'success',
            'success' => true,
            'message' => $archiveMessage,
            'archived_count' => $result['archived_count'],
        ]);
    }

    // ---- action = restore ----
    $result = restoreYear($pdo, $yearId, $adminId, $reason);
    if (!$result['success']) {
        archJsonError('Restore failed: ' . $result['message'], 500);
    }

    archJsonOut([
        'status'  => 'success',
        'success' => true,
        'message' => 'School year ' . $result['year_label'] . ' restored as the active year.',
    ]);
} catch (Throwable $e) {
    archJsonError('Unexpected server error: ' . $e->getMessage(), 500);
}
