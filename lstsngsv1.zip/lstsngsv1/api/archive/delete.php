<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

$payload = json_decode(file_get_contents('php://input'), true);

$id = (int) ($payload['id'] ?? 0);
$role = strtolower(trim((string) ($payload['role'] ?? '')));

if ($id <= 0 || !in_array($role, ['teacher', 'student'], true)) {
    echo json_encode(['success' => false, 'error' => 'Invalid delete request']);
    exit;
}

try {
    $pdo->beginTransaction();

    if ($role === 'teacher') {
        $deleteUser = $pdo->prepare("
            DELETE FROM tblusers
            WHERE role_id = 2 AND reference_id = ?
        ");
        $deleteUser->execute([$id]);

        $deleteTeacher = $pdo->prepare("DELETE FROM tblteacher WHERE id = ?");
        $deleteTeacher->execute([$id]);
    } else {
        $deleteStudent = $pdo->prepare("DELETE FROM tblstudents WHERE id = ?");
        $deleteStudent->execute([$id]);
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => ucfirst($role) . ' permanently deleted.'
    ]);
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    $friendly = 'Delete failed. This record may still be used in other tables.';
    if (stripos($e->getMessage(), 'foreign key') !== false || stripos($e->getMessage(), 'constraint') !== false) {
        $friendly = 'Cannot permanently delete this record because it is still linked to other records.';
    }

    echo json_encode([
        'success' => false,
        'error' => $friendly
    ]);
}