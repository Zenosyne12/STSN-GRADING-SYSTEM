<?php
/**
 * api/archive/auto_check.php
 * STSN Grading System — cron-callable archive heartbeat.
 *
 * Hostinger shared hosting (no Event Scheduler): this endpoint is called
 * by a cron job (`curl -s "<url>"`) with the token generated in
 * SuperAdmin/Archive-Settings.php.
 *
 * NO session auth — token only. Deliberately does NOT call requireLogin()
 * or requireAdmin(): cron has no PHP session.
 *
 * Output: text/plain (curl-log friendly).
 */

header('Content-Type: text/plain; charset=utf-8');

// ── Auto-archive DISABLED on this environment ─────────────────────────
// Cron/auto-archive will be moved to Render later. This endpoint now
// performs no archiving. Manual archiving via api/archive/manage.php and
// includes/archive_engine.php stay intact.
echo "Archive check ran at " . date('Y-m-d H:i:s') . "\n";
echo "Auto-archive is DISABLED on this environment. No actions taken.\n";
exit;

try {
    require_once __DIR__ . '/../../api/shared/db_connect.php';
    require_once __DIR__ . '/../../includes/archive_engine.php';

    $token = isset($_GET['token']) ? (string)$_GET['token'] : '';
    if (trim($token) === '') {
        http_response_code(401);
        echo "Missing token";
        exit;
    }

    if (!verifyCronToken($pdo, $token)) {
        http_response_code(403);
        echo "Invalid token";
        exit;
    }

    $result = checkAutoArchive($pdo);
    $actions = is_array($result['actions'] ?? null) ? $result['actions'] : [];

    echo "Archive check ran at " . date('Y-m-d H:i:s') . "\n";
    echo "Actions taken: " . count($actions) . "\n";
    if ($actions === []) {
        echo "No actions needed.\n";
    } else {
        foreach ($actions as $action) {
            echo "  - " . $action . "\n";
        }
    }
    if (!empty($result['message'])) {
        echo "Note: " . $result['message'] . "\n";
    }
    // last_cron_run / last_cron_status are updated inside checkAutoArchive()
} catch (Throwable $e) {
    http_response_code(500);
    echo "Archive check failed: " . $e->getMessage() . "\n";
}
