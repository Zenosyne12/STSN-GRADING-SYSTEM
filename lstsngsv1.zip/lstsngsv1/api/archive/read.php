<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;

$role = strtolower(trim((string) ($_GET['role'] ?? 'all')));
$search = trim((string) ($_GET['search'] ?? ''));

if (!in_array($role, ['all', 'teacher', 'student'], true)) {
    $role = 'all';
}

$whereParts = [];
$params = [];

if ($role === 'all' || $role === 'teacher') {
    $teacherSql = "
        SELECT
            t.id,
            t.teacher_id AS identifier_code,
            CONCAT_WS(' ', t.fname, NULLIF(t.mname, ''), t.lname) AS full_name,
            t.email,
            NULL AS lrn,
            'teacher' AS role,
            'Teacher' AS role_label,
            NULL AS archived_at,
            NULL AS archive_reason
        FROM tblteacher t
        WHERE t.is_active = 0
    ";

    if ($search !== '') {
        $teacherSql .= " AND (
            t.teacher_id LIKE ?
            OR t.email LIKE ?
            OR t.fname LIKE ?
            OR t.mname LIKE ?
            OR t.lname LIKE ?
            OR CONCAT_WS(' ', t.fname, NULLIF(t.mname, ''), t.lname) LIKE ?
        )";
    }

    $whereParts[] = $teacherSql;
}

if ($role === 'all' || $role === 'student') {
    $studentSql = "
        SELECT
            s.id,
            NULL AS identifier_code,
            CONCAT_WS(' ', s.fname, NULLIF(s.mname, ''), s.lname) AS full_name,
            NULL AS email,
            s.lrn,
            'student' AS role,
            'Student' AS role_label,
            NULL AS archived_at,
            NULL AS archive_reason
        FROM tblstudents s
        WHERE COALESCE(s.is_active, 0) = 0
    ";

    if ($search !== '') {
        $studentSql .= " AND (
            s.lrn LIKE ?
            OR s.fname LIKE ?
            OR s.mname LIKE ?
            OR s.lname LIKE ?
            OR CONCAT_WS(' ', s.fname, NULLIF(s.mname, ''), s.lname) LIKE ?
        )";
    }

    $whereParts[] = $studentSql;
}

if (!$whereParts) {
    echo json_encode([
        'success' => true,
        'accounts' => [],
        'page' => 1,
        'pages' => 1,
        'filtered_count' => 0,
        'total_count' => 0
    ]);
    exit;
}

if ($search !== '') {
    if ($role === 'all' || $role === 'teacher') {
        $like = '%' . $search . '%';
        array_push($params, $like, $like, $like, $like, $like, $like);
    }
    if ($role === 'all' || $role === 'student') {
        $like = '%' . $search . '%';
        array_push($params, $like, $like, $like, $like, $like);
    }
}

$unionSql = implode(' UNION ALL ', $whereParts);

try {
    $totalSql = "
        SELECT
            (SELECT COUNT(*) FROM tblteacher WHERE is_active = 0) +
            (SELECT COUNT(*) FROM tblstudents WHERE COALESCE(is_active, 0) = 0)
            AS total_count
    ";
    $totalCount = (int) $pdo->query($totalSql)->fetchColumn();

    $countStmt = $pdo->prepare("SELECT COUNT(*) FROM ({$unionSql}) archived_people");
    $countStmt->execute($params);
    $filteredCount = (int) $countStmt->fetchColumn();

    $pages = max(1, (int) ceil($filteredCount / $perPage));

    if ($page > $pages) {
        $page = $pages;
        $offset = ($page - 1) * $perPage;
    }

    $listSql = "
        SELECT *
        FROM ({$unionSql}) archived_people
        ORDER BY role_label ASC, full_name ASC
        LIMIT {$perPage} OFFSET {$offset}
    ";

    $listStmt = $pdo->prepare($listSql);
    $listStmt->execute($params);
    $accounts = $listStmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'accounts' => $accounts,
        'page' => $page,
        'pages' => $pages,
        'filtered_count' => $filteredCount,
        'total_count' => $totalCount
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Failed to load archive: ' . $e->getMessage()
    ]);
}