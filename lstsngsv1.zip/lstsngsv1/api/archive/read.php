<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;
$role = strtolower(trim((string)($_GET['role'] ?? 'all')));
$type = strtolower(trim((string)($_GET['type'] ?? 'all')));
$scope = strtolower(trim((string)($_GET['scope'] ?? 'all')));
$search = trim((string)($_GET['search'] ?? ''));
$from = trim((string)($_GET['from'] ?? ''));
$to = trim((string)($_GET['to'] ?? ''));

if (!in_array($role, ['all', 'teacher', 'student'], true)) {
    $role = 'all';
}

$validTypes = ['all', 'teacher_record', 'student_record', 'teacher_account', 'student_account'];
if (!in_array($type, $validTypes, true)) {
    $type = 'all';
}

if ($scope === 'accounts_only') {
    $includeRecords = false;
    $includeAccounts = true;
} elseif ($scope === 'records_only') {
    $includeRecords = true;
    $includeAccounts = false;
} else {
    $includeRecords = true;
    $includeAccounts = true;
}

$includeTeacherRecord = $includeRecords && ($role === 'all' || $role === 'teacher') && ($type === 'all' || $type === 'teacher_record');
$includeStudentRecord = $includeRecords && ($role === 'all' || $role === 'student') && ($type === 'all' || $type === 'student_record');
$includeTeacherAccount = $includeAccounts && ($role === 'all' || $role === 'teacher') && ($type === 'all' || $type === 'teacher_account');
$includeStudentAccount = $includeAccounts && ($role === 'all' || $role === 'student') && ($type === 'all' || $type === 'student_account');

$parts = [];
$params = [];

$addSearch = static function (array &$params, string $search, int $count): string {
    if ($search === '') {
        return '';
    }
    $like = '%' . $search . '%';
    for ($i = 0; $i < $count; $i++) {
        $params[] = $like;
    }
    return '';
};

if ($includeTeacherRecord) {
    $sql = "
        SELECT
            t.id,
            '' AS username,
            t.teacher_id AS identifier_code,
            CONCAT_WS(' ', t.fname, NULLIF(t.mname, ''), t.lname) AS full_name,
            t.email,
            NULL AS lrn,
            'teacher' AS role,
            'Teacher' AS role_label,
            'teacher_record' AS archive_type,
            'Teacher Record' AS archive_type_label,
            NULL AS archived_at,
            'Archived teacher record' AS archive_reason
        FROM tblteacher t
        WHERE COALESCE(t.is_active, 1) = 0
    ";
    if ($search !== '') {
        $sql .= " AND (t.teacher_id LIKE ? OR t.email LIKE ? OR t.fname LIKE ? OR t.mname LIKE ? OR t.lname LIKE ? OR CONCAT_WS(' ', t.fname, NULLIF(t.mname, ''), t.lname) LIKE ?)";
        $addSearch($params, $search, 6);
    }
    $parts[] = $sql;
}

if ($includeStudentRecord) {
    $sql = "
        SELECT
            s.id,
            '' AS username,
            NULL AS identifier_code,
            CONCAT_WS(' ', s.fname, NULLIF(s.mname, ''), s.lname) AS full_name,
            s.email,
            s.lrn,
            'student' AS role,
            'Student' AS role_label,
            'student_record' AS archive_type,
            'Student Record' AS archive_type_label,
            NULL AS archived_at,
            'Archived student record' AS archive_reason
        FROM tblstudents s
        WHERE COALESCE(s.is_active, 1) = 0
    ";
    if ($search !== '') {
        $sql .= " AND (s.lrn LIKE ? OR s.email LIKE ? OR s.fname LIKE ? OR s.mname LIKE ? OR s.lname LIKE ? OR CONCAT_WS(' ', s.fname, NULLIF(s.mname, ''), s.lname) LIKE ?)";
        $addSearch($params, $search, 6);
    }
    $parts[] = $sql;
}

if ($includeTeacherAccount) {
    $sql = "
        SELECT
            u.id,
            u.username,
            t.teacher_id AS identifier_code,
            CONCAT_WS(' ', t.fname, NULLIF(t.mname, ''), t.lname) AS full_name,
            t.email,
            NULL AS lrn,
            'teacher' AS role,
            'Teacher' AS role_label,
            'teacher_account' AS archive_type,
            'Teacher Account' AS archive_type_label,
            COALESCE(u.updated_at, u.created_at) AS archived_at,
            'Deactivated teacher account' AS archive_reason
        FROM tblusers u
        LEFT JOIN tblteacher t ON t.id = u.reference_id
        WHERE u.role_id = 2
          AND u.status = 'Inactive'
          AND LOWER(COALESCE(u.username, '')) <> 'admin'
    ";
    if ($search !== '') {
        $sql .= " AND (u.username LIKE ? OR t.teacher_id LIKE ? OR t.email LIKE ? OR t.fname LIKE ? OR t.lname LIKE ? OR CONCAT_WS(' ', t.fname, NULLIF(t.mname, ''), t.lname) LIKE ?)";
        $addSearch($params, $search, 6);
    }
    $parts[] = $sql;
}

if ($includeStudentAccount) {
    $sql = "
        SELECT
            u.id,
            u.username,
            NULL AS identifier_code,
            CONCAT_WS(' ', s.fname, NULLIF(s.mname, ''), s.lname) AS full_name,
            s.email,
            s.lrn,
            'student' AS role,
            'Student' AS role_label,
            'student_account' AS archive_type,
            'Student Account' AS archive_type_label,
            COALESCE(u.updated_at, u.created_at) AS archived_at,
            'Deactivated student mobile account' AS archive_reason
        FROM tblusers u
        JOIN tblstudents s ON s.id = u.reference_id
        WHERE u.role_id = 3
          AND u.status = 'Inactive'
    ";
    if ($search !== '') {
        $sql .= " AND (u.username LIKE ? OR s.lrn LIKE ? OR s.email LIKE ? OR s.fname LIKE ? OR s.lname LIKE ? OR CONCAT_WS(' ', s.fname, NULLIF(s.mname, ''), s.lname) LIKE ?)";
        $addSearch($params, $search, 6);
    }
    $parts[] = $sql;
}

if (!$parts) {
    echo json_encode(['success' => true, 'accounts' => [], 'page' => 1, 'pages' => 1, 'filtered_count' => 0, 'total_count' => 0]);
    exit;
}

$unionSql = implode(' UNION ALL ', $parts);
$where = [];
$dateParams = [];

if ($from !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) {
    $where[] = '(archived_at IS NULL OR DATE(archived_at) >= ?)';
    $dateParams[] = $from;
}
if ($to !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
    $where[] = '(archived_at IS NULL OR DATE(archived_at) <= ?)';
    $dateParams[] = $to;
}

$wrappedSql = "SELECT * FROM ({$unionSql}) archived_items";
if ($where) {
    $wrappedSql .= ' WHERE ' . implode(' AND ', $where);
}

try {
    $countStmt = $pdo->prepare("SELECT COUNT(*) FROM ({$wrappedSql}) counted");
    $countStmt->execute(array_merge($params, $dateParams));
    $filteredCount = (int)$countStmt->fetchColumn();
    $pages = max(1, (int)ceil($filteredCount / $perPage));

    if ($page > $pages) {
        $page = $pages;
        $offset = ($page - 1) * $perPage;
    }

    $totalCount = (int)$pdo->query("
        SELECT
            (SELECT COUNT(*) FROM tblteacher WHERE COALESCE(is_active, 1) = 0) +
            (SELECT COUNT(*) FROM tblstudents WHERE COALESCE(is_active, 1) = 0) +
            (SELECT COUNT(*) FROM tblusers WHERE role_id IN (2, 3) AND status = 'Inactive' AND LOWER(COALESCE(username, '')) <> 'admin')
    ")->fetchColumn();

    $listStmt = $pdo->prepare("
        {$wrappedSql}
        ORDER BY COALESCE(archived_at, '1970-01-01') DESC, archive_type_label ASC, full_name ASC
        LIMIT {$perPage} OFFSET {$offset}
    ");
    $listStmt->execute(array_merge($params, $dateParams));

    echo json_encode([
        'success' => true,
        'accounts' => $listStmt->fetchAll(PDO::FETCH_ASSOC),
        'page' => $page,
        'pages' => $pages,
        'filtered_count' => $filteredCount,
        'total_count' => $totalCount
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to load archive: ' . $e->getMessage()]);
}
