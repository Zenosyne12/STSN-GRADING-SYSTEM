<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

function archiveHasColumn(PDO $pdo, string $table, string $column): bool
{
    $stmt = $pdo->prepare("SHOW COLUMNS FROM `{$table}` LIKE ?");
    $stmt->execute([$column]);
    return (bool) $stmt->fetch(PDO::FETCH_ASSOC);
}

$payload = json_decode(file_get_contents('php://input'), true);

$id = (int) ($payload['id'] ?? 0);
$role = strtolower(trim((string) ($payload['role'] ?? '')));
$type = strtolower(trim((string) ($payload['type'] ?? '')));

if ($type === 'account' && in_array($role, ['teacher', 'student'], true)) {
    $type = $role . '_account';
}

if ($id <= 0 || !in_array($role, ['teacher', 'student'], true)) {
    echo json_encode(['success' => false, 'error' => 'Invalid restore request']);
    exit;
}

if (!in_array($type, ['teacher_record', 'student_record', 'teacher_account', 'student_account'], true)) {
    $type = $role === 'teacher' ? 'teacher_record' : 'student_record';
}

try {
    $pdo->beginTransaction();

    if ($type === 'teacher_record') {
        $fields = ['is_active = 1'];
        if (archiveHasColumn($pdo, 'tblteacher', 'is_archived')) {
            $fields[] = 'is_archived = 0';
        }
        if (archiveHasColumn($pdo, 'tblteacher', 'archived_at')) {
            $fields[] = 'archived_at = NULL';
        }
        if (archiveHasColumn($pdo, 'tblteacher', 'date_archived')) {
            $fields[] = 'date_archived = NULL';
        }

        $updateTeacher = $pdo->prepare("UPDATE tblteacher SET " . implode(', ', $fields) . " WHERE id = ?");
        $updateTeacher->execute([$id]);

        $updateUser = $pdo->prepare("
            UPDATE tblusers
            SET status = 'Active'
            WHERE role_id = 2 AND reference_id = ?
        ");
        $updateUser->execute([$id]);
    } elseif ($type === 'student_record') {
        $updateStudent = $pdo->prepare("UPDATE tblstudents SET is_active = 1 WHERE id = ?");
        $updateStudent->execute([$id]);
    } elseif ($type === 'teacher_account') {
        $updateUser = $pdo->prepare("UPDATE tblusers SET status = 'Active' WHERE id = ? AND role_id = 2");
        $updateUser->execute([$id]);
    } else {
        $updateUser = $pdo->prepare("UPDATE tblusers SET status = 'Active' WHERE id = ? AND role_id = 3");
        $updateUser->execute([$id]);
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => ucfirst($role) . ' restored successfully.'
    ]);
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    echo json_encode([
        'success' => false,
        'error' => 'Restore failed: ' . $e->getMessage()
    ]);
}
