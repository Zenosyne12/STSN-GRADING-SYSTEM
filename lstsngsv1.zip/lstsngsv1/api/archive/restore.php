<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

$payload = json_decode(file_get_contents('php://input'), true);

$id = (int) ($payload['id'] ?? 0);
$role = strtolower(trim((string) ($payload['role'] ?? '')));

if ($id <= 0 || !in_array($role, ['teacher', 'student'], true)) {
    echo json_encode(['success' => false, 'error' => 'Invalid restore request']);
    exit;
}

try {
    $pdo->beginTransaction();

    if ($role === 'teacher') {
        $updateTeacher = $pdo->prepare("UPDATE tblteacher SET is_active = 1 WHERE id = ?");
        $updateTeacher->execute([$id]);

        $updateUser = $pdo->prepare("
            UPDATE tblusers
            SET status = 'Active'
            WHERE role_id = 2 AND reference_id = ?
        ");
        $updateUser->execute([$id]);
    } else {
        $updateStudent = $pdo->prepare("UPDATE tblstudents SET is_active = 1 WHERE id = ?");
        $updateStudent->execute([$id]);
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => ucfirst($role) . ' restored successfully.'
    ]);
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    echo json_encode([
        'success' => false,
        'error' => 'Restore failed: ' . $e->getMessage()
    ]);
}