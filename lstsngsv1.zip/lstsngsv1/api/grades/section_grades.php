<?php
/**
 * api/grades/section_grades.php
 *
 * FIXED:
 *  1. Always returns all 4 quarters per subject in quarter_grades[subject_id][quarter_number]
 *     so the SF9 print card Q1/Q2/Q3/Q4 columns always populate correctly.
 *  2. Still returns grades[subject_id] = final_grade for the selected quarter (for the
 *     on-screen table view and general average calculation).
 *  3. Quarter filter only narrows the on-screen general_average/remark — print always
 *     shows all quarters.
 *  4. Accepts year_id param; falls back to active year.
 *  5. Resolves quarter_id → quarter_number (tblgrades.quarter is tinyint 1-4, NOT the PK).
 */
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/auth.php';

header('Content-Type: application/json');

$sectionId = isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0;
$quarterId = isset($_GET['quarter_id']) ? (int)$_GET['quarter_id'] : 0;
$yearId    = isset($_GET['year_id'])    ? (int)$_GET['year_id']    : 0;

if (!$sectionId) {
    echo json_encode(['success' => false, 'error' => 'Section ID required']);
    exit;
}

try {
    // ── Resolve academic year ─────────────────────────────────────────────────
    if ($yearId) {
        $yearStmt = $pdo->prepare("SELECT id, year_label FROM tblacademicyear WHERE id = ? LIMIT 1");
        $yearStmt->execute([$yearId]);
        $activeYear = $yearStmt->fetch(PDO::FETCH_ASSOC);
    } else {
        $activeYear = $pdo->query("SELECT id, year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1")
                         ->fetch(PDO::FETCH_ASSOC);
    }

    if (!$activeYear) {
        echo json_encode(['success' => false, 'error' => 'Academic year not found']);
        exit;
    }

    $yearId    = (int)$activeYear['id'];
    $yearLabel = $activeYear['year_label'];

    // ── Resolve quarter_id → quarter_number ──────────────────────────────────
    // tblgrades.quarter stores 1/2/3/4 (NOT the tblquarters PK)
    $quarterNumber = null;   // null = "all quarters"
    $quarterLabel  = '';

    if ($quarterId) {
        $qStmt = $pdo->prepare("SELECT quarter_number, quarter_label FROM tblquarters WHERE id = ? LIMIT 1");
        $qStmt->execute([$quarterId]);
        $qRow = $qStmt->fetch(PDO::FETCH_ASSOC);
        if ($qRow) {
            $quarterNumber = (int)$qRow['quarter_number'];   // 1, 2, 3, or 4
            $quarterLabel  = $qRow['quarter_label'] . ' Quarter';
        }
    }

    // ── Section info ──────────────────────────────────────────────────────────
    $secStmt = $pdo->prepare("
        SELECT
            s.id,
            s.section_name,
            s.section_code,
            s.grade_level_id,
            gl.grade_level_name,
            gl.grade_level_code,
            CONCAT(t.fname, ' ', t.lname) AS adviser_name
        FROM tblsection s
        JOIN  tblgradelevel gl ON gl.id = s.grade_level_id
        LEFT JOIN tblsectionadviser sa ON sa.section_id = s.id AND sa.academic_year_id = :year_id
        LEFT JOIN tblteacher t ON t.id = sa.teacher_id
        WHERE s.id = :sid
        LIMIT 1
    ");
    $secStmt->execute([':sid' => $sectionId, ':year_id' => $yearId]);
    $section = $secStmt->fetch(PDO::FETCH_ASSOC);

    if (!$section) {
        echo json_encode(['success' => false, 'error' => 'Section not found']);
        exit;
    }

    $section['year_label'] = $yearLabel;
    $section['year_id']    = $yearId;
    $gradeLevelId          = (int)$section['grade_level_id'];

    // ── Subjects for this grade level ─────────────────────────────────────────
    $subjStmt = $pdo->prepare("
        SELECT id, subject_code, subject_name, subject_type
        FROM tblsubjects
        WHERE grade_level_id = :gl_id AND is_active = 1
        ORDER BY subject_type ASC, subject_name ASC
    ");
    $subjStmt->execute([':gl_id' => $gradeLevelId]);
    $subjects = $subjStmt->fetchAll(PDO::FETCH_ASSOC);

    // ── Enrolled students ─────────────────────────────────────────────────────
    $studentStmt = $pdo->prepare("
        SELECT
            st.id,
            st.lrn,
            CONCAT(st.lname, ', ', st.fname, ' ', COALESCE(NULLIF(st.mname,''), '')) AS full_name,
            st.fname,
            st.lname,
            st.gender
        FROM tblsectionstudent ss
        JOIN tblstudents st ON st.id = ss.student_id
        WHERE ss.section_id       = :sid
          AND ss.academic_year_id = :year_id
          AND ss.is_active        = 1
          AND st.is_active        = 1
        ORDER BY st.lname ASC, st.fname ASC
    ");
    $studentStmt->execute([':sid' => $sectionId, ':year_id' => $yearId]);
    $students = $studentStmt->fetchAll(PDO::FETCH_ASSOC);

    // ── Fetch ALL quarters for every student in this section at once ──────────
    // This single query replaces the per-student loop and powers BOTH the
    // screen table (filtered quarter) and the SF9 print card (all quarters).
    $allGradesStmt = $pdo->prepare("
        SELECT g.student_id, g.subject_id, g.quarter,
               g.final_grade, g.initial_grade, g.remarks
        FROM tblgrades g
        WHERE g.section_id       = :section_id
          AND g.academic_year_id = :year_id
        ORDER BY g.student_id, g.subject_id, g.quarter
    ");
    $allGradesStmt->execute([':section_id' => $sectionId, ':year_id' => $yearId]);
    $rawGrades = $allGradesStmt->fetchAll(PDO::FETCH_ASSOC);

    // Index: [student_id][subject_id][quarter_number] = grade_row
    $gradeIndex = [];
    foreach ($rawGrades as $r) {
        $gradeIndex[(int)$r['student_id']][(int)$r['subject_id']][(int)$r['quarter']] = $r;
    }

    // ── Build per-student grade data ──────────────────────────────────────────
    foreach ($students as &$student) {
        $sid = (int)$student['id'];

        // quarter_grades[subject_id][quarter_number] = final_grade  (for SF9 print)
        // grades[subject_id]                         = final_grade  (for screen table)
        $student['quarter_grades'] = [];
        $student['grades']         = [];

        $totalGrades = 0;
        $gradeCount  = 0;

        foreach ($subjects as $sub) {
            $subId      = (int)$sub['id'];
            $subQuarters = $gradeIndex[$sid][$subId] ?? [];

            // Populate all 4 quarters for this subject (SF9 print needs them all)
            foreach ($subQuarters as $qNum => $row) {
                $fg = (float)$row['final_grade'];
                $student['quarter_grades'][$subId][$qNum] = $fg;
            }

            // For the screen table: use the filtered quarter, or average all if no filter
            if ($quarterNumber !== null) {
                // Specific quarter selected
                $fg = isset($subQuarters[$quarterNumber])
                    ? (float)$subQuarters[$quarterNumber]['final_grade']
                    : 0;
            } else {
                // All quarters: average of whatever quarters exist
                $fgValues = array_map(fn($r) => (float)$r['final_grade'], $subQuarters);
                $fgValues = array_filter($fgValues, fn($v) => $v > 0);
                $fg = count($fgValues) ? array_sum($fgValues) / count($fgValues) : 0;
            }

            $student['grades'][$subId] = round($fg, 2);

            if ($fg > 0) {
                $totalGrades += $fg;
                $gradeCount++;
            }
        }

        // General average (based on filtered quarter or all quarters)
        $student['general_average'] = $gradeCount > 0
            ? round($totalGrades / $gradeCount, 2)
            : 0;

        // Remark
        $avg = $student['general_average'];
        if ($avg >= 75) {
            $student['remark'] = 'Passed';
        } elseif ($avg > 0) {
            $student['remark'] = 'Failed';
        } else {
            $student['remark'] = '—';
        }
    }
    unset($student);

    echo json_encode([
        'success'       => true,
        'section'       => $section,
        'subjects'      => $subjects,
        'students'      => $students,
        'quarter_label' => $quarterLabel ?: 'All Quarters',
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}