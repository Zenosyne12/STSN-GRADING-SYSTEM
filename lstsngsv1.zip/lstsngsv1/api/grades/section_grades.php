<?php













require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/auth.php';
require_once __DIR__ . '/../advisory/attendance_table.php';
require_once __DIR__ . '/../advisory/deportment_table.php';
require_once __DIR__ . '/../shared/grade_workflow.php';

header('Content-Type: application/json');

$sectionId = isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0;
$quarterId = isset($_GET['quarter_id']) ? (int)$_GET['quarter_id'] : 0;
$yearId    = isset($_GET['year_id'])    ? (int)$_GET['year_id']    : 0;
$viewMode  = $_GET['view_mode'] ?? 'default'; 
$termId    = isset($_GET['term_id'])    ? (int)$_GET['term_id']    : 0; 

if (!$sectionId) {
    echo json_encode(['success' => false, 'error' => 'Section ID required']);
    exit;
}


$role_id    = $_SESSION['role_id']    ?? 0;
$teacher_id = $_SESSION['teacher_id'] ?? 0;
$isAdmin    = ($role_id == 1);


if ($viewMode === 'report' && !$isAdmin) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Admin access required for report view.']);
    exit;
}

try {
    ensureAttendanceTable($pdo);
    ensureDeportmentTable($pdo);
    ensureGradeWorkflowSchema($pdo);

    
    if ($yearId) {
        $yearStmt = $pdo->prepare("SELECT id, year_label FROM tblacademicyear WHERE id = ? LIMIT 1");
        $yearStmt->execute([$yearId]);
        $activeYear = $yearStmt->fetch(PDO::FETCH_ASSOC);
    } else {
        $activeYear = $pdo->query("SELECT id, year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1")
                         ->fetch(PDO::FETCH_ASSOC);
    }

    if (!$activeYear) {
        echo json_encode(['success' => false, 'error' => 'Academic year not found']);
        exit;
    }

    $yearId    = (int)$activeYear['id'];
    $yearLabel = $activeYear['year_label'];

    
    $quarterNumber = null;
    $quarterLabel  = '';

    if ($termId) {
        /* 3-term structure (tblconfig_terms). term_id maps 1:1 to tblgrades.quarter. */
        $tStmt = $pdo->prepare("
            SELECT term_number, term_label
            FROM tblconfig_terms
            WHERE id = ? AND academic_year_id = ?
            LIMIT 1
        ");
        $tStmt->execute([$termId, $yearId]);
        $tRow = $tStmt->fetch(PDO::FETCH_ASSOC);
        if ($tRow) {
            $quarterNumber = (int)$tRow['term_number'];
            $quarterLabel  = $tRow['term_label'];
        }
    } elseif ($quarterId) {
        $qStmt = $pdo->prepare("SELECT quarter_number, quarter_label FROM tblquarters WHERE id = ? LIMIT 1");
        $qStmt->execute([$quarterId]);
        $qRow = $qStmt->fetch(PDO::FETCH_ASSOC);
        if ($qRow) {
            $quarterNumber = (int)$qRow['quarter_number'];
            $quarterLabel  = $qRow['quarter_label'] . ' Quarter';
        }
    }

    
    
    $secStmt = $pdo->prepare("
        SELECT
            s.id,
            s.section_name,
            s.section_code,
            s.grade_level_id,
            s.strand,
            gl.grade_level_name,
            gl.grade_level_code,
            CONCAT(t.fname, ' ', t.lname) AS adviser_name
        FROM tblsection s
        JOIN  tblgradelevel gl ON gl.id = s.grade_level_id
        LEFT JOIN tblsectionadviser sa ON sa.section_id = s.id AND sa.academic_year_id = :year_id
        LEFT JOIN tblteacher t ON t.id = sa.teacher_id
        WHERE s.id = :sid
        LIMIT 1
    ");
    $secStmt->execute([':sid' => $sectionId, ':year_id' => $yearId]);
    $section = $secStmt->fetch(PDO::FETCH_ASSOC);

    if (!$section) {
        echo json_encode(['success' => false, 'error' => 'Section not found']);
        exit;
    }

    $section['year_label'] = $yearLabel;
    $section['year_id']    = $yearId;
    $gradeLevelId          = (int)$section['grade_level_id'];

    
    
    
    
    
    
    
    
    
    
    
    $sectionStrand  = $section['strand'] ?? null;
    $gradeLevelCode = (int)($section['grade_level_code'] ?? 0);
    $isSHS = in_array($gradeLevelCode, [11, 12], true);

    if ($isSHS && $sectionStrand) {
        
        $subjStmt = $pdo->prepare("
            SELECT id, subject_code, subject_name, subject_type, semester, strand,
                   subject_type AS category
            FROM tblsubjects
            WHERE grade_level_id = :gl_id
              AND is_active = 1
              AND (strand IS NULL OR strand = :strand)
            ORDER BY semester ASC,
                     FIELD(subject_type, 'CORE', 'APPLIED', 'SPECIALIZED', 'ELECTIVE'),
                     subject_name ASC
        ");
        $subjStmt->execute([':gl_id' => $gradeLevelId, ':strand' => $sectionStrand]);

    } elseif ($isSHS && !$sectionStrand) {
        
        $subjStmt = $pdo->prepare("
            SELECT id, subject_code, subject_name, subject_type, semester, strand,
                   subject_type AS category
            FROM tblsubjects
            WHERE grade_level_id = :gl_id
              AND is_active = 1
              AND strand IS NULL
            ORDER BY semester ASC,
                     FIELD(subject_type, 'CORE', 'APPLIED', 'SPECIALIZED', 'ELECTIVE'),
                     subject_name ASC
        ");
        $subjStmt->execute([':gl_id' => $gradeLevelId]);

    } else {
        
        $subjStmt = $pdo->prepare("
            SELECT id, subject_code, subject_name, subject_type,
                   NULL AS semester, NULL AS strand, subject_type AS category
            FROM tblsubjects
            WHERE grade_level_id = :gl_id
              AND is_active = 1
              AND (strand IS NULL OR strand = '')
            ORDER BY subject_name ASC
        ");
        $subjStmt->execute([':gl_id' => $gradeLevelId]);
    }

    $subjects = $subjStmt->fetchAll(PDO::FETCH_ASSOC);

    
    $studentStmt = $pdo->prepare("
        SELECT
            st.id,
            st.lrn,
            CONCAT(st.lname, ', ', st.fname, ' ', COALESCE(NULLIF(st.mname,''), '')) AS full_name,
            st.fname,
            st.lname,
            st.gender AS sex
        FROM tblsectionstudent ss
        JOIN tblstudents st ON st.id = ss.student_id
        WHERE ss.section_id       = :sid
          AND ss.academic_year_id = :year_id
          AND ss.is_active        = 1
          AND st.is_active        = 1
        ORDER BY st.lname ASC, st.fname ASC
    ");
    $studentStmt->execute([':sid' => $sectionId, ':year_id' => $yearId]);
    $students = $studentStmt->fetchAll(PDO::FETCH_ASSOC);

    
    $extraClause = "";
    $extraParams = [];
    if ($viewMode === 'teacher' && $teacher_id) {
        $extraClause = "AND g.teacher_id = :teacher_id";
        $extraParams[':teacher_id'] = $teacher_id;
    }

    
    $reportFinalized = true;
    if ($viewMode === 'report') {
        $submissionQuarter = $quarterNumber ?: 1;
        $chk = $pdo->prepare("
            SELECT COUNT(*)
            FROM tbladviser_submissions
            WHERE section_id = ? AND quarter = ? AND school_year = ?
              AND " . officialAdviserSubmissionSql('tbladviser_submissions') . "
        ");
        $chk->execute([$sectionId, $submissionQuarter, $yearLabel]);
        $reportFinalized = (int)$chk->fetchColumn() > 0;
    }

    
    $allGradesStmt = $pdo->prepare("
        SELECT g.student_id, g.subject_id, g.quarter,
               g.final_grade, g.initial_grade, g.remarks
        FROM tblgrades g
        WHERE g.section_id       = :section_id
          AND g.academic_year_id = :year_id
          " . ($viewMode === 'report' ? ($reportFinalized ? "AND " . officialGradeExistsSql('g') : "AND 1 = 0") : "") . "
          $extraClause
        ORDER BY g.student_id, g.subject_id, g.quarter
    ");
    $params = array_merge([':section_id' => $sectionId, ':year_id' => $yearId], $extraParams);
    $allGradesStmt->execute($params);
    $rawGrades = $allGradesStmt->fetchAll(PDO::FETCH_ASSOC);

    
    $gradeIndex = [];
    foreach ($rawGrades as $r) {
        $gradeIndex[(int)$r['student_id']][(int)$r['subject_id']][(int)$r['quarter']] = $r;
    }

    
    $attendanceStmt = $pdo->prepare("
        SELECT student_id, month_number, month_name, school_days, days_present, days_absent
        FROM tblattendance_records
        WHERE section_id = ? AND academic_year_id = ?
        ORDER BY month_number
    ");
    $attendanceStmt->execute([$sectionId, $yearId]);
    $attendanceIndex = [];
    foreach ($attendanceStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $attendanceIndex[(int)$row['student_id']][(int)$row['month_number']] = [
            'month_number'  => (int)$row['month_number'],
            'month_name'    => $row['month_name'],
            'school_days'   => (float)$row['school_days'],
            'days_present'  => (float)$row['days_present'],
            'days_absent'   => (float)$row['days_absent'],
        ];
    }

    
    $deportmentStmt = $pdo->prepare("
        SELECT student_id, statement_index, quarter, rating
        FROM tbldeportment_records
        WHERE section_id = ? AND academic_year_id = ?
        ORDER BY student_id, statement_index, quarter
    ");
    $deportmentStmt->execute([$sectionId, $yearId]);
    $deportmentIndex = [];
    foreach ($deportmentStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $deportmentIndex[(int)$row['student_id']][(int)$row['statement_index']][(int)$row['quarter']] = $row['rating'];
    }

    
    foreach ($students as &$student) {
        $sid = (int)$student['id'];

        $student['quarter_grades'] = [];
        $student['grades']         = [];

        $totalGrades = 0;
        $gradeCount  = 0;

        foreach ($subjects as $sub) {
            $subId      = (int)$sub['id'];
            $subQuarters = $gradeIndex[$sid][$subId] ?? [];

            
            foreach ($subQuarters as $qNum => $row) {
                $student['quarter_grades'][$subId][$qNum] = (float)$row['final_grade'];
            }

            
            if ($quarterNumber !== null) {
                $fg = isset($subQuarters[$quarterNumber])
                    ? (float)$subQuarters[$quarterNumber]['final_grade']
                    : 0;
            } else {
                $fgValues = array_map(fn($r) => (float)$r['final_grade'], $subQuarters);
                $fgValues = array_filter($fgValues, fn($v) => $v > 0);
                $fg = count($fgValues) ? array_sum($fgValues) / count($fgValues) : 0;
            }

            $student['grades'][$subId] = round($fg, 2);

            if ($fg > 0) {
                $totalGrades += $fg;
                $gradeCount++;
            }
        }

        $student['general_average'] = $gradeCount > 0
            ? round($totalGrades / $gradeCount, 2)
            : 0;

        $avg = $student['general_average'];
        if ($avg >= 75) {
            $student['remark'] = 'Passed';
        } elseif ($avg > 0) {
            $student['remark'] = 'Failed';
        } else {
            $student['remark'] = '—';
        }

        $student['attendance'] = $attendanceIndex[$sid] ?? [];
        $student['deportment'] = $deportmentIndex[$sid] ?? [];
    }
    unset($student);

    echo json_encode([
        'success'       => true,
        'section'       => $section,
        'subjects'      => $subjects,
        'students'      => $students,
        'quarter_label' => $quarterLabel ?: 'All Quarters',
        'view_mode'     => $viewMode,
        'report_finalized' => $reportFinalized,
        'report_status' => $reportFinalized ? 'finalized' : 'pending_adviser_finalization',
        'report_message' => $reportFinalized
            ? ''
            : 'Grades are hidden because the adviser has not finalized this section/quarter yet.',
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
