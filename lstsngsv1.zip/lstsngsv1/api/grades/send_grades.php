<?php






header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/grade_workflow.php';

function ensureGradeReleasesTable(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS tblgrade_releases (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            section_id INT NOT NULL,
            academic_year_id INT NOT NULL,
            quarter TINYINT NOT NULL,
            sent_by INT DEFAULT NULL,
            sent_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_grade_release (section_id, academic_year_id, quarter),
            KEY idx_grade_release_lookup (section_id, academic_year_id, quarter)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
}

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
    session_start();
}

if ((int)($_SESSION['user_id'] ?? 0) <= 0 || (int)($_SESSION['role_id'] ?? 0) !== 1) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'Unauthorized. Admin login required.',
    ]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

$sectionId = (int)($input['section_id'] ?? 0);
$yearId = (int)($input['year_id'] ?? 0);
$quarterIds = $input['quarter_ids'] ?? null;

if ($sectionId <= 0 || $yearId <= 0) {
    echo json_encode([
        'success' => false,
        'error' => 'section_id and year_id are required.',
    ]);
    exit;
}

try {
    ensureGradeReleasesTable($pdo);
    ensureGradeWorkflowSchema($pdo);

    $yearStmt = $pdo->prepare("SELECT id, year_label FROM tblacademicyear WHERE id = ? LIMIT 1");
    $yearStmt->execute([$yearId]);
    $year = $yearStmt->fetch(PDO::FETCH_ASSOC);

    if (!$year) {
        echo json_encode(['success' => false, 'error' => 'Academic year not found.']);
        exit;
    }

    $quarterNumbers = [];
    if (is_array($quarterIds) && count($quarterIds) > 0) {
        $cleanIds = array_values(array_filter(array_map('intval', $quarterIds), fn($id) => $id > 0));

        if ($cleanIds) {
            $placeholders = implode(',', array_fill(0, count($cleanIds), '?'));
            $qStmt = $pdo->prepare("
                SELECT quarter_number
                FROM tblquarters
                WHERE academic_year_id = ?
                  AND id IN ($placeholders)
                ORDER BY quarter_number
            ");
            $qStmt->execute(array_merge([$yearId], $cleanIds));
            $quarterNumbers = array_map('intval', $qStmt->fetchAll(PDO::FETCH_COLUMN));
        }
    }

    if (!$quarterNumbers) {
        $qStmt = $pdo->prepare("
            SELECT DISTINCT quarter
            FROM tblgrades
            WHERE section_id = ?
              AND academic_year_id = ?
              AND final_grade > 0
              AND status IN ('approved', 'approved_by_adviser', 'finalized')
            ORDER BY quarter
        ");
        $qStmt->execute([$sectionId, $yearId]);
        $quarterNumbers = array_map('intval', $qStmt->fetchAll(PDO::FETCH_COLUMN));
    }

    if (!$quarterNumbers) {
        echo json_encode([
            'success' => false,
            'error' => 'No grades found for this section and school year.',
            'students_processed' => 0,
            'notifications_sent' => 0,
        ]);
        exit;
    }

    $quarterPlaceholders = implode(',', array_fill(0, count($quarterNumbers), '?'));

    $finalizedQuarterStmt = $pdo->prepare("
        SELECT DISTINCT quarter
        FROM tbladviser_submissions
        WHERE section_id = ?
          AND school_year = ?
          AND quarter IN ($quarterPlaceholders)
          AND " . officialAdviserSubmissionSql('tbladviser_submissions') . "
    ");
    $finalizedQuarterStmt->execute(array_merge([$sectionId, $year['year_label']], $quarterNumbers));
    $quarterNumbers = array_values(array_intersect($quarterNumbers, array_map('intval', $finalizedQuarterStmt->fetchAll(PDO::FETCH_COLUMN))));

    if (!$quarterNumbers) {
        echo json_encode([
            'success' => false,
            'error' => 'No adviser-finalized grades found for the selected quarter(s).',
            'students_processed' => 0,
            'notifications_sent' => 0,
        ]);
        exit;
    }

    $quarterPlaceholders = implode(',', array_fill(0, count($quarterNumbers), '?'));

    $studentStmt = $pdo->prepare("
        SELECT DISTINCT st.id AS student_id, u.id AS user_id
        FROM tblsectionstudent ss
        INNER JOIN tblstudents st ON st.id = ss.student_id
        LEFT JOIN tblusers u
               ON u.reference_id = st.id
              AND u.role_id = 3
              AND u.status = 'Active'
        WHERE ss.section_id = ?
          AND ss.academic_year_id = ?
          AND ss.is_active = 1
          AND st.is_active = 1
        ORDER BY st.lname, st.fname
    ");
    $studentStmt->execute([$sectionId, $yearId]);
    $students = $studentStmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$students) {
        echo json_encode([
            'success' => false,
            'error' => 'No active students found in this section.',
            'students_processed' => 0,
            'notifications_sent' => 0,
        ]);
        exit;
    }

    $pdo->beginTransaction();

    $releasedRows = 0;

    $releaseMarkStmt = $pdo->prepare("
        INSERT INTO tblgrade_releases
            (section_id, academic_year_id, quarter, sent_by, sent_at, created_at, updated_at)
        VALUES
            (?, ?, ?, ?, NOW(), NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            sent_by = VALUES(sent_by),
            sent_at = NOW(),
            updated_at = NOW()
    ");

    foreach ($quarterNumbers as $quarterNumber) {
        $releaseMarkStmt->execute([
            $sectionId,
            $yearId,
            (int)$quarterNumber,
            (int)($_SESSION['user_id'] ?? 0),
        ]);
    }

    $hasGradeStmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM tblgrades
        WHERE student_id = ?
          AND section_id = ?
          AND academic_year_id = ?
          AND quarter IN ($quarterPlaceholders)
          AND final_grade > 0
          AND status IN ('approved', 'approved_by_adviser', 'finalized')
          AND " . officialGradeExistsSql('tblgrades') . "
    ");

    $notificationStmt = $pdo->prepare("
        INSERT INTO system_notifications (title, message, type, created_at)
        VALUES (?, ?, ?, NOW())
    ");

    $notificationsSent = 0;
    $studentsProcessed = 0;

    foreach ($students as $student) {
        $studentId = (int)$student['student_id'];
        $hasGradeStmt->execute(array_merge([$studentId, $sectionId, $yearId], $quarterNumbers));
        $gradeCount = (int)$hasGradeStmt->fetchColumn();

        if ($gradeCount <= 0) {
            continue;
        }

        $studentsProcessed++;
        $quarterText = count($quarterNumbers) === 1
            ? 'Quarter ' . $quarterNumbers[0]
            : 'selected quarters';

        $notificationStmt->execute([
            'Grades Released',
            "Your grades for {$quarterText}, S.Y. {$year['year_label']}, are now available in My Grades.",
            'student:' . $studentId,
        ]);
        $notificationsSent++;
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Grades sent to students successfully.',
        'students_processed' => $studentsProcessed,
        'notifications_sent' => $notificationsSent,
        'released_rows' => $releasedRows,
        'quarters' => $quarterNumbers,
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Failed to send grades: ' . $e->getMessage(),
    ]);
}
