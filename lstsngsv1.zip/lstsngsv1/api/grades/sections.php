<?php










require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/auth.php';
require_once __DIR__ . '/../shared/grade_workflow.php';

header('Content-Type: application/json');

$yearId     = isset($_GET['year_id'])     ? (int)$_GET['year_id']     : 0;
$gradeLevel = isset($_GET['grade_level']) ? (int)$_GET['grade_level'] : 0;
// Accept term_id (preferred) with backward-compatible quarter_id fallback
$quarterId  = isset($_GET['term_id'])     ? (int)$_GET['term_id']
            : (isset($_GET['quarter_id']) ? (int)$_GET['quarter_id']  : 0);

if (!$yearId) {
    echo json_encode(['sections' => [], 'term_label' => '', 'quarter_label' => '']);
    exit;
}

try {
    ensureGradeWorkflowSchema($pdo);
    
    
    $quarterNumber = null;
    $quarterLabel  = '';

    if ($quarterId) {
        $qStmt = $pdo->prepare("SELECT term_number, term_label FROM tblconfig_terms WHERE id = ? AND is_active = 1 AND is_closed = 0 LIMIT 1");
        $qStmt->execute([$quarterId]);
        $qRow = $qStmt->fetch(PDO::FETCH_ASSOC);
        if ($qRow) {
            $quarterNumber = (int)$qRow['term_number'];   
            $quarterLabel  = $qRow['term_label'];
        }
    }

    
    $sql = "
        SELECT
            s.id,
            s.section_name,
            s.section_code,
            gl.id              AS grade_level_id,
            gl.grade_level_name,
            gl.grade_level_code,
            gl.sort_order      AS grade_sort_order,
            CONCAT(t.fname, ' ', t.lname) AS adviser_name,
            ay.year_label
        FROM tblsection s
        JOIN  tblgradelevel gl    ON s.grade_level_id  = gl.id
        LEFT JOIN tblsectionadviser sa ON sa.section_id = s.id AND sa.academic_year_id = :year_id
        LEFT JOIN tblteacher t         ON t.id = sa.teacher_id
        LEFT JOIN tblacademicyear ay   ON ay.id = :year_id2
        WHERE COALESCE(s.is_active, 1) = 1
    ";

    $params = [':year_id' => $yearId, ':year_id2' => $yearId];

    if ($gradeLevel) {
        $sql .= " AND gl.id = :grade_level";
        $params[':grade_level'] = $gradeLevel;
    }

    $sql .= " ORDER BY gl.sort_order ASC, s.section_name ASC";

    $stmt     = $pdo->prepare($sql);
    $stmt->execute($params);
    $sections = $stmt->fetchAll(PDO::FETCH_ASSOC);

    
    foreach ($sections as &$sec) {
        $sid         = (int)$sec['id'];
        $glId        = (int)$sec['grade_level_id'];

        
        $enrollStmt = $pdo->prepare("
            SELECT COUNT(DISTINCT ss.student_id)
            FROM tblsectionstudent ss
            JOIN tblstudents st ON st.id = ss.student_id
            WHERE ss.section_id       = :sid
              AND ss.academic_year_id = :year_id
              AND ss.is_active        = 1
              AND st.is_active        = 1
        ");
        $enrollStmt->execute([':sid' => $sid, ':year_id' => $yearId]);
        $sec['enrolled'] = (int)$enrollStmt->fetchColumn();

        
        
        $subjectIds = $pdo->prepare("SELECT id FROM tblsubjects WHERE grade_level_id = ? AND is_active = 1");
        $subjectIds->execute([$glId]);
        $validSubjectIds = $subjectIds->fetchAll(PDO::FETCH_COLUMN);

        if (empty($validSubjectIds)) {
            $sec['passed']        = 0;
            $sec['failed']        = 0;
            $sec['class_average'] = 0;
            continue;
        }

        $placeholders = implode(',', array_fill(0, count($validSubjectIds), '?'));

        
        $quarterClause  = ($quarterNumber !== null) ? "AND g.quarter = ?" : "";
        $gradeBaseParams = array_merge([$sid, $yearId], $validSubjectIds);
        if ($quarterNumber !== null) {
            $gradeBaseParams[] = $quarterNumber;
        }

        
        
        $passedSql = "
            SELECT COUNT(DISTINCT g.student_id)
            FROM tblgrades g
            WHERE g.section_id       = ?
              AND g.academic_year_id = ?
              AND g.subject_id IN ($placeholders)
              AND g.remarks = 'Passed'
              AND " . officialGradeExistsSql('g') . "
              $quarterClause
        ";
        $passStmt = $pdo->prepare($passedSql);
        $passStmt->execute($gradeBaseParams);
        $sec['passed'] = (int)$passStmt->fetchColumn();

        $failedSql = "
            SELECT COUNT(DISTINCT g.student_id)
            FROM tblgrades g
            WHERE g.section_id       = ?
              AND g.academic_year_id = ?
              AND g.subject_id IN ($placeholders)
              AND g.remarks = 'Failed'
              AND " . officialGradeExistsSql('g') . "
              $quarterClause
        ";
        $failStmt = $pdo->prepare($failedSql);
        $failStmt->execute($gradeBaseParams);
        $sec['failed'] = (int)$failStmt->fetchColumn();

        $avgSql = "
            SELECT AVG(g.final_grade)
            FROM tblgrades g
            WHERE g.section_id       = ?
              AND g.academic_year_id = ?
              AND g.subject_id IN ($placeholders)
              AND g.final_grade > 0
              AND " . officialGradeExistsSql('g') . "
              $quarterClause
        ";
        $avgStmt = $pdo->prepare($avgSql);
        $avgStmt->execute($gradeBaseParams);
        $sec['class_average'] = round((float)$avgStmt->fetchColumn(), 2);
    }
    unset($sec);

    usort($sections, static function (array $a, array $b): int {
        $aHasStudents = ((int)($a['enrolled'] ?? 0)) > 0 ? 0 : 1;
        $bHasStudents = ((int)($b['enrolled'] ?? 0)) > 0 ? 0 : 1;

        if ($aHasStudents !== $bHasStudents) {
            return $aHasStudents <=> $bHasStudents;
        }

        $gradeCompare = ((int)($a['grade_sort_order'] ?? 0)) <=> ((int)($b['grade_sort_order'] ?? 0));
        if ($gradeCompare !== 0) {
            return $gradeCompare;
        }

        return strcasecmp((string)($a['section_name'] ?? ''), (string)($b['section_name'] ?? ''));
    });

    echo json_encode([
        'success'       => true,
        'sections'      => $sections,
        'term_label'    => $quarterLabel ?: 'All Terms',
        'quarter_label' => $quarterLabel ?: 'All Terms',
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
