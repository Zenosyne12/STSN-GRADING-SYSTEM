<?php
/**
 * api/grades/sections.php
 * Returns sections with enrollment/grade stats for the grades report.
 *
 * FIXED:
 *  1. Resolve quarter_id → quarter_number before filtering tblgrades.quarter.
 *  2. Stats (passed/failed/avg) now scoped to the section's own grade_level subjects
 *     so a grade saved under the wrong subject_id doesn't pollute counts.
 *  3. Single efficient query per section instead of 4 separate queries.
 */
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/auth.php';

header('Content-Type: application/json');

$yearId     = isset($_GET['year_id'])     ? (int)$_GET['year_id']     : 0;
$gradeLevel = isset($_GET['grade_level']) ? (int)$_GET['grade_level'] : 0;
$quarterId  = isset($_GET['quarter_id'])  ? (int)$_GET['quarter_id']  : 0;

if (!$yearId) {
    echo json_encode(['sections' => [], 'quarter_label' => '']);
    exit;
}

try {
    // ── Resolve quarter_id → quarter_number ───────────────────────────────────
    // tblgrades.quarter is a tinyint storing 1/2/3/4, NOT the tblquarters.id PK
    $quarterNumber = null;
    $quarterLabel  = '';

    if ($quarterId) {
        $qStmt = $pdo->prepare("SELECT quarter_number, quarter_label FROM tblquarters WHERE id = ? LIMIT 1");
        $qStmt->execute([$quarterId]);
        $qRow = $qStmt->fetch(PDO::FETCH_ASSOC);
        if ($qRow) {
            $quarterNumber = (int)$qRow['quarter_number'];   // 1, 2, 3, or 4
            $quarterLabel  = $qRow['quarter_label'] . ' Quarter';
        }
    }

    // ── Sections ──────────────────────────────────────────────────────────────
    $sql = "
        SELECT
            s.id,
            s.section_name,
            s.section_code,
            gl.id              AS grade_level_id,
            gl.grade_level_name,
            gl.grade_level_code,
            CONCAT(t.fname, ' ', t.lname) AS adviser_name,
            ay.year_label
        FROM tblsection s
        JOIN  tblgradelevel gl    ON s.grade_level_id  = gl.id
        LEFT JOIN tblsectionadviser sa ON sa.section_id = s.id AND sa.academic_year_id = :year_id
        LEFT JOIN tblteacher t         ON t.id = sa.teacher_id
        LEFT JOIN tblacademicyear ay   ON ay.id = :year_id2
        WHERE s.is_active = 1
    ";

    $params = [':year_id' => $yearId, ':year_id2' => $yearId];

    if ($gradeLevel) {
        $sql .= " AND gl.id = :grade_level";
        $params[':grade_level'] = $gradeLevel;
    }

    $sql .= " ORDER BY gl.sort_order ASC, s.section_name ASC";

    $stmt     = $pdo->prepare($sql);
    $stmt->execute($params);
    $sections = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // ── Stats per section ─────────────────────────────────────────────────────
    foreach ($sections as &$sec) {
        $sid         = (int)$sec['id'];
        $glId        = (int)$sec['grade_level_id'];

        // ── Enrolled count ────────────────────────────────────────────────────
        $enrollStmt = $pdo->prepare("
            SELECT COUNT(DISTINCT ss.student_id)
            FROM tblsectionstudent ss
            JOIN tblstudents st ON st.id = ss.student_id
            WHERE ss.section_id       = :sid
              AND ss.academic_year_id = :year_id
              AND ss.is_active        = 1
              AND st.is_active        = 1
        ");
        $enrollStmt->execute([':sid' => $sid, ':year_id' => $yearId]);
        $sec['enrolled'] = (int)$enrollStmt->fetchColumn();

        // ── Grade stats scoped to this section's grade level subjects ─────────
        // Subjects valid for this section's grade level
        $subjectIds = $pdo->prepare("SELECT id FROM tblsubjects WHERE grade_level_id = ? AND is_active = 1");
        $subjectIds->execute([$glId]);
        $validSubjectIds = $subjectIds->fetchAll(PDO::FETCH_COLUMN);

        if (empty($validSubjectIds)) {
            $sec['passed']        = 0;
            $sec['failed']        = 0;
            $sec['class_average'] = 0;
            continue;
        }

        $placeholders = implode(',', array_fill(0, count($validSubjectIds), '?'));

        // Build quarter clause
        $quarterClause  = ($quarterNumber !== null) ? "AND g.quarter = ?" : "";
        $gradeBaseParams = array_merge([$sid, $yearId], $validSubjectIds);
        if ($quarterNumber !== null) {
            $gradeBaseParams[] = $quarterNumber;
        }

        // Passed: students who have at least one Passed row and NO Failed row
        // (simpler consistent approach: count distinct students with any Passed + 0 Failed)
        $passedSql = "
            SELECT COUNT(DISTINCT g.student_id)
            FROM tblgrades g
            WHERE g.section_id       = ?
              AND g.academic_year_id = ?
              AND g.subject_id IN ($placeholders)
              AND g.remarks = 'Passed'
              $quarterClause
        ";
        $passStmt = $pdo->prepare($passedSql);
        $passStmt->execute($gradeBaseParams);
        $sec['passed'] = (int)$passStmt->fetchColumn();

        $failedSql = "
            SELECT COUNT(DISTINCT g.student_id)
            FROM tblgrades g
            WHERE g.section_id       = ?
              AND g.academic_year_id = ?
              AND g.subject_id IN ($placeholders)
              AND g.remarks = 'Failed'
              $quarterClause
        ";
        $failStmt = $pdo->prepare($failedSql);
        $failStmt->execute($gradeBaseParams);
        $sec['failed'] = (int)$failStmt->fetchColumn();

        $avgSql = "
            SELECT AVG(g.final_grade)
            FROM tblgrades g
            WHERE g.section_id       = ?
              AND g.academic_year_id = ?
              AND g.subject_id IN ($placeholders)
              AND g.final_grade > 0
              $quarterClause
        ";
        $avgStmt = $pdo->prepare($avgSql);
        $avgStmt->execute($gradeBaseParams);
        $sec['class_average'] = round((float)$avgStmt->fetchColumn(), 2);
    }
    unset($sec);

    echo json_encode([
        'success'       => true,
        'sections'      => $sections,
        'quarter_label' => $quarterLabel ?: 'All Quarters',
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}