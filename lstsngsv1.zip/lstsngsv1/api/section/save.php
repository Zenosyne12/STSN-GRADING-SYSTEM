<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = isset($data['id']) && $data['id'] !== '' ? (int)$data['id'] : null;
    $gradeLevelId = (int)($data['grade_level_id'] ?? 0);
    $sectionName = trim($data['section_name'] ?? '');
    $strand = isset($data['strand']) && $data['strand'] !== '' ? trim($data['strand']) : null;

    if ($gradeLevelId <= 0 || $sectionName === '') {
        echo json_encode(['success' => false, 'error' => 'Grade level and section name are required.']);
        exit;
    }

    $isShs = ($gradeLevelId == 12 || $gradeLevelId == 13);
    if ($isShs && empty($strand)) {
        echo json_encode(['success' => false, 'error' => 'Strand is required for Senior High School sections.']);
        exit;
    }
    if (!$isShs) {
        $strand = null;
    }

    if (!$id) {
        $prefix = 'SEC-';
        $countStmt = $pdo->query("SELECT COUNT(*) as total FROM tblsection");
        $count = $countStmt->fetch(PDO::FETCH_ASSOC)['total'] + 1;
        $sectionCode = $prefix . str_pad($count, 2, '0', STR_PAD_LEFT);
    }

    if ($id) {
        // Update
        $stmt = $pdo->prepare("
            UPDATE tblsection 
            SET grade_level_id = ?, strand = ?, section_name = ?, updated_at = NOW()
            WHERE id = ?
        ");
        $stmt->execute([$gradeLevelId, $strand, $sectionName, $id]);
        echo json_encode(['success' => true, 'message' => 'Section updated successfully.']);
    } else {
        // Insert
        $stmt = $pdo->prepare("
            INSERT INTO tblsection (grade_level_id, strand, section_code, section_name, created_at, updated_at)
            VALUES (?, ?, ?, ?, NOW(), NOW())
        ");
        $stmt->execute([$gradeLevelId, $strand, $sectionCode, $sectionName]);
        echo json_encode(['success' => true, 'message' => 'Section created successfully.']);
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}