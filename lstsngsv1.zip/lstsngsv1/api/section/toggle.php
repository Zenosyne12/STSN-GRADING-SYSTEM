<?php
require_once __DIR__.'/../shared/db_connect.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$id   = (int)($data['id'] ?? 0);

if (!$id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Bad ID']);
    exit;
}

$stmt = $pdo->prepare("UPDATE tblsection SET is_active = 1 - is_active WHERE id = ?");
$stmt->execute([$id]);

try {
    if ($stmt->rowCount() > 0) {
        logActivity($pdo, 'Sections', 'UPDATE', 'section', $id, 'Section activation toggled');
    }
} catch (Throwable $e) {}

echo json_encode(['success' => $stmt->rowCount() > 0]);
?>