<?php
require_once '../shared/db_connect.php';
$stmt=$db->query("SELECT id, section_name FROM tblsection WHERE is_active=1");
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
