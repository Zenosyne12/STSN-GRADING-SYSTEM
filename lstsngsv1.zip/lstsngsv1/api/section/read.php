<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $page = max(1, (int)($_GET['p'] ?? 1));
    $search = trim($_GET['s'] ?? '');
    $perPage = 5;
    $offset = ($page - 1) * $perPage;

    $where = "WHERE 1=1";
    $params = [];

    if ($search !== '') {
        $where .= " AND (s.section_name LIKE ? OR s.section_code LIKE ? OR gl.grade_level_name LIKE ?)";
        $like = "%$search%";
        $params = [$like, $like, $like];
    }

    // Count
    $countStmt = $pdo->prepare("
        SELECT COUNT(*) as total 
        FROM tblsection s
        LEFT JOIN tblgradelevel gl ON gl.id = s.grade_level_id
        $where
    ");
    $countStmt->execute($params);
    $total = (int)$countStmt->fetch(PDO::FETCH_ASSOC)['total'];
    $pages = max(1, ceil($total / $perPage));

    // Fetch
    $sql = "
        SELECT s.id, s.grade_level_id, s.strand, s.section_code, s.section_name, s.is_active,
               gl.grade_level_name
        FROM tblsection s
        LEFT JOIN tblgradelevel gl ON gl.id = s.grade_level_id
        $where
        ORDER BY gl.sort_order ASC, s.section_name ASC
        LIMIT $perPage OFFSET $offset
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    echo json_encode([
        'success' => true,
        'sections' => $stmt->fetchAll(PDO::FETCH_ASSOC),
        'page' => $page,
        'pages' => $pages,
        'total' => $total
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}