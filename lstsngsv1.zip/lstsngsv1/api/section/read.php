<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

$page = max(1, (int) ($_GET['p'] ?? $_GET['page'] ?? 1));
$search = trim((string) ($_GET['s'] ?? $_GET['search'] ?? ''));
$perPage = 5;
$offset = ($page - 1) * $perPage;

try {
    $where = ['1 = 1'];
    $params = [];

    if ($search !== '') {
        $where[] = "(
            s.section_name LIKE ?
            OR g.grade_level_name LIKE ?
        )";

        $like = '%' . $search . '%';
        $params[] = $like;
        $params[] = $like;
    }

    $whereSql = implode(' AND ', $where);

    $countStmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM tblsection s
        LEFT JOIN tblgradelevel g ON g.id = s.grade_level_id
        WHERE {$whereSql}
    ");
    $countStmt->execute($params);
    $total = (int) $countStmt->fetchColumn();

    $pages = max(1, (int) ceil($total / $perPage));

    if ($page > $pages) {
        $page = $pages;
        $offset = ($page - 1) * $perPage;
    }

    $stmt = $pdo->prepare("
        SELECT
            s.id,
            s.grade_level_id,
            s.section_name,
            s.is_active,
            g.grade_level_name
        FROM tblsection s
        LEFT JOIN tblgradelevel g ON g.id = s.grade_level_id
        WHERE {$whereSql}
        ORDER BY g.id ASC, s.section_name ASC
        LIMIT {$perPage} OFFSET {$offset}
    ");
    $stmt->execute($params);
    $sections = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'sections' => $sections,
        'page' => $page,
        'pages' => $pages,
        'total' => $total,
        'per_page' => $perPage
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Failed to load sections: ' . $e->getMessage()
    ]);
}