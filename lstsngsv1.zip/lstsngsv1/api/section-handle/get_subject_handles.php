<?php
session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../shared/db_connect.php';

if (!$pdo) {
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed.'
    ]);
    exit;
}

$teacherId = null;

if (isset($_SESSION['teacher_id']) && is_numeric($_SESSION['teacher_id'])) {
    $teacherId = (int) $_SESSION['teacher_id'];
} elseif (isset($_SESSION['reference_id']) && is_numeric($_SESSION['reference_id'])) {
    $teacherId = (int) $_SESSION['reference_id'];
} elseif (isset($_SESSION['user']['reference_id']) && is_numeric($_SESSION['user']['reference_id'])) {
    $teacherId = (int) $_SESSION['user']['reference_id'];
} elseif (isset($_GET['teacher_id']) && is_numeric($_GET['teacher_id'])) {
    $teacherId = (int) $_GET['teacher_id'];
}

if (!$teacherId) {
    echo json_encode([
        'success' => false,
        'message' => 'Teacher session not found.'
    ]);
    exit;
}

try {
    $activeYearStmt = $pdo->prepare("
        SELECT id, year_label
        FROM tblacademicyear
        WHERE is_active = 1
        LIMIT 1
    ");
    $activeYearStmt->execute();
    $activeYear = $activeYearStmt->fetch(PDO::FETCH_ASSOC);

    if (!$activeYear) {
        echo json_encode([
            'success' => false,
            'message' => 'No active academic year found.'
        ]);
        exit;
    }

    $academicYearId = (int) $activeYear['id'];
    $schoolYear = $activeYear['year_label'];
    $activeTermStmt = $pdo->prepare("
        SELECT id, term_number
        FROM tblconfig_terms
        WHERE academic_year_id = ? AND is_active = 1 AND is_closed = 0
        ORDER BY term_number
        LIMIT 1
    ");
    $activeTermStmt->execute([$academicYearId]);
    $activeTerm = $activeTermStmt->fetch(PDO::FETCH_ASSOC) ?: [];
    $termId = (int)($activeTerm['id'] ?? 0);
    $quarter = (int)($activeTerm['term_number'] ?? 0);

    $stmt = $pdo->prepare("
        SELECT
            sch.section_id,sch.subject_id, sub.subject_name AS subject_name, gl.grade_level_name AS grade_level_name, sec.section_name AS section_name,
            COUNT(DISTINCT ss.student_id) AS total_students,
            CASE
                WHEN MAX(ts.submitted_at) IS NULL THEN 'No'
                WHEN MAX(CASE WHEN wfi.status = 'COMPLETED' THEN 1 ELSE 0 END) = 1 THEN 'Published'
                ELSE 'Processing'
            END AS submitted_status
        FROM tblschedule sch
        INNER JOIN tblsection sec
            ON sec.id = sch.section_id
        INNER JOIN tblsubjects sub
            ON sub.id = sch.subject_id
           AND sub.grade_level_id = sec.grade_level_id
           AND CAST(sub.strand AS CHAR) <=> CAST(sec.strand AS CHAR)
           AND sub.academic_year_id = (
               SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1
           )
        LEFT JOIN tblgradelevel gl
            ON gl.id = sec.grade_level_id
        LEFT JOIN tblsectionstudent ss
            ON ss.section_id = sch.section_id
            AND ss.is_active = 1
        LEFT JOIN tblteacher_submissions ts
            ON ts.teacher_id = sch.teacher_id
            AND ts.section_id = sch.section_id
            AND ts.subject_id = sch.subject_id
            AND ts.school_year = :school_year
            AND ts.quarter = :quarter
        LEFT JOIN tblworkflow_instance wfi
            ON wfi.teacher_id = sch.teacher_id
            AND wfi.section_id = sch.section_id
            AND wfi.subject_id = sch.subject_id
            AND wfi.term_id = :term_id
            AND wfi.academic_year_id = :academic_year_id
            AND wfi.id = (
                SELECT MAX(wfi_latest.id)
                FROM tblworkflow_instance wfi_latest
                WHERE wfi_latest.teacher_id = sch.teacher_id
                  AND wfi_latest.section_id = sch.section_id
                  AND wfi_latest.subject_id = sch.subject_id
                  AND wfi_latest.term_id = :latest_term_id
                  AND wfi_latest.academic_year_id = :latest_academic_year_id
            )
        WHERE sch.teacher_id = :teacher_id
          AND sch.is_active = 1
                    AND sch.school_year = (
                            SELECT year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1
                    )
        GROUP BY
            sch.section_id,
            sch.subject_id,
            sub.subject_name,
            gl.grade_level_name,
            sec.section_name
        ORDER BY
            sub.subject_name ASC,
            gl.grade_level_name ASC,
            sec.section_name ASC
    ");

    $stmt->execute([
        ':teacher_id' => $teacherId,
        ':school_year' => $schoolYear,
        ':quarter' => $quarter,
        ':term_id' => $termId,
        ':academic_year_id' => $academicYearId,
        ':latest_term_id' => $termId,
        ':latest_academic_year_id' => $academicYearId
    ]);

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $data = [];

    foreach ($rows as $row) {
        $sectionLabel = trim(($row['grade_level_name'] ?? '') . ' - ' . ($row['section_name'] ?? ''), ' -');

        $data[] = [
            'section_id' => (int) $row['section_id'],
            'subject_id' => (int) $row['subject_id'],
            'subject' => $row['subject_name'] ?? '',
            'section' => $sectionLabel,
            'schedule' => 'Schedule not available',
            'students' => (int) ($row['total_students'] ?? 0),
            'pending' => 0,
            'submitted' => $row['submitted_status'] ?? 'No',
            'average' => '--',
            'at_risk' => 0
        ];
    }

    echo json_encode([
        'success' => true,
        'message' => 'Subject handles loaded successfully.',
        'academic_year' => $schoolYear,
        'teacher_id' => $teacherId,
        'data' => $data
    ]);
    exit;

} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Query failed: ' . $e->getMessage()
    ]);
    exit;
}