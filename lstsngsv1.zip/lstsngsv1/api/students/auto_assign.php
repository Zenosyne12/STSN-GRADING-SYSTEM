<?php
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/settings_schema.php';

stsnEnsureSettingsSchema($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    stsnJsonOut(['success' => false, 'error' => 'Method not allowed'], 405);
}

$input = stsnJsonInput();
$studentIds = [];
if (!empty($input['student_ids']) && is_array($input['student_ids'])) {
    foreach ($input['student_ids'] as $id) {
        $id = (int) $id;
        if ($id > 0) {
            $studentIds[] = $id;
        }
    }
} elseif (!empty($input['student_id'])) {
    $studentIds[] = (int) $input['student_id'];
}

$gradeLevelId = (int) ($input['grade_level_id'] ?? 0);
$academicYearId = (int) ($input['academic_year_id'] ?? 0);
$strand = isset($input['strand']) ? trim((string) $input['strand']) : '';

if (!$academicYearId) {
    $academicYearId = stsnActiveAcademicYearId($pdo);
}

if (!$studentIds || $gradeLevelId <= 0 || $academicYearId <= 0) {
    stsnJsonOut([
        'success' => false,
        'error' => 'student_id, grade_level_id, and academic_year_id are required',
    ], 422);
}

$assigned = [];
$unassigned = [];
$lastError = '';
$lastCode = '';

foreach ($studentIds as $studentId) {
    $result = autoAssignStudentToSection($pdo, $studentId, $gradeLevelId, $academicYearId, $strand !== '' ? $strand : null);
    if (!empty($result['success'])) {
        $assigned[] = [
            'student_id' => $studentId,
            'section_id' => $result['section_id'] ?? null,
            'section_name' => $result['section_name'] ?? '',
        ];
    } else {
        $lastError = $result['error'] ?? 'Unable to assign student';
        $lastCode = $result['code'] ?? '';
        $unassigned[] = $studentId;
    }
}

$gradeName = stsnGradeLevelName($pdo, $gradeLevelId);

if (count($studentIds) === 1) {
    if ($assigned) {
        $row = $assigned[0];
        try {
            logActivity($pdo, 'Sections', 'UPDATE', 'section', (int)($row['section_id'] ?? 0) ?: null,
                'Auto-assigned 1 student to grade ' . $gradeName);
        } catch (Throwable $e) {}
        stsnJsonOut([
            'success' => true,
            'section_id' => $row['section_id'],
            'section_name' => $row['section_name'],
            'message' => 'Student assigned to Section ' . $row['section_name'],
            'grade_level_id' => $gradeLevelId,
            'grade_level_name' => $gradeName,
        ]);
    }
    stsnJsonOut([
        'success' => false,
        'error' => $lastError ?: 'All sections at capacity',
        'code' => $lastCode ?: 'full',
        'grade_level_id' => $gradeLevelId,
        'grade_level_name' => $gradeName,
    ]);
}

try {
    if (count($assigned) > 0) {
        logActivity($pdo, 'Sections', 'UPDATE', 'section', $gradeLevelId,
            'Auto-assigned ' . count($assigned) . ' student(s) to grade ' . $gradeName);
    }
} catch (Throwable $e) {}

stsnJsonOut([
    'success' => count($unassigned) === 0,
    'assigned' => $assigned,
    'unassigned' => $unassigned,
    'assigned_count' => count($assigned),
    'unassigned_count' => count($unassigned),
    'error' => $unassigned ? ($lastError ?: 'All sections at capacity') : null,
    'code' => $unassigned ? ($lastCode ?: 'full') : null,
    'message' => count($assigned) . ' student(s) assigned to sections',
    'grade_level_id' => $gradeLevelId,
    'grade_level_name' => $gradeName,
]);
