<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $id = (int)($_GET['id'] ?? 0);

    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(['error' => 'Bad ID']);
        exit;
    }

    $stmt = $pdo->prepare("
        SELECT
            s.id,
            ay.id AS academic_year_id,
            s.section_id,
            s.subject_id,
            s.teacher_id,
            s.day_name,
            s.time_start,
            s.time_end,
            s.room,
            s.is_active
        FROM tblschedule s
        LEFT JOIN tblacademicyear ay ON ay.year_label = s.school_year
        WHERE s.id = ?
        LIMIT 1
    ");
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        http_response_code(404);
        echo json_encode(['error' => 'Schedule not found']);
        exit;
    }

    echo json_encode($row);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}