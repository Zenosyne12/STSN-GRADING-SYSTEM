<?php
/**
 * Schedule configuration API.
 *
 * GET  ?section_id=&academic_year_id=
 *      -> school schedule configuration, the curriculum resolved for the
 *         section's grade level + academic year, and the per-subject
 *         requirement summary (meetings/minutes per week).
 *
 * POST JSON { setting_key: value, ... } (whitelisted schedule_* keys)
 *      -> update the configurable school schedule parameters.
 */
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/schedule_engine.php';
header('Content-Type: application/json');

const SCHEDULE_SETTING_KEYS = [
    'schedule_days',
    'schedule_start',
    'schedule_end',
    'schedule_break_start',
    'schedule_break_end',
    'schedule_lunch_start',
    'schedule_lunch_end',
    'schedule_slot_step',
    'schedule_rooms',
];

function scheduleConfigRespond(array $payload, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($payload);
    exit;
}

try {
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    /* ---------------- POST: update school schedule settings ---------------- */
    if ($method === 'POST') {
        $data = json_decode(file_get_contents('php://input'), true);
        if (!is_array($data)) {
            scheduleConfigRespond(['success' => false, 'error' => 'Invalid JSON payload.'], 422);
        }

        $updates = [];
        foreach ($data as $key => $value) {
            if (!in_array($key, SCHEDULE_SETTING_KEYS, true)) {
                continue; // ignore unknown keys (do not allow arbitrary writes)
            }
            if (is_array($value)) {
                $value = implode(',', $value);
            }
            $updates[$key] = trim((string) $value);
        }

        if (!$updates) {
            scheduleConfigRespond([
                'success' => false,
                'error'   => 'No valid schedule setting keys were provided.',
                'allowed' => SCHEDULE_SETTING_KEYS,
            ], 422);
        }

        $stmt = $pdo->prepare(
            "INSERT INTO tblsystemsettings (setting_key, setting_value)
             VALUES (?, ?)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)"
        );
        foreach ($updates as $key => $value) {
            $stmt->execute([$key, $value]);
        }

        scheduleConfigRespond([
            'success' => true,
            'message' => 'School schedule configuration saved.',
            'updated' => array_keys($updates),
        ]);
    }

    /* ---------------- GET: read configuration + curriculum ------------------ */
    $sectionId = (int) ($_GET['section_id'] ?? 0);
    $academicYearId = (int) ($_GET['academic_year_id'] ?? 0);

    $cfg = scheduleLoadSchoolConfig($pdo);

    $payload = [
        'success'          => true,
        'school'           => [
            'days'       => $cfg['days'],
            'start_time' => $cfg['start_time'],
            'end_time'   => $cfg['end_time'],
            'break'      => $cfg['break_start'] && $cfg['break_end']
                ? $cfg['break_start'] . '-' . $cfg['break_end'] : null,
            'lunch'      => $cfg['lunch_start'] && $cfg['lunch_end']
                ? $cfg['lunch_start'] . '-' . $cfg['lunch_end'] : null,
            'rooms'      => $cfg['rooms'],
            'slot_step'  => $cfg['slot_step'],
        ],
        'settings_warnings' => $cfg['warnings'],
        'section_id'       => $sectionId,
        'academic_year_id' => $academicYearId,
        'curriculum'       => null,
        'grade_level'      => null,
        'requirements'     => [],
        'warnings'         => [],
    ];

    if ($sectionId > 0 && $academicYearId > 0) {
        $yearStmt = $pdo->prepare("SELECT year_label FROM tblacademicyear WHERE id = ? LIMIT 1");
        $yearStmt->execute([$academicYearId]);
        $year = $yearStmt->fetch(PDO::FETCH_ASSOC);
        if (!$year) {
            scheduleConfigRespond(['success' => false, 'error' => 'Invalid academic year.'], 422);
        }

        $sectionStmt = $pdo->prepare(
            "SELECT s.id, s.section_name, s.grade_level_id, s.strand, g.grade_level_name, g.grade_level_code
             FROM tblsection s
             LEFT JOIN tblgradelevel g ON g.id = s.grade_level_id
             WHERE s.id = ? LIMIT 1"
        );
        $sectionStmt->execute([$sectionId]);
        $section = $sectionStmt->fetch(PDO::FETCH_ASSOC);
        if (!$section) {
            scheduleConfigRespond(['success' => false, 'error' => 'Section not found.'], 404);
        }

        $gradeLevelId = (int) $section['grade_level_id'];
        $payload['section'] = [
            'id'          => (int) $section['id'],
            'name'        => $section['section_name'],
            'grade_level' => $section['grade_level_name'],
            'strand'      => $section['strand'],
        ];
        $payload['grade_level'] = [
            'id'   => $gradeLevelId,
            'name' => $section['grade_level_name'],
            'code' => (int) $section['grade_level_code'],
        ];
        $payload['academic_year'] = ['id' => $academicYearId, 'label' => $year['year_label']];

        $resolved = scheduleResolveCurriculum($pdo, $gradeLevelId, (string) $year['year_label']);
        $payload['curriculum'] = $resolved['curriculum'] ? [
            'id'                    => (int) $resolved['curriculum']['curriculum_id'],
            'name'                  => $resolved['curriculum']['curriculum_name'],
            'version'               => $resolved['curriculum']['curriculum_version'],
            'effective_school_year' => $resolved['curriculum']['effective_school_year'],
            'description'           => $resolved['curriculum']['description'],
            'configured_for_grade'  => $resolved['configured_for_grade'],
        ] : null;

        // Per-subject requirement summary for the grade (curriculum config)
        if ($resolved['curriculum']) {
            $reqs = scheduleLoadCurriculumRequirements($pdo, (int) $resolved['curriculum']['curriculum_id'], $gradeLevelId);
            $requirements = [];
            foreach ($reqs['configured'] as $sid => $row) {
                $requirements[] = [
                    'subject_id'             => $sid,
                    'subject_code'           => $row['subject_code'],
                    'subject_name'           => $row['subject_name'],
                    'subject_type'           => $row['subject_type'],
                    'applicable_period'      => $row['applicable_period'],
                    'meetings_per_week'      => $row['meetings_per_week'],
                    'minutes_per_meeting'    => $row['minutes_per_meeting'],
                    'total_required_minutes' => $row['total_required_minutes'],
                    'is_required'            => (int) $row['is_required'],
                    'source_reference'       => $row['source_reference'],
                    'is_official'            => (int) $row['is_official'],
                ];
            }
            usort($requirements, function ($a, $b) {
                return strcmp((string) $a['subject_name'], (string) $b['subject_name']);
            });
            $payload['requirements'] = $requirements;

            if (!$resolved['configured_for_grade']) {
                $payload['warnings'][] = sprintf(
                    'No curriculum configuration exists for %s in the applicable curriculum. Add rows to tblcurriculum_subjects for this grade before using Auto Generate.',
                    (string) ($section['grade_level_name'] ?? 'this grade level')
                );
            }
        } else {
            $payload['warnings'][] = 'No active curriculum applies to the selected academic year.';
        }
    }

    scheduleConfigRespond($payload);
} catch (Throwable $e) {
    scheduleConfigRespond(['success' => false, 'error' => $e->getMessage()], 500);
}
