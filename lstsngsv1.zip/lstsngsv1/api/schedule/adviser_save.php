<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

$sectionId = (int)($data['section_id'] ?? 0);
$academicYearId = (int)($data['academic_year_id'] ?? 0);
$teacherId = isset($data['teacher_id']) && $data['teacher_id'] !== '' ? (int)$data['teacher_id'] : null;

if ($sectionId <= 0 || $academicYearId <= 0) {
    echo json_encode([
        'success' => false,
        'error' => 'Invalid section or academic year.'
    ]);
    exit;
}

try {
    $check = $pdo->prepare("
        SELECT id
        FROM tblsectionadviser
        WHERE section_id = ?
          AND academic_year_id = ?
        LIMIT 1
    ");
    $check->execute([$sectionId, $academicYearId]);
    $existing = $check->fetch(PDO::FETCH_ASSOC);

    if ($existing) {
        $stmt = $pdo->prepare("
            UPDATE tblsectionadviser
            SET teacher_id = ?
            WHERE id = ?
        ");
        $stmt->execute([$teacherId, $existing['id']]);
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO tblsectionadviser (section_id, academic_year_id, teacher_id)
            VALUES (?, ?, ?)
        ");
        $stmt->execute([$sectionId, $academicYearId, $teacherId]);
    }

    echo json_encode([
        'success' => true
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}