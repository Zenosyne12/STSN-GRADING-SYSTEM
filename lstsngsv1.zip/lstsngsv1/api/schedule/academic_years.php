<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $stmt = $pdo->query("
        SELECT id, year_label, is_active
        FROM tblacademicyear
        ORDER BY is_active DESC, id DESC
    ");

    $years = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $activeYear = null;
    foreach ($years as $year) {
        if ((int)$year['is_active'] === 1) {
            $activeYear = $year;
            break;
        }
    }

    if (!$activeYear && !empty($years)) {
        $activeYear = $years[0];
    }

    echo json_encode([
        'success' => true,
        'academic_years' => $years,
        'active_year' => $activeYear
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'academic_years' => [],
        'active_year' => null,
        'error' => $e->getMessage()
    ]);
}