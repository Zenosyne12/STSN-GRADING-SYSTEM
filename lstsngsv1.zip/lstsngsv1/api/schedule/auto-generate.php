﻿<?php
/**
 * Auto Generate â€” curriculum-aware schedule generation.
 *
 * POST JSON: { section_id: int, academic_year_id: int }
 *
 * The heavy lifting lives in api/shared/schedule_engine.php:
 *   1. validate section + academic year
 *   2. determine the grade level of the section
 *   3. resolve the curriculum applicable to that grade for that AY
 *   4. load only subjects applicable to the grade (+ strand/semester)
 *   5. load each subject's configured meetings/minutes requirement
 *   6. load eligible teachers (section assignments first)
 *   7. load configured rooms, school hours, breaks and lunch
 *   8. skip subjects that already have a valid schedule
 *   9. generate a candidate timetable (meetings spread across days)
 *  10. validate section/teacher/room conflicts
 *  11. save only valid records inside one transaction
 *  12. return a detailed JSON response (unscheduled subjects included)
 */
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/schedule_engine.php';
header('Content-Type: application/json');

function jsonError(string $message, int $statusCode = 422, array $extra = []): void
{
    http_response_code($statusCode);
    echo json_encode(array_merge(['success' => false, 'error' => $message], $extra));
    exit;
}

try {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!is_array($data)) {
        $data = [];
    }

    $sectionId = (int) ($data['section_id'] ?? 0);
    $academicYearId = (int) ($data['academic_year_id'] ?? 0);

    $result = scheduleGenerateForSection($pdo, $sectionId, $academicYearId);
    try {
        if (!empty($result['success'])) {
            logActivity($pdo, 'Schedule', 'CREATE', 'schedule', $sectionId,
                'Auto-generated schedule');
        }
    } catch (Throwable $e) {}
    echo json_encode($result);
} catch (ScheduleEngineException $e) {
    jsonError($e->getMessage(), 422, ['details' => [$e->getMessage()]]);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    jsonError($e->getMessage(), 500, ['details' => [$e->getMessage()]]);
}
