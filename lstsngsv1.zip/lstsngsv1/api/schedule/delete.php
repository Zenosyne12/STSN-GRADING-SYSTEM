<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Support both single 'id' and array 'ids' for compatibility
    $ids = [];
    
    if (isset($data['ids']) && is_array($data['ids'])) {
        $ids = array_map('intval', array_filter($data['ids'], 'is_numeric'));
    } elseif (isset($data['id']) && is_numeric($data['id'])) {
        $ids = [(int)$data['id']];
    }

    if (empty($ids)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid ID(s)']);
        exit;
    }

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("DELETE FROM tblschedule WHERE id IN ($placeholders)");
    $stmt->execute($ids);

    echo json_encode(['success' => true]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}