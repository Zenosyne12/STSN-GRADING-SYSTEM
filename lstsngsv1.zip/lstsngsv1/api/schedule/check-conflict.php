<?php
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/schedule_engine.php';
header('Content-Type: application/json');

function respondConflict(bool $hasConflict, ?array $row = null, string $type = 'section'): void
{
    $response = [
        'has_conflict' => $hasConflict,
        'conflict_type' => $type,
        'conflicting_teacher' => $row['teacher_name'] ?? null,
        'conflicting_subject' => $row['subject_name'] ?? null,
        'conflicting_time_start' => $row['time_start'] ?? null,
        'conflicting_time_end' => $row['time_end'] ?? null,
        'conflicting_section' => $row['section_name'] ?? null,
    ];

    if ($hasConflict && $row !== null) {
        $response['conflict'] = [
            'section_id' => (int) ($row['section_id'] ?? 0),
            'section_name' => $row['section_name'] ?? '',
            'grade_level_name' => $row['grade_level_name'] ?? '',
            'subject_name' => $row['subject_name'] ?? '',
            'day_name' => $row['day_name'] ?? '',
            'time_start' => $row['time_start'] ?? '',
            'time_end' => $row['time_end'] ?? '',
        ];
    }

    echo json_encode($response);
}

try {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!is_array($data)) {
        $data = [];
    }

    $sectionId = (int)($data['section_id'] ?? 0);
    $academicYearId = (int)($data['academic_year_id'] ?? 0);
    $dayName = trim($data['day_name'] ?? '');
    $timeStart = trim($data['time_start'] ?? '');
    $timeEnd = trim($data['time_end'] ?? '');
    $teacherId = isset($data['teacher_id']) && $data['teacher_id'] !== ''
        ? (int) $data['teacher_id']
        : null;
    $room = trim($data['room'] ?? '');
    $excludeScheduleIds = array_values(array_filter(array_map('intval', $data['exclude_schedule_ids'] ?? [])));

    // Configurable school days (falls back to Monday-Friday)
    $validDays = scheduleLoadSchoolConfig($pdo)['days'];

    if ($sectionId <= 0 || $academicYearId <= 0 || $dayName === '' || $timeStart === '' || $timeEnd === '') {
        http_response_code(422);
        echo json_encode(['has_conflict' => false, 'error' => 'Section, academic year, day, start time, and end time are required']);
        exit;
    }

    if (!in_array($dayName, $validDays, true)) {
        http_response_code(422);
        echo json_encode(['has_conflict' => false, 'error' => 'Invalid day']);
        exit;
    }

    if ($timeStart >= $timeEnd) {
        http_response_code(422);
        echo json_encode(['has_conflict' => false, 'error' => 'Start time must be before end time']);
        exit;
    }

    $yearStmt = $pdo->prepare("SELECT year_label FROM tblacademicyear WHERE id = ? LIMIT 1");
    $yearStmt->execute([$academicYearId]);
    $yearRow = $yearStmt->fetch(PDO::FETCH_ASSOC);

    if (!$yearRow) {
        http_response_code(422);
        echo json_encode(['has_conflict' => false, 'error' => 'Invalid academic year']);
        exit;
    }

    $schoolYear = $yearRow['year_label'];
    $excludeClause = '';
    $params = [];

    if (!empty($excludeScheduleIds)) {
        $placeholders = implode(',', array_fill(0, count($excludeScheduleIds), '?'));
        $excludeClause = " AND sc.id NOT IN ($placeholders)";
    }

    // 1) Section overlap (existing behavior: any active section slot in the range)
    $sql = "
        SELECT
            sc.id,
            sc.teacher_id,
            sc.section_id,
            sc.day_name,
            sc.time_start,
            sc.time_end,
            CONCAT(
                t.lname, ', ', t.fname,
                CASE
                    WHEN t.mname IS NULL OR t.mname = '' THEN ''
                    ELSE CONCAT(' ', LEFT(t.mname, 1), '.')
                END
            ) AS teacher_name,
            sub.subject_name,
            sec.section_name,
            gl.grade_level_name
        FROM tblschedule sc
        INNER JOIN tblteacher t ON sc.teacher_id = t.id
        INNER JOIN tblsubjects sub ON sc.subject_id = sub.id
        LEFT JOIN tblsection sec ON sec.id = sc.section_id
        LEFT JOIN tblgradelevel gl ON gl.id = sec.grade_level_id
        WHERE sc.section_id = ?
          AND sc.school_year = ?
          AND sc.day_name = ?
          AND COALESCE(sc.is_active, 1) = 1
          AND sc.time_start < ?
          AND sc.time_end > ?
          $excludeClause
    ";
    $params = [$sectionId, $schoolYear, $dayName, $timeEnd, $timeStart];

    if ($excludeClause !== '') {
        $params = array_merge($params, $excludeScheduleIds);
    }

    $sql .= " ORDER BY sc.time_start ASC LIMIT 1";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $conflict = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($conflict) {
        respondConflict(true, $conflict, 'section');
        exit;
    }

    // 2) Teacher overlap
    if ($teacherId !== null && $teacherId > 0) {
        $teacherSql = "
            SELECT
                sc.id,
                sc.section_id,
                sc.day_name,
                sc.time_start,
                sc.time_end,
                sec.section_name,
                gl.grade_level_name,
                sub.subject_name
            FROM tblschedule sc
            LEFT JOIN tblsection sec ON sec.id = sc.section_id
            LEFT JOIN tblgradelevel gl ON gl.id = sec.grade_level_id
            LEFT JOIN tblsubjects sub ON sub.id = sc.subject_id
            WHERE sc.school_year = ? AND sc.teacher_id = ? AND sc.day_name = ?
              AND ? < sc.time_end AND ? > sc.time_start
              $excludeClause
            LIMIT 1
        ";
        $teacherParams = [$schoolYear, $teacherId, $dayName, $timeStart, $timeEnd];
        if ($excludeClause !== '') {
            $teacherParams = array_merge($teacherParams, $excludeScheduleIds);
        }

        $teacherStmt = $pdo->prepare($teacherSql);
        $teacherStmt->execute($teacherParams);
        if ($teacherConflict = $teacherStmt->fetch(PDO::FETCH_ASSOC)) {
            respondConflict(true, $teacherConflict, 'teacher');
            exit;
        }
    }

    // 3) Room overlap
    if ($room !== '') {
        $roomSql = "
            SELECT
                sc.id,
                sc.room,
                sc.section_id,
                sc.day_name,
                sc.time_start,
                sc.time_end,
                CONCAT(
                    t.lname, ', ', t.fname,
                    CASE
                        WHEN t.mname IS NULL OR t.mname = '' THEN ''
                        ELSE CONCAT(' ', LEFT(t.mname, 1), '.')
                    END
                ) AS teacher_name,
                sub.subject_name,
                sec.section_name,
                gl.grade_level_name
            FROM tblschedule sc
            INNER JOIN tblteacher t ON sc.teacher_id = t.id
            INNER JOIN tblsubjects sub ON sc.subject_id = sub.id
            LEFT JOIN tblsection sec ON sec.id = sc.section_id
            LEFT JOIN tblgradelevel gl ON gl.id = sec.grade_level_id
            WHERE sc.school_year = ?
              AND sc.day_name = ?
              AND COALESCE(sc.is_active, 1) = 1
              AND sc.room = ?
              AND sc.section_id <> ?
              AND sc.time_start < ?
              AND sc.time_end > ?
              $excludeClause
            ORDER BY sc.time_start ASC
            LIMIT 1
        ";
        $roomParams = [$schoolYear, $dayName, $room, $sectionId, $timeEnd, $timeStart];
        if ($excludeClause !== '') {
            $roomParams = array_merge($roomParams, $excludeScheduleIds);
        }
        $roomStmt = $pdo->prepare($roomSql);
        $roomStmt->execute($roomParams);
        $roomConflict = $roomStmt->fetch(PDO::FETCH_ASSOC);

        if ($roomConflict) {
            respondConflict(true, $roomConflict, 'room');
            exit;
        }
    }

    respondConflict(false);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'has_conflict' => false,
        'error' => $e->getMessage(),
    ]);
}
