<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

$stmt = $pdo->query("SELECT id, grade_level_name FROM tblgradelevel ORDER BY id ASC");

echo json_encode([
    'grade_levels' => $stmt->fetchAll(PDO::FETCH_ASSOC)
]);