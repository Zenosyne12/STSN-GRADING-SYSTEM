<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $id = (int)($_GET['id'] ?? 0);

    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Bad ID']);
        exit;
    }

    $stmt = $pdo->prepare("
        SELECT
            s.id,
            s.section_name,
            s.grade_level_id,
            g.grade_level_name,
            (
                SELECT ay.id
                FROM tblacademicyear ay
                WHERE COALESCE(ay.is_active, 1) = 1
                ORDER BY ay.id DESC
                LIMIT 1
            ) AS default_academic_year_id
        FROM tblsection s
        LEFT JOIN tblgradelevel g ON s.grade_level_id = g.id
        WHERE s.id = ?
        LIMIT 1
    ");
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Section not found']);
        exit;
    }

    echo json_encode([
        'success' => true,
        'data' => $row
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>