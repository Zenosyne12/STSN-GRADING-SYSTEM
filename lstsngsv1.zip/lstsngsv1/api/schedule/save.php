<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $data = json_decode(file_get_contents('php://input'), true);

    $id = (int)($data['id'] ?? 0);
    $academicYearId = (int)($data['academic_year_id'] ?? 0);
    $sectionId = (int)($data['section_id'] ?? 0);
    $subjectId = (int)($data['subject_id'] ?? 0);
    $teacherId = (int)($data['teacher_id'] ?? 0);
    $dayOfWeek = trim($data['day_of_week'] ?? '');
    $timeStart = trim($data['time_start'] ?? '');
    $timeEnd = trim($data['time_end'] ?? '');
    $room = trim($data['room'] ?? '');
    $isActive = (int)($data['is_active'] ?? 1);

    $validDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

    if (
        $academicYearId <= 0 ||
        $sectionId <= 0 ||
        $subjectId <= 0 ||
        $teacherId <= 0 ||
        $dayOfWeek === '' ||
        $timeStart === '' ||
        $timeEnd === ''
    ) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'All required fields must be filled out']);
        exit;
    }

    if (!in_array($dayOfWeek, $validDays, true)) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'Invalid day selected']);
        exit;
    }

    if ($timeStart >= $timeEnd) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'End time must be later than start time']);
        exit;
    }

    $yearStmt = $pdo->prepare("SELECT year_label FROM tblacademicyear WHERE id = ? LIMIT 1");
    $yearStmt->execute([$academicYearId]);
    $yearRow = $yearStmt->fetch(PDO::FETCH_ASSOC);

    if (!$yearRow) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'Invalid academic year']);
        exit;
    }

    $schoolYear = $yearRow['year_label'];

    $subjectConflictSql = "
        SELECT id
        FROM tblschedule
        WHERE school_year = ?
          AND section_id = ?
          AND subject_id = ?
    ";
    $subjectParams = [$schoolYear, $sectionId, $subjectId];

    if ($id > 0) {
        $subjectConflictSql .= " AND id != ? ";
        $subjectParams[] = $id;
    }

    $subjectConflictSql .= " LIMIT 1 ";

    $subjectConflict = $pdo->prepare($subjectConflictSql);
    $subjectConflict->execute($subjectParams);

    if ($subjectConflict->fetch()) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'This subject is already scheduled for this section']);
        exit;
    }

    $teacherConflictSql = "
        SELECT id
        FROM tblschedule
        WHERE school_year = ?
          AND teacher_id = ?
          AND day_name = ?
          AND (? < time_end)
          AND (? > time_start)
    ";
    $teacherParams = [$schoolYear, $teacherId, $dayOfWeek, $timeStart, $timeEnd];

    if ($id > 0) {
        $teacherConflictSql .= " AND id != ? ";
        $teacherParams[] = $id;
    }

    $teacherConflictSql .= " LIMIT 1 ";

    $teacherConflict = $pdo->prepare($teacherConflictSql);
    $teacherConflict->execute($teacherParams);

    if ($teacherConflict->fetch()) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'Teacher has a time conflict on this day']);
        exit;
    }

    $sectionConflictSql = "
        SELECT id
        FROM tblschedule
        WHERE school_year = ?
          AND section_id = ?
          AND day_name = ?
          AND (? < time_end)
          AND (? > time_start)
    ";
    $sectionParams = [$schoolYear, $sectionId, $dayOfWeek, $timeStart, $timeEnd];

    if ($id > 0) {
        $sectionConflictSql .= " AND id != ? ";
        $sectionParams[] = $id;
    }

    $sectionConflictSql .= " LIMIT 1 ";

    $sectionConflict = $pdo->prepare($sectionConflictSql);
    $sectionConflict->execute($sectionParams);

    if ($sectionConflict->fetch()) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'Time slot already occupied in this section']);
        exit;
    }

    if ($id > 0) {
        $stmt = $pdo->prepare("
            UPDATE tblschedule
            SET school_year = ?,
                section_id = ?,
                subject_id = ?,
                teacher_id = ?,
                day_name = ?,
                time_start = ?,
                time_end = ?,
                room = ?,
                is_active = ?
            WHERE id = ?
        ");
        $stmt->execute([
            $schoolYear,
            $sectionId,
            $subjectId,
            $teacherId,
            $dayOfWeek,
            $timeStart,
            $timeEnd,
            $room,
            $isActive,
            $id
        ]);
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO tblschedule (
                school_year,
                section_id,
                subject_id,
                teacher_id,
                day_name,
                time_start,
                time_end,
                room,
                is_active
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $schoolYear,
            $sectionId,
            $subjectId,
            $teacherId,
            $dayOfWeek,
            $timeStart,
            $timeEnd,
            $room,
            $isActive
        ]);
    }

    echo json_encode(['success' => true]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}