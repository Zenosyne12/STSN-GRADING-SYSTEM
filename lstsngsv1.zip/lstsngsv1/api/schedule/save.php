<?php
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/schedule_engine.php';
header('Content-Type: application/json');

try {
    $data = json_decode(file_get_contents('php://input'), true);

    $groupIds       = array_map('intval', $data['group_ids']       ?? []);
    $academicYearId = (int)($data['academic_year_id'] ?? 0);
    $sectionId      = (int)($data['section_id']       ?? 0);
    $subjectId      = (int)($data['subject_id']       ?? 0);
    $clusterId      = isset($data['cluster_id']) && $data['cluster_id'] !== ''
        ? (int) $data['cluster_id']
        : null;
    $teacherId      = (int)($data['teacher_id']        ?? 0);
    $room           = trim($data['room']               ?? '');
    $isActive       = (int)($data['is_active']         ?? 1);
    $days           = $data['days']                    ?? [];

    // Configurable school days (falls back to Monday-Friday)
    $validDays = scheduleLoadSchoolConfig($pdo)['days'];

    
    if ($academicYearId <= 0 || $sectionId <= 0 || $subjectId <= 0 || $teacherId <= 0) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'All required fields must be filled out']);
        exit;
    }

    $sectionStmt = $pdo->prepare('SELECT grade_level_id, strand FROM tblsection WHERE id = ? LIMIT 1');
    $sectionStmt->execute([$sectionId]);
    $sectionRow = $sectionStmt->fetch(PDO::FETCH_ASSOC);
    if (!$sectionRow) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'Invalid section']);
        exit;
    }

    $isShsSection = in_array((int) $sectionRow['grade_level_id'], [11, 12], true);
    if ($isShsSection && ($clusterId === null || $clusterId <= 0)) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'A cluster is required for Grade 11 and Grade 12 schedules']);
        exit;
    }

    if ($clusterId !== null) {
        $clusterStmt = $pdo->prepare('SELECT track FROM tblclusters WHERE id = ? AND is_active = 1 LIMIT 1');
        $clusterStmt->execute([$clusterId]);
        $clusterTrack = $clusterStmt->fetchColumn();
        if ($clusterTrack === false) {
            http_response_code(422);
            echo json_encode(['success' => false, 'error' => 'Select a valid active cluster']);
            exit;
        }

        $sectionTrack = trim((string) ($sectionRow['strand'] ?? ''));
        if (preg_match('/technical-professional/i', $sectionTrack)) {
            $sectionTrack = 'Tech-Pro';
        }
        if (!$isShsSection || $sectionTrack !== $clusterTrack) {
            http_response_code(422);
            echo json_encode(['success' => false, 'error' => 'The selected cluster does not match the section track']);
            exit;
        }
    }

    if (empty($days)) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'At least one day must be added']);
        exit;
    }

    
    $seenDays = [];
    foreach ($days as $i => $row) {
        $dayName   = trim($row['day_name']   ?? '');
        $timeStart = trim($row['time_start'] ?? '');
        $timeEnd   = trim($row['time_end']   ?? '');

        if ($dayName === '' || $timeStart === '' || $timeEnd === '') {
            http_response_code(422);
            echo json_encode(['success' => false, 'error' => 'All day rows must have a day, start time, and end time']);
            exit;
        }

        if (!in_array($dayName, $validDays, true)) {
            http_response_code(422);
            echo json_encode(['success' => false, 'error' => "Invalid day: $dayName"]);
            exit;
        }

        if ($timeStart >= $timeEnd) {
            http_response_code(422);
            echo json_encode(['success' => false, 'error' => "Start time must be before end time on $dayName"]);
            exit;
        }

        if (in_array($dayName, $seenDays, true)) {
            http_response_code(422);
            echo json_encode(['success' => false, 'error' => "Duplicate day: $dayName"]);
            exit;
        }

        $seenDays[] = $dayName;
    }

    
    $yearStmt = $pdo->prepare("SELECT year_label FROM tblacademicyear WHERE id = ? LIMIT 1");
    $yearStmt->execute([$academicYearId]);
    $yearRow = $yearStmt->fetch(PDO::FETCH_ASSOC);

    if (!$yearRow) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'Invalid academic year']);
        exit;
    }

    $schoolYear = $yearRow['year_label'];

    

    
    $subjectConflictSql = "
        SELECT id FROM tblschedule
        WHERE school_year = ? AND section_id = ? AND subject_id = ?
    ";
    $subjectParams = [$schoolYear, $sectionId, $subjectId];

    if (!empty($groupIds)) {
        $placeholders    = implode(',', array_fill(0, count($groupIds), '?'));
        $subjectConflictSql .= " AND id NOT IN ($placeholders)";
        $subjectParams   = array_merge($subjectParams, $groupIds);
    }

    $subjectConflictSql .= " LIMIT 1";
    $stmt = $pdo->prepare($subjectConflictSql);
    $stmt->execute($subjectParams);

    if ($stmt->fetch()) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'This subject is already scheduled for this section']);
        exit;
    }

    
    foreach ($days as $row) {
        $dayName   = $row['day_name'];
        $timeStart = $row['time_start'];
        $timeEnd   = $row['time_end'];

        
        $teacherSql = "
            SELECT id FROM tblschedule
            WHERE school_year = ? AND teacher_id = ? AND day_name = ?
              AND ? < time_end AND ? > time_start
        ";
        $teacherParams = [$schoolYear, $teacherId, $dayName, $timeStart, $timeEnd];

        if (!empty($groupIds)) {
            $placeholders  = implode(',', array_fill(0, count($groupIds), '?'));
            $teacherSql   .= " AND id NOT IN ($placeholders)";
            $teacherParams = array_merge($teacherParams, $groupIds);
        }

        $teacherSql .= " LIMIT 1";
        $stmt = $pdo->prepare($teacherSql);
        $stmt->execute($teacherParams);

        if ($stmt->fetch()) {
            http_response_code(422);
            echo json_encode(['success' => false, 'error' => "Teacher has a time conflict on $dayName"]);
            exit;
        }

        
        $sectionSql = "
            SELECT id FROM tblschedule
            WHERE school_year = ? AND section_id = ? AND day_name = ?
              AND ? < time_end AND ? > time_start
        ";
        $sectionParams = [$schoolYear, $sectionId, $dayName, $timeStart, $timeEnd];

        if (!empty($groupIds)) {
            $placeholders  = implode(',', array_fill(0, count($groupIds), '?'));
            $sectionSql   .= " AND id NOT IN ($placeholders)";
            $sectionParams = array_merge($sectionParams, $groupIds);
        }

        $sectionSql .= " LIMIT 1";
        $stmt = $pdo->prepare($sectionSql);
        $stmt->execute($sectionParams);

        if ($stmt->fetch()) {
            http_response_code(422);
            echo json_encode(['success' => false, 'error' => "Time slot already occupied in this section on $dayName"]);
            exit;
        }

        // Room overlap: the same room cannot host two sections simultaneously.
        if ($room !== '') {
            $roomSql = "
                SELECT sec.section_name FROM tblschedule sc
                LEFT JOIN tblsection sec ON sec.id = sc.section_id
                WHERE sc.school_year = ? AND sc.day_name = ?
                  AND sc.room = ?
                  AND COALESCE(sc.is_active, 1) = 1
                  AND ? < sc.time_end AND ? > sc.time_start
                  AND sc.section_id <> ?
            ";
            $roomParams = [$schoolYear, $dayName, $room, $timeStart, $timeEnd, $sectionId];

            if (!empty($groupIds)) {
                $placeholders  = implode(',', array_fill(0, count($groupIds), '?'));
                $roomSql      .= " AND sc.id NOT IN ($placeholders)";
                $roomParams    = array_merge($roomParams, $groupIds);
            }

            $roomSql .= " LIMIT 1";
            $stmt = $pdo->prepare($roomSql);
            $stmt->execute($roomParams);

            if ($conflictRow = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $conflictingSection = $conflictRow['section_name'] ?? 'another section';
                http_response_code(422);
                echo json_encode([
                    'success' => false,
                    'error'   => "Room $room is already used by $conflictingSection on $dayName at that time"
                ]);
                exit;
            }
        }
    }

    
    $pdo->beginTransaction();

    
    if (!empty($groupIds)) {
        $placeholders = implode(',', array_fill(0, count($groupIds), '?'));
        $pdo->prepare("DELETE FROM tblschedule WHERE id IN ($placeholders)")
            ->execute($groupIds);
    }

    
    $insert = $pdo->prepare("
        INSERT INTO tblschedule
            (school_year, section_id, subject_id, cluster_id, teacher_id, day_name, time_start, time_end, room, is_active)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    foreach ($days as $row) {
        $insert->execute([
            $schoolYear,
            $sectionId,
            $subjectId,
            $clusterId,
            $teacherId,
            $row['day_name'],
            $row['time_start'],
            $row['time_end'],
            $room,
            $isActive,
        ]);
    }

    $pdo->commit();

    try {
        logActivity($pdo, 'Schedule', 'UPDATE', 'schedule', $sectionId,
            'Saved schedule for ' . count($days) . ' day(s)');
    } catch (Throwable $e) {}

    // Mirror to tblsection_teacher_subject for teacher-side visibility
    try {
        $syncStmt = $pdo->prepare("
            INSERT INTO tblsection_teacher_subject
                (section_id, subject_id, teacher_id, academic_year_id, is_active)
            VALUES (?, ?, ?, ?, 1)
            ON DUPLICATE KEY UPDATE
                is_active = 1
        ");
        $syncStmt->execute([
            $sectionId,
            $subjectId,
            $teacherId,
            $academicYearId ?? 0
        ]);
    } catch (Throwable $e) {
        error_log('Sync to tblsection_teacher_subject failed: ' . $e->getMessage());
        // Don't fail the main save
    }

    echo json_encode(['success' => true]);

} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}