<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $data = json_decode(file_get_contents('php://input'), true);

    $groupIds       = array_map('intval', $data['group_ids']       ?? []);
    $academicYearId = (int)($data['academic_year_id'] ?? 0);
    $sectionId      = (int)($data['section_id']       ?? 0);
    $subjectId      = (int)($data['subject_id']       ?? 0);
    $teacherId      = (int)($data['teacher_id']        ?? 0);
    $room           = trim($data['room']               ?? '');
    $isActive       = (int)($data['is_active']         ?? 1);
    $days           = $data['days']                    ?? [];

    $validDays = ['Monday','Tuesday','Wednesday','Thursday','Friday'];

    // ── Basic required-field validation ──────────────────────────────────────
    if ($academicYearId <= 0 || $sectionId <= 0 || $subjectId <= 0 || $teacherId <= 0) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'All required fields must be filled out']);
        exit;
    }

    if (empty($days)) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'At least one day must be added']);
        exit;
    }

    // ── Validate each day row ─────────────────────────────────────────────────
    $seenDays = [];
    foreach ($days as $i => $row) {
        $dayName   = trim($row['day_name']   ?? '');
        $timeStart = trim($row['time_start'] ?? '');
        $timeEnd   = trim($row['time_end']   ?? '');

        if ($dayName === '' || $timeStart === '' || $timeEnd === '') {
            http_response_code(422);
            echo json_encode(['success' => false, 'error' => 'All day rows must have a day, start time, and end time']);
            exit;
        }

        if (!in_array($dayName, $validDays, true)) {
            http_response_code(422);
            echo json_encode(['success' => false, 'error' => "Invalid day: $dayName"]);
            exit;
        }

        if ($timeStart >= $timeEnd) {
            http_response_code(422);
            echo json_encode(['success' => false, 'error' => "Start time must be before end time on $dayName"]);
            exit;
        }

        if (in_array($dayName, $seenDays, true)) {
            http_response_code(422);
            echo json_encode(['success' => false, 'error' => "Duplicate day: $dayName"]);
            exit;
        }

        $seenDays[] = $dayName;
    }

    // ── Resolve school_year label from academic year ID ───────────────────────
    $yearStmt = $pdo->prepare("SELECT year_label FROM tblacademicyear WHERE id = ? LIMIT 1");
    $yearStmt->execute([$academicYearId]);
    $yearRow = $yearStmt->fetch(PDO::FETCH_ASSOC);

    if (!$yearRow) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'Invalid academic year']);
        exit;
    }

    $schoolYear = $yearRow['year_label'];

    // ── Conflict checks (exclude current group_ids being replaced) ────────────

    // 1. Subject already scheduled for this section this year?
    $subjectConflictSql = "
        SELECT id FROM tblschedule
        WHERE school_year = ? AND section_id = ? AND subject_id = ?
    ";
    $subjectParams = [$schoolYear, $sectionId, $subjectId];

    if (!empty($groupIds)) {
        $placeholders    = implode(',', array_fill(0, count($groupIds), '?'));
        $subjectConflictSql .= " AND id NOT IN ($placeholders)";
        $subjectParams   = array_merge($subjectParams, $groupIds);
    }

    $subjectConflictSql .= " LIMIT 1";
    $stmt = $pdo->prepare($subjectConflictSql);
    $stmt->execute($subjectParams);

    if ($stmt->fetch()) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'This subject is already scheduled for this section']);
        exit;
    }

    // 2. Teacher / section time conflicts — check each day row
    foreach ($days as $row) {
        $dayName   = $row['day_name'];
        $timeStart = $row['time_start'];
        $timeEnd   = $row['time_end'];

        // Teacher conflict
        $teacherSql = "
            SELECT id FROM tblschedule
            WHERE school_year = ? AND teacher_id = ? AND day_name = ?
              AND ? < time_end AND ? > time_start
        ";
        $teacherParams = [$schoolYear, $teacherId, $dayName, $timeStart, $timeEnd];

        if (!empty($groupIds)) {
            $placeholders  = implode(',', array_fill(0, count($groupIds), '?'));
            $teacherSql   .= " AND id NOT IN ($placeholders)";
            $teacherParams = array_merge($teacherParams, $groupIds);
        }

        $teacherSql .= " LIMIT 1";
        $stmt = $pdo->prepare($teacherSql);
        $stmt->execute($teacherParams);

        if ($stmt->fetch()) {
            http_response_code(422);
            echo json_encode(['success' => false, 'error' => "Teacher has a time conflict on $dayName"]);
            exit;
        }

        // Section conflict
        $sectionSql = "
            SELECT id FROM tblschedule
            WHERE school_year = ? AND section_id = ? AND day_name = ?
              AND ? < time_end AND ? > time_start
        ";
        $sectionParams = [$schoolYear, $sectionId, $dayName, $timeStart, $timeEnd];

        if (!empty($groupIds)) {
            $placeholders  = implode(',', array_fill(0, count($groupIds), '?'));
            $sectionSql   .= " AND id NOT IN ($placeholders)";
            $sectionParams = array_merge($sectionParams, $groupIds);
        }

        $sectionSql .= " LIMIT 1";
        $stmt = $pdo->prepare($sectionSql);
        $stmt->execute($sectionParams);

        if ($stmt->fetch()) {
            http_response_code(422);
            echo json_encode(['success' => false, 'error' => "Time slot already occupied in this section on $dayName"]);
            exit;
        }
    }

    // ── Save: delete old rows, insert new ones (inside a transaction) ─────────
    $pdo->beginTransaction();

    // Delete existing group rows if editing
    if (!empty($groupIds)) {
        $placeholders = implode(',', array_fill(0, count($groupIds), '?'));
        $pdo->prepare("DELETE FROM tblschedule WHERE id IN ($placeholders)")
            ->execute($groupIds);
    }

    // Insert one row per day
    $insert = $pdo->prepare("
        INSERT INTO tblschedule
            (school_year, section_id, subject_id, teacher_id, day_name, time_start, time_end, room, is_active)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    foreach ($days as $row) {
        $insert->execute([
            $schoolYear,
            $sectionId,
            $subjectId,
            $teacherId,
            $row['day_name'],
            $row['time_start'],
            $row['time_end'],
            $room,
            $isActive,
        ]);
    }

    $pdo->commit();
    echo json_encode(['success' => true]);

} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}