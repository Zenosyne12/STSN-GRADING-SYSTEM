<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $sectionId = (int)($_GET['section_id'] ?? 0);
    $academicYearId = (int)($_GET['academic_year_id'] ?? 0);
    $excludeScheduleId = (int)($_GET['exclude_schedule_id'] ?? 0);

    $schoolYear = null;
    $gradeLevelId = null;

    // Get school year and grade level from section
    if ($sectionId > 0 && $academicYearId > 0) {
        // Get school year
        $yearStmt = $pdo->prepare("SELECT year_label FROM tblacademicyear WHERE id = ? LIMIT 1");
        $yearStmt->execute([$academicYearId]);
        $yearRow = $yearStmt->fetch(PDO::FETCH_ASSOC);
        $schoolYear = $yearRow['year_label'] ?? null;

        // Get grade level from section
        $sectionStmt = $pdo->prepare("
            SELECT grade_level_id 
            FROM tblsection 
            WHERE id = ? 
            LIMIT 1
        ");
        $sectionStmt->execute([$sectionId]);
        $sectionRow = $sectionStmt->fetch(PDO::FETCH_ASSOC);
        $gradeLevelId = $sectionRow['grade_level_id'] ?? null;
    }

    // Build query to get subjects available for this grade level
    $sql = "
        SELECT s.id, s.subject_code, s.subject_name
        FROM tblsubjects s
        INNER JOIN tblcurriculum_grade cg ON s.id = cg.subject_id
        WHERE s.is_active = 1
          AND cg.is_active = 1
    ";
    $params = [];

    if ($gradeLevelId !== null) {
        $sql .= " AND cg.grade_level_id = ?";
        $params[] = $gradeLevelId;
    }

    if ($sectionId > 0 && $schoolYear !== null) {
        $sql .= " AND s.id NOT IN (
            SELECT subject_id
            FROM tblschedule
            WHERE section_id = ?
              AND school_year = ?
        ";
        $params[] = $sectionId;
        $params[] = $schoolYear;

        if ($excludeScheduleId > 0) {
            $sql .= " AND id != ? ";
            $params[] = $excludeScheduleId;
        }

        $sql .= ")";
    }

    $sql .= " ORDER BY s.subject_name ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    echo json_encode([
        'success' => true,
        'subjects' => $stmt->fetchAll(PDO::FETCH_ASSOC)
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'subjects' => [],
        'error' => $e->getMessage()
    ]);
}