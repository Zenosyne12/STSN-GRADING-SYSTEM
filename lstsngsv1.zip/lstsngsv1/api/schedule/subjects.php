<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $sectionId      = (int)($_GET['section_id'] ?? 0);
    $academicYearId = (int)($_GET['academic_year_id'] ?? 0);

    $rawExclude    = $_GET['exclude_schedule_id'] ?? [];
    $excludeSchIds = is_array($rawExclude)
                     ? array_map('intval', $rawExclude)
                     : [(int)$rawExclude];
    $excludeSchIds = array_filter($excludeSchIds);

    $schoolYear    = null;
    $gradeLevelId  = null;
    $sectionStrand = null;
    $semester      = null;

    if ($sectionId > 0 && $academicYearId > 0) {
        $yearStmt = $pdo->prepare("SELECT year_label FROM tblacademicyear WHERE id = ? LIMIT 1");
        $yearStmt->execute([$academicYearId]);
        $schoolYear = $yearStmt->fetch(PDO::FETCH_ASSOC)['year_label'] ?? null;

        $sectionStmt = $pdo->prepare("SELECT grade_level_id, strand FROM tblsection WHERE id = ? LIMIT 1");
        $sectionStmt->execute([$sectionId]);
        $sectionRow    = $sectionStmt->fetch(PDO::FETCH_ASSOC);
        $gradeLevelId  = $sectionRow['grade_level_id'] ?? null;
        $sectionStrand = !empty($sectionRow['strand']) ? $sectionRow['strand'] : null;

        $qtrStmt = $pdo->prepare("
            SELECT quarter_number 
            FROM tblquarters 
            WHERE academic_year_id = ? AND is_active = 1 
            LIMIT 1
        ");
        $qtrStmt->execute([$academicYearId]);
        $activeQuarter = $qtrStmt->fetch(PDO::FETCH_ASSOC)['quarter_number'] ?? null;

        if ($activeQuarter !== null) {
            $semester = ($activeQuarter <= 2) ? '1st' : '2nd';
        }
    }

    $sql    = "SELECT s.id, s.subject_code, s.subject_name, s.semester
               FROM tblsubjects s
               WHERE s.is_active = 1";
    $params = [];

    if ($gradeLevelId !== null) {
        $sql     .= " AND s.grade_level_id = ?";
        $params[] = $gradeLevelId;
    }

    if ($sectionStrand !== null) {
        $sql     .= " AND (s.strand IS NULL OR s.strand = ?)";
        $params[] = $sectionStrand;
    }

    if ($semester !== null) {
        $sql     .= " AND (s.semester IS NULL OR s.semester = ?)";
        $params[] = $semester;
    }

    if ($sectionId > 0 && $schoolYear !== null) {
        $sql     .= " AND s.id NOT IN (
                        SELECT subject_id FROM tblschedule
                        WHERE section_id = ? AND school_year = ?";
        $params[] = $sectionId;
        $params[] = $schoolYear;

        if (!empty($excludeSchIds)) {
            $placeholders = implode(',', array_fill(0, count($excludeSchIds), '?'));
            $sql         .= " AND id NOT IN ($placeholders)";
            $params       = array_merge($params, $excludeSchIds);
        }

        $sql .= ")";
    }

    $sql .= " ORDER BY s.subject_name ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    echo json_encode(['success' => true, 'subjects' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'subjects' => [], 'error' => $e->getMessage()]);
}