<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $sectionId = (int)($_GET['section_id'] ?? 0);
    $academicYearId = (int)($_GET['academic_year_id'] ?? 0);
    $excludeScheduleId = (int)($_GET['exclude_schedule_id'] ?? 0);
    $dayOfWeek = trim($_GET['day_of_week'] ?? '');
    $timeStart = trim($_GET['time_start'] ?? '');
    $timeEnd = trim($_GET['time_end'] ?? '');

    $schoolYear = null;
    if ($academicYearId > 0) {
        $yearStmt = $pdo->prepare("SELECT year_label FROM tblacademicyear WHERE id = ? LIMIT 1");
        $yearStmt->execute([$academicYearId]);
        $yearRow = $yearStmt->fetch(PDO::FETCH_ASSOC);
        $schoolYear = $yearRow['year_label'] ?? null;
    }

    $sql = "
        SELECT
            t.id,
            CONCAT(
                t.lname, ', ', t.fname,
                CASE
                    WHEN t.mname IS NULL OR t.mname = '' THEN ''
                    ELSE CONCAT(' ', LEFT(t.mname, 1), '.')
                END
            ) AS full_name
        FROM tblteacher t
        WHERE t.is_active = 1
    ";
    $params = [];

    if ($schoolYear !== null && $dayOfWeek !== '' && $timeStart !== '' && $timeEnd !== '') {
        $sql .= "
            AND t.id NOT IN (
                SELECT sc.teacher_id
                FROM tblschedule sc
                WHERE sc.school_year = ?
                  AND sc.day_name = ?
                  AND (? < sc.time_end)
                  AND (? > sc.time_start)
        ";
        $params[] = $schoolYear;
        $params[] = $dayOfWeek;
        $params[] = $timeStart;
        $params[] = $timeEnd;

        if ($excludeScheduleId > 0) {
            $sql .= " AND sc.id != ? ";
            $params[] = $excludeScheduleId;
        }

        $sql .= ")";
    }

    $sql .= " ORDER BY t.lname ASC, t.fname ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    echo json_encode([
        'success' => true,
        'teachers' => $stmt->fetchAll(PDO::FETCH_ASSOC)
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'teachers' => [],
        'error' => $e->getMessage()
    ]);
}