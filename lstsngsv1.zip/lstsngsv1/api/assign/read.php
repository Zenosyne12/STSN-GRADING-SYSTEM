<?php
require_once __DIR__.'/../shared/db_connect.php';
header('Content-Type: application/json');

/* dropdown flag */
if(isset($_GET['drop'])){
    $ay   = $pdo->query("SELECT id, year_label AS name FROM tblacademicyear WHERE is_active=1 ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
    $teach= $pdo->query("SELECT id, CONCAT(lname,', ',fname) AS name FROM tblteacher WHERE is_active=1 ORDER BY lname,fname")->fetchAll(PDO::FETCH_ASSOC);
    $subj = $pdo->query("SELECT id, subject_name AS name FROM tblsubjects WHERE is_active=1 ORDER BY subject_name")->fetchAll(PDO::FETCH_ASSOC);
    $sect = $pdo->query("SELECT id, section_name AS name FROM tblsection WHERE is_active=1 ORDER BY section_name")->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['ay_id'=>$ay,'teacher_id'=>$teach,'subject_id'=>$subj,'section_id'=>$sect]);
    exit;
}

/* normal list with search */
$search = isset($_GET['s']) ? trim($_GET['s']) : '';
$page   = max(1, intval($_GET['p'] ?? 1));
$limit  = 10;
$offset = ($page - 1) * $limit;

$where = " WHERE (
          CONCAT(t.lname,', ',t.fname) LIKE :s
          OR s.subject_name LIKE :s
          OR sc.section_name LIKE :s
          OR ay.year_label LIKE :s )";
$params= ['s'=>"%$search%"];

$cnt = $pdo->prepare("SELECT COUNT(*) 
                      FROM tblteacher_assignment ta
                      JOIN tblteacher   t  ON t.id  = ta.teacher_id
                      JOIN tblsubjects  s  ON s.id  = ta.subject_id
                      JOIN tblsection   sc ON sc.id = ta.section_id
                      JOIN tblacademicyear ay ON ay.id = ta.ay_id
                      $where");
$cnt->execute($params);
$total = (int)$cnt->fetchColumn();
$pages = max(1, ceil($total/$limit));

$stmt = $pdo->prepare("SELECT ta.id,
                              CONCAT(t.lname,', ',t.fname) AS teacher,
                              s.subject_name                AS subject,
                              sc.section_name               AS section,
                              ay.year_label                 AS ay,
                              ta.isAdvisory                 AS advisory,
                              ta.is_active
                       FROM tblteacher_assignment ta
                       JOIN tblteacher   t  ON t.id  = ta.teacher_id
                       JOIN tblsubjects  s  ON s.id  = ta.subject_id
                       JOIN tblsection   sc ON sc.id = ta.section_id
                       JOIN tblacademicyear ay ON ay.id = ta.ay_id
                       $where
                       ORDER BY ta.id DESC
                       LIMIT {$offset},{$limit}");
$stmt->execute($params);
echo json_encode([
    'assignments'=>$stmt->fetchAll(PDO::FETCH_ASSOC),
    'page'=>$page,
    'pages'=>$pages,
    'total'=>$total
]);