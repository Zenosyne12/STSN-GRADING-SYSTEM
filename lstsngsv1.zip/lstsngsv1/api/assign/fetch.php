<?php
require_once __DIR__.'/../shared/db_connect.php';
header('Content-Type: application/json');
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if(!$id){ http_response_code(400); echo json_encode(['error'=>'Bad ID']); exit; }
$stmt = $pdo->prepare("SELECT ta.* FROM tblteacher_assignment ta WHERE ta.id=:id AND ta.is_active=1");
$stmt->execute(['id'=>$id]);
$out = $stmt->fetch(PDO::FETCH_ASSOC);
if(!$out){ http_response_code(404); echo json_encode(['error'=>'Not found']); exit; }
echo json_encode($out);