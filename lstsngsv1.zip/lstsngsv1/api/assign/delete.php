<?php
require_once __DIR__.'/../shared/db_connect.php';
header('Content-Type: application/json');
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if(!$id){ http_response_code(400); echo json_encode(['error'=>'Bad ID']); exit; }
$stmt = $pdo->prepare("UPDATE tblteacher_assignment SET is_active=0 WHERE id=?");
$stmt->execute([$id]);
echo json_encode(['success'=>true]);