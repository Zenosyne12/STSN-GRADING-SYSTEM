<?php
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/settings_schema.php';

stsnEnsureSettingsSchema($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    stsnJsonOut(['success' => false, 'error' => 'Method not allowed'], 405);
}

$input = stsnJsonInput();
$show = $input['show_section_prompt'] ?? 0;
$show = filter_var($show, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
if ($show === null) {
    $show = (int) $show === 1;
}

$userId = (int) ($_SESSION['user_id'] ?? 0);
$pdo->prepare("UPDATE tblusers SET show_section_prompt = ? WHERE id = ?")->execute([$show ? 1 : 0, $userId]);

stsnJsonOut(['success' => true, 'show_section_prompt' => $show ? 1 : 0]);
