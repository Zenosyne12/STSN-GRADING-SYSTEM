<?php
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/settings_schema.php';

stsnEnsureSettingsSchema($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    stsnJsonOut(['success' => false, 'error' => 'Method not allowed'], 405);
}

$input = stsnJsonInput();
$theme = strtolower(trim((string) ($input['theme'] ?? '')));
if (!in_array($theme, ['dark', 'light'], true)) {
    stsnJsonOut(['success' => false, 'error' => 'Theme must be dark or light'], 422);
}

$userId = (int) ($_SESSION['user_id'] ?? 0);
$stmt = $pdo->prepare("UPDATE tblusers SET theme_preference = ?, updated_at = NOW() WHERE id = ?");
$stmt->execute([$theme, $userId]);

$_SESSION['theme_preference'] = $theme;
$secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
setcookie('stsn_theme', $theme, [
    'expires' => time() + 60 * 60 * 24 * 365,
    'path' => '/',
    'httponly' => false,
    'samesite' => 'Lax',
    'secure' => $secure,
]);

stsnJsonOut([
    'success' => true,
    'theme' => $theme,
    'message' => 'Theme updated',
]);
