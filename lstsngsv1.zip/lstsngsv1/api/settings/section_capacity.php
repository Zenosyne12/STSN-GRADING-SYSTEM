<?php
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/settings_schema.php';

stsnEnsureSettingsSchema($pdo);

$method = $_SERVER['REQUEST_METHOD'];
$academicYearId = stsnActiveAcademicYearId($pdo);

if ($method === 'GET') {
    $stmt = $pdo->prepare("
        SELECT
            s.id,
            s.section_name,
            s.grade_level_id,
            gl.grade_level_name,
            COALESCE(s.max_capacity, 40) AS max_capacity,
            (
                SELECT COUNT(*)
                FROM tblsectionstudent ss
                WHERE ss.section_id = s.id
                  AND ss.is_active = 1
                  AND (? = 0 OR ss.academic_year_id = ?)
            ) AS current_count
        FROM tblsection s
        LEFT JOIN tblgradelevel gl ON gl.id = s.grade_level_id
        WHERE s.is_active = 1
        ORDER BY gl.id ASC, s.section_name ASC
    ");
    $stmt->execute([$academicYearId, $academicYearId]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $sections = [];
    foreach ($rows as $row) {
        $max = (int) $row['max_capacity'];
        $current = (int) $row['current_count'];
        $sections[] = [
            'id' => (int) $row['id'],
            'section_name' => $row['section_name'],
            'grade_level_id' => (int) $row['grade_level_id'],
            'grade_level_name' => $row['grade_level_name'] ?: '—',
            'max_capacity' => $max,
            'current_count' => $current,
            'remaining' => max(0, $max - $current),
            'status' => stsnCapacityStatus($current, $max),
        ];
    }

    stsnJsonOut(['success' => true, 'sections' => $sections, 'academic_year_id' => $academicYearId]);
}

if (!in_array($method, ['PUT', 'POST'], true)) {
    stsnJsonOut(['success' => false, 'error' => 'Method not allowed'], 405);
}

$input = stsnJsonInput();
$sectionId = (int) ($input['section_id'] ?? 0);
$maxCapacity = (int) ($input['max_capacity'] ?? 0);

if ($sectionId <= 0) {
    stsnJsonOut(['success' => false, 'error' => 'section_id is required'], 422);
}
if ($maxCapacity < 10 || $maxCapacity > 100) {
    stsnJsonOut(['success' => false, 'error' => 'Max capacity must be between 10 and 100'], 422);
}

$exists = $pdo->prepare("SELECT id, section_name FROM tblsection WHERE id = ? LIMIT 1");
$exists->execute([$sectionId]);
$section = $exists->fetch(PDO::FETCH_ASSOC);
if (!$section) {
    stsnJsonOut(['success' => false, 'error' => 'Section not found'], 404);
}

$pdo->prepare("UPDATE tblsection SET max_capacity = ?, updated_at = NOW() WHERE id = ?")->execute([$maxCapacity, $sectionId]);
$current = stsnSectionEnrollmentCount($pdo, $sectionId, $academicYearId);

stsnJsonOut([
    'success' => true,
    'message' => 'Capacity updated',
    'section_name' => $section['section_name'],
    'max_capacity' => $maxCapacity,
    'current_count' => $current,
    'remaining' => max(0, $maxCapacity - $current),
    'status' => stsnCapacityStatus($current, $maxCapacity),
]);
