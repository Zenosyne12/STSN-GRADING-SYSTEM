<?php
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/settings_schema.php';

stsnEnsureSettingsSchema($pdo);

$userId = (int) ($_SESSION['user_id'] ?? 0);

function stsnSectionConfigPayload(PDO $pdo, int $userId): array
{
    $prompt = 1;
    if ($userId > 0) {
        $stmt = $pdo->prepare("SELECT show_section_prompt FROM tblusers WHERE id = ? LIMIT 1");
        $stmt->execute([$userId]);
        $prompt = (int) $stmt->fetchColumn();
    }

    return [
        'auto_assign_enabled' => stsnIsAutoAssignEnabled($pdo),
        'max_capacity' => stsnDefaultMaxCapacity($pdo),
        'show_section_prompt' => $prompt === 1,
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    stsnJsonOut(stsnSectionConfigPayload($pdo, $userId));
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    stsnJsonOut(['success' => false, 'error' => 'Method not allowed'], 405);
}

$input = stsnJsonInput();

if (array_key_exists('auto_assign_enabled', $input)) {
    $enabled = filter_var($input['auto_assign_enabled'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
    if ($enabled === null) {
        $enabled = (int) $input['auto_assign_enabled'] === 1;
    }
    stsnSetSetting($pdo, 'auto_assign_enabled', $enabled ? '1' : '0');
}

if (array_key_exists('max_capacity', $input)) {
    $capacity = (int) $input['max_capacity'];
    if ($capacity < 10 || $capacity > 100) {
        stsnJsonOut(['success' => false, 'error' => 'Max capacity must be between 10 and 100'], 422);
    }
    stsnSetSetting($pdo, 'default_max_capacity', (string) $capacity);
    $pdo->prepare("UPDATE tblsection SET max_capacity = ?")->execute([$capacity]);
}

if (array_key_exists('show_section_prompt', $input) && $userId > 0) {
    $show = filter_var($input['show_section_prompt'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
    if ($show === null) {
        $show = (int) $input['show_section_prompt'] === 1;
    }
    $pdo->prepare("UPDATE tblusers SET show_section_prompt = ? WHERE id = ?")->execute([$show ? 1 : 0, $userId]);
}

stsnJsonOut([
    'success' => true,
    'message' => 'Settings updated',
] + stsnSectionConfigPayload($pdo, $userId));
