<?php
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/settings_schema.php';

stsnEnsureSettingsSchema($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    stsnJsonOut(['success' => false, 'error' => 'Method not allowed'], 405);
}

$input = stsnJsonInput();
$currentPassword = (string) ($input['current_password'] ?? '');
$newPassword = (string) ($input['new_password'] ?? '');
$confirmPassword = (string) ($input['confirm_password'] ?? '');

$userId = (int) ($_SESSION['user_id'] ?? 0);
if ($userId <= 0) {
    stsnJsonOut(['success' => false, 'error' => 'Not authenticated'], 401);
}

if ($currentPassword === '' || $newPassword === '' || $confirmPassword === '') {
    stsnJsonOut(['success' => false, 'error' => 'All password fields are required'], 422);
}

if ($newPassword !== $confirmPassword) {
    stsnJsonOut(['success' => false, 'error' => "Passwords don't match"], 422);
}

if (strlen($newPassword) < 8) {
    stsnJsonOut(['success' => false, 'error' => 'New password must be at least 8 characters'], 422);
}

if (!preg_match('/[A-Z]/', $newPassword) || !preg_match('/[a-z]/', $newPassword) || !preg_match('/[0-9]/', $newPassword)) {
    stsnJsonOut(['success' => false, 'error' => 'New password must contain uppercase, lowercase, and numbers'], 422);
}

if (hash_equals($currentPassword, $newPassword)) {
    stsnJsonOut(['success' => false, 'error' => 'New password cannot be same as current'], 422);
}

$stmt = $pdo->prepare("SELECT password_hash FROM tblusers WHERE id = ? LIMIT 1");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$user) {
    stsnJsonOut(['success' => false, 'error' => 'User not found'], 404);
}

$stored = (string) $user['password_hash'];
$valid = false;
$info = password_get_info($stored);
if (!empty($info['algo'])) {
    $valid = password_verify($currentPassword, $stored);
} else {
    $valid = hash_equals($stored, $currentPassword);
}

if (!$valid) {
    stsnJsonOut(['success' => false, 'error' => 'Current password is incorrect'], 422);
}

if (!empty($info['algo']) && password_verify($newPassword, $stored)) {
    stsnJsonOut(['success' => false, 'error' => 'New password cannot be same as current'], 422);
}

$hash = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => 12]);
$update = $pdo->prepare("
    UPDATE tblusers
    SET password_hash = ?, password_changed_at = NOW(), must_change_password = 0, updated_at = NOW()
    WHERE id = ?
");
$update->execute([$hash, $userId]);

$_SESSION['must_change_password'] = 0;

$changedAt = date('Y-m-d H:i:s');
stsnJsonOut([
    'success' => true,
    'message' => 'Password changed successfully',
    'changed_at' => $changedAt,
]);
