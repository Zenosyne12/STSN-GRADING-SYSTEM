<?php
header('Content-Type: application/json');

require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

$adminId = (int)($_SESSION['user_id'] ?? 0);
if ($adminId <= 0) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Admin session is invalid.']);
    exit;
}

try {
    $stmt = $pdo->prepare("
        SELECT id, title, message, created_at
        FROM system_notifications
        WHERE type = ?
        ORDER BY created_at DESC, id DESC
        LIMIT 8
    ");
    $stmt->execute(['admin:' . $adminId]);
    $notifications = array_map(static function (array $row): array {
        return [
            'id' => (int)$row['id'],
            'title' => (string)$row['title'],
            'message' => (string)$row['message'],
            'created_at' => (string)$row['created_at'],
            'created_at_display' => !empty($row['created_at'])
                ? date('M d, Y h:i A', strtotime($row['created_at']))
                : '-',
        ];
    }, $stmt->fetchAll(PDO::FETCH_ASSOC));

    echo json_encode(['success' => true, 'notifications' => $notifications]);
} catch (Throwable $e) {
    error_log('[admin notification feed] ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Unable to load notifications.']);
}
