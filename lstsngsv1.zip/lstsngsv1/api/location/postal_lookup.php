<?php
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

function respond(array $payload): void
{
    echo json_encode($payload);
    exit;
}

function normalizePostalCode(string $postalCode): string
{
    return preg_replace('/\D+/', '', $postalCode) ?? '';
}

function locationSql(string $whereClause): string
{
    return "
        SELECT
            co.id AS country_id,
            co.country_name,
            r.id AS region_id,
            r.region_name,
            p.id AS province_id,
            p.province_name,
            ci.id AS city_id,
            ci.city_name,
            b.id AS barangay_id,
            b.barangay_name,
            b.postal_code
        FROM tblbarangay b
        JOIN tblcity ci ON ci.id = b.city_id
        JOIN tblprovince p ON p.id = ci.province_id
        JOIN tblregion r ON r.id = p.region_id
        JOIN tblcountry co ON co.id = r.country_id
        WHERE {$whereClause}
        ORDER BY co.country_name, r.region_name, p.province_name, ci.city_name, b.barangay_name
    ";
}

try {
    $postalCode = normalizePostalCode((string) ($_GET['postal_code'] ?? ''));
    $barangayId = isset($_GET['barangay_id']) ? (int) $_GET['barangay_id'] : 0;

    if ($postalCode !== '') {
        if (!preg_match('/^\d{4}$/', $postalCode)) {
            respond([
                'success' => false,
                'error' => 'Postal code must be exactly 4 digits.',
                'matches' => [],
            ]);
        }

        $stmt = $pdo->prepare(locationSql('b.postal_code = ?'));
        $stmt->execute([$postalCode]);
        $matches = $stmt->fetchAll(PDO::FETCH_ASSOC);

        respond([
            'success' => count($matches) > 0,
            'error' => count($matches) > 0 ? null : 'Postal code was not found.',
            'matches' => $matches,
        ]);
    }

    if ($barangayId > 0) {
        $stmt = $pdo->prepare(locationSql('b.id = ?'));
        $stmt->execute([$barangayId]);
        $matches = $stmt->fetchAll(PDO::FETCH_ASSOC);

        respond([
            'success' => count($matches) === 1,
            'error' => count($matches) === 1 ? null : 'Barangay was not found.',
            'matches' => $matches,
        ]);
    }

    respond([
        'success' => false,
        'error' => 'Postal code or barangay is required.',
        'matches' => [],
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    respond([
        'success' => false,
        'error' => 'Lookup failed.',
        'matches' => [],
    ]);
}
