<?php
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../../includes/psgc_location.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

$level = strtoupper(trim((string) ($_GET['level'] ?? '')));
$parentId = filter_var($_GET['parent_id'] ?? null, FILTER_VALIDATE_INT);

if (!in_array($level, ['REGION', 'PROVINCE', 'CITY', 'BARANGAY'], true) || !$parentId || $parentId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'A valid location level and parent ID are required.']);
    exit;
}

try {
    $result = getPsgcLocationOptions($pdo, $level, $parentId);
    echo json_encode([
        'success' => true,
        'source' => $result['source'],
        'items' => $result['items'],
    ], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    error_log('[location/hierarchy] ' . $e->getMessage());
    http_response_code(503);
    echo json_encode([
        'success' => false,
        'error' => 'Address options could not be loaded from PSGC or the local cache.',
    ]);
}
