<?php
/**
 * Schedule generation engine — shared by the Schedule module APIs.
 *
 * Curriculum-aware / grade-level-aware / academic-year-aware auto
 * scheduling for the STSN Grading System.
 *
 * Data sources:
 *   tblcurriculum, tblcurriculum_subjects (see sql/migration_schedule_curriculum.sql)
 *   tblsystemsettings (schedule_* keys = configurable school hours)
 *   tblsection, tblgradelevel, tblsubjects, tblacademicyear, tblquarters
 *   tblteacher, tblsection_teacher_subject, tblschedule
 */

if (!class_exists('ScheduleEngineException')) {
    class ScheduleEngineException extends Exception {}
}

/* ============================================================
 * Time helpers
 * ============================================================ */

if (!function_exists('scheduleTimeToMinutes')) {
    /** '07:30' or '07:30:00' -> 450 ; returns null when unparseable */
    function scheduleTimeToMinutes(?string $value): ?int
    {
        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }
        $parts = explode(':', $value);
        if (count($parts) < 2) {
            return null;
        }
        $h = (int) $parts[0];
        $m = (int) $parts[1];
        if ($h < 0 || $h > 24 || $m < 0 || $m > 59) {
            return null;
        }
        return $h * 60 + $m;
    }
}

if (!function_exists('scheduleMinutesToTime')) {
    /** 450 -> '07:30' */
    function scheduleMinutesToTime(int $minutes): string
    {
        $minutes = max(0, min(24 * 60, $minutes));
        return sprintf('%02d:%02d', intdiv($minutes, 60), $minutes % 60);
    }
}

/* ============================================================
 * Configurable school schedule parameters (tblsystemsettings)
 * ============================================================ */

if (!function_exists('scheduleLoadSchoolConfig')) {
    /**
     * Returns the school's configured operating hours. Never throws:
     * invalid/missing values fall back to documented defaults and are
     * reported through the 'warnings' array.
     */
    function scheduleLoadSchoolConfig(PDO $pdo): array
    {
        $warnings = [];

        $defaults = [
            'schedule_days'        => 'Monday,Tuesday,Wednesday,Thursday,Friday',
            'schedule_start'       => '07:00',
            'schedule_end'         => '17:00',
            'schedule_break_start' => '10:00',
            'schedule_break_end'   => '10:15',
            'schedule_lunch_start' => '12:00',
            'schedule_lunch_end'   => '13:00',
            'schedule_slot_step'   => '15',
            'schedule_rooms'       => 'ROOM 101,ROOM 102,ROOM 103,ROOM 104,ROOM 105',
        ];

        $settings = $defaults;
        try {
            $rows = $pdo->query(
                "SELECT setting_key, setting_value FROM tblsystemsettings WHERE setting_key LIKE 'schedule%'"
            )->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $row) {
                if (array_key_exists($row['setting_key'], $settings) && trim((string) $row['setting_value']) !== '') {
                    $settings[$row['setting_key']] = trim((string) $row['setting_value']);
                }
            }
        } catch (Throwable $e) {
            $warnings[] = 'School schedule settings could not be read (' . $e->getMessage() . '); built-in defaults were used.';
        }

        $validDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        $days = [];
        foreach (explode(',', (string) $settings['schedule_days']) as $day) {
            $day = trim($day);
            if ($day !== '' && in_array(ucfirst(strtolower($day)), $validDays, true)) {
                $days[] = ucfirst(strtolower($day));
            }
        }
        if (!$days) {
            $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
            $warnings[] = 'schedule_days setting is empty/invalid; default Monday-Friday was used.';
        }

        $startTime = scheduleTimeToMinutes($settings['schedule_start']);
        $endTime   = scheduleTimeToMinutes($settings['schedule_end']);
        if ($startTime === null || $endTime === null || $startTime >= $endTime) {
            $startTime = 7 * 60;
            $endTime   = 17 * 60;
            $warnings[] = 'schedule_start/schedule_end settings are invalid; default 07:00-17:00 was used.';
        }

        $breakStart = scheduleTimeToMinutes($settings['schedule_break_start']);
        $breakEnd   = scheduleTimeToMinutes($settings['schedule_break_end']);
        if ($breakStart !== null && $breakEnd !== null && $breakEnd <= $breakStart) {
            $warnings[] = 'schedule_break_end must be later than schedule_break_start; break window ignored.';
            $breakStart = $breakEnd = null;
        }

        $lunchStart = scheduleTimeToMinutes($settings['schedule_lunch_start']);
        $lunchEnd   = scheduleTimeToMinutes($settings['schedule_lunch_end']);
        if ($lunchStart !== null && $lunchEnd !== null && $lunchEnd <= $lunchStart) {
            $warnings[] = 'schedule_lunch_end must be later than schedule_lunch_start; lunch window ignored.';
            $lunchStart = $lunchEnd = null;
        }

        $step = (int) $settings['schedule_slot_step'];
        if ($step < 5 || $step > 240) {
            $step = 15;
            $warnings[] = 'schedule_slot_step setting is invalid; default 15 minutes was used.';
        }

        $rooms = [];
        foreach (explode(',', (string) $settings['schedule_rooms']) as $room) {
            $room = trim($room);
            if ($room !== '') {
                $rooms[] = $room;
            }
        }

        return [
            'days'        => $days,
            'start_time'  => scheduleMinutesToTime($startTime),
            'end_time'    => scheduleMinutesToTime($endTime),
            'break_start' => $breakStart !== null ? scheduleMinutesToTime($breakStart) : null,
            'break_end'   => $breakEnd !== null ? scheduleMinutesToTime($breakEnd) : null,
            'lunch_start' => $lunchStart !== null ? scheduleMinutesToTime($lunchStart) : null,
            'lunch_end'   => $lunchEnd !== null ? scheduleMinutesToTime($lunchEnd) : null,
            'slot_step'   => $step,
            'rooms'       => $rooms,
            'warnings'    => $warnings,
        ];
    }
}

if (!function_exists('scheduleIntervalsOverlap')) {
    function scheduleIntervalsOverlap(int $aStart, int $aEnd, int $bStart, int $bEnd): bool
    {
        return $aStart < $bEnd && $aEnd > $bStart;
    }
}

if (!function_exists('scheduleDaySegments')) {
    /**
     * Build the free time segments for each configured school day.
     * Break and lunch windows are blocked out.
     *
     * @return array<string, array<int, array{0:int,1:int}>> day => [[startMin,endMin],...]
     */
    function scheduleDaySegments(array $cfg): array
    {
        $start = scheduleTimeToMinutes($cfg['start_time']);
        $end   = scheduleTimeToMinutes($cfg['end_time']);
        if ($start === null || $end === null || $start >= $end) {
            $start = 7 * 60;
            $end   = 17 * 60;
        }

        $blocked = [];
        $bStart = scheduleTimeToMinutes($cfg['break_start'] ?? '');
        $bEnd   = scheduleTimeToMinutes($cfg['break_end'] ?? '');
        if ($bStart !== null && $bEnd !== null && $bEnd > $bStart) {
            $blocked[] = [$bStart, $bEnd];
        }
        $lStart = scheduleTimeToMinutes($cfg['lunch_start'] ?? '');
        $lEnd   = scheduleTimeToMinutes($cfg['lunch_end'] ?? '');
        if ($lStart !== null && $lEnd !== null && $lEnd > $lStart) {
            $blocked[] = [$lStart, $lEnd];
        }

        $windows = [[$start, $end]];
        foreach ($blocked as $block) {
            $next = [];
            foreach ($windows as $win) {
                if ($block[1] <= $win[0] || $block[0] >= $win[1]) {
                    $next[] = $win; // block outside this window
                    continue;
                }
                if ($block[0] > $win[0]) {
                    $next[] = [$win[0], $block[0]];
                }
                if ($block[1] < $win[1]) {
                    $next[] = [$block[1], $win[1]];
                }
            }
            $windows = $next;
        }

        $segments = [];
        foreach ($cfg['days'] as $day) {
            $segments[$day] = [];
            foreach ($windows as $win) {
                if ($win[1] - $win[0] > 0) {
                    $segments[$day][] = [(int) $win[0], (int) $win[1]];
                }
            }
        }
        return $segments;
    }
}

/* ============================================================
 * Curriculum resolution (grade level + academic year aware)
 * ============================================================ */

if (!function_exists('scheduleSchoolYearStart')) {
    /** Start calendar year of a school year label like '2026-2027' */
    function scheduleSchoolYearStart(string $schoolYear): int
    {
        return (int) substr(trim($schoolYear), 0, 4);
    }
}

if (!function_exists('scheduleResolveCurriculum')) {
    /**
     * Determine the curriculum configuration applicable to a grade level
     * for the selected academic year.
     *
     * Rules: among ACTIVE curricula whose effective_school_year is not
     * later than the selected academic year, pick the most recent one
     * that actually has configuration rows for this grade level. This
     * models DepEd's phased curriculum adoption: a newer curriculum only
     * "wins" for grades it has been configured for.
     *
     * @return array{curriculum: ?array, applicable: array, configured_for_grade: bool}
     */
    function scheduleResolveCurriculum(PDO $pdo, int $gradeLevelId, string $schoolYear): array
    {
        $startYear = scheduleSchoolYearStart($schoolYear);

        try {
            $rows = $pdo->query(
                "SELECT curriculum_id, curriculum_name, curriculum_version, effective_school_year,
                        status, description
                 FROM tblcurriculum
                 WHERE status = 'ACTIVE'
                 ORDER BY effective_school_year DESC, curriculum_id DESC"
            )->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {
            throw new ScheduleEngineException(
                'Curriculum configuration tables are missing or unreadable. Run sql/migration_schedule_curriculum.sql first. (' . $e->getMessage() . ')'
            );
        }

        $applicable = [];
        foreach ($rows as $row) {
            if (scheduleSchoolYearStart((string) $row['effective_school_year']) <= $startYear) {
                $applicable[] = $row;
            }
        }

        foreach ($applicable as $candidate) {
            $check = $pdo->prepare(
                "SELECT COUNT(*) FROM tblcurriculum_subjects WHERE curriculum_id = ? AND grade_level_id = ?"
            );
            $check->execute([(int) $candidate['curriculum_id'], $gradeLevelId]);
            if ((int) $check->fetchColumn() > 0) {
                return [
                    'curriculum'          => $candidate,
                    'applicable'          => $applicable,
                    'configured_for_grade' => true,
                ];
            }
        }

        return [
            'curriculum'           => $applicable[0] ?? ($rows[0] ?? null),
            'applicable'           => $applicable,
            'configured_for_grade' => false,
        ];
    }
}

if (!function_exists('scheduleLoadCurriculumRequirements')) {
    /**
     * Load the per-subject scheduling requirements configured for a
     * curriculum + grade level.
     *
     * @return array{required: array<int, array>, configured: array<int, array>}
     */
    function scheduleLoadCurriculumRequirements(PDO $pdo, int $curriculumId, int $gradeLevelId): array
    {
        $stmt = $pdo->prepare(
            "SELECT cs.curriculum_subject_id, cs.subject_id, cs.applicable_period,
                    cs.meetings_per_week, cs.minutes_per_meeting, cs.total_required_minutes,
                    cs.is_required, cs.room_preference, cs.source_reference, cs.is_official,
                    s.subject_code, s.subject_name, s.subject_type, s.semester, s.strand,
                    COALESCE(s.is_active, 1) AS subject_is_active
             FROM tblcurriculum_subjects cs
             INNER JOIN tblsubjects s ON s.id = cs.subject_id
             WHERE cs.curriculum_id = ? AND cs.grade_level_id = ?"
        );
        $stmt->execute([$curriculumId, $gradeLevelId]);

        $required = [];
        $configured = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $row['subject_id'] = (int) $row['subject_id'];
            $row['meetings_per_week'] = $row['meetings_per_week'] !== null ? (int) $row['meetings_per_week'] : null;
            $row['minutes_per_meeting'] = $row['minutes_per_meeting'] !== null ? (int) $row['minutes_per_meeting'] : null;
            $row['total_required_minutes'] = $row['total_required_minutes'] !== null ? (int) $row['total_required_minutes'] : null;
            $row['is_required'] = (int) $row['is_required'];
            $configured[$row['subject_id']] = $row;
            if ($row['is_required'] === 1) {
                $required[$row['subject_id']] = $row;
            }
        }

        return ['required' => $required, 'configured' => $configured];
    }
}

if (!function_exists('schedulePeriodMatchesSemester')) {
    /**
     * Does the configured applicable_period apply to the active semester?
     * 'ALL' always applies; '1st Semester'/'1st Quarter' style values are
     * matched against the derived semester ('1st'/'2nd'); unknown quarter
     * labels are treated as applying to the whole school year.
     */
    function schedulePeriodMatchesSemester(?string $applicablePeriod, ?string $semester): bool
    {
        $period = strtoupper(trim((string) $applicablePeriod));
        if ($period === '' || $period === 'ALL' || $period === 'FULL YEAR' || $period === 'WHOLE YEAR') {
            return true;
        }
        if ($semester === null) {
            return true;
        }
        if (strpos($period, '1ST') === 0) {
            return $semester === '1st';
        }
        if (strpos($period, '2ND') === 0) {
            return $semester === '2nd';
        }
        return true; // quarter labels etc. schedule weekly across the year
    }
}

/* ============================================================
 * Placement engine (conflict state, slot search, insertion)
 * ============================================================ */

if (!function_exists('scheduleAddBusy')) {
    /** Record an occupied interval for section/teacher/room caches. */
    function scheduleAddBusy(array &$busy, ?string $key, string $day, int $start, int $end): void
    {
        if ($key === null || $key === '') {
            return;
        }
        if (!isset($busy[$key])) {
            $busy[$key] = [];
        }
        if (!isset($busy[$key][$day])) {
            $busy[$key][$day] = [];
        }
        $busy[$key][$day][] = [$start, $end];
    }
}

if (!function_exists('scheduleIsBusy')) {
    function scheduleIsBusy(array $busy, ?string $key, string $day, int $start, int $end): bool
    {
        if ($key === null || $key === '' || !isset($busy[$key][$day])) {
            return false;
        }
        foreach ($busy[$key][$day] as $interval) {
            if (scheduleIntervalsOverlap($start, $end, $interval[0], $interval[1])) {
                return true;
            }
        }
        return false;
    }
}

if (!function_exists('scheduleFindSlot')) {
    /**
     * Find the next free (day, start, room) for a meeting.
     *
     * Order heuristics:
     *   - Prefer days where this subject has the fewest meetings, then the
     *     days where the section has the fewest meetings (spreads subjects
     *     across the week instead of stacking them into one day).
     *   - Within a day prefer earlier times.
     *   - Teachers are tried in order of lowest current load (balance).
     *   - Rooms: subject room_preference first, then lowest room load.
     *
     * @return array{day:string,start:int,end:int,room:string,teacher_id:int}|null
     */
    function scheduleFindSlot(
        array $subject,
        int $minutes,
        array $teacherIds,
        array $segments,
        array $cfg,
        array $dayIndex,
        array &$sectionBusy,
        array &$teacherBusy,
        array &$roomBusy,
        array &$daySectionCount,
        array &$daySubjectCount,
        array $teacherLoad,
        array $roomLoad
    ): ?array {
        $subjectId = (int) $subject['subject_id'];
        $days = $cfg['days'];

        $rankedDays = $days;
        usort($rankedDays, function ($a, $b) use ($daySubjectCount, $daySectionCount, $dayIndex, $subjectId) {
            $sa = $daySubjectCount[$subjectId][$a] ?? 0;
            $sb = $daySubjectCount[$subjectId][$b] ?? 0;
            if ($sa !== $sb) {
                return $sa <=> $sb;
            }
            $ca = $daySectionCount[$a] ?? 0;
            $cb = $daySectionCount[$b] ?? 0;
            if ($ca !== $cb) {
                return $ca <=> $cb;
            }
            return ($dayIndex[$a] ?? 99) <=> ($dayIndex[$b] ?? 99);
        });

        $rankedTeachers = $teacherIds;
        usort($rankedTeachers, function ($a, $b) use ($teacherLoad) {
            $la = $teacherLoad[$a] ?? 0;
            $lb = $teacherLoad[$b] ?? 0;
            if ($la !== $lb) {
                return $la <=> $lb;
            }
            return $a <=> $b;
        });

        $step = $cfg['slot_step'];

        // Rooms ordered by current load (least used first); a subject's
        // configured room_preference (e.g. a laboratory) is tried first.
        $rooms = $cfg['rooms'];
        usort($rooms, function ($a, $b) use ($roomLoad) {
            $la = $roomLoad[$a] ?? 0;
            $lb = $roomLoad[$b] ?? 0;
            if ($la !== $lb) {
                return $la <=> $lb;
            }
            return strcmp($a, $b);
        });
        $preference = trim((string) ($subject['room_preference'] ?? ''));
        if ($preference !== '' && in_array($preference, $rooms, true)) {
            $rooms = array_merge([$preference], array_diff($rooms, [$preference]));
        }

        foreach ($rankedDays as $day) {
            foreach ($segments[$day] as $segment) {
                for ($start = $segment[0]; $start + $minutes <= $segment[1]; $start += $step) {
                    $end = $start + $minutes;

                    if (scheduleIsBusy($sectionBusy, (string) $subject['section_id'], $day, $start, $end)) {
                        continue; // section already has a class here
                    }

                    // Room: first free room (least loaded, preference first)
                    $freeRoom = null;
                    foreach ($rooms as $room) {
                        if (!scheduleIsBusy($roomBusy, $room, $day, $start, $end)) {
                            $freeRoom = $room;
                            break;
                        }
                    }
                    if ($freeRoom === null) {
                        continue; // every room is occupied at this time
                    }

                    foreach ($rankedTeachers as $teacherId) {
                        if (scheduleIsBusy($teacherBusy, (string) $teacherId, $day, $start, $end)) {
                            continue;
                        }
                        return [
                            'day'        => $day,
                            'start'      => $start,
                            'end'        => $end,
                            'room'       => $freeRoom,
                            'teacher_id' => (int) $teacherId,
                        ];
                    }
                }
            }
        }

        return null;
    }
}

/* ============================================================
 * Main entry point: generate a section timetable
 * ============================================================ */

if (!function_exists('scheduleGenerateContext')) {
    /**
     * Load and validate everything needed to generate a timetable for a
     * section. Throws ScheduleEngineException on invalid input.
     *
     * @return array{
     *   section: array, schoolYear: string, startYear: int,
     *   semester: ?string, semesterLabel: string, cfg: array, segments: array,
     *   curriculum: ?array, curriculumConfigured: bool,
     *   gradeSubjects: array<int, array>, requirements: array,
     *   teacherNames: array<int, string>
     * }
     */
    function scheduleGenerateContext(PDO $pdo, int $sectionId, int $academicYearId): array
    {
        if ($sectionId <= 0 || $academicYearId <= 0) {
            throw new ScheduleEngineException('Section and academic year are required');
        }

        $yearStmt = $pdo->prepare(
            "SELECT id, year_label, term_structure FROM tblacademicyear WHERE id = ? LIMIT 1"
        );
        $yearStmt->execute([$academicYearId]);
        $yearRow = $yearStmt->fetch(PDO::FETCH_ASSOC);
        if (!$yearRow) {
            throw new ScheduleEngineException('Invalid academic year');
        }
        $schoolYear = (string) $yearRow['year_label'];

        $sectionStmt = $pdo->prepare(
            "SELECT s.id, s.grade_level_id, s.strand, s.section_name,
                    g.grade_level_name, g.grade_level_code
             FROM tblsection s
             LEFT JOIN tblgradelevel g ON s.grade_level_id = g.id
             WHERE s.id = ? AND COALESCE(s.is_active, 1) = 1
             LIMIT 1"
        );
        $sectionStmt->execute([$sectionId]);
        $section = $sectionStmt->fetch(PDO::FETCH_ASSOC);
        if (!$section) {
            throw new ScheduleEngineException('Section not found or inactive');
        }
        $gradeLevelId = (int) $section['grade_level_id'];
        $section['grade_level_id'] = $gradeLevelId;

        // Active quarter -> applicable SHS semester (same rule as subjects.php)
        $quarterStmt = $pdo->prepare(
            "SELECT quarter_number FROM tblquarters WHERE academic_year_id = ? AND is_active = 1 LIMIT 1"
        );
        $quarterStmt->execute([$academicYearId]);
        $quarterNumber = $quarterStmt->fetch(PDO::FETCH_ASSOC)['quarter_number'] ?? null;
        $semester = null;
        $semesterLabel = '1st Semester';
        if ($quarterNumber !== null) {
            $semester = ((int) $quarterNumber <= 2) ? '1st' : '2nd';
            $semesterLabel = $semester . ' Semester';
        }

        $cfg = scheduleLoadSchoolConfig($pdo);
        $segments = scheduleDaySegments($cfg);

        $resolved = scheduleResolveCurriculum($pdo, $gradeLevelId, $schoolYear);

        // All active subjects of the grade (strand-aware, same shape as subjects.php)
        $strand = trim((string) ($section['strand'] ?? ''));
        $normalized = strtoupper($strand);
        $subjectStrand = ($normalized === 'TECH-PRO'
            || strpos($normalized, 'TECHNICAL-PROFESSIONAL') === 0)
            ? 'Tech-Pro'
            : $strand;

        $subjectSql = "SELECT id, subject_code, subject_name, semester, strand, subject_type
                       FROM tblsubjects
                       WHERE grade_level_id = ? AND COALESCE(is_active, 1) = 1";
        $subjectParams = [$gradeLevelId];
        $subjectSql .= " AND academic_year_id = ?";
        $subjectParams[] = $academicYearId;
        if ($strand !== '') {
            $subjectSql .= " AND strand = ?";
            $subjectParams[] = $subjectStrand;
        } else {
            $subjectSql .= " AND (strand IS NULL OR strand = '')";
        }
        if ($semester !== null) {
            $subjectSql .= " AND (semester IS NULL OR semester = ?)";
            $subjectParams[] = $semester;
        }
        $subjectSql .= " ORDER BY subject_name ASC";
        $subjectStmt = $pdo->prepare($subjectSql);
        $subjectStmt->execute($subjectParams);
        $gradeSubjects = [];
        foreach ($subjectStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $gradeSubjects[(int) $row['id']] = $row;
        }

        // Active teachers
        $teacherStmt = $pdo->query(
            "SELECT id, CONCAT(lname, ', ', fname,
                CASE WHEN mname IS NULL OR mname = '' THEN ''
                     ELSE CONCAT(' ', LEFT(mname, 1), '.') END) AS teacher_name
             FROM tblteacher
             WHERE COALESCE(is_active, 1) = 1
             ORDER BY lname ASC, fname ASC"
        );
        $teacherNames = [];
        foreach ($teacherStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $teacherNames[(int) $row['id']] = $row['teacher_name'];
        }

        $requirements = $resolved['curriculum']
            ? scheduleLoadCurriculumRequirements($pdo, (int) $resolved['curriculum']['curriculum_id'], $gradeLevelId)
            : ['required' => [], 'configured' => []];

        return [
            'section'              => $section,
            'schoolYear'           => $schoolYear,
            'startYear'            => $startYear,
            'semester'             => $semester,
            'semesterLabel'        => $semesterLabel,
            'cfg'                  => $cfg,
            'segments'             => $segments,
            'curriculum'           => $resolved['curriculum'],
            'curriculumConfigured' => $resolved['configured_for_grade'],
            'gradeSubjects'        => $gradeSubjects,
            'requirements'         => $requirements,
            'teacherNames'         => $teacherNames,
        ];
    }
}

if (!function_exists('scheduleBuildPlan')) {
    /**
     * Decide exactly which meetings must be created for the section:
     * skip subjects that already have a valid schedule, expand every
     * required subject into its configured weekly meetings, and collect
     * configuration warnings for anything that cannot be scheduled.
     *
     * @return array{plan: array, skipped: array, warnings: array, notAuto: array}
     */
    function scheduleBuildPlan(array $ctx): array
    {
        $warnings = [];
        $notAuto = []; // subjects present for the grade but NOT auto-scheduled

        $gradeName = (string) ($ctx['section']['grade_level_name'] ?? ('Grade Level #' . $ctx['section']['grade_level_id']));

        if (!$ctx['curriculumConfigured'] || !$ctx['curriculum']) {
            $curriculumText = $ctx['curriculum']
                ? sprintf('%s (%s, effective SY %s)', $ctx['curriculum']['curriculum_name'], $ctx['curriculum']['curriculum_version'], $ctx['curriculum']['effective_school_year'])
                : 'none';
            $warnings[] = sprintf(
                'No curriculum configuration rows exist for %s in the applicable curriculum (%s). Curriculum/time-allotment setup is required before Auto Generate can schedule this grade.',
                $gradeName,
                $curriculumText
            );
        }

        // Subjects of the grade that are not configured as required
        foreach ($ctx['gradeSubjects'] as $sid => $subject) {
            if (isset($ctx['requirements']['required'][$sid])) {
                continue;
            }
            $type = strtoupper((string) ($subject['subject_type'] ?? ''));
            if (isset($ctx['requirements']['configured'][$sid])) {
                $notAuto[] = [
                    'subject_id'   => $sid,
                    'subject_name' => $subject['subject_name'],
                    'subject_code' => $subject['subject_code'],
                    'reason'       => sprintf(
                        '%s subject - not auto-scheduled. Configure its allotment (meetings_per_week/minutes_per_meeting) in tblcurriculum_subjects or add the schedule manually.',
                        ucfirst(strtolower($type === '' ? 'ELECTIVE' : $type))
                    ),
                ];
            } else {
                $notAuto[] = [
                    'subject_id'   => $sid,
                    'subject_name' => $subject['subject_name'],
                    'subject_code' => $subject['subject_code'],
                    'reason'       => 'No curriculum time allotment is configured for this subject - it cannot be auto-scheduled.',
                ];
                $warnings[] = sprintf(
                    'Missing curriculum configuration: %s (%s) has no entry in tblcurriculum_subjects for %s.',
                    $subject['subject_name'],
                    $subject['subject_code'],
                    $gradeName
                );
            }
        }

        // Requirements pointing at subjects that are inactive / not applicable
        foreach ($ctx['requirements']['required'] as $sid => $req) {
            if (!isset($ctx['gradeSubjects'][$sid])) {
                $warnings[] = sprintf(
                    'Curriculum requirement skipped: %s (%s) is inactive or not applicable to this section (strand/semester filter).',
                    $req['subject_name'],
                    $req['subject_code']
                );
                unset($ctx['requirements']['required'][$sid]);
                continue;
            }
            if ($req['meetings_per_week'] === null || $req['minutes_per_meeting'] === null) {
                $warnings[] = sprintf(
                    'Missing curriculum configuration: %s (%s) is required but has no meetings_per_week/minutes_per_meeting allotment.',
                    $req['subject_name'],
                    $req['subject_code']
                );
                unset($ctx['requirements']['required'][$sid]);
                continue;
            }
            if (!schedulePeriodMatchesSemester($req['applicable_period'], $ctx['semester'])) {
                unset($ctx['requirements']['required'][$sid]); // belongs to the other semester
            } elseif ((int) $req['is_official'] === 0) {
                $warnings[] = sprintf(
                    'Review configuration: %s (%s) uses a school-configured allotment (%s).',
                    $req['subject_name'],
                    $req['subject_code'],
                    (string) $req['source_reference']
                );
            }
        }

        return ['requirements' => $ctx['requirements'], 'warnings' => $warnings, 'notAuto' => $notAuto];
    }
}

if (!function_exists('scheduleExistingSubjectMap')) {
    /**
     * Active schedule rows already stored for the section in this school
     * year, keyed by subject: ['semester' => string|null, 'count' => n].
     */
    function scheduleExistingSubjectMap(PDO $pdo, int $sectionId, string $schoolYear): array
    {
        $stmt = $pdo->prepare(
            "SELECT subject_id, semester, COUNT(*) AS meeting_count
             FROM tblschedule
             WHERE section_id = ? AND school_year = ? AND COALESCE(is_active, 1) = 1
             GROUP BY subject_id, semester"
        );
        $stmt->execute([$sectionId, $schoolYear]);

        $map = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $sid = (int) $row['subject_id'];
            if (!isset($map[$sid])) {
                $map[$sid] = ['semester' => null, 'count' => 0];
            }
            $map[$sid]['count'] += (int) $row['meeting_count'];
            $map[$sid]['semester'] = $row['semester'];
        }
        return $map;
    }
}

if (!function_exists('scheduleSemesterMatches')) {
    /**
     * Does an existing schedule row belong to the same semester scope as
     * the subject? Subjects without a semester are year-long: any active
     * schedule for the school year blocks them. Semester subjects are only
     * blocked by schedules of the same semester.
     */
    function scheduleSemesterMatches(?string $existingSemester, ?string $subjectSemester): bool
    {
        $existing = strtoupper(trim((string) $existingSemester));
        $subject  = strtoupper(trim((string) $subjectSemester));
        if ($subject === '' || $subject === 'ALL') {
            return true; // year-long subject: any existing schedule blocks it
        }
        if ($existing === '') {
            return true;
        }
        return strpos($existing, $subject) === 0; // '1st' matches '1st Semester'
    }
}

if (!function_exists('scheduleGenerateForSection')) {
    /**
     * Generate the weekly timetable for one section using the curriculum
     * configuration applicable to its grade level and the selected
     * academic year.
     *
     * Guarantees:
     *   - only subjects configured for the grade/curriculum are scheduled;
     *   - teacher / section / room conflicts are impossible (in-memory
     *     caches during search + full DB re-validation inside the
     *     transaction before commit);
     *   - meetings are spread across the configured school days;
     *   - an incomplete result is never presented as complete: every
     *     unsatisfied requirement is reported with a concrete reason;
     *   - critical failures roll the whole transaction back.
     */
    function scheduleGenerateForSection(PDO $pdo, int $sectionId, int $academicYearId): array
    {
        $ctx = scheduleGenerateContext($pdo, $sectionId, $academicYearId);

        $sectionId = (int) $ctx['section']['id'];
        $schoolYear = $ctx['schoolYear'];
        $cfg = $ctx['cfg'];

        $warnings = $cfg['warnings'];
        $plan = scheduleBuildPlan($ctx);
        $warnings = array_merge($warnings, $plan['warnings']);
        $notAuto = $plan['notAuto'];
        $required = $plan['requirements']['required'];

        // ---- Existing schedules (skip subjects already scheduled) -------
        $existing = scheduleExistingSubjectMap($pdo, $sectionId, $schoolYear);

        $skipped = [];
        $todos = [];
        foreach ($required as $sid => $req) {
            $subject = $ctx['gradeSubjects'][$sid];
            $blocked = false;
            if (isset($existing[$sid])) {
                $blocked = scheduleSemesterMatches($existing[$sid]['semester'], $subject['semester']);
            }
            if ($blocked) {
                $skipped[] = [
                    'subject_id'   => $sid,
                    'subject_name' => $subject['subject_name'],
                    'subject_code' => $subject['subject_code'],
                    'reason'       => 'Already has an active schedule for this section, academic year'
                        . (($subject['semester'] !== null) ? ' and semester' : '') . '.',
                ];
                continue;
            }
            $todos[] = [
                'subject_id'    => $sid,
                'subject'       => $subject,
                'requirement'   => $req,
                'meetings'      => max(1, (int) $req['meetings_per_week']),
                'minutes'       => max(5, (int) $req['minutes_per_meeting']),
                // Heuristic: place the heaviest loads first so tight
                // capacities are filled in the best order.
                'weeklyMinutes' => (int) $req['meetings_per_week'] * (int) $req['minutes_per_meeting'],
            ];
        }

        usort($todos, function ($a, $b) {
            if ($a['weeklyMinutes'] !== $b['weeklyMinutes']) {
                return $b['weeklyMinutes'] <=> $a['weeklyMinutes'];
            }
            return strcmp((string) $a['subject']['subject_name'], (string) $b['subject']['subject_name']);
        });

        // ---- Capacity check -------------------------------------------------
        $capacityMinutes = 0;
        foreach ($cfg['days'] as $day) {
            foreach ($ctx['segments'][$day] as $seg) {
                $capacityMinutes += $seg[1] - $seg[0];
            }
        }
        $neededMinutes = 0;
        foreach ($todos as $todo) {
            $neededMinutes += $todo['weeklyMinutes'];
        }

        if ($capacityMinutes <= 0) {
            throw new ScheduleEngineException(
                'The configured school hours leave no usable time slots. Check schedule_start/schedule_end, break and lunch settings.'
            );
        }
        if ($neededMinutes > $capacityMinutes) {
            $warnings[] = sprintf(
                'Required weekly minutes (%d) exceed the configured weekly capacity (%d minutes across %d day(s) %s-%s). Some subjects will remain unscheduled.',
                $neededMinutes,
                $capacityMinutes,
                count($cfg['days']),
                $cfg['start_time'],
                $cfg['end_time']
            );
        }

        // ---- Teacher eligibility --------------------------------------------
        // Only teachers explicitly assigned to this section+subject are eligible.
        $assignedStmt = $pdo->prepare(
            "SELECT sts.subject_id, sts.teacher_id
             FROM tblsection_teacher_subject sts
             WHERE sts.section_id = ? AND COALESCE(sts.is_active, 1) = 1"
        );
        $assignedStmt->execute([$sectionId]);
        $assignedBySubject = [];
        foreach ($assignedStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $tid = (int) $row['teacher_id'];
            if (isset($ctx['teacherNames'][$tid])) {
                $assignedBySubject[(int) $row['subject_id']][] = $tid;
            } else {
                $warnings[] = 'An inactive teacher (#' . $tid . ') is assigned to this section and was ignored.';
            }
        }

        if (!$ctx['teacherNames']) {
            throw new ScheduleEngineException('No active teachers are available to generate schedules.');
        }

        $assignedTodos = [];
        foreach ($todos as $todo) {
            $sid = (int) $todo['subject_id'];
            if (!empty($assignedBySubject[$sid])) {
                $assignedTodos[] = $todo;
                continue;
            }
            $subject = $ctx['gradeSubjects'][$sid];
            $skipped[] = [
                'subject_id'   => $sid,
                'subject_name' => $subject['subject_name'],
                'subject_code' => $subject['subject_code'],
                'reason'       => 'No active teacher is assigned to this subject for this section.',
            ];
        }
        $todos = $assignedTodos;

        if (!$todos) {
            return scheduleBuildResponse($ctx, [], $skipped, $notAuto, $warnings, [], []);
        }

        // ---- Existing occupancy (school-year wide) ---------------------------
        $sectionBusy = [];
        $teacherBusy = [];
        $roomBusy = [];
        $daySectionCount = array_fill_keys($cfg['days'], 0);
        $daySubjectCount = [];
        $teacherLoad = array_fill_keys(array_keys($ctx['teacherNames']), 0);
        $roomLoad = array_fill_keys($cfg['rooms'], 0);

        $occStmt = $pdo->prepare(
            "SELECT day_name, time_start, time_end, section_id, teacher_id, room
             FROM tblschedule
             WHERE school_year = ? AND COALESCE(is_active, 1) = 1"
        );
        $occStmt->execute([$schoolYear]);
        foreach ($occStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $day = (string) $row['day_name'];
            $start = scheduleTimeToMinutes((string) $row['time_start']);
            $end = scheduleTimeToMinutes((string) $row['time_end']);
            if ($start === null || $end === null || $end <= $start) {
                continue;
            }
            $sid = (string) $row['section_id'];
            $tid = (string) $row['teacher_id'];
            $room = $row['room'] !== null ? trim((string) $row['room']) : '';
            scheduleAddBusy($sectionBusy, $sid, $day, $start, $end);
            scheduleAddBusy($teacherBusy, $tid, $day, $start, $end);
            if ($room !== '') {
                scheduleAddBusy($roomBusy, $room, $day, $start, $end);
            }
            if ($sid === (string) $sectionId && isset($daySectionCount[$day])) {
                $daySectionCount[$day]++;
            }
            if ($tid !== '' && isset($teacherLoad[(int) $tid])) {
                $teacherLoad[(int) $tid]++;
            }
            if ($room !== '' && isset($roomLoad[$room])) {
                $roomLoad[$room]++;
            }
        }

        // ---- Transactional placement ----------------------------------------
        $dayIndex = array_flip($cfg['days']);
        $inserted = [];
        $placementNotes = [];

        $pdo->beginTransaction();
        try {
            $insertStmt = $pdo->prepare(
                "INSERT IGNORE INTO tblschedule
                    (section_id, subject_id, teacher_id, day_name, time_start, time_end, room, semester, school_year, is_active)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)"
            );

            foreach ($todos as $todo) {
                $sid = (int) $todo['subject_id'];
                $subject = $todo['subject'];

                $teacherIds = $assignedBySubject[$sid];

                $subjectCtx = $subject + [
                    'subject_id'     => $sid,
                    'section_id'     => $sectionId,
                    'room_preference' => $todo['requirement']['room_preference'],
                ];

                $placed = [];
                $lockedTeacherId = null;
                for ($k = 0; $k < $todo['meetings']; $k++) {
                    $eligibleTeacherIds = $lockedTeacherId === null
                        ? $teacherIds
                        : [$lockedTeacherId];
                    $slot = scheduleFindSlot(
                        $subjectCtx,
                        $todo['minutes'],
                        $eligibleTeacherIds,
                        $ctx['segments'],
                        $cfg,
                        $dayIndex,
                        $sectionBusy,
                        $teacherBusy,
                        $roomBusy,
                        $daySectionCount,
                        $daySubjectCount,
                        $teacherLoad,
                        $roomLoad
                    );
                    if ($slot === null) {
                        break; // no feasible slot left for this meeting
                    }
                    if ($lockedTeacherId === null) {
                        $lockedTeacherId = (int) $slot['teacher_id'];
                    }

                    $semesterLabel = $subject['semester'] !== null
                        ? $subject['semester'] . ' Semester'
                        : $ctx['semesterLabel'];

                    $insertStmt->execute([
                        $sectionId,
                        $sid,
                        $slot['teacher_id'],
                        $slot['day'],
                        scheduleMinutesToTime($slot['start']) . ':00',
                        scheduleMinutesToTime($slot['end']) . ':00',
                        $slot['room'],
                        $semesterLabel,
                        $schoolYear,
                    ]);
                    if ($insertStmt->rowCount() === 0) {
                        continue;
                    }
                    $meeting = [
                        'id'         => (int) $pdo->lastInsertId(),
                        'subject_id' => $sid,
                        'day'        => $slot['day'],
                        'start'      => $slot['start'],
                        'end'        => $slot['end'],
                        'room'       => $slot['room'],
                        'teacher_id' => $slot['teacher_id'],
                    ];
                    $inserted[] = $meeting;
                    $placed[] = $meeting;

                    // update caches
                    scheduleAddBusy($sectionBusy, (string) $sectionId, $slot['day'], $slot['start'], $slot['end']);
                    scheduleAddBusy($teacherBusy, (string) $slot['teacher_id'], $slot['day'], $slot['start'], $slot['end']);
                    scheduleAddBusy($roomBusy, $slot['room'], $slot['day'], $slot['start'], $slot['end']);
                    $daySectionCount[$slot['day']] = ($daySectionCount[$slot['day']] ?? 0) + 1;
                    $daySubjectCount[$sid][$slot['day']] = ($daySubjectCount[$sid][$slot['day']] ?? 0) + 1;
                    $teacherLoad[$slot['teacher_id']] = ($teacherLoad[$slot['teacher_id']] ?? 0) + 1;
                    $roomLoad[$slot['room']] = ($roomLoad[$slot['room']] ?? 0) + 1;
                }

                $todo['placed'] = $placed;
            }

            // ---- Full DB re-validation (section + teacher + room) ------------
            foreach ($inserted as $row) {
                $dupStmt = $pdo->prepare(
                    "SELECT COUNT(*)
                     FROM tblschedule sc
                     WHERE sc.school_year = ?
                       AND sc.day_name = ?
                       AND COALESCE(sc.is_active, 1) = 1
                       AND sc.id <> ?
                       AND sc.time_start < ? AND sc.time_end > ?
                       AND (sc.section_id = ? OR sc.teacher_id = ? OR (sc.room IS NOT NULL AND sc.room = ?))"
                );
                $dupStmt->execute([
                    $schoolYear,
                    $row['day'],
                    $row['id'],
                    scheduleMinutesToTime($row['end']) . ':00',
                    scheduleMinutesToTime($row['start']) . ':00',
                    $sectionId,
                    $row['teacher_id'],
                    $row['room'],
                ]);
                if ((int) $dupStmt->fetchColumn() > 0) {
                    throw new ScheduleEngineException(sprintf(
                        'Conflict detected while saving subject #%d on %s. The generated timetable was rolled back.',
                        $row['subject_id'],
                        $row['day']
                    ));
                }
            }

            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }

        return scheduleBuildResponse($ctx, $todos, $skipped, $notAuto, $warnings, $placementNotes);
    }
}

if (!function_exists('scheduleBuildResponse')) {
    /**
     * Assemble the Auto Generate API response: what was scheduled, what
     * was skipped, what could NOT be satisfied (with concrete reasons),
     * plus curriculum/school context.
     */
    function scheduleBuildResponse(array $ctx, array $todos, array $skipped, array $notAuto, array $warnings, array $placementNotes): array
    {
        $scheduled = [];
        $unscheduled = [];
        $generatedCount = 0;

        foreach ($todos as $todo) {
            $subject = $todo['subject'];
            $meetings = $todo['placed'] ?? [];
            $meetingsPlaced = count($meetings);
            $meetingsRequired = (int) $todo['meetings'];
            $generatedCount += $meetingsPlaced;

            $teacherNames = [];
            $teacherIds = [];
            $meetingRows = [];
            foreach ($meetings as $m) {
                $tid = (int) $m['teacher_id'];
                if (!in_array($tid, $teacherIds, true)) {
                    $teacherIds[] = $tid;
                    $teacherNames[] = $ctx['teacherNames'][$tid] ?? ('Teacher #' . $tid);
                }
                $meetingRows[] = [
                    'id'         => $m['id'],
                    'day_name'   => $m['day'],
                    'time_start' => scheduleMinutesToTime($m['start']),
                    'time_end'   => scheduleMinutesToTime($m['end']),
                    'room'       => $m['room'],
                    'teacher_id' => $tid,
                ];
            }

            if ($meetingsPlaced === $meetingsRequired) {
                $scheduled[] = [
                    'subject_id'        => (int) $todo['subject_id'],
                    'subject_name'      => $subject['subject_name'],
                    'subject_code'      => $subject['subject_code'],
                    'teacher_ids'       => $teacherIds,
                    'teacher_names'     => $teacherNames,
                    'meetings_required' => $meetingsRequired,
                    'meetings_placed'   => $meetingsPlaced,
                    'minutes_per_week'  => $meetingsPlaced * (int) $todo['minutes'],
                    'meetings'          => $meetingRows,
                ];
            } else {
                $reason = sprintf(
                    'Required weekly time could not be satisfied (%d of %d meeting(s) placed).',
                    $meetingsPlaced,
                    $meetingsRequired
                );
                if (isset($placementNotes[(int) $todo['subject_id']])) {
                    $reason .= ' ' . $placementNotes[(int) $todo['subject_id']];
                }
                if (!$meetingsPlaced) {
                    $reason .= ' No compatible free slot/teacher/room combination was found within the configured school hours.';
                }
                $unscheduled[] = [
                    'subject_id'   => (int) $todo['subject_id'],
                    'subject_name' => $subject['subject_name'],
                    'subject_code' => $subject['subject_code'],
                    'reason'       => $reason,
                ];
            }
        }

        $curriculum = $ctx['curriculum'];
        $gradeName = (string) ($ctx['section']['grade_level_name'] ?? 'the selected grade');

        $message = $generatedCount > 0
            ? sprintf('%d schedule entr%s generated for %s - %s.', $generatedCount, $generatedCount === 1 ? 'y' : 'ies', $gradeName, (string) $ctx['section']['section_name'])
            : 'No new schedule entries were generated.';

        if ($unscheduled) {
            $message = sprintf('%s Unable to complete the %s schedule: %d subject(s) could not be scheduled.', $message, $gradeName, count($unscheduled));
        }

        $details = array_merge(
            array_map(function ($u) {
                return $u['subject_name'] . ' — ' . $u['reason'];
            }, $unscheduled),
            $warnings
        );

        $response = [
            'success'         => true,
            'generated_count' => $generatedCount,
            'skipped_count'   => count($skipped),
            'complete'        => !$unscheduled,
            'message'         => $message,
            'details'         => $details,
        ];

        return scheduleBuildResponseTail($ctx, $curriculum, $unscheduled, $skipped, $notAuto, $warnings, $response);
    }
}

if (!function_exists('scheduleBuildResponseTail')) {
    /** Add section/AY/curriculum/school context and finalize success state. */
    function scheduleBuildResponseTail(array $ctx, ?array $curriculum, array $unscheduled, array $skipped, array $notAuto, array $warnings, array $response): array
    {
        $response['section'] = [
            'id'          => (int) $ctx['section']['id'],
            'name'        => $ctx['section']['section_name'],
            'grade_level' => $ctx['section']['grade_level_name'],
        ];
        $response['academic_year'] = [
            'label'      => $ctx['schoolYear'],
            'start_year' => $ctx['startYear'],
        ];
        $response['curriculum'] = $curriculum ? [
            'id'                    => (int) $curriculum['curriculum_id'],
            'name'                  => $curriculum['curriculum_name'],
            'version'               => $curriculum['curriculum_version'],
            'effective_school_year' => $curriculum['effective_school_year'],
            'description'           => $curriculum['description'],
        ] : null;
        $response['school'] = [
            'days'       => $ctx['cfg']['days'],
            'start_time' => $ctx['cfg']['start_time'],
            'end_time'   => $ctx['cfg']['end_time'],
            'break'      => $ctx['cfg']['break_start'] && $ctx['cfg']['break_end']
                ? $ctx['cfg']['break_start'] . '-' . $ctx['cfg']['break_end'] : null,
            'lunch'      => $ctx['cfg']['lunch_start'] && $ctx['cfg']['lunch_end']
                ? $ctx['cfg']['lunch_start'] . '-' . $ctx['cfg']['lunch_end'] : null,
            'rooms'      => $ctx['cfg']['rooms'],
        ];
        $response['unscheduled'] = $unscheduled;
        $response['skipped'] = $skipped;
        $response['not_auto'] = $notAuto;
        $response['warnings'] = $warnings;

        if ((int) $response['generated_count'] === 0 && $skipped && !$response['details']) {
            $response['message'] = sprintf(
                'All %d configured subject(s) already have valid schedules for %s - %s. Nothing new was generated.',
                count($skipped),
                (string) ($ctx['section']['grade_level_name'] ?? 'this grade'),
                (string) $ctx['section']['section_name']
            );
        }

        // Nothing could be generated while there is something to explain -> failure
        if ((int) $response['generated_count'] === 0 && $response['details']) {
            $response['success'] = false;
            $response['error'] = 'Unable to generate a complete schedule.';
        }

        return $response;
    }
}
