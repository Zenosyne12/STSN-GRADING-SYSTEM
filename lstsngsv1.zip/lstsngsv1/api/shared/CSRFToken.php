<?php
/**
 * CSRFToken - Session-based CSRF protection
 */
class CSRFToken
{
    const TOKEN_NAME = '_csrf_token';
    const TOKEN_LENGTH = 32;

    /**
     * Generate and store CSRF token in session
     */
    public static function generate(): string
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (empty($_SESSION[self::TOKEN_NAME])) {
            $_SESSION[self::TOKEN_NAME] = bin2hex(random_bytes(self::TOKEN_LENGTH));
        }

        return $_SESSION[self::TOKEN_NAME];
    }

    /**
     * Get current token (without generating new one)
     */
    public static function get(): ?string
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        return $_SESSION[self::TOKEN_NAME] ?? null;
    }

    /**
     * Verify token from POST/GET
     */
    public static function verify(?string $token): bool
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $sessionToken = $_SESSION[self::TOKEN_NAME] ?? null;

        if ($sessionToken === null || $token === null) {
            return false;
        }

        // Use hash_equals to prevent timing attacks
        return hash_equals($sessionToken, $token);
    }

    /**
     * Get hidden input HTML for forms
     */
    public static function getInputHTML(): string
    {
        return '<input type="hidden" name="' . self::TOKEN_NAME . '" value="' . htmlspecialchars(self::generate()) . '">';
    }

    /**
     * Regenerate token (call after sensitive operations)
     */
    public static function regenerate(): string
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $_SESSION[self::TOKEN_NAME] = bin2hex(random_bytes(self::TOKEN_LENGTH));
        return $_SESSION[self::TOKEN_NAME];
    }
}
?>