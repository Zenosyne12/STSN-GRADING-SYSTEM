<?php



class CSRFToken
{
    const TOKEN_NAME = '_csrf_token';
    const TOKEN_LENGTH = 32;

    


    public static function generate(): string
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (empty($_SESSION[self::TOKEN_NAME])) {
            $_SESSION[self::TOKEN_NAME] = bin2hex(random_bytes(self::TOKEN_LENGTH));
        }

        return $_SESSION[self::TOKEN_NAME];
    }

    


    public static function get(): ?string
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        return $_SESSION[self::TOKEN_NAME] ?? null;
    }

    


    public static function verify(?string $token): bool
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $sessionToken = $_SESSION[self::TOKEN_NAME] ?? null;

        if ($sessionToken === null || $token === null) {
            return false;
        }

        
        return hash_equals($sessionToken, $token);
    }

    


    public static function getInputHTML(): string
    {
        return '<input type="hidden" name="' . self::TOKEN_NAME . '" value="' . htmlspecialchars(self::generate()) . '">';
    }

    


    public static function regenerate(): string
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $_SESSION[self::TOKEN_NAME] = bin2hex(random_bytes(self::TOKEN_LENGTH));
        return $_SESSION[self::TOKEN_NAME];
    }
}
?>