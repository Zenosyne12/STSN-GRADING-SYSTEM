<?php
// Include the main auth file from includes folder
$authPath = __DIR__ . '/../../includes/auth.php';

if (file_exists($authPath)) {
    require_once $authPath;
} else {
    // Fallback if includes/auth.php doesn't exist
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params([
            'path' => '/',
            'httponly' => true,
            'samesite' => 'Lax',
            'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        ]);
        session_start();
    }

    function requireLogin(): void
    {
        if (
            !isset($_SESSION['user_id']) ||
            (int) $_SESSION['user_id'] <= 0 ||
            !isset($_SESSION['role_id']) ||
            (int) $_SESSION['role_id'] <= 0
        ) {
            http_response_code(401);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'Unauthorized. Please log in.']);
            exit;
        }
    }

    function getSessionRoleId(): int
    {
        requireLogin();
        return (int) ($_SESSION['role_id'] ?? 0);
    }

    function isAdminSession(): bool
    {
        return getSessionRoleId() === 1;
    }

    function isTeacherSession(): bool
    {
        return getSessionRoleId() === 2;
    }

    function requireAdmin(): void
    {
        requireLogin();

        if (!isAdminSession()) {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'Forbidden. Admin access required.']);
            exit;
        }
    }

    function requireTeacher(): void
    {
        requireLogin();

        if (!isTeacherSession()) {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'Forbidden. Teacher access required.']);
            exit;
        }

        if (!isset($_SESSION['teacher_id']) || (int) $_SESSION['teacher_id'] <= 0) {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'Invalid teacher session.']);
            exit;
        }
    }
}

// Helper function to get current user ID for API operations
function getCurrentUserId(): int {
    requireLogin();
    return (int) ($_SESSION['user_id'] ?? 0);
}

// Helper function to get current teacher ID
function getCurrentTeacherId(): int {
    requireTeacher();
    return (int) ($_SESSION['teacher_id'] ?? 0);
}
?>