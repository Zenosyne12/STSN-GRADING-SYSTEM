<?php
/**
 * PasswordValidator - Shared utility for password validation
 * Used by both change-password.php and forgot password flows
 */
class PasswordValidator
{
    const MIN_LENGTH = 8;
    const MAX_LENGTH = 128;

    /**
     * Validate password strength and return errors
     * @param string $password
     * @return array ['valid' => bool, 'errors' => string[]]
     */
    public static function validate(string $password): array
    {
        $errors = [];

        // Check length
        if (strlen($password) < self::MIN_LENGTH) {
            $errors[] = "Password must be at least " . self::MIN_LENGTH . " characters long.";
        }
        if (strlen($password) > self::MAX_LENGTH) {
            $errors[] = "Password must not exceed " . self::MAX_LENGTH . " characters.";
        }

        // Check for uppercase letter
        if (!preg_match('/[A-Z]/', $password)) {
            $errors[] = "Password must contain at least one uppercase letter (A-Z).";
        }

        // Check for lowercase letter
        if (!preg_match('/[a-z]/', $password)) {
            $errors[] = "Password must contain at least one lowercase letter (a-z).";
        }

        // Check for number
        if (!preg_match('/[0-9]/', $password)) {
            $errors[] = "Password must contain at least one number (0-9).";
        }

        // Check for special character
        if (!preg_match('/[!@#$%^&*()_\-+=\[\]{};:\'",.<>?\/\\|`~]/', $password)) {
            $errors[] = "Password must contain at least one special character (!@#$%^&* etc).";
        }

        // Check for common weak patterns
        if (preg_match('/(.)\1{2,}/', $password)) {
            $errors[] = "Password cannot contain 3 or more repeated characters.";
        }

        // Check if password is sequential
        if (preg_match('/(?:abc|bcd|cde|def|efg|fgh|ghi|hij|ijk|jkl|klm|lmn|mno|nop|opq|pqr|qrs|rst|stu|tuv|uvw|vwx|wxy|xyz|012|123|234|345|456|567|678|789)/i', $password)) {
            $errors[] = "Password cannot contain sequential characters (abc, 123, etc).";
        }

        return [
            'valid' => empty($errors),
            'errors' => $errors
        ];
    }

    /**
     * Hash password using BCRYPT
     */
    public static function hash(string $password): string
    {
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    }

    /**
     * Verify password against hash
     */
    public static function verify(string $password, string $hash): bool
    {
        return password_verify($password, $hash);
    }

    /**
     * Get formatted validation rules as HTML
     */
    public static function getRequirementsHTML(): string
    {
        return '
            <ul style="font-size: 0.9rem; color: #666; margin: 10px 0;">
                <li>At least ' . self::MIN_LENGTH . ' characters long</li>
                <li>One uppercase letter (A-Z)</li>
                <li>One lowercase letter (a-z)</li>
                <li>One number (0-9)</li>
                <li>One special character (!@#$%^&* etc)</li>
            </ul>
        ';
    }
}
?>