<?php
/**
 * Ensures settings-related columns/tables exist and provides auto-section helpers.
 */

function stsnColumnExists(PDO $pdo, string $table, string $column): bool
{
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = ?
          AND COLUMN_NAME = ?
    ");
    $stmt->execute([$table, $column]);
    return (int) $stmt->fetchColumn() > 0;
}

function stsnTableExists(PDO $pdo, string $table): bool
{
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = ?
    ");
    $stmt->execute([$table]);
    return (int) $stmt->fetchColumn() > 0;
}

function stsnEnsureSettingsSchema(PDO $pdo): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    try {
        if (!stsnColumnExists($pdo, 'tblusers', 'theme_preference')) {
            $pdo->exec("ALTER TABLE tblusers ADD COLUMN theme_preference VARCHAR(10) NOT NULL DEFAULT 'light' AFTER status");
        }
        if (!stsnColumnExists($pdo, 'tblusers', 'show_section_prompt')) {
            $after = stsnColumnExists($pdo, 'tblusers', 'theme_preference') ? 'theme_preference' : 'status';
            $pdo->exec("ALTER TABLE tblusers ADD COLUMN show_section_prompt TINYINT(1) NOT NULL DEFAULT 1 AFTER {$after}");
        }
        if (!stsnColumnExists($pdo, 'tblusers', 'password_changed_at')) {
            $pdo->exec("ALTER TABLE tblusers ADD COLUMN password_changed_at TIMESTAMP NULL DEFAULT NULL AFTER password_hash");
        }
        if (!stsnColumnExists($pdo, 'tblsection', 'max_capacity')) {
            $pdo->exec("ALTER TABLE tblsection ADD COLUMN max_capacity INT NOT NULL DEFAULT 40 AFTER is_active");
        }
        if (!stsnTableExists($pdo, 'tblsystemsettings')) {
            $pdo->exec("
                CREATE TABLE tblsystemsettings (
                    setting_key VARCHAR(64) NOT NULL,
                    setting_value VARCHAR(255) NOT NULL,
                    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (setting_key)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
            ");
        }
        $pdo->exec("INSERT IGNORE INTO tblsystemsettings (setting_key, setting_value) VALUES ('auto_assign_enabled', '1')");
        $pdo->exec("INSERT IGNORE INTO tblsystemsettings (setting_key, setting_value) VALUES ('default_max_capacity', '40')");
    } catch (Throwable $e) {
        error_log('[settings_schema] ' . $e->getMessage());
    }
}

function stsnGetSetting(PDO $pdo, string $key, string $default = ''): string
{
    stsnEnsureSettingsSchema($pdo);
    $stmt = $pdo->prepare("SELECT setting_value FROM tblsystemsettings WHERE setting_key = ? LIMIT 1");
    $stmt->execute([$key]);
    $value = $stmt->fetchColumn();
    return $value === false ? $default : (string) $value;
}

function stsnSetSetting(PDO $pdo, string $key, string $value): void
{
    stsnEnsureSettingsSchema($pdo);
    $stmt = $pdo->prepare("
        INSERT INTO tblsystemsettings (setting_key, setting_value)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
    ");
    $stmt->execute([$key, $value]);
}

function stsnIsAutoAssignEnabled(PDO $pdo): bool
{
    return stsnGetSetting($pdo, 'auto_assign_enabled', '1') === '1';
}

function stsnDefaultMaxCapacity(PDO $pdo): int
{
    $value = (int) stsnGetSetting($pdo, 'default_max_capacity', '40');
    if ($value < 10) {
        $value = 10;
    }
    if ($value > 100) {
        $value = 100;
    }
    return $value;
}

function stsnJsonInput(): array
{
    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '[]', true);
    return is_array($data) ? $data : [];
}

function stsnJsonOut(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

function stsnActiveAcademicYearId(PDO $pdo): int
{
    $row = $pdo->query("SELECT id FROM tblacademicyear WHERE is_active = 1 ORDER BY id DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    if ($row) {
        return (int) $row['id'];
    }
    $row = $pdo->query("SELECT id FROM tblacademicyear ORDER BY id DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    return $row ? (int) $row['id'] : 0;
}

function stsnSectionEnrollmentCount(PDO $pdo, int $sectionId, int $academicYearId): int
{
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM tblsectionstudent
        WHERE section_id = ? AND academic_year_id = ? AND is_active = 1
    ");
    $stmt->execute([$sectionId, $academicYearId]);
    return (int) $stmt->fetchColumn();
}

function stsnStudentAlreadySectioned(PDO $pdo, int $studentId, int $academicYearId): ?array
{
    $stmt = $pdo->prepare("
        SELECT ss.section_id, s.section_name
        FROM tblsectionstudent ss
        INNER JOIN tblsection s ON s.id = ss.section_id
        WHERE ss.student_id = ? AND ss.academic_year_id = ? AND ss.is_active = 1
        LIMIT 1
    ");
    $stmt->execute([$studentId, $academicYearId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

/**
 * Place a student into the least-filled active section of their grade that still has capacity.
 */
function autoAssignStudentToSection(PDO $pdo, int $studentId, int $gradeLevelId, int $academicYearId, ?string $strand = null): array
{
    stsnEnsureSettingsSchema($pdo);

    if ($studentId <= 0 || $gradeLevelId <= 0 || $academicYearId <= 0) {
        return ['success' => false, 'error' => 'Student, grade level, and academic year are required.'];
    }

    $existing = stsnStudentAlreadySectioned($pdo, $studentId, $academicYearId);
    if ($existing) {
        return [
            'success' => true,
            'already_assigned' => true,
            'section_id' => (int) $existing['section_id'],
            'section_name' => $existing['section_name'],
            'message' => 'Student is already assigned to Section ' . $existing['section_name'],
        ];
    }

    $sql = "
        SELECT s.id, s.section_name, s.strand, COALESCE(s.max_capacity, 40) AS max_capacity,
               (
                   SELECT COUNT(*)
                   FROM tblsectionstudent ss
                   WHERE ss.section_id = s.id
                     AND ss.academic_year_id = ?
                     AND ss.is_active = 1
               ) AS current_count
        FROM tblsection s
        WHERE s.grade_level_id = ? AND s.is_active = 1
    ";
    $params = [$academicYearId, $gradeLevelId];

    $strand = trim((string) $strand);
    if ($strand !== '') {
        $sql .= " AND (s.strand IS NULL OR s.strand = '' OR s.strand = ?)";
        $params[] = $strand;
    }

    $sql .= " ORDER BY current_count ASC, s.id ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $sections = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$sections) {
        return [
            'success' => false,
            'error' => 'No available sections',
            'code' => 'no_sections',
        ];
    }

    foreach ($sections as $section) {
        $max = (int) $section['max_capacity'];
        $count = (int) $section['current_count'];
        if ($count < $max) {
            $ins = $pdo->prepare("
                INSERT INTO tblsectionstudent (section_id, student_id, academic_year_id, is_active)
                VALUES (?, ?, ?, 1)
            ");
            $ins->execute([(int) $section['id'], $studentId, $academicYearId]);
            return [
                'success' => true,
                'section_id' => (int) $section['id'],
                'section_name' => $section['section_name'],
                'message' => 'Student assigned to Section ' . $section['section_name'],
            ];
        }
    }

    return [
        'success' => false,
        'error' => 'All sections at capacity',
        'code' => 'full',
    ];
}

function stsnGradeLevelName(PDO $pdo, int $gradeLevelId): string
{
    $stmt = $pdo->prepare("SELECT grade_level_name FROM tblgradelevel WHERE id = ? LIMIT 1");
    $stmt->execute([$gradeLevelId]);
    return (string) ($stmt->fetchColumn() ?: 'this grade');
}

function stsnCapacityStatus(int $current, int $max): string
{
    if ($max <= 0) {
        return 'full';
    }
    if ($current >= $max) {
        return 'full';
    }
    if ($current >= (int) ceil($max * 0.9)) {
        return 'nearly_full';
    }
    return 'available';
}
