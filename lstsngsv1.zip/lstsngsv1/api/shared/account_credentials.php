<?php
require_once __DIR__ . '/phpmailer.php';

function stsnFullName(array $person): string
{
    return trim(implode(' ', array_filter([
        trim((string)($person['fname'] ?? '')),
        trim((string)($person['mname'] ?? '')),
        trim((string)($person['lname'] ?? '')),
    ], static fn($part) => $part !== '')));
}

function stsnNamePart(string $value, bool $titleCase = false): string
{
    $value = preg_replace('/[^A-Za-z0-9]+/', '', $value);
    if ($value === '') {
        return '';
    }

    return $titleCase ? ucfirst(strtolower($value)) : strtolower($value);
}

function stsnGenerateTemporaryPassword(): string
{
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';
    $password = '';
    $max = strlen($alphabet) - 1;

    for ($i = 0; $i < 14; $i++) {
        $password .= $alphabet[random_int(0, $max)];
    }

    return $password;
}

function stsnGenerateTeacherTemporaryPassword(array $teacher): string
{
    $surname = stsnNamePart((string)($teacher['lname'] ?? ''));
    $dateHired = preg_replace('/[^0-9]/', '', (string)($teacher['date_hired'] ?? ''));

    if ($surname === '' || $dateHired === '') {
        throw new Exception('Teacher surname and date hired are required to create the temporary password.');
    }

    return $surname . $dateHired;
}

function stsnLoginUrl(): string
{
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443);
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
    $root = rtrim(preg_replace('#/api/.*$#', '', $scriptDir), '/');

    return $scheme . '://' . $host . ($root === '' ? '' : $root) . '/login.php';
}

function stsnUniqueUsername(PDO $pdo, string $baseUsername): string
{
    $baseUsername = trim($baseUsername);
    if ($baseUsername === '') {
        $baseUsername = 'stsnuser';
    }

    $stmt = $pdo->prepare('SELECT id FROM tblusers WHERE username = ? LIMIT 1');
    $username = $baseUsername;
    $suffix = 2;

    while (true) {
        $stmt->execute([$username]);
        if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
            return $username;
        }
        $username = $baseUsername . $suffix;
        $suffix++;
    }
}

function stsnTeacherUsername(PDO $pdo, array $teacher): string
{
    return trim((string)($teacher['email'] ?? ''));
}

function stsnStudentUsername(PDO $pdo, array $student): string
{
    return trim((string)($student['email'] ?? ''));
}

function stsnValidateCredentialEmail(string $email, string $label): void
{
    if ($email === '') {
        throw new Exception($label . ' email address is required before account creation.');
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception($label . ' email address is invalid.');
    }
}

function stsnTeacherEmailAccountExists(PDO $pdo, string $email, int $excludeTeacherId = 0, int $excludeUserId = 0): bool
{
    $userSql = 'SELECT id FROM tblusers WHERE username = ?';
    $userParams = [$email];
    if ($excludeUserId > 0) {
        $userSql .= ' AND id <> ?';
        $userParams[] = $excludeUserId;
    }
    $userSql .= ' LIMIT 1';

    $userStmt = $pdo->prepare($userSql);
    $userStmt->execute($userParams);
    if ($userStmt->fetch(PDO::FETCH_ASSOC)) {
        return true;
    }

    $teacherSql = 'SELECT id FROM tblteacher WHERE email = ?';
    $teacherParams = [$email];
    if ($excludeTeacherId > 0) {
        $teacherSql .= ' AND id <> ?';
        $teacherParams[] = $excludeTeacherId;
    }
    $teacherSql .= ' LIMIT 1';

    $teacherStmt = $pdo->prepare($teacherSql);
    $teacherStmt->execute($teacherParams);

    return (bool)$teacherStmt->fetch(PDO::FETCH_ASSOC);
}

function stsnAssertTeacherEmailAvailable(PDO $pdo, string $email, int $excludeTeacherId = 0, int $excludeUserId = 0, string $message = 'This email address already has an existing account.'): void
{
    stsnValidateCredentialEmail($email, 'Teacher');

    if (stsnTeacherEmailAccountExists($pdo, $email, $excludeTeacherId, $excludeUserId)) {
        throw new Exception($message);
    }
}

function stsnStudentEmailExists(PDO $pdo, string $email, int $excludeStudentId = 0, int $excludeUserId = 0): bool
{
    if ($email === '') {
        return false;
    }

    $sql = 'SELECT id FROM tblstudents WHERE email = ?';
    $params = [$email];
    if ($excludeStudentId > 0) {
        $sql .= ' AND id <> ?';
        $params[] = $excludeStudentId;
    }
    $sql .= ' LIMIT 1';

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    if ($stmt->fetch(PDO::FETCH_ASSOC)) {
        return true;
    }

    $userSql = 'SELECT id FROM tblusers WHERE username = ?';
    $userParams = [$email];
    if ($excludeUserId > 0) {
        $userSql .= ' AND id <> ?';
        $userParams[] = $excludeUserId;
    }
    $userSql .= ' LIMIT 1';

    $userStmt = $pdo->prepare($userSql);
    $userStmt->execute($userParams);

    return (bool)$userStmt->fetch(PDO::FETCH_ASSOC);
}

function stsnAssertStudentEmailAvailable(PDO $pdo, string $email, int $excludeStudentId = 0, int $excludeUserId = 0): void
{
    if ($email === '') {
        return;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Student email address is invalid.');
    }

    if (stsnStudentEmailExists($pdo, $email, $excludeStudentId, $excludeUserId)) {
        throw new Exception('This email address already has an existing account.');
    }
}

function stsnCreateLinkedAccount(PDO $pdo, int $roleId, int $referenceId, string $username, string $temporaryPassword): int
{
    $existing = $pdo->prepare('
        SELECT id, username, status
        FROM tblusers
        WHERE role_id = ? AND reference_id = ?
        LIMIT 1
    ');
    $existing->execute([$roleId, $referenceId]);
    $account = $existing->fetch(PDO::FETCH_ASSOC);
    if ($account) {
        throw new Exception('Account already exists for this user. Existing username: ' . $account['username'] . '.');
    }

    $hash = password_hash($temporaryPassword, PASSWORD_DEFAULT);
    $insert = $pdo->prepare('
        INSERT INTO tblusers (username, password_hash, role_id, reference_id, status, must_change_password)
        VALUES (?, ?, ?, ?, \'Active\', 1)
    ');
    $insert->execute([$username, $hash, $roleId, $referenceId]);

    return (int)$pdo->lastInsertId();
}

function stsnCreateTeacherAccount(PDO $pdo, int $teacherId, array $teacher): array
{
    $email = trim((string)($teacher['email'] ?? ''));
    stsnAssertTeacherEmailAvailable($pdo, $email, $teacherId);

    $username = $email;
    $temporaryPassword = stsnGenerateTeacherTemporaryPassword($teacher);
    $accountId = stsnCreateLinkedAccount($pdo, 2, $teacherId, $username, $temporaryPassword);

    return [
        'account_id' => $accountId,
        'username' => $username,
        'temporary_password' => $temporaryPassword,
        'email' => $email,
        'full_name' => stsnFullName($teacher),
    ];
}

function stsnCreateStudentAccount(PDO $pdo, int $studentId, array $student): array
{
    $email = trim((string)($student['email'] ?? ''));
    stsnValidateCredentialEmail($email, 'Student');
    stsnAssertStudentEmailAvailable($pdo, $email, $studentId);

    $username = $email;
    $temporaryPassword = stsnGenerateTemporaryPassword();
    $accountId = stsnCreateLinkedAccount($pdo, 3, $studentId, $username, $temporaryPassword);

    return [
        'account_id' => $accountId,
        'username' => $username,
        'temporary_password' => $temporaryPassword,
        'email' => $email,
        'full_name' => stsnFullName($student),
    ];
}

function stsnCredentialsEmailBody(string $fullName, string $username, string $temporaryPassword, string $loginUrl): array
{
    $safeName = htmlspecialchars($fullName, ENT_QUOTES, 'UTF-8');
    $safeUsername = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');
    $safePassword = htmlspecialchars($temporaryPassword, ENT_QUOTES, 'UTF-8');
    $safeLoginUrl = htmlspecialchars($loginUrl, ENT_QUOTES, 'UTF-8');

    $html = <<<HTML
<!doctype html>
<html lang="en">
<body style="margin:0;padding:0;background:#f3f4f6;font-family:Segoe UI,Arial,sans-serif;color:#1f2937;">
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="width:100%;background:#f3f4f6;">
        <tr>
            <td align="center" style="padding:24px 12px;">
                <table role="presentation" width="600" cellspacing="0" cellpadding="0" border="0" style="width:100%;max-width:600px;background:#ffffff;">
                    <tr>
                        <td style="padding:30px;background-color:#800000;background-image:linear-gradient(rgba(128,0,0,.82),rgba(86,0,0,.88)),url(cid:stsn-school-photo);background-position:center;background-size:cover;color:#ffffff;">
                            <div style="width:58px;height:58px;padding:6px;border-radius:50%;background:#ffffff;">
                                <img src="cid:stsn-school-logo" width="58" height="58" alt="St. Theresa's National School logo" style="display:block;width:58px;height:58px;border:0;">
                            </div>
                            <div style="margin-top:16px;font-size:18px;font-weight:700;line-height:1.35;">St. Theresa's School of Novaliches, Inc.</div>
                            <div style="margin-top:18px;font-size:24px;font-weight:700;line-height:1.25;">Welcome to STSN Grading System</div>
                            <div style="margin-top:8px;font-size:16px;line-height:1.5;color:#dbeafe;">Your account is ready!</div>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:38px 30px 32px;">
                            <p style="margin:0 0 22px;font-size:16px;font-weight:600;line-height:1.5;">Hello {$safeName},</p>
                            <p style="margin:0 0 28px;font-size:14px;line-height:1.6;color:#4b5563;">Your STSN Grading System account has been created successfully.</p>

                            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="width:100%;background:#f3f4f6;border:1px solid #e5e7eb;border-radius:12px;">
                                <tr>
                                    <td style="padding:22px 24px;">
                                        <div style="margin-bottom:18px;font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#6b7280;"><img src="cid:stsn-envelope-icon" width="14" height="14" alt="" style="display:inline-block;width:14px;height:14px;vertical-align:-2px;border:0;">&nbsp; Email</div>
                                        <div style="margin-bottom:20px;font-size:14px;line-height:1.5;color:#1f2937;word-break:break-word;">{$safeUsername}</div>
                                        <div style="margin-bottom:8px;font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#6b7280;"><img src="cid:stsn-lock-icon" width="14" height="14" alt="" style="display:inline-block;width:14px;height:14px;vertical-align:-2px;border:0;">&nbsp; Temporary Password</div>
                                        <div style="margin-bottom:20px;font-family:Courier New,monospace;font-size:14px;line-height:1.5;color:#1f2937;word-break:break-all;">{$safePassword}</div>
                                    </td>
                                </tr>
                            </table>

                            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="width:100%;margin-top:22px;background:#f5e6e8;border-radius:8px;">
                                <tr>
                                    <td style="padding:14px 16px;font-size:13px;font-weight:500;line-height:1.6;color:#6b1f2a;"><img src="cid:stsn-lock-icon" width="14" height="14" alt="" style="display:inline-block;width:14px;height:14px;vertical-align:-2px;border:0;">&nbsp; For your security, please change your password after your first login.</td>
                                </tr>
                            </table>

                            <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="margin:28px auto 18px;">
                                <tr>
                                    <td align="center" style="border-radius:8px;background:#800000;">
                                        <a href="{$safeLoginUrl}" style="display:inline-block;padding:14px 32px;border-radius:8px;color:#ffffff;font-size:14px;font-weight:700;text-decoration:none;">Login to Your Account</a>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
HTML;

    $text = "Hello {$fullName},\n\n"
        . "Your STSN Grading System account has been created successfully.\n\n"
        . "Login Details:\n\n"
        . "Email: {$username}\n"
        . "Temporary Password: {$temporaryPassword}\n"
        . "For your security, please change your password after your first login.\n\n"
        . "Thank you,\nSTSN Grading System Administrator";

    return [$html, $text];
}

function stsnSendCredentialsEmail(string $email, string $fullName, string $username, string $temporaryPassword): bool
{
    $loginUrl = stsnLoginUrl();
    [$html, $text] = stsnCredentialsEmailBody($fullName, $username, $temporaryPassword, $loginUrl);

    $mail = createMailer();
    $mail->addAddress($email, $fullName);
    $logoPath = dirname(__DIR__, 2) . '/assets/img/stsn logo.png';
    if (is_file($logoPath)) {
        $mail->addEmbeddedImage($logoPath, 'stsn-school-logo', 'stsn-logo.png', 'base64', 'image/png');
    }
    $schoolPhotoPath = dirname(__DIR__, 2) . '/assets/img/stsnschool.jpg';
    if (is_file($schoolPhotoPath)) {
        $mail->addEmbeddedImage($schoolPhotoPath, 'stsn-school-photo', 'stsnschool.jpg', 'base64', 'image/jpeg');
    }
    $envelopeIconPath = dirname(__DIR__, 2) . '/assets/img/email-envelope.svg';
    if (is_file($envelopeIconPath)) {
        $mail->addEmbeddedImage($envelopeIconPath, 'stsn-envelope-icon', 'email-envelope.svg', 'base64', 'image/svg+xml');
    }
    $lockIconPath = dirname(__DIR__, 2) . '/assets/img/email-lock.svg';
    if (is_file($lockIconPath)) {
        $mail->addEmbeddedImage($lockIconPath, 'stsn-lock-icon', 'email-lock.svg', 'base64', 'image/svg+xml');
    }
    $mail->Subject = 'Your STSN Grading System Account Has Been Created';
    $mail->Body = $html;
    $mail->AltBody = $text;

    return (bool)$mail->send();
}

function stsnResendCredentials(PDO $pdo, int $accountId, int $roleId): array
{
    $join = $roleId === 2
        ? 'JOIN tblteacher p ON p.id = u.reference_id'
        : 'JOIN tblstudents p ON p.id = u.reference_id';

    $stmt = $pdo->prepare("
        SELECT u.id, u.username, u.reference_id, p.fname, p.mname, p.lname, p.email, p.date_hired
        FROM tblusers u
        {$join}
        WHERE u.id = ? AND u.role_id = ?
        LIMIT 1
    ");
    $stmt->execute([$accountId, $roleId]);
    $account = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$account) {
        throw new Exception($roleId === 2 ? 'Teacher account not found.' : 'Student mobile account not found.');
    }

    $email = trim((string)($account['email'] ?? ''));
    stsnValidateCredentialEmail($email, $roleId === 2 ? 'Teacher' : 'Student');

    $username = (string)$account['username'];
    if ($roleId === 2) {
        stsnAssertTeacherEmailAvailable($pdo, $email, (int)$account['reference_id'], (int)$account['id'], 'This email address is already assigned to another account.');
        $username = $email;
    } elseif ($roleId === 3) {
        stsnAssertStudentEmailAvailable($pdo, $email, (int)$account['reference_id'], (int)$account['id']);
        $username = $email;
    }

    $temporaryPassword = $roleId === 2
        ? stsnGenerateTeacherTemporaryPassword($account)
        : stsnGenerateTemporaryPassword();
    $hash = password_hash($temporaryPassword, PASSWORD_DEFAULT);
    $update = $pdo->prepare('UPDATE tblusers SET username = ?, password_hash = ?, must_change_password = 1 WHERE id = ? AND role_id = ?');
    $update->execute([$username, $hash, $accountId, $roleId]);

    $fullName = stsnFullName($account);
    $emailSent = false;
    try {
        $emailSent = stsnSendCredentialsEmail($email, $fullName, $username, $temporaryPassword);
    } catch (Throwable $e) {
        $emailSent = false;
    }

    return [
        'username' => $username,
        'email' => $email,
        'email_sent' => $emailSent,
    ];
}
