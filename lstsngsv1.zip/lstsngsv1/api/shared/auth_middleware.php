<?php
// ── auth_middleware.php ───────────────────────────────────────────────────────
// Include this at the top of any protected API endpoint.
// Usage: require_once __DIR__ . '/../shared/auth_middleware.php';
// Returns $authUserId and $authStudentId if valid.

require_once __DIR__ . '/db_connect.php';

function validateToken(PDO $pdo): array {
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';

    $token = '';
    if (str_starts_with($authHeader, 'Bearer ')) {
        $token = trim(substr($authHeader, 7));
    }

    if (!$token) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Unauthorized. No token provided.']);
        exit;
    }

    $stmt = $pdo->prepare("
        SELECT id, reference_id FROM tblusers
        WHERE token = ? AND token_expires > NOW() AND status = 'Active' AND role_id = 3
    ");
    $stmt->execute([$token]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Unauthorized. Invalid or expired token.']);
        exit;
    }

    return [
        'user_id'    => (int) $user['id'],
        'student_id' => (int) $user['reference_id'],
    ];
}

$auth = validateToken($pdo);
$authUserId    = $auth['user_id'];
$authStudentId = $auth['student_id'];