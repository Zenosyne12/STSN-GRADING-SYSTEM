<?php
date_default_timezone_set('Asia/Manila');

$host = '127.0.0.1';
$db   = 'dbstsn';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$db;charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
    $pdo->exec("SET time_zone = '+08:00'");
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}

// Auto-include activity log helper
require_once __DIR__ . '/../../includes/activity_log.php';

// Ensure a session exists so logActivity() can attribute the current user
if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
    session_start();
}
?>
