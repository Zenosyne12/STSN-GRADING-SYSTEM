<?php

function ensureGradeWorkflowSchema(PDO $pdo): void
{
    $gradeColumn = $pdo->query("SHOW COLUMNS FROM tblgrades LIKE 'status'")->fetch(PDO::FETCH_ASSOC);
    if ($gradeColumn && !str_contains((string)$gradeColumn['Type'], 'submitted_to_adviser')) {
        $pdo->exec("
            ALTER TABLE tblgrades
            MODIFY status ENUM(
                'draft',
                'pending_adviser',
                'submitted_to_adviser',
                'approved',
                'approved_by_adviser',
                'finalized',
                'returned'
            ) NOT NULL DEFAULT 'draft'
        ");
    }

    $adviserColumn = $pdo->query("SHOW COLUMNS FROM tbladviser_submissions LIKE 'status'")->fetch(PDO::FETCH_ASSOC);
    if ($adviserColumn && !str_contains((string)$adviserColumn['Type'], 'finalized')) {
        $pdo->exec("
            ALTER TABLE tbladviser_submissions
            MODIFY status ENUM('pending','approved','finalized','returned') NOT NULL DEFAULT 'pending'
        ");
    }
}

function officialGradeStatusSql(string $alias = 'g'): string
{
    return "{$alias}.status IN ('approved', 'approved_by_adviser', 'finalized')";
}

function reviewableGradeStatusSql(string $alias = 'g'): string
{
    return "{$alias}.status IN ('pending_adviser', 'submitted_to_adviser', 'approved', 'approved_by_adviser', 'finalized')";
}

function officialAdviserSubmissionSql(string $alias = 'ads'): string
{
    return "{$alias}.status IN ('approved', 'finalized')";
}

function officialGradeExistsSql(string $gradeAlias = 'g'): string
{
    return "
        " . officialGradeStatusSql($gradeAlias) . "
        AND EXISTS (
            SELECT 1
            FROM tblacademicyear ayv
            INNER JOIN tbladviser_submissions ads_v
                ON ads_v.school_year = ayv.year_label
               AND ads_v.section_id = {$gradeAlias}.section_id
               AND ads_v.quarter = {$gradeAlias}.quarter
               AND " . officialAdviserSubmissionSql('ads_v') . "
            WHERE ayv.id = {$gradeAlias}.academic_year_id
        )
        AND EXISTS (
            SELECT 1
            FROM tblworkflow_instance wfi
            INNER JOIN tblconfig_terms term
                ON term.id = wfi.term_id
               AND term.term_number = {$gradeAlias}.quarter
            WHERE wfi.section_id = {$gradeAlias}.section_id
              AND wfi.subject_id = {$gradeAlias}.subject_id
              AND wfi.teacher_id = {$gradeAlias}.teacher_id
              AND wfi.academic_year_id = {$gradeAlias}.academic_year_id
              AND wfi.status = 'COMPLETED'
              AND wfi.id = (
                  SELECT MAX(wfi_latest.id)
                  FROM tblworkflow_instance wfi_latest
                  WHERE wfi_latest.section_id = wfi.section_id
                    AND wfi_latest.subject_id = wfi.subject_id
                    AND wfi_latest.term_id = wfi.term_id
                    AND wfi_latest.academic_year_id = wfi.academic_year_id
              )
        )
    ";
}

function gradeWorkflowLabel(?string $status, bool $hasTeacherSubmission, bool $hasGradeRow): string
{
    $status = (string)($status ?? '');
    if (!$hasGradeRow) {
        return 'No Grades Yet';
    }
    if (in_array($status, ['draft', 'returned'], true)) {
        return 'Draft Only';
    }
    if (!$hasTeacherSubmission || in_array($status, ['pending_adviser', 'submitted_to_adviser'], true)) {
        return 'Pending Submission';
    }
    return 'Submitted';
}
