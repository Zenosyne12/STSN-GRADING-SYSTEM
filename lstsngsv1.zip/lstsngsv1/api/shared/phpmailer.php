<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../../vendor/autoload.php';

function createMailer() {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com'; 
    $mail->SMTPAuth = true;
    $mail->Username = 'hechanova919@gmail.com'; // EMAIL USED 
    $mail->Password = 'rbjslxdcytllregd'; // GOOGLE PASSWORD HERE
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;
    $mail->Timeout = 12;
    $mail->SMTPKeepAlive = false;
    $mail->CharSet = 'UTF-8';
    $mail->SMTPAutoTLS = true;
    // Common fix for local Windows/XAMPP OpenSSL CA chain issues.
    $mail->SMTPOptions = [
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true,
        ],
    ];
    // Gmail SMTP usually rejects messages when From does not match the authenticated account.
    $mail->setFrom($mail->Username, 'STSN Grading System');
    $mail->addReplyTo($mail->Username, 'STSN Grading System');
    $mail->isHTML(true);
    return $mail;
}
?>