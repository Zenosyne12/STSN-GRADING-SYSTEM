<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json');

$connect_path = __DIR__ . '/../shared/db_connect.php';
if (!file_exists($connect_path)) {
    echo json_encode([
        'success' => false,
        'error' => 'db_connect.php not found'
    ]);
    exit;
}

require_once $connect_path;

if (!isset($pdo) || $pdo === null) {
    echo json_encode([
        'success' => false,
        'error' => 'Database connection failed'
    ]);
    exit;
}

try {
    $stmt = $pdo->prepare("
        SELECT
            id,
            teacher_id,
            fname,
            mname,
            lname,
            email,
            date_hired
        FROM tblteacher
        WHERE is_active = 1
        ORDER BY lname ASC, fname ASC, teacher_id ASC
    ");
    $stmt->execute();
    $teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $result = [];
    foreach ($teachers as $teacher) {
        $middle = '';
        if (!empty($teacher['mname'])) {
            $middle = ' ' . strtoupper(substr($teacher['mname'], 0, 1)) . '.';
        }

        $fullName = trim($teacher['fname'] . $middle . ' ' . $teacher['lname']);

        $result[] = [
            'id' => $teacher['id'],
            'teacher_id' => $teacher['teacher_id'],
            'fname' => $teacher['fname'],
            'mname' => $teacher['mname'],
            'lname' => $teacher['lname'],
            'full_name' => $fullName,
            'email' => $teacher['email'],
            'date_hired' => $teacher['date_hired']
        ];
    }

    echo json_encode([
        'success' => true,
        'teachers' => $result
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Query failed: ' . $e->getMessage()
    ]);
}
?>