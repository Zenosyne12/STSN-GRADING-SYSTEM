<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

function resolveTable(PDO $pdo, array $candidates): ?string
{
    $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN) ?: [];
    $map = [];

    foreach ($tables as $table) {
        $map[strtolower($table)] = $table;
    }

    foreach ($candidates as $candidate) {
        $key = strtolower($candidate);
        if (isset($map[$key])) {
            return $map[$key];
        }
    }

    return null;
}

function hasColumn(PDO $pdo, string $table, string $column): bool
{
    $stmt = $pdo->prepare("SHOW COLUMNS FROM `{$table}` LIKE ?");
    $stmt->execute([$column]);
    return (bool) $stmt->fetch(PDO::FETCH_ASSOC);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$in = json_decode(file_get_contents('php://input'), true);

if (empty($in['id']) || !isset($in['status'])) {
    echo json_encode(['success' => false, 'error' => 'Missing id or status']);
    exit;
}

$id = (int) $in['id'];
$status = ($in['status'] === 'Active') ? 'Active' : 'Inactive';
try {
    $check = $pdo->prepare("
        SELECT id, role_id, reference_id, status
        FROM tblusers
        WHERE id = ?
        LIMIT 1
    ");
    $check->execute([$id]);
    $user = $check->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode(['success' => false, 'error' => 'Account not found']);
        exit;
    }

    if ((int) ($user['role_id'] ?? 0) !== 2) {
        echo json_encode(['success' => false, 'error' => 'Only teacher accounts can be updated here']);
        exit;
    }

    $updateUser = $pdo->prepare("UPDATE tblusers SET status = ? WHERE id = ?");
    $updateUser->execute([$status, $id]);

    echo json_encode([
        'success' => true,
        'message' => $status === 'Inactive'
            ? 'Account disabled successfully.'
            : 'Account enabled successfully.'
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'DB error: ' . $e->getMessage()
    ]);
}
