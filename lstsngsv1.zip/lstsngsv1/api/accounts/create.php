<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../../api/shared/db_connect.php';
require_once __DIR__ . '/../../api/shared/phpmailer.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (empty($data['teacher_db_id']) || empty($data['username'])) {
    echo json_encode(['success' => false, 'error' => 'Missing required data']);
    exit;
}

$teacherDbId = (int) $data['teacher_db_id'];
$username = trim((string) $data['username']);

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("
        SELECT id, teacher_id, fname, lname, date_hired, email, is_active
        FROM tblteacher
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->execute([$teacherDbId]);
    $teacher = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$teacher) {
        throw new Exception('Teacher not found.');
    }

    if ((int) ($teacher['is_active'] ?? 0) !== 1) {
        throw new Exception('Cannot create an account for an inactive teacher.');
    }

    if (empty($teacher['email'])) {
        throw new Exception('Teacher has no email address.');
    }

    $checkExistingTeacherAccount = $pdo->prepare("
        SELECT id, username, status
        FROM tblusers
        WHERE role_id = 2 AND reference_id = ?
        LIMIT 1
    ");
    $checkExistingTeacherAccount->execute([$teacherDbId]);
    $existingTeacherAccount = $checkExistingTeacherAccount->fetch(PDO::FETCH_ASSOC);

    if ($existingTeacherAccount) {
        $status = $existingTeacherAccount['status'] ?? 'Inactive';
        throw new Exception(
            'Account already exists for this teacher. Existing username: ' .
            $existingTeacherAccount['username'] .
            ' (' . $status . '). Reactivate the existing account instead.'
        );
    }

    $checkUsername = $pdo->prepare("SELECT id FROM tblusers WHERE username = ? LIMIT 1");
    $checkUsername->execute([$username]);

    if ($checkUsername->fetch()) {
        throw new Exception('Username already exists.');
    }

    $tempPassword = strtolower(str_replace(' ', '', (string) $teacher['lname'])) .
        str_replace('-', '', (string) $teacher['date_hired']);
    $passwordHash = password_hash($tempPassword, PASSWORD_DEFAULT);

    $insert = $pdo->prepare("
        INSERT INTO tblusers (username, password_hash, role_id, reference_id, status, must_change_password)
        VALUES (?, ?, 2, ?, 'Active', 1)
    ");
    $insert->execute([$username, $passwordHash, $teacherDbId]);

    $mail = createMailer();
    $mail->addAddress($teacher['email'], trim(($teacher['fname'] ?? '') . ' ' . ($teacher['lname'] ?? '')));
    $mail->Subject = 'STSN Grading System - Account Created';
    $mail->Body = "
        <html>
        <body style='font-family: Arial, sans-serif; padding: 20px;'>
            <h2 style='color: #2c3e50;'>Welcome to STSN Grading System</h2>
            <p>Hello {$teacher['fname']},</p>
            <p>Your account has been successfully created. Please use the following credentials to log in:</p>
            <div style='background: #f8f9fa; padding: 15px; border-left: 4px solid #007bff; margin: 20px 0;'>
                <p style='margin: 0;'><strong>Username:</strong> {$username}</p>
                <p style='margin: 0;'><strong>Temporary Password:</strong> {$tempPassword}</p>
            </div>
            <p>Please change your password after your first login.</p>
            <p>Best regards,<br>STSN Administration</p>
        </body>
        </html>
    ";
    $mail->AltBody = "Hello {$teacher['fname']},\n\nUsername: {$username}\nTemporary Password: {$tempPassword}\n\nPlease change your password after your first login.\n\nSTSN Administration";

    if (!$mail->send()) {
        throw new Exception('Account created but email failed: ' . $mail->ErrorInfo);
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'username' => $username,
        'message' => 'Account created. Temporary password sent to ' . $teacher['email']
    ]);
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}