<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/account_credentials.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$payload = json_decode(file_get_contents('php://input'), true);
$id = (int)($payload['id'] ?? 0);

if ($id <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid account ID']);
    exit;
}

try {
    $result = stsnResendCredentials($pdo, $id, 2);

    echo json_encode([
        'success' => true,
        'email_sent' => $result['email_sent'],
        'message' => $result['email_sent']
            ? 'Credentials sent to ' . $result['email'] . '.'
            : 'Account created successfully, but email sending failed. Please resend credentials.',
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
