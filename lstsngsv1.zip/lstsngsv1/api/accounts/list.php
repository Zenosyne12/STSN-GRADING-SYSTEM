<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

function resolveTable(PDO $pdo, array $candidates): ?string
{
    $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN) ?: [];
    $map = [];

    foreach ($tables as $table) {
        $map[strtolower($table)] = $table;
    }

    foreach ($candidates as $candidate) {
        $key = strtolower($candidate);
        if (isset($map[$key])) {
            return $map[$key];
        }
    }

    return null;
}

function hasColumn(PDO $pdo, string $table, string $column): bool
{
    $stmt = $pdo->prepare("SHOW COLUMNS FROM `{$table}` LIKE ?");
    $stmt->execute([$column]);
    return (bool) $stmt->fetch(PDO::FETCH_ASSOC);
}

try {
    $page = isset($_GET['p']) ? max(1, (int) $_GET['p']) : 1;
    $search = trim($_GET['s'] ?? '');
    $perPage = 5;
    $offset = ($page - 1) * $perPage;

    $teacherTable = resolveTable($pdo, ['tblteacher', 'tblTeacher']);
    if (!$teacherTable) {
        throw new Exception('Teacher table not found.');
    }

    $hasTeacherActive = hasColumn($pdo, $teacherTable, 'is_active');
    $hasTeacherArchived = hasColumn($pdo, $teacherTable, 'is_archived');

    $where = [];
    $params = [];

    $where[] = "u.role_id = 2";
    $where[] = "LOWER(COALESCE(u.username, '')) <> 'admin'";
    $where[] = "LOWER(COALESCE(u.status, '')) = 'active'";

    if ($hasTeacherActive) {
        $where[] = "COALESCE(t.is_active, 1) = 1";
    }

    if ($hasTeacherArchived) {
        $where[] = "COALESCE(t.is_archived, 0) = 0";
    }

    if ($search !== '') {
        $where[] = "(
            COALESCE(t.teacher_id, '') LIKE ?
            OR COALESCE(u.username, '') LIKE ?
            OR COALESCE(t.email, '') LIKE ?
            OR CONCAT(
                COALESCE(t.fname, ''), ' ',
                COALESCE(t.mname, ''), ' ',
                COALESCE(t.lname, '')
            ) LIKE ?
        )";

        $like = '%' . $search . '%';
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
    }

    $whereSql = implode(' AND ', $where);

    $countSql = "
        SELECT COUNT(*)
        FROM tblusers u
        LEFT JOIN `{$teacherTable}` t ON t.id = u.reference_id
        WHERE {$whereSql}
    ";
    $countStmt = $pdo->prepare($countSql);
    $countStmt->execute($params);
    $total = (int) $countStmt->fetchColumn();

    $pages = max(1, (int) ceil($total / $perPage));

    if ($page > $pages) {
        $page = $pages;
        $offset = ($page - 1) * $perPage;
    }

    $dataSql = "
        SELECT
            u.id,
            u.reference_id,
            u.username,
            u.role_id,
            u.status,
            u.must_change_password,
            u.created_at,
            t.teacher_id,
            t.fname,
            t.mname,
            t.lname,
            t.email,
            " . ($hasTeacherActive ? "t.is_active" : "1 AS is_active") . "
        FROM tblusers u
        LEFT JOIN `{$teacherTable}` t ON t.id = u.reference_id
        WHERE {$whereSql}
        ORDER BY
            COALESCE(t.lname, '') ASC,
            COALESCE(t.fname, '') ASC,
            u.id DESC
        LIMIT {$perPage} OFFSET {$offset}
    ";

    $dataStmt = $pdo->prepare($dataSql);
    $dataStmt->execute($params);
    $rows = $dataStmt->fetchAll(PDO::FETCH_ASSOC);

    $accounts = array_map(function ($row) {
        $fullName = trim(
            ($row['lname'] ?? '') .
            ((($row['lname'] ?? '') !== '' && ($row['fname'] ?? '') !== '') ? ', ' : '') .
            ($row['fname'] ?? '') .
            ((($row['mname'] ?? '') !== '') ? ' ' . $row['mname'] : '')
        );

        return [
            'id' => (int) ($row['id'] ?? 0),
            'reference_id' => $row['reference_id'] ?? null,
            'teacher_id' => $row['teacher_id'] ?? '',
            'name' => $fullName !== '' ? $fullName : 'N/A',
            'username' => $row['username'] ?? '',
            'role' => 'Teacher',
            'role_id' => (int) ($row['role_id'] ?? 2),
            'must_change_password' => isset($row['must_change_password']) ? (int) $row['must_change_password'] : null,
            'status' => $row['status'] ?? 'Active',
            'created' => $row['created_at'] ?? '',
            'created_at' => $row['created_at'] ?? ''
        ];
    }, $rows);

    echo json_encode([
        'success' => true,
        'data' => $accounts,
        'accounts' => $accounts,
        'total' => $total,
        'page' => $page,
        'pages' => $pages
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}