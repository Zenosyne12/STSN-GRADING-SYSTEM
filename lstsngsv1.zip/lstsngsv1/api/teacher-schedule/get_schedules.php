<?php
session_start();
header('Content-Type: application/json');
error_reporting(0);
ini_set('display_errors', 0);

// Check if db_connect exists (note: your file is named db_connecr.php)
$dbPath = __DIR__ . '/../shared/db_connecr.php';
if (!file_exists($dbPath)) {
    $dbPath = __DIR__ . '/../shared/db_connect.php';
}

if (!file_exists($dbPath)) {
    echo json_encode(['success' => false, 'message' => 'Database configuration not found']);
    exit;
}

require_once $dbPath;

$teacherId = $_SESSION['teacher_id'] ?? null;
$sectionId = $_GET['section_id'] ?? null;
$subjectId = $_GET['subject_id'] ?? null;

if (!$teacherId) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

if (!$sectionId || !$subjectId) {
    echo json_encode(['success' => false, 'message' => 'Missing section_id or subject_id']);
    exit;
}

try {
    $checkTable = $pdo->query("SHOW TABLES LIKE 'tblschedule'");
    if ($checkTable->rowCount() === 0) {
        echo json_encode(['success' => false, 'message' => 'Schedule table (tblschedule) not found']);
        exit;
    }

    $infoStmt = $pdo->prepare("
        SELECT s.section_name, sub.subject_name 
        FROM tblsection s
        JOIN tblsubjects sub ON sub.id = ?
        WHERE s.id = ?
    ");
    $infoStmt->execute([$subjectId, $sectionId]);
    $info = $infoStmt->fetch(PDO::FETCH_ASSOC);

    $stmt = $pdo->prepare("
        SELECT * FROM tblschedule 
        WHERE section_id = ? AND subject_id = ? AND teacher_id = ?
        ORDER BY FIELD(day_name, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'), time_start
    ");
    $stmt->execute([$sectionId, $subjectId, $teacherId]);
    $schedules = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'data' => $schedules,
        'section' => $info['section_name'] ?? null,
        'subject' => $info['subject_name'] ?? null
    ]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>