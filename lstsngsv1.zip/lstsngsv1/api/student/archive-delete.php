<?php
/**
 * api/student/archive-delete.php
 * Permanently deletes a record from tblstudent_archive.
 *
 * POST body (JSON):
 * { "id": 5 }   <- tblstudent_archive.id
 */
ob_start();
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
ob_end_clean();

header('Content-Type: application/json');

$data      = json_decode(file_get_contents('php://input'), true);
$archiveId = intval($data['id'] ?? 0);

if (!$archiveId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Archive ID is required.']);
    exit;
}

try {
    $stmt = $pdo->prepare("DELETE FROM tblstudent_archive WHERE id = ?");
    $stmt->execute([$archiveId]);

    if ($stmt->rowCount() === 0) {
        throw new Exception('Archive record not found or already deleted.');
    }

    echo json_encode(['success' => true, 'message' => 'Archived record permanently deleted.']);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}