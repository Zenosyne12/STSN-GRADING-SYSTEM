<?php
require_once '../../includes/auth.php';
requireAdmin();

header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="student_import_template.xls"');
header('Cache-Control: max-age=0');
header('Pragma: public');

$columns = [
    ['db' => 'lrn', 'header' => 'LRN', 'width' => 120, 'example' => '123456789012', 'required' => true, 'hint' => '12 digits'],
    ['db' => 'grade_level_id', 'header' => 'Grade Level ID', 'width' => 100, 'example' => '1', 'required' => true, 'hint' => 'See lookup'],
    ['db' => 'fname', 'header' => 'First Name', 'width' => 120, 'example' => 'Juan', 'required' => true, 'hint' => ''],
    ['db' => 'mname', 'header' => 'Middle Name', 'width' => 120, 'example' => 'Dela', 'required' => false, 'hint' => 'Optional'],
    ['db' => 'lname', 'header' => 'Last Name', 'width' => 120, 'example' => 'Cruz', 'required' => true, 'hint' => ''],
    ['db' => 'birthdate', 'header' => 'Birthdate', 'width' => 100, 'example' => '2010-05-15', 'required' => true, 'hint' => 'YYYY-MM-DD'],
    ['db' => 'gender', 'header' => 'Gender', 'width' => 80, 'example' => 'Male', 'required' => true, 'hint' => 'Male/Female'],
    ['db' => 'citizenship', 'header' => 'Citizenship', 'width' => 100, 'example' => 'Filipino', 'required' => false, 'hint' => ''],
    ['db' => 'fathers_name', 'header' => 'Father Name', 'width' => 150, 'example' => 'Jose Cruz', 'required' => false, 'hint' => ''],
    ['db' => 'fathers_contact_num', 'header' => 'Father Contact', 'width' => 120, 'example' => '09171234567', 'required' => false, 'hint' => '09#########'],
    ['db' => 'mothers_name', 'header' => 'Mother Name', 'width' => 150, 'example' => 'Maria Cruz', 'required' => false, 'hint' => ''],
    ['db' => 'mothers_contact_num', 'header' => 'Mother Contact', 'width' => 120, 'example' => '09179876543', 'required' => false, 'hint' => '09#########'],
    ['db' => 'guardian_name', 'header' => 'Guardian Name', 'width' => 150, 'example' => 'Jose Cruz', 'required' => false, 'hint' => ''],
    ['db' => 'guardian_contact_num', 'header' => 'Guardian Contact', 'width' => 120, 'example' => '09171234567', 'required' => false, 'hint' => '09#########'],
    ['db' => 'street_name', 'header' => 'Street Name', 'width' => 200, 'example' => '123 Main St.', 'required' => false, 'hint' => ''],
    ['db' => 'country_id', 'header' => 'Country ID', 'width' => 80, 'example' => '1', 'required' => false, 'hint' => 'See lookup'],
    ['db' => 'region_id', 'header' => 'Region ID', 'width' => 80, 'example' => '1', 'required' => false, 'hint' => 'See lookup'],
    ['db' => 'province_id', 'header' => 'Province ID', 'width' => 80, 'example' => '1', 'required' => false, 'hint' => 'See lookup'],
    ['db' => 'city_id', 'header' => 'City ID', 'width' => 80, 'example' => '1', 'required' => false, 'hint' => 'See lookup'],
    ['db' => 'barangay_id', 'header' => 'Barangay ID', 'width' => 80, 'example' => '1', 'required' => false, 'hint' => 'See lookup'],
    ['db' => 'postal_code', 'header' => 'Postal Code', 'width' => 100, 'example' => '1100', 'required' => false, 'hint' => ''],
    ['db' => 'strand', 'header' => 'Strand', 'width' => 100, 'example' => '', 'required' => false, 'hint' => 'Grade 11-12 only'],
    ['db' => 'is_active', 'header' => 'Is Active', 'width' => 80, 'example' => '1', 'required' => false, 'hint' => '1=Active, 0=Inactive'],
];
?>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<meta charset="UTF-8">
<style>
    body { font-family: Calibri, Arial, sans-serif; }
    table { border-collapse: collapse; width: 100%; }
    .title { background-color: #1248a8; color: #ffffff; font-size: 16px; font-weight: bold; text-align: center; padding: 12px; border: 1px solid #0f3d90; }
    .warning { background-color: #fff0f0; color: #c0392b; font-size: 11px; font-weight: bold; text-align: center; padding: 10px; border: 2px solid #f7b8b8; }
    .instructions { background-color: #f9fbff; color: #1a6ef5; font-size: 10px; font-style: italic; padding: 8px; text-align: left; border: 1px solid #e8f0fb; }
    .header { background-color: #1248a8; color: #ffffff; font-weight: bold; font-size: 11px; text-align: center; vertical-align: middle; padding: 8px 5px; border: 1px solid #0f3d90; mso-number-format: "\@"; }
    .header.req { background-color: #c0392b; border: 1px solid #a93226; }
    .example { background-color: #e6f7ed; color: #0a6b47; font-style: italic; font-size: 11px; padding: 6px 5px; border: 1px solid #a0dfc8; mso-number-format: "\@"; }
    .hint { background-color: #fff8e6; color: #a46a00; font-size: 9px; font-style: italic; padding: 4px 5px; border: 1px solid #ffe4b3; mso-number-format: "\@"; }
    .data { background-color: #ffffff; font-size: 11px; padding: 6px 5px; border: 1px solid #dce8f8; height: 22px; mso-number-format: "\@"; }
    .lookup-title { background-color: #27ae60; color: #ffffff; font-size: 14px; font-weight: bold; text-align: center; padding: 10px; border: 1px solid #1e8449; }
    .lookup-header { background-color: #27ae60; color: #ffffff; font-weight: bold; font-size: 11px; text-align: center; padding: 6px; border: 1px solid #1e8449; }
    .lookup-cell { font-size: 11px; padding: 5px; border: 1px solid #a9dfbf; text-align: center; mso-number-format: "\@"; }
    .lookup-name { text-align: left; padding-left: 10px; }
    .section-title { background-color: #d5f5e3; color: #1e8449; font-weight: bold; font-size: 12px; padding: 8px; text-align: left; border: 1px solid #a9dfbf; }
</style>
</head>
<body>
<table>
    <tr><td colspan="<?php echo count($columns); ?>" class="title">STUDENT IMPORT TEMPLATE</td></tr>
    <tr><td colspan="<?php echo count($columns); ?>" class="warning">IMPORTANT: Grade Level, Country, Region, Province, City, and Barangay columns use ID numbers (not names). Refer to the LOOKUP SHEET below for correct ID values.</td></tr>
    <tr><td colspan="<?php echo count($columns); ?>" class="instructions">How to use: Fill in student data starting from row 5. Red headers are REQUIRED. Yellow hints show data format. Example row shows correct format. Do not modify header row order.</td></tr>
    <tr>
        <?php foreach ($columns as $col): ?>
            <td class="header <?php echo $col['required'] ? 'req' : ''; ?>" style="width:<?php echo $col['width']; ?>px;">
                <?php echo htmlspecialchars($col['header']); ?>
                <?php if ($col['required']): ?><br><small style="font-size:8px;">(REQUIRED)</small><?php endif; ?>
            </td>
        <?php endforeach; ?>
    </tr>
    <tr>
        <?php foreach ($columns as $col): ?>
            <td class="example"><?php echo htmlspecialchars($col['example']); ?></td>
        <?php endforeach; ?>
    </tr>
    <tr>
        <?php foreach ($columns as $col): ?>
            <td class="hint"><?php echo htmlspecialchars($col['hint']); ?></td>
        <?php endforeach; ?>
    </tr>
    <?php for ($r = 0; $r < 100; $r++): ?>
    <tr><?php foreach ($columns as $col): ?><td class="data">&nbsp;</td><?php endforeach; ?></tr>
    <?php endfor; ?>
</table>
<br><br>
<table>
    <tr><td colspan="3" class="lookup-title">LOOKUP REFERENCE SHEET</td></tr>
    <tr><td colspan="3" style="font-size:10px; padding:8px; background:#e8f8f5; border:1px solid #a9dfbf;">Use these ID values when filling the Import Template above. Ask your administrator if an ID is missing.</td></tr>
    <tr><td colspan="3" class="section-title">GRADE LEVELS (tblgradelevel)</td></tr>
    <tr><td class="lookup-header">ID</td><td class="lookup-header" colspan="2">Grade Level Name</td></tr>
    <tr><td class="lookup-cell">1</td><td class="lookup-cell lookup-name" colspan="2">Grade 7</td></tr>
    <tr><td class="lookup-cell">2</td><td class="lookup-cell lookup-name" colspan="2">Grade 8</td></tr>
    <tr><td class="lookup-cell">3</td><td class="lookup-cell lookup-name" colspan="2">Grade 9</td></tr>
    <tr><td class="lookup-cell">4</td><td class="lookup-cell lookup-name" colspan="2">Grade 10</td></tr>
    <tr><td class="lookup-cell">5</td><td class="lookup-cell lookup-name" colspan="2">Grade 11</td></tr>
    <tr><td class="lookup-cell">6</td><td class="lookup-cell lookup-name" colspan="2">Grade 12</td></tr>
    <tr><td colspan="3" class="section-title">COUNTRIES (tblcountry)</td></tr>
    <tr><td class="lookup-header">ID</td><td class="lookup-header" colspan="2">Country Name</td></tr>
    <tr><td class="lookup-cell">1</td><td class="lookup-cell lookup-name" colspan="2">Philippines</td></tr>
    <tr><td colspan="3" class="section-title">REGIONS (tblregion)</td></tr>
    <tr><td class="lookup-header">ID</td><td class="lookup-header" colspan="2">Region Name</td></tr>
    <tr><td class="lookup-cell">1</td><td class="lookup-cell lookup-name" colspan="2">NCR</td></tr>
    <tr><td class="lookup-cell">2</td><td class="lookup-cell lookup-name" colspan="2">CAR</td></tr>
    <tr><td class="lookup-cell">3</td><td class="lookup-cell lookup-name" colspan="2">Region I</td></tr>
    <tr><td class="lookup-cell">4</td><td class="lookup-cell lookup-name" colspan="2">Region II</td></tr>
    <tr><td class="lookup-cell">5</td><td class="lookup-cell lookup-name" colspan="2">Region III</td></tr>
    <tr><td class="lookup-cell">6</td><td class="lookup-cell lookup-name" colspan="2">Region IV-A</td></tr>
    <tr><td class="lookup-cell">7</td><td class="lookup-cell lookup-name" colspan="2">Region IV-B</td></tr>
    <tr><td class="lookup-cell">8</td><td class="lookup-cell lookup-name" colspan="2">Region V</td></tr>
    <tr><td class="lookup-cell">9</td><td class="lookup-cell lookup-name" colspan="2">Region VI</td></tr>
    <tr><td class="lookup-cell">10</td><td class="lookup-cell lookup-name" colspan="2">Region VII</td></tr>
    <tr><td class="lookup-cell">11</td><td class="lookup-cell lookup-name" colspan="2">Region VIII</td></tr>
    <tr><td class="lookup-cell">12</td><td class="lookup-cell lookup-name" colspan="2">Region IX</td></tr>
    <tr><td class="lookup-cell">13</td><td class="lookup-cell lookup-name" colspan="2">Region X</td></tr>
    <tr><td class="lookup-cell">14</td><td class="lookup-cell lookup-name" colspan="2">Region XI</td></tr>
    <tr><td class="lookup-cell">15</td><td class="lookup-cell lookup-name" colspan="2">Region XII</td></tr>
    <tr><td class="lookup-cell">16</td><td class="lookup-cell lookup-name" colspan="2">Region XIII</td></tr>
    <tr><td class="lookup-cell">17</td><td class="lookup-cell lookup-name" colspan="2">BARMM</td></tr>
    <tr><td colspan="3" class="section-title">STRANDS (Senior High: Grades 11-12 only)</td></tr>
    <tr><td class="lookup-header">Code</td><td class="lookup-header" colspan="2">Strand Name</td></tr>
    <tr><td class="lookup-cell">STEM</td><td class="lookup-cell lookup-name" colspan="2">Science, Technology, Engineering, Mathematics</td></tr>
    <tr><td class="lookup-cell">ABM</td><td class="lookup-cell lookup-name" colspan="2">Accountancy, Business, Management</td></tr>
    <tr><td class="lookup-cell">HUMSS</td><td class="lookup-cell lookup-name" colspan="2">Humanities and Social Sciences</td></tr>
    <tr><td class="lookup-cell">GAS</td><td class="lookup-cell lookup-name" colspan="2">General Academic Strand</td></tr>
    <tr><td class="lookup-cell">TVL</td><td class="lookup-cell lookup-name" colspan="2">Technical-Vocational-Livelihood</td></tr>
    <tr><td colspan="3" class="section-title">IMPORTANT NOTES</td></tr>
    <tr><td colspan="3" class="lookup-cell lookup-name" style="text-align:left; padding:10px;">
        <b>ID-based fields:</b> grade_level_id, country_id, region_id, province_id, city_id, barangay_id must match IDs in your database.<br><br>
        <b>LRN:</b> Exactly 12 digits, no spaces or dashes.<br>
        <b>Gender:</b> Use "Male" or "Female" exactly.<br>
        <b>Birthdate:</b> Format YYYY-MM-DD (e.g., 2010-05-15).<br>
        <b>Strand:</b> Leave blank for Grades 7-10. Required for Grades 11-12.<br>
        <b>Is Active:</b> Use 1 for active students, 0 for inactive.<br>
        <b>Contact numbers:</b> Format 09######### (11 digits starting with 09).
    </td></tr>
</table>
</body>
</html>