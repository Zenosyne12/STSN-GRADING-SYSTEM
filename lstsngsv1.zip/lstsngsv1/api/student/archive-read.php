<?php
ob_start();
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
ob_end_clean();

header('Content-Type: application/json');

try {
    $page   = max(1, intval($_GET['p'] ?? 1));

    // ✅ FIXED: LIMIT TO 5
    $limit  = 5;
    $offset = ($page - 1) * $limit;

    $status = $_GET['status'] ?? 'all';
    $yearId = $_GET['year_id'] ?? 'all';
    $search = trim($_GET['search'] ?? '');

    $where  = ['1=1'];
    $params = [];

    if ($status !== 'all') {
        $where[] = 'sa.status = ?';
        $params[] = $status;
    }

    if ($yearId !== 'all') {
        $where[] = 'sa.academic_year_id = ?';
        $params[] = intval($yearId);
    }

    if ($search !== '') {
        $where[] = '(s.lrn LIKE ? OR s.fname LIKE ? OR s.lname LIKE ?)';
        $like = "%$search%";
        $params = array_merge($params, [$like, $like, $like]);
    }

    $whereStr = implode(' AND ', $where);

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM tblstudent_archive sa JOIN tblstudents s ON sa.student_id = s.id WHERE $whereStr");
    $stmt->execute($params);
    $total = (int)$stmt->fetchColumn();

    $pages = max(1, ceil($total / $limit));

    $stmt = $pdo->prepare("
        SELECT sa.*, s.lrn, s.fname, s.mname, s.lname
        FROM tblstudent_archive sa
        JOIN tblstudents s ON sa.student_id = s.id
        WHERE $whereStr
        ORDER BY sa.archived_at DESC
        LIMIT $limit OFFSET $offset
    ");
    $stmt->execute($params);

    echo json_encode([
        'success' => true,
        'records' => $stmt->fetchAll(PDO::FETCH_ASSOC),
        'page'    => $page,
        'pages'   => $pages,
        'total'   => $total
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}