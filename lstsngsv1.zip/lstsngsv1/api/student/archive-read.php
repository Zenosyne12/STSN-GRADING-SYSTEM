<?php
ob_start();
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
ob_end_clean();

header('Content-Type: application/json');

try {
    $page   = max(1, intval($_GET['p'] ?? 1));

    
    $limit  = 5;
    $offset = ($page - 1) * $limit;

    $yearId = $_GET['year_id'] ?? 'all';
    $search = trim($_GET['search'] ?? '');

    $where  = ['1=1'];
    $params = [];

    if ($yearId !== 'all') {
        $where[] = 'sa.academic_year_id = ?';
        $params[] = intval($yearId);
    }

    if ($search !== '') {
        $where[] = '(
            LOWER(s.lrn) LIKE ?
            OR LOWER(s.fname) LIKE ?
            OR LOWER(s.mname) LIKE ?
            OR LOWER(s.lname) LIKE ?
            OR LOWER(gl.grade_level_name) LIKE ?
            OR LOWER(CONCAT_WS(\' \', s.fname, NULLIF(s.mname, \'\'), s.lname)) LIKE ?
        )';
        $like = '%' . mb_strtolower($search, 'UTF-8') . '%';
        $params = array_merge($params, [$like, $like, $like, $like, $like, $like]);
    }

    $whereStr = implode(' AND ', $where);

    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM tblstudent_archive sa JOIN tblstudents s ON sa.student_id = s.id LEFT JOIN tblgradelevel gl ON gl.id = sa.grade_level_id WHERE $whereStr");
    $stmt->execute($params);
    $total = (int)$stmt->fetchColumn();

    $pages = max(1, ceil($total / $limit));

    
    $stmt = $pdo->prepare("
        SELECT sa.*, s.lrn, s.fname, s.mname, s.lname,
               gl.grade_level_name,
               ay.year_label
        FROM tblstudent_archive sa
        JOIN tblstudents s ON sa.student_id = s.id
        LEFT JOIN tblgradelevel gl ON gl.id = sa.grade_level_id
        LEFT JOIN tblacademicyear ay ON ay.id = sa.academic_year_id
        WHERE $whereStr
        ORDER BY sa.archived_at DESC
        LIMIT $limit OFFSET $offset
    ");
    $stmt->execute($params);

    
    $allYears = $pdo->query("
        SELECT id, year_label, is_active FROM tblacademicyear ORDER BY id DESC
    ")->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'records' => $stmt->fetchAll(PDO::FETCH_ASSOC),
        'page'    => $page,
        'pages'   => $pages,
        'total'   => $total,
        'all_years' => $allYears
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}