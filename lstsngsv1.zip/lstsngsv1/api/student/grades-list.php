<?php




require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $rows = $pdo->query(
        "SELECT id, grade_level_name FROM tblgradelevel ORDER BY sort_order, id"
    )->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'grades' => $rows]);
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}