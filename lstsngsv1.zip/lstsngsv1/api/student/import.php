<?php























require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json; charset=utf-8');

function jsonOut(array $d): void
{
    echo json_encode($d, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST')
    jsonOut(['success' => false, 'message' => 'Method not allowed.']);

$raw = file_get_contents('php://input');
$payload = json_decode($raw, true);

if (!$payload || !isset($payload['rows']) || !is_array($payload['rows']))
    jsonOut(['success' => false, 'message' => 'Invalid payload. Expected JSON with "rows" array.']);


$gradeLevelId = isset($payload['grade_level_id']) ? (int) $payload['grade_level_id'] : 0;
if ($gradeLevelId <= 0)
    jsonOut(['success' => false, 'message' => 'Invalid grade_level_id.']);


$strand = trim($payload['strand'] ?? '');
$sectionName = trim($payload['section_name'] ?? '');
$schoolYear = trim($payload['school_year'] ?? '');   
$rows = $payload['rows'];




function resolveAcademicYearId(PDO $pdo): int
{
    $r = $pdo->query("SELECT id FROM tblacademicyear WHERE is_active=1 ORDER BY id DESC LIMIT 1")->fetch();
    if ($r)
        return (int) $r['id'];
    $r = $pdo->query("SELECT id FROM tblacademicyear ORDER BY id DESC LIMIT 1")->fetch();
    return $r ? (int) $r['id'] : 0;
}

$academicYearId = 0;

if ($schoolYear !== '') {
    
    $stmtAy = $pdo->prepare("
        SELECT id FROM tblacademicyear
        WHERE year_label = ?
        LIMIT 1
    ");
    $stmtAy->execute([$schoolYear]);
    $ayRow = $stmtAy->fetch();
    $academicYearId = $ayRow ? (int) $ayRow['id'] : 0;
}


if (!$academicYearId) {
    $academicYearId = resolveAcademicYearId($pdo);
}



$sectionId = null;
$sectionAssigned = null;

if ($sectionName !== '') {
    
    $stmtSec = $pdo->prepare("
        SELECT id, section_name
        FROM tblsection
        WHERE LOWER(TRIM(section_name)) = LOWER(TRIM(?))
          AND grade_level_id = ?
          AND is_active = 1
        LIMIT 1
    ");
    $stmtSec->execute([$sectionName, $gradeLevelId]);
    $secRow = $stmtSec->fetch();

    if (!$secRow) {
        
        $stmtSec2 = $pdo->prepare("
            SELECT id, section_name
            FROM tblsection
            WHERE LOWER(TRIM(section_name)) = LOWER(TRIM(?))
              AND is_active = 1
            LIMIT 1
        ");
        $stmtSec2->execute([$sectionName]);
        $secRow = $stmtSec2->fetch();
    }

    if ($secRow) {
        $sectionId = (int) $secRow['id'];
        $sectionAssigned = $secRow['section_name'];
    }
}


function normalizeLocationName(string $value): string
{
    $value = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $value = preg_replace('/\s+/u', ' ', trim($value));
    return strtolower($value ?? '');
}

function locationKeys(string $value): array
{
    $base = normalizeLocationName($value);
    if ($base === '')
        return [];

    $candidates = [$base];
    $withoutParen = normalizeLocationName(preg_replace('/\([^)]*\)/u', ' ', $base));
    if ($withoutParen !== '')
        $candidates[] = $withoutParen;

    if (preg_match_all('/\(([^)]*)\)/u', $base, $matches)) {
        foreach ($matches[1] as $inside) {
            $inside = normalizeLocationName($inside);
            if ($inside !== '')
                $candidates[] = $inside;
        }
    }

    $keys = [];
    foreach ($candidates as $candidate) {
        $keys[$candidate] = true;

        $stripped = preg_replace('/^(province|prov\.?|city|municipality|mun\.?|barangay|brgy\.?)\s+(of\s+)?/u', '', $candidate);
        $stripped = normalizeLocationName($stripped ?? '');
        if ($stripped !== '')
            $keys[$stripped] = true;

        $withoutCitySuffix = preg_replace('/\s+city$/u', '', $candidate);
        $withoutCitySuffix = normalizeLocationName($withoutCitySuffix ?? '');
        if ($withoutCitySuffix !== '')
            $keys[$withoutCitySuffix] = true;
    }

    return array_keys($keys);
}

function addLocationLookup(array &$map, string $name, array $row, ?int $parentId = null): void
{
    foreach (locationKeys($name) as $key) {
        $lookupKey = $parentId === null ? $key : $key . '|' . $parentId;
        $map[$lookupKey][$row['id']] = $row;
    }
}

function resolveLocation(array $map, string $name, string $label, int $rowNum, string $lrn, array &$errors, ?int $parentId = null): ?array
{
    $name = trim($name);
    if ($name === '') {
        $errors[] = ['row' => $rowNum, 'lrn' => $lrn, 'msg' => "{$label} is required for address mapping."];
        return null;
    }

    $matches = [];
    foreach (locationKeys($name) as $key) {
        $lookupKey = $parentId === null ? $key : $key . '|' . $parentId;
        if (isset($map[$lookupKey])) {
            foreach ($map[$lookupKey] as $id => $row) {
                $matches[$id] = $row;
            }
        }
    }

    if (count($matches) === 1)
        return reset($matches);

    $msg = count($matches) > 1
        ? "{$label} '{$name}' is ambiguous in the address database."
        : "{$label} '{$name}' was not found in the address database.";
    $errors[] = ['row' => $rowNum, 'lrn' => $lrn, 'msg' => $msg];
    return null;
}

function locationNameMatches(string $input, string $stored): bool
{
    return count(array_intersect(locationKeys($input), locationKeys($stored))) > 0;
}

$countryMap = $regionMap = $provinceMap = $cityMap = $barangayMap = [];

foreach ($pdo->query("SELECT id, country_name FROM tblcountry") as $country) {
    $country['id'] = (int) $country['id'];
    addLocationLookup($countryMap, $country['country_name'], $country);
}

foreach ($pdo->query("
    SELECT r.id, r.region_name, r.country_id, c.country_name
    FROM tblregion r
    JOIN tblcountry c ON c.id = r.country_id
") as $region) {
    $region['id'] = (int) $region['id'];
    $region['country_id'] = (int) $region['country_id'];
    addLocationLookup($regionMap, $region['region_name'], $region, $region['country_id']);
}

foreach ($pdo->query("
    SELECT p.id, p.province_name, p.region_id, r.region_name, r.country_id, c.country_name
    FROM tblprovince p
    JOIN tblregion r ON r.id = p.region_id
    JOIN tblcountry c ON c.id = r.country_id
") as $province) {
    $province['id'] = (int) $province['id'];
    $province['region_id'] = (int) $province['region_id'];
    $province['country_id'] = (int) $province['country_id'];
    addLocationLookup($provinceMap, $province['province_name'], $province);
}

foreach ($pdo->query("
    SELECT ci.id, ci.city_name, ci.province_id, p.province_name, p.region_id, r.region_name, r.country_id, c.country_name
    FROM tblcity ci
    JOIN tblprovince p ON p.id = ci.province_id
    JOIN tblregion r ON r.id = p.region_id
    JOIN tblcountry c ON c.id = r.country_id
") as $city) {
    $city['id'] = (int) $city['id'];
    $city['province_id'] = (int) $city['province_id'];
    $city['region_id'] = (int) $city['region_id'];
    $city['country_id'] = (int) $city['country_id'];
    addLocationLookup($cityMap, $city['city_name'], $city, $city['province_id']);
}

foreach ($pdo->query("
    SELECT b.id, b.barangay_name, b.city_id, b.postal_code, ci.city_name, ci.province_id, p.province_name,
           p.region_id, r.region_name, r.country_id, c.country_name
    FROM tblbarangay b
    JOIN tblcity ci ON ci.id = b.city_id
    JOIN tblprovince p ON p.id = ci.province_id
    JOIN tblregion r ON r.id = p.region_id
    JOIN tblcountry c ON c.id = r.country_id
") as $barangay) {
    $barangay['id'] = (int) $barangay['id'];
    $barangay['city_id'] = (int) $barangay['city_id'];
    $barangay['province_id'] = (int) $barangay['province_id'];
    $barangay['region_id'] = (int) $barangay['region_id'];
    $barangay['country_id'] = (int) $barangay['country_id'];
    addLocationLookup($barangayMap, $barangay['barangay_name'], $barangay, $barangay['city_id']);
}


$existingLRNs = [];
foreach ($pdo->query("SELECT lrn FROM tblstudents WHERE lrn IS NOT NULL") as $r)
    $existingLRNs[$r['lrn']] = true;


$insStudent = $pdo->prepare("
    INSERT INTO tblstudents (
        lrn, fname, mname, lname, birthdate, gender, citizenship,
        grade_level_id, strand,
        fathers_name, fathers_contact_num,
        mothers_name, mothers_contact_num,
        guardian_name, guardian_contact_num,
        email, street_name, postal_code,
        barangay_id, city_id, region_id, province_id, country_id,
        is_active
    ) VALUES (
        :lrn,:fname,:mname,:lname,:birthdate,:gender,:citizenship,
        :grade_level_id,:strand,
        :fathers_name,:fathers_contact_num,
        :mothers_name,:mothers_contact_num,
        :guardian_name,:guardian_contact_num,
        '',:street_name,:postal_code,
        :barangay_id,:city_id,:region_id,:province_id,:country_id,
        1
    )
");

$insEnroll = $pdo->prepare("
    INSERT IGNORE INTO tblenrollment
        (student_id, academic_year_id, grade_level_id, enrollment_status, is_active)
    VALUES (:sid,:ayid,:glid,'ENROLLED',1)
");

$insSectionStudent = $pdo->prepare("
    INSERT IGNORE INTO tblsectionstudent
        (section_id, student_id, academic_year_id, is_active)
    VALUES (:section_id, :student_id, :academic_year_id, 1)
");


$inserted = $total = 0;
$duplicates = $errors = [];

foreach ($rows as $i => $row) {
    $rowNum = $i + 1;

    $lrn = preg_replace('/\D/', '', trim($row['lrn'] ?? ''));
    if (strlen($lrn) < 10)
        continue;
    $lrn = str_pad($lrn, 12, '0', STR_PAD_LEFT);
    $total++;

    
    if (isset($existingLRNs[$lrn])) {
        $duplicates[] = [
            'row' => $rowNum,
            'lrn' => $lrn,
            'name' => trim(($row['lname'] ?? '') . ', ' . ($row['fname'] ?? '')),
        ];
        continue;
    }

    $fname = trim($row['fname'] ?? '');
    $lname = trim($row['lname'] ?? '');
    if ($fname === '' || $lname === '') {
        $errors[] = ['row' => $rowNum, 'lrn' => $lrn, 'msg' => 'Missing first or last name.'];
        continue;
    }

    
    $sx = strtoupper(trim($row['sex'] ?? ''));
    $gen = match ($sx) { 'M', 'MALE' => 'Male', 'F', 'FEMALE' => 'Female', default => ''};

    
    $bd = trim($row['birthdate'] ?? '');
    $bdate = null;
    if ($bd !== '') {
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $bd)) {
            $bdate = $bd;
        } else {
            foreach (['m/d/Y', 'd/m/Y', 'm-d-Y', 'Y/m/d'] as $fmt) {
                $dt = DateTime::createFromFormat($fmt, $bd);
                if ($dt) {
                    $bdate = $dt->format('Y-m-d');
                    break;
                }
            }
            if (!$bdate) {
                $ts = strtotime($bd);
                if ($ts)
                    $bdate = date('Y-m-d', $ts);
            }
        }
    }

    
    $province = resolveLocation($provinceMap, trim($row['province'] ?? ''), 'Province', $rowNum, $lrn, $errors);
    if (!$province)
        continue;

    $city = resolveLocation($cityMap, trim($row['city'] ?? ''), 'City/Municipality', $rowNum, $lrn, $errors, (int) $province['id']);
    if (!$city)
        continue;

    $barangay = resolveLocation($barangayMap, trim($row['barangay'] ?? ''), 'Barangay', $rowNum, $lrn, $errors, (int) $city['id']);
    if (!$barangay)
        continue;

    if (!empty($row['country']) && !locationNameMatches((string) $row['country'], (string) $province['country_name'])) {
        $errors[] = ['row' => $rowNum, 'lrn' => $lrn, 'msg' => "Country '{$row['country']}' does not match province '{$province['province_name']}'."];
        continue;
    }

    if (!empty($row['region']) && !locationNameMatches((string) $row['region'], (string) $province['region_name'])) {
        $errors[] = ['row' => $rowNum, 'lrn' => $lrn, 'msg' => "Region '{$row['region']}' does not match province '{$province['province_name']}'."];
        continue;
    }

    $countryId = (int) $province['country_id'];
    $regionId = (int) $province['region_id'];
    $provId = (int) $province['id'];
    $cityId = (int) $city['id'];
    $brgyId = (int) $barangay['id'];
    $postalCode = (string) ($barangay['postal_code'] ?? '');

    if (!preg_match('/^\d{4}$/', $postalCode)) {
        $errors[] = ['row' => $rowNum, 'lrn' => $lrn, 'msg' => "Barangay '{$barangay['barangay_name']}' has no valid postal code."];
        continue;
    }

    
    $father = trim($row['father'] ?? '');
    $mother = trim($row['mother'] ?? '');
    $guard = trim($row['guardian'] ?? '') ?: $father;
    $contact = trim($row['contact'] ?? '');

    
    try {
        $pdo->beginTransaction();

        $insStudent->execute([
            ':lrn' => $lrn,
            ':fname' => $fname,
            ':mname' => trim($row['mname'] ?? ''),
            ':lname' => $lname,
            ':birthdate' => $bdate,
            ':gender' => $gen,
            ':citizenship' => 'Filipino',
            ':grade_level_id' => $gradeLevelId,
            ':strand' => $strand,
            ':fathers_name' => $father,
            ':fathers_contact_num' => $contact,
            ':mothers_name' => $mother,
            ':mothers_contact_num' => '',
            ':guardian_name' => $guard,
            ':guardian_contact_num' => $contact,
            ':street_name' => trim($row['street'] ?? ''),
            ':postal_code' => $postalCode,
            ':barangay_id' => $brgyId,
            ':city_id' => $cityId,
            ':region_id' => $regionId,
            ':province_id' => $provId,
            ':country_id' => $countryId,
        ]);

        $newId = (int) $pdo->lastInsertId();

        
        if ($academicYearId && $newId) {
            $insEnroll->execute([
                ':sid' => $newId,
                ':ayid' => $academicYearId,
                ':glid' => $gradeLevelId,
            ]);
        }

        
        if ($sectionId && $newId && $academicYearId) {
            $insSectionStudent->execute([
                ':section_id' => $sectionId,
                ':student_id' => $newId,
                ':academic_year_id' => $academicYearId,
            ]);
        }

        $pdo->commit();
        $existingLRNs[$lrn] = true;
        $inserted++;

    } catch (Throwable $e) {
        if ($pdo->inTransaction())
            $pdo->rollBack();
        $errors[] = ['row' => $rowNum, 'lrn' => $lrn, 'msg' => $e->getMessage()];
    }
}

try {
    if ($inserted > 0) {
        $importFileName = '';
        if (!empty($_FILES['file']['name'])) {
            $importFileName = (string)$_FILES['file']['name'];
        } elseif (!empty($_POST['filename'])) {
            $importFileName = (string)$_POST['filename'];
        }
        $importMsg = 'Imported ' . $inserted . ' student(s)';
        if ($importFileName !== '') {
            $importMsg .= ' from ' . $importFileName;
        }
        logActivity($pdo, 'Students', 'CREATE', 'student', null, $importMsg);
    }
} catch (Throwable $e) {}

jsonOut([
    'success' => true,
    'inserted' => $inserted,
    'total' => $total,
    'duplicates' => $duplicates,
    'errors' => $errors,
    'section_assigned' => $sectionAssigned,
    'academic_year_id' => $academicYearId,   
]);
