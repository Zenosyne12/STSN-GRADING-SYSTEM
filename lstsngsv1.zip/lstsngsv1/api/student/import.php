<?php
require_once '../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => '', 'imported' => 0, 'errors' => []];

try {
    if (!isset($_FILES['excel_file']) || $_FILES['excel_file']['error'] !== UPLOAD_ERR_OK) {
        $errorMessages = [
            UPLOAD_ERR_INI_SIZE => 'File too large (exceeds server limit).',
            UPLOAD_ERR_FORM_SIZE => 'File too large (exceeds form limit).',
            UPLOAD_ERR_PARTIAL => 'File partially uploaded.',
            UPLOAD_ERR_NO_FILE => 'No file selected.',
            UPLOAD_ERR_NO_TMP_DIR => 'Server temp folder missing.',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file.',
            UPLOAD_ERR_EXTENSION => 'Upload stopped by extension.'
        ];
        $errCode = $_FILES['excel_file']['error'] ?? UPLOAD_ERR_NO_FILE;
        throw new Exception($errorMessages[$errCode] ?? 'Upload error occurred.');
    }

    $file = $_FILES['excel_file'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($ext, ['csv', 'xls', 'xlsx'])) {
        throw new Exception('Invalid file format. Please upload a .csv, .xls, or .xlsx file.');
    }

    $tmpName = $file['tmp_name'];
    $data = [];

    $handle = fopen($tmpName, 'r');
    if (!$handle) throw new Exception('Cannot read file.');
    
    // Skip BOM
    $bom = fread($handle, 3);
    if ($bom !== "\xEF\xBB\xBF") rewind($handle);
    
    $headers = fgetcsv($handle);
    if (!$headers) throw new Exception('File is empty.');
    
    // Normalize headers: lowercase, replace spaces with underscores, strip non-alphanumeric
    $headers = array_map(function($h) {
        $h = strtolower(trim($h));
        $h = str_replace([' ', '-'], '_', $h);
        // Map common variations to DB column names
        $map = [
            'first_name' => 'fname',
            'middle_name' => 'mname',
            'last_name' => 'lname',
            'sex' => 'gender',
            'father_name' => 'fathers_name',
            'father_contact' => 'fathers_contact_num',
            'mother_name' => 'mothers_name',
            'mother_contact' => 'mothers_contact_num',
            'guardian_contact' => 'guardian_contact_num',
            'street' => 'street_name',
            'grade_level' => 'grade_level_id',
            'country' => 'country_id',
            'region' => 'region_id',
            'province' => 'province_id',
            'city' => 'city_id',
            'barangay' => 'barangay_id',
        ];
        return $map[$h] ?? $h;
    }, $headers);
    
    // Remove empty columns
    $headers = array_values(array_filter($headers, fn($h) => $h !== ''));
    
    $rowNum = 2;
    while (($row = fgetcsv($handle)) !== false) {
        // Skip empty rows
        if (empty(array_filter($row, fn($v) => trim($v) !== ''))) continue;
        
        // Skip instruction/hint rows
        $firstCell = strtolower(trim($row[0] ?? ''));
        $skipPatterns = ['digit', 'required', 'optional', 'must match', 'yyyy-mm-dd', 'male/female', 'abm', 'see lookup', '12 digits', 'how to use', 'important', 'note'];
        foreach ($skipPatterns as $pattern) {
            if (strpos($firstCell, $pattern) !== false) continue 2;
        }
        
        // Skip lookup sheet content
        if (in_array($firstCell, ['id', 'grade levels', 'countries', 'regions', 'strands', 'important notes'])) continue;
        
        $rowData = [];
        foreach ($headers as $i => $header) {
            if (isset($row[$i])) {
                $rowData[$header] = trim($row[$i]);
            }
        }
        
        if (!empty($rowData)) {
            $data[] = $rowData;
        }
        $rowNum++;
    }
    fclose($handle);

    if (empty($data)) {
        throw new Exception('No valid data found in the file. Make sure you removed any notes or instruction rows.');
    }

    // Required DB columns
    $requiredFields = ['lrn', 'grade_level_id', 'fname', 'lname', 'birthdate', 'gender'];
    
    $imported = 0;
    $errors = [];
    $pdo->beginTransaction();

    foreach ($data as $index => $row) {
        $rowNum = $index + 2;
        
        // Check required fields
        $missing = [];
        foreach ($requiredFields as $field) {
            if (empty($row[$field] ?? '')) {
                $missing[] = $field;
            }
        }
        
        if (!empty($missing)) {
            $errors[] = "Row {$rowNum}: Missing required fields - " . implode(', ', $missing);
            continue;
        }

        // Validate LRN
        $lrn = $row['lrn'];
        if (!preg_match('/^\d{12}$/', $lrn)) {
            $errors[] = "Row {$rowNum}: LRN must be exactly 12 digits (got: {$lrn}).";
            continue;
        }

        // Check duplicate LRN
        $check = $pdo->prepare('SELECT id FROM tblstudents WHERE lrn = ?');
        $check->execute([$lrn]);
        if ($check->fetch()) {
            $errors[] = "Row {$rowNum}: LRN '{$lrn}' already exists.";
            continue;
        }

        // Validate gender
        $gender = ucfirst(strtolower($row['gender']));
        if (!in_array($gender, ['Male', 'Female'])) {
            $errors[] = "Row {$rowNum}: Gender must be 'Male' or 'Female' (got: {$row['gender']}).";
            continue;
        }

        // Validate grade_level_id exists
        $gradeLevelId = (int)($row['grade_level_id'] ?? 0);
        $gradeCheck = $pdo->prepare('SELECT id FROM tblgradelevel WHERE id = ?');
        $gradeCheck->execute([$gradeLevelId]);
        if (!$gradeCheck->fetch()) {
            $errors[] = "Row {$rowNum}: Invalid grade_level_id '{$gradeLevelId}'.";
            continue;
        }

        // Validate strand for senior high
        $strand = strtoupper(trim($row['strand'] ?? ''));
        $validStrands = ['ABM', 'GAS', 'STEM', 'HUMSS', 'TVL', ''];
        $isSeniorHigh = in_array($gradeLevelId, [5, 6]); // Grade 11 = 5, Grade 12 = 6
        
        if ($isSeniorHigh && empty($strand)) {
            $errors[] = "Row {$rowNum}: Strand is required for Grade 11/12.";
            continue;
        }
        
        if (!empty($strand) && !in_array($strand, $validStrands)) {
            $errors[] = "Row {$rowNum}: Invalid strand '{$strand}'. Must be ABM, GAS, STEM, HUMSS, or TVL.";
            continue;
        }

        // Validate location IDs (if provided)
        $locationFields = ['country_id', 'region_id', 'province_id', 'city_id', 'barangay_id'];
        foreach ($locationFields as $field) {
            $val = $row[$field] ?? '';
            if ($val !== '' && $val !== '0') {
                $tableMap = [
                    'country_id' => 'tblcountry',
                    'region_id' => 'tblregion',
                    'province_id' => 'tblprovince',
                    'city_id' => 'tblcity',
                    'barangay_id' => 'tblbarangay'
                ];
                $table = $tableMap[$field];
                $checkLoc = $pdo->prepare("SELECT id FROM {$table} WHERE id = ?");
                $checkLoc->execute([(int)$val]);
                if (!$checkLoc->fetch()) {
                    $errors[] = "Row {$rowNum}: Invalid {$field} '{$val}' (not found in {$table}).";
                    continue 2;
                }
            }
        }

        // Build insert data
        $insertData = [
            'lrn' => $lrn,
            'grade_level_id' => $gradeLevelId,
            'fname' => $row['fname'],
            'mname' => $row['mname'] ?? '',
            'lname' => $row['lname'],
            'birthdate' => $row['birthdate'],
            'gender' => $gender,
            'citizenship' => $row['citizenship'] ?? 'Filipino',
            'fathers_name' => $row['fathers_name'] ?? '',
            'fathers_contact_num' => $row['fathers_contact_num'] ?? '',
            'mothers_name' => $row['mothers_name'] ?? '',
            'mothers_contact_num' => $row['mothers_contact_num'] ?? '',
            'guardian_name' => $row['guardian_name'] ?? '',
            'guardian_contact_num' => $row['guardian_contact_num'] ?? '',
            'street_name' => $row['street_name'] ?? '',
            'country_id' => !empty($row['country_id']) ? (int)$row['country_id'] : null,
            'region_id' => !empty($row['region_id']) ? (int)$row['region_id'] : null,
            'province_id' => !empty($row['province_id']) ? (int)$row['province_id'] : null,
            'city_id' => !empty($row['city_id']) ? (int)$row['city_id'] : null,
            'barangay_id' => !empty($row['barangay_id']) ? (int)$row['barangay_id'] : null,
            'postal_code' => $row['postal_code'] ?? '',
            'strand' => $isSeniorHigh ? $strand : '',
            'is_active' => isset($row['is_active']) ? (int)$row['is_active'] : 1,
        ];

        // Build SQL
        $fields = array_keys($insertData);
        $placeholders = array_fill(0, count($fields), '?');
        
        $sql = "INSERT INTO tblstudents (" . implode(', ', $fields) . ") VALUES (" . implode(', ', $placeholders) . ")";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(array_values($insertData));

        $imported++;
    }

    if ($imported > 0) {
        $pdo->commit();
    } else {
        $pdo->rollBack();
    }

    $response['success'] = $imported > 0;
    $response['imported'] = $imported;
    $response['errors'] = $errors;
    
    if ($imported > 0 && empty($errors)) {
        $response['message'] = "Successfully imported {$imported} student(s).";
    } elseif ($imported > 0) {
        $response['message'] = "Imported {$imported} student(s) with " . count($errors) . " warning(s).";
    } else {
        $response['message'] = "No students imported. Please fix the errors and try again.";
    }

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $response['message'] = $e->getMessage();
    $response['errors'][] = $e->getMessage();
}

echo json_encode($response);