<?php
/**
 * api/student/archive-restore.php
 * Restores an archived student back to active enrollment.
 *
 * POST body (JSON):
 * { "id": 5 }   <- tblstudent_archive.id
 */
ob_start();
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
ob_end_clean();

header('Content-Type: application/json');

$data      = json_decode(file_get_contents('php://input'), true);
$archiveId = intval($data['id'] ?? 0);

if (!$archiveId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Archive ID is required.']);
    exit;
}

try {
    $pdo->beginTransaction();

    // 1. Fetch the archive record
    $stmt = $pdo->prepare("SELECT * FROM tblstudent_archive WHERE id = ? LIMIT 1");
    $stmt->execute([$archiveId]);
    $archive = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$archive) {
        throw new Exception('Archive record not found.');
    }

    // 2. Check if student already has an active enrollment
    $activeCheck = $pdo->prepare("
        SELECT id FROM tblenrollment
        WHERE student_id = ? AND is_active = 1 LIMIT 1
    ");
    $activeCheck->execute([$archive['student_id']]);
    if ($activeCheck->fetch()) {
        throw new Exception('This student already has an active enrollment record.');
    }

    // 3. Get current active year
    $activeYear = $pdo->query("
        SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1
    ")->fetch(PDO::FETCH_ASSOC);

    $targetYearId = $activeYear ? (int)$activeYear['id'] : $archive['academic_year_id'];

    // 4. Re-activate existing enrollment or create new one
    $enrollCheck = $pdo->prepare("
        SELECT id FROM tblenrollment
        WHERE student_id = ? AND academic_year_id = ? LIMIT 1
    ");
    $enrollCheck->execute([$archive['student_id'], $targetYearId]);
    $existingEnrollment = $enrollCheck->fetch(PDO::FETCH_ASSOC);

    if ($existingEnrollment) {
        $pdo->prepare("
            UPDATE tblenrollment
            SET is_active = 1, enrollment_status = 'ENROLLED'
            WHERE id = ?
        ")->execute([$existingEnrollment['id']]);
    } else {
        $pdo->prepare("
            INSERT INTO tblenrollment
                (student_id, academic_year_id, grade_level_id, enrollment_status, is_active)
            VALUES (?, ?, ?, 'ENROLLED', 1)
        ")->execute([
            $archive['student_id'],
            $targetYearId,
            $archive['grade_level_id'],
        ]);
    }

    // 5. Re-activate student
    $pdo->prepare("
        UPDATE tblstudents
        SET is_active = 1, grade_level_id = ?
        WHERE id = ?
    ")->execute([$archive['grade_level_id'], $archive['student_id']]);

    // 6. Remove the archive record
    $pdo->prepare("DELETE FROM tblstudent_archive WHERE id = ?")->execute([$archiveId]);

    $pdo->commit();
    echo json_encode(['success' => true, 'message' => 'Student restored successfully.']);

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}