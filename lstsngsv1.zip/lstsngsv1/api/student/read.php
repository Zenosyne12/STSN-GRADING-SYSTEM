<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

$page         = max(1, (int)($_GET['p']            ?? $_GET['page']   ?? 1));
$search       = trim((string)($_GET['s']           ?? $_GET['search'] ?? ''));
$yearId       = isset($_GET['year_id'])       && $_GET['year_id']       !== '' ? (int)$_GET['year_id']       : null;
$gradeLevelId = isset($_GET['grade_level_id']) && $_GET['grade_level_id'] !== '' ? (int)$_GET['grade_level_id'] : null;
$perPage      = max(1, min(100, (int)($_GET['per_page'] ?? 10)));      // <-- now configurable
$offset       = ($page - 1) * $perPage;

try {
    // Resolve academic year
    $viewingYear = null;

    if ($yearId) {
        $stmt = $pdo->prepare("
            SELECT id, year_label, is_active FROM tblacademicyear WHERE id = ? LIMIT 1
        ");
        $stmt->execute([$yearId]);
        $viewingYear = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    if (!$viewingYear) {
        $viewingYear = $pdo->query("
            SELECT id, year_label, is_active FROM tblacademicyear WHERE is_active = 1 LIMIT 1
        ")->fetch(PDO::FETCH_ASSOC);
    }

    $resolvedYearId = $viewingYear ? (int)$viewingYear['id'] : null;

    // Build WHERE
    $where  = ['1=1'];
    $params = [];

    // Filter by specific grade level (used by schedule_manage.php Students tab)
    if ($gradeLevelId) {
        $where[]  = "COALESCE(e.grade_level_id, s.grade_level_id) = ?";
        $params[] = $gradeLevelId;
    }

    if ($search !== '') {
        $where[] = "(
            s.lrn                     LIKE ?
            OR s.fname                LIKE ?
            OR s.mname                LIKE ?
            OR s.lname                LIKE ?
            OR s.guardian_name        LIKE ?
            OR s.guardian_contact_num LIKE ?
            OR gl.grade_level_name    LIKE ?
            OR CONCAT_WS(' ', s.fname, NULLIF(s.mname,''), s.lname) LIKE ?
        )";
        $like = '%' . $search . '%';
        array_push($params, $like, $like, $like, $like, $like, $like, $like, $like);
    }

    $whereSql = implode(' AND ', $where);

    // JOIN for enrollment
    if ($resolvedYearId) {
        $yearJoin = "LEFT JOIN tblenrollment e
                         ON e.student_id = s.id
                        AND e.academic_year_id = {$resolvedYearId}
                        AND e.is_active = 1";
    } else {
        $yearJoin = "LEFT JOIN tblenrollment e
                         ON e.student_id = s.id
                        AND e.academic_year_id = (
                            SELECT COALESCE(MAX(id), 0)
                            FROM tblacademicyear
                            WHERE is_active = 1
                            LIMIT 1
                        )
                        AND e.is_active = 1";
    }

    $joinSql = "
        FROM tblstudents s
        {$yearJoin}
        LEFT JOIN tblgradelevel gl ON gl.id = COALESCE(e.grade_level_id, s.grade_level_id)
    ";

    // Count
    $countStmt = $pdo->prepare("SELECT COUNT(DISTINCT s.id) {$joinSql} WHERE {$whereSql}");
    $countStmt->execute($params);
    $total = (int)$countStmt->fetchColumn();

    $pages = max(1, (int)ceil($total / $perPage));
    if ($page > $pages) {
        $page   = $pages;
        $offset = ($page - 1) * $perPage;
    }

    // Fetch
    $stmt = $pdo->prepare("
        SELECT
            s.id,
            s.lrn,
            s.fname,
            s.mname,
            s.lname,
            s.gender,
            s.guardian_name,
            s.guardian_contact_num,
            s.is_active,
            TIMESTAMPDIFF(YEAR, s.birthdate, CURDATE()) AS age,
            gl.id               AS grade_level_id,
            gl.grade_level_name,
            e.id                AS enrollment_id,
            e.enrollment_status,
            e.academic_year_id
        {$joinSql}
        WHERE {$whereSql}
        GROUP BY s.id
        ORDER BY s.lname ASC, s.fname ASC, s.lrn ASC
        LIMIT {$perPage} OFFSET {$offset}
    ");
    $stmt->execute($params);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // All years for dropdown (still returned, but front‑end won't use it for student list)
    $allYears = $pdo->query("
        SELECT id, year_label, is_active FROM tblacademicyear ORDER BY id DESC
    ")->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success'      => true,
        'students'     => $students,
        'page'         => $page,
        'pages'        => $pages,
        'total'        => $total,
        'per_page'     => $perPage,
        'viewing_year' => $viewingYear,
        'all_years'    => $allYears,
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error'   => 'Failed to load students: ' . $e->getMessage(),
    ]);
}