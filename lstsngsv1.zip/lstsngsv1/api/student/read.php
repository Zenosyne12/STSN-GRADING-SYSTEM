<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

$page = max(1, (int) ($_GET['p'] ?? $_GET['page'] ?? 1));
$search = trim((string) ($_GET['s'] ?? $_GET['search'] ?? ''));
$perPage = 5;
$offset = ($page - 1) * $perPage;

try {
    $where = ["1 = 1"];
    $params = [];

    if ($search !== '') {
        $where[] = "(
            lrn LIKE ?
            OR fname LIKE ?
            OR mname LIKE ?
            OR lname LIKE ?
            OR guardian_name LIKE ?
            OR guardian_contact_num LIKE ?
            OR grade_level_name LIKE ?
            OR CONCAT_WS(' ', fname, NULLIF(mname, ''), lname) LIKE ?
        )";

        $like = '%' . $search . '%';
        array_push($params, $like, $like, $like, $like, $like, $like, $like, $like);
    }

    $whereSql = implode(' AND ', $where);

    $countStmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM vwStudentInfo
        WHERE {$whereSql}
    ");
    $countStmt->execute($params);
    $total = (int) $countStmt->fetchColumn();

    $pages = max(1, (int) ceil($total / $perPage));

    if ($page > $pages) {
        $page = $pages;
        $offset = ($page - 1) * $perPage;
    }

    $stmt = $pdo->prepare("
        SELECT
            id,
            lrn,
            fname,
            mname,
            lname,
            grade_level_name,
            age,
            gender,
            guardian_name,
            guardian_contact_num,
            is_active
        FROM vwStudentInfo
        WHERE {$whereSql}
        ORDER BY lname ASC, fname ASC, lrn ASC
        LIMIT {$perPage} OFFSET {$offset}
    ");
    $stmt->execute($params);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'students' => $students,
        'page' => $page,
        'pages' => $pages,
        'total' => $total,
        'per_page' => $perPage
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Failed to load students: ' . $e->getMessage()
    ]);
}