<?php







ob_start();
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
ob_end_clean();

header('Content-Type: application/json');

$studentId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$studentId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Student ID is required.']);
    exit;
}

try {
    $pdo->beginTransaction();

    
    $stmt = $pdo->prepare("SELECT id, is_active, fname, lname, grade_level_id FROM tblstudents WHERE id = ? LIMIT 1");
    $stmt->execute([$studentId]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Student not found.']);
        exit;
    }

    $newStatus = $student['is_active'] ? 0 : 1;
    $action    = $newStatus ? 'activated' : 'deactivated';

    
    $pdo->prepare("UPDATE tblstudents SET is_active = ? WHERE id = ?")
        ->execute([$newStatus, $studentId]);

    if (!$newStatus) {
        
        $enrollStmt = $pdo->prepare("
            SELECT * FROM tblenrollment
            WHERE student_id = ? AND is_active = 1
            ORDER BY enrolled_at DESC LIMIT 1
        ");
        $enrollStmt->execute([$studentId]);
        $enrollment = $enrollStmt->fetch(PDO::FETCH_ASSOC);

        if ($enrollment) {
            
            $pdo->prepare("
                UPDATE tblenrollment
                SET is_active = 0, enrollment_status = 'DROPPED'
                WHERE id = ?
            ")->execute([$enrollment['id']]);

            
            $dupCheck = $pdo->prepare("
                SELECT id FROM tblstudent_archive
                WHERE student_id = ? AND academic_year_id = ? LIMIT 1
            ");
            $dupCheck->execute([$studentId, $enrollment['academic_year_id']]);

            if (!$dupCheck->fetch()) {
                $archivedBy = $_SESSION['user_id'] ?? $_SESSION['admin_id'] ?? null;

                $pdo->prepare("
                    INSERT INTO tblstudent_archive
                        (student_id, academic_year_id, grade_level_id, final_average, status, archived_by)
                    VALUES (?, ?, ?, NULL, 'DROPPED', ?)
                ")->execute([
                    $studentId,
                    $enrollment['academic_year_id'],
                    $enrollment['grade_level_id'] ?? $student['grade_level_id'],
                    $archivedBy
                ]);
            }
        }
    } else {
        
        $activeYear = $pdo->query("
            SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1
        ")->fetch(PDO::FETCH_ASSOC);

        if ($activeYear) {
            $yearId = $activeYear['id'];

            
            $checkStmt = $pdo->prepare("
                SELECT id, is_active FROM tblenrollment
                WHERE student_id = ? AND academic_year_id = ? LIMIT 1
            ");
            $checkStmt->execute([$studentId, $yearId]);
            $existing = $checkStmt->fetch(PDO::FETCH_ASSOC);

            if ($existing) {
                
                if (!$existing['is_active']) {
                    $pdo->prepare("
                        UPDATE tblenrollment
                        SET is_active = 1, enrollment_status = 'ENROLLED'
                        WHERE id = ?
                    ")->execute([$existing['id']]);
                }
            } else {
                
                $pdo->prepare("
                    INSERT INTO tblenrollment
                        (student_id, academic_year_id, grade_level_id, enrollment_status, is_active)
                    VALUES (?, ?, ?, 'ENROLLED', 1)
                ")->execute([
                    $studentId,
                    $yearId,
                    $student['grade_level_id']
                ]);
            }
        }
    }

    $pdo->commit();

    try {
        logActivity($pdo, 'Students', 'UPDATE', 'student', $studentId,
            'Student ' . trim($student['fname'] . ' ' . $student['lname']) . ' ' . $action);
    } catch (Throwable $e) {}

    echo json_encode([
        'success' => true,
        'message' => "{$student['fname']} {$student['lname']} has been {$action}.",
        'is_active' => $newStatus,
    ]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}