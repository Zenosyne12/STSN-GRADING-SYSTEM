<?php







ob_start();
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../../includes/archive_engine.php';
ob_end_clean();

header('Content-Type: application/json');

$studentId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$studentId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Student ID is required.']);
    exit;
}

try {
    ensureProfileArchiveSchema($pdo);
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("SELECT id, is_active, fname, lname, grade_level_id FROM tblstudents WHERE id = ? LIMIT 1 FOR UPDATE");
    $stmt->execute([$studentId]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        throw new RuntimeException('Student not found.');
    }

    $newStatus = $student['is_active'] ? 0 : 1;
    $action    = $newStatus ? 'restored' : 'archived';

    if (!$newStatus) {
        $activeYearId = (int) $pdo->query("
            SELECT id FROM tblacademicyear
            WHERE is_active = 1 AND archived_at IS NULL
            ORDER BY id DESC LIMIT 1
        ")->fetchColumn();
        if ($activeYearId <= 0) {
            throw new RuntimeException('There is no active academic year to associate with this archived profile.');
        }

        $archiveStmt = $pdo->prepare("
            INSERT INTO tblprofile_archive (profile_type, profile_id, academic_year_id, archived_by)
            VALUES ('STUDENT', ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                archived_at = CURRENT_TIMESTAMP,
                archived_by = VALUES(archived_by),
                restored_at = NULL
        ");
        $archiveStmt->execute([
            $studentId,
            $activeYearId,
            $_SESSION['user_id'] ?? $_SESSION['admin_id'] ?? null
        ]);

        $archiveIdStmt = $pdo->prepare("
            SELECT id FROM tblprofile_archive
            WHERE profile_type = 'STUDENT' AND profile_id = ? AND academic_year_id = ?
            LIMIT 1
        ");
        $archiveIdStmt->execute([$studentId, $activeYearId]);
        $archiveId = (int) $archiveIdStmt->fetchColumn();
        $snapshotMemberships = $pdo->prepare("
            INSERT IGNORE INTO tblprofile_archive_section (profile_archive_id, section_student_id)
            SELECT ?, id
            FROM tblsectionstudent
            WHERE student_id = ? AND academic_year_id = ? AND is_active = 1
        ");
        $snapshotMemberships->execute([$archiveId, $studentId, $activeYearId]);

        $snapshotEnrollments = $pdo->prepare("
            INSERT IGNORE INTO tblprofile_archive_enrollment (profile_archive_id, enrollment_id)
            SELECT ?, id
            FROM tblenrollment
            WHERE student_id = ? AND academic_year_id = ? AND is_active = 1
        ");
        $snapshotEnrollments->execute([$archiveId, $studentId, $activeYearId]);

        $pdo->prepare("
            UPDATE tblenrollment
            SET is_active = 0
            WHERE student_id = ? AND academic_year_id = ? AND is_active = 1
        ")->execute([$studentId, $activeYearId]);
        $pdo->prepare("
            UPDATE tblsectionstudent
            SET is_active = 0
            WHERE student_id = ? AND academic_year_id = ? AND is_active = 1
        ")->execute([$studentId, $activeYearId]);
    } else {
        restoreArchivedStudentSectionMemberships($pdo, $studentId);
        $pdo->prepare("
            UPDATE tblprofile_archive
            SET restored_at = CURRENT_TIMESTAMP
            WHERE profile_type = 'STUDENT' AND profile_id = ? AND restored_at IS NULL
        ")->execute([$studentId]);
    }

    $pdo->prepare("UPDATE tblstudents SET is_active = ? WHERE id = ?")
        ->execute([$newStatus, $studentId]);
    $pdo->prepare("
        UPDATE tblusers SET status = ?
        WHERE role_id = 3 AND reference_id = ?
    ")->execute([$newStatus ? 'Active' : 'Inactive', $studentId]);

    $pdo->commit();

    try {
        logActivity($pdo, 'Students', 'UPDATE', 'student', $studentId,
            'Student ' . trim($student['fname'] . ' ' . $student['lname']) . ' ' . $action);
    } catch (Throwable $e) {}

    echo json_encode([
        'success' => true,
        'message' => "{$student['fname']} {$student['lname']} has been {$action}.",
        'is_active' => $newStatus,
    ]);

} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code($e instanceof RuntimeException && $e->getMessage() === 'Student not found.' ? 404 : 500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}