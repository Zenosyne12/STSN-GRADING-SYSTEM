<?php
/**
 * api/student/toggle.php
 * Toggles a student's active status in tblstudents.
 *
 * GET: ?id=5
 */
ob_start();
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
ob_end_clean();

header('Content-Type: application/json');

$studentId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$studentId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Student ID is required.']);
    exit;
}

try {
    // Get current status
    $stmt = $pdo->prepare("SELECT is_active, fname, lname FROM tblstudents WHERE id = ? LIMIT 1");
    $stmt->execute([$studentId]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Student not found.']);
        exit;
    }

    $newStatus = $student['is_active'] ? 0 : 1;
    $action    = $newStatus ? 'activated' : 'deactivated';

    $pdo->prepare("UPDATE tblstudents SET is_active = ? WHERE id = ?")
        ->execute([$newStatus, $studentId]);

    // Also update active enrollment if deactivating
    if (!$newStatus) {
        $pdo->prepare("
            UPDATE tblenrollment
            SET is_active = 0, enrollment_status = 'DROPPED'
            WHERE student_id = ? AND is_active = 1
        ")->execute([$studentId]);
    }

    echo json_encode([
        'success' => true,
        'message' => "{$student['fname']} {$student['lname']} has been {$action}.",
        'is_active' => $newStatus,
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}