<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

function resolveTable(PDO $pdo, array $candidates): ?string
{
    $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN) ?: [];
    $map = [];

    foreach ($tables as $table) {
        $map[strtolower($table)] = $table;
    }

    foreach ($candidates as $candidate) {
        $key = strtolower($candidate);
        if (isset($map[$key])) {
            return $map[$key];
        }
    }

    return null;
}

function hasColumn(PDO $pdo, string $table, string $column): bool
{
    $stmt = $pdo->prepare("SHOW COLUMNS FROM `{$table}` LIKE ?");
    $stmt->execute([$column]);
    return (bool) $stmt->fetch(PDO::FETCH_ASSOC);
}

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($id <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid student ID']);
    exit;
}

try {
    $studentTable = resolveTable($pdo, ['tblStudentInfo', 'tblStudents', 'tblstudents']);

    if (!$studentTable) {
        echo json_encode(['success' => false, 'error' => 'Student table not found']);
        exit;
    }

    $pdo->beginTransaction();

    $stmt = $pdo->prepare("
        SELECT id" .
        (hasColumn($pdo, $studentTable, 'is_active') ? ", is_active" : ", 1 AS is_active") .
        (hasColumn($pdo, $studentTable, 'is_archived') ? ", is_archived" : ", 0 AS is_archived") . "
        FROM `{$studentTable}`
        WHERE id = ?
        LIMIT 1
        FOR UPDATE
    ");
    $stmt->execute([$id]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'error' => 'Student not found']);
        exit;
    }

    $currentState = (int) ($student['is_active'] ?? 0);
    $newState = $currentState === 1 ? 0 : 1;
    $newArchive = $newState === 1 ? 0 : 1;
    $accountStatus = $newState === 1 ? 'Active' : 'Inactive';

    $fields = [];
    $params = [];

    if (hasColumn($pdo, $studentTable, 'is_active')) {
        $fields[] = 'is_active = ?';
        $params[] = $newState;
    }

    if (hasColumn($pdo, $studentTable, 'is_archived')) {
        $fields[] = 'is_archived = ?';
        $params[] = $newArchive;
    }

    if (hasColumn($pdo, $studentTable, 'archived_at')) {
        $fields[] = 'archived_at = ?';
        $params[] = $newArchive ? date('Y-m-d H:i:s') : null;
    }

    if (hasColumn($pdo, $studentTable, 'date_archived')) {
        $fields[] = 'date_archived = ?';
        $params[] = $newArchive ? date('Y-m-d H:i:s') : null;
    }

    if (!empty($fields)) {
        $params[] = $id;

        $updateStudent = $pdo->prepare("
            UPDATE `{$studentTable}`
            SET " . implode(', ', $fields) . "
            WHERE id = ?
        ");
        $updateStudent->execute($params);
    }

    $findUser = $pdo->prepare("
        SELECT id
        FROM tblusers
        WHERE reference_id = ?
          AND role_id = 3
        LIMIT 1
        FOR UPDATE
    ");
    $findUser->execute([$id]);
    $userId = $findUser->fetchColumn();

    if (!$userId) {
        $fallbackUser = $pdo->prepare("
            SELECT id
            FROM tblusers
            WHERE reference_id = ?
              AND role_id NOT IN (1, 2)
            LIMIT 1
            FOR UPDATE
        ");
        $fallbackUser->execute([$id]);
        $userId = $fallbackUser->fetchColumn();
    }

    if ($userId) {
        $updateUser = $pdo->prepare("
            UPDATE tblusers
            SET status = ?
            WHERE id = ?
        ");
        $updateUser->execute([$accountStatus, $userId]);
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => $newState === 1
            ? 'Student and linked account activated successfully.'
            : 'Student and linked account deactivated successfully.'
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    echo json_encode([
        'success' => false,
        'error' => 'Failed to update student status: ' . $e->getMessage()
    ]);
}