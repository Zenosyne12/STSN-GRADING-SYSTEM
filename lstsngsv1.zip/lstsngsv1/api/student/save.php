<?php
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/account_credentials.php';

$rootUrl = rtrim(dirname(dirname(dirname($_SERVER['SCRIPT_NAME']))), '/');

function redirectBack(bool $success, string $msg, int $id = 0, bool $redirectToStudentList = false, ?string $toastParam = null): void
{
    global $rootUrl;
    if ($redirectToStudentList) {
        $base = "{$rootUrl}/student.php";
    } else {
        $base = $id > 0
            ? "{$rootUrl}/student_form.php?id={$id}"
            : "{$rootUrl}/student_form.php";
    }

    $param = $toastParam ?: ($success ? 'msg' : 'error');
    $separator = (strpos($base, '?') === false) ? '?' : '&';
    header("Location: {$base}{$separator}{$param}=" . urlencode($msg));
    exit;
}

$id     = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$isEdit = $id > 0;

$required = [
    'lrn', 'fname', 'lname', 'birthdate', 'gender',
    'fathers_name', 'fathers_contact_num',
    'mothers_name', 'mothers_contact_num',
    'guardian_name', 'guardian_contact_num',
    'street_name', 'country_id', 'region_id', 'province_id', 'city_id', 'barangay_id', 'postal_code',
    'grade_level_id'
];

foreach ($required as $field) {
    if (empty($_POST[$field])) {
        redirectBack(false, "Field '{$field}' is required.", $id);
    }
}

$lrn          = trim($_POST['lrn']);
$fname        = trim($_POST['fname']);
$mname        = trim($_POST['mname'] ?? '');
$lname        = trim($_POST['lname']);
$birthdate    = $_POST['birthdate'];
$gender       = $_POST['gender'];
$citizenship  = trim($_POST['citizenship'] ?? '');
$email        = trim($_POST['email'] ?? '');
$gradeLevelId = (int)$_POST['grade_level_id'];
$strand       = trim($_POST['strand'] ?? '');

$fathersName     = trim($_POST['fathers_name']);
$fathersContact  = trim($_POST['fathers_contact_num']);
$mothersName     = trim($_POST['mothers_name']);
$mothersContact  = trim($_POST['mothers_contact_num']);
$guardianName    = trim($_POST['guardian_name']);
$guardianContact = trim($_POST['guardian_contact_num']);

$streetName = trim($_POST['street_name']);
$postalCode = trim($_POST['postal_code'] ?? '');
$countryId  = (int)$_POST['country_id'];
$regionId   = (int)$_POST['region_id'];
$provinceId = (int)$_POST['province_id'];
$cityId     = (int)$_POST['city_id'];
$barangayId = (int)$_POST['barangay_id'];

if (!preg_match('/^\d{12}$/', $lrn)) {
    redirectBack(false, 'LRN must be exactly 12 digits.', $id);
}

if ($email === '') {
    redirectBack(false, 'Email address is required before account creation.', $id);
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    redirectBack(false, 'Please provide a valid email address.', $id);
}

$linkedStudentUserId = 0;
if ($isEdit) {
    $studentUserStmt = $pdo->prepare("SELECT id FROM tblusers WHERE role_id = 3 AND reference_id = ? LIMIT 1");
    $studentUserStmt->execute([$id]);
    $linkedStudentUserId = (int)($studentUserStmt->fetchColumn() ?: 0);
}

try {
    stsnAssertStudentEmailAvailable($pdo, $email, $id, $linkedStudentUserId);
} catch (Throwable $emailError) {
    redirectBack(false, $emailError->getMessage(), $id);
}

function validateAddressHierarchy(PDO $pdo, int $countryId, int $regionId, int $provinceId, int $cityId, int $barangayId): bool
{
    $stmt = $pdo->prepare("
        SELECT b.city_id, c.province_id, p.region_id, r.country_id
        FROM tblbarangay b
        JOIN tblcity c ON c.id = b.city_id
        JOIN tblprovince p ON p.id = c.province_id
        JOIN tblregion r ON r.id = p.region_id
        WHERE b.id = ?
        LIMIT 1
    ");
    $stmt->execute([$barangayId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row
        && (int)$row['city_id'] === $cityId
        && (int)$row['province_id'] === $provinceId
        && (int)$row['region_id'] === $regionId
        && (int)$row['country_id'] === $countryId;
}

if (!validateAddressHierarchy($pdo, $countryId, $regionId, $provinceId, $cityId, $barangayId)) {
    redirectBack(false, 'Selected address hierarchy is invalid. Please reselect country, region, province, city, and barangay.', $id);
}

if (!preg_match('/^\d{4}$/', $postalCode)) {
    redirectBack(false, 'Postal code must be exactly 4 digits.', $id);
}

$postalStmt = $pdo->prepare('SELECT postal_code FROM tblbarangay WHERE id = ? LIMIT 1');
$postalStmt->execute([$barangayId]);
$expectedPostalCode = (string) $postalStmt->fetchColumn();

if ($expectedPostalCode === '' || $postalCode !== $expectedPostalCode) {
    redirectBack(false, 'Postal code does not match the selected barangay.', $id);
}




function resolveAcademicYearId(PDO $pdo): int
{
    
    $row = $pdo->query(
        "SELECT id FROM tblacademicyear WHERE is_active = 1 ORDER BY id DESC LIMIT 1"
    )->fetch(PDO::FETCH_ASSOC);

    if ($row) return (int)$row['id'];

    
    $row = $pdo->query(
        "SELECT id FROM tblacademicyear ORDER BY id DESC LIMIT 1"
    )->fetch(PDO::FETCH_ASSOC);

    return $row ? (int)$row['id'] : 0;
}

try {
    $pdo->beginTransaction();

    if ($isEdit) {
        
        $check = $pdo->prepare("SELECT COUNT(*) FROM tblstudents WHERE lrn = ? AND id <> ?");
        $check->execute([$lrn, $id]);
        if ((int)$check->fetchColumn() > 0) {
            $pdo->rollBack();
            header("Location: {$rootUrl}/student_form.php?id={$id}&duplicate=1");
            exit;
        }

        
        $stmt = $pdo->prepare("
            UPDATE tblstudents SET
                lrn                  = ?,
                fname                = ?,
                mname                = ?,
                lname                = ?,
                birthdate            = ?,
                gender               = ?,
                citizenship          = ?,
                grade_level_id       = ?,
                strand               = ?,
                fathers_name         = ?,
                fathers_contact_num  = ?,
                mothers_name         = ?,
                mothers_contact_num  = ?,
                guardian_name        = ?,
                guardian_contact_num = ?,
                email                = ?,
                street_name          = ?,
                postal_code          = ?,
                barangay_id          = ?,
                city_id              = ?,
                region_id            = ?,
                province_id          = ?,
                country_id           = ?
            WHERE id = ?
        ");
        $stmt->execute([
            $lrn, $fname, $mname, $lname, $birthdate, $gender, $citizenship,
            $gradeLevelId, $strand,
            $fathersName, $fathersContact, $mothersName, $mothersContact,
            $guardianName, $guardianContact,
            $email,
            $streetName, $postalCode, $barangayId,
            $cityId, $regionId, $provinceId, $countryId,
            $id
        ]);

        if ($linkedStudentUserId > 0) {
            $syncUser = $pdo->prepare("UPDATE tblusers SET username = ? WHERE id = ? AND role_id = 3");
            $syncUser->execute([$email, $linkedStudentUserId]);
        }

        
        $academicYearId = resolveAcademicYearId($pdo);

        if ($academicYearId) {
            
            $upEnroll = $pdo->prepare("
                UPDATE tblenrollment
                SET grade_level_id = ?
                WHERE student_id = ? AND academic_year_id = ?
            ");
            $upEnroll->execute([$gradeLevelId, $id, $academicYearId]);

            
            if ($upEnroll->rowCount() === 0) {
                $pdo->prepare("
                    INSERT IGNORE INTO tblenrollment
                        (student_id, academic_year_id, grade_level_id, enrollment_status, is_active)
                    VALUES (?, ?, ?, 'ENROLLED', 1)
                ")->execute([$id, $academicYearId, $gradeLevelId]);
            }
        }

        $pdo->commit();
        try {
            logActivity($pdo, 'Students', 'UPDATE', 'student', $id,
                'Updated student ' . trim($fname . ' ' . $lname) . ' (LRN ' . $lrn . ')');
        } catch (Throwable $e) {}
        redirectBack(true, 'Student updated successfully.', $id, true);

    } else {
        
        $check = $pdo->prepare("SELECT COUNT(*) FROM tblstudents WHERE lrn = ?");
        $check->execute([$lrn]);
        if ((int)$check->fetchColumn() > 0) {
            $pdo->rollBack();
            header("Location: {$rootUrl}/student_form.php?duplicate=1");
            exit;
        }

        $stmt = $pdo->prepare("
            INSERT INTO tblstudents (
                lrn, fname, mname, lname, birthdate, gender, citizenship,
                grade_level_id, strand,
                fathers_name, fathers_contact_num,
                mothers_name, mothers_contact_num,
                guardian_name, guardian_contact_num,
                email,
                street_name, postal_code, barangay_id,
                city_id, region_id, province_id, country_id,
                is_active
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)
        ");
        $stmt->execute([
            $lrn, $fname, $mname, $lname, $birthdate, $gender, $citizenship,
            $gradeLevelId, $strand,
            $fathersName, $fathersContact, $mothersName, $mothersContact,
            $guardianName, $guardianContact,
            $email,
            $streetName, $postalCode, $barangayId,
            $cityId, $regionId, $provinceId, $countryId
        ]);

        $newStudentId = (int)$pdo->lastInsertId();

        
        $academicYearId = resolveAcademicYearId($pdo);

        if ($academicYearId) {
            $pdo->prepare("
                INSERT IGNORE INTO tblenrollment
                    (student_id, academic_year_id, grade_level_id, enrollment_status, is_active)
                VALUES (?, ?, ?, 'ENROLLED', 1)
            ")->execute([$newStudentId, $academicYearId, $gradeLevelId]);
        }

        $credentials = stsnCreateStudentAccount($pdo, $newStudentId, [
            'email' => $email,
            'fname' => $fname,
            'mname' => $mname,
            'lname' => $lname,
            'birthdate' => $birthdate,
        ]);

        $pdo->commit();
        try {
            logActivity($pdo, 'Students', 'CREATE', 'student', $newStudentId,
                'Created student ' . trim($fname . ' ' . $lname) . ' (LRN ' . $lrn . ')');
        } catch (Throwable $e) {}


        $emailSent = false;
        try {
            $emailSent = stsnSendCredentialsEmail(
                $credentials['email'],
                $credentials['full_name'],
                $credentials['username'],
                $credentials['temporary_password']
            );
        } catch (Throwable $mailError) {
            $emailSent = false;
        }

        if ($emailSent) {
            redirectBack(true, 'Student record and mobile account created successfully. Credentials sent to email.', 0, true);
        }

        redirectBack(true, 'Account created successfully, but email sending failed. Please resend credentials.', 0, true, 'warning');
    }

} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    redirectBack(false, 'Database error: ' . $e->getMessage(), $id);
}
