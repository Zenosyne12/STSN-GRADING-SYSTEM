<?php
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

$rootUrl = rtrim(dirname(dirname(dirname($_SERVER['SCRIPT_NAME']))), '/');

function redirectBack(bool $success, string $msg, int $id = 0): void
{
    global $rootUrl;
    $base  = $id > 0
        ? "{$rootUrl}/student_form.php?id={$id}"
        : "{$rootUrl}/student_form.php";
    $param = $success ? 'msg' : 'error';
    $sep = (strpos($base, '?') !== false) ? '&' : '?';
    header("Location: {$base}{$sep}{$param}=" . urlencode($msg));
    exit;
}

$id     = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$isEdit = $id > 0;

$required = [
    'lrn', 'fname', 'lname', 'birthdate', 'gender',
    'fathers_name', 'fathers_contact_num',
    'mothers_name', 'mothers_contact_num',
    'guardian_name', 'guardian_contact_num',
    'street_name', 'country_id', 'region_id', 'province_id', 'city_id', 'barangay_id',
    'grade_level_id'
];

foreach ($required as $field) {
    if (empty($_POST[$field])) {
        redirectBack(false, "Field '{$field}' is required.", $id);
    }
}

$lrn          = trim($_POST['lrn']);
$fname        = trim($_POST['fname']);
$mname        = trim($_POST['mname'] ?? '');
$lname        = trim($_POST['lname']);
$birthdate    = $_POST['birthdate'];
$gender       = $_POST['gender'];
$citizenship  = trim($_POST['citizenship'] ?? '');
$gradeLevelId = (int)$_POST['grade_level_id'];
$strand       = trim($_POST['strand'] ?? '');

// ── NEW: optional email, stored as NULL when blank ──
$email = trim($_POST['email'] ?? '');
$email = $email !== '' ? $email : null;

$fathersName     = trim($_POST['fathers_name']);
$fathersContact  = trim($_POST['fathers_contact_num']);
$mothersName     = trim($_POST['mothers_name']);
$mothersContact  = trim($_POST['mothers_contact_num']);
$guardianName    = trim($_POST['guardian_name']);
$guardianContact = trim($_POST['guardian_contact_num']);

$streetName = trim($_POST['street_name']);
$postalCode = trim($_POST['postal_code'] ?? '');
$countryId  = (int)$_POST['country_id'];
$regionId   = (int)$_POST['region_id'];
$provinceId = (int)$_POST['province_id'];
$cityId     = (int)$_POST['city_id'];
$barangayId = (int)$_POST['barangay_id'];

if (!preg_match('/^\d{12}$/', $lrn)) {
    redirectBack(false, 'LRN must be exactly 12 digits.', $id);
}

// ── Helper: get active OR latest academic year ────────────────────────────────
function resolveAcademicYearId(PDO $pdo): int
{
    $row = $pdo->query(
        "SELECT id FROM tblacademicyear WHERE is_active = 1 ORDER BY id DESC LIMIT 1"
    )->fetch(PDO::FETCH_ASSOC);
    if ($row) return (int)$row['id'];

    $row = $pdo->query(
        "SELECT id FROM tblacademicyear ORDER BY id DESC LIMIT 1"
    )->fetch(PDO::FETCH_ASSOC);
    return $row ? (int)$row['id'] : 0;
}

try {
    $pdo->beginTransaction();

    if ($isEdit) {
        // Check LRN uniqueness (exclude self)
        $check = $pdo->prepare("SELECT COUNT(*) FROM tblstudents WHERE lrn = ? AND id <> ?");
        $check->execute([$lrn, $id]);
        if ((int)$check->fetchColumn() > 0) {
            $pdo->rollBack();
            header("Location: {$rootUrl}/student_form.php?id={$id}&duplicate=1");
            exit;
        }

        // Update tblstudents (now including email)
        $stmt = $pdo->prepare("
            UPDATE tblstudents SET
                lrn                  = ?,
                fname                = ?,
                mname                = ?,
                lname                = ?,
                birthdate            = ?,
                gender               = ?,
                citizenship          = ?,
                grade_level_id       = ?,
                strand               = ?,
                fathers_name         = ?,
                fathers_contact_num  = ?,
                mothers_name         = ?,
                mothers_contact_num  = ?,
                guardian_name        = ?,
                guardian_contact_num = ?,
                street_name          = ?,
                postal_code          = ?,
                barangay_id          = ?,
                email                = ?
            WHERE id = ?
        ");
        $stmt->execute([
            $lrn, $fname, $mname, $lname, $birthdate, $gender, $citizenship,
            $gradeLevelId, $strand,
            $fathersName, $fathersContact, $mothersName, $mothersContact,
            $guardianName, $guardianContact,
            $streetName, $postalCode, $barangayId,
            $email,   // ← added
            $id
        ]);

        $academicYearId = resolveAcademicYearId($pdo);
        if ($academicYearId) {
            $upEnroll = $pdo->prepare("
                UPDATE tblenrollment
                SET grade_level_id = ?
                WHERE student_id = ? AND academic_year_id = ?
            ");
            $upEnroll->execute([$gradeLevelId, $id, $academicYearId]);

            if ($upEnroll->rowCount() === 0) {
                $pdo->prepare("
                    INSERT IGNORE INTO tblenrollment
                        (student_id, academic_year_id, grade_level_id, enrollment_status, is_active)
                    VALUES (?, ?, ?, 'ENROLLED', 1)
                ")->execute([$id, $academicYearId, $gradeLevelId]);
            }
        }

        $pdo->commit();
        redirectBack(true, 'Student updated successfully.', $id);

    } else {
        // Check LRN uniqueness for new student
        $check = $pdo->prepare("SELECT COUNT(*) FROM tblstudents WHERE lrn = ?");
        $check->execute([$lrn]);
        if ((int)$check->fetchColumn() > 0) {
            $pdo->rollBack();
            header("Location: {$rootUrl}/student_form.php?duplicate=1");
            exit;
        }

        $stmt = $pdo->prepare("
            INSERT INTO tblstudents (
                lrn, fname, mname, lname, birthdate, gender, citizenship,
                grade_level_id, strand,
                fathers_name, fathers_contact_num,
                mothers_name, mothers_contact_num,
                guardian_name, guardian_contact_num,
                street_name, postal_code, barangay_id,
                email, is_active
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)
        ");
        $stmt->execute([
            $lrn, $fname, $mname, $lname, $birthdate, $gender, $citizenship,
            $gradeLevelId, $strand,
            $fathersName, $fathersContact, $mothersName, $mothersContact,
            $guardianName, $guardianContact,
            $streetName, $postalCode, $barangayId,
            $email,   // ← added
        ]);

        $newStudentId = (int)$pdo->lastInsertId();

        $academicYearId = resolveAcademicYearId($pdo);
        if ($academicYearId) {
            $pdo->prepare("
                INSERT IGNORE INTO tblenrollment
                    (student_id, academic_year_id, grade_level_id, enrollment_status, is_active)
                VALUES (?, ?, ?, 'ENROLLED', 1)
            ")->execute([$newStudentId, $academicYearId, $gradeLevelId]);
        }

        $pdo->commit();
        redirectBack(true, 'Student added successfully.', $newStudentId);
    }

} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    redirectBack(false, 'Database error: ' . $e->getMessage(), $id);
}