<?php
declare(strict_types=1);

$authFile = __DIR__ . '/../../includes/auth.php';
if (file_exists($authFile)) {
    require_once $authFile;
    if (function_exists('requireAdmin')) {
        requireAdmin();
    }
}

require_once __DIR__ . '/../shared/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../../student.php');
    exit;
}

function clean(?string $value): string
{
    return trim((string) $value);
}

function redirectToForm(int $id = 0, array $params = []): void
{
    $url = '../../student_form.php';

    if ($id > 0) {
        $params = array_merge(['id' => $id], $params);
    }

    if (!empty($params)) {
        $url .= '?' . http_build_query($params);
    }

    header('Location: ' . $url);
    exit;
}

$id = (int) ($_POST['id'] ?? 0);
$edit = $id > 0;

$lrn                  = clean($_POST['lrn'] ?? '');
$gradeLevelId         = (int) ($_POST['grade_level_id'] ?? 0);
$strand               = strtoupper(clean($_POST['strand'] ?? ''));
$fname                = clean($_POST['fname'] ?? '');
$mname                = clean($_POST['mname'] ?? '');
$lname                = clean($_POST['lname'] ?? '');
$birthdate            = clean($_POST['birthdate'] ?? '');
$gender               = clean($_POST['gender'] ?? '');
$citizenship          = clean($_POST['citizenship'] ?? '');
$fathersName          = clean($_POST['fathers_name'] ?? '');
$fathersContactNum    = clean($_POST['fathers_contact_num'] ?? '');
$mothersName          = clean($_POST['mothers_name'] ?? '');
$mothersContactNum    = clean($_POST['mothers_contact_num'] ?? '');
$guardianName         = clean($_POST['guardian_name'] ?? '');
$guardianContactNum   = clean($_POST['guardian_contact_num'] ?? '');
$streetName           = clean($_POST['street_name'] ?? '');
$countryId            = (int) ($_POST['country_id'] ?? 0);
$regionId             = (int) ($_POST['region_id'] ?? 0);
$provinceId           = (int) ($_POST['province_id'] ?? 0);
$cityId               = (int) ($_POST['city_id'] ?? 0);
$barangayId           = (int) ($_POST['barangay_id'] ?? 0);
$postalCode           = clean($_POST['postal_code'] ?? '');

$requiredTextFields = [
    'LRN' => $lrn,
    'First Name' => $fname,
    'Last Name' => $lname,
    'Birthdate' => $birthdate,
    'Sex' => $gender,
    "Father's Name" => $fathersName,
    "Father's Contact" => $fathersContactNum,
    "Mother's Name" => $mothersName,
    "Mother's Contact" => $mothersContactNum,
    'Guardian Name' => $guardianName,
    'Guardian Contact' => $guardianContactNum,
    'Street / House No.' => $streetName,
];

foreach ($requiredTextFields as $label => $value) {
    if ($value === '') {
        redirectToForm($id, ['error' => $label . ' is required.']);
    }
}

$requiredNumericFields = [
    'Grade Level' => $gradeLevelId,
    'Country' => $countryId,
    'Region' => $regionId,
    'Province' => $provinceId,
    'City' => $cityId,
    'Barangay' => $barangayId,
];

foreach ($requiredNumericFields as $label => $value) {
    if ($value <= 0) {
        redirectToForm($id, ['error' => $label . ' is required.']);
    }
}

if (!preg_match('/^\d{12}$/', $lrn)) {
    redirectToForm($id, ['error' => 'LRN must be exactly 12 digits.']);
}

if (!in_array($gender, ['Male', 'Female'], true)) {
    redirectToForm($id, ['error' => 'Please select a valid sex.']);
}

$birthdateObj = DateTime::createFromFormat('Y-m-d', $birthdate);
if (!$birthdateObj || $birthdateObj->format('Y-m-d') !== $birthdate) {
    redirectToForm($id, ['error' => 'Please enter a valid birthdate.']);
}

if ($birthdateObj > new DateTime('today')) {
    redirectToForm($id, ['error' => 'Birthdate cannot be in the future.']);
}

try {
    $gradeStmt = $pdo->prepare('SELECT grade_level_name FROM tblGradeLevel WHERE id = ? LIMIT 1');
    $gradeStmt->execute([$gradeLevelId]);
    $gradeName = (string) $gradeStmt->fetchColumn();

    if ($gradeName === '') {
        redirectToForm($id, ['error' => 'Selected grade level is invalid.']);
    }

    $isSeniorHigh = preg_match('/grade\s*(11|12)\b/i', $gradeName) === 1;

    if ($isSeniorHigh) {
        $allowedStrands = ['ABM', 'GAS', 'STEAM', 'HUMSS'];

        if ($strand === '' || !in_array($strand, $allowedStrands, true)) {
            redirectToForm($id, ['error' => 'Please select a valid strand for Grade 11 or Grade 12.']);
        }
    } else {
        $strand = null;
    }

    $dupSql = 'SELECT COUNT(*) FROM tblstudents WHERE lrn = ?';
    $dupParams = [$lrn];

    if ($edit) {
        $dupSql .= ' AND id <> ?';
        $dupParams[] = $id;
    }

    $dupStmt = $pdo->prepare($dupSql);
    $dupStmt->execute($dupParams);

    if ((int) $dupStmt->fetchColumn() > 0) {
        redirectToForm($id, ['duplicate' => 1]);
    }

    if ($edit) {
        $checkStmt = $pdo->prepare('SELECT id FROM tblstudents WHERE id = ? LIMIT 1');
        $checkStmt->execute([$id]);

        if (!$checkStmt->fetchColumn()) {
            redirectToForm(0, ['error' => 'Student record not found.']);
        }

        $sql = 'UPDATE tblstudents SET
                    lrn = ?,
                    grade_level_id = ?,
                    strand = ?,
                    fname = ?,
                    mname = ?,
                    lname = ?,
                    birthdate = ?,
                    gender = ?,
                    citizenship = ?,
                    fathers_name = ?,
                    fathers_contact_num = ?,
                    mothers_name = ?,
                    mothers_contact_num = ?,
                    guardian_name = ?,
                    guardian_contact_num = ?,
                    street_name = ?,
                    country_id = ?,
                    region_id = ?,
                    province_id = ?,
                    city_id = ?,
                    barangay_id = ?,
                    postal_code = ?
                WHERE id = ?';

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $lrn,
            $gradeLevelId,
            $strand,
            $fname,
            $mname,
            $lname,
            $birthdate,
            $gender,
            $citizenship,
            $fathersName,
            $fathersContactNum,
            $mothersName,
            $mothersContactNum,
            $guardianName,
            $guardianContactNum,
            $streetName,
            $countryId,
            $regionId,
            $provinceId,
            $cityId,
            $barangayId,
            $postalCode,
            $id
        ]);

        redirectToForm($id, ['msg' => 'Student updated successfully.']);
    }

    $sql = 'INSERT INTO tblstudents (
                lrn,
                grade_level_id,
                strand,
                fname,
                mname,
                lname,
                birthdate,
                gender,
                citizenship,
                fathers_name,
                fathers_contact_num,
                mothers_name,
                mothers_contact_num,
                guardian_name,
                guardian_contact_num,
                street_name,
                country_id,
                region_id,
                province_id,
                city_id,
                barangay_id,
                postal_code,
                is_active
            ) VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1
            )';

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $lrn,
        $gradeLevelId,
        $strand,
        $fname,
        $mname,
        $lname,
        $birthdate,
        $gender,
        $citizenship,
        $fathersName,
        $fathersContactNum,
        $mothersName,
        $mothersContactNum,
        $guardianName,
        $guardianContactNum,
        $streetName,
        $countryId,
        $regionId,
        $provinceId,
        $cityId,
        $barangayId,
        $postalCode
    ]);

    $newId = (int) $pdo->lastInsertId();

    redirectToForm($newId, ['msg' => 'Student added successfully.']);
} catch (PDOException $e) {
    $errorMessage = 'Unable to save student right now.';

    if (stripos($e->getMessage(), 'Unknown column') !== false && stripos($e->getMessage(), 'strand') !== false) {
        $errorMessage = 'Please add the strand column in tblstudents first.';
    }

    redirectToForm($id, ['error' => $errorMessage]);
} catch (Throwable $e) {
    redirectToForm($id, ['error' => 'Something went wrong while saving the student.']);
}