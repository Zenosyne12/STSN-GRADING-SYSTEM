<?php





require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $lrns = $pdo->query("SELECT lrn FROM tblstudents WHERE lrn IS NOT NULL AND lrn != ''")
                ->fetchAll(PDO::FETCH_COLUMN);
    echo json_encode(['success' => true, 'lrns' => array_values($lrns)]);
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'lrns' => [], 'message' => $e->getMessage()]);
}