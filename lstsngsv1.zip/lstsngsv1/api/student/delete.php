<?php
require_once '../shared/db_connect.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id) {
    $stmt = $pdo->prepare('DELETE FROM tblStudents WHERE id = ?');
    $stmt->execute([$id]);
}

header('Location: ../../student.php?deleted=1');
exit;