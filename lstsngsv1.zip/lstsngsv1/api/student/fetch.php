<?php
require_once __DIR__.'/../shared/db_connect.php';

header('Content-Type: application/json; charset=utf-8');

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare(
   "SELECT id, lrn, fname, mname, lname, birthdate, gender, citizenship, grade_level_name,
           fathers_name, fathers_contact_num, mothers_name, mothers_contact_num,
           guardian_name, guardian_contact_num, street_name, postal_code,
           barangay_name, city_name, province_name, region_name, country_name,
           TIMESTAMPDIFF(YEAR, birthdate, CURDATE()) AS age,
           CONCAT_WS(', ', street_name, barangay_name, city_name, province_name, region_name, country_name) AS full_address,
           is_active
    FROM vwStudentInfo
    WHERE id = ?");
$stmt->execute([$id]);
echo json_encode($stmt->fetch(PDO::FETCH_ASSOC) ?: []);