<?php
/**
 * archive-create.php
 * Moves a student's active enrollment into tblstudent_archive.
 *
 * POST body (JSON):
 * {
 *   "enrollment_id": 36,
 *   "status": "PROMOTED",
 *   "final_average": 88.50     <- optional, pass null if not known
 * }
 */
ob_start();
require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';
ob_end_clean();
header('Content-Type: application/json');

$data         = json_decode(file_get_contents('php://input'), true);
$enrollmentId = intval($data['enrollment_id'] ?? 0);
$status       = strtoupper(trim($data['status'] ?? ''));
$finalAverage = (isset($data['final_average']) && $data['final_average'] !== null && $data['final_average'] !== '')
                ? floatval($data['final_average'])
                : null;

$allowed = ['PROMOTED', 'RETAINED', 'DROPPED', 'TRANSFERRED', 'GRADUATED'];

if (!$enrollmentId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'enrollment_id is required.']);
    exit;
}
if (!in_array($status, $allowed, true)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid status. Allowed: ' . implode(', ', $allowed)]);
    exit;
}

try {
    $pdo->beginTransaction();

    // 1. Fetch the active enrollment row
    $stmt = $pdo->prepare(
        "SELECT * FROM tblenrollment WHERE id = ? AND is_active = 1 LIMIT 1"
    );
    $stmt->execute([$enrollmentId]);
    $enrollment = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$enrollment) {
        throw new Exception('Active enrollment record not found.');
    }

    // 2. Prevent duplicate archive for same student + year
    $dupCheck = $pdo->prepare(
        "SELECT id FROM tblstudent_archive
         WHERE student_id = ? AND academic_year_id = ? LIMIT 1"
    );
    $dupCheck->execute([$enrollment['student_id'], $enrollment['academic_year_id']]);
    if ($dupCheck->fetch()) {
        throw new Exception('This student already has an archive record for this academic year.');
    }

    // 3. Logged-in admin ID
    $archivedBy = $_SESSION['user_id'] ?? $_SESSION['admin_id'] ?? null;

    // 4. Insert into tblstudent_archive
    $insertStmt = $pdo->prepare(
        "INSERT INTO tblstudent_archive
            (student_id, academic_year_id, grade_level_id, final_average, status, archived_by)
         VALUES (?, ?, ?, ?, ?, ?)"
    );
    $insertStmt->execute([
        $enrollment['student_id'],
        $enrollment['academic_year_id'],
        $enrollment['grade_level_id'],
        $finalAverage,
        $status,
        $archivedBy,
    ]);

    // 5. Mark enrollment as inactive + set final status
    $updateStmt = $pdo->prepare(
        "UPDATE tblenrollment
         SET is_active = 0, enrollment_status = ?
         WHERE id = ?"
    );
    $updateStmt->execute([$status, $enrollmentId]);

    // 6. Mark student as inactive in tblstudents
    $updateStudent = $pdo->prepare(
        "UPDATE tblstudents SET is_active = 0 WHERE id = ?"
    );
    $updateStudent->execute([$enrollment['student_id']]);

    $pdo->commit();
    echo json_encode(['success' => true, 'message' => 'Student archived successfully.']);

} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}