<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();
require_once __DIR__ . '/../../api/shared/db_connect.php';

$yearId = (int)($_GET['year_id'] ?? 0);
if ($yearId <= 0) {
    $yearId = (int)($pdo->query("SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1")->fetchColumn() ?: 0);
}

if ($yearId <= 0) {
    echo json_encode(['success' => false, 'terms' => []]);
    exit;
}

try {
    $stmt = $pdo->prepare("
        SELECT id, academic_year_id, term_number, term_label, term_type,
               start_date, end_date, is_active, is_closed
        FROM tblconfig_terms
        WHERE academic_year_id = ?
        ORDER BY term_number ASC
    ");
    $stmt->execute([$yearId]);
    $terms = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['success' => true, 'terms' => $terms]);
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'terms' => [], 'error' => $e->getMessage()]);
}
