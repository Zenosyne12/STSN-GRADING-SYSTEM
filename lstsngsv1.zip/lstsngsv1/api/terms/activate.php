<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();

if (!in_array((int) ($_SESSION['role_id'] ?? 0), [1, 4], true)) {
    jsonAuthError(403, 'Administrator access is required.');
}

require_once __DIR__ . '/../shared/db_connect.php';

function respond(bool $success, string $message, int $statusCode = 200): void
{
    http_response_code($statusCode);
    echo json_encode([
        'status' => $success ? 'success' : 'error',
        'success' => $success,
        'message' => $message,
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(false, 'POST requests are required.', 405);
}

$input = json_decode(file_get_contents('php://input'), true);
$termId = is_array($input) ? (int) ($input['term_id'] ?? 0) : 0;
$requestedYearId = is_array($input) ? (int) ($input['academic_year_id'] ?? 0) : 0;

if ($termId <= 0) {
    respond(false, 'A valid term is required.', 400);
}

try {
    $pdo->beginTransaction();

    $termYearStmt = $pdo->prepare('SELECT academic_year_id FROM tblconfig_terms WHERE id = ?');
    $termYearStmt->execute([$termId]);
    $termYearId = $termYearStmt->fetchColumn();
    if ($termYearId === false) {
        $pdo->rollBack();
        respond(false, 'Term not found.', 404);
    }
    $yearId = (int) $termYearId;
    if ($requestedYearId > 0 && $requestedYearId !== $yearId) {
        $pdo->rollBack();
        respond(false, 'Term not found for the specified academic year.', 404);
    }

    $yearStmt = $pdo->prepare('SELECT is_active FROM tblacademicyear WHERE id = ? FOR UPDATE');
    $yearStmt->execute([$yearId]);
    $year = $yearStmt->fetch(PDO::FETCH_ASSOC);
    if (!$year) {
        $pdo->rollBack();
        respond(false, 'Academic year not found.', 404);
    }
    if ((int) $year['is_active'] !== 1) {
        $pdo->rollBack();
        respond(false, 'The academic year must be active before activating a term.', 409);
    }

    $termStmt = $pdo->prepare('
        SELECT id, academic_year_id, term_number, is_closed
        FROM tblconfig_terms
        WHERE id = ?
        FOR UPDATE
    ');
    $termStmt->execute([$termId]);
    $term = $termStmt->fetch(PDO::FETCH_ASSOC);
    if (!$term || (int) $term['academic_year_id'] !== $yearId) {
        $pdo->rollBack();
        respond(false, 'Term not found for the specified academic year.', 404);
    }

    $closePrevious = $pdo->prepare('
        UPDATE tblconfig_terms
        SET is_active = 0, is_closed = 1
        WHERE academic_year_id = ?
          AND is_active = 1
          AND id <> ?
    ');
    $closePrevious->execute([$yearId, $termId]);

    $activate = $pdo->prepare('
        UPDATE tblconfig_terms
        SET is_active = 1, is_closed = 0
        WHERE id = ? AND academic_year_id = ?
    ');
    $activate->execute([$termId, $yearId]);

    $pdo->commit();
    respond(true, 'Term activated successfully.');
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('Term activation failed: ' . $e->getMessage());
    respond(false, 'Unable to activate the term.', 500);
}
