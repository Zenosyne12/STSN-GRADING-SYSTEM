<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();

if (!in_array((int) ($_SESSION['role_id'] ?? 0), [1, 4], true)) {
    jsonAuthError(403, 'Administrator access is required.');
}

require_once __DIR__ . '/../shared/db_connect.php';

function respond(bool $success, string $message, int $statusCode = 200): void
{
    http_response_code($statusCode);
    echo json_encode([
        'status' => $success ? 'success' : 'error',
        'success' => $success,
        'message' => $message,
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(false, 'POST requests are required.', 405);
}

$input = json_decode(file_get_contents('php://input'), true);
$termId = is_array($input) ? (int) ($input['term_id'] ?? 0) : 0;
if ($termId <= 0) {
    respond(false, 'A valid term is required.', 400);
}

try {
    $pdo->beginTransaction();

    $termStmt = $pdo->prepare('
        SELECT id, academic_year_id, term_number, is_closed
        FROM tblconfig_terms
        WHERE id = ?
        FOR UPDATE
    ');
    $termStmt->execute([$termId]);
    $term = $termStmt->fetch(PDO::FETCH_ASSOC);
    if (!$term) {
        $pdo->rollBack();
        respond(false, 'Term not found.', 404);
    }
    if ((int) $term['is_closed'] === 1) {
        $pdo->rollBack();
        respond(false, 'This term is already closed.', 409);
    }

    $close = $pdo->prepare('UPDATE tblconfig_terms SET is_closed = 1, is_active = 0 WHERE id = ?');
    $close->execute([$termId]);

    $lockGrades = $pdo->prepare('
        UPDATE tblgrades
        SET is_locked = 1
        WHERE academic_year_id = ? AND quarter = ?
    ');
    $lockGrades->execute([(int) $term['academic_year_id'], (int) $term['term_number']]);

    $pdo->commit();
    respond(true, 'Term closed and its grades locked successfully.');
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('Term close failed: ' . $e->getMessage());
    respond(false, 'Unable to close the term.', 500);
}
