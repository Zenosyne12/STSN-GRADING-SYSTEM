<?php
header('Content-Type: application/json');
session_start();
if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 4) {
    header('Location: ../../login.php');
    exit;
}
require_once __DIR__ . '/../shared/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../../SuperAdmin/Terms-Configuration.php');
    exit;
}

$action = $_POST['action'] ?? '';
$yearId = (int)($_POST['academic_year_id'] ?? 0);

try {
    if ($action === 'create' || $action === 'update') {
        $id = (int)($_POST['id'] ?? 0);
        $termNumber = (int)($_POST['term_number'] ?? 0);
        $termLabel = trim((string)($_POST['term_label'] ?? ''));
        $termType = strtoupper((string)($_POST['term_type'] ?? 'TRIMESTER'));
        $startDate = $_POST['start_date'] ?? null;
        $endDate = $_POST['end_date'] ?? null;
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $isClosed = isset($_POST['is_closed']) ? 1 : 0;
        
        if ($termNumber < 1 || $termNumber > 4 || $termLabel === '') {
            throw new Exception('Invalid input');
        }
        
        if ($action === 'create') {
            $stmt = $pdo->prepare("
                INSERT INTO tblconfig_terms 
                    (academic_year_id, term_number, term_label, term_type,
                     start_date, end_date, is_active, is_closed)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $yearId, $termNumber, $termLabel, $termType,
                $startDate ?: null, $endDate ?: null, $isActive, $isClosed
            ]);
        } else {
            $stmt = $pdo->prepare("
                UPDATE tblconfig_terms SET
                    term_number = ?, term_label = ?, term_type = ?,
                    start_date = ?, end_date = ?, is_active = ?, is_closed = ?
                WHERE id = ?
            ");
            $stmt->execute([
                $termNumber, $termLabel, $termType,
                $startDate ?: null, $endDate ?: null, $isActive, $isClosed,
                $id
            ]);
        }
    } elseif ($action === 'toggle') {
        $id = (int)($_POST['id'] ?? 0);
        $stmt = $pdo->prepare("UPDATE tblconfig_terms SET is_active = 1 - is_active WHERE id = ?");
        $stmt->execute([$id]);
    }
    
    header('Location: ../../SuperAdmin/Terms-Configuration.php?year_id=' . $yearId . '&msg=saved');
    exit;
} catch (Throwable $e) {
    error_log('Terms save error: ' . $e->getMessage());
    header('Location: ../../SuperAdmin/Terms-Configuration.php?year_id=' . $yearId . '&msg=error');
    exit;
}
