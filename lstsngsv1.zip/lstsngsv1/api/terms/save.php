<?php
header('Content-Type: application/json');
session_start();
if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 4) {
    header('Location: ../../login.php');
    exit;
}
require_once __DIR__ . '/../shared/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../../SuperAdmin/Terms-Configuration.php');
    exit;
}

$action = $_POST['action'] ?? '';
$yearId = (int)($_POST['academic_year_id'] ?? 0);

try {
    if ($action === 'create' || $action === 'update') {
        $id = (int)($_POST['id'] ?? 0);
        $termLabel = trim((string)($_POST['term_label'] ?? ''));
        $termType = strtoupper((string)($_POST['term_type'] ?? 'TRIMESTER'));
        if ($termLabel === '') {
            throw new Exception('Invalid input');
        }
        
        if ($action === 'create') {
            $activeYearId = (int) ($pdo->query("SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1")->fetchColumn() ?: 0);
            if ($yearId <= 0 || $yearId !== $activeYearId) {
                throw new Exception('The active academic year changed. Reload the page and try again.');
            }
            $numberStmt = $pdo->prepare('SELECT term_number FROM tblconfig_terms WHERE academic_year_id = ?');
            $numberStmt->execute([$yearId]);
            $usedNumbers = array_map('intval', $numberStmt->fetchAll(PDO::FETCH_COLUMN));
            $availableNumbers = array_values(array_diff([1, 2, 3, 4], $usedNumbers));
            $termNumber = $availableNumbers[0] ?? 0;
            if ($termNumber === 0) {
                throw new Exception('All term numbers are already configured for this academic year.');
            }
            $startDate = null;
            $endDate = null;
            $stmt = $pdo->prepare("
                INSERT INTO tblconfig_terms 
                    (academic_year_id, term_number, term_label, term_type,
                     start_date, end_date, is_active, is_closed)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $yearId, $termNumber, $termLabel, $termType, $startDate, $endDate, 0, 0
            ]);
        } else {
            $termStmt = $pdo->prepare('
                SELECT id FROM tblconfig_terms
                WHERE id = ? AND academic_year_id = ?
                LIMIT 1
            ');
            $termStmt->execute([$id, $yearId]);
            if (!$termStmt->fetchColumn()) {
                throw new Exception('Term not found for the active academic year.');
            }
            $stmt = $pdo->prepare("
                UPDATE tblconfig_terms SET
                    term_label = ?, term_type = ?
                WHERE id = ? AND academic_year_id = ?
            ");
            $stmt->execute([
                $termLabel, $termType, $id, $yearId
            ]);
        }
    } elseif ($action === 'toggle') {
        $id = (int)($_POST['id'] ?? 0);
        $stmt = $pdo->prepare("UPDATE tblconfig_terms SET is_active = 1 - is_active WHERE id = ?");
        $stmt->execute([$id]);
    }
    
    header('Location: ../../SuperAdmin/Terms-Configuration.php?year_id=' . $yearId . '&msg=saved');
    exit;
} catch (Throwable $e) {
    error_log('Terms save error: ' . $e->getMessage());
    header('Location: ../../SuperAdmin/Terms-Configuration.php?year_id=' . $yearId . '&msg=error');
    exit;
}
