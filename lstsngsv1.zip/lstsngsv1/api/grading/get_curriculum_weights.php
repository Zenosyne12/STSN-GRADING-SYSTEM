<?php
header('Content-Type: application/json');
require_once '../shared/db_connect.php';

function respond($success, $message, $data = [], $code = 200) {
    http_response_code($code);
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}

$grade_level_id = isset($_GET['grade_level_id']) ? (int)$_GET['grade_level_id'] : 0;
$subject_id = isset($_GET['subject_id']) ? (int)$_GET['subject_id'] : 0;

if ($grade_level_id <= 0 || $subject_id <= 0) {
    respond(false, 'grade_level_id and subject_id are required.', [], 400);
}

$weights = [
    'ww' => 40,
    'pt' => 40,
    'qa' => 20
];

$sql = "SELECT ww, pt, qa
        FROM tblcurriculum_grade
        WHERE grade_level_id = ?
          AND subject_id = ?
          AND is_active = 1
        LIMIT 1";

$stmt = $pdo->prepare($sql);
$stmt->execute([$grade_level_id, $subject_id]);

if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $weights = [
        'ww' => (float)$row['ww'],
        'pt' => (float)$row['pt'],
        'qa' => (float)$row['qa']
    ];
}
$stmt = null;

respond(true, 'Curriculum weights loaded successfully.', [
    'grade_level_id' => $grade_level_id,
    'subject_id' => $subject_id,
    'weights' => $weights
]);
?>