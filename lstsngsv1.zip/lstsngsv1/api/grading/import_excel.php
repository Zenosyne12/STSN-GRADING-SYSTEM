<?php
// api/grading/import_excel.php
// Imports PS, WS, total scores, initial, final, remarks
header('Content-Type: application/json');
require_once '../shared/db_connect.php';
session_start();

$teacherId = $_SESSION['teacher_id'] ?? 0;
if (!$teacherId) {
    echo json_encode(['success' => false, 'error' => 'Not authenticated']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    $sectionId = $input['section_id'] ?? 0;
    $subjectId = $input['subject_id'] ?? 0;
    $quarter = $input['quarter'] ?? 1;
    $students = $input['students'] ?? [];

    if (!$sectionId || !$subjectId || empty($students)) {
        echo json_encode(['success' => false, 'error' => 'Missing required data']);
        exit;
    }

    $ay_sql = "SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1";
    $ay_stmt = $pdo->query($ay_sql);
    $academic_year_id = $ay_stmt->fetchColumn() ?: 1;

    $pdo->beginTransaction();

    $savedCount = 0;
    foreach ($students as $student) {
        $scores = $student['scores'] ?? [];

        $checkStmt = $pdo->prepare("
            SELECT id FROM tblgrades 
            WHERE student_id = ? AND subject_id = ? AND section_id = ? AND quarter = ? AND academic_year_id = ?
        ");
        $checkStmt->execute([
            $student['student_id'], $subjectId, $sectionId, $quarter, $academic_year_id
        ]);
        $existing = $checkStmt->fetch();

        // Total scores
        $ww_total = floatval($scores['ww_total'] ?? 0);
        $pt_total = floatval($scores['pt_total'] ?? 0);
        $qa_total = floatval($scores['qa_total'] ?? 0);

        // PS & WS
        $ww_ps = floatval($scores['ww_ps'] ?? 0);
        $ww_ws = floatval($scores['ww_ws'] ?? 0);
        $pt_ps = floatval($scores['pt_ps'] ?? 0);
        $pt_ws = floatval($scores['pt_ws'] ?? 0);
        $qa_ps = floatval($scores['qa_ps'] ?? 0);
        $qa_ws = floatval($scores['qa_ws'] ?? 0);

        $initial_grade = floatval($student['initial_grade'] ?? 0);
        $final_grade = intval($student['final_grade'] ?? 0);
        $remarks = $final_grade >= 75 ? 'Passed' : 'Failed';

        if ($existing) {
            $updateStmt = $pdo->prepare("
                UPDATE tblgrades SET
                    ww_total = ?, pt_total = ?, qa_total = ?,
                    ww_ps = ?, ww_ws = ?,
                    pt_ps = ?, pt_ws = ?,
                    qa_ps = ?, qa_ws = ?,
                    initial_grade = ?, final_grade = ?, remarks = ?,
                    updated_at = NOW()
                WHERE id = ?
            ");
            $updateStmt->execute([
                $ww_total, $pt_total, $qa_total,
                $ww_ps, $ww_ws, $pt_ps, $pt_ws, $qa_ps, $qa_ws,
                $initial_grade, $final_grade, $remarks,
                $existing['id']
            ]);
        } else {
            $insertStmt = $pdo->prepare("
                INSERT INTO tblgrades (
                    student_id, subject_id, section_id, teacher_id, quarter, academic_year_id,
                    ww_total, pt_total, qa_total,
                    ww_ps, ww_ws, pt_ps, pt_ws, qa_ps, qa_ws,
                    initial_grade, final_grade, remarks,
                    created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
            ");
            $insertStmt->execute([
                $student['student_id'], $subjectId, $sectionId, $teacherId, $quarter, $academic_year_id,
                $ww_total, $pt_total, $qa_total,
                $ww_ps, $ww_ws, $pt_ps, $pt_ws, $qa_ps, $qa_ws,
                $initial_grade, $final_grade, $remarks
            ]);
        }
        $savedCount++;
    }

    $pdo->commit();
    echo json_encode(['success' => true, 'saved_count' => $savedCount]);

} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>