<?php
// api/grading/create_grades.php
header('Content-Type: application/json');
require_once '../shared/db_connect.php';

$section_id = $_GET['section_id'] ?? 0;
$subject_id = $_GET['subject_id'] ?? 0;
$quarter = $_GET['quarter'] ?? 1;

$ay_sql = "SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1";
$ay_stmt = $pdo->query($ay_sql);
$academic_year_id = $ay_stmt->fetchColumn() ?: 1;

$stmt = $pdo->prepare("
    SELECT COUNT(*) FROM tblgrades 
    WHERE section_id = ? AND subject_id = ? AND quarter = ? AND academic_year_id = ?
");
$stmt->execute([$section_id, $subject_id, $quarter, $academic_year_id]);
$count = $stmt->fetchColumn();

if ($count > 0) {
    $stmt = $pdo->prepare("
        SELECT g.*, CONCAT(s.lname, ', ', s.fname) as student_name, s.gender 
        FROM tblgrades g 
        JOIN tblstudents s ON g.student_id = s.id 
        WHERE g.section_id = ? AND g.subject_id = ? AND g.quarter = ? AND g.academic_year_id = ?
    ");
    $stmt->execute([$section_id, $subject_id, $quarter, $academic_year_id]);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['has_grades' => true, 'students' => $students]);
} else {
    echo json_encode(['has_grades' => false]);
}
?>