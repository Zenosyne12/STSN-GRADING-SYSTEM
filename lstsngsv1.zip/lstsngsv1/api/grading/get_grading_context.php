<?php
header('Content-Type: application/json');
require_once '../shared/db_connect.php';

function respond($success, $message, $data = [], $code = 200) {
    http_response_code($code);
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}

$teacher_id = isset($_GET['teacher_id']) ? (int)$_GET['teacher_id'] : 0;
$subject_id = isset($_GET['subject_id']) ? (int)$_GET['subject_id'] : 0;
$section_id = isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0;
$quarter    = isset($_GET['quarter']) ? (int)$_GET['quarter'] : 1;

if ($teacher_id <= 0 || $subject_id <= 0 || $section_id <= 0) {
    respond(false, 'teacher_id, subject_id, and section_id are required.', [], 400);
}

$sqlAy = "SELECT id, year_label
          FROM tblacademicyear
          WHERE is_active = 1
          LIMIT 1";
$resAy = $conn->query($sqlAy);
$academicYear = $resAy ? $resAy->fetch_assoc() : null;

if (!$academicYear) {
    respond(false, 'No active academic year found.', [], 404);
}

$academic_year_id = (int)$academicYear['id'];

$sqlSchedule = "SELECT ts.*, s.section_name, sub.subject_name
                FROM tblschedule ts
                INNER JOIN tblsection s ON s.id = ts.section_id
                INNER JOIN tblsubjects sub ON sub.id = ts.subject_id
                WHERE ts.teacher_id = ?
                  AND ts.subject_id = ?
                  AND ts.section_id = ?
                  AND ts.academic_year_id = ?
                  AND ts.is_active = 1
                LIMIT 1";
$stmt = $conn->prepare($sqlSchedule);
$stmt->bind_param("iiii", $teacher_id, $subject_id, $section_id, $academic_year_id);
$stmt->execute();
$resSchedule = $stmt->get_result();
$schedule = $resSchedule->fetch_assoc();
$stmt->close();

if (!$schedule) {
    respond(false, 'No active schedule found for this teacher, subject, and section.', [], 404);
}

$sqlSection = "SELECT s.id, s.section_name, s.grade_level_id, gl.grade_level_name
               FROM tblsection s
               LEFT JOIN tblgradelevel gl ON gl.id = s.grade_level_id
               WHERE s.id = ?
               LIMIT 1";
$stmt = $conn->prepare($sqlSection);
$stmt->bind_param("i", $section_id);
$stmt->execute();
$resSection = $stmt->get_result();
$section = $resSection->fetch_assoc();
$stmt->close();

if (!$section) {
    respond(false, 'Section not found.', [], 404);
}

$grade_level_id = (int)$section['grade_level_id'];

$weights = ['ww' => 30, 'pt' => 50, 'qa' => 20];
$sqlCurr = "SELECT ww, pt, qa
            FROM tblcurriculum_grade
            WHERE grade_level_id = ?
              AND subject_id = ?
              AND is_active = 1
            LIMIT 1";
$stmt = $conn->prepare($sqlCurr);
$stmt->bind_param("ii", $grade_level_id, $subject_id);
$stmt->execute();
$resCurr = $stmt->get_result();
if ($curr = $resCurr->fetch_assoc()) {
    $weights = [
        'ww' => (float)$curr['ww'],
        'pt' => (float)$curr['pt'],
        'qa' => (float)$curr['qa']
    ];
}
$stmt->close();

$sqlTeacher = "SELECT id, CONCAT(fname, ' ', IFNULL(mname, ''), ' ', lname) AS teacher_name
               FROM tblteacher
               WHERE id = ?
               LIMIT 1";
$stmt = $conn->prepare($sqlTeacher);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$resTeacher = $stmt->get_result();
$teacher = $resTeacher->fetch_assoc();
$stmt->close();

$sqlStudents = "SELECT 
                    ss.student_id,
                    CONCAT(
                        st.lname, ', ',
                        st.fname,
                        CASE
                            WHEN st.mname IS NOT NULL AND st.mname <> ''
                            THEN CONCAT(' ', LEFT(st.mname, 1), '.')
                            ELSE ''
                        END
                    ) AS student_name,
                    st.gender
                FROM tblsectionstudent ss
                INNER JOIN tblstudents st ON st.id = ss.student_id
                WHERE ss.section_id = ?
                  AND ss.academic_year_id = ?
                  AND ss.is_active = 1
                  AND st.is_active = 1
                ORDER BY st.lname ASC, st.fname ASC";
$stmt = $conn->prepare($sqlStudents);
$stmt->bind_param("ii", $section_id, $academic_year_id);
$stmt->execute();
$resStudents = $stmt->get_result();

$students = [];
$counter = 1;
while ($row = $resStudents->fetch_assoc()) {
    $students[] = [
        'no' => $counter++,
        'student_id' => (int)$row['student_id'],
        'name' => $row['student_name'],
        'gender' => $row['gender']
    ];
}
$stmt->close();

$gradingItems = [
    'WW' => [],
    'PT' => [],
    'QA' => []
];

if ($conn->query("SHOW TABLES LIKE 'tblgrading_items'")->num_rows > 0) {
    $sqlItems = "SELECT id, component, item_no, item_name, max_score
                 FROM tblgrading_items
                 WHERE teacher_id = ?
                   AND section_id = ?
                   AND subject_id = ?
                   AND academic_year_id = ?
                   AND quarter = ?
                   AND is_active = 1
                 ORDER BY component, item_no";
    $stmt = $conn->prepare($sqlItems);
    $stmt->bind_param("iiiii", $teacher_id, $section_id, $subject_id, $academic_year_id, $quarter);
    $stmt->execute();
    $resItems = $stmt->get_result();

    while ($row = $resItems->fetch_assoc()) {
        $gradingItems[$row['component']][] = [
            'id' => (int)$row['id'],
            'item_no' => (int)$row['item_no'],
            'item_name' => $row['item_name'],
            'max_score' => (float)$row['max_score']
        ];
    }
    $stmt->close();
}

respond(true, 'Grading context loaded successfully.', [
    'academic_year' => [
        'id' => $academic_year_id,
        'year_label' => $academicYear['year_label']
    ],
    'teacher' => [
        'id' => (int)$teacher['id'],
        'name' => trim(preg_replace('/\s+/', ' ', $teacher['teacher_name']))
    ],
    'subject' => [
        'id' => (int)$subject_id,
        'name' => $schedule['subject_name']
    ],
    'section' => [
        'id' => (int)$section_id,
        'name' => $section['section_name'],
        'grade_level_id' => $grade_level_id,
        'grade_level_name' => $section['grade_level_name']
    ],
    'schedule' => [
        'id' => (int)$schedule['id'],
        'day_of_week' => $schedule['day_of_week'],
        'time_start' => $schedule['time_start'],
        'time_end' => $schedule['time_end'],
        'room' => $schedule['room']
    ],
    'quarter' => $quarter,
    'weights' => $weights,
    'grading_items' => $gradingItems,
    'students' => $students
]);