<?php
// api/grades/grade_level_students.php
// Returns all students enrolled in a specific grade level for a given academic year,
// along with their section, subject grades per quarter, and general average.
header('Content-Type: application/json');
require_once __DIR__ . '/../shared/db_connect.php';

$grade_level_id  = isset($_GET['grade_level_id'])  ? (int)$_GET['grade_level_id']  : 0;
$year_id         = isset($_GET['year_id'])          ? (int)$_GET['year_id']         : 0;
$quarter_id      = isset($_GET['quarter_id'])       ? (int)$_GET['quarter_id']      : 0;  // 0 = all quarters
$section_id      = isset($_GET['section_id'])       ? (int)$_GET['section_id']      : 0;  // 0 = all sections

if (!$grade_level_id || !$year_id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'grade_level_id and year_id are required.']);
    exit;
}

// ── Resolve quarter number if quarter_id given ────────────────────────────────
$quarter_number = 0;
if ($quarter_id) {
    $qStmt = $pdo->prepare("SELECT quarter_number FROM tblquarters WHERE id = ? AND academic_year_id = ?");
    $qStmt->execute([$quarter_id, $year_id]);
    $qRow = $qStmt->fetch(PDO::FETCH_ASSOC);
    if ($qRow) $quarter_number = (int)$qRow['quarter_number'];
}

// ── Grade level label ─────────────────────────────────────────────────────────
$glStmt = $pdo->prepare("SELECT grade_level_name, grade_level_code FROM tblgradelevel WHERE id = ?");
$glStmt->execute([$grade_level_id]);
$glRow  = $glStmt->fetch(PDO::FETCH_ASSOC);
$grade_level_name = $glRow['grade_level_name'] ?? "Grade $grade_level_id";

// ── Sections for this grade level ─────────────────────────────────────────────
$secParams  = [$grade_level_id];
$secWhere   = "s.grade_level_id = ?";
if ($section_id) { $secWhere .= " AND s.id = ?"; $secParams[] = $section_id; }

$secSql = "
    SELECT s.id, s.section_name,
           CONCAT(t.fname,' ',t.lname) AS adviser_name
    FROM tblsection s
    LEFT JOIN tblsectionadviser sa ON sa.section_id = s.id AND sa.academic_year_id = ?
    LEFT JOIN tblteacher t ON t.id = sa.teacher_id
    WHERE $secWhere AND s.is_active = 1
    ORDER BY s.section_name";
array_unshift($secParams, $year_id);
$secStmt = $pdo->prepare($secSql);
$secStmt->execute($secParams);
$sections = $secStmt->fetchAll(PDO::FETCH_ASSOC);
$sectionMap = [];
foreach ($sections as $sec) $sectionMap[$sec['id']] = $sec;

// ── Subjects for this grade level ─────────────────────────────────────────────
$subSql  = "SELECT id, subject_name FROM tblsubjects WHERE grade_level_id = ? AND is_active = 1 ORDER BY subject_name";
$subStmt = $pdo->prepare($subSql);
$subStmt->execute([$grade_level_id]);
$subjects = $subStmt->fetchAll(PDO::FETCH_ASSOC);
$subjectIds = array_column($subjects, 'id');

// ── Students enrolled in this grade level ─────────────────────────────────────
$stSql = "
    SELECT DISTINCT
        st.id             AS student_id,
        st.lrn,
        CONCAT(st.lname,', ',st.fname,' ',COALESCE(st.mname,'')) AS full_name,
        st.gender,
        ss.section_id
    FROM tblstudents st
    JOIN tblenrollment e
        ON e.student_id = st.id
       AND e.academic_year_id = ?
       AND e.grade_level_id   = ?
       AND e.enrollment_status IN ('ENROLLED','RETAINED')
    LEFT JOIN tblsectionstudent ss
        ON ss.student_id = st.id
       AND ss.academic_year_id = ?
       AND ss.is_active = 1
    WHERE st.is_active = 1
    " . ($section_id ? "AND ss.section_id = $section_id" : "") . "
    ORDER BY st.lname, st.fname";

$stStmt = $pdo->prepare($stSql);
$stStmt->execute([$year_id, $grade_level_id, $year_id]);
$students = $stStmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($students)) {
    echo json_encode([
        'success'          => true,
        'grade_level_name' => $grade_level_name,
        'sections'         => array_values($sections),
        'subjects'         => $subjects,
        'students'         => [],
        'count'            => 0
    ]);
    exit;
}

$studentIds = array_column($students, 'student_id');

// ── Grades for these students ─────────────────────────────────────────────────
$placeholders = implode(',', array_fill(0, count($studentIds), '?'));
$gradeParams  = array_merge($studentIds, [$year_id]);
$quarterClause = '';
if ($quarter_number) {
    $quarterClause = "AND g.quarter = ?";
    $gradeParams[] = $quarter_number;
}

$gradeSql = "
    SELECT g.student_id, g.subject_id, g.quarter,
           g.final_grade, g.initial_grade, g.remarks,
           g.ww_ps, g.pt_ps, g.qa_ps,
           g.ww_ws, g.pt_ws, g.qa_ws
    FROM tblgrades g
    WHERE g.student_id IN ($placeholders)
      AND g.academic_year_id = ?
      $quarterClause
    ORDER BY g.student_id, g.subject_id, g.quarter";

$gradeStmt = $pdo->prepare($gradeSql);
$gradeStmt->execute($gradeParams);
$rawGrades  = $gradeStmt->fetchAll(PDO::FETCH_ASSOC);

// Index grades: [student_id][subject_id][quarter] = row
$gradeIndex = [];
foreach ($rawGrades as $r) {
    $gradeIndex[$r['student_id']][$r['subject_id']][$r['quarter']] = $r;
}

// ── Build student rows ────────────────────────────────────────────────────────
$result = [];
foreach ($students as $st) {
    $sid       = $st['student_id'];
    $secId     = $st['section_id'];
    $secInfo   = $sectionMap[$secId] ?? null;
    $stuGrades = $gradeIndex[$sid] ?? [];

    // Compute general average across subjects (using final_grade)
    $gradedCount = 0;
    $gradeSum    = 0;
    $subjectGrades = [];

    foreach ($subjects as $sub) {
        $subId    = $sub['id'];
        $subGrades = $stuGrades[$subId] ?? [];
        // If filtering by quarter, get that quarter's grade; else average all quarters
        if ($quarter_number && isset($subGrades[$quarter_number])) {
            $fg = (int)$subGrades[$quarter_number]['final_grade'];
        } elseif (!$quarter_number && !empty($subGrades)) {
            $fg = (int)round(array_sum(array_column($subGrades, 'final_grade')) / count($subGrades));
        } else {
            $fg = 0;
        }
        $subjectGrades[$subId] = $fg;
        if ($fg > 0) { $gradeSum += $fg; $gradedCount++; }
    }

    $genAvg = $gradedCount ? round($gradeSum / $gradedCount, 2) : 0;
    $remark = $genAvg >= 75 ? 'Passed' : ($genAvg > 0 ? 'Failed' : '—');

    $result[] = [
        'student_id'      => $sid,
        'lrn'             => $st['lrn'],
        'full_name'       => trim($st['full_name']),
        'gender'          => $st['gender'],
        'section_id'      => $secId,
        'section_name'    => $secInfo['section_name'] ?? '—',
        'adviser_name'    => $secInfo['adviser_name'] ?? '—',
        'subject_grades'  => $subjectGrades,  // [subject_id => final_grade]
        'general_average' => $genAvg,
        'remark'          => $remark,
    ];
}

echo json_encode([
    'success'          => true,
    'grade_level_name' => $grade_level_name,
    'sections'         => array_values($sections),
    'subjects'         => $subjects,
    'students'         => $result,
    'count'            => count($result)
]);