<?php
// api/grades/student_full_grades.php
// Returns a single student's complete grade record:
//   – all subjects they are enrolled in (via their section)
//   – grades for every quarter that has data
//   – computed general average per subject and overall
header('Content-Type: application/json');
require_once __DIR__ . '/../shared/db_connect.php';

$student_id = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
$year_id    = isset($_GET['year_id'])    ? (int)$_GET['year_id']    : 0;

if (!$student_id || !$year_id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'student_id and year_id are required.']);
    exit;
}

// ── Student info ──────────────────────────────────────────────────────────────
$stSql  = "SELECT id, lrn,
                  CONCAT(lname,', ',fname,' ',COALESCE(mname,'')) AS full_name,
                  gender
           FROM tblstudents WHERE id = ? AND is_active = 1 LIMIT 1";
$stStmt = $pdo->prepare($stSql);
$stStmt->execute([$student_id]);
$student = $stStmt->fetch(PDO::FETCH_ASSOC);
if (!$student) {
    echo json_encode(['success' => false, 'message' => 'Student not found.']);
    exit;
}

// ── Enrollment & grade level ──────────────────────────────────────────────────
$enSql  = "SELECT e.grade_level_id, gl.grade_level_name, gl.grade_level_code
           FROM tblenrollment e
           JOIN tblgradelevel gl ON gl.id = e.grade_level_id
           WHERE e.student_id = ? AND e.academic_year_id = ?
           LIMIT 1";
$enStmt = $pdo->prepare($enSql);
$enStmt->execute([$student_id, $year_id]);
$enrollment = $enStmt->fetch(PDO::FETCH_ASSOC);
if (!$enrollment) {
    echo json_encode(['success' => false, 'message' => 'Enrollment record not found for this year.']);
    exit;
}
$grade_level_id = $enrollment['grade_level_id'];

// ── Section assignment ────────────────────────────────────────────────────────
$ssSql  = "SELECT ss.section_id, s.section_name,
                  CONCAT(t.fname,' ',t.lname) AS adviser_name
           FROM tblsectionstudent ss
           JOIN tblsection s ON s.id = ss.section_id
           LEFT JOIN tblsectionadviser sa ON sa.section_id = ss.section_id AND sa.academic_year_id = ?
           LEFT JOIN tblteacher t ON t.id = sa.teacher_id
           WHERE ss.student_id = ? AND ss.academic_year_id = ? AND ss.is_active = 1
           LIMIT 1";
$ssStmt = $pdo->prepare($ssSql);
$ssStmt->execute([$year_id, $student_id, $year_id]);
$section = $ssStmt->fetch(PDO::FETCH_ASSOC);

// ── Subjects for this grade level ─────────────────────────────────────────────
$subSql  = "SELECT id, subject_name, subject_code, subject_type
            FROM tblsubjects
            WHERE grade_level_id = ? AND is_active = 1
            ORDER BY subject_type, subject_name";
$subStmt = $pdo->prepare($subSql);
$subStmt->execute([$grade_level_id]);
$subjects = $subStmt->fetchAll(PDO::FETCH_ASSOC);

// ── Quarters for this year ────────────────────────────────────────────────────
$quSql  = "SELECT id, quarter_number, quarter_label
           FROM tblquarters
           WHERE academic_year_id = ?
           ORDER BY quarter_number";
$quStmt = $pdo->prepare($quSql);
$quStmt->execute([$year_id]);
$quarters = $quStmt->fetchAll(PDO::FETCH_ASSOC);

// ── Grade records ─────────────────────────────────────────────────────────────
$grSql  = "SELECT subject_id, quarter,
                  final_grade, initial_grade, remarks,
                  ww_ps, pt_ps, qa_ps, ww_ws, pt_ws, qa_ws,
                  ww_total, pt_total, qa_total
           FROM tblgrades
           WHERE student_id = ? AND academic_year_id = ?
           ORDER BY subject_id, quarter";
$grStmt = $pdo->prepare($grSql);
$grStmt->execute([$student_id, $year_id]);
$rawGrades = $grStmt->fetchAll(PDO::FETCH_ASSOC);

// Index: [subject_id][quarter_number] = grade_row
$gradeIndex = [];
foreach ($rawGrades as $r) {
    $gradeIndex[$r['subject_id']][$r['quarter']] = $r;
}

// ── Build subject rows with per-quarter grades ────────────────────────────────
$subjectRows = [];
$overallSum  = 0;
$overallCnt  = 0;

foreach ($subjects as $sub) {
    $subId      = $sub['id'];
    $qGrades    = $gradeIndex[$subId] ?? [];
    $qData      = [];
    $subSum     = 0;
    $subCnt     = 0;

    foreach ($quarters as $q) {
        $qNum  = $q['quarter_number'];
        $qLbl  = $q['quarter_label'];
        if (isset($qGrades[$qNum])) {
            $g = $qGrades[$qNum];
            $fg = (int)$g['final_grade'];
            $qData[] = [
                'quarter_number' => $qNum,
                'quarter_label'  => $qLbl,
                'final_grade'    => $fg,
                'initial_grade'  => round((float)$g['initial_grade'], 2),
                'remarks'        => $g['remarks'],
                'ww_ps'  => round((float)$g['ww_ps'],  2),
                'pt_ps'  => round((float)$g['pt_ps'],  2),
                'qa_ps'  => round((float)$g['qa_ps'],  2),
                'ww_ws'  => round((float)$g['ww_ws'],  2),
                'pt_ws'  => round((float)$g['pt_ws'],  2),
                'qa_ws'  => round((float)$g['qa_ws'],  2),
            ];
            if ($fg > 0) { $subSum += $fg; $subCnt++; }
        } else {
            $qData[] = [
                'quarter_number' => $qNum,
                'quarter_label'  => $qLbl,
                'final_grade'    => null,
                'initial_grade'  => null,
                'remarks'        => null,
            ];
        }
    }

    $subAvg = $subCnt ? round($subSum / $subCnt, 2) : null;
    if ($subAvg !== null) { $overallSum += $subAvg; $overallCnt++; }

    $subjectRows[] = [
        'subject_id'      => $subId,
        'subject_name'    => $sub['subject_name'],
        'subject_type'    => $sub['subject_type'],
        'quarter_grades'  => $qData,
        'subject_average' => $subAvg,
        'subject_remark'  => $subAvg !== null ? ($subAvg >= 75 ? 'Passed' : 'Failed') : '—',
    ];
}

$generalAverage = $overallCnt ? round($overallSum / $overallCnt, 2) : null;

echo json_encode([
    'success'         => true,
    'student'         => [
        'id'           => (int)$student['id'],
        'lrn'          => $student['lrn'],
        'full_name'    => trim($student['full_name']),
        'gender'       => $student['gender'],
        'grade_level'  => $enrollment['grade_level_name'],
        'section_name' => $section['section_name'] ?? '—',
        'adviser_name' => $section['adviser_name'] ?? '—',
    ],
    'quarters'        => $quarters,
    'subjects'        => $subjectRows,
    'general_average' => $generalAverage,
    'overall_remark'  => $generalAverage !== null ? ($generalAverage >= 75 ? 'Passed' : 'Failed') : '—',
]);