<?php
header('Content-Type: application/json');

require_once '../shared/db_connect.php';

$section_id = isset($_GET['section_id']) ? intval($_GET['section_id']) : 0;
$subject_id = isset($_GET['subject_id']) ? intval($_GET['subject_id']) : 0;
$teacher_id = isset($_GET['teacher_id']) ? intval($_GET['teacher_id']) : 0;

if (!$section_id || !$subject_id) {
    echo json_encode(['error' => 'Section ID and Subject ID required']);
    exit;
}

$db = new Database();
$conn = $db->connect();

// Get section info with grade level
$sql = "SELECT 
            s.section_name,
            gl.grade_level,
            sub.subject_name,
            CONCAT(t.firstname, ' ', t.lastname) as teacher_name,
            sem.semester,
            ay.year as school_year
        FROM tblsection s
        INNER JOIN tblgradelevel gl ON s.grade_level_id = gl.id
        INNER JOIN tblsubject sub ON sub.id = ?
        LEFT JOIN tblteacher t ON t.id = ?
        LEFT JOIN tblsemester sem ON sem.is_active = 1
        LEFT JOIN tblacademicyear ay ON ay.is_active = 1
        WHERE s.id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("iii", $subject_id, $teacher_id, $section_id);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode([
        'success' => true,
        'subject' => $row['subject_name'],
        'section' => $row['grade_level'] . ' - ' . $row['section_name'],
        'teacher' => $row['teacher_name'] ?? 'Unassigned',
        'quarter' => $row['semester'] ?? '1st Quarter',
        'schoolYear' => $row['school_year'] ?? date('Y') . '-' . (date('Y') + 1)
    ]);
} else {
    echo json_encode(['error' => 'Class info not found']);
}

$stmt->close();
$db->close();
?>