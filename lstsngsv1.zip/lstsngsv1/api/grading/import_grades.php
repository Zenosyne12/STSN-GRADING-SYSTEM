<?php
// api/grading/import_grades.php
// Minimal schema: legacy JSON import
header('Content-Type: application/json');
require_once '../shared/db_connect.php';

$data = json_decode(file_get_contents('php://input'), true);

try {
    $pdo->beginTransaction();

    $ay_sql = "SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1";
    $ay_stmt = $pdo->query($ay_sql);
    $academic_year_id = $ay_stmt->fetchColumn() ?: 1;

    $inserted = 0;
    foreach ($data['grades'] as $grade) {
        $stmt = $pdo->prepare("SELECT id FROM tblstudents WHERE CONCAT(lname, ', ', fname) = ? AND section_id = ?");
        $stmt->execute([$grade['student_name'], $data['section_id']]);
        $student = $stmt->fetch();

        if (!$student) continue;

        $delStmt = $pdo->prepare("
            DELETE FROM tblgrades 
            WHERE student_id = ? AND subject_id = ? AND quarter = ? AND academic_year_id = ?
        ");
        $delStmt->execute([$student['id'], $data['subject_id'], $data['quarter'], $academic_year_id]);

        $initial_grade = floatval($grade['initial_grade'] ?? 0);
        $final_grade = intval($grade['final_grade'] ?? 0);
        $remarks = $final_grade >= 75 ? 'Passed' : 'Failed';

        $insStmt = $pdo->prepare("
            INSERT INTO tblgrades (
                student_id, subject_id, quarter, academic_year_id,
                initial_grade, final_grade, remarks,
                created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $insStmt->execute([
            $student['id'], $data['subject_id'], $data['quarter'], $academic_year_id,
            $initial_grade, $final_grade, $remarks
        ]);

        $inserted++;
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'imported_count' => $inserted
    ]);

} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>