<?php
header('Content-Type: application/json');

require_once '../shared/db_connect.php';

$section_id = isset($_GET['section_id']) ? intval($_GET['section_id']) : 0;
$subject_id = isset($_GET['subject_id']) ? intval($_GET['subject_id']) : 0;

if (!$section_id || !$subject_id) {
    echo json_encode(['error' => 'Section ID and Subject ID required']);
    exit;
}

$db = new Database();
$conn = $db->connect();

// Get grade configuration for this subject
$sql = "SELECT ww, pt, qa FROM tblgrade_config 
        WHERE grade_level_id = (SELECT grade_level_id FROM tblsection WHERE id = ?) 
        AND subject_id = ? AND is_active = 1";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $section_id, $subject_id);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode([
        'success' => true,
        'ww_percentage' => intval($row['ww']),
        'pt_percentage' => intval($row['pt']),
        'qa_percentage' => intval($row['qa'])
    ]);
} else {
    // Default DepEd K-12 weights
    echo json_encode([
        'success' => true,
        'ww_percentage' => 40,
        'pt_percentage' => 40,
        'qa_percentage' => 20
    ]);
}

$stmt->close();
$db->close();
?>