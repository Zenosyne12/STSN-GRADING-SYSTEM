<?php

header('Content-Type: application/json');

require_once '../shared/db_connect.php';

$section_id = isset($_GET['section_id']) ? intval($_GET['section_id']) : 0;
$subject_id = isset($_GET['subject_id']) ? intval($_GET['subject_id']) : 0;

if (!$section_id || !$subject_id) {
    echo json_encode(['error' => 'Section ID and Subject ID required']);
    exit;
}


$sql = "SELECT ww, pt, qa FROM tblcurriculum_grade 
        WHERE grade_level_id = (SELECT grade_level_id FROM tblsection WHERE id = ?) 
        AND subject_id = ? AND is_active = 1";

$stmt = $pdo->prepare($sql);
$stmt->execute([$section_id, $subject_id]);

if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo json_encode([
        'success' => true,
        'ww_percentage' => intval($row['ww']),
        'pt_percentage' => intval($row['pt']),
        'qa_percentage' => intval($row['qa'])
    ]);
} else {
    
    echo json_encode([
        'success' => true,
        'ww_percentage' => 40,
        'pt_percentage' => 40,
        'qa_percentage' => 20
    ]);
}

$stmt = null;
?>