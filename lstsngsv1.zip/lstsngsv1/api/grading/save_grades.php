<?php


header('Content-Type: application/json');

require_once '../../api/shared/db_connect.php';
require_once '../../api/deadline/check_submission_lock.php';
require_once '../../api/shared/grade_workflow.php';
require_once '../../includes/grading_engine.php';
require_once '../../includes/descriptor_engine.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['grades']) || !is_array($data['grades'])) {
    echo json_encode(['error' => 'Invalid data format']);
    exit;
}

$section_id = intval($data['section_id'] ?? 0);
$subject_id = intval($data['subject_id'] ?? 0);
$quarter = intval($data['quarter'] ?? 1);
$teacher_id = intval($_SESSION['teacher_id'] ?? ($data['teacher_id'] ?? 0));

if (!$section_id || !$subject_id || !$teacher_id) {
    echo json_encode(['error' => 'Section ID, Subject ID, and Teacher ID required']);
    exit;
}

/* ---------------------------------------------------------------------
 * Server-authoritative grading configuration.
 * The ACTIVE GRADING TEMPLATE decides PS/WS/initial/final/remarks — the
 * browser's numbers are never trusted for storage. Fallbacks below apply
 * only when no template exists (legacy behaviour).
 * ------------------------------------------------------------------- */
$sectionRow = null;
try {
    $secStmt = $pdo->prepare("SELECT grade_level_id FROM tblsection WHERE id = ? LIMIT 1");
    $secStmt->execute([$section_id]);
    $sectionRow = $secStmt->fetch(PDO::FETCH_ASSOC);
} catch (Throwable $e) {}

$gradeLevelId = (int)($sectionRow['grade_level_id'] ?? 0);
$gradeCode = ($gradeLevelId > 0) ? geResolveGradeCode($pdo, $gradeLevelId) : 0;

/* Guard: descriptive / kindergarten sections must use the rating endpoint. */
if ($gradeCode > 0 && $gradeCode <= 3) {
    echo json_encode([
        'success' => false,
        'error'   => 'This section uses descriptive/developmental grading (Grade 3 or below). Use the rating save endpoint instead of numeric scores.'
    ]);
    exit;
}

$programId = ($gradeLevelId > 0 && function_exists('geResolveProgramId'))
    ? geResolveProgramId($pdo, $section_id)
    : null;

$template = ($gradeLevelId > 0)
    ? getActiveGradingTemplate($pdo, $gradeLevelId, $programId)
    : null;

/* Default HPS per component — the sheet sends max_scores (100/100/100 or the
   imported DepEd Excel scale). */
$payloadMax = $data['max_scores'] ?? [];
$hpsDefault = [
    'ww' => ((float)($payloadMax['ww'] ?? 100)) ?: 100.0,
    'pt' => ((float)($payloadMax['pt'] ?? 100)) ?: 100.0,
    'qa' => ((float)($payloadMax['qa'] ?? 100)) ?: 100.0,
];


$ay_sql = "SELECT id, year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1";
$ay_stmt = $pdo->query($ay_sql);
$activeYear = $ay_stmt->fetch(PDO::FETCH_ASSOC);
$academic_year_id = $activeYear['id'] ?? 1;
$school_year = $activeYear['year_label'] ?? '';

ensureGradeWorkflowSchema($pdo);

if ($school_year !== '') {
    $overrideRequested = !empty($data['override']) && ((int)($_SESSION['role_id'] ?? 0) === 1);
    if (!$overrideRequested) {
        checkSubmissionLock($pdo, $teacher_id, $section_id, $subject_id, $quarter, $school_year, 'teacher');
    }
}

$success_count = 0;
$error_count = 0;
$errors = [];

foreach ($data['grades'] as $grade) {
    $student_id = intval($grade['student_id'] ?? 0);
    if (!$student_id) continue;

    
    $scores = $grade['scores'] ?? [];

    
    $ww_total = floatval($scores['ww_total'] ?? 0);
    $pt_total = floatval($scores['pt_total'] ?? 0);
    $qa_total = floatval($scores['qa_total'] ?? 0);

    /* ---- Server-side validation of the raw scores ---- */
    if ($ww_total < 0 || $pt_total < 0 || $qa_total < 0) {
        $error_count++;
        $errors[] = "Student {$student_id}: component scores cannot be negative.";
        continue;
    }

    /* HPS: per-student override (DepEd Excel import) else payload default. */
    $gradeHps = $grade['hps'] ?? [];
    $hps_ww = ((float)($gradeHps['ww'] ?? 0)) ?: $hpsDefault['ww'];
    $hps_pt = ((float)($gradeHps['pt'] ?? 0)) ?: $hpsDefault['pt'];
    $hps_qa = ((float)($gradeHps['qa'] ?? 0)) ?: $hpsDefault['qa'];
    if ($hps_ww <= 0 || $hps_pt <= 0 || $hps_qa <= 0) {
        $error_count++;
        $errors[] = "Student {$student_id}: highest possible scores must be greater than zero.";
        continue;
    }

    /* ---- Server-authoritative computation from the ACTIVE TEMPLATE ---- */
    if ($template !== null && $gradeLevelId > 0) {
        $computed = computeFinalGrade($pdo, [
            'ww_total'       => $ww_total,
            'pt_total'       => $pt_total,
            'qa_total'       => $qa_total,
            'hps_ww'         => $hps_ww,
            'hps_pt'         => $hps_pt,
            'hps_qa'         => $hps_qa,
            'grade_level_id' => $gradeLevelId,
            'program_id'     => $programId,
        ]);
        $ww_ps = (float)$computed['ww_ps'];
        $pt_ps = (float)$computed['pt_ps'];
        $qa_ps = (float)$computed['qa_ps'];
        $ww_ws = (float)$computed['ww_ws'];
        $pt_ws = (float)$computed['pt_ws'];
        $qa_ws = (float)$computed['qa_ws'];
        $initial_grade = (float)$computed['initial_grade'];
        $final_grade   = (int)$computed['final_grade'];
        $remarks       = $computed['remarks'] !== ''
            ? $computed['remarks']
            : ($final_grade >= (int)$template['passing_threshold'] ? 'Passed' : 'Failed');
    } else {
        /* No template configured — keep legacy behaviour (client values). */
        $ww_ps = floatval($scores['ww_ps'] ?? 0);
        $pt_ps = floatval($scores['pt_ps'] ?? 0);
        $qa_ps = floatval($scores['qa_ps'] ?? 0);
        $ww_ws = floatval($scores['ww_ws'] ?? 0);
        $pt_ws = floatval($scores['pt_ws'] ?? 0);
        $qa_ws = floatval($scores['qa_ws'] ?? 0);
        $initial_grade = floatval($grade['initial_grade'] ?? 0);
        $final_grade = intval($grade['final_grade'] ?? 0);
        $remarks = $grade['remarks'] ?? ($final_grade >= 75 ? 'Passed' : 'Failed');
    }

    
    $check_sql = "SELECT id FROM tblgrades 
                  WHERE student_id = :student_id 
                  AND section_id = :section_id 
                  AND subject_id = :subject_id 
                  AND quarter = :quarter 
                  AND academic_year_id = :academic_year_id";
    $check_stmt = $pdo->prepare($check_sql);
    $check_stmt->execute([
        'student_id' => $student_id,
        'section_id' => $section_id,
        'subject_id' => $subject_id,
        'quarter' => $quarter,
        'academic_year_id' => $academic_year_id
    ]);
    $existing = $check_stmt->fetch();

    if ($existing) {
        
        $update_sql = "UPDATE tblgrades SET 
            teacher_id = :teacher_id,
            ww_total = :ww_total, pt_total = :pt_total, qa_total = :qa_total,
            ww_ps = :ww_ps, pt_ps = :pt_ps, qa_ps = :qa_ps,
            ww_ws = :ww_ws, pt_ws = :pt_ws, qa_ws = :qa_ws,
            initial_grade = :initial_grade, final_grade = :final_grade, remarks = :remarks,
            grading_mode = 'NUMERICAL', rating_code = NULL,
            status = CASE
                WHEN status IN ('approved', 'approved_by_adviser', 'finalized') THEN status
                ELSE 'draft'
            END,
            updated_at = NOW()
            WHERE id = :id";

        $stmt = $pdo->prepare($update_sql);
        $params = [
            'teacher_id' => $teacher_id,
            'ww_total' => $ww_total, 'pt_total' => $pt_total, 'qa_total' => $qa_total,
            'ww_ps' => $ww_ps, 'pt_ps' => $pt_ps, 'qa_ps' => $qa_ps,
            'ww_ws' => $ww_ws, 'pt_ws' => $pt_ws, 'qa_ws' => $qa_ws,
            'initial_grade' => $initial_grade, 'final_grade' => $final_grade, 'remarks' => $remarks,
            'id' => $existing['id']
        ];
    } else {
        
        $insert_sql = "INSERT INTO tblgrades (
            student_id, section_id, subject_id, teacher_id, quarter, academic_year_id,
            ww_total, pt_total, qa_total,
            ww_ps, pt_ps, qa_ps,
            ww_ws, pt_ws, qa_ws,
            initial_grade, final_grade, remarks, status, grading_mode,
            created_at, updated_at
        ) VALUES (
            :student_id, :section_id, :subject_id, :teacher_id, :quarter, :academic_year_id,
            :ww_total, :pt_total, :qa_total,
            :ww_ps, :pt_ps, :qa_ps,
            :ww_ws, :pt_ws, :qa_ws,
            :initial_grade, :final_grade, :remarks, 'draft', 'NUMERICAL',
            NOW(), NOW()
        )";

        $stmt = $pdo->prepare($insert_sql);
        $params = [
            'student_id' => $student_id, 'section_id' => $section_id, 'subject_id' => $subject_id,
            'teacher_id' => $teacher_id, 'quarter' => $quarter, 'academic_year_id' => $academic_year_id,
            'ww_total' => $ww_total, 'pt_total' => $pt_total, 'qa_total' => $qa_total,
            'ww_ps' => $ww_ps, 'pt_ps' => $pt_ps, 'qa_ps' => $qa_ps,
            'ww_ws' => $ww_ws, 'pt_ws' => $pt_ws, 'qa_ws' => $qa_ws,
            'initial_grade' => $initial_grade, 'final_grade' => $final_grade, 'remarks' => $remarks
        ];
    }

try {
    $stmt->execute($params);
    $success_count++;
} catch (PDOException $e) {
    $error_count++;
    $errors[] = "Student $student_id: " . $e->getMessage();
}
}

// Log admin override past the deadline
if (!empty($data['override']) && ((int)($_SESSION['role_id'] ?? 0) === 1)) {
    try {
        $instStmt = $pdo->prepare("
            SELECT id FROM tblworkflow_instance
            WHERE section_id = ? AND subject_id = ? AND teacher_id = ?
              AND academic_year_id = ?
            ORDER BY id DESC LIMIT 1
        ");
        $instStmt->execute([$section_id, $subject_id, $teacher_id, $academic_year_id]);
        $instanceId = (int)($instStmt->fetchColumn() ?: 0);

        if ($instanceId > 0 && function_exists('wfLogAction')) {
            require_once '../../includes/workflow_engine.php';
            wfLogAction(
                $pdo,
                $instanceId,
                1,
                (int)($_SESSION['user_id'] ?? $teacher_id),
                (int)($_SESSION['role_id'] ?? 1),
                'Admin',
                'OVERRIDE',
                'Admin override past deadline'
            );
        }
    } catch (Throwable $e) {
        // Never block the save on logging failure
    }
}

try {
    if ($success_count > 0) {
        logActivity($pdo, 'Grades', 'ENCODE', 'grade', $section_id, 'Encoded grades');
    }
} catch (Throwable $e) {}


echo json_encode([
    'success' => $error_count === 0,
    'message' => "Saved $success_count records" . ($error_count > 0 ? ", $error_count errors" : ""),
    'saved_count' => $success_count,
    'error_count' => $error_count,
    'errors' => $errors,
    /* Authoritative template-driven config so the sheet can re-render with
       exactly the values that were stored. */
    'grading' => [
        'template_id'   => $template !== null ? (int)$template['id'] : 0,
        'template_name' => $template !== null ? (string)$template['template_name'] : 'Default',
        'weights'       => [
            'ww' => $template !== null ? (float)$template['ww_weight'] : 40,
            'pt' => $template !== null ? (float)$template['pt_weight'] : 40,
            'qa' => $template !== null ? (float)$template['qa_weight'] : 20,
        ],
        'max_scores'    => $hpsDefault,
        'passing_threshold' => $template !== null ? (int)$template['passing_threshold'] : 75,
        'rounding_rule'     => $template !== null ? (string)$template['rounding_rule'] : 'ROUND',
    ]
]);
?>
