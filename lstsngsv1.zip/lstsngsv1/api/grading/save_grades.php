<?php
// api/grading/save_grades.php
header('Content-Type: application/json');

require_once '../../api/shared/db_connect.php';

$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['grades']) || !is_array($data['grades'])) {
    echo json_encode(['error' => 'Invalid data format']);
    exit;
}

$section_id = intval($data['section_id'] ?? 0);
$subject_id = intval($data['subject_id'] ?? 0);
$quarter = intval($data['quarter'] ?? 1);
$teacher_id = intval($data['teacher_id'] ?? 0);

if (!$section_id || !$subject_id || !$teacher_id) {
    echo json_encode(['error' => 'Section ID, Subject ID, and Teacher ID required']);
    exit;
}

// Get active academic year
$ay_sql = "SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1";
$ay_stmt = $pdo->query($ay_sql);
$academic_year_id = $ay_stmt->fetchColumn() ?: 1;

$success_count = 0;
$error_count = 0;
$errors = [];

$max_scores = $data['max_scores'] ?? [
    'ww' => [10, 10, 20, 20, 50, 50, 100, 100, 100, 100],
    'pt' => [50, 50, 50, 50, 100, 100, 100, 100, 100, 100],
    'qa' => [100]
];
$weights = $data['weights'] ?? ['ww' => 40, 'pt' => 40, 'qa' => 20];

foreach ($data['grades'] as $grade) {
    $student_id = intval($grade['student_id'] ?? 0);
    if (!$student_id) continue;
    
    $ww = array_pad(array_slice($grade['ww'] ?? [], 0, 10), 10, 0);
    $pt = array_pad(array_slice($grade['pt'] ?? [], 0, 10), 10, 0);
    $qa = array_pad(array_slice($grade['qa'] ?? [], 0, 1), 1, 0);
    
    $ww_total = array_sum($ww);
    $pt_total = array_sum($pt);
    $qa_total = array_sum($qa);
    
    $ww_max_total = array_sum($max_scores['ww']);
    $pt_max_total = array_sum($max_scores['pt']);
    $qa_max_total = array_sum($max_scores['qa']);
    
    $ww_ps = $ww_max_total > 0 ? round(($ww_total / $ww_max_total) * 100, 2) : 0;
    $pt_ps = $pt_max_total > 0 ? round(($pt_total / $pt_max_total) * 100, 2) : 0;
    $qa_ps = $qa_max_total > 0 ? round(($qa_total / $qa_max_total) * 100, 2) : 0;
    
    $ww_ws = round($ww_ps * ($weights['ww'] / 100), 2);
    $pt_ws = round($pt_ps * ($weights['pt'] / 100), 2);
    $qa_ws = round($qa_ps * ($weights['qa'] / 100), 2);
    
    $initial = round($ww_ws + $pt_ws + $qa_ws, 2);
    $final = transmuteGrade($initial);
    $remarks = $final >= 75 ? 'Passed' : 'Failed';
    
    // Check if grade record exists
    $check_sql = "SELECT id FROM tblgrades 
                  WHERE student_id = :student_id AND section_id = :section_id AND subject_id = :subject_id AND quarter = :quarter";
    $check_stmt = $pdo->prepare($check_sql);
    $check_stmt->execute([
        'student_id' => $student_id,
        'section_id' => $section_id,
        'subject_id' => $subject_id,
        'quarter' => $quarter
    ]);
    $existing = $check_stmt->fetch();
    
    if ($existing) {
        // Update existing
        $update_sql = "UPDATE tblgrades SET 
            ww1=:ww1, ww2=:ww2, ww3=:ww3, ww4=:ww4, ww5=:ww5, ww6=:ww6, ww7=:ww7, ww8=:ww8, ww9=:ww9, ww10=:ww10,
            pt1=:pt1, pt2=:pt2, pt3=:pt3, pt4=:pt4, pt5=:pt5, pt6=:pt6, pt7=:pt7, pt8=:pt8, pt9=:pt9, pt10=:pt10,
            qa1=:qa1,
            max_ww1=:max_ww1, max_ww2=:max_ww2, max_ww3=:max_ww3, max_ww4=:max_ww4, max_ww5=:max_ww5, 
            max_ww6=:max_ww6, max_ww7=:max_ww7, max_ww8=:max_ww8, max_ww9=:max_ww9, max_ww10=:max_ww10,
            max_pt1=:max_pt1, max_pt2=:max_pt2, max_pt3=:max_pt3, max_pt4=:max_pt4, max_pt5=:max_pt5,
            max_pt6=:max_pt6, max_pt7=:max_pt7, max_pt8=:max_pt8, max_pt9=:max_pt9, max_pt10=:max_pt10,
            max_qa1=:max_qa1,
            ww_percentage=:ww_percentage, pt_percentage=:pt_percentage, qa_percentage=:qa_percentage,
            ww_total=:ww_total, pt_total=:pt_total, qa_total=:qa_total,
            ww_max_total=:ww_max_total, pt_max_total=:pt_max_total, qa_max_total=:qa_max_total,
            ww_ps=:ww_ps, pt_ps=:pt_ps, qa_ps=:qa_ps,
            ww_ws=:ww_ws, pt_ws=:pt_ws, qa_ws=:qa_ws,
            initial_grade=:initial_grade, final_grade=:final_grade, remarks=:remarks,
            updated_at = NOW()
            WHERE id=:id";
            
        $stmt = $pdo->prepare($update_sql);
        $params = [
            'ww1' => $ww[0], 'ww2' => $ww[1], 'ww3' => $ww[2], 'ww4' => $ww[3], 'ww5' => $ww[4],
            'ww6' => $ww[5], 'ww7' => $ww[6], 'ww8' => $ww[7], 'ww9' => $ww[8], 'ww10' => $ww[9],
            'pt1' => $pt[0], 'pt2' => $pt[1], 'pt3' => $pt[2], 'pt4' => $pt[3], 'pt5' => $pt[4],
            'pt6' => $pt[5], 'pt7' => $pt[6], 'pt8' => $pt[7], 'pt9' => $pt[8], 'pt10' => $pt[9],
            'qa1' => $qa[0],
            'max_ww1' => $max_scores['ww'][0], 'max_ww2' => $max_scores['ww'][1], 'max_ww3' => $max_scores['ww'][2],
            'max_ww4' => $max_scores['ww'][3], 'max_ww5' => $max_scores['ww'][4], 'max_ww6' => $max_scores['ww'][5],
            'max_ww7' => $max_scores['ww'][6], 'max_ww8' => $max_scores['ww'][7], 'max_ww9' => $max_scores['ww'][8],
            'max_ww10' => $max_scores['ww'][9],
            'max_pt1' => $max_scores['pt'][0], 'max_pt2' => $max_scores['pt'][1], 'max_pt3' => $max_scores['pt'][2],
            'max_pt4' => $max_scores['pt'][3], 'max_pt5' => $max_scores['pt'][4], 'max_pt6' => $max_scores['pt'][5],
            'max_pt7' => $max_scores['pt'][6], 'max_pt8' => $max_scores['pt'][7], 'max_pt9' => $max_scores['pt'][8],
            'max_pt10' => $max_scores['pt'][9],
            'max_qa1' => $max_scores['qa'][0],
            'ww_percentage' => $weights['ww'], 'pt_percentage' => $weights['pt'], 'qa_percentage' => $weights['qa'],
            'ww_total' => $ww_total, 'pt_total' => $pt_total, 'qa_total' => $qa_total,
            'ww_max_total' => $ww_max_total, 'pt_max_total' => $pt_max_total, 'qa_max_total' => $qa_max_total,
            'ww_ps' => $ww_ps, 'pt_ps' => $pt_ps, 'qa_ps' => $qa_ps,
            'ww_ws' => $ww_ws, 'pt_ws' => $pt_ws, 'qa_ws' => $qa_ws,
            'initial_grade' => $initial, 'final_grade' => $final, 'remarks' => $remarks,
            'id' => $existing['id']
        ];
    } else {
        // Insert new
        $insert_sql = "INSERT INTO tblgrades (
            student_id, section_id, subject_id, teacher_id, quarter, academic_year_id,
            ww1, ww2, ww3, ww4, ww5, ww6, ww7, ww8, ww9, ww10,
            pt1, pt2, pt3, pt4, pt5, pt6, pt7, pt8, pt9, pt10,
            qa1,
            max_ww1, max_ww2, max_ww3, max_ww4, max_ww5, max_ww6, max_ww7, max_ww8, max_ww9, max_ww10,
            max_pt1, max_pt2, max_pt3, max_pt4, max_pt5, max_pt6, max_pt7, max_pt8, max_pt9, max_pt10,
            max_qa1,
            ww_percentage, pt_percentage, qa_percentage,
            ww_total, pt_total, qa_total,
            ww_max_total, pt_max_total, qa_max_total,
            ww_ps, pt_ps, qa_ps,
            ww_ws, pt_ws, qa_ws,
            initial_grade, final_grade, remarks,
            created_at, updated_at
        ) VALUES (
            :student_id, :section_id, :subject_id, :teacher_id, :quarter, :academic_year_id,
            :ww1, :ww2, :ww3, :ww4, :ww5, :ww6, :ww7, :ww8, :ww9, :ww10,
            :pt1, :pt2, :pt3, :pt4, :pt5, :pt6, :pt7, :pt8, :pt9, :pt10,
            :qa1,
            :max_ww1, :max_ww2, :max_ww3, :max_ww4, :max_ww5, :max_ww6, :max_ww7, :max_ww8, :max_ww9, :max_ww10,
            :max_pt1, :max_pt2, :max_pt3, :max_pt4, :max_pt5, :max_pt6, :max_pt7, :max_pt8, :max_pt9, :max_pt10,
            :max_qa1,
            :ww_percentage, :pt_percentage, :qa_percentage,
            :ww_total, :pt_total, :qa_total,
            :ww_max_total, :pt_max_total, :qa_max_total,
            :ww_ps, :pt_ps, :qa_ps,
            :ww_ws, :pt_ws, :qa_ws,
            :initial_grade, :final_grade, :remarks,
            NOW(), NOW()
        )";
        
        $stmt = $pdo->prepare($insert_sql);
        $params = [
            'student_id' => $student_id, 'section_id' => $section_id, 'subject_id' => $subject_id,
            'teacher_id' => $teacher_id, 'quarter' => $quarter, 'academic_year_id' => $academic_year_id,
            'ww1' => $ww[0], 'ww2' => $ww[1], 'ww3' => $ww[2], 'ww4' => $ww[3], 'ww5' => $ww[4],
            'ww6' => $ww[5], 'ww7' => $ww[6], 'ww8' => $ww[7], 'ww9' => $ww[8], 'ww10' => $ww[9],
            'pt1' => $pt[0], 'pt2' => $pt[1], 'pt3' => $pt[2], 'pt4' => $pt[3], 'pt5' => $pt[4],
            'pt6' => $pt[5], 'pt7' => $pt[6], 'pt8' => $pt[7], 'pt9' => $pt[8], 'pt10' => $pt[9],
            'qa1' => $qa[0],
            'max_ww1' => $max_scores['ww'][0], 'max_ww2' => $max_scores['ww'][1], 'max_ww3' => $max_scores['ww'][2],
            'max_ww4' => $max_scores['ww'][3], 'max_ww5' => $max_scores['ww'][4], 'max_ww6' => $max_scores['ww'][5],
            'max_ww7' => $max_scores['ww'][6], 'max_ww8' => $max_scores['ww'][7], 'max_ww9' => $max_scores['ww'][8],
            'max_ww10' => $max_scores['ww'][9],
            'max_pt1' => $max_scores['pt'][0], 'max_pt2' => $max_scores['pt'][1], 'max_pt3' => $max_scores['pt'][2],
            'max_pt4' => $max_scores['pt'][3], 'max_pt5' => $max_scores['pt'][4], 'max_pt6' => $max_scores['pt'][5],
            'max_pt7' => $max_scores['pt'][6], 'max_pt8' => $max_scores['pt'][7], 'max_pt9' => $max_scores['pt'][8],
            'max_pt10' => $max_scores['pt'][9],
            'max_qa1' => $max_scores['qa'][0],
            'ww_percentage' => $weights['ww'], 'pt_percentage' => $weights['pt'], 'qa_percentage' => $weights['qa'],
            'ww_total' => $ww_total, 'pt_total' => $pt_total, 'qa_total' => $qa_total,
            'ww_max_total' => $ww_max_total, 'pt_max_total' => $pt_max_total, 'qa_max_total' => $qa_max_total,
            'ww_ps' => $ww_ps, 'pt_ps' => $pt_ps, 'qa_ps' => $qa_ps,
            'ww_ws' => $ww_ws, 'pt_ws' => $pt_ws, 'qa_ws' => $qa_ws,
            'initial_grade' => $initial, 'final_grade' => $final, 'remarks' => $remarks
        ];
    }
    
    try {
        $stmt->execute($params);
        $success_count++;
    } catch (PDOException $e) {
        $error_count++;
        $errors[] = "Student $student_id: " . $e->getMessage();
    }
}

echo json_encode([
    'success' => $error_count === 0,
    'message' => "Saved $success_count records" . ($error_count > 0 ? ", $error_count errors" : ""),
    'saved_count' => $success_count,
    'error_count' => $error_count,
    'errors' => $errors
]);

function transmuteGrade($initial) {
    if ($initial >= 100) return 100;
    if ($initial >= 98.40) return 99;
    if ($initial >= 96.80) return 98;
    if ($initial >= 95.20) return 97;
    if ($initial >= 93.60) return 96;
    if ($initial >= 92.00) return 95;
    if ($initial >= 90.40) return 94;
    if ($initial >= 88.80) return 93;
    if ($initial >= 87.20) return 92;
    if ($initial >= 85.60) return 91;
    if ($initial >= 84.00) return 90;
    if ($initial >= 82.40) return 89;
    if ($initial >= 80.80) return 88;
    if ($initial >= 79.20) return 87;
    if ($initial >= 77.60) return 86;
    if ($initial >= 76.00) return 85;
    if ($initial >= 74.40) return 84;
    if ($initial >= 72.80) return 83;
    if ($initial >= 71.20) return 82;
    if ($initial >= 69.60) return 81;
    if ($initial >= 68.00) return 80;
    if ($initial >= 66.40) return 79;
    if ($initial >= 64.80) return 78;
    if ($initial >= 63.20) return 77;
    if ($initial >= 61.60) return 76;
    if ($initial >= 60.00) return 75;
    if ($initial >= 56.00) return 74;
    if ($initial >= 52.00) return 73;
    if ($initial >= 48.00) return 72;
    if ($initial >= 44.00) return 71;
    if ($initial >= 40.00) return 70;
    if ($initial >= 36.00) return 69;
    if ($initial >= 32.00) return 68;
    if ($initial >= 28.00) return 67;
    if ($initial >= 24.00) return 66;
    if ($initial >= 20.00) return 65;
    if ($initial >= 16.00) return 64;
    if ($initial >= 12.00) return 63;
    if ($initial >= 8.00) return 62;
    if ($initial >= 4.00) return 61;
    return 60;
}
?>