<?php
// api/grading/save_grades.php
// Saves computed values + total scores (ww_total, pt_total, qa_total) from frontend
header('Content-Type: application/json');

require_once '../../api/shared/db_connect.php';

$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['grades']) || !is_array($data['grades'])) {
    echo json_encode(['error' => 'Invalid data format']);
    exit;
}

$section_id = intval($data['section_id'] ?? 0);
$subject_id = intval($data['subject_id'] ?? 0);
$quarter = intval($data['quarter'] ?? 1);
$teacher_id = intval($data['teacher_id'] ?? 0);

if (!$section_id || !$subject_id || !$teacher_id) {
    echo json_encode(['error' => 'Section ID, Subject ID, and Teacher ID required']);
    exit;
}

// Get active academic year
$ay_sql = "SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1";
$ay_stmt = $pdo->query($ay_sql);
$academic_year_id = $ay_stmt->fetchColumn() ?: 1;

$success_count = 0;
$error_count = 0;
$errors = [];

foreach ($data['grades'] as $grade) {
    $student_id = intval($grade['student_id'] ?? 0);
    if (!$student_id) continue;

    // Frontend sends computed values in scores object
    $scores = $grade['scores'] ?? [];

    // Total scores (raw sums from individual assessments)
    $ww_total = floatval($scores['ww_total'] ?? 0);
    $pt_total = floatval($scores['pt_total'] ?? 0);
    $qa_total = floatval($scores['qa_total'] ?? 0);

    // Percentage Scores
    $ww_ps = floatval($scores['ww_ps'] ?? 0);
    $pt_ps = floatval($scores['pt_ps'] ?? 0);
    $qa_ps = floatval($scores['qa_ps'] ?? 0);

    // Weighted Scores
    $ww_ws = floatval($scores['ww_ws'] ?? 0);
    $pt_ws = floatval($scores['pt_ws'] ?? 0);
    $qa_ws = floatval($scores['qa_ws'] ?? 0);

    $initial_grade = floatval($grade['initial_grade'] ?? 0);
    $final_grade = intval($grade['final_grade'] ?? 0);
    $remarks = $grade['remarks'] ?? ($final_grade >= 75 ? 'Passed' : 'Failed');

    // Check if grade record exists
    $check_sql = "SELECT id FROM tblgrades 
                  WHERE student_id = :student_id 
                  AND section_id = :section_id 
                  AND subject_id = :subject_id 
                  AND quarter = :quarter 
                  AND academic_year_id = :academic_year_id";
    $check_stmt = $pdo->prepare($check_sql);
    $check_stmt->execute([
        'student_id' => $student_id,
        'section_id' => $section_id,
        'subject_id' => $subject_id,
        'quarter' => $quarter,
        'academic_year_id' => $academic_year_id
    ]);
    $existing = $check_stmt->fetch();

    if ($existing) {
        // Update existing - now includes ww_total, pt_total, qa_total
        $update_sql = "UPDATE tblgrades SET 
            ww_total = :ww_total, pt_total = :pt_total, qa_total = :qa_total,
            ww_ps = :ww_ps, pt_ps = :pt_ps, qa_ps = :qa_ps,
            ww_ws = :ww_ws, pt_ws = :pt_ws, qa_ws = :qa_ws,
            initial_grade = :initial_grade, final_grade = :final_grade, remarks = :remarks,
            updated_at = NOW()
            WHERE id = :id";

        $stmt = $pdo->prepare($update_sql);
        $params = [
            'ww_total' => $ww_total, 'pt_total' => $pt_total, 'qa_total' => $qa_total,
            'ww_ps' => $ww_ps, 'pt_ps' => $pt_ps, 'qa_ps' => $qa_ps,
            'ww_ws' => $ww_ws, 'pt_ws' => $pt_ws, 'qa_ws' => $qa_ws,
            'initial_grade' => $initial_grade, 'final_grade' => $final_grade, 'remarks' => $remarks,
            'id' => $existing['id']
        ];
    } else {
        // Insert new - now includes ww_total, pt_total, qa_total
        $insert_sql = "INSERT INTO tblgrades (
            student_id, section_id, subject_id, teacher_id, quarter, academic_year_id,
            ww_total, pt_total, qa_total,
            ww_ps, pt_ps, qa_ps,
            ww_ws, pt_ws, qa_ws,
            initial_grade, final_grade, remarks,
            created_at, updated_at
        ) VALUES (
            :student_id, :section_id, :subject_id, :teacher_id, :quarter, :academic_year_id,
            :ww_total, :pt_total, :qa_total,
            :ww_ps, :pt_ps, :qa_ps,
            :ww_ws, :pt_ws, :qa_ws,
            :initial_grade, :final_grade, :remarks,
            NOW(), NOW()
        )";

        $stmt = $pdo->prepare($insert_sql);
        $params = [
            'student_id' => $student_id, 'section_id' => $section_id, 'subject_id' => $subject_id,
            'teacher_id' => $teacher_id, 'quarter' => $quarter, 'academic_year_id' => $academic_year_id,
            'ww_total' => $ww_total, 'pt_total' => $pt_total, 'qa_total' => $qa_total,
            'ww_ps' => $ww_ps, 'pt_ps' => $pt_ps, 'qa_ps' => $qa_ps,
            'ww_ws' => $ww_ws, 'pt_ws' => $pt_ws, 'qa_ws' => $qa_ws,
            'initial_grade' => $initial_grade, 'final_grade' => $final_grade, 'remarks' => $remarks
        ];
    }

    try {
        $stmt->execute($params);
        $success_count++;
    } catch (PDOException $e) {
        $error_count++;
        $errors[] = "Student $student_id: " . $e->getMessage();
    }
}

echo json_encode([
    'success' => $error_count === 0,
    'message' => "Saved $success_count records" . ($error_count > 0 ? ", $error_count errors" : ""),
    'saved_count' => $success_count,
    'error_count' => $error_count,
    'errors' => $errors
]);
?>