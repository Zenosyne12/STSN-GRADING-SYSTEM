<?php
// api/grading/get_students.php
header('Content-Type: application/json');

require_once '../../api/shared/db_connect.php';

$section_id = isset($_GET['section_id']) ? intval($_GET['section_id']) : 0;
$subject_id = isset($_GET['subject_id']) ? intval($_GET['subject_id']) : 0;
$quarter = isset($_GET['quarter']) ? intval($_GET['quarter']) : 1;

if (!$section_id || !$subject_id) {
    echo json_encode(['error' => 'Section ID and Subject ID required']);
    exit;
}

// Get students enrolled in this section with their grades
$sql = "SELECT 
            s.id as student_id,
            s.lrn as student_no,
            CONCAT(s.lname, ', ', s.fname, ' ', COALESCE(s.mname, '')) as name,
            s.gender,
            g.id as grade_id,
            g.ww1, g.ww2, g.ww3, g.ww4, g.ww5, g.ww6, g.ww7, g.ww8, g.ww9, g.ww10,
            g.pt1, g.pt2, g.pt3, g.pt4, g.pt5, g.pt6, g.pt7, g.pt8, g.pt9, g.pt10,
            g.qa1,
            g.max_ww1, g.max_ww2, g.max_ww3, g.max_ww4, g.max_ww5, 
            g.max_ww6, g.max_ww7, g.max_ww8, g.max_ww9, g.max_ww10,
            g.max_pt1, g.max_pt2, g.max_pt3, g.max_pt4, g.max_pt5,
            g.max_pt6, g.max_pt7, g.max_pt8, g.max_pt9, g.max_pt10,
            g.max_qa1,
            g.ww_percentage, g.pt_percentage, g.qa_percentage,
            g.ww_total, g.pt_total, g.qa_total,
            g.ww_max_total, g.pt_max_total, g.qa_max_total,
            g.ww_ps, g.pt_ps, g.qa_ps,
            g.ww_ws, g.pt_ws, g.qa_ws,
            g.initial_grade, g.final_grade, g.remarks
        FROM tblstudents s
        INNER JOIN tblsectionstudent ss ON s.id = ss.student_id
        LEFT JOIN tblgrades g ON s.id = g.student_id 
            AND g.section_id = :section_id 
            AND g.subject_id = :subject_id 
            AND g.quarter = :quarter
        WHERE ss.section_id = :section_id2 AND ss.is_active = 1 AND ss.academic_year_id = (
            SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1
        )
        ORDER BY s.lname, s.fname";

$stmt = $pdo->prepare($sql);
$stmt->execute([
    'section_id' => $section_id,
    'subject_id' => $subject_id,
    'quarter' => $quarter,
    'section_id2' => $section_id
]);
$students = [];
$max_scores = null;
$weights = null;

while ($row = $stmt->fetch()) {
    // Store max scores and weights from first record
    if ($max_scores === null && $row['grade_id']) {
        $max_scores = [
            'ww' => [
                $row['max_ww1'], $row['max_ww2'], $row['max_ww3'], $row['max_ww4'], $row['max_ww5'],
                $row['max_ww6'], $row['max_ww7'], $row['max_ww8'], $row['max_ww9'], $row['max_ww10']
            ],
            'pt' => [
                $row['max_pt1'], $row['max_pt2'], $row['max_pt3'], $row['max_pt4'], $row['max_pt5'],
                $row['max_pt6'], $row['max_pt7'], $row['max_pt8'], $row['max_pt9'], $row['max_pt10']
            ],
            'qa' => [$row['max_qa1']]
        ];
        $weights = [
            'ww' => $row['ww_percentage'],
            'pt' => $row['pt_percentage'],
            'qa' => $row['qa_percentage']
        ];
    }

    $students[] = [
        'student_id' => $row['student_id'],
        'student_no' => $row['student_no'],
        'name' => $row['name'],
        'gender' => $row['gender'],
        'scores' => [
            'ww' => [
                floatval($row['ww1'] ?? 0), floatval($row['ww2'] ?? 0), floatval($row['ww3'] ?? 0),
                floatval($row['ww4'] ?? 0), floatval($row['ww5'] ?? 0), floatval($row['ww6'] ?? 0),
                floatval($row['ww7'] ?? 0), floatval($row['ww8'] ?? 0), floatval($row['ww9'] ?? 0),
                floatval($row['ww10'] ?? 0)
            ],
            'pt' => [
                floatval($row['pt1'] ?? 0), floatval($row['pt2'] ?? 0), floatval($row['pt3'] ?? 0),
                floatval($row['pt4'] ?? 0), floatval($row['pt5'] ?? 0), floatval($row['pt6'] ?? 0),
                floatval($row['pt7'] ?? 0), floatval($row['pt8'] ?? 0), floatval($row['pt9'] ?? 0),
                floatval($row['pt10'] ?? 0)
            ],
            'qa' => [floatval($row['qa1'] ?? 0)]
        ],
        'totals' => [
            'ww' => floatval($row['ww_total'] ?? 0),
            'pt' => floatval($row['pt_total'] ?? 0),
            'qa' => floatval($row['qa_total'] ?? 0)
        ],
        'max_totals' => [
            'ww' => floatval($row['ww_max_total'] ?? 0),
            'pt' => floatval($row['pt_max_total'] ?? 0),
            'qa' => floatval($row['qa_max_total'] ?? 0)
        ],
        'ps' => [
            'ww' => floatval($row['ww_ps'] ?? 0),
            'pt' => floatval($row['pt_ps'] ?? 0),
            'qa' => floatval($row['qa_ps'] ?? 0)
        ],
        'ws' => [
            'ww' => floatval($row['ww_ws'] ?? 0),
            'pt' => floatval($row['pt_ws'] ?? 0),
            'qa' => floatval($row['qa_ws'] ?? 0)
        ],
        'initial_grade' => floatval($row['initial_grade'] ?? 0),
        'final_grade' => intval($row['final_grade'] ?? 0),
        'remarks' => $row['remarks'] ?: 'Failed'
    ];
}

// Default max scores if none stored yet
if ($max_scores === null) {
    $max_scores = [
        'ww' => [10, 10, 20, 20, 50, 50, 100, 100, 100, 100],
        'pt' => [50, 50, 50, 50, 100, 100, 100, 100, 100, 100],
        'qa' => [100]
    ];
}
if ($weights === null) {
    $weights = ['ww' => 40, 'pt' => 40, 'qa' => 20];
}

echo json_encode([
    'success' => true,
    'students' => $students,
    'max_scores' => $max_scores,
    'weights' => $weights,
    'count' => count($students)
]);
?>