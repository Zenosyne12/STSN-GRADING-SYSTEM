<?php
// api/grading/get_students.php
// Retrieves students with total scores (ww_total, pt_total, qa_total) + PS, WS, initial, final, remarks
header('Content-Type: application/json');

require_once '../../api/shared/db_connect.php';

$section_id = isset($_GET['section_id']) ? intval($_GET['section_id']) : 0;
$subject_id = isset($_GET['subject_id']) ? intval($_GET['subject_id']) : 0;
$quarter = isset($_GET['quarter']) ? intval($_GET['quarter']) : 1;

if (!$section_id || !$subject_id) {
    echo json_encode(['error' => 'Section ID and Subject ID required']);
    exit;
}

// Get active academic year
$ay_sql = "SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1";
$ay_stmt = $pdo->query($ay_sql);
$academic_year_id = $ay_stmt->fetchColumn() ?: 1;

// Get students with their computed grades including total scores
$sql = "SELECT 
            s.id as student_id,
            s.lrn as student_no,
            CONCAT(s.lname, ', ', s.fname, ' ', COALESCE(s.mname, '')) as name,
            s.gender,
            g.id as grade_id,
            g.ww_total, g.pt_total, g.qa_total,
            g.ww_ps, g.pt_ps, g.qa_ps,
            g.ww_ws, g.pt_ws, g.qa_ws,
            g.initial_grade, g.final_grade, g.remarks
        FROM tblstudents s
        INNER JOIN tblsectionstudent ss ON s.id = ss.student_id
        LEFT JOIN tblgrades g ON s.id = g.student_id 
            AND g.section_id = :section_id 
            AND g.subject_id = :subject_id 
            AND g.quarter = :quarter
            AND g.academic_year_id = :academic_year_id
        WHERE ss.section_id = :section_id2 
          AND ss.is_active = 1 
          AND ss.academic_year_id = :academic_year_id2
        ORDER BY s.lname, s.fname";

$stmt = $pdo->prepare($sql);
$stmt->execute([
    'section_id' => $section_id,
    'subject_id' => $subject_id,
    'quarter' => $quarter,
    'academic_year_id' => $academic_year_id,
    'section_id2' => $section_id,
    'academic_year_id2' => $academic_year_id
]);

$students = [];
$weights = null;

while ($row = $stmt->fetch()) {
    // Build scores object that frontend expects - now includes total scores
    $students[] = [
        'student_id' => $row['student_id'],
        'student_no' => $row['student_no'],
        'name' => $row['name'],
        'gender' => $row['gender'],
        'scores' => [
            'ww_total' => floatval($row['ww_total'] ?? 0),  // Now retrieved from DB
            'pt_total' => floatval($row['pt_total'] ?? 0),  // Now retrieved from DB
            'qa_total' => floatval($row['qa_total'] ?? 0),  // Now retrieved from DB
            'ww_ps' => floatval($row['ww_ps'] ?? 0),
            'pt_ps' => floatval($row['pt_ps'] ?? 0),
            'qa_ps' => floatval($row['qa_ps'] ?? 0),
            'ww_ws' => floatval($row['ww_ws'] ?? 0),
            'pt_ws' => floatval($row['pt_ws'] ?? 0),
            'qa_ws' => floatval($row['qa_ws'] ?? 0)
        ],
        'initial_grade' => floatval($row['initial_grade'] ?? 0),
        'final_grade' => intval($row['final_grade'] ?? 0),
        'remarks' => $row['remarks'] ?: 'Failed'
    ];
}

// Default weights (frontend will override from curriculum)
$weights = ['ww' => 40, 'pt' => 40, 'qa' => 20];

// Default max scores (frontend uses these for display/calculation)
$max_scores = ['ww' => 100, 'pt' => 100, 'qa' => 100];

echo json_encode([
    'success' => true,
    'students' => $students,
    'max_scores' => $max_scores,
    'weights' => $weights,
    'count' => count($students)
]);
?>