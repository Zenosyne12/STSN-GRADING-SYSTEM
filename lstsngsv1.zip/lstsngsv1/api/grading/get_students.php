<?php
/**
 * api/grading/get_students.php
 * ---------------------------------------------------------------------
 * Students + the ACTIVE grading configuration for the Grading Sheet.
 *
 * The grading configuration (component weights, passing threshold,
 * rounding rule, transmutation table, template identity, descriptor
 * rating options) is resolved SERVER-SIDE from the active grading
 * template for the section's grade level via includes/grading_engine.php.
 * The sheet renders these values and uses them for its live computation,
 * so a template change on the Grading Templates page takes effect on the
 * next load of this sheet.
 *
 * Fallbacks (40/40/20, passing 75, ROUND, legacy A/P/AP/D/B dropdown)
 * apply ONLY when no template is configured at all.
 * ---------------------------------------------------------------------
 */

header('Content-Type: application/json');

require_once '../../api/shared/db_connect.php';
require_once '../../includes/grading_engine.php';
require_once '../../includes/descriptor_engine.php';

$section_id = isset($_GET['section_id']) ? intval($_GET['section_id']) : 0;
$subject_id = isset($_GET['subject_id']) ? intval($_GET['subject_id']) : 0;
$quarter = isset($_GET['quarter']) ? intval($_GET['quarter']) : 1;

if (!$section_id || !$subject_id) {
    echo json_encode(['error' => 'Section ID and Subject ID required']);
    exit;
}


$ay_sql = "SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1";
$ay_stmt = $pdo->query($ay_sql);
$academic_year_id = $ay_stmt->fetchColumn() ?: 1;


$sql = "SELECT 
            s.id as student_id,
            s.lrn as student_no,
            CONCAT(s.lname, ', ', s.fname, ' ', COALESCE(s.mname, '')) as name,
            s.gender,
            g.id as grade_id,
            g.ww_total, g.pt_total, g.qa_total,
            g.ww_ps, g.pt_ps, g.qa_ps,
            g.ww_ws, g.pt_ws, g.qa_ws,
            g.initial_grade, g.final_grade, g.remarks
        FROM tblstudents s
        INNER JOIN tblsectionstudent ss ON s.id = ss.student_id
        LEFT JOIN tblgrades g ON s.id = g.student_id 
            AND g.section_id = :section_id 
            AND g.subject_id = :subject_id 
            AND g.quarter = :quarter
            AND g.academic_year_id = :academic_year_id
        WHERE ss.section_id = :section_id2 
          AND ss.is_active = 1 
          AND ss.academic_year_id = :academic_year_id2
        ORDER BY s.lname, s.fname";

$stmt = $pdo->prepare($sql);
$stmt->execute([
    'section_id' => $section_id,
    'subject_id' => $subject_id,
    'quarter' => $quarter,
    'academic_year_id' => $academic_year_id,
    'section_id2' => $section_id,
    'academic_year_id2' => $academic_year_id
]);

$students = [];

while ($row = $stmt->fetch()) {
    
    $students[] = [
        'student_id' => $row['student_id'],
        'lrn' => $row['student_no'],
        'student_no' => $row['student_no'],
        'name' => $row['name'],
        'gender' => $row['gender'],
        'scores' => [
            'ww_total' => floatval($row['ww_total'] ?? 0),  
            'pt_total' => floatval($row['pt_total'] ?? 0),  
            'qa_total' => floatval($row['qa_total'] ?? 0),  
            'ww_ps' => floatval($row['ww_ps'] ?? 0),
            'pt_ps' => floatval($row['pt_ps'] ?? 0),
            'qa_ps' => floatval($row['qa_ps'] ?? 0),
            'ww_ws' => floatval($row['ww_ws'] ?? 0),
            'pt_ws' => floatval($row['pt_ws'] ?? 0),
            'qa_ws' => floatval($row['qa_ws'] ?? 0)
        ],
        'initial_grade' => floatval($row['initial_grade'] ?? 0),
        'final_grade' => intval($row['final_grade'] ?? 0),
        'remarks' => $row['remarks'] ?: 'Failed'
    ];
}


/* ---------------------------------------------------------------------
 * Grading configuration — resolved from the ACTIVE GRADING TEMPLATE.
 * (Previously this endpoint returned a hardcoded 40/40/20 array which
 * overwrote the template values in the sheet; that was the root cause
 * of template changes never reaching the grading sheet.)
 * ------------------------------------------------------------------- */
$gradeLevelId = 0;
try {
    $secStmt = $pdo->prepare("SELECT grade_level_id FROM tblsection WHERE id = ? LIMIT 1");
    $secStmt->execute([$section_id]);
    $gradeLevelId = (int)($secStmt->fetchColumn() ?: 0);
} catch (Throwable $e) {
    error_log('get_students: grade level lookup failed: ' . $e->getMessage());
}

$programId = ($gradeLevelId > 0 && function_exists('geResolveProgramId'))
    ? geResolveProgramId($pdo, $section_id)
    : null;

$template = ($gradeLevelId > 0)
    ? getActiveGradingTemplate($pdo, $gradeLevelId, $programId)
    : null;

// Fallbacks apply only when NO template exists at all.
$weights = [
    'ww' => $template !== null ? (float)$template['ww_weight'] : 40.0,
    'pt' => $template !== null ? (float)$template['pt_weight'] : 40.0,
    'qa' => $template !== null ? (float)$template['qa_weight'] : 20.0,
];
$passing_threshold = $template !== null ? (int)$template['passing_threshold'] : 75;
$rounding_rule     = $template !== null ? (string)$template['rounding_rule'] : 'ROUND';

$transmutation_table = ($template !== null && !empty($template['id']))
    ? getTransmutationTable($pdo, (int)$template['id'])
    : [];

// Descriptor rating options (dropdown) for descriptive/kindergarten modes.
$rating_options = ($gradeLevelId > 0) ? geGetRatingOptions($pdo, $gradeLevelId) : [];
$rating_equivalents = function_exists('geDescriptiveEquivalents')
    ? geDescriptiveEquivalents()
    : ['A' => 95, 'P' => 90, 'AP' => 85, 'D' => 80, 'B' => 75];

// Grading mode of the subject (NUMERICAL / DESCRIPTIVE) — the sheet uses
// this to switch between score inputs and rating dropdowns.
$grading_mode = 'NUMERICAL';
try {
    $gmStmt = $pdo->prepare("SELECT grading_mode FROM tblsubjects WHERE id = ? LIMIT 1");
    $gmStmt->execute([$subject_id]);
    $grading_mode = ($gmStmt->fetchColumn() ?: 'NUMERICAL');
} catch (Throwable $e) {}

error_log(
    'get_students: template=' . ($template['id'] ?? 'NONE')
    . ' weights=' . $weights['ww'] . '/' . $weights['pt'] . '/' . $weights['qa']
    . ' passing=' . $passing_threshold
    . ' rounding=' . $rounding_rule
    . ' transmutation_rows=' . count($transmutation_table)
    . ' rating_options=' . count($rating_options)
    . ' mode=' . $grading_mode
);

$max_scores = ['ww' => 100, 'pt' => 100, 'qa' => 100];

echo json_encode([
    'success' => true,
    'students' => $students,
    'max_scores' => $max_scores,
    'weights' => $weights,
    'passing_threshold' => $passing_threshold,
    'rounding_rule' => $rounding_rule,
    'template_id' => $template !== null ? (int)$template['id'] : 0,
    'template_name' => $template !== null ? (string)$template['template_name'] : 'Default',
    'transmutation_table' => $transmutation_table,
    'rating_options' => $rating_options,
    'rating_equivalents' => $rating_equivalents,
    'grading_mode' => $grading_mode,
    'count' => count($students)
]);
?>
