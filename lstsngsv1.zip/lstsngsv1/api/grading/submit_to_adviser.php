<?php
header('Content-Type: application/json');
require_once '../../api/shared/db_connect.php';
require_once '../../api/shared/auth.php';
require_once '../../api/deadline/check_submission_lock.php';
require_once '../../api/shared/grade_workflow.php';
require_once __DIR__ . '/../../includes/workflow_engine.php';

$teacher_id = $_SESSION['teacher_id'] ?? 0;
if (!$teacher_id) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized. Please login as teacher.']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$section_id = intval($data['section_id'] ?? 0);
$subject_id = intval($data['subject_id'] ?? 0);
$quarter    = intval($data['quarter'] ?? 1);

if (!$section_id || !$subject_id || !$quarter) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'section_id, subject_id, and quarter are required.']);
    exit;
}

$ay_stmt = $pdo->query("SELECT id, year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
$activeYear = $ay_stmt->fetch(PDO::FETCH_ASSOC);
if (!$activeYear) {
    echo json_encode(['success' => false, 'message' => 'No active academic year found.']);
    exit;
}
$academic_year_id = $activeYear['id'];
$school_year = $activeYear['year_label'];

try {
    ensureGradeWorkflowSchema($pdo);

    checkSubmissionLock($pdo, $teacher_id, $section_id, $subject_id, $quarter, $school_year, 'teacher');

    $lockCheck = $pdo->prepare("
        SELECT COUNT(*)
        FROM tbldeadline_locks
        WHERE teacher_id = ? AND section_id = ? AND subject_id = ? AND quarter = ? AND school_year = ? AND is_locked = 1
    ");
    $lockCheck->execute([$teacher_id, $section_id, $subject_id, $quarter, $school_year]);
    if ((int)$lockCheck->fetchColumn() > 0) {
        echo json_encode(['success' => false, 'message' => 'Submission locked. Please contact admin to unlock.']);
        exit;
    }

    $verifyStmt = $pdo->prepare("
        SELECT 1
        FROM (
            SELECT sts.section_id, sts.subject_id, sts.teacher_id
            FROM tblsection_teacher_subject sts
            WHERE sts.is_active = 1
            UNION ALL
            SELECT sch.section_id, sch.subject_id, sch.teacher_id
            FROM tblschedule sch
            WHERE sch.is_active = 1
        ) t
        WHERE t.section_id = ? AND t.subject_id = ? AND t.teacher_id = ?
        LIMIT 1
    ");
    $verifyStmt->execute([$section_id, $subject_id, $teacher_id]);
    if (!$verifyStmt->fetch()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'You are not assigned to teach this subject in this section.']);
        exit;
    }

    $countStmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM tblgrades
        WHERE section_id = :section_id
          AND subject_id = :subject_id
          AND teacher_id = :teacher_id
          AND quarter = :quarter
          AND academic_year_id = :year_id
    ");
    $countStmt->execute([
        ':section_id' => $section_id,
        ':subject_id' => $subject_id,
        ':teacher_id' => $teacher_id,
        ':quarter' => $quarter,
        ':year_id' => $academic_year_id
    ]);
    $savedCount = (int)$countStmt->fetchColumn();

    if ($savedCount === 0) {
        echo json_encode(['success' => false, 'message' => 'No saved grades found to submit. Please save grades first.']);
        exit;
    }

    $existingStmt = $pdo->prepare("
        SELECT id
        FROM tblteacher_submissions
        WHERE teacher_id = ? AND section_id = ? AND subject_id = ? AND quarter = ? AND school_year = ?
        LIMIT 1
    ");
    $existingStmt->execute([$teacher_id, $section_id, $subject_id, $quarter, $school_year]);
    $existing = $existingStmt->fetch(PDO::FETCH_ASSOC);

    if ($existing) {
        $updSubmit = $pdo->prepare("
            UPDATE tblteacher_submissions
            SET submitted_at = NOW(), updated_at = NOW()
            WHERE id = ?
        ");
        $updSubmit->execute([(int)$existing['id']]);
    } else {
        $insSubmit = $pdo->prepare("
            INSERT INTO tblteacher_submissions
                (teacher_id, section_id, subject_id, quarter, school_year, submitted_at, created_at, updated_at)
            VALUES
                (:teacher_id, :section_id, :subject_id, :quarter, :school_year, NOW(), NOW(), NOW())
        ");
        $insSubmit->execute([
            ':teacher_id' => $teacher_id,
            ':section_id' => $section_id,
            ':subject_id' => $subject_id,
            ':quarter' => $quarter,
            ':school_year' => $school_year
        ]);
    }

    $statusStmt = $pdo->prepare("
        UPDATE tblgrades
        SET status = 'submitted_to_adviser', updated_at = NOW()
        WHERE section_id = :section_id
          AND subject_id = :subject_id
          AND teacher_id = :teacher_id
          AND quarter = :quarter
          AND academic_year_id = :year_id
          AND status IN ('draft', 'pending_adviser', 'returned')
    ");
    $statusStmt->execute([
        ':section_id' => $section_id,
        ':subject_id' => $subject_id,
        ':teacher_id' => $teacher_id,
        ':quarter' => $quarter,
        ':year_id' => $academic_year_id
    ]);

    // -----------------------------------------------------------------
    // Workflow engine (ADDITIVE — legacy tblgrades.status flow above is
    // untouched and still works even if no workflow template is found).
    // -----------------------------------------------------------------
    $workflowResponse = null;

    try {
        // Get grade level from section
        $glStmt = $pdo->prepare("SELECT grade_level_id FROM tblsection WHERE id = ?");
        $glStmt->execute([$section_id]);
        $gradeLevelId = (int)$glStmt->fetchColumn();

        // Find active template
        $tmpl = getActiveTemplate($pdo, $gradeLevelId);

        if ($tmpl && !empty($tmpl['template']['id'])) {
            // Get term_id from tblconfig_terms (fallback: tblquarters)
            $termId = 0;
            try {
                $termStmt = $pdo->prepare("
                    SELECT id FROM tblconfig_terms
                    WHERE academic_year_id = ? AND term_number = ?
                    LIMIT 1
                ");
                $termStmt->execute([$academic_year_id, $quarter]);
                $termId = (int)$termStmt->fetchColumn();
            } catch (PDOException $e) {
                $termId = 0; // tblconfig_terms not present in this schema
            }

            if (!$termId) {
                try {
                    $termStmt = $pdo->prepare("
                        SELECT id FROM tblquarters
                        WHERE academic_year_id = ? AND quarter_number = ?
                        LIMIT 1
                    ");
                    $termStmt->execute([$academic_year_id, $quarter]);
                    $termId = (int)$termStmt->fetchColumn();
                } catch (PDOException $e) {
                    $termId = 0;
                }
            }

            if ($termId) {
                $wfResult = startWorkflow($pdo, [
                    'section_id'       => $section_id,
                    'subject_id'       => $subject_id,
                    'term_id'          => $termId,
                    'academic_year_id' => $academic_year_id,
                    'teacher_id'       => $teacher_id,
                    'template_id'      => (int)$tmpl['template']['id'],
                    'actor_role_id'    => (int)($_SESSION['role_id'] ?? 2),
                ]);

                if (!empty($wfResult['success']) && !empty($wfResult['instance_id'])) {
                    $nextStep = $wfResult['next_step'] ?? null;
                    $workflowResponse = [
                        'instance_id'    => (int)$wfResult['instance_id'],
                        'next_step_label' => $nextStep['step_label'] ?? null,
                        'next_position'  => $nextStep['required_position'] ?? null,
                    ];
                }
            }
        }
    } catch (Throwable $wfError) {
        // Never block the grade submission on workflow failures.
        $workflowResponse = null;
    }

    echo json_encode([
        'success' => true,
        'message' => "Grades submitted to adviser successfully. $savedCount saved grade record(s) included.",
        'submitted_count' => $savedCount,
        'section_id' => $section_id,
        'subject_id' => $subject_id,
        'quarter' => $quarter,
        'school_year' => $school_year,
        'workflow' => $workflowResponse
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
