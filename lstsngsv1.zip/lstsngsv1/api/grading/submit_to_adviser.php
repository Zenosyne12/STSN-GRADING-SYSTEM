<?php
header('Content-Type: application/json');
require_once '../../api/shared/db_connect.php';
require_once '../../api/shared/auth.php';
require_once '../../api/deadline/check_submission_lock.php';
require_once '../../api/shared/grade_workflow.php';
require_once __DIR__ . '/../../includes/workflow_engine.php';

$teacher_id = $_SESSION['teacher_id'] ?? 0;
if (!$teacher_id) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized. Please login as teacher.']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$section_id = intval($data['section_id'] ?? 0);
$subject_id = intval($data['subject_id'] ?? 0);
$quarter    = intval($data['quarter'] ?? 1);

if (!$section_id || !$subject_id || !$quarter) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'section_id, subject_id, and quarter are required.']);
    exit;
}

$ay_stmt = $pdo->query("SELECT id, year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
$activeYear = $ay_stmt->fetch(PDO::FETCH_ASSOC);
if (!$activeYear) {
    echo json_encode(['success' => false, 'message' => 'No active academic year found.']);
    exit;
}
$academic_year_id = $activeYear['id'];
$school_year = $activeYear['year_label'];

try {
    ensureGradeWorkflowSchema($pdo);

    checkSubmissionLock($pdo, $teacher_id, $section_id, $subject_id, $quarter, $school_year, 'teacher');

    $lockCheck = $pdo->prepare("
        SELECT COUNT(*)
        FROM tbldeadline_locks
        WHERE teacher_id = ? AND section_id = ? AND subject_id = ? AND quarter = ? AND school_year = ? AND is_locked = 1
    ");
    $lockCheck->execute([$teacher_id, $section_id, $subject_id, $quarter, $school_year]);
    if ((int)$lockCheck->fetchColumn() > 0) {
        echo json_encode(['success' => false, 'message' => 'Submission locked. Please contact admin to unlock.']);
        exit;
    }

    $verifyStmt = $pdo->prepare("
        SELECT 1
        FROM (
            SELECT sts.section_id, sts.subject_id, sts.teacher_id
            FROM tblsection_teacher_subject sts
            WHERE sts.is_active = 1
            UNION ALL
            SELECT sch.section_id, sch.subject_id, sch.teacher_id
            FROM tblschedule sch
            WHERE sch.is_active = 1
        ) t
        WHERE t.section_id = ? AND t.subject_id = ? AND t.teacher_id = ?
        LIMIT 1
    ");
    $verifyStmt->execute([$section_id, $subject_id, $teacher_id]);
    if (!$verifyStmt->fetch()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'You are not assigned to teach this subject in this section.']);
        exit;
    }

    $countStmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM tblgrades
        WHERE section_id = :section_id
          AND subject_id = :subject_id
          AND teacher_id = :teacher_id
          AND quarter = :quarter
          AND academic_year_id = :year_id
    ");
    $countStmt->execute([
        ':section_id' => $section_id,
        ':subject_id' => $subject_id,
        ':teacher_id' => $teacher_id,
        ':quarter' => $quarter,
        ':year_id' => $academic_year_id
    ]);
    $savedCount = (int)$countStmt->fetchColumn();

    if ($savedCount === 0) {
        echo json_encode(['success' => false, 'message' => 'No saved grades found to submit. Please save grades first.']);
        exit;
    }

    $gradeLevelStmt = $pdo->prepare("SELECT grade_level_id FROM tblsection WHERE id = ? LIMIT 1");
    $gradeLevelStmt->execute([$section_id]);
    $gradeLevelId = (int)$gradeLevelStmt->fetchColumn();
    $template = getActiveTemplate($pdo, $gradeLevelId, (int)$academic_year_id);
    $workflowStepOrders = array_map('intval', array_column($template['steps'] ?? [], 'step_order'));
    if (!$template || empty($template['template']['id']) || !in_array(2, $workflowStepOrders, true)) {
        http_response_code(409);
        echo json_encode([
            'success' => false,
            'message' => 'An active grade approval workflow is not configured for this section. Grades were not submitted.'
        ]);
        exit;
    }

    $termStmt = $pdo->prepare("
        SELECT id
        FROM tblconfig_terms
        WHERE academic_year_id = ? AND term_number = ?
        LIMIT 1
    ");
    $termStmt->execute([$academic_year_id, $quarter]);
    $termId = (int)$termStmt->fetchColumn();
    if ($termId <= 0) {
        http_response_code(409);
        echo json_encode([
            'success' => false,
            'message' => 'The approval workflow term could not be resolved. Grades were not submitted.'
        ]);
        exit;
    }

    $pdo->beginTransaction();
    $workflowResult = startWorkflow($pdo, [
        'section_id' => $section_id,
        'subject_id' => $subject_id,
        'term_id' => $termId,
        'academic_year_id' => (int)$academic_year_id,
        'teacher_id' => (int)$teacher_id,
        'template_id' => (int)$template['template']['id'],
        'actor_role_id' => (int)($_SESSION['role_id'] ?? 2),
    ]);
    if (empty($workflowResult['success']) || empty($workflowResult['instance_id'])) {
        throw new RuntimeException($workflowResult['message'] ?? 'Unable to start the grade approval workflow.');
    }
    if (($workflowResult['status'] ?? '') === 'COMPLETED') {
        $pdo->rollBack();
        http_response_code(409);
        echo json_encode([
            'success' => false,
            'message' => 'These grades have already passed approval and been published.'
        ]);
        exit;
    }
    $nextStep = $workflowResult['next_step'] ?? null;
    $workflowResponse = [
        'instance_id' => (int)$workflowResult['instance_id'],
        'next_step_label' => $nextStep['step_label'] ?? null,
        'next_position' => $nextStep['required_position'] ?? null,
        'status' => $workflowResult['status'] ?? 'IN_PROGRESS',
    ];

    $existingStmt = $pdo->prepare("
        SELECT id
        FROM tblteacher_submissions
        WHERE teacher_id = ? AND section_id = ? AND subject_id = ? AND quarter = ? AND school_year = ?
        LIMIT 1
    ");
    $existingStmt->execute([$teacher_id, $section_id, $subject_id, $quarter, $school_year]);
    $existing = $existingStmt->fetch(PDO::FETCH_ASSOC);

    if ($existing) {
        $updSubmit = $pdo->prepare("
            UPDATE tblteacher_submissions
            SET submitted_at = NOW(), updated_at = NOW()
            WHERE id = ?
        ");
        $updSubmit->execute([(int)$existing['id']]);
    } else {
        $insSubmit = $pdo->prepare("
            INSERT INTO tblteacher_submissions
                (teacher_id, section_id, subject_id, quarter, school_year, submitted_at, created_at, updated_at)
            VALUES
                (:teacher_id, :section_id, :subject_id, :quarter, :school_year, NOW(), NOW(), NOW())
        ");
        $insSubmit->execute([
            ':teacher_id' => $teacher_id,
            ':section_id' => $section_id,
            ':subject_id' => $subject_id,
            ':quarter' => $quarter,
            ':school_year' => $school_year
        ]);
    }

    $statusStmt = $pdo->prepare("
        UPDATE tblgrades
        SET status = 'submitted_to_adviser', updated_at = NOW()
        WHERE section_id = :section_id
          AND subject_id = :subject_id
          AND teacher_id = :teacher_id
          AND quarter = :quarter
          AND academic_year_id = :year_id
          AND status IN ('draft', 'pending_adviser', 'returned')
    ");
    $statusStmt->execute([
        ':section_id' => $section_id,
        ':subject_id' => $subject_id,
        ':teacher_id' => $teacher_id,
        ':quarter' => $quarter,
        ':year_id' => $academic_year_id
    ]);
    $pdo->commit();

    $notificationsSent = 0;
    $notificationWarning = null;
    try {
        $adviserStmt = $pdo->prepare("
            SELECT DISTINCT teacher_id
            FROM tblsectionadviser
            WHERE section_id = ? AND academic_year_id = ?
        ");
        $adviserStmt->execute([$section_id, $academic_year_id]);
        $adviserIds = array_map('intval', $adviserStmt->fetchAll(PDO::FETCH_COLUMN));

        if (!$adviserIds) {
            $notificationWarning = 'Grade submission succeeded, but no assigned adviser was found to notify.';
        } else {
            $contextStmt = $pdo->prepare("
                SELECT s.section_name, gl.grade_level_name, sub.subject_name,
                       CONCAT_WS(' ', teacher.fname, teacher.lname) AS teacher_name
                FROM tblsection s
                JOIN tblgradelevel gl ON gl.id = s.grade_level_id
                JOIN tblsubjects sub ON sub.id = ?
                LEFT JOIN tblteacher teacher ON teacher.id = ?
                WHERE s.id = ?
                LIMIT 1
            ");
            $contextStmt->execute([$subject_id, $teacher_id, $section_id]);
            $context = $contextStmt->fetch(PDO::FETCH_ASSOC) ?: [];

            $termStmt = $pdo->prepare("
                SELECT term_label
                FROM tblconfig_terms
                WHERE academic_year_id = ? AND term_number = ?
                LIMIT 1
            ");
            $termStmt->execute([$academic_year_id, $quarter]);
            $termLabel = (string)($termStmt->fetchColumn() ?: ('Term ' . $quarter));

            $notificationStmt = $pdo->prepare("
                INSERT INTO system_notifications (title, message, type, created_at)
                VALUES (?, ?, ?, NOW())
            ");
            $title = 'Grades submitted for review';
            $message = sprintf(
                '%s submitted %s grades for %s - %s (%s, S.Y. %s). Ready for adviser review.',
                trim((string)($context['teacher_name'] ?? 'A teacher')) ?: 'A teacher',
                (string)($context['subject_name'] ?? 'subject'),
                (string)($context['grade_level_name'] ?? 'Section'),
                (string)($context['section_name'] ?? ''),
                $termLabel,
                $school_year
            );
            foreach ($adviserIds as $adviserId) {
                $notificationStmt->execute([$title, $message, 'adviser:' . $adviserId]);
                $notificationsSent++;
            }
        }
    } catch (Throwable $notificationError) {
        $notificationWarning = 'Grade submission succeeded, but the adviser notification could not be sent.';
        error_log('[submit_to_adviser notification error] ' . $notificationError->getMessage());
    }

    try {
        $teacherContextStmt = $pdo->prepare("
            SELECT s.section_name, gl.grade_level_name, sub.subject_name
            FROM tblsection s
            JOIN tblgradelevel gl ON gl.id = s.grade_level_id
            JOIN tblsubjects sub ON sub.id = ?
            WHERE s.id = ?
            LIMIT 1
        ");
        $teacherContextStmt->execute([$subject_id, $section_id]);
        $teacherContext = $teacherContextStmt->fetch(PDO::FETCH_ASSOC) ?: [];
        $teacherTermStmt = $pdo->prepare("
            SELECT term_label
            FROM tblconfig_terms
            WHERE academic_year_id = ? AND term_number = ?
            LIMIT 1
        ");
        $teacherTermStmt->execute([$academic_year_id, $quarter]);
        $teacherTermLabel = (string)($teacherTermStmt->fetchColumn() ?: ('Term ' . $quarter));
        $teacherNotificationStmt = $pdo->prepare("
            INSERT INTO system_notifications (title, message, type, created_at)
            VALUES (?, ?, ?, NOW())
        ");
        $teacherNotificationStmt->execute([
            'Grades processing',
            sprintf(
                '%s grades for %s - %s (%s, S.Y. %s) were submitted and are processing for review and publication.',
                (string)($teacherContext['subject_name'] ?? 'Subject'),
                (string)($teacherContext['grade_level_name'] ?? 'Section'),
                (string)($teacherContext['section_name'] ?? ''),
                $teacherTermLabel,
                $school_year
            ),
            'teacher:' . $teacher_id
        ]);
        $notificationsSent++;
    } catch (Throwable $teacherNotificationError) {
        $notificationWarning = 'Grade submission succeeded, but your processing notification could not be sent.';
        error_log('[submit_to_adviser teacher notification error] ' . $teacherNotificationError->getMessage());
    }

    $responseMessage = "Grades submitted to adviser successfully. $savedCount saved grade record(s) included.";
    if ($notificationWarning !== null) {
        $responseMessage .= ' ' . $notificationWarning;
    }

    echo json_encode([
        'success' => true,
        'message' => $responseMessage,
        'submitted_count' => $savedCount,
        'notifications_sent' => $notificationsSent,
        'section_id' => $section_id,
        'subject_id' => $subject_id,
        'quarter' => $quarter,
        'school_year' => $school_year,
        'workflow' => $workflowResponse
    ]);

} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('[submit_to_adviser] ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Unable to submit grades for approval. Please try again or contact an administrator.']);
}
