<?php
header('Content-Type: application/json');

require_once '../../api/shared/db_connect.php';
require_once '../../api/deadline/check_submission_lock.php';
require_once '../../api/shared/grade_workflow.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !is_array($data)) {
    echo json_encode(['success' => false, 'error' => 'Invalid data format']);
    exit;
}

$section_id       = intval($data['section_id'] ?? 0);
$term_id          = intval($data['term_id'] ?? 0);
$academic_year_id = intval($data['academic_year_id'] ?? 0);
$teacher_id       = intval($_SESSION['teacher_id'] ?? ($data['teacher_id'] ?? 0));

if (!$section_id || !$term_id || !$academic_year_id || !$teacher_id) {
    echo json_encode(['success' => false, 'error' => 'Section ID, Term ID, Academic Year ID, and Teacher ID required']);
    exit;
}

$ratings    = (isset($data['ratings']) && is_array($data['ratings'])) ? $data['ratings'] : [];
$narratives = (isset($data['narratives']) && is_array($data['narratives'])) ? $data['narratives'] : [];

if (count($ratings) === 0 && count($narratives) === 0) {
    echo json_encode(['success' => false, 'error' => 'Nothing to save: provide ratings and/or narratives']);
    exit;
}

$allowedRatings = ['A', 'S', 'R', 'N'];

// Validate every rating BEFORE touching the database (transaction = all or nothing)
foreach ($ratings as $rating) {
    $studentId = intval($rating['student_id'] ?? 0);
    $skillId   = intval($rating['skill_id'] ?? 0);
    $code      = strtoupper(trim((string)($rating['rating'] ?? '')));

    if (!$studentId) {
        echo json_encode(['success' => false, 'error' => 'Every rating needs a student_id']);
        exit;
    }
    if (!$skillId) {
        echo json_encode(['success' => false, 'error' => 'Every rating needs a skill_id']);
        exit;
    }
    if (!in_array($code, $allowedRatings, true)) {
        echo json_encode([
            'success' => false,
            'error'   => "Invalid rating '{$code}' for student {$studentId}. Allowed: A, S, R, N"
        ]);
        exit;
    }
}

foreach ($narratives as $narrative) {
    if (!intval($narrative['student_id'] ?? 0)) {
        echo json_encode(['success' => false, 'error' => 'Every narrative needs a student_id']);
        exit;
    }
}

// Archive term lock — locked terms are read-only for teachers
try {
    $lockStmt = $pdo->prepare("SELECT is_locked FROM tblconfig_terms WHERE id = ? LIMIT 1");
    $lockStmt->execute([$term_id]);
    $isTermLocked = (bool) $lockStmt->fetchColumn();
} catch (Throwable $e) {
    $isTermLocked = false;
}
if ($isTermLocked) {
    echo json_encode(['success' => false, 'error' => 'Term is locked']);
    exit;
}

$savedCount     = 0;
$narrativeCount = 0;

try {
    $pdo->beginTransaction();

    // Upsert ratings — unique key: (student_id, skill_id, term_id, academic_year_id)
    $ratingSql = "INSERT INTO tblkinder_assessments
        (student_id, section_id, term_id, academic_year_id, skill_id, rating, assessed_by, assessed_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE
            rating = VALUES(rating),
            assessed_by = VALUES(assessed_by),
            assessed_at = NOW()";
    $ratingStmt = $pdo->prepare($ratingSql);

    foreach ($ratings as $rating) {
        $ratingStmt->execute([
            intval($rating['student_id']),
            $section_id,
            $term_id,
            $academic_year_id,
            intval($rating['skill_id']),
            strtoupper(trim((string)($rating['rating'] ?? ''))),
            $teacher_id
        ]);
        $savedCount++;
    }

    // Upsert narratives — unique key: (student_id, term_id, academic_year_id)
    $narrativeSql = "INSERT INTO tblkinder_narratives
        (student_id, section_id, term_id, academic_year_id, narrative, teacher_id, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE
            narrative = VALUES(narrative),
            teacher_id = VALUES(teacher_id),
            updated_at = NOW()";
    $narrativeStmt = $pdo->prepare($narrativeSql);

    foreach ($narratives as $narrative) {
        $narrativeStmt->execute([
            intval($narrative['student_id']),
            $section_id,
            $term_id,
            $academic_year_id,
            trim((string)($narrative['narrative'] ?? '')),
            $teacher_id
        ]);
        $narrativeCount++;
    }

    $pdo->commit();

    echo json_encode([
        'success'         => true,
        'saved_count'     => $savedCount,
        'narrative_count' => $narrativeCount,
        'message'         => "Saved {$savedCount} ratings and {$narrativeCount} narratives"
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(['success' => false, 'error' => 'Save failed: ' . $e->getMessage()]);
}
