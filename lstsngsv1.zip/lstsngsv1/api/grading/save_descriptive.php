<?php
header('Content-Type: application/json');

require_once '../../api/shared/db_connect.php';
require_once '../../api/deadline/check_submission_lock.php';
require_once '../../api/shared/grade_workflow.php';
require_once '../../includes/grading_engine.php';
require_once '../../includes/descriptor_engine.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !is_array($data)) {
    echo json_encode(['error' => 'Invalid data format']);
    exit;
}

$section_id = intval($data['section_id'] ?? 0);
$subject_id = intval($data['subject_id'] ?? 0);
$quarter    = intval($data['quarter'] ?? 0);
$teacher_id = intval($_SESSION['teacher_id'] ?? ($data['teacher_id'] ?? 0));

if (!$section_id || !$subject_id || !$quarter || !$teacher_id) {
    echo json_encode(['error' => 'Section ID, Subject ID, Quarter, and Teacher ID required']);
    exit;
}

if (!isset($data['ratings']) || !is_array($data['ratings']) || count($data['ratings']) === 0) {
    echo json_encode(['error' => 'Ratings array required']);
    exit;
}

/* ---------------------------------------------------------------------
 * Template-driven rating validation.
 * Allowed rating codes + remarks come from tbldescriptors for the
 * section's grade level (Grading Templates page). The legacy A/P/AP/D/B
 * list is ONLY a fallback when nothing is configured in the database.
 * ------------------------------------------------------------------- */
$gradeLevelId = 0;
try {
    $secStmt = $pdo->prepare("SELECT grade_level_id FROM tblsection WHERE id = ? LIMIT 1");
    $secStmt->execute([$section_id]);
    $gradeLevelId = (int)($secStmt->fetchColumn() ?: 0);
} catch (Throwable $e) {}

$gradeCode = ($gradeLevelId > 0) ? geResolveGradeCode($pdo, $gradeLevelId) : 0;

/* Guard: this endpoint is for DESCRIPTIVE / KINDERGARTEN sections only. */
if ($gradeCode > 3) {
    echo json_encode([
        'success' => false,
        'error'   => 'This section uses numerical grading (Grade 4 and above). Use the numeric score save endpoint instead.'
    ]);
    exit;
}

$allowedRatings = ['A', 'P', 'AP', 'D', 'B'];   // legacy fallback
$remarksByCode = ['A' => 'Passed', 'P' => 'Passed', 'AP' => 'Passed', 'D' => 'Passed', 'B' => 'Failed'];
if ($gradeLevelId > 0) {
    $options = geGetRatingOptions($pdo, $gradeLevelId);
    if ($options) {
        $allowedRatings = [];
        $remarksByCode = [];
        foreach ($options as $opt) {
            $code = strtoupper(trim((string)$opt['rating_code']));
            if ($code === '') continue;
            $allowedRatings[] = $code;
            $remarksByCode[$code] = ($opt['remarks'] !== '' ? $opt['remarks'] : 'Passed');
        }
    }
}

// Validate every rating BEFORE touching the database (transaction = all or nothing)
foreach ($data['ratings'] as $rating) {
    $studentId = intval($rating['student_id'] ?? 0);
    $code      = strtoupper(trim((string)($rating['rating_code'] ?? '')));

    if (!$studentId) {
        echo json_encode(['error' => 'Every rating needs a student_id']);
        exit;
    }
    if (!in_array($code, $allowedRatings, true)) {
        echo json_encode([
            'error' => "Invalid rating_code '{$code}' for student {$studentId}. Allowed: " . implode(', ', $allowedRatings)
        ]);
        exit;
    }
}

// Archive term lock — locked terms are read-only for teachers
$termLocked = false;
try {
    require_once __DIR__ . '/../../includes/archive_engine.php';
    if (function_exists('isTermLocked')) {
        $termLocked = isTermLocked($pdo, $section_id, $subject_id, $quarter);
    }
} catch (Throwable $e) {
    $termLocked = false;
}
if ($termLocked) {
    echo json_encode(['error' => 'This term is locked (archived). Grades are read-only.']);
    exit;
}

// Active academic year
$activeYear = $pdo->query("SELECT id, year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1")
    ->fetch(PDO::FETCH_ASSOC);
$academic_year_id = (int)($activeYear['id'] ?? 1);

$savedCount = 0;

try {
    $pdo->beginTransaction();

    $checkSql = "SELECT id FROM tblgrades
                 WHERE student_id = :student_id
                   AND section_id = :section_id
                   AND subject_id = :subject_id
                   AND quarter = :quarter
                   AND academic_year_id = :academic_year_id";
    $checkStmt = $pdo->prepare($checkSql);

    $insertSql = "INSERT INTO tblgrades (
            student_id, section_id, subject_id, teacher_id, quarter, academic_year_id,
            ww_total, pt_total, qa_total,
            ww_ps, pt_ps, qa_ps,
            ww_ws, pt_ws, qa_ws,
            initial_grade, final_grade,
            rating_code, grading_mode, remarks, status,
            created_at, updated_at
        ) VALUES (
            :student_id, :section_id, :subject_id, :teacher_id, :quarter, :academic_year_id,
            0, 0, 0,
            0, 0, 0,
            0, 0, 0,
            0, 0,
            :rating_code, 'DESCRIPTIVE', :remarks, 'draft',
            NOW(), NOW()
        )";
    $insertStmt = $pdo->prepare($insertSql);

    $updateSql = "UPDATE tblgrades SET
            teacher_id = :teacher_id,
            ww_total = 0, pt_total = 0, qa_total = 0,
            ww_ps = 0, pt_ps = 0, qa_ps = 0,
            ww_ws = 0, pt_ws = 0, qa_ws = 0,
            initial_grade = 0, final_grade = 0,
            rating_code = :rating_code,
            grading_mode = 'DESCRIPTIVE',
            remarks = :remarks,
            status = CASE
                WHEN status IN ('approved', 'approved_by_adviser', 'finalized') THEN status
                ELSE 'draft'
            END,
            updated_at = NOW()
        WHERE id = :id";
    $updateStmt = $pdo->prepare($updateSql);

    foreach ($data['ratings'] as $rating) {
        $studentId = intval($rating['student_id']);
        $code      = strtoupper(trim((string)($rating['rating_code'] ?? '')));
        /* Server-authoritative remarks from the configured descriptor;
           the client value is only a fallback for unlisted codes. */
        $remarks   = $remarksByCode[$code] ?? trim((string)($rating['remarks'] ?? ''));

        $checkStmt->execute([
            'student_id'       => $studentId,
            'section_id'       => $section_id,
            'subject_id'       => $subject_id,
            'quarter'          => $quarter,
            'academic_year_id' => $academic_year_id
        ]);
        $existing = $checkStmt->fetch(PDO::FETCH_ASSOC);

        if ($existing) {
            $updateStmt->execute([
                'teacher_id'  => $teacher_id,
                'rating_code' => $code,
                'remarks'     => $remarks,
                'id'          => (int)$existing['id']
            ]);
        } else {
            $insertStmt->execute([
                'student_id'       => $studentId,
                'section_id'       => $section_id,
                'subject_id'       => $subject_id,
                'teacher_id'       => $teacher_id,
                'quarter'          => $quarter,
                'academic_year_id' => $academic_year_id,
                'rating_code'      => $code,
                'remarks'          => $remarks
            ]);
        }

        $savedCount++;
    }

    $pdo->commit();

    try {
        if ($savedCount > 0) {
            logActivity($pdo, 'Grades', 'ENCODE', 'grade', $section_id,
                'Encoded descriptive ratings, Q' . $quarter . ' (' . $savedCount . ' record(s))');
        }
    } catch (Throwable $e) {}

    echo json_encode([
        'success'     => true,
        'message'     => "Saved {$savedCount} records",
        'saved_count' => $savedCount
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(['success' => false, 'error' => 'Save failed: ' . $e->getMessage()]);
}
