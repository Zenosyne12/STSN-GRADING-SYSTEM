<?php
/**
 * api/system/backup.php
 * STSN Grading System — SuperAdmin database backup / restore endpoint.
 *
 * Modes:
 *   - Library mode : included by SuperAdmin/Backup-Restore.php for its
 *                    POST handlers (brCreateBackupFile / brRestoreDatabase / ...).
 *   - Endpoint mode: requested directly over HTTP:
 *       ?action=download&file=dbstsn_backup_YYYY-MM-DD_HHMMSS.sql  → streams .sql
 *       ?action=create                                             → creates dump, PRG back to page
 *
 * Credentials come from api/shared/db_connect.php ($host, $db, $user, $pass).
 * Reading (history, instance lookups) uses PDO; dump/restore shells out to
 * mysqldump/mysql binaries with escapeshellarg-protected arguments.
 */

/* ============================ Shared library ============================ */

function brBackupDir(): string
{
    $dir = __DIR__ . '/../../backups';
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    return $dir;
}

/**
 * Only accepts files named dbstsn_backup_YYYY-MM-DD_HHMMSS.sql —
 * anything else is rejected (prevents path traversal / arbitrary deletes).
 */
function brSafeBackupName(string $name): ?string
{
    $name = basename($name);
    return preg_match('/^dbstsn_backup_\d{4}-\d{2}-\d{2}_\d{6}\.sql$/', $name) ? $name : null;
}

function brHumanSize(int $bytes): string
{
    if ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    }
    return number_format(max(0, $bytes) / 1024, 1) . ' KB';
}

function brListBackups(): array
{
    $dir = brBackupDir();
    $rows = [];
    foreach ((glob($dir . DIRECTORY_SEPARATOR . 'dbstsn_backup_*.sql') ?: []) as $path) {
        $rows[] = [
            'name'  => basename($path),
            'size'  => (int)@filesize($path),
            'mtime' => (int)@filemtime($path),
        ];
    }
    usort($rows, static fn(array $a, array $b): int => $b['mtime'] <=> $a['mtime']);
    return $rows;
}

function brPageRedirect(string $msg, string $detail = ''): void
{
    $url = '../../SuperAdmin/Backup-Restore.php?msg=' . urlencode($msg);
    if ($detail !== '') {
        $url .= '&detail=' . urlencode($detail);
    }
    header('Location: ' . $url);
    exit;
}

/**
 * Locate a usable mysqldump executable: Laragon/XAMPP/WAMP known paths
 * first, then whatever the PATH provides.
 */
function brFindMysqldump(): ?string
{
    static $found = null;
    if ($found !== null) {
        return $found ?: null;
    }
    if (!function_exists('exec')) {
        $found = '';
        return null;
    }
    $candidates = [];
    if (stripos(PHP_OS, 'WIN') === 0) {
        foreach ((glob('C:\\laragon\\bin\\mysql\\*\\bin\\mysqldump.exe') ?: []) as $p) {
            $candidates[] = $p;
        }
        $candidates[] = 'C:\\xampp\\mysql\\bin\\mysqldump.exe';
        $candidates[] = 'C:\\wamp64\\bin\\mysql\\mysqldump.exe';
    }
    $candidates[] = 'mysqldump';
    foreach ($candidates as $candidate) {
        $out = [];
        $code = 1;
        @exec(escapeshellarg($candidate) . ' --version 2>&1', $out, $code);
        if ($code === 0) {
            $found = $candidate;
            return $candidate;
        }
    }
    $found = '';
    return null;
}
/**
 * Create a .sql dump into the backups/ folder.
 * Returns [ok(bool), filename-or-error-message].
 */
function brCreateBackupFile(): array
{
    global $host, $db, $user, $pass;

    $binary = brFindMysqldump();
    if ($binary === null) {
        return [false, 'mysqldump executable was not found on this server.'];
    }

    if (!is_dir(brBackupDir()) || !is_writable(brBackupDir())) {
        return [false, 'The backups/ folder is not writable by the web server.'];
    }

    $filename = 'dbstsn_backup_' . date('Y-m-d_His') . '.sql';
    $target   = brBackupDir() . DIRECTORY_SEPARATOR . $filename;

    $cmd = escapeshellarg($binary)
        . ' --host=' . escapeshellarg((string)$host)
        . ' --user=' . escapeshellarg((string)$user)
        . ($pass !== '' ? ' --password=' . escapeshellarg((string)$pass) : '')
        . ' --single-transaction --quick --routines --events --triggers'
        . ' ' . escapeshellarg((string)$db)
        . ' > ' . escapeshellarg($target) . ' 2>&1';

    $out = [];
    $code = 1;
    @exec($cmd, $out, $code);

    if ($code !== 0 || !is_file($target) || filesize($target) === 0) {
        @unlink($target);
        $msg = trim(implode("\n", array_slice($out, 0, 3)));
        return [false, $msg !== '' ? $msg : 'mysqldump exited with code ' . $code . '.'];
    }
    return [true, $filename];
}

/**
 * Restore a .sql file (path to uploaded tmp file) into the database.
 * Returns [ok(bool), success-or-error-message].
 */
function brRestoreDatabase(string $sqlPath): array
{
    global $host, $db, $user, $pass;

    if (!is_file($sqlPath) || filesize($sqlPath) === 0) {
        return [false, 'The uploaded file is empty or unreadable.'];
    }

    $mysql = null;
    $candidates = [str_replace('mysqldump', 'mysql', (string)brFindMysqldump())];
    $candidates[] = stripos(PHP_OS, 'WIN') === 0 ? 'C:\\xampp\\mysql\\bin\\mysql.exe' : 'mysql';
    foreach (array_unique(array_filter($candidates)) as $candidate) {
        if ($candidate === '' || $candidate === 'mysqldump') {
            continue;
        }
        $out = [];
        $code = 1;
        @exec(escapeshellarg($candidate) . ' --version 2>&1', $out, $code);
        if ($code === 0) {
            $mysql = $candidate;
            break;
        }
    }
    if ($mysql === null) {
        return [false, 'mysql client executable was not found on this server.'];
    }

    $cmd = escapeshellarg($mysql)
        . ' --host=' . escapeshellarg((string)$host)
        . ' --user=' . escapeshellarg((string)$user)
        . ($pass !== '' ? ' --password=' . escapeshellarg((string)$pass) : '')
        . ' ' . escapeshellarg((string)$db)
        . ' < ' . escapeshellarg($sqlPath) . ' 2>&1';

    $out = [];
    $code = 1;
    @exec($cmd, $out, $code);

    if ($code !== 0) {
        $msg = trim(implode("\n", array_slice($out, 0, 3)));
        return [false, $msg !== '' ? $msg : 'mysql exited with code ' . $code . '.'];
    }
    return [true, 'Database restored successfully.'];
}
/* ============================ HTTP endpoint mode ============================ */

$isHttp = (PHP_SAPI !== 'cli' && !isset($GLOBALS['brPageMode']));
if ($isHttp) {
    require_once __DIR__ . '/../shared/auth.php';
    requireSuperAdmin();

    $action = (string)($_GET['action'] ?? '');

    /* action=create — generate dump, then PRG back to the page */
    if ($action === 'create') {
        set_time_limit(0);
        [$ok, $value] = brCreateBackupFile();
        brPageRedirect($ok ? 'backup_created' : 'backup_failed', $ok ? '' : $value);
    }

    /* action=download — stream an existing .sql file in chunks */
    if ($action === 'download') {
        $name = brSafeBackupName((string)($_GET['file'] ?? ''));
        if ($name === null) {
            http_response_code(400);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'Invalid backup filename.']);
            exit;
        }
        $path = brBackupDir() . DIRECTORY_SEPARATOR . $name;
        if (!is_file($path)) {
            http_response_code(404);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'Backup file not found.']);
            exit;
        }

        $size = (int)filesize($path);
        header('Content-Type: application/sql');
        header('Content-Disposition: attachment; filename="' . $name . '"');
        header('Content-Length: ' . $size);
        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('X-Content-Type-Options: nosniff');

        while (ob_get_level() > 0) {
            @ob_end_flush();
        }
        @set_time_limit(0);

        // Chunked output — reads 1 MB at a time so large dumps don't exhaust memory
        $handle = @fopen($path, 'rb');
        if ($handle === false) {
            http_response_code(500);
            echo 'Unable to open backup file.';
            exit;
        }
        while (!feof($handle)) {
            echo fread($handle, 1048576);
            flush();
        }
        fclose($handle);
        exit;
    }
}

/* Included as a library (page mode) — nothing else to do here. */


