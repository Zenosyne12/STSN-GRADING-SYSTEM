<?php
require_once __DIR__.'/../shared/db_connect.php';
header('Content-Type: application/json');

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$id) { http_response_code(400); echo json_encode(['error'=>'Bad ID']); exit; }

$stmt = $pdo->prepare("SELECT
                           t.id, t.teacher_id, t.email, t.fname, t.mname, t.lname,
                           t.date_hired, t.sex, t.contact_no, t.is_active,
                           u.id AS account_id, u.username, u.status AS account_status,
                           u.must_change_password, u.created_at AS account_created_at
                       FROM tblteacher t
                       LEFT JOIN tblusers u ON u.reference_id = t.id AND u.role_id = 2
                       WHERE t.id = ?");
$stmt->execute([$id]);
$out = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$out) { http_response_code(404); echo json_encode(['error'=>'Not found']); exit; }

echo json_encode($out);
?>