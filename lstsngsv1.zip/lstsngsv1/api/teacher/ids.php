<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

try {
    $stmt = $pdo->prepare("
        SELECT
            t.id,
            t.teacher_id,
            t.fname,
            t.mname,
            t.lname,
            t.email,
            t.date_hired
        FROM tblteacher t
        WHERE t.is_active = 1
          AND NOT EXISTS (
              SELECT 1
              FROM tblusers u
              WHERE u.role_id = 2
                AND u.reference_id = t.id
          )
        ORDER BY t.lname ASC, t.fname ASC, t.teacher_id ASC
    ");
    $stmt->execute();
    $teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $result = [];
    foreach ($teachers as $teacher) {
        $middle = '';
        if (!empty($teacher['mname'])) {
            $middle = ' ' . strtoupper(substr($teacher['mname'], 0, 1)) . '.';
        }

        $fullName = trim($teacher['fname'] . $middle . ' ' . $teacher['lname']);

        $result[] = [
            'id' => $teacher['id'],
            'teacher_id' => $teacher['teacher_id'],
            'fname' => $teacher['fname'],
            'mname' => $teacher['mname'],
            'lname' => $teacher['lname'],
            'full_name' => $fullName,
            'email' => $teacher['email'],
            'date_hired' => $teacher['date_hired']
        ];
    }

    echo json_encode([
        'success' => true,
        'teachers' => $result
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Query failed: ' . $e->getMessage()
    ]);
}