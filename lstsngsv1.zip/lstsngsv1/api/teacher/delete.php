<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

function resolveTable(PDO $pdo, array $candidates): ?string
{
    $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN) ?: [];
    $map = [];

    foreach ($tables as $table) {
        $map[strtolower($table)] = $table;
    }

    foreach ($candidates as $candidate) {
        $key = strtolower($candidate);
        if (isset($map[$key])) {
            return $map[$key];
        }
    }

    return null;
}

function hasColumn(PDO $pdo, string $table, string $column): bool
{
    $stmt = $pdo->prepare("SHOW COLUMNS FROM `{$table}` LIKE ?");
    $stmt->execute([$column]);
    return (bool) $stmt->fetch(PDO::FETCH_ASSOC);
}

if (!in_array($_SERVER['REQUEST_METHOD'], ['GET', 'POST'], true)) {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed'
    ]);
    exit;
}

$input = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true);
    if (!is_array($input)) {
        $input = [];
    }
}

$id = 0;
if (isset($input['id'])) {
    $id = (int) $input['id'];
} elseif (isset($_GET['id'])) {
    $id = (int) $_GET['id'];
}

if ($id <= 0) {
    echo json_encode([
        'success' => false,
        'error' => 'Invalid teacher ID'
    ]);
    exit;
}

$requestedState = null;
if (isset($input['new_state'])) {
    $requestedState = (int) $input['new_state'];
} elseif (isset($_GET['new_state'])) {
    $requestedState = (int) $_GET['new_state'];
}

try {
    $teacherTable = resolveTable($pdo, ['tblteacher', 'tblTeacher']);

    if (!$teacherTable) {
        echo json_encode([
            'success' => false,
            'error' => 'Teacher table not found'
        ]);
        exit;
    }

    $pdo->beginTransaction();

    $sql = "
        SELECT id, teacher_id, fname, lname" .
        (hasColumn($pdo, $teacherTable, 'is_active') ? ", is_active" : ", 1 AS is_active") .
        (hasColumn($pdo, $teacherTable, 'is_archived') ? ", is_archived" : ", 0 AS is_archived") . "
        FROM `{$teacherTable}`
        WHERE id = ?
        LIMIT 1
        FOR UPDATE
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    $teacher = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$teacher) {
        $pdo->rollBack();
        echo json_encode([
            'success' => false,
            'error' => 'Teacher not found'
        ]);
        exit;
    }

    $currentState = (int) ($teacher['is_active'] ?? 0);
    $newState = ($requestedState === 0 || $requestedState === 1)
        ? $requestedState
        : ($currentState === 1 ? 0 : 1);

    $newArchive = $newState === 1 ? 0 : 1;
    $accountStatus = $newState === 1 ? 'Active' : 'Inactive';

    $fields = [];
    $params = [];

    if (hasColumn($pdo, $teacherTable, 'is_active')) {
        $fields[] = 'is_active = ?';
        $params[] = $newState;
    }

    if (hasColumn($pdo, $teacherTable, 'is_archived')) {
        $fields[] = 'is_archived = ?';
        $params[] = $newArchive;
    }

    if (hasColumn($pdo, $teacherTable, 'archived_at')) {
        $fields[] = 'archived_at = ?';
        $params[] = $newArchive ? date('Y-m-d H:i:s') : null;
    }

    if (hasColumn($pdo, $teacherTable, 'date_archived')) {
        $fields[] = 'date_archived = ?';
        $params[] = $newArchive ? date('Y-m-d H:i:s') : null;
    }

    if (!empty($fields)) {
        $params[] = $id;

        $updateTeacher = $pdo->prepare("
            UPDATE `{$teacherTable}`
            SET " . implode(', ', $fields) . "
            WHERE id = ?
        ");
        $updateTeacher->execute($params);
    }

    $updateUser = $pdo->prepare("
        UPDATE tblusers
        SET status = ?
        WHERE role_id = 2 AND reference_id = ?
    ");
    $updateUser->execute([$accountStatus, $id]);

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => $newState === 1
            ? 'Teacher and linked account activated successfully.'
            : 'Teacher and linked account deactivated successfully.'
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Failed to update teacher status: ' . $e->getMessage()
    ]);
}