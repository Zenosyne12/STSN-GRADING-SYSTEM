<?php
require_once __DIR__.'/../shared/db_connect.php';
require_once __DIR__.'/../shared/account_credentials.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);


$required = ['teacher_id','email','fname','lname','date_hired','sex','contact_no'];
foreach ($required as $f) {
    if (empty($data[$f])) {
        http_response_code(422);
        echo json_encode(['error'=>'Required field missing: '.$f]);
        exit;
    }
}

$id        = (int)($data['id']        ?? 0);
$teacherId = trim($data['teacher_id']);
$email     = trim($data['email']);
$fname     = trim($data['fname']);
$mname     = trim($data['mname']      ?? '');
$lname     = trim($data['lname']);
$dateHired = $data['date_hired'];
$sex       = $data['sex'];
$contact   = trim($data['contact_no']);
$active    = !empty($data['is_active']) ? 1 : 0;

try {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        http_response_code(422);
        echo json_encode(['error' => 'Please provide a valid teacher email address.']);
        exit;
    }

    if ($id) {
        $userStmt = $pdo->prepare("SELECT id FROM tblusers WHERE role_id = 2 AND reference_id = ? LIMIT 1");
        $userStmt->execute([$id]);
        $linkedUserId = (int)($userStmt->fetchColumn() ?: 0);

        stsnAssertTeacherEmailAvailable(
            $pdo,
            $email,
            $id,
            $linkedUserId,
            'This email address is already assigned to another account.'
        );

        $pdo->beginTransaction();
        $stmt = $pdo->prepare("UPDATE tblteacher
                               SET teacher_id = ?,
                                   email      = ?,
                                   fname      = ?,
                                   mname      = ?,
                                   lname      = ?,
                                   date_hired = ?,
                                   sex        = ?,
                                   contact_no = ?,
                                   is_active  = ?
                               WHERE id = ?");
        $stmt->execute([$teacherId,$email,$fname,$mname,$lname,$dateHired,$sex,$contact,$active,$id]);

        if ($linkedUserId > 0) {
            $sync = $pdo->prepare("UPDATE tblusers SET username = ? WHERE id = ? AND role_id = 2");
            $sync->execute([$email, $linkedUserId]);
        }

        $pdo->commit();
        try {
            logActivity($pdo, 'Teachers', 'UPDATE', 'teacher', $id,
                'Updated teacher ' . trim($fname . ' ' . $lname));
        } catch (Throwable $e) {}
        echo json_encode(['success'=>true, 'id'=>$id, 'message' => 'Teacher updated successfully.']);
    } else {
        stsnAssertTeacherEmailAvailable($pdo, $email);

        $pdo->beginTransaction();
        $stmt = $pdo->prepare("INSERT INTO tblteacher
                                     (teacher_id,email,fname,mname,lname,date_hired,sex,contact_no,is_active)
                              VALUES (?,?,?,?,?,?,?,?,?)");
        $stmt->execute([$teacherId,$email,$fname,$mname,$lname,$dateHired,$sex,$contact,$active]);
        $id = (int)$pdo->lastInsertId();

        $credentials = stsnCreateTeacherAccount($pdo, $id, [
            'email' => $email,
            'fname' => $fname,
            'mname' => $mname,
            'lname' => $lname,
            'date_hired' => $dateHired,
        ]);

        $pdo->commit();

        try {
            logActivity($pdo, 'Teachers', 'CREATE', 'teacher', $id,
                'Created teacher ' . trim($fname . ' ' . $lname));
        } catch (Throwable $e) {}

        $emailSent = false;
        try {
            $emailSent = stsnSendCredentialsEmail(
                $credentials['email'],
                $credentials['full_name'],
                $credentials['username'],
                $credentials['temporary_password']
            );
        } catch (Throwable $mailError) {
            $emailSent = false;
        }

        echo json_encode([
            'success' => true,
            'id' => $id,
            'username' => $credentials['username'],
            'email_sent' => $emailSent,
            'warning' => $emailSent ? null : 'Account created successfully, but email sending failed. Please resend credentials.',
            'message' => $emailSent
                ? 'Teacher record and account created successfully. Credentials sent to email.'
                : 'Account created successfully, but email sending failed. Please resend credentials.',
        ]);
    }
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['error'=>$e->getMessage()]);
}
?>
