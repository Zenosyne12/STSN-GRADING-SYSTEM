<?php
require_once __DIR__.'/../shared/db_connect.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

// --- basic validation ---
$required = ['teacher_id','email','fname','lname','date_hired','sex','contact_no'];
foreach ($required as $f) {
    if (empty($data[$f])) {
        http_response_code(422);
        echo json_encode(['error'=>'Required field missing: '.$f]);
        exit;
    }
}

$id        = (int)($data['id']        ?? 0);
$teacherId = trim($data['teacher_id']);
$email     = trim($data['email']);
$fname     = trim($data['fname']);
$mname     = trim($data['mname']      ?? '');
$lname     = trim($data['lname']);
$dateHired = $data['date_hired'];
$sex       = $data['sex'];
$contact   = trim($data['contact_no']);
$active    = !empty($data['is_active']) ? 1 : 0;

try {
    if ($id) {          // UPDATE
        $stmt = $pdo->prepare("UPDATE tblteacher
                               SET teacher_id = ?,
                                   email      = ?,
                                   fname      = ?,
                                   mname      = ?,
                                   lname      = ?,
                                   date_hired = ?,
                                   sex        = ?,
                                   contact_no = ?,
                                   is_active  = ?
                               WHERE id = ?");
        $stmt->execute([$teacherId,$email,$fname,$mname,$lname,$dateHired,$sex,$contact,$active,$id]);
    } else {            // INSERT
        $stmt = $pdo->prepare("INSERT INTO tblteacher
                                     (teacher_id,email,fname,mname,lname,date_hired,sex,contact_no,is_active)
                              VALUES (?,?,?,?,?,?,?,?,?)");
        $stmt->execute([$teacherId,$email,$fname,$mname,$lname,$dateHired,$sex,$contact,$active]);
        $id = $pdo->lastInsertId();
    }
    echo json_encode(['success'=>true, 'id'=>$id]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error'=>$e->getMessage()]);
}
?>