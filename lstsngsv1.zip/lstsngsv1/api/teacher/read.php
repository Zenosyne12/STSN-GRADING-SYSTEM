<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

$page = max(1, (int) ($_GET['p'] ?? $_GET['page'] ?? 1));
$search = trim((string) ($_GET['s'] ?? $_GET['search'] ?? ''));
$perPage = 5;
$offset = ($page - 1) * $perPage;

try {
    $where = ["is_active = 1"];
    $params = [];

    if ($search !== '') {
        $where[] = "(
            teacher_id LIKE ?
            OR email LIKE ?
            OR fname LIKE ?
            OR mname LIKE ?
            OR lname LIKE ?
            OR CONCAT_WS(' ', fname, NULLIF(mname, ''), lname) LIKE ?
        )";

        $like = '%' . $search . '%';
        array_push($params, $like, $like, $like, $like, $like, $like);
    }

    $whereSql = implode(' AND ', $where);

    $countStmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM tblteacher
        WHERE {$whereSql}
    ");
    $countStmt->execute($params);
    $total = (int) $countStmt->fetchColumn();

    $pages = max(1, (int) ceil($total / $perPage));

    if ($page > $pages) {
        $page = $pages;
        $offset = ($page - 1) * $perPage;
    }

    $listStmt = $pdo->prepare("
        SELECT
            id,
            teacher_id,
            email,
            fname,
            mname,
            lname,
            date_hired,
            sex,
            contact_no,
            is_active
        FROM tblteacher
        WHERE {$whereSql}
        ORDER BY lname ASC, fname ASC, teacher_id ASC
        LIMIT {$perPage} OFFSET {$offset}
    ");
    $listStmt->execute($params);
    $teachers = $listStmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'teachers' => $teachers,
        'page' => $page,
        'pages' => $pages,
        'total' => $total,
        'per_page' => $perPage
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Failed to load teachers: ' . $e->getMessage()
    ]);
}