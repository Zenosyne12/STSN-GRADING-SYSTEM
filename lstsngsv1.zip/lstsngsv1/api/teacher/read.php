<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../shared/db_connect.php';

header('Content-Type: application/json');

$page = max(1, (int) ($_GET['p'] ?? $_GET['page'] ?? 1));
$search = trim((string) ($_GET['s'] ?? $_GET['search'] ?? ''));
$perPage = 5;
$offset = ($page - 1) * $perPage;

try {
    $where = ["t.is_active = 1"];
    $params = [];

    if ($search !== '') {
        $where[] = "(
            t.teacher_id LIKE ?
            OR t.email LIKE ?
            OR t.fname LIKE ?
            OR t.mname LIKE ?
            OR t.lname LIKE ?
            OR CONCAT_WS(' ', t.fname, NULLIF(t.mname, ''), t.lname) LIKE ?
        )";

        $like = '%' . $search . '%';
        array_push($params, $like, $like, $like, $like, $like, $like);
    }

    $whereSql = implode(' AND ', $where);

    $countStmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM tblteacher t
        LEFT JOIN tblusers u ON u.reference_id = t.id AND u.role_id = 2
        WHERE {$whereSql}
    ");
    $countStmt->execute($params);
    $total = (int) $countStmt->fetchColumn();

    $pages = max(1, (int) ceil($total / $perPage));

    if ($page > $pages) {
        $page = $pages;
        $offset = ($page - 1) * $perPage;
    }

    $listStmt = $pdo->prepare("
        SELECT
            t.id,
            t.teacher_id,
            t.email,
            t.fname,
            t.mname,
            t.lname,
            t.date_hired,
            t.sex,
            t.contact_no,
            t.is_active,
            u.id AS account_id,
            u.username,
            u.status AS account_status,
            u.must_change_password,
            u.created_at AS account_created_at
        FROM tblteacher t
        LEFT JOIN tblusers u ON u.reference_id = t.id AND u.role_id = 2
        WHERE {$whereSql}
        ORDER BY lname ASC, fname ASC, teacher_id ASC
        LIMIT {$perPage} OFFSET {$offset}
    ");
    $listStmt->execute($params);
    $teachers = $listStmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'teachers' => $teachers,
        'page' => $page,
        'pages' => $pages,
        'total' => $total,
        'per_page' => $perPage
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Failed to load teachers: ' . $e->getMessage()
    ]);
}