<?php
require_once '../shared/db_connect.php';
$stmt=$db->query("SELECT id, CONCAT(fname,' ',lname) AS teacher_name FROM tblteacher WHERE is_active=1");
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
?>