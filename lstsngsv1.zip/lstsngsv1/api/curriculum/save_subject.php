<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

function gradeCodeFromId(int $gradeLevelId): string
{
    return match ($gradeLevelId) {
        1 => 'KINDER',
        2 => 'G1', 3 => 'G2', 4 => 'G3', 5 => 'G4', 6 => 'G5', 7 => 'G6',
        8 => 'G7', 9 => 'G8', 10 => 'G9', 11 => 'G10',
        12 => 'G11', 13 => 'G12',
        default => 'G' . $gradeLevelId,
    };
}

function buildSubjectCode(int $gradeLevelId, ?string $strand, string $subjectName): string
{
    $gradeCode = gradeCodeFromId($gradeLevelId);
    $strandCode = $strand ? '_' . strtoupper($strand) : '';
    $slug = strtoupper(trim($subjectName));
    $slug = preg_replace('/[^A-Z0-9]+/', '_', $slug);
    $slug = trim($slug, '_');
    return substr($gradeCode . $strandCode . '_' . $slug, 0, 20);
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) {
        throw new Exception('Invalid JSON payload.');
    }

    $curriculumId = !empty($input['curriculum_id']) ? (int) $input['curriculum_id'] : null;
    $gradeLevelId = (int) ($input['grade_level_id'] ?? 0);
    $subjectName  = trim($input['subject_name'] ?? '');
    $subjectType  = strtoupper(trim($input['subject_type'] ?? 'CORE'));
    $isActive     = isset($input['is_active']) ? (int) (bool) $input['is_active'] : 1;
    $strand       = strtoupper(trim($input['strand'] ?? ''));

    $allowedTypes = ['CORE', 'APPLIED', 'SPECIALIZED', 'ELECTIVE'];
    $allowedStrands = ['ABM', 'STEM', 'GAS', 'HUMSS', 'TVL', 'ARTS', 'SPORTS'];
    $isShs = in_array($gradeLevelId, [12, 13], true);

    if ($gradeLevelId <= 0) {
        throw new Exception('grade_level_id is required.');
    }
    if ($subjectName === '') {
        throw new Exception('Subject name is required.');
    }
    if (!in_array($subjectType, $allowedTypes, true)) {
        throw new Exception('Invalid subject type.');
    }

    if ($isShs) {
        if ($strand === '' || !in_array($strand, $allowedStrands, true)) {
            throw new Exception('Valid strand is required for Grade 11 and Grade 12.');
        }
    } else {
        $strand = null;
        $subjectType = 'CORE';
    }

    $subjectCode = trim($input['subject_code'] ?? '');
    if ($subjectCode === '') {
        $subjectCode = buildSubjectCode($gradeLevelId, $strand, $subjectName);
    }

    if ($curriculumId) {
        // UPDATE existing
        $stmt = $pdo->prepare("SELECT id FROM tblsubjects WHERE id = ? LIMIT 1");
        $stmt->execute([$curriculumId]);
        if (!$stmt->fetch()) {
            throw new Exception('Subject not found.');
        }

        $dup = $pdo->prepare("
            SELECT COUNT(*) FROM tblsubjects 
            WHERE grade_level_id = ? AND COALESCE(strand, '') = COALESCE(?, '') 
            AND LOWER(TRIM(subject_name)) = LOWER(TRIM(?)) AND id <> ?
        ");
        $dup->execute([$gradeLevelId, $strand, $subjectName, $curriculumId]);
        if ((int) $dup->fetchColumn() > 0) {
            throw new Exception('Subject already exists in this grade/strand.');
        }

        $pdo->prepare("
            UPDATE tblsubjects 
            SET grade_level_id = ?, strand = ?, subject_code = ?, subject_name = ?, 
                subject_type = ?, is_active = ?, updated_at = NOW()
            WHERE id = ?
        ")->execute([$gradeLevelId, $strand, $subjectCode, $subjectName, $subjectType, $isActive, $curriculumId]);

        echo json_encode(['success' => true, 'message' => 'Subject updated successfully.']);
        exit;
    }

    // INSERT new
    $dup = $pdo->prepare("
        SELECT COUNT(*) FROM tblsubjects 
        WHERE grade_level_id = ? AND COALESCE(strand, '') = COALESCE(?, '') 
        AND LOWER(TRIM(subject_name)) = LOWER(TRIM(?))
    ");
    $dup->execute([$gradeLevelId, $strand, $subjectName]);
    if ((int) $dup->fetchColumn() > 0) {
        throw new Exception('Subject already exists in this grade/strand.');
    }

    $pdo->prepare("
        INSERT INTO tblsubjects (grade_level_id, strand, subject_code, subject_name, subject_type, is_active, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())
    ")->execute([$gradeLevelId, $strand, $subjectCode, $subjectName, $subjectType, $isActive]);

    echo json_encode(['success' => true, 'message' => 'Subject added successfully.']);

} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}