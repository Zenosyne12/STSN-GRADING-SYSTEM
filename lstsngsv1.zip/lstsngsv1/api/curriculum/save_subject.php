<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

function gradeCodeFromId(int $gradeLevelId): string
{
    return match ($gradeLevelId) {
        1 => 'KINDER',
        2 => 'G1',
        3 => 'G2',
        4 => 'G3',
        5 => 'G4',
        6 => 'G5',
        7 => 'G6',
        8 => 'G7',
        9 => 'G8',
        10 => 'G9',
        11 => 'G10',
        12 => 'G11',
        13 => 'G12',
        default => 'G' . $gradeLevelId,
    };
}

function buildSubjectCode(int $gradeLevelId, ?string $strand, string $subjectName): string
{
    $gradeCode = gradeCodeFromId($gradeLevelId);
    $strandCode = $strand ? '_' . strtoupper($strand) : '';
    $slug = strtoupper(trim($subjectName));
    $slug = preg_replace('/[^A-Z0-9]+/', '_', $slug);
    $slug = trim($slug, '_');

    return substr($gradeCode . $strandCode . '_' . $slug, 0, 80);
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) {
        throw new Exception('Invalid JSON payload.');
    }

    $curriculumId = !empty($input['curriculum_id']) ? (int) $input['curriculum_id'] : null;
    $gradeLevelId = (int) ($input['grade_level_id'] ?? 0);
    $subjectName  = trim($input['subject_name'] ?? '');
    $subjectType  = strtoupper(trim($input['subject_type'] ?? 'CORE'));
    $description  = trim($input['description'] ?? '');
    $isActive     = isset($input['is_active']) ? (int) (bool) $input['is_active'] : 1;
    $strand       = strtoupper(trim($input['strand'] ?? ''));

    $allowedTypes = ['CORE', 'APPLIED', 'SPECIALIZED', 'ELECTIVE'];
    $allowedStrands = ['ABM', 'STEM', 'GAS', 'HUMSS'];
    $isShs = in_array($gradeLevelId, [12, 13], true);

    if ($gradeLevelId <= 0) {
        throw new Exception('grade_level_id is required.');
    }
    if ($subjectName === '') {
        throw new Exception('Subject name is required.');
    }
    if (!in_array($subjectType, $allowedTypes, true)) {
        throw new Exception('Invalid subject type.');
    }

    if ($isShs) {
        if ($strand === '' || !in_array($strand, $allowedStrands, true)) {
            throw new Exception('Valid strand is required for Grade 11 and Grade 12.');
        }
    } else {
        $strand = null;
        $subjectType = 'CORE';
    }

    $subjectCode = buildSubjectCode($gradeLevelId, $strand, $subjectName);

    $pdo->beginTransaction();

    if ($curriculumId) {
        $stmt = $pdo->prepare(
            "SELECT cg.id, cg.subject_id, cg.grade_level_id, cg.strand
             FROM tblcurriculum_grade cg
             WHERE cg.id = ?
             LIMIT 1"
        );
        $stmt->execute([$curriculumId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$row) {
            throw new Exception('Curriculum record not found.');
        }

        $subjectId = (int) $row['subject_id'];

        $dup = $pdo->prepare(
            "SELECT COUNT(*)
             FROM tblcurriculum_grade cg
             JOIN tblsubjects s ON s.id = cg.subject_id
             WHERE cg.grade_level_id = ?
               AND COALESCE(cg.strand, '') = COALESCE(?, '')
               AND LOWER(TRIM(s.subject_name)) = LOWER(TRIM(?))
               AND cg.id <> ?"
        );
        $dup->execute([$gradeLevelId, $strand, $subjectName, $curriculumId]);
        if ((int) $dup->fetchColumn() > 0) {
            throw new Exception('Subject already exists in this grade/strand.');
        }

        $pdo->prepare(
            "UPDATE tblsubjects
             SET subject_code = ?, subject_name = ?, subject_type = ?, description = ?, is_active = ?
             WHERE id = ?"
        )->execute([$subjectCode, $subjectName, $subjectType, $description, $isActive, $subjectId]);

        $pdo->prepare(
            "UPDATE tblcurriculum_grade
             SET grade_level_id = ?, strand = ?, is_active = ?
             WHERE id = ?"
        )->execute([$gradeLevelId, $strand, $isActive, $curriculumId]);

        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Subject updated successfully.']);
        exit;
    }

    $dup = $pdo->prepare(
        "SELECT COUNT(*)
         FROM tblcurriculum_grade cg
         JOIN tblsubjects s ON s.id = cg.subject_id
         WHERE cg.grade_level_id = ?
           AND COALESCE(cg.strand, '') = COALESCE(?, '')
           AND LOWER(TRIM(s.subject_name)) = LOWER(TRIM(?))"
    );
    $dup->execute([$gradeLevelId, $strand, $subjectName]);
    if ((int) $dup->fetchColumn() > 0) {
        throw new Exception('Subject already exists in this grade/strand.');
    }

    $pdo->prepare(
        "INSERT INTO tblsubjects (subject_code, subject_name, subject_type, description, is_active)
         VALUES (?, ?, ?, ?, ?)"
    )->execute([$subjectCode, $subjectName, $subjectType, $description, $isActive]);

    $subjectId = (int) $pdo->lastInsertId();

    $pdo->prepare(
        "INSERT INTO tblcurriculum_grade (grade_level_id, strand, subject_id, ww, pt, qa, is_active)
         VALUES (?, ?, ?, 30, 50, 20, ?)"
    )->execute([$gradeLevelId, $strand, $subjectId, $isActive]);

    $pdo->commit();
    echo json_encode(['success' => true, 'message' => 'Subject added successfully.']);

} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}