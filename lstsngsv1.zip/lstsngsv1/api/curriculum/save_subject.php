<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

function gradeCodeFromId(int $gradeLevelId): string
{
    return match ($gradeLevelId) {
        1 => 'KINDER',
        2 => 'G1', 3 => 'G2', 4 => 'G3', 5 => 'G4', 6 => 'G5', 7 => 'G6',
        8 => 'G7', 9 => 'G8', 10 => 'G9', 11 => 'G10',
        12 => 'G11', 13 => 'G12',
        default => 'G' . $gradeLevelId,
    };
}

function buildSubjectCode(int $gradeLevelId, ?string $strand, string $subjectName): string
{
    $gradeCode = gradeCodeFromId($gradeLevelId);
    $strandCode = $strand ? '_' . strtoupper($strand) : '';
    $slug = strtoupper(trim($subjectName));
    $slug = preg_replace('/[^A-Z0-9]+/', '_', $slug);
    $slug = trim($slug, '_');
    return substr($gradeCode . $strandCode . '_' . $slug, 0, 20);
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) {
        throw new Exception('Invalid JSON payload.');
    }

    $curriculumId = !empty($input['curriculum_id']) ? (int) $input['curriculum_id'] : null;
    $gradeLevelId = (int) ($input['grade_level_id'] ?? 0);
    $subjectName  = trim($input['subject_name'] ?? '');
    $subjectType  = strtoupper(trim($input['subject_type'] ?? 'CORE'));
    $isActive     = isset($input['is_active']) ? (int) (bool) $input['is_active'] : 1;
    $strand       = strtoupper(trim($input['strand'] ?? ''));
    $yearId       = !empty($input['academic_year_id']) ? (int) $input['academic_year_id'] : 0;
    $cluster      = trim((string) ($input['cluster'] ?? ''));
    $hoursInput   = trim((string) ($input['hours'] ?? ''));
    $semester     = trim((string) ($input['semester'] ?? ''));
    $tesdaLevel   = trim((string) ($input['tesda_nc_level'] ?? ''));
    $prerequisites = trim((string) ($input['prerequisites'] ?? ''));

    $allowedTypes = ['CORE', 'APPLIED', 'SPECIALIZED', 'ELECTIVE'];
    $allowedStrands = ['ACADEMIC', 'TECHNICAL-PROFESSIONAL (TECH-PRO)', 'TECH-PRO', 'ABM', 'STEM', 'GAS', 'HUMSS', 'TVL', 'ARTS', 'SPORTS'];

    if ($gradeLevelId <= 0) {
        throw new Exception('grade_level_id is required.');
    }
    $stmtGradeLevel = $pdo->prepare("SELECT grade_level_code FROM tblgradelevel WHERE id = ? LIMIT 1");
    $stmtGradeLevel->execute([$gradeLevelId]);
    $gradeLevelCode = $stmtGradeLevel->fetchColumn();
    if ($gradeLevelCode === false) {
        throw new Exception('Grade level not found.');
    }
    $isShs = (int) $gradeLevelCode >= 11;
    if ($subjectName === '') {
        throw new Exception('Subject name is required.');
    }
    if (!in_array($subjectType, $allowedTypes, true)) {
        throw new Exception('Invalid subject type.');
    }
    if ($isShs) {
        if ($hoursInput !== '' && (!ctype_digit($hoursInput) || (int)$hoursInput > 65535)) {
            throw new Exception('Hours must be a whole number between 0 and 65535.');
        }
        if (mb_strlen($prerequisites) > 200) {
            throw new Exception('Prerequisites must be at most 200 characters.');
        }
    } else {
        $hoursInput = '';
        $prerequisites = '';
    }
    if (mb_strlen($tesdaLevel) > 20) {
        throw new Exception('TESDA NC Level must be at most 20 characters.');
    }
    if (mb_strlen($cluster) > 100) {
        throw new Exception('Cluster must be at most 100 characters.');
    }
    if ($semester !== '' && !in_array($semester, ['1st Semester', '2nd Semester'], true)) {
        throw new Exception('Invalid semester selected.');
    }

    if ($isShs) {
        if ($strand === '' || !in_array($strand, $allowedStrands, true)) {
            throw new Exception('Valid track is required for Grade 11 and Grade 12.');
        }
        if ($strand === 'ACADEMIC') {
            $strand = 'Academic';
        } elseif (in_array($strand, ['TECH-PRO', 'TECHNICAL-PROFESSIONAL (TECH-PRO)'], true)) {
            $strand = 'Tech-Pro';
        }
    } else {
        $strand = null;
        $subjectType = 'CORE';
    }

    // Resolve target academic year (each year keeps its own subject copy).
    if ($yearId <= 0) {
        $yearId = (int) ($pdo->query("SELECT id FROM tblacademicyear WHERE is_active = 1 ORDER BY id DESC LIMIT 1")->fetchColumn() ?: 0);
    }

    $subjectCode = trim($input['subject_code'] ?? '');
    if ($subjectCode === '') {
        $subjectCode = buildSubjectCode($gradeLevelId, $strand, $subjectName);
    }

    if ($curriculumId) {
        
        $stmt = $pdo->prepare("SELECT id FROM tblsubjects WHERE id = ? LIMIT 1");
        $stmt->execute([$curriculumId]);
        if (!$stmt->fetch()) {
            throw new Exception('Subject not found.');
        }

        $dup = $pdo->prepare("
            SELECT COUNT(*) FROM tblsubjects 
            WHERE grade_level_id = ? AND COALESCE(strand, '') = COALESCE(?, '') 
            AND LOWER(TRIM(subject_name)) = LOWER(TRIM(?)) AND id <> ?
            AND COALESCE(academic_year_id, 0) = ?
        ");
        $dup->execute([$gradeLevelId, $strand, $subjectName, $curriculumId, $yearId]);
        if ((int) $dup->fetchColumn() > 0) {
            throw new Exception('Subject already exists in this grade/track.');
        }

        $pdo->prepare("
            UPDATE tblsubjects 
            SET grade_level_id = ?, strand = ?, subject_code = ?, subject_name = ?, 
                subject_type = ?, cluster = ?, hours = ?, semester = ?,
                tesda_nc_level = ?, prerequisites = ?, is_active = ?, updated_at = NOW()
            WHERE id = ?
        ")->execute([
            $gradeLevelId,
            $strand,
            $subjectCode,
            $subjectName,
            $subjectType,
            $cluster !== '' ? $cluster : null,
            $hoursInput !== '' ? (int)$hoursInput : null,
            $semester !== '' ? $semester : null,
            $tesdaLevel !== '' ? $tesdaLevel : null,
            $prerequisites !== '' ? $prerequisites : null,
            $isActive,
            $curriculumId,
        ]);

        try {
            logActivity($pdo, 'Curriculum', 'UPDATE', 'subject', $curriculumId,
                'Updated subject ' . $subjectName);
        } catch (Throwable $e) {}

        echo json_encode(['success' => true, 'message' => 'Subject updated successfully.']);
        exit;
    }

    
    $dup = $pdo->prepare("
        SELECT COUNT(*) FROM tblsubjects 
        WHERE grade_level_id = ? AND COALESCE(strand, '') = COALESCE(?, '') 
        AND LOWER(TRIM(subject_name)) = LOWER(TRIM(?))
        AND COALESCE(academic_year_id, 0) = ?
    ");
    $dup->execute([$gradeLevelId, $strand, $subjectName, $yearId]);
    if ((int) $dup->fetchColumn() > 0) {
        throw new Exception('Subject already exists in this grade/track.');
    }

    $pdo->prepare("
        INSERT INTO tblsubjects
            (academic_year_id, grade_level_id, strand, subject_code, subject_name, subject_type,
             cluster, hours, semester, tesda_nc_level, prerequisites, is_active, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    ")->execute([
        $yearId > 0 ? $yearId : null,
        $gradeLevelId,
        $strand,
        $subjectCode,
        $subjectName,
        $subjectType,
        $cluster !== '' ? $cluster : null,
        $hoursInput !== '' ? (int)$hoursInput : null,
        $semester !== '' ? $semester : null,
        $tesdaLevel !== '' ? $tesdaLevel : null,
        $prerequisites !== '' ? $prerequisites : null,
        $isActive,
    ]);

    try {
        $newSubjectId = (int)$pdo->lastInsertId();
        logActivity($pdo, 'Curriculum', 'CREATE', 'subject', $newSubjectId ?: null,
            'Created subject ' . $subjectName);
    } catch (Throwable $e) {}

    echo json_encode(['success' => true, 'message' => 'Subject added successfully.']);

} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}