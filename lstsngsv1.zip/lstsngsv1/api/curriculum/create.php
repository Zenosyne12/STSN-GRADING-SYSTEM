<?php
header('Content-Type: application/json');

require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/copy_support.php';

requireLogin();

if (!in_array((int) ($_SESSION['role_id'] ?? 0), [1, 4], true)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid request body.']);
    exit;
}

$yearId = (int) ($input['academic_year_id'] ?? 0);
$setupMode = (string) ($input['setup_mode'] ?? (!empty($input['copy_previous']) ? 'copy' : 'manual'));
$sourceYearId = (int) ($input['source_year_id'] ?? 0);
$acknowledgeSkips = !empty($input['acknowledge_skips']);

if ($yearId <= 0 || !in_array($setupMode, ['manual', 'copy'], true)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid curriculum setup request.']);
    exit;
}

try {
    $pdo->beginTransaction();

    $activeCheck = $pdo->query("
        SELECT id
        FROM tblacademicyear
        WHERE curriculum_status = 'ACTIVE'
        LIMIT 1
        FOR UPDATE
    ");
    if ($activeCheck->fetchColumn()) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'error' => 'An active curriculum already exists.']);
        exit;
    }

    $targetStmt = $pdo->prepare("
        SELECT id, year_label
        FROM tblacademicyear
        WHERE id = ? AND curriculum_status = 'NONE'
        LIMIT 1
        FOR UPDATE
    ");
    $targetStmt->execute([$yearId]);
    $year = $targetStmt->fetch(PDO::FETCH_ASSOC);
    if (!$year) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'error' => 'Invalid year or curriculum already exists.']);
        exit;
    }

    $copyPlan = null;
    if ($setupMode === 'copy') {
        if ($sourceYearId <= 0 && !empty($input['copy_previous'])) {
            $previousStmt = $pdo->prepare("
                SELECT id
                FROM tblacademicyear
                WHERE curriculum_status IN ('ACTIVE', 'ARCHIVED')
                  AND id <> ?
                ORDER BY curriculum_created_at DESC, id DESC
                LIMIT 1
            ");
            $previousStmt->execute([$yearId]);
            $sourceYearId = (int) ($previousStmt->fetchColumn() ?: 0);
        }
        if ($sourceYearId <= 0 || $sourceYearId === $yearId) {
            $pdo->rollBack();
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Select a valid previous curriculum to copy.']);
            exit;
        }

        $sourceStmt = $pdo->prepare("
            SELECT id
            FROM tblacademicyear
            WHERE id = ? AND curriculum_status IN ('ACTIVE', 'ARCHIVED')
            LIMIT 1
            FOR UPDATE
        ");
        $sourceStmt->execute([$sourceYearId]);
        if (!$sourceStmt->fetchColumn()) {
            $pdo->rollBack();
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'The source year does not have an active or archived curriculum.']);
            exit;
        }

        $copyPlan = getCurriculumCopyPlan($pdo, $sourceYearId, true);
        if ($copyPlan['total_source_subjects'] === 0) {
            $pdo->rollBack();
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'The source curriculum has no subjects to copy.']);
            exit;
        }
        if ($copyPlan['will_skip'] > 0 && !$acknowledgeSkips) {
            $pdo->rollBack();
            echo json_encode([
                'success' => false,
                'requires_acknowledgement' => true,
                'error' => 'Review and acknowledge the skipped subjects before creating the curriculum.',
                'preview' => formatCurriculumCopyPreview($copyPlan),
            ]);
            exit;
        }

        $insertSubject = $pdo->prepare("
            INSERT INTO tblsubjects
                (academic_year_id, grade_level_id, strand, cluster, hours,
                 tesda_nc_level, prerequisites, semester, subject_code,
                 subject_name, subject_type, grading_mode, is_active)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
        ");
        foreach ($copyPlan['subjects_to_copy'] as $subject) {
            $insertSubject->execute([
                $yearId,
                $subject['grade_level_id'],
                $subject['strand'],
                $subject['cluster'],
                $subject['hours'],
                $subject['tesda_nc_level'],
                $subject['prerequisites'],
                $subject['semester'],
                $subject['subject_code'],
                $subject['subject_name'],
                $subject['subject_type'],
                $subject['grading_mode'],
            ]);
        }
    }

    $pdo->prepare("
        UPDATE tblacademicyear
        SET curriculum_status = 'ACTIVE',
            curriculum_created_at = NOW()
        WHERE id = ?
    ")->execute([$yearId]);

    $pdo->commit();

    $copiedCount = $copyPlan ? $copyPlan['will_copy'] : 0;
    $skippedSubjects = $copyPlan ? $copyPlan['skipped'] : [];
    $skippedCount = count($skippedSubjects);
    $description = 'Created curriculum for ' . ($year['year_label'] ?? ('AY #' . $yearId));
    if ($setupMode === 'copy') {
        $description .= sprintf(
            ' by copying from AY #%d: %d subjects copied, %d skipped.',
            $sourceYearId,
            $copiedCount,
            $skippedCount
        );
    }
    logActivity(
        $pdo,
        'Curriculum',
        'CREATE',
        'curriculum',
        $yearId,
        $description,
        null,
        $setupMode === 'copy'
            ? ['source_year_id' => $sourceYearId, 'copied' => $copiedCount, 'skipped_subjects' => $skippedSubjects]
            : null
    );

    $message = $setupMode === 'copy'
        ? sprintf('Curriculum created. %d subjects copied, %d skipped.', $copiedCount, $skippedCount)
        : 'Curriculum created.';
    echo json_encode([
        'success' => true,
        'copied' => $copiedCount,
        'skipped' => $skippedCount,
        'skipped_subjects' => $skippedSubjects,
        'message' => $message,
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('Curriculum creation failed: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Unable to create the curriculum. Please try again.']);
}
