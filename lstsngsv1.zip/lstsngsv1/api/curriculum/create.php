<?php
/**
 * api/curriculum/create.php
 * Create (activate) a curriculum for a given academic year.
 * Admin (role 1) or Super Admin (role 4) only.
 */
header('Content-Type: application/json');

require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../shared/db_connect.php';

requireLogin();

if (!in_array((int) ($_SESSION['role_id'] ?? 0), [1, 4], true)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

$input        = json_decode(file_get_contents('php://input'), true) ?: [];
$yearId       = (int) ($input['academic_year_id'] ?? 0);
$copyPrevious = !empty($input['copy_previous']);

if ($yearId <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid year.']);
    exit;
}

try {
    // Rule: only ONE active curriculum at a time.
    $activeCheck = $pdo->query("SELECT COUNT(*) FROM tblacademicyear WHERE curriculum_status = 'ACTIVE'");
    if ((int) $activeCheck->fetchColumn() > 0) {
        echo json_encode(['success' => false, 'error' => 'An active curriculum already exists. Deactivate it first.']);
        exit;
    }

    // Target year must exist and not already own a curriculum.
    $stmt = $pdo->prepare("SELECT id, year_label, curriculum_status FROM tblacademicyear WHERE id = ? LIMIT 1");
    $stmt->execute([$yearId]);
    $year = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$year || ($year['curriculum_status'] ?? 'NONE') !== 'NONE') {
        echo json_encode(['success' => false, 'error' => 'Invalid year or curriculum already exists.']);
        exit;
    }

    $pdo->beginTransaction();

    // copy_previous: duplicate subjects from the most recent curriculum.
    if ($copyPrevious) {
        $prevStmt = $pdo->prepare("
            SELECT id FROM tblacademicyear
            WHERE curriculum_status IN ('ACTIVE','ARCHIVED')
              AND id <> ?
            ORDER BY curriculum_created_at DESC, id DESC
            LIMIT 1
        ");
        $prevStmt->execute([$yearId]);
        $prevYear = $prevStmt->fetchColumn();

        if ($prevYear) {
            $pdo->prepare("
                INSERT INTO tblsubjects
                    (academic_year_id, grade_level_id, strand, cluster, hours,
                     tesda_nc_level, prerequisites, semester, subject_code,
                     subject_name, subject_type, grading_mode, is_active)
                SELECT ?, grade_level_id, strand, cluster, hours,
                       tesda_nc_level, prerequisites, semester, subject_code,
                       subject_name, subject_type, grading_mode, is_active
                FROM tblsubjects
                WHERE academic_year_id = ?
            ")->execute([$yearId, $prevYear]);
        }
    }

    // Mark this year's curriculum as ACTIVE.
    $pdo->prepare("
        UPDATE tblacademicyear
        SET curriculum_status = 'ACTIVE',
            curriculum_created_at = NOW()
        WHERE id = ?
    ")->execute([$yearId]);

    $pdo->commit();

    try {
        logActivity($pdo, 'Curriculum', 'CREATE', 'curriculum', $yearId,
            'Created curriculum for ' . ($year['year_label'] ?? ('AY #' . $yearId)));
    } catch (Throwable $e) {}

    echo json_encode(['success' => true, 'message' => 'Curriculum created.']);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
