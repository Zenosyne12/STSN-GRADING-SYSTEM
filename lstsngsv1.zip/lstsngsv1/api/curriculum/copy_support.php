<?php

function getCurriculumCopyPlan(PDO $pdo, int $sourceYearId, bool $forUpdate = false): array
{
    $lockClause = $forUpdate ? ' FOR UPDATE' : '';
    $clusters = $pdo->query(
        'SELECT cluster_name, is_active FROM tblclusters' . $lockClause
    )->fetchAll(PDO::FETCH_ASSOC);
    $clusterByName = [];
    foreach ($clusters as $cluster) {
        $key = mb_strtolower(trim((string) $cluster['cluster_name']));
        $clusterByName[$key] = ($clusterByName[$key] ?? false)
            || (int) ($cluster['is_active'] ?? 0) === 1;
    }

    $subjectsStmt = $pdo->prepare("
        SELECT id, grade_level_id, strand, cluster, hours, tesda_nc_level,
               prerequisites, semester, subject_code, subject_name,
               subject_type, grading_mode, is_active
        FROM tblsubjects
        WHERE academic_year_id = ?
        ORDER BY id
        $lockClause
    ");
    $subjectsStmt->execute([$sourceYearId]);
    $subjects = $subjectsStmt->fetchAll(PDO::FETCH_ASSOC);

    $validSubjects = [];
    $skipped = [];
    $clusterChanges = [];
    $inactiveCount = 0;

    foreach ($subjects as $subject) {
        $clusterName = trim((string) ($subject['cluster'] ?? ''));
        if ((int) ($subject['is_active'] ?? 0) !== 1) {
            $skipped[] = [
                'subject_name' => (string) $subject['subject_name'],
                'reason' => 'Subject is inactive',
            ];
            $inactiveCount++;
            continue;
        }

        if ($clusterName !== '') {
            $clusterKey = mb_strtolower($clusterName);
            if (!array_key_exists($clusterKey, $clusterByName) || !$clusterByName[$clusterKey]) {
                $exists = array_key_exists($clusterKey, $clusterByName);
                $status = $exists ? 'disabled' : 'deleted';
                $reason = $exists
                    ? 'Cluster "' . $clusterName . '" is disabled'
                    : 'Cluster "' . $clusterName . '" was deleted';
                $skipped[] = [
                    'subject_name' => (string) $subject['subject_name'],
                    'reason' => $reason,
                ];

                if (!isset($clusterChanges[$clusterKey])) {
                    $clusterChanges[$clusterKey] = [
                        'cluster_name' => $clusterName,
                        'status' => $status,
                        'affected_subjects' => 0,
                    ];
                }
                $clusterChanges[$clusterKey]['affected_subjects']++;
                continue;
            }
        }

        $validSubjects[] = $subject;
    }

    $warnings = [];
    if ($inactiveCount > 0) {
        $warnings[] = $inactiveCount . ' inactive subject' . ($inactiveCount === 1 ? '' : 's') . ' will be skipped.';
    }
    foreach ($clusterChanges as $change) {
        $warnings[] = sprintf(
            '%d subject%s reference the %s "%s" cluster and will be skipped.',
            $change['affected_subjects'],
            $change['affected_subjects'] === 1 ? '' : 's',
            $change['status'],
            $change['cluster_name']
        );
    }

    return [
        'total_source_subjects' => count($subjects),
        'will_copy' => count($validSubjects),
        'will_skip' => count($skipped),
        'subjects_to_copy' => $validSubjects,
        'skipped' => $skipped,
        'cluster_changes' => array_values($clusterChanges),
        'warnings' => $warnings,
    ];
}

function formatCurriculumCopyPreview(array $plan): array
{
    return [
        'total_source_subjects' => $plan['total_source_subjects'],
        'will_copy' => $plan['will_copy'],
        'will_skip' => $plan['will_skip'],
        'skipped' => $plan['skipped'],
        'cluster_changes' => $plan['cluster_changes'],
        'warnings' => $plan['warnings'],
    ];
}
