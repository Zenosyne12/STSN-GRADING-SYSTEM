<?php
// api/curriculum/structure.php
// Reads tblgradelevel and groups into Kinder / Elem / JHS / SHS

require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT id, grade_level_name FROM tblgradelevel ORDER BY id ASC");
    $grades = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $groups = [
        'KINDER' => ['code' => 'KINDER', 'label' => 'Kinder',            'grades' => []],
        'ELEM'   => ['code' => 'ELEM',   'label' => 'Elementary',         'grades' => []],
        'JHS'    => ['code' => 'JHS',    'label' => 'Junior High School', 'grades' => []],
        'SHS'    => ['code' => 'SHS',    'label' => 'Senior High School', 'grades' => []],
    ];

    foreach ($grades as $g) {
        $id  = (int) $g['id'];
        $row = ['id' => $id, 'grade_label' => $g['grade_level_name']];

        if ($id === 1)                  $groups['KINDER']['grades'][] = $row;
        elseif ($id >= 2  && $id <= 7)  $groups['ELEM']['grades'][]   = $row;
        elseif ($id >= 8  && $id <= 11) $groups['JHS']['grades'][]    = $row;
        elseif ($id >= 12 && $id <= 13) $groups['SHS']['grades'][]    = $row;
    }

    echo json_encode([
        'success' => true,
        'data'    => array_values($groups),
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}