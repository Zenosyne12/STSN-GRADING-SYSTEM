<?php



require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT id, grade_level_name, grade_level_code FROM tblgradelevel ORDER BY grade_level_code ASC, id ASC");
    $grades = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $groups = [
        'KINDER' => ['code' => 'KINDER', 'label' => 'Kinder',            'grades' => []],
        'ELEM'   => ['code' => 'ELEM',   'label' => 'Elementary',         'grades' => []],
        'JHS'    => ['code' => 'JHS',    'label' => 'Junior High School', 'grades' => []],
        'SHS'    => ['code' => 'SHS',    'label' => 'Senior High School', 'grades' => []],
    ];

    foreach ($grades as $g) {
        $id   = (int) $g['id'];
        $code = (int) $g['grade_level_code'];
        $row = ['id' => $id, 'grade_label' => $g['grade_level_name']];

        /*
         * FIX: group by grade_level_code, not by hardcoded id ranges.
         * Live tblgradelevel: id 1-12 = Grade 1-12 (code = id), id 13 = Kindergarten (code 0).
         */
        if ($code === 0)                   $groups['KINDER']['grades'][] = $row;
        elseif ($code >= 1  && $code <= 6)  $groups['ELEM']['grades'][]   = $row;
        elseif ($code >= 7  && $code <= 10) $groups['JHS']['grades'][]    = $row;
        elseif ($code >= 11)                $groups['SHS']['grades'][]    = $row;
    }

    echo json_encode([
        'success' => true,
        'data'    => array_values($groups),
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}