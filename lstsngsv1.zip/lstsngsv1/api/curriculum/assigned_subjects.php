<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

$gradeId = isset($_GET['grade_id']) ? (int) $_GET['grade_id'] : 0;
$strand = strtoupper(trim($_GET['strand'] ?? ''));
$cluster = trim($_GET['cluster'] ?? '');
$yearId  = isset($_GET['academic_year_id']) ? (int) $_GET['academic_year_id'] : 0;
$allowedStrands = ['ACADEMIC', 'TECHNICAL-PROFESSIONAL (TECH-PRO)', 'TECH-PRO', 'ABM', 'STEM', 'GAS', 'HUMSS', 'TVL', 'ARTS', 'SPORTS'];

if ($gradeId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'grade_id is required.']);
    exit;
}

try {
    $stmtGrade = $pdo->prepare("SELECT id, grade_level_name, grade_level_code FROM tblgradelevel WHERE id = ? LIMIT 1");
    $stmtGrade->execute([$gradeId]);
    $gradeRow = $stmtGrade->fetch(PDO::FETCH_ASSOC);

    if (!$gradeRow) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Grade not found.']);
        exit;
    }

    /*
     * FIX: tblgradelevel (live) is id 1-12 = Grade 1-12, id 13 = Kindergarten (grade_level_code 0).
     * tblsubjects.grade_level_id stores those same tblgradelevel.id values
     * (verified: grade_level_id 1 = AP1..., 11 = Grade 11, 12 = Grade 12), so
     * SHS must be derived from grade_level_code >= 11, NOT from hardcoded ids [12,13]
     * (which made Grade 11 fall into the non-SHS branch and hide all strand-tagged subjects).
     */
    $gradeCode = (int) $gradeRow['grade_level_code'];
    $isShs = ($gradeCode >= 11);

    if ($isShs) {
        if (mb_strlen($cluster) > 100) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Cluster name is too long.']);
            exit;
        }
        if ($strand !== '' && !in_array($strand, $allowedStrands, true)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Valid track is required for Grade 11 and Grade 12.']);
            exit;
        }
        // tblsubjects.strand is varchar(10) holding 'Academic' / 'Tech-Pro';
        // Keep accepting the former long UI label while querying the stored value.
        $strandFilter = in_array($strand, ['TECH-PRO', 'TECHNICAL-PROFESSIONAL (TECH-PRO)'], true) ? 'TECH-PRO' : $strand;
    } else {
        $strand = null;
        $strandFilter = null;
        $cluster = '';
    }

    // Require a year so yearless and other-year records never leak into this view.
    $yearClause = $yearId > 0 ? ' AND academic_year_id = ?' : ' AND 1 = 0';

    if ($gradeCode === 0)                        $levelLabel = 'Kinder';
    elseif ($gradeCode >= 1  && $gradeCode <= 6)  $levelLabel = 'Elementary';
    elseif ($gradeCode >= 7  && $gradeCode <= 10) $levelLabel = 'Junior High School';
    else                                         $levelLabel = 'Senior High School';

    $grade = [
        'id'          => (int) $gradeRow['id'],
        'grade_label' => $gradeRow['grade_level_name'],
        'level_label' => $levelLabel,
        'strand'      => $strand,
        'cluster'     => $cluster,
    ];

    if ($isShs) {
        $clusterClause = $cluster !== '' ? ' AND cluster = ?' : '';
        if ($strand !== null && $strand !== '') {
            $stmtSubj = $pdo->prepare("
                SELECT 
                    id AS curriculum_id,
                    grade_level_id,
                    strand,
                    cluster,
                    hours,
                    semester,
                    tesda_nc_level,
                    prerequisites,
                    subject_code,
                    subject_name,
                    subject_type,
                    is_active,
                    created_at,
                    updated_at
                FROM tblsubjects
                WHERE grade_level_id = ? AND strand = ?{$yearClause}{$clusterClause}
                ORDER BY 
                    FIELD(subject_type, 'CORE', 'APPLIED', 'SPECIALIZED', 'ELECTIVE'),
                    subject_name ASC
            ");
            $params = [$gradeId, $strandFilter];
            if ($yearId > 0) $params[] = $yearId;
            if ($cluster !== '') $params[] = $cluster;
            $stmtSubj->execute($params);
        } else {
            // No strand or cluster selected: show all subjects for the grade.
            $stmtSubj = $pdo->prepare("
                SELECT 
                    id AS curriculum_id,
                    grade_level_id,
                    strand,
                    cluster,
                    hours,
                    semester,
                    tesda_nc_level,
                    prerequisites,
                    subject_code,
                    subject_name,
                    subject_type,
                    is_active,
                    created_at,
                    updated_at
                FROM tblsubjects
                WHERE grade_level_id = ?{$yearClause}{$clusterClause}
                ORDER BY 
                    strand IS NULL DESC,
                    strand ASC,
                    FIELD(subject_type, 'CORE', 'APPLIED', 'SPECIALIZED', 'ELECTIVE'),
                    subject_name ASC
            ");
            $params = [$gradeId];
            if ($yearId > 0) $params[] = $yearId;
            if ($cluster !== '') $params[] = $cluster;
            $stmtSubj->execute($params);
        }
    } else {
        $stmtSubj = $pdo->prepare("
            SELECT 
                id AS curriculum_id,
                grade_level_id,
                strand,
                cluster,
                hours,
                semester,
                tesda_nc_level,
                prerequisites,
                subject_code,
                subject_name,
                subject_type,
                is_active,
                created_at,
                updated_at
            FROM tblsubjects
            WHERE grade_level_id = ?{$yearClause}
            ORDER BY subject_name ASC
        ");
        $stmtSubj->execute($yearId > 0 ? [$gradeId, $yearId] : [$gradeId]);
    }

    $subjects = $stmtSubj->fetchAll(PDO::FETCH_ASSOC);

    foreach ($subjects as &$row) {
        $row['curriculum_id']   = (int) $row['curriculum_id'];
        $row['grade_level_id']  = (int) $row['grade_level_id'];
        $row['is_active']       = (int) $row['is_active'];
        $row['strand']          = $row['strand'] !== null ? (string) $row['strand'] : null;
    }
    unset($row);

    echo json_encode([
        'success'  => true,
        'grade'    => $grade,
        'subjects' => $subjects,
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}