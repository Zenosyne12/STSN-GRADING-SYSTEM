<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

$gradeId = isset($_GET['grade_id']) ? (int) $_GET['grade_id'] : 0;
$strand = strtoupper(trim($_GET['strand'] ?? ''));
$allowedStrands = ['ABM', 'STEM', 'GAS', 'HUMSS', 'TVL', 'ARTS', 'SPORTS'];

if ($gradeId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'grade_id is required.']);
    exit;
}

$isShs = in_array($gradeId, [12, 13], true);

if ($isShs) {
    if ($strand === '' || !in_array($strand, $allowedStrands, true)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Valid strand is required for Grade 11 and Grade 12.']);
        exit;
    }
} else {
    $strand = null;
}

try {
    $stmtGrade = $pdo->prepare("SELECT id, grade_level_name FROM tblgradelevel WHERE id = ? LIMIT 1");
    $stmtGrade->execute([$gradeId]);
    $gradeRow = $stmtGrade->fetch(PDO::FETCH_ASSOC);

    if (!$gradeRow) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Grade not found.']);
        exit;
    }

    $id = (int) $gradeRow['id'];
    if ($id === 1)                  $levelLabel = 'Kinder';
    elseif ($id >= 2  && $id <= 7)  $levelLabel = 'Elementary';
    elseif ($id >= 8  && $id <= 11) $levelLabel = 'Junior High School';
    elseif ($id >= 12 && $id <= 13) $levelLabel = 'Senior High School';
    else                            $levelLabel = '';

    $grade = [
        'id'          => $id,
        'grade_label' => $gradeRow['grade_level_name'],
        'level_label' => $levelLabel,
        'strand'      => $strand,
    ];

    if ($isShs) {
        $stmtSubj = $pdo->prepare("
            SELECT 
                id AS curriculum_id,
                grade_level_id,
                strand,
                subject_code,
                subject_name,
                subject_type,
                is_active,
                created_at,
                updated_at
            FROM tblsubjects
            WHERE grade_level_id = ? AND (strand = ? OR strand IS NULL)
            ORDER BY 
                FIELD(subject_type, 'CORE', 'APPLIED', 'SPECIALIZED', 'ELECTIVE'),
                subject_name ASC
        ");
        $stmtSubj->execute([$gradeId, $strand]);
    } else {
        $stmtSubj = $pdo->prepare("
            SELECT 
                id AS curriculum_id,
                grade_level_id,
                strand,
                subject_code,
                subject_name,
                subject_type,
                is_active,
                created_at,
                updated_at
            FROM tblsubjects
            WHERE grade_level_id = ? AND (strand IS NULL OR strand = '')
            ORDER BY subject_name ASC
        ");
        $stmtSubj->execute([$gradeId]);
    }

    $subjects = $stmtSubj->fetchAll(PDO::FETCH_ASSOC);

    foreach ($subjects as &$row) {
        $row['curriculum_id']   = (int) $row['curriculum_id'];
        $row['grade_level_id']  = (int) $row['grade_level_id'];
        $row['is_active']       = (int) $row['is_active'];
        $row['strand']          = $row['strand'] !== null ? (string) $row['strand'] : null;
    }
    unset($row);

    echo json_encode([
        'success'  => true,
        'grade'    => $grade,
        'subjects' => $subjects,
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}