<?php
/**
 * api/curriculum/deactivate.php
 * Archive (deactivate) the currently active curriculum.
 * Admin (role 1) or Super Admin (role 4) only.
 */
header('Content-Type: application/json');

require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../shared/db_connect.php';

requireLogin();

if (!in_array((int) ($_SESSION['role_id'] ?? 0), [1, 4], true)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

$input  = json_decode(file_get_contents('php://input'), true) ?: [];
$yearId = (int) ($input['academic_year_id'] ?? 0);

if ($yearId <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid year.']);
    exit;
}

try {
    $stmt = $pdo->prepare("
        UPDATE tblacademicyear
        SET curriculum_status = 'ARCHIVED',
            curriculum_archived_at = NOW()
        WHERE id = ? AND curriculum_status = 'ACTIVE'
    ");
    $stmt->execute([$yearId]);

    if ($stmt->rowCount() < 1) {
        echo json_encode(['success' => false, 'error' => 'No active curriculum found for that year.']);
        exit;
    }

    try {
        logActivity($pdo, 'Curriculum', 'UPDATE', 'curriculum', $yearId,
            'Archived curriculum (AY #' . $yearId . ')');
    } catch (Throwable $e) {}

    echo json_encode(['success' => true, 'message' => 'Curriculum archived.']);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
