<?php
require_once __DIR__ . '/../shared/db_connect.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) {
        throw new Exception('Invalid JSON payload.');
    }

    $curriculumId = (int) ($input['curriculum_id'] ?? 0);
    if ($curriculumId <= 0) {
        throw new Exception('curriculum_id is required.');
    }

    $stmt = $pdo->prepare("DELETE FROM tblsubjects WHERE id = ?");
    $stmt->execute([$curriculumId]);

    if ($stmt->rowCount() < 1) {
        throw new Exception('Subject not found or already deleted.');
    }

    echo json_encode(['success' => true, 'message' => 'Subject deleted successfully.']);

} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}