<?php
header('Content-Type: application/json');

require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../shared/db_connect.php';

requireLogin();

// Subject deletion is a Super Admin capability only.
if ((int) ($_SESSION['role_id'] ?? 0) !== 4) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Only Super Admins can delete subjects.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) {
        throw new Exception('Invalid JSON payload.');
    }

    $curriculumId = (int) ($input['curriculum_id'] ?? 0);
    if ($curriculumId <= 0) {
        throw new Exception('curriculum_id is required.');
    }

    $delName = '';
    try {
        $nameStmt = $pdo->prepare("SELECT subject_name FROM tblsubjects WHERE id = ? LIMIT 1");
        $nameStmt->execute([$curriculumId]);
        $delName = (string)($nameStmt->fetchColumn() ?: '');
    } catch (Throwable $e) {}

    $stmt = $pdo->prepare("DELETE FROM tblsubjects WHERE id = ?");
    $stmt->execute([$curriculumId]);

    if ($stmt->rowCount() < 1) {
        throw new Exception('Subject not found or already deleted.');
    }

    try {
        logActivity($pdo, 'Curriculum', 'DELETE', 'subject', $curriculumId,
            'Deleted subject' . ($delName !== '' ? ' ' . $delName : ''));
    } catch (Throwable $e) {}

    echo json_encode(['success' => true, 'message' => 'Subject deleted successfully.']);

} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}