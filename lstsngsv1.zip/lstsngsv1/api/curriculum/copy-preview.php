<?php
header('Content-Type: application/json');

require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/copy_support.php';

requireLogin();

if (!in_array((int) ($_SESSION['role_id'] ?? 0), [1, 4], true)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

$sourceYearId = filter_input(INPUT_GET, 'source_year_id', FILTER_VALIDATE_INT);
$targetYearId = filter_input(INPUT_GET, 'target_year_id', FILTER_VALIDATE_INT);
if (!$sourceYearId || !$targetYearId || $sourceYearId === $targetYearId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Select a valid source and target year.']);
    exit;
}

try {
    $sourceStmt = $pdo->prepare("
        SELECT id, curriculum_status
        FROM tblacademicyear
        WHERE id = ? AND curriculum_status IN ('ACTIVE', 'ARCHIVED')
        LIMIT 1
    ");
    $sourceStmt->execute([$sourceYearId]);
    if (!$sourceStmt->fetch(PDO::FETCH_ASSOC)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'The source year does not have an active or archived curriculum.']);
        exit;
    }

    $targetStmt = $pdo->prepare("
        SELECT id
        FROM tblacademicyear
        WHERE id = ? AND curriculum_status = 'NONE'
        LIMIT 1
    ");
    $targetStmt->execute([$targetYearId]);
    if (!$targetStmt->fetchColumn()) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'The target year is unavailable or already has a curriculum.']);
        exit;
    }

    $plan = getCurriculumCopyPlan($pdo, $sourceYearId);
    if ($plan['total_source_subjects'] === 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'The source curriculum has no subjects to copy.']);
        exit;
    }

    echo json_encode([
        'success' => true,
        'total_source_subjects' => $plan['total_source_subjects'],
        'will_copy' => $plan['will_copy'],
        'will_skip' => $plan['will_skip'],
        'skipped' => $plan['skipped'],
        'cluster_changes' => $plan['cluster_changes'],
        'warnings' => $plan['warnings'],
    ]);
} catch (Throwable $e) {
    error_log('Curriculum copy preview failed: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Unable to preview the curriculum copy. Please try again.']);
}
