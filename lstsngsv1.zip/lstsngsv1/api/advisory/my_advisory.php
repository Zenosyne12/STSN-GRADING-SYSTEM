<?php
session_start();
header('Content-Type: application/json');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../shared/db_connect.php';

function respond(array $data, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    // Support either $pdo or $conn from db_connect.php
    if (isset($pdo) && $pdo instanceof PDO) {
        $db = $pdo;
    } elseif (isset($conn) && $conn instanceof PDO) {
        $db = $conn;
    } else {
        respond([
            'success' => false,
            'message' => 'Database connection not found. Expected $pdo or $conn from db_connect.php.'
        ], 500);
    }

    // Logged-in teacher
    $teacherId = $_SESSION['reference_id'] ?? null;

    // Temporary fallback for testing
    if (!$teacherId && isset($_GET['teacher_id'])) {
        $teacherId = (int) $_GET['teacher_id'];
    }

    // Debug fallback
    if (!$teacherId) {
        $teacherId = 3;
    }

    // Active academic year
    $ayStmt = $db->query("
        SELECT id, year_label
        FROM tblacademicyear
        WHERE is_active = 1
        LIMIT 1
    ");
    $activeYear = $ayStmt->fetch(PDO::FETCH_ASSOC);

    if (!$activeYear) {
        respond([
            'success' => false,
            'message' => 'No active academic year found.'
        ], 404);
    }

    $academicYearId = (int) $activeYear['id'];

    // Teacher info
    $teacherStmt = $db->prepare("
        SELECT id, teacher_id, fname, lname, email
        FROM tblteacher
        WHERE id = :teacher_id
        LIMIT 1
    ");
    $teacherStmt->execute([
        'teacher_id' => $teacherId
    ]);
    $teacher = $teacherStmt->fetch(PDO::FETCH_ASSOC);

    if (!$teacher) {
        respond([
            'success' => false,
            'message' => 'Teacher record not found.',
            'teacher_id_used' => $teacherId
        ], 404);
    }

    $teacherName = trim(($teacher['fname'] ?? '') . ' ' . ($teacher['lname'] ?? ''));

    // Advisories assigned to this teacher
    $advisoryStmt = $db->prepare("
        SELECT
            sa.section_id,
            s.section_name,
            s.grade_level_id,
            gl.grade_level_name,
            COUNT(ss.student_id) AS total_students
        FROM tblsectionadviser sa
        INNER JOIN tblsection s
            ON s.id = sa.section_id
        LEFT JOIN tblgradelevel gl
            ON gl.id = s.grade_level_id
        LEFT JOIN tblsectionstudent ss
            ON ss.section_id = sa.section_id
            AND ss.academic_year_id = sa.academic_year_id
            AND ss.is_active = 1
        WHERE sa.teacher_id = :teacher_id
          AND sa.academic_year_id = :academic_year_id
        GROUP BY
            sa.section_id,
            s.section_name,
            s.grade_level_id,
            gl.grade_level_name
        ORDER BY s.grade_level_id ASC, s.section_name ASC
    ");
    $advisoryStmt->execute([
        'teacher_id' => $teacherId,
        'academic_year_id' => $academicYearId
    ]);
    $advisories = $advisoryStmt->fetchAll(PDO::FETCH_ASSOC);

    // Fallback if active year has no assignment yet
    if (!$advisories) {
        $fallbackStmt = $db->prepare("
            SELECT
                sa.section_id,
                s.section_name,
                s.grade_level_id,
                gl.grade_level_name,
                COUNT(ss.student_id) AS total_students
            FROM tblsectionadviser sa
            INNER JOIN tblsection s
                ON s.id = sa.section_id
            LEFT JOIN tblgradelevel gl
                ON gl.id = s.grade_level_id
            LEFT JOIN tblsectionstudent ss
                ON ss.section_id = sa.section_id
                AND ss.is_active = 1
            WHERE sa.teacher_id = :teacher_id
            GROUP BY
                sa.section_id,
                s.section_name,
                s.grade_level_id,
                gl.grade_level_name
            ORDER BY s.grade_level_id ASC, s.section_name ASC
        ");
        $fallbackStmt->execute([
            'teacher_id' => $teacherId
        ]);
        $advisories = $fallbackStmt->fetchAll(PDO::FETCH_ASSOC);
    }

    if (!$advisories) {
        respond([
            'success' => true,
            'teacher' => [
                'id' => (int) $teacher['id'],
                'teacher_code' => $teacher['teacher_id'],
                'name' => $teacherName,
                'email' => $teacher['email']
            ],
            'academic_year' => [
                'id' => $academicYearId,
                'label' => $activeYear['year_label']
            ],
            'advisories' => [],
            'selected_section' => null,
            'students' => [],
            'alerts' => []
        ]);
    }

    $selectedSectionId = isset($_GET['section']) ? (int) $_GET['section'] : (int) $advisories[0]['section_id'];

    $selectedSection = null;
    foreach ($advisories as $advisory) {
        if ((int) $advisory['section_id'] === $selectedSectionId) {
            $selectedSection = $advisory;
            break;
        }
    }

    if (!$selectedSection) {
        $selectedSection = $advisories[0];
        $selectedSectionId = (int) $selectedSection['section_id'];
    }

    // Students in selected section
    $studentStmt = $db->prepare("
        SELECT
            st.id,
            st.lrn,
            st.fname,
            st.mname,
            st.lname,
            st.gender,
            st.birthdate,
            st.grade_level_id,
            gl.grade_level_name,
            s.section_name,
            ss.section_id
        FROM tblsectionstudent ss
        INNER JOIN tblstudents st
            ON st.id = ss.student_id
        INNER JOIN tblsection s
            ON s.id = ss.section_id
        LEFT JOIN tblgradelevel gl
            ON gl.id = st.grade_level_id
        WHERE ss.section_id = :section_id
          AND ss.is_active = 1
        ORDER BY st.lname ASC, st.fname ASC
    ");
    $studentStmt->execute([
        'section_id' => $selectedSectionId
    ]);
    $studentRows = $studentStmt->fetchAll(PDO::FETCH_ASSOC);

    $students = array_map(function ($row) {
        $fullName = trim(
            ($row['fname'] ?? '') .
            (!empty($row['mname']) ? ' ' . $row['mname'] : '') .
            ' ' .
            ($row['lname'] ?? '')
        );

        return [
            'id' => (int) $row['id'],
            'lrn' => $row['lrn'],
            'name' => preg_replace('/\s+/', ' ', $fullName),
            'gender' => $row['gender'],
            'birthdate' => $row['birthdate'],
            'grade_level_id' => $row['grade_level_id'] ? (int) $row['grade_level_id'] : null,
            'grade_level_name' => $row['grade_level_name'],
            'section_id' => (int) $row['section_id'],
            'section_name' => $row['section_name']
        ];
    }, $studentRows);

    $alerts = array_map(function ($student) {
        return [
            'title' => $student['name'],
            'desc' => 'Student is enrolled in the selected advisory section.'
        ];
    }, $students);

    respond([
        'success' => true,
        'teacher' => [
            'id' => (int) $teacher['id'],
            'teacher_code' => $teacher['teacher_id'],
            'name' => $teacherName,
            'email' => $teacher['email']
        ],
        'academic_year' => [
            'id' => $academicYearId,
            'label' => $activeYear['year_label']
        ],
        'advisories' => array_map(function ($row) {
            return [
                'section_id' => (int) $row['section_id'],
                'section_name' => $row['section_name'],
                'grade_level_id' => $row['grade_level_id'] ? (int) $row['grade_level_id'] : null,
                'grade_level_name' => $row['grade_level_name'],
                'display_name' => trim(($row['grade_level_name'] ?? '') . ' - ' . ($row['section_name'] ?? '')),
                'total_students' => (int) $row['total_students']
            ];
        }, $advisories),
        'selected_section' => [
            'section_id' => (int) $selectedSection['section_id'],
            'section_name' => $selectedSection['section_name'],
            'grade_level_id' => $selectedSection['grade_level_id'] ? (int) $selectedSection['grade_level_id'] : null,
            'grade_level_name' => $selectedSection['grade_level_name'],
            'display_name' => trim(($selectedSection['grade_level_name'] ?? '') . ' - ' . ($selectedSection['section_name'] ?? '')),
            'total_students' => (int) $selectedSection['total_students']
        ],
        'students' => $students,
        'alerts' => $alerts
    ]);
} catch (Throwable $e) {
    respond([
        'success' => false,
        'message' => 'Server error.',
        'error' => $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine()
    ], 500);
}