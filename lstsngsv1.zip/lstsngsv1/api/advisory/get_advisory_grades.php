<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/auth.php';
require_once __DIR__ . '/attendance_table.php';
require_once __DIR__ . '/../shared/grade_workflow.php';

$teacher_id = $_SESSION['teacher_id'] ?? 0;
if (!$teacher_id) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized.']);
    exit;
}

$section_id = isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0;
$quarter    = isset($_GET['quarter']) ? (int)$_GET['quarter'] : 0;
$year_id    = isset($_GET['year_id']) ? (int)$_GET['year_id'] : 0;

if (!$section_id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'section_id is required.']);
    exit;
}

try {
    ensureAttendanceTable($pdo);
    ensureGradeWorkflowSchema($pdo);

    $advStmt = $pdo->prepare("
        SELECT sa.id FROM tblsectionadviser sa
        WHERE sa.section_id = ? AND sa.teacher_id = ?
        AND sa.academic_year_id = (SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1)
        LIMIT 1
    ");
    $advStmt->execute([$section_id, $teacher_id]);
    if (!$advStmt->fetch()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'You are not the adviser of this section.']);
        exit;
    }

    if ($year_id) {
        $yearStmt = $pdo->prepare("SELECT id, year_label FROM tblacademicyear WHERE id = ? LIMIT 1");
        $yearStmt->execute([$year_id]);
        $yearRow = $yearStmt->fetch(PDO::FETCH_ASSOC);
    } else {
        $yearRow = $pdo->query("SELECT id, year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1")
                       ->fetch(PDO::FETCH_ASSOC);
    }
    $year_id = $yearRow['id'] ?? 0;
    $year_label = $yearRow['year_label'] ?? '';

    $secStmt = $pdo->prepare("
        SELECT s.id, s.section_name, s.grade_level_id, gl.grade_level_name, gl.grade_level_code
        FROM tblsection s
        JOIN tblgradelevel gl ON gl.id = s.grade_level_id
        WHERE s.id = ?
    ");
    $secStmt->execute([$section_id]);
    $section = $secStmt->fetch(PDO::FETCH_ASSOC);

    $subjStmt = $pdo->prepare("
        SELECT id, subject_code, subject_name, subject_type
        FROM tblsubjects
        WHERE grade_level_id = ? AND is_active = 1
        ORDER BY subject_type ASC, subject_name ASC
    ");
    $subjStmt->execute([$section['grade_level_id']]);
    $subjects = $subjStmt->fetchAll(PDO::FETCH_ASSOC);

    $stuStmt = $pdo->prepare("
        SELECT st.id, st.lrn,
            CONCAT(st.lname, ', ', st.fname, ' ', COALESCE(NULLIF(st.mname,''), '')) AS full_name,
            st.gender
        FROM tblsectionstudent ss
        JOIN tblstudents st ON st.id = ss.student_id
        WHERE ss.section_id = ? AND ss.academic_year_id = ? AND ss.is_active = 1 AND st.is_active = 1
        ORDER BY st.gender DESC, st.lname, st.fname
    ");
    $stuStmt->execute([$section_id, $year_id]);
    $students = $stuStmt->fetchAll(PDO::FETCH_ASSOC);

    $quarterClause = $quarter ? "AND g.quarter = $quarter" : "";

    $studentIds = array_column($students, 'id');
    if (empty($studentIds)) {
        echo json_encode([
            'success' => true,
            'section' => $section,
            'subjects' => $subjects,
            'students' => [],
            'year_label' => $year_label,
            'quarter' => $quarter,
            'submission_status' => null
        ]);
        exit;
    }

    $placeholders = implode(',', array_fill(0, count($studentIds), '?'));

    $gradeSql = "
        SELECT g.student_id, g.subject_id, g.quarter, g.final_grade, g.initial_grade,
               g.remarks, g.teacher_id, g.status,
               ts.id AS teacher_submission_id,
               CONCAT(t.fname, ' ', t.lname) AS teacher_name
        FROM tblgrades g
        LEFT JOIN tblteacher_submissions ts
            ON ts.teacher_id = g.teacher_id
           AND ts.section_id = g.section_id
           AND ts.subject_id = g.subject_id
           AND ts.quarter = g.quarter
           AND ts.school_year = ?
        LEFT JOIN tblteacher t ON t.id = g.teacher_id
        WHERE g.student_id IN ($placeholders)
          AND g.section_id = ?
          AND g.academic_year_id = ?
          $quarterClause
        ORDER BY g.student_id, g.subject_id, g.quarter
    ";
    $gradeStmt = $pdo->prepare($gradeSql);
    $params = array_merge([$year_label], $studentIds, [$section_id, $year_id]);
    $gradeStmt->execute($params);
    $rawGrades = $gradeStmt->fetchAll(PDO::FETCH_ASSOC);

    $gradeIndex = [];
    foreach ($rawGrades as $r) {
        $gradeIndex[$r['student_id']][$r['subject_id']][$r['quarter']] = $r;
    }

    $attendanceStmt = $pdo->prepare("
        SELECT student_id, month_number, month_name, school_days, days_present, days_absent
        FROM tblattendance_records
        WHERE section_id = ? AND academic_year_id = ?
        ORDER BY month_number
    ");
    $attendanceStmt->execute([$section_id, $year_id]);
    $attendanceIndex = [];
    foreach ($attendanceStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $attendanceIndex[(int)$row['student_id']][(int)$row['month_number']] = [
            'month_number' => (int)$row['month_number'],
            'month_name' => $row['month_name'],
            'school_days' => (float)$row['school_days'],
            'days_present' => (float)$row['days_present'],
            'days_absent' => (float)$row['days_absent']
        ];
    }

    $subStmt = $pdo->prepare("
        SELECT id, teacher_id, section_id, quarter, school_year, submitted_at
        FROM tbladviser_submissions
        WHERE section_id = ? AND quarter = ? AND school_year = ?
        LIMIT 1
    ");
    $subStmt->execute([$section_id, $quarter ?: 1, $year_label]);
    $adviserSubmission = $subStmt->fetch(PDO::FETCH_ASSOC);

    $expectedStmt = $pdo->prepare("
        SELECT DISTINCT subject_id
        FROM tblschedule
        WHERE section_id = ? AND is_active = 1
    ");
    $expectedStmt->execute([$section_id]);
    $expectedSubjectIds = array_map('intval', array_column($expectedStmt->fetchAll(PDO::FETCH_ASSOC), 'subject_id'));
    if (empty($expectedSubjectIds)) {
        $expectedSubjectIds = array_map('intval', array_column($subjects, 'id'));
    }

    $resultStudents = [];
    foreach ($students as $st) {
        $sid = $st['id'];
        $stuGrades = [];
        $totalGrades = 0;
        $gradeCount = 0;
        foreach ($subjects as $sub) {
            $subId = $sub['id'];
            $subQuarters = $gradeIndex[$sid][$subId] ?? [];

            if ($quarter) {
                $g = $subQuarters[$quarter] ?? null;
                $hasTeacherSubmission = $g && !empty($g['teacher_submission_id']);
                $isReviewable = $g && $hasTeacherSubmission && in_array((string)$g['status'], ['pending_adviser', 'submitted_to_adviser', 'approved', 'approved_by_adviser', 'finalized'], true);
                $fg = $isReviewable ? (float)$g['final_grade'] : 0;
                $teacherName = $g ? $g['teacher_name'] : '';
                $statusLabel = gradeWorkflowLabel($g['status'] ?? null, (bool)$hasTeacherSubmission, (bool)$g);
            } else {
                $reviewableRows = array_filter($subQuarters, fn($r) => !empty($r['teacher_submission_id']) && in_array((string)$r['status'], ['pending_adviser', 'submitted_to_adviser', 'approved', 'approved_by_adviser', 'finalized'], true));
                $fgValues = array_map(fn($r) => (float)$r['final_grade'], $reviewableRows);
                $fgValues = array_filter($fgValues, fn($v) => $v > 0);
                $fg = count($fgValues) ? array_sum($fgValues) / count($fgValues) : 0;
                $teacherName = '';
                $statusLabel = empty($subQuarters) ? 'No Grades Yet' : 'Pending Submission';
                foreach ($subQuarters as $q) {
                    if (!$teacherName && $q['teacher_name']) $teacherName = $q['teacher_name'];
                    if (($q['status'] ?? '') === 'draft') $statusLabel = 'Draft Only';
                    if (!empty($q['teacher_submission_id']) && in_array((string)$q['status'], ['pending_adviser', 'submitted_to_adviser', 'approved', 'approved_by_adviser', 'finalized'], true)) $statusLabel = 'Submitted';
                }
            }

            $stuGrades[$subId] = [
                'final_grade' => round($fg, 2),
                'status' => $statusLabel,
                'teacher_name' => $teacherName
            ];

            if ($fg > 0) {
                $totalGrades += $fg;
                $gradeCount++;
            }
        }

        $genAvg = $gradeCount > 0 ? round($totalGrades / $gradeCount, 2) : 0;
        $remark = $genAvg >= 75 ? 'Passed' : ($genAvg > 0 ? 'Failed' : '—');

        $resultStudents[] = [
            'student_id' => $sid,
            'lrn' => $st['lrn'],
            'full_name' => $st['full_name'],
            'gender' => $st['gender'],
            'grades' => $stuGrades,
            'general_average' => $genAvg,
            'remark' => $remark,
            'attendance' => $attendanceIndex[(int)$sid] ?? []
        ];
    }

    $enrolledCount = count($students);
    $submittedSubjectCount = 0;
    $missingSubjectCount = 0;
    $subjectCompleteness = [];
    foreach ($expectedSubjectIds as $subjectId) {
        $subjectGradeStudents = 0;
        foreach ($students as $st) {
            $sid = (int)$st['id'];
            $gradeRow = $gradeIndex[$sid][(int)$subjectId][$quarter ?: 1] ?? null;
            $hasGrade = $gradeRow
                && !empty($gradeRow['teacher_submission_id'])
                && in_array((string)$gradeRow['status'], ['pending_adviser', 'submitted_to_adviser', 'approved', 'approved_by_adviser', 'finalized'], true);
            if ($hasGrade) {
                $subjectGradeStudents++;
            }
        }
        $isComplete = $enrolledCount > 0 && $subjectGradeStudents >= $enrolledCount;
        $subjectCompleteness[] = [
            'subject_id' => (int)$subjectId,
            'graded_students' => $subjectGradeStudents,
            'enrolled_students' => $enrolledCount,
            'complete' => $isComplete
        ];
        if ($isComplete) {
            $submittedSubjectCount++;
        } else {
            $missingSubjectCount++;
        }
    }
    $totalExpectedSubjects = count($expectedSubjectIds);
    $pendingSubjectCount = $missingSubjectCount;

    $statusSummary = [
        'total_subjects' => $totalExpectedSubjects,
        'submitted_subjects' => $submittedSubjectCount,
        'pending_subjects' => $pendingSubjectCount,
        'total_grade_rows' => count($rawGrades)
    ];

    echo json_encode([
        'success' => true,
        'section' => $section,
        'subjects' => $subjects,
        'students' => $resultStudents,
        'year_label' => $year_label,
        'quarter' => $quarter,
        'status_summary' => $statusSummary,
        'subject_completeness' => $subjectCompleteness,
        'adviser_submission' => $adviserSubmission ? array_merge($adviserSubmission, ['status' => 'submitted']) : null,
        'can_submit_to_admin' => $totalExpectedSubjects > 0 &&
                                 $pendingSubjectCount === 0 &&
                                 !$adviserSubmission
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
