<?php
header('Content-Type: application/json');

require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/auth.php';
require_once __DIR__ . '/../deadline/check_submission_lock.php';
require_once __DIR__ . '/deportment_table.php';

$teacherId = (int)($_SESSION['teacher_id'] ?? 0);
if (!$teacherId) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized.']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$sectionId = (int)($data['section_id'] ?? 0);
$ratings = is_array($data['ratings'] ?? null) ? $data['ratings'] : [];

if ($sectionId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'section_id is required.']);
    exit;
}

try {
    ensureDeportmentTable($pdo);

    $advStmt = $pdo->prepare("
        SELECT sa.academic_year_id, ay.year_label
        FROM tblsectionadviser sa
        INNER JOIN tblacademicyear ay ON ay.id = sa.academic_year_id
        WHERE sa.section_id = ? AND sa.teacher_id = ? AND ay.is_active = 1
        LIMIT 1
    ");
    $advStmt->execute([$sectionId, $teacherId]);
    $advisory = $advStmt->fetch(PDO::FETCH_ASSOC);

    if (!$advisory) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'You are not the adviser of this section.']);
        exit;
    }

    $yearId = (int)$advisory['academic_year_id'];
    $schoolYear = (string)$advisory['year_label'];
    $activeQuarter = 1;
    try {
        $qStmt = $pdo->prepare("
            SELECT quarter_number
            FROM tblquarters
            WHERE academic_year_id = ? AND is_active = 1
            ORDER BY quarter_number ASC
            LIMIT 1
        ");
        $qStmt->execute([$yearId]);
        $activeQuarter = (int)($qStmt->fetchColumn() ?: 1);
    } catch (Throwable $e) {
        $activeQuarter = 1;
    }

    checkSubmissionLock($pdo, $teacherId, $sectionId, 0, $activeQuarter, $schoolYear, 'adviser');

    $studentStmt = $pdo->prepare("
        SELECT ss.student_id
        FROM tblsectionstudent ss
        INNER JOIN tblstudents st ON st.id = ss.student_id
        WHERE ss.section_id = ? AND ss.academic_year_id = ? AND ss.is_active = 1 AND COALESCE(st.is_active, 1) = 1
    ");
    $studentStmt->execute([$sectionId, $yearId]);
    $allowedStudents = array_fill_keys(array_map('intval', $studentStmt->fetchAll(PDO::FETCH_COLUMN)), true);

    $validRatings = ['AO' => true, 'SO' => true, 'RO' => true, 'NO' => true];
    $cleanRows = [];
    foreach ($ratings as $row) {
        $studentId = (int)($row['student_id'] ?? 0);
        $statementIndex = (int)($row['statement_index'] ?? -1);
        $quarter = (int)($row['quarter'] ?? 0);
        $rating = strtoupper(trim((string)($row['rating'] ?? '')));

        if (!isset($allowedStudents[$studentId])) {
            continue;
        }
        if ($statementIndex < 0 || $statementIndex > 20 || $quarter < 1 || $quarter > 5 || !isset($validRatings[$rating])) {
            continue;
        }

        $cleanRows[] = [$studentId, $statementIndex, $quarter, $rating];
    }

    $pdo->beginTransaction();

    $delStmt = $pdo->prepare("DELETE FROM tbldeportment_records WHERE section_id = ? AND academic_year_id = ?");
    $delStmt->execute([$sectionId, $yearId]);

    if ($cleanRows) {
        $insStmt = $pdo->prepare("
            INSERT INTO tbldeportment_records
                (student_id, section_id, academic_year_id, school_year, statement_index, quarter, rating, created_by, updated_by)
            VALUES
                (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        foreach ($cleanRows as [$studentId, $statementIndex, $quarter, $rating]) {
            $insStmt->execute([$studentId, $sectionId, $yearId, $schoolYear, $statementIndex, $quarter, $rating, $teacherId, $teacherId]);
        }
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Deportment ratings saved successfully.',
        'saved_count' => count($cleanRows),
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
