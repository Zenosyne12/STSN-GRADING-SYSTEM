<?php
function ensureAttendanceTable(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS tblattendance_records (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            student_id INT NOT NULL,
            section_id INT NOT NULL,
            academic_year_id INT NOT NULL,
            month_number TINYINT NOT NULL,
            month_name VARCHAR(20) NOT NULL,
            school_year VARCHAR(20) NOT NULL,
            school_days DECIMAL(5,2) NOT NULL DEFAULT 0,
            days_present DECIMAL(5,2) NOT NULL DEFAULT 0,
            days_absent DECIMAL(5,2) NOT NULL DEFAULT 0,
            source_filename VARCHAR(255) DEFAULT NULL,
            imported_by INT DEFAULT NULL,
            imported_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_attendance_student_month (student_id, section_id, academic_year_id, month_number),
            KEY idx_attendance_section_year (section_id, academic_year_id),
            KEY idx_attendance_student (student_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
}
?>
