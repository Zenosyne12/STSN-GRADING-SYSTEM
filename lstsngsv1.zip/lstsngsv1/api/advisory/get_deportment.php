<?php
header('Content-Type: application/json');

require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/auth.php';
require_once __DIR__ . '/deportment_table.php';

$teacherId = (int)($_SESSION['teacher_id'] ?? 0);
if (!$teacherId) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized.']);
    exit;
}

$sectionId = isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0;
if ($sectionId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'section_id is required.']);
    exit;
}

try {
    ensureDeportmentTable($pdo);

    $advStmt = $pdo->prepare("
        SELECT sa.academic_year_id, ay.year_label
        FROM tblsectionadviser sa
        INNER JOIN tblacademicyear ay ON ay.id = sa.academic_year_id
        WHERE sa.section_id = ? AND sa.teacher_id = ? AND ay.is_active = 1
        LIMIT 1
    ");
    $advStmt->execute([$sectionId, $teacherId]);
    $advisory = $advStmt->fetch(PDO::FETCH_ASSOC);

    if (!$advisory) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'You are not the adviser of this section.']);
        exit;
    }

    $stmt = $pdo->prepare("
        SELECT student_id, statement_index, quarter, rating
        FROM tbldeportment_records
        WHERE section_id = ? AND academic_year_id = ?
        ORDER BY student_id, statement_index, quarter
    ");
    $stmt->execute([$sectionId, (int)$advisory['academic_year_id']]);

    $records = [];
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $studentId = (int)$row['student_id'];
        $statement = (int)$row['statement_index'];
        $quarter = (int)$row['quarter'];
        $records[$studentId][$statement][$quarter] = $row['rating'];
    }

    echo json_encode([
        'success' => true,
        'records' => $records,
        'school_year' => $advisory['year_label'],
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
