<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/auth.php';
require_once __DIR__ . '/../deadline/check_submission_lock.php';
require_once __DIR__ . '/../shared/grade_workflow.php';
require_once __DIR__ . '/../../includes/workflow_engine.php';

$teacher_id = $_SESSION['teacher_id'] ?? 0;
if (!$teacher_id) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized.']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$repairExisting = filter_var($data['repair_existing'] ?? false, FILTER_VALIDATE_BOOLEAN);

$section_id = intval($data['section_id'] ?? 0);
$quarter    = intval($data['quarter'] ?? 0);
if (!$section_id || !$quarter) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'section_id and quarter are required.']);
    exit;
}

try {
    ensureGradeWorkflowSchema($pdo);

    $advStmt = $pdo->prepare("
        SELECT sa.id, ay.id AS year_id, ay.year_label
        FROM tblsectionadviser sa
        JOIN tblacademicyear ay ON ay.id = sa.academic_year_id
        WHERE sa.section_id = ? AND sa.teacher_id = ? AND ay.is_active = 1
        LIMIT 1
    ");
    $advStmt->execute([$section_id, $teacher_id]);
    $adviser = $advStmt->fetch(PDO::FETCH_ASSOC);

    if (!$adviser) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'You are not the adviser of this section.']);
        exit;
    }

    $year_id = $adviser['year_id'];
    $school_year = $adviser['year_label'];

    checkSubmissionLock($pdo, $teacher_id, $section_id, 0, $quarter, $school_year, 'adviser');

    $expectedStmt = $pdo->prepare("
        SELECT DISTINCT subject_id
        FROM tblschedule
        WHERE section_id = ? AND school_year = ? AND is_active = 1
    ");
    $expectedStmt->execute([$section_id, $school_year]);
    $expectedSubjectIds = array_map('intval', array_column($expectedStmt->fetchAll(PDO::FETCH_ASSOC), 'subject_id'));
    if (empty($expectedSubjectIds)) {
        echo json_encode(['success' => false, 'message' => 'No scheduled subjects found for this section.']);
        exit;
    }

    $studentStmt = $pdo->prepare("
        SELECT COUNT(DISTINCT ss.student_id)
        FROM tblsectionstudent ss
        JOIN tblstudents st ON st.id = ss.student_id
        WHERE ss.section_id = ? AND ss.academic_year_id = ? AND ss.is_active = 1 AND st.is_active = 1
    ");
    $studentStmt->execute([$section_id, $year_id]);
    $enrolledCount = (int)$studentStmt->fetchColumn();
    if ($enrolledCount <= 0) {
        echo json_encode(['success' => false, 'message' => 'No active students found in this section.']);
        exit;
    }

    $checkSubjectStmt = $pdo->prepare("
        SELECT COUNT(DISTINCT g.student_id) AS grade_students
        FROM tblgrades g
        INNER JOIN tblteacher_submissions ts
            ON ts.teacher_id = g.teacher_id
           AND ts.section_id = g.section_id
           AND ts.subject_id = g.subject_id
           AND ts.quarter = g.quarter
           AND ts.school_year = ?
           AND ts.submitted_at IS NOT NULL
        WHERE g.section_id = ? AND g.subject_id = ? AND g.quarter = ? AND g.academic_year_id = ?
          AND " . reviewableGradeStatusSql('g') . "
    ");
    $missingSubjectIds = [];
    foreach ($expectedSubjectIds as $subjectId) {
        $checkSubjectStmt->execute([$school_year, $section_id, $subjectId, $quarter, $year_id]);
        $gradeStudents = (int)$checkSubjectStmt->fetchColumn();
        if ($gradeStudents < $enrolledCount) {
            $missingSubjectIds[] = (int)$subjectId;
        }
    }
    if ($missingSubjectIds) {
        echo json_encode([
            'success' => false,
            'message' => 'Cannot submit yet. Some subjects still have missing/incomplete student grades.',
            'missing_subject_count' => count($missingSubjectIds)
        ]);
        exit;
    }

    $termStmt = $pdo->prepare("
        SELECT id
        FROM tblconfig_terms
        WHERE academic_year_id = ? AND term_number = ?
        LIMIT 1
    ");
    $termStmt->execute([$year_id, $quarter]);
    $termId = (int)$termStmt->fetchColumn();
    if ($termId <= 0) {
        echo json_encode(['success' => false, 'message' => 'No configured approval term was found for this grading period.']);
        exit;
    }

    $gradeLevelStmt = $pdo->prepare("SELECT grade_level_id FROM tblsection WHERE id = ? LIMIT 1");
    $gradeLevelStmt->execute([$section_id]);
    $gradeLevelId = (int)$gradeLevelStmt->fetchColumn();
    $template = getActiveTemplate($pdo, $gradeLevelId, (int)$year_id);
    if (!$template || empty($template['template']['id'])) {
        echo json_encode(['success' => false, 'message' => 'No active approval workflow is configured. The class record was not submitted.']);
        exit;
    }

    $stepOrders = array_map('intval', array_column($template['steps'] ?? [], 'step_order'));
    if (!in_array(2, $stepOrders, true)) {
        echo json_encode(['success' => false, 'message' => 'The configured workflow has no Adviser approval step. The class record was not submitted.']);
        exit;
    }

    $pdo->beginTransaction();

    $subjectTeachersStmt = $pdo->prepare("
        SELECT ts.subject_id, ts.teacher_id
        FROM tblteacher_submissions ts
        WHERE ts.section_id = ?
          AND ts.quarter = ?
          AND ts.school_year = ?
          AND ts.submitted_at IS NOT NULL
        ORDER BY ts.submitted_at DESC, ts.id DESC
    ");
    $subjectTeachersStmt->execute([$section_id, $quarter, $school_year]);
    $subjectTeachers = [];
    foreach ($subjectTeachersStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $subjectId = (int)$row['subject_id'];
        if (!isset($subjectTeachers[$subjectId])) {
            $subjectTeachers[$subjectId] = (int)$row['teacher_id'];
        }
    }

    $positionStmt = $pdo->prepare("SELECT position FROM tblteacher WHERE id = ? LIMIT 1");
    $positionStmt->execute([$teacher_id]);
    $actorPosition = (string)($positionStmt->fetchColumn() ?: 'Adviser');
    $actorRoleId = (int)($_SESSION['role_id'] ?? 2);
    $pendingApprovalPositions = [];
    $allWorkflowsComplete = true;
    $approvalRoutingChanged = false;

    foreach ($expectedSubjectIds as $subjectId) {
        $subjectTeacherId = $subjectTeachers[$subjectId] ?? 0;
        if ($subjectTeacherId <= 0) {
            throw new RuntimeException("No submitted subject-teacher record was found for subject {$subjectId}.");
        }

        $workflowStmt = $pdo->prepare("
            SELECT id, status, current_step_order
            FROM tblworkflow_instance
            WHERE section_id = ?
              AND subject_id = ?
              AND term_id = ?
              AND academic_year_id = ?
            ORDER BY id DESC
            LIMIT 1
            FOR UPDATE
        ");
        $workflowStmt->execute([$section_id, $subjectId, $termId, $year_id]);
        $workflow = $workflowStmt->fetch(PDO::FETCH_ASSOC);

        if (!$workflow) {
            $started = startWorkflow($pdo, [
                'section_id' => $section_id,
                'subject_id' => $subjectId,
                'term_id' => $termId,
                'academic_year_id' => (int)$year_id,
                'teacher_id' => $subjectTeacherId,
                'template_id' => (int)$template['template']['id'],
                'actor_role_id' => 2,
            ]);
            if (empty($started['success']) || empty($started['instance_id'])) {
                throw new RuntimeException($started['message'] ?? "Unable to start approval for subject {$subjectId}.");
            }
            $approvalRoutingChanged = true;
            $workflow = [
                'id' => (int)$started['instance_id'],
                'status' => (string)($started['status'] ?? 'IN_PROGRESS'),
                'current_step_order' => (int)($started['next_step']['step_order'] ?? 2),
            ];
        }

        if ((string)$workflow['status'] === 'REJECTED') {
            throw new RuntimeException("Subject {$subjectId} was returned. The teacher must resubmit it before the class record can proceed.");
        }
        if ((string)$workflow['status'] === 'LOCKED') {
            throw new RuntimeException("Subject {$subjectId} has a locked approval workflow and cannot proceed.");
        }

        if ((string)$workflow['status'] === 'IN_PROGRESS' && (int)$workflow['current_step_order'] === 2) {
            $adviserApproval = advanceWorkflow($pdo, [
                'instance_id' => (int)$workflow['id'],
                'actor_user_id' => (int)$teacher_id,
                'actor_role_id' => $actorRoleId,
                'actor_position' => $actorPosition,
                'action' => 'APPROVED',
                'remarks' => 'Adviser submitted the complete class record.',
            ]);
            if (empty($adviserApproval['success'])) {
                throw new RuntimeException($adviserApproval['message'] ?? "Unable to record Adviser approval for subject {$subjectId}.");
            }
            $approvalRoutingChanged = true;
        }

        $workflowStateStmt = $pdo->prepare("
            SELECT status
            FROM tblworkflow_instance
            WHERE id = ?
            LIMIT 1
        ");
        $workflowStateStmt->execute([(int)$workflow['id']]);
        $currentWorkflowStatus = (string)$workflowStateStmt->fetchColumn();
        if ($currentWorkflowStatus !== 'COMPLETED') {
            $allWorkflowsComplete = false;
        }
        if ($currentWorkflowStatus === 'IN_PROGRESS') {
            $nextStep = getCurrentStep($pdo, (int)$workflow['id']);
            if (!empty($nextStep['required_position'])) {
                $pendingApprovalPositions[(string)$nextStep['required_position']] = true;
            }
        }
    }

    $existingStmt = $pdo->prepare("
        SELECT id, status
        FROM tbladviser_submissions
        WHERE section_id = ? AND quarter = ? AND school_year = ?
        LIMIT 1
        FOR UPDATE
    ");
    $existingStmt->execute([$section_id, $quarter, $school_year]);
    $existing = $existingStmt->fetch(PDO::FETCH_ASSOC);

    if ($repairExisting && (!$existing || (string)$existing['status'] !== 'pending')) {
        $pdo->rollBack();
        http_response_code(409);
        echo json_encode(['success' => false, 'message' => 'There is no pending class-record submission to repair.']);
        exit;
    }

    if ($existing) {
        if (in_array((string)$existing['status'], ['approved', 'finalized'], true)) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'message' => 'This class record has already passed approval and is published.']);
            exit;
        }
        if (!$repairExisting) {
            $updStmt = $pdo->prepare("
                UPDATE tbladviser_submissions
                SET teacher_id = :teacher_id, status = 'pending', submitted_at = NOW(), reviewed_at = NULL, updated_at = NOW()
                WHERE id = :id
            ");
            $updStmt->execute([
                ':teacher_id' => $teacher_id,
                ':id' => (int)$existing['id']
            ]);
        }
    } else {
        $insStmt = $pdo->prepare("
            INSERT INTO tbladviser_submissions
                (teacher_id, section_id, quarter, school_year, submitted_at, status, reviewed_at, created_at, updated_at)
            VALUES
                (:teacher_id, :section_id, :quarter, :school_year, NOW(), 'pending', NULL, NOW(), NOW())
        ");
        $insStmt->execute([
            ':teacher_id' => $teacher_id,
            ':section_id' => $section_id,
            ':quarter' => $quarter,
            ':school_year' => $school_year
        ]);
    }

    if ($allWorkflowsComplete) {
        $publishStmt = $pdo->prepare("
            UPDATE tbladviser_submissions
            SET status = 'approved', reviewed_at = NOW(), updated_at = NOW()
            WHERE section_id = ? AND quarter = ? AND school_year = ? AND status = 'pending'
        ");
        $publishStmt->execute([$section_id, $quarter, $school_year]);
    }

    $pdo->commit();

    $notificationsSent = 0;
    $notificationWarning = null;
    try {
        if ($approvalRoutingChanged) {
            $contextStmt = $pdo->prepare("
                SELECT s.section_name, gl.grade_level_name, CONCAT_WS(' ', t.fname, t.lname) AS adviser_name
                FROM tblsection s
                JOIN tblgradelevel gl ON gl.id = s.grade_level_id
                LEFT JOIN tblteacher t ON t.id = ?
                WHERE s.id = ?
                LIMIT 1
            ");
            $contextStmt->execute([$teacher_id, $section_id]);
            $context = $contextStmt->fetch(PDO::FETCH_ASSOC) ?: [];

            $termLabelStmt = $pdo->prepare("
                SELECT term_label
                FROM tblconfig_terms
                WHERE academic_year_id = ? AND term_number = ?
                LIMIT 1
            ");
            $termLabelStmt->execute([$year_id, $quarter]);
            $termLabel = (string)($termLabelStmt->fetchColumn() ?: ('Term ' . $quarter));

            $notificationStmt = $pdo->prepare("
                INSERT INTO system_notifications (title, message, type, created_at)
                VALUES (?, ?, ?, NOW())
            ");
            $message = sprintf(
                '%s submitted grades for %s - %s (%s, S.Y. %s). %s',
                trim((string)($context['adviser_name'] ?? 'The adviser')) ?: 'The adviser',
                (string)($context['grade_level_name'] ?? 'Section'),
                (string)($context['section_name'] ?? ''),
                $termLabel,
                $school_year,
                $allWorkflowsComplete ? 'The grades are published.' : 'Awaiting approval.'
            );
            foreach (array_keys($pendingApprovalPositions) as $pendingPosition) {
                if (strcasecmp($pendingPosition, 'Registrar') === 0) {
                    $recipientStmt = $pdo->query("SELECT id FROM tblusers WHERE role_id = 1");
                    $recipients = array_map('intval', $recipientStmt->fetchAll(PDO::FETCH_COLUMN));
                    $typePrefix = 'admin:';
                } else {
                    $recipientStmt = $pdo->prepare("
                        SELECT id
                        FROM tblteacher
                        WHERE is_active = 1 AND LOWER(position) = LOWER(?)
                    ");
                    $recipientStmt->execute([$pendingPosition]);
                    $recipients = array_map('intval', $recipientStmt->fetchAll(PDO::FETCH_COLUMN));
                    $typePrefix = 'teacher:';
                }
                foreach ($recipients as $recipientId) {
                    $notificationStmt->execute([
                        'Class grades awaiting approval',
                        $message,
                        $typePrefix . $recipientId,
                    ]);
                    $notificationsSent++;
                }
            }
            if (!$allWorkflowsComplete && $notificationsSent === 0) {
                $notificationWarning = 'Submission succeeded, but no next-step approver account was found to notify.';
            }
        }
    } catch (Throwable $notificationError) {
        $notificationWarning = 'Submission succeeded, but the next approver notification could not be sent.';
        error_log('[submit_to_admin notification error] ' . $notificationError->getMessage());
    }

    $responseMessage = $allWorkflowsComplete
        ? 'Grades submitted successfully. All required approvals are complete and the report is published.'
        : ($repairExisting
            ? 'The existing submission was checked and its approval routing has been repaired.'
            : 'Grades submitted successfully. Adviser approval was recorded; the class record is now awaiting the next approval step.');
    if ($notificationWarning !== null) {
        $responseMessage .= ' ' . $notificationWarning;
    }

    echo json_encode([
        'success' => true,
        'message' => $responseMessage,
        'approval_complete' => $allWorkflowsComplete,
        'approval_routing_changed' => $approvalRoutingChanged,
        'pending_approval_positions' => array_keys($pendingApprovalPositions),
        'notifications_sent' => $notificationsSent,
        'section_id' => $section_id,
        'quarter' => $quarter,
        'school_year' => $school_year
    ]);

} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
