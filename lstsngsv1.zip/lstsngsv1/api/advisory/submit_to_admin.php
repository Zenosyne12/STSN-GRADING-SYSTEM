<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/auth.php';
require_once __DIR__ . '/../deadline/check_submission_lock.php';
require_once __DIR__ . '/../shared/grade_workflow.php';

$teacher_id = $_SESSION['teacher_id'] ?? 0;
if (!$teacher_id) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized.']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$section_id = intval($data['section_id'] ?? 0);
$quarter    = intval($data['quarter'] ?? 0);
if (!$section_id || !$quarter) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'section_id and quarter are required.']);
    exit;
}

try {
    ensureGradeWorkflowSchema($pdo);

    $advStmt = $pdo->prepare("
        SELECT sa.id, ay.id AS year_id, ay.year_label
        FROM tblsectionadviser sa
        JOIN tblacademicyear ay ON ay.id = sa.academic_year_id
        WHERE sa.section_id = ? AND sa.teacher_id = ? AND ay.is_active = 1
        LIMIT 1
    ");
    $advStmt->execute([$section_id, $teacher_id]);
    $adviser = $advStmt->fetch(PDO::FETCH_ASSOC);

    if (!$adviser) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'You are not the adviser of this section.']);
        exit;
    }

    $year_id = $adviser['year_id'];
    $school_year = $adviser['year_label'];

    checkSubmissionLock($pdo, $teacher_id, $section_id, 0, $quarter, $school_year, 'adviser');

    $expectedStmt = $pdo->prepare("
        SELECT DISTINCT subject_id
        FROM tblschedule
        WHERE section_id = ? AND is_active = 1
    ");
    $expectedStmt->execute([$section_id]);
    $expectedSubjectIds = array_map('intval', array_column($expectedStmt->fetchAll(PDO::FETCH_ASSOC), 'subject_id'));
    if (empty($expectedSubjectIds)) {
        echo json_encode(['success' => false, 'message' => 'No scheduled subjects found for this section.']);
        exit;
    }

    $studentStmt = $pdo->prepare("
        SELECT COUNT(DISTINCT ss.student_id)
        FROM tblsectionstudent ss
        JOIN tblstudents st ON st.id = ss.student_id
        WHERE ss.section_id = ? AND ss.academic_year_id = ? AND ss.is_active = 1 AND st.is_active = 1
    ");
    $studentStmt->execute([$section_id, $year_id]);
    $enrolledCount = (int)$studentStmt->fetchColumn();
    if ($enrolledCount <= 0) {
        echo json_encode(['success' => false, 'message' => 'No active students found in this section.']);
        exit;
    }

    $checkSubjectStmt = $pdo->prepare("
        SELECT COUNT(DISTINCT g.student_id) AS grade_students
        FROM tblgrades g
        INNER JOIN tblteacher_submissions ts
            ON ts.teacher_id = g.teacher_id
           AND ts.section_id = g.section_id
           AND ts.subject_id = g.subject_id
           AND ts.quarter = g.quarter
           AND ts.school_year = ?
        WHERE g.section_id = ? AND g.subject_id = ? AND g.quarter = ? AND g.academic_year_id = ?
          AND " . reviewableGradeStatusSql('g') . "
    ");
    $missingSubjectIds = [];
    foreach ($expectedSubjectIds as $subjectId) {
        $checkSubjectStmt->execute([$school_year, $section_id, $subjectId, $quarter, $year_id]);
        $gradeStudents = (int)$checkSubjectStmt->fetchColumn();
        if ($gradeStudents < $enrolledCount) {
            $missingSubjectIds[] = (int)$subjectId;
        }
    }
    if ($missingSubjectIds) {
        echo json_encode([
            'success' => false,
            'message' => 'Cannot submit yet. Some subjects still have missing/incomplete student grades.',
            'missing_subject_count' => count($missingSubjectIds)
        ]);
        exit;
    }

    $pdo->beginTransaction();

    $existingStmt = $pdo->prepare("
        SELECT id
        FROM tbladviser_submissions
        WHERE section_id = ? AND quarter = ? AND school_year = ?
        LIMIT 1
    ");
    $existingStmt->execute([$section_id, $quarter, $school_year]);
    $existing = $existingStmt->fetch(PDO::FETCH_ASSOC);

    if ($existing) {
        $updStmt = $pdo->prepare("
            UPDATE tbladviser_submissions
            SET teacher_id = :teacher_id, status = 'finalized', submitted_at = NOW(), reviewed_at = NOW(), updated_at = NOW()
            WHERE id = :id
        ");
        $updStmt->execute([
            ':teacher_id' => $teacher_id,
            ':id' => (int)$existing['id']
        ]);
    } else {
        $insStmt = $pdo->prepare("
            INSERT INTO tbladviser_submissions
                (teacher_id, section_id, quarter, school_year, submitted_at, status, reviewed_at, created_at, updated_at)
            VALUES
                (:teacher_id, :section_id, :quarter, :school_year, NOW(), 'finalized', NOW(), NOW(), NOW())
        ");
        $insStmt->execute([
            ':teacher_id' => $teacher_id,
            ':section_id' => $section_id,
            ':quarter' => $quarter,
            ':school_year' => $school_year
        ]);
    }

    $subjectPlaceholders = implode(',', array_fill(0, count($expectedSubjectIds), '?'));
    $approveStmt = $pdo->prepare("
        UPDATE tblgrades g
        INNER JOIN tblteacher_submissions ts
            ON ts.teacher_id = g.teacher_id
           AND ts.section_id = g.section_id
           AND ts.subject_id = g.subject_id
           AND ts.quarter = g.quarter
           AND ts.school_year = ?
        SET g.status = 'finalized',
            g.updated_at = NOW()
        WHERE g.section_id = ?
          AND g.quarter = ?
          AND g.academic_year_id = ?
          AND g.subject_id IN ($subjectPlaceholders)
          AND " . reviewableGradeStatusSql('g') . "
    ");
    $approveStmt->execute(array_merge(
        [$school_year, $section_id, $quarter, $year_id],
        $expectedSubjectIds
    ));
    $approvedCount = $approveStmt->rowCount();

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Grades submitted to admin successfully.',
        'approved_count' => $approvedCount,
        'section_id' => $section_id,
        'quarter' => $quarter,
        'school_year' => $school_year
    ]);

} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
