<?php
function ensureDeportmentTable(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS tbldeportment_records (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            student_id INT NOT NULL,
            section_id INT NOT NULL,
            academic_year_id INT NOT NULL,
            school_year VARCHAR(20) NOT NULL,
            statement_index TINYINT NOT NULL,
            quarter TINYINT NOT NULL,
            rating VARCHAR(2) NOT NULL,
            created_by INT DEFAULT NULL,
            updated_by INT DEFAULT NULL,
            created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_deportment_rating (student_id, section_id, academic_year_id, statement_index, quarter),
            KEY idx_deportment_section_year (section_id, academic_year_id),
            KEY idx_deportment_student (student_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
}
?>
