<?php
header('Content-Type: application/json');

require_once __DIR__ . '/../shared/db_connect.php';
require_once __DIR__ . '/../shared/auth.php';
require_once __DIR__ . '/attendance_table.php';


require_once __DIR__ . '/../deadline/check_submission_lock.php';

$teacher_id = $_SESSION['teacher_id'] ?? $_SESSION['reference_id'] ?? 0;
if (!$teacher_id) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized.']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid JSON payload.']);
    exit;
}

$section_id = (int)($data['section_id'] ?? 0);
$month_number = (int)($data['month_number'] ?? 0);
$month_name = trim((string)($data['month_name'] ?? ''));
$school_year = trim((string)($data['school_year'] ?? ''));
$school_days = (float)($data['school_days'] ?? 0);
$filename = trim((string)($data['filename'] ?? ''));
$records = $data['records'] ?? [];

if (!$section_id || $month_number < 1 || $month_number > 12 || !$month_name || !$school_year || !is_array($records)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Section, month, school year, and records are required.']);
    exit;
}

try {
    ensureAttendanceTable($pdo);

    $advStmt = $pdo->prepare("
        SELECT sa.id, ay.id AS year_id, ay.year_label
        FROM tblsectionadviser sa
        JOIN tblacademicyear ay ON ay.id = sa.academic_year_id
        WHERE sa.section_id = ? AND sa.teacher_id = ? AND ay.is_active = 1
        LIMIT 1
    ");
    $advStmt->execute([$section_id, $teacher_id]);
    $adviser = $advStmt->fetch(PDO::FETCH_ASSOC);

    if (!$adviser) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'You are not the adviser of this section.']);
        exit;
    }

    $year_id = (int)$adviser['year_id'];
    $active_year_label = (string)$adviser['year_label'];
    if ($school_year !== $active_year_label) {
        echo json_encode([
            'success' => false,
            'message' => "The file school year ({$school_year}) does not match the active school year ({$active_year_label})."
        ]);
        exit;
    }

    
    $qtrStmt = $pdo->query("SELECT term_number FROM tblconfig_terms WHERE is_active = 1 AND is_closed = 0 LIMIT 1");
    $quarter = $qtrStmt ? (int)$qtrStmt->fetchColumn() : 0;
    
    
    checkSubmissionLock($pdo, (int)$teacher_id, $section_id, 0, $quarter, $school_year, 'adviser');

    $studentStmt = $pdo->prepare("
        SELECT st.id
        FROM tblsectionstudent ss
        JOIN tblstudents st ON st.id = ss.student_id
        WHERE ss.section_id = ? AND ss.academic_year_id = ? AND ss.is_active = 1 AND st.is_active = 1
    ");
    $studentStmt->execute([$section_id, $year_id]);
    $validStudentIds = array_flip(array_map('intval', array_column($studentStmt->fetchAll(PDO::FETCH_ASSOC), 'id')));

    $clean = [];
    $skipped = [];
    foreach ($records as $record) {
        $studentId = (int)($record['student_id'] ?? 0);
        if (!$studentId || !isset($validStudentIds[$studentId])) {
            $skipped[] = [
                'name' => $record['learner_name'] ?? '',
                'reason' => 'Student was not matched to this advisory section.'
            ];
            continue;
        }

        $present = max(0, (float)($record['days_present'] ?? 0));
        $absent = max(0, (float)($record['days_absent'] ?? 0));
        $recordSchoolDays = max($school_days, $present + $absent);

        $clean[$studentId] = [
            'student_id' => $studentId,
            'school_days' => $recordSchoolDays,
            'days_present' => $present,
            'days_absent' => $absent
        ];
    }

    if (!$clean) {
        echo json_encode(['success' => false, 'message' => 'No matched attendance records to import.', 'skipped' => $skipped]);
        exit;
    }

    $pdo->beginTransaction();
    $stmt = $pdo->prepare("
        INSERT INTO tblattendance_records
            (student_id, section_id, academic_year_id, month_number, month_name, school_year,
             school_days, days_present, days_absent, source_filename, imported_by, imported_at, created_at, updated_at)
        VALUES
            (:student_id, :section_id, :academic_year_id, :month_number, :month_name, :school_year,
             :school_days, :days_present, :days_absent, :source_filename, :imported_by, NOW(), NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            month_name = VALUES(month_name),
            school_year = VALUES(school_year),
            school_days = VALUES(school_days),
            days_present = VALUES(days_present),
            days_absent = VALUES(days_absent),
            source_filename = VALUES(source_filename),
            imported_by = VALUES(imported_by),
            imported_at = NOW(),
            updated_at = NOW()
    ");

    foreach ($clean as $row) {
        $stmt->execute([
            ':student_id' => $row['student_id'],
            ':section_id' => $section_id,
            ':academic_year_id' => $year_id,
            ':month_number' => $month_number,
            ':month_name' => $month_name,
            ':school_year' => $school_year,
            ':school_days' => $row['school_days'],
            ':days_present' => $row['days_present'],
            ':days_absent' => $row['days_absent'],
            ':source_filename' => $filename ?: null,
            ':imported_by' => $teacher_id
        ]);
    }
    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Attendance imported successfully.',
        'imported_count' => count($clean),
        'skipped_count' => count($skipped),
        'skipped' => $skipped,
        'month_name' => $month_name,
        'school_days' => $school_days
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>