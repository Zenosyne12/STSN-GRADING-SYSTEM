<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/api/shared/db_connect.php';
require_once __DIR__ . '/includes/archive_engine.php';
ensureProfileArchiveSchema($pdo);

$requestedYear = (string) ($_GET['year_id'] ?? '');
$selectedYear = null;

if (ctype_digit($requestedYear) && (int) $requestedYear > 0) {
    try {
        $stmt = $pdo->prepare("
            SELECT
                ay.id,
                ay.year_label,
                ay.is_active,
                ay.archived_at,
                ay.created_at,
                (
                    SELECT COUNT(*)
                    FROM (
                        SELECT student_id, academic_year_id FROM tblsectionstudent
                        UNION
                        SELECT student_id, academic_year_id FROM tblenrollment
                        UNION
                        SELECT student_id, academic_year_id FROM tblstudent_archive
                    ) AS year_students
                    WHERE year_students.academic_year_id = ay.id
                ) AS students,
                (SELECT COUNT(DISTINCT ss.section_id) FROM tblsectionstudent ss WHERE ss.academic_year_id = ay.id) AS sections,
                (SELECT COUNT(DISTINCT sad.teacher_id) FROM tblsectionadviser sad WHERE sad.academic_year_id = ay.id) AS teachers,
                (SELECT COUNT(*) FROM tblgrades g WHERE g.academic_year_id = ay.id) AS grade_records,
                (SELECT COUNT(DISTINCT subj.id) FROM tblsubjects subj WHERE subj.academic_year_id = ay.id) AS subjects
            FROM tblacademicyear ay
            WHERE ay.id = ?
            LIMIT 1
        ");
        $stmt->execute([(int) $requestedYear]);
        $selectedYear = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) {
        error_log('[historical_selection] Failed to load selected academic year: ' . $e->getMessage());
        $selectedYear = null;
    }
}

if (!$selectedYear && $requestedYear === '') {
    try {
        $stmt = $pdo->query("
            SELECT
                ay.id,
                ay.year_label,
                ay.is_active,
                ay.archived_at,
                ay.created_at,
                (
                    SELECT COUNT(*)
                    FROM (
                        SELECT student_id, academic_year_id FROM tblsectionstudent
                        UNION
                        SELECT student_id, academic_year_id FROM tblenrollment
                        UNION
                        SELECT student_id, academic_year_id FROM tblstudent_archive
                    ) AS year_students
                    WHERE year_students.academic_year_id = ay.id
                ) AS students,
                (SELECT COUNT(DISTINCT ss.section_id) FROM tblsectionstudent ss WHERE ss.academic_year_id = ay.id) AS sections,
                (SELECT COUNT(DISTINCT sad.teacher_id) FROM tblsectionadviser sad WHERE sad.academic_year_id = ay.id) AS teachers,
                (SELECT COUNT(*) FROM tblgrades g WHERE g.academic_year_id = ay.id) AS grade_records,
                (SELECT COUNT(DISTINCT subj.id) FROM tblsubjects subj WHERE subj.academic_year_id = ay.id) AS subjects
            FROM tblacademicyear ay
            WHERE ay.is_active = 1
            LIMIT 1
        ");
        $selectedYear = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) {
        error_log('[historical_selection] Failed to load active academic year: ' . $e->getMessage());
        $selectedYear = null;
    }
}

if (!$selectedYear) {
    header('Location: historical_records.php');
    exit;
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>STSN Grading System | <?= htmlspecialchars($selectedYear['year_label']) ?> Archive</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="./css/historical-records.css">

    <style>
        /* ============================================================
           DARK MODE OVERRIDES for Academic Year selection page
           ============================================================ */
        :root,
        [data-bs-theme="light"] {
            --hs-card-bg: #ffffff;
            --hs-card-soft: #fafcff;
            --hs-border: #dce8f8;
            --hs-border-soft: #e8f0fb;
            --hs-text: #213a5e;
            --hs-text-strong: #132f62;
            --hs-text-muted: #7a93b8;
            --hs-text-dim: #9ab0c8;
            --hs-shadow: rgba(18, 72, 168, 0.06);

            --hs-icon-blue-bg: #eef4ff;
            --hs-icon-blue-text: #1248a8;
            --hs-icon-green-bg: #e8fbf1;
            --hs-icon-green-text: #0f6c45;
            --hs-icon-purple-bg: #f3ebff;
            --hs-icon-purple-text: #6a1ea8;
            --hs-icon-yellow-bg: #fff7e5;
            --hs-icon-yellow-text: #a86a00;

            --hs-action-btn-bg: linear-gradient(130deg, #1a6ef5, #1248a8);
            --hs-action-btn-text: #ffffff;
        }

        [data-bs-theme="dark"] {
            --hs-card-bg: #2D2D2D;
            --hs-card-soft: #262626;
            --hs-border: #3a3a3a;
            --hs-border-soft: #3a3a3a;
            --hs-text: #e4e6e8;
            --hs-text-strong: #ffffff;
            --hs-text-muted: #adb5bd;
            --hs-text-dim: #8b939a;
            --hs-shadow: rgba(0, 0, 0, 0.35);

            --hs-icon-blue-bg: #1e2a3d;
            --hs-icon-blue-text: #8ab4f8;
            --hs-icon-green-bg: #17351f;
            --hs-icon-green-text: #6ee7a0;
            --hs-icon-purple-bg: #2d1e42;
            --hs-icon-purple-text: #c4b5fd;
            --hs-icon-yellow-bg: #3a2e13;
            --hs-icon-yellow-text: #f5c56b;

            --hs-action-btn-bg: linear-gradient(130deg, #1a6ef5, #1248a8);
            --hs-action-btn-text: #ffffff;
        }

        /* Text color only — no background override on body */
        [data-bs-theme="dark"] .hr-archive-page {
            color: var(--hs-text);
        }

        /* Page header */
        [data-bs-theme="dark"] .page-header {
            background: linear-gradient(130deg, #0f3573 0%, #0f4fb8 100%) !important;
            color: #ffffff !important;
        }
        [data-bs-theme="dark"] .page-header h3,
        [data-bs-theme="dark"] .page-header p {
            color: #ffffff !important;
        }

        /* Breadcrumb */
        [data-bs-theme="dark"] .breadcrumb,
        [data-bs-theme="dark"] .breadcrumb-wrapper,
        [data-bs-theme="dark"] .hr-breadcrumb {
            background: var(--hs-card-bg) !important;
            border-color: var(--hs-border) !important;
            color: var(--hs-text) !important;
        }
        [data-bs-theme="dark"] .breadcrumb a,
        [data-bs-theme="dark"] .breadcrumb-item a {
            color: #8ab4f8 !important;
        }
        [data-bs-theme="dark"] .breadcrumb-item.active,
        [data-bs-theme="dark"] .breadcrumb-item + .breadcrumb-item::before {
            color: var(--hs-text-muted) !important;
        }

        /* Metric cards */
        [data-bs-theme="dark"] .hr-year-metrics {
            color: var(--hs-text) !important;
        }
        [data-bs-theme="dark"] .hr-year-metric {
            background: var(--hs-card-bg) !important;
            border: 1px solid var(--hs-border) !important;
            color: var(--hs-text) !important;
            box-shadow: 0 2px 12px var(--hs-shadow) !important;
        }
        [data-bs-theme="dark"] .hr-year-metric strong {
            color: var(--hs-text-strong) !important;
        }
        [data-bs-theme="dark"] .hr-year-metric span {
            color: var(--hs-text-muted) !important;
        }
        [data-bs-theme="dark"] .hr-year-metric i {
            background: var(--hs-icon-blue-bg) !important;
            color: var(--hs-icon-blue-text) !important;
        }
        [data-bs-theme="dark"] .hr-year-metric .student-icon {
            background: var(--hs-icon-blue-bg) !important;
            color: var(--hs-icon-blue-text) !important;
        }
        [data-bs-theme="dark"] .hr-year-metric .section-icon {
            background: var(--hs-icon-green-bg) !important;
            color: var(--hs-icon-green-text) !important;
        }
        [data-bs-theme="dark"] .hr-year-metric .teacher-icon {
            background: var(--hs-icon-purple-bg) !important;
            color: var(--hs-icon-purple-text) !important;
        }
        [data-bs-theme="dark"] .hr-year-metric .document-icon {
            background: var(--hs-icon-yellow-bg) !important;
            color: var(--hs-icon-yellow-text) !important;
        }

        /* Archive action cards (Student / Teacher / Document) */
        [data-bs-theme="dark"] .hr-archive-action-card {
            background: var(--hs-card-bg) !important;
            border: 1px solid var(--hs-border) !important;
            color: var(--hs-text) !important;
            box-shadow: 0 2px 12px var(--hs-shadow) !important;
        }
        [data-bs-theme="dark"] .hr-archive-action-card strong {
            color: var(--hs-text-strong) !important;
        }
        [data-bs-theme="dark"] .hr-archive-action-card span {
            color: var(--hs-text-muted) !important;
        }
        [data-bs-theme="dark"] .hr-archive-action-card i {
            color: var(--hs-icon-blue-text) !important;
        }
        [data-bs-theme="dark"] .hr-archive-action-card.teacher-card i {
            color: var(--hs-icon-purple-text) !important;
        }
        [data-bs-theme="dark"] .hr-archive-action-card.document-card i {
            color: var(--hs-icon-yellow-text) !important;
        }
        /* The "View ... Records" pill/button inside the card */
        [data-bs-theme="dark"] .hr-archive-action-card b {
            background: var(--hs-action-btn-bg) !important;
            color: var(--hs-action-btn-text) !important;
        }
        [data-bs-theme="dark"] .hr-archive-action-card:hover {
            border-color: #4a5a6e !important;
            box-shadow: 0 4px 18px rgba(0, 0, 0, 0.45) !important;
        }

        /* Sidebar */
        [data-bs-theme="dark"] .sidebar-wrapper,
        [data-bs-theme="dark"] .app-sidebar,
        [data-bs-theme="dark"] .main-sidebar,
        [data-bs-theme="dark"] .custom-sidebar {
            background-color: #2D2D2D !important;
            color: #e4e6e8 !important;
        }
        [data-bs-theme="dark"] .sidebar-wrapper a,
        [data-bs-theme="dark"] .sidebar-wrapper .nav-link,
        [data-bs-theme="dark"] .sidebar-wrapper .sidebar-brand-text {
            color: #e4e6e8 !important;
        }
        [data-bs-theme="dark"] .sidebar-wrapper .nav-link:hover,
        [data-bs-theme="dark"] .sidebar-wrapper .nav-link.active {
            background-color: #3a3a3a !important;
            color: #ffffff !important;
        }

        /* Footer */
        [data-bs-theme="dark"] .app-footer,
        [data-bs-theme="dark"] footer.main-footer {
            background: #2D2D2D !important;
            color: #adb5bd !important;
            border-top-color: #3a3a3a !important;
        }

        /* Generic text helpers */
        [data-bs-theme="dark"] .hr-archive-page h1,
        [data-bs-theme="dark"] .hr-archive-page h2,
        [data-bs-theme="dark"] .hr-archive-page h3,
        [data-bs-theme="dark"] .hr-archive-page h4,
        [data-bs-theme="dark"] .hr-archive-page h5,
        [data-bs-theme="dark"] .hr-archive-page h6 {
            color: var(--hs-text-strong) !important;
        }
        [data-bs-theme="dark"] .hr-archive-page a {
            color: #8ab4f8;
        }
        [data-bs-theme="dark"] .hr-archive-page a:hover {
            color: #b3ceff;
        }
        [data-bs-theme="dark"] .archive-stat-card,
        [data-bs-theme="dark"] .archive-block-card {
            background: var(--hs-card-bg) !important;
            border-color: var(--hs-border) !important;
            color: var(--hs-text) !important;
            box-shadow: 0 2px 12px var(--hs-shadow) !important;
        }
        [data-bs-theme="dark"] .archive-stat-count,
        [data-bs-theme="dark"] .archive-block-title {
            color: var(--hs-text-strong) !important;
        }
        [data-bs-theme="dark"] .archive-stat-label,
        [data-bs-theme="dark"] .archive-block-subtitle {
            color: var(--hs-text-muted) !important;
        }
        [data-bs-theme="dark"] .archive-stat-icon,
        [data-bs-theme="dark"] .archive-block-icon {
            box-shadow: 0 4px 14px rgba(0, 0, 0, .35) !important;
        }
            /* Archive stat cards & block cards — improved design */
        .archive-stat-card {
            display: flex; align-items: center; gap: 1rem;
            background: #fff; border: 1px solid #dce8f8;
            border-radius: 14px; padding: 1.15rem 1.25rem;
            box-shadow: 0 2px 10px rgba(18,72,168,0.05);
            transition: all 0.15s ease;
        }
        .archive-stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(18,72,168,0.12);
        }
        .archive-stat-icon {
            width: 52px; height: 52px; border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.5rem; flex-shrink: 0;
        }
        .archive-stat-count {
            font-size: 1.75rem; font-weight: 800;
            color: #132f62; line-height: 1; margin-bottom: 0.2rem;
        }
        .archive-stat-label {
            font-size: 0.82rem; font-weight: 600; color: #7a93b8;
            text-transform: uppercase; letter-spacing: 0.04em;
        }
        .archive-block-card {
            background: #fff; border: 1px solid #dce8f8;
            border-radius: 16px; padding: 2rem 1.5rem 1.5rem;
            text-align: center;
            box-shadow: 0 2px 12px rgba(18,72,168,0.06);
            transition: all 0.18s ease;
            display: flex; flex-direction: column; height: 100%;
        }
        .archive-subject-records {
            grid-column: 1 / -1;
            justify-self: center;
            width: calc(50% - 0.5rem);
        }
        @media (max-width: 767.98px) {
           .archive-subject-records {
                grid-column: auto;
                width: auto;
            }
        }
        .archive-block-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 28px rgba(18,72,168,0.12);
            border-color: #b8d0fa;
        }
        .archive-block-icon {
            width: 68px; height: 68px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 2rem; margin: 0 auto 1rem;
            box-shadow: 0 4px 14px rgba(18,72,168,0.15);
        }
        .archive-block-title {
            font-size: 1.1rem; font-weight: 700;
            color: #132f62; margin: 0 0 0.35rem;
        }
        .archive-block-subtitle {
            font-size: 0.85rem; color: #7a93b8; margin: 0 0 1.25rem;
        }
        .archive-block-btn {
            display: inline-flex; align-items: center; justify-content: center;
            gap: 0.45rem;
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff; font-weight: 600; font-size: 0.88rem;
            padding: 0.6rem 1.2rem; border-radius: 10px;
            text-decoration: none; border: none;
            transition: all 0.15s ease;
            box-shadow: 0 2px 10px rgba(26,110,245,0.25);
            margin-top: auto;
        }
        .archive-block-btn:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
            box-shadow: 0 4px 16px rgba(26,110,245,0.35);
            transform: translateY(-1px);
        }
</style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once __DIR__ . '/includes/header.php'; ?>
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3 hr-archive-page stsn-anim-fade-in-up">
                <div class="page-header">
                    <div>
                        <h3><i class="bi bi-clock-history me-2"></i><?= htmlspecialchars($selectedYear['year_label']) ?> Academic Year</h3>
                        <p><?= empty($selectedYear['archived_at'])
                            ? 'Current academic year records'
                            : 'Archived on ' . htmlspecialchars(date('M j, Y', strtotime($selectedYear['archived_at']))) . ' by Administrator' ?></p>
                    </div>
                </div>

                <?php require_once __DIR__ . '/includes/breadcrumb.php'; renderBreadcrumb([
                    ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door'],
                    ['label' => 'Archive', 'href' => 'historical_records.php', 'icon' => 'bi bi-archive'],
                    ['label' => 'Academic Years', 'href' => 'historical_records.php', 'icon' => 'bi bi-calendar3'],
                    ['label' => $selectedYear['year_label']]
                ]); ?>

                <div class="hr-year-metrics">
                    <div class="archive-stat-card stsn-anim-fade-in-up">
                        <div class="archive-stat-icon" style="background:#e3edff;color:#1a56c4;"><i class="bi bi-people-fill"></i></div>
                        <div>
                            <div class="archive-stat-count"><?= number_format((int) $selectedYear['students']) ?></div>
                            <div class="archive-stat-label">Total Students</div>
                        </div>
                    </div>
                    <div class="archive-stat-card stsn-anim-fade-in-up stsn-anim-delay-100">
                        <div class="archive-stat-icon" style="background:#eee5ff;color:#7340e8;"><i class="bi bi-layout-text-window-reverse"></i></div>
                        <div>
                            <div class="archive-stat-count"><?= number_format((int) $selectedYear['sections']) ?></div>
                            <div class="archive-stat-label">Total Sections</div>
                        </div>
                    </div>
                    <div class="archive-stat-card stsn-anim-fade-in-up stsn-anim-delay-200">
                        <div class="archive-stat-icon" style="background:#ffe9ec;color:#d63384;"><i class="bi bi-person-workspace"></i></div>
                        <div>
                            <div class="archive-stat-count"><?= number_format((int) $selectedYear['teachers']) ?></div>
                            <div class="archive-stat-label">Total Teachers</div>
                        </div>
                    </div>
                    <div class="archive-stat-card stsn-anim-fade-in-up stsn-anim-delay-300">
                        <div class="archive-stat-icon" style="background:#e2f6ef;color:#0F6E56;"><i class="bi bi-clipboard-data"></i></div>
                        <div>
                            <div class="archive-stat-count"><?= number_format((int) $selectedYear['grade_records']) ?></div>
                            <div class="archive-stat-label">Grade Records</div>
                        </div>
                    </div>
                    <div class="archive-stat-card stsn-anim-fade-in-up stsn-anim-delay-300">
                        <div class="archive-stat-icon" style="background:rgba(139, 92, 246, 0.15);color:#8b5cf6;"><i class="bi bi-journal-text"></i></div>
                        <div>
                            <div class="archive-stat-count"><?= number_format((int) $selectedYear['subjects']) ?></div>
                            <div class="archive-stat-label">Total Subjects</div>
                        </div>
                    </div>
                </div>

                <div class="hr-archive-card-grid">
                    <div class="archive-block-card stsn-anim-fade-in-up stsn-anim-delay-100">
                        <div class="archive-block-icon" style="background:#e3edff;color:#1a56c4;"><i class="bi bi-mortarboard-fill"></i></div>
                        <h4 class="archive-block-title">Student Archive</h4>
                        <p class="archive-block-subtitle"><?= number_format((int) $selectedYear['students']) ?> student records for S.Y. <?= htmlspecialchars($selectedYear['year_label']) ?></p>
                        <a class="archive-block-btn" href="Historical_records_student.php?year_id=<?= (int) $selectedYear['id'] ?>">
                            <i class="bi bi-box-arrow-up-right"></i> View Student Records
                        </a>
                    </div>
                    <div class="archive-block-card stsn-anim-fade-in-up stsn-anim-delay-200">
                        <div class="archive-block-icon" style="background:#eee5ff;color:#7340e8;"><i class="bi bi-people"></i></div>
                        <h4 class="archive-block-title">Faculty Archive</h4>
                        <p class="archive-block-subtitle"><?= number_format((int) $selectedYear['teachers']) ?> faculty records for S.Y. <?= htmlspecialchars($selectedYear['year_label']) ?></p>
                        <a class="archive-block-btn" href="Historical_records_teacher.php?year_id=<?= (int) $selectedYear['id'] ?>">
                            <i class="bi bi-box-arrow-up-right"></i> View Faculty Records
                        </a>
                    </div>
                    <section class="archive-block-card archive-subject-records stsn-anim-fade-in-up stsn-anim-delay-300" aria-labelledby="subjectRecordsTitle">
                        <div class="archive-block-icon" style="background:rgba(139, 92, 246, 0.15);color:#8b5cf6;">
                            <i class="bi bi-journal-text"></i>
                        </div>
                        <h5 id="subjectRecordsTitle" class="archive-block-title">Subject Records</h5>
                        <p class="archive-block-subtitle">
                            <?= number_format((int) $selectedYear['subjects']) ?> subject records for S.Y. <?= htmlspecialchars($selectedYear['year_label']) ?>
                        </p>
                        <a class="archive-block-btn" href="Curriculum-Year.php?year_id=<?= (int) $selectedYear['id'] ?>&amp;view=readonly">
                            <i class="bi bi-eye"></i> View Subject Records
                        </a>
                    </section>
                </div>
            </div>
        </div>
    </main>
    <?php require_once __DIR__ . '/includes/footer.php'; ?>
</div>
<script src="./vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script>
(function () {
    var buttons = document.querySelectorAll('.archive-block-btn');
    if (!buttons.length) return;
    var page = document.querySelector('.hr-archive-page');
    if (!page) return;
    var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    buttons.forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            var href = btn.getAttribute('href');
            if (!href || href === '#' || e.ctrlKey || e.metaKey || e.shiftKey) return;
            e.preventDefault();
            if (reduced) { window.location.href = href; return; }
            page.style.transition = 'opacity 180ms cubic-bezier(0.22, 1, 0.36, 1), transform 180ms cubic-bezier(0.22, 1, 0.36, 1)';
            page.style.opacity = '0';
            page.style.transform = 'translateY(-8px)';
            window.setTimeout(function () {
                window.location.href = href;
            }, 180);
        });
    });
})();
</script>
</body>
</html>