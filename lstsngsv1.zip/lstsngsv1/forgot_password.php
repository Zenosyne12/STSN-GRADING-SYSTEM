<?php
session_start();
require_once __DIR__ . '/api/shared/CSRFToken.php';

$csrfToken = CSRFToken::generate();
$prefilledUsername = trim($_GET['username'] ?? '');
$autoSendCode = ($_GET['auto'] ?? '') === '1';

if ($autoSendCode && $prefilledUsername === '') {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - STSN Grading System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="css/login.css">

    <style>
        :root {
            --maroon: #9e112d;
            --maroon-dark: #7d0d24;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f7f6;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px) scale(0.97); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }
        .forgot-card {
            animation: fadeInUp 0.5s cubic-bezier(0.23, 1, 0.32, 1) both;
        }

        .main-wrapper {
            min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 24px;
        }
        .forgot-card {
            width: 100%; max-width: 450px; background: rgba(255, 255, 255, 0.96);
            border-radius: 22px; padding: 40px; box-shadow: 0 22px 60px rgba(0, 0, 0, 0.22);
            border: 1px solid rgba(255, 255, 255, 0.45);
        }
        .brand {
            text-align: center; margin-bottom: 30px;
        }
        .brand-logo {
            width: 70px; height: 70px; margin: 0 auto 15px; border-radius: 15px;
            background: linear-gradient(145deg, #fff, #f7efef); border: 1px solid #e6d9dc;
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 10px 22px rgba(158, 17, 45, 0.08);
        }
        .brand-logo img { width: 45px; height: 45px; object-fit: contain; }
        .brand h1 { margin: 0; font-size: 1.8rem; font-weight: 700; color: var(--maroon); }
        .brand p { margin: 8px 0 0; font-size: 0.9rem; color: #777; }

        .section { margin-bottom: 30px; }
        .section.hidden { display: none; }

        .alert-box {
            display: flex; gap: 10px; align-items: flex-start; border-radius: 12px;
            padding: 12px 13px; margin-bottom: 15px; font-size: 0.85rem;
        }
        .alert-error { background: #fff1f3; border: 1px solid #f3c3cb; color: #8a1830; }
        .alert-success { background: #d4edda; border: 1px solid #c3e6cb; color: #155724; }
        .alert-warning { background: #fff3cd; border: 1px solid #ffeaa7; color: #856404; }

        .hint-box {
            background: #fff8eb; border: 1px solid #f1dfb6; color: #7a5d23;
            border-radius: 12px; padding: 12px; margin-bottom: 20px; font-size: 0.85rem;
        }

        .form-group { margin-bottom: 15px; }
        .form-label { display: block; margin-bottom: 8px; font-size: 0.9rem; font-weight: 600; color: #333; }
        .form-control {
            width: 100%; height: 48px; border: 1.5px solid #e6d9dc; border-radius: 12px;
            background: rgba(255, 255, 255, 0.92); padding: 0 15px;
            font-size: 0.95rem; color: #2b2b2b; transition: 0.2s ease;
        }
        .form-control:focus {
            border-color: rgba(158, 17, 45, 0.5); box-shadow: 0 0 0 3px rgba(158, 17, 45, 0.08);
            background: #fff; outline: none;
        }
        .form-control.code-input {
            font-family: 'Courier New', monospace; font-size: 1.3rem; font-weight: bold;
            letter-spacing: 3px; text-transform: uppercase; text-align: center;
        }

        .btn-primary {
            width: 100%; height: 48px; border: none; border-radius: 12px; color: #fff;
            font-weight: 700; font-size: 0.95rem; cursor: pointer;
            background: linear-gradient(135deg, var(--maroon), var(--maroon-dark));
            box-shadow: 0 10px 25px rgba(158, 17, 45, 0.22);
            transition: 0.2s ease; display: inline-flex; align-items: center; justify-content: center; gap: 0.4rem;
        }
        .btn-primary:hover:not(:disabled) {
            transform: translateY(-2px); box-shadow: 0 12px 30px rgba(158, 17, 45, 0.28);
        }
        .btn-primary:disabled { opacity: 0.6; cursor: not-allowed; }

        .tries-counter { text-align: center; font-size: 0.85rem; color: #666; margin-top: 10px; }
        .tries-counter.warning { color: #dc3545; font-weight: bold; }

        .back-link {
            display: block; text-align: center; margin-top: 25px; color: var(--maroon);
            text-decoration: none; font-weight: 600; font-size: 0.9rem;
        }
        .back-link:hover { text-decoration: underline; }

        .timer { text-align: center; font-size: 0.85rem; color: #666; margin-top: 10px; }
        .timer.warning { color: #dc3545; font-weight: bold; }

        @media (max-width: 480px) {
            .forgot-card { padding: 30px 20px; }
            .brand h1 { font-size: 1.5rem; }
        }
    </style>
</head>
<body class="login-page">
    <div class="main-wrapper">
        <div class="forgot-card">
            <div class="brand">
                <div class="brand-logo">
                    <img src="assets/img/stsn logo.png" alt="STSN Logo">
                </div>
                <h1>Forgot Password?</h1>
                <p>Reset your password securely</p>
            </div>

            <div id="errorBox" class="alert-box alert-error" style="display: none;">
                <i class="bi bi-exclamation-octagon-fill"></i>
                <div id="errorMessage"></div>
            </div>

            <div id="successBox" class="alert-box alert-success" style="display: none;">
                <i class="bi bi-check-circle-fill"></i>
                <div id="successMessage"></div>
            </div>

            <!-- STEP 1: Username Input -->
            <div id="step1" class="section">
                <div class="hint-box">
                    <i class="bi bi-info-circle me-2"></i>
                    <?= $prefilledUsername !== '' ? "We'll send a code to your email." : "Enter your username. We'll send a code to your email." ?>
                </div>

                <form id="usernameForm">
                    <input type="hidden" name="_csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">

                    <div class="form-group">
                        <label class="form-label" for="username">
                            <i class="bi bi-person-fill me-2"></i>Username
                        </label>
                        <input
                            type="text"
                            class="form-control"
                            name="username"
                            id="username"
                            placeholder="<?= $prefilledUsername !== '' ? 'We will send a code to your email' : 'Enter your username' ?>"
                            required
                            autofocus
                            minlength="3"
                            maxlength="50"
                            value="<?= htmlspecialchars($prefilledUsername) ?>"
                            <?= $prefilledUsername !== '' ? 'readonly' : '' ?>
                        >
                    </div>

                    <button type="submit" class="btn-primary" id="sendCodeBtn" disabled>
                        SEND CODE <i class="bi bi-arrow-right ms-2"></i>
                    </button>
                </form>
            </div>

            <!-- STEP 2: Code Input (3 Tries) -->
            <div id="step2" class="section hidden">
                <div class="hint-box">
                    <i class="bi bi-shield-check me-2"></i>
                    Check your email for the code. You have 3 attempts.
                </div>

                <div class="timer" id="timer">
                    Time remaining: <strong id="countdown">10:00</strong>
                </div>

                <form id="codeForm">
                    <input type="hidden" name="_csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">

                    <div class="form-group">
                        <label class="form-label" for="code">
                            <i class="bi bi-lock-fill me-2"></i>Code
                        </label>
                        <input
                            type="text"
                            class="form-control code-input"
                            name="code"
                            id="code"
                            placeholder="e.g. ABC12345"
                            required
                            maxlength="8"
                            autofocus
                        >
                    </div>

                    <div class="tries-counter" id="triesCounter">
                        Attempts remaining: <strong id="triesLeft">3</strong>
                    </div>

                    <button type="submit" class="btn-primary" id="verifyCodeBtn">
                        VERIFY CODE <i class="bi bi-arrow-right ms-2"></i>
                    </button>
                </form>

                <div style="text-align: center; margin-top: 20px;">
                    <button type="button" class="btn-link" id="resendCodeBtn" style="background: none; border: none; color: var(--maroon); cursor: pointer; text-decoration: none; font-weight: 600;">
                        Didn't receive code? Resend
                    </button>
                </div>
            </div>

            <a href="login.php" class="back-link">
                <i class="bi bi-arrow-left me-2"></i>Back to Login
            </a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const usernameInput = document.getElementById('username');
            const sendCodeBtn = document.getElementById('sendCodeBtn');
            const usernameForm = document.getElementById('usernameForm');
            const codeForm = document.getElementById('codeForm');
            const codeInput = document.getElementById('code');
            const verifyCodeBtn = document.getElementById('verifyCodeBtn');
            const resendCodeBtn = document.getElementById('resendCodeBtn');
            const errorBox = document.getElementById('errorBox');
            const errorMessage = document.getElementById('errorMessage');
            const successBox = document.getElementById('successBox');
            const successMessage = document.getElementById('successMessage');
            const step1 = document.getElementById('step1');
            const step2 = document.getElementById('step2');
            const triesLeft = document.getElementById('triesLeft');
            const triesCounter = document.getElementById('triesCounter');
            const timer = document.getElementById('timer');
            const countdown = document.getElementById('countdown');

            let currentUsername = '';
            let currentUserId = null;
            let attemptsRemaining = 3;
            let timeLeft = 600;
            let timerInterval = null;
            const autoSendCode = <?= $autoSendCode ? 'true' : 'false' ?>;

            function showError(message) {
                successBox.style.display = 'none';
                errorMessage.textContent = message;
                errorBox.style.display = 'flex';
            }

            function showSuccess(message) {
                errorBox.style.display = 'none';
                successMessage.textContent = message;
                successBox.style.display = 'flex';
            }

            usernameInput.addEventListener('input', function () {
                const username = this.value.trim();
                sendCodeBtn.disabled = username.length < 3;
            });

            // If the username is prefilled and read-only, enable the button immediately
            if (usernameInput.readOnly && usernameInput.value.trim().length >= 3) {
                sendCodeBtn.disabled = false;
            }

            function sendCodeRequest(fromResend = false) {
                currentUsername = usernameInput.value.trim();

                if (currentUsername.length < 3) {
                    showError('Type the username');
                    return;
                }

                errorBox.style.display = 'none';
                successBox.style.display = 'none';
                sendCodeBtn.disabled = true;
                sendCodeBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Sending...';
                resendCodeBtn.disabled = true;
                resendCodeBtn.textContent = 'Resending...';

                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 15000);

                fetch('api/login/send_code.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'username=' + encodeURIComponent(currentUsername) +
                          '&_csrf_token=' + encodeURIComponent(document.querySelector('input[name="_csrf_token"]').value),
                    signal: controller.signal
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        currentUserId = data.user_id || null;
                        showSuccess(fromResend
                            ? 'Code resent! Check your email.'
                            : data.message);

                        step1.classList.add('hidden');
                        step2.classList.remove('hidden');
                        attemptsRemaining = 3;
                        triesLeft.textContent = '3';
                        triesCounter.classList.remove('warning');
                        codeInput.disabled = false;
                        verifyCodeBtn.disabled = false;
                        codeInput.value = '';
                        timer.classList.remove('warning');
                        clearInterval(timerInterval);
                        startTimer();
                        codeInput.focus();
                    } else {
                        // Clean error – no debug info shown to user
                        showError(data.error || 'Error sending code');
                    }
                })
                .catch(err => {
                    const message = err.name === 'AbortError'
                        ? 'Request timed out. Please try again.'
                        : 'Error sending code. Please try again.';
                    showError(message);
                })
                .finally(() => {
                    clearTimeout(timeoutId);
                    sendCodeBtn.disabled = false;
                    sendCodeBtn.innerHTML = 'SEND CODE <i class="bi bi-arrow-right ms-2"></i>';
                    resendCodeBtn.disabled = false;
                    resendCodeBtn.textContent = "Didn't receive code? Resend";
                });
            }

            usernameForm.addEventListener('submit', function (e) {
                e.preventDefault();
                sendCodeRequest(false);
            });

            function startTimer() {
                timeLeft = 600;
                timerInterval = setInterval(function () {
                    timeLeft--;
                    const minutes = Math.floor(timeLeft / 60);
                    const seconds = timeLeft % 60;
                    const display = minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
                    countdown.textContent = display;

                    if (timeLeft <= 60) timer.classList.add('warning');
                    if (timeLeft <= 0) {
                        clearInterval(timerInterval);
                        codeInput.disabled = true;
                        verifyCodeBtn.disabled = true;
                        errorMessage.textContent = 'Code has expired. Please request a new one.';
                        errorBox.style.display = 'flex';
                    }
                }, 1000);
            }

            codeInput.addEventListener('input', function () {
                this.value = this.value.toUpperCase().substring(0, 8);
            });

            codeForm.addEventListener('submit', function (e) {
                e.preventDefault();
                const code = codeInput.value.trim();

                if (code.length !== 8) {
                    showError('Code must be 8 characters (e.g., ABC12345)');
                    return;
                }

                errorBox.style.display = 'none';
                verifyCodeBtn.disabled = true;
                verifyCodeBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Verifying...';

                fetch('api/login/verify_code.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'user_id=' + encodeURIComponent(currentUserId || 0) +
                          '&code=' + encodeURIComponent(code) +
                          '&_csrf_token=' + encodeURIComponent(document.querySelector('input[name="_csrf_token"]').value)
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        clearInterval(timerInterval);
                        showSuccess('Code verified! Redirecting to reset password...');
                        setTimeout(() => {
                            window.location.href = 'reset_password.php';
                        }, 1500);
                    } else {
                        attemptsRemaining--;
                        triesLeft.textContent = attemptsRemaining;

                        if (attemptsRemaining <= 0) {
                            showError('No attempts remaining. Please request a new code.');
                            codeInput.disabled = true;
                            verifyCodeBtn.disabled = true;
                        } else {
                            if (attemptsRemaining <= 1) triesCounter.classList.add('warning');
                            // Clean error message, no debug info
                            showError('Invalid code. ' + attemptsRemaining + ' attempt' + (attemptsRemaining === 1 ? '' : 's') + ' remaining.');
                            codeInput.value = '';
                            codeInput.focus();
                        }

                        verifyCodeBtn.disabled = false;
                        verifyCodeBtn.innerHTML = 'VERIFY CODE <i class="bi bi-arrow-right ms-2"></i>';
                    }
                })
                .catch(err => {
                    attemptsRemaining--;
                    triesLeft.textContent = attemptsRemaining;

                    if (attemptsRemaining <= 0) {
                        showError('No attempts remaining. Please request a new code.');
                        codeInput.disabled = true;
                        verifyCodeBtn.disabled = true;
                    } else {
                        showError('Error verifying code. ' + attemptsRemaining + ' attempt' + (attemptsRemaining === 1 ? '' : 's') + ' remaining.');
                        codeInput.value = '';
                        codeInput.focus();
                        verifyCodeBtn.disabled = false;
                    }

                    verifyCodeBtn.innerHTML = 'VERIFY CODE <i class="bi bi-arrow-right ms-2"></i>';
                });
            });

            resendCodeBtn.addEventListener('click', function () {
                usernameInput.value = currentUsername;
                sendCodeRequest(true);
            });

            if (autoSendCode && usernameInput.value.trim().length >= 3) {
                sendCodeBtn.disabled = false;
                usernameForm.dispatchEvent(new Event('submit', { cancelable: true }));
            }
        });
    </script>
</body>
</html>