/*

SQLyog Ultimate v8.55 
MySQL - 5.5.5-10.4.32-MariaDB : Database - dbstsn

*********************************************************************

*/



/*!40101 SET NAMES utf8 */;



/*!40101 SET SQL_MODE=''*/;



/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`dbstsn` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;



USE `dbstsn`;



/*Table structure for table `system_notifications` */



DROP TABLE IF EXISTS `system_notifications`;



CREATE TABLE `system_notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `system_notifications` */



/*Table structure for table `tblacademicyear` */



DROP TABLE IF EXISTS `tblacademicyear`;



CREATE TABLE `tblacademicyear` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `year_label` varchar(9) NOT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `year_label` (`year_label`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblacademicyear` */



insert  into `tblacademicyear`(`id`,`year_label`,`is_active`,`created_at`) values (1,'2026-2027',1,'2025-11-17 21:40:48');



/*Table structure for table `tbladviser_submissions` */



DROP TABLE IF EXISTS `tbladviser_submissions`;



CREATE TABLE `tbladviser_submissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `teacher_id` bigint(20) unsigned NOT NULL,
  `section_id` bigint(20) unsigned NOT NULL,
  `quarter` tinyint(4) NOT NULL,
  `school_year` varchar(20) NOT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tbladviser_submissions` */



/*Table structure for table `tblbarangay` */



DROP TABLE IF EXISTS `tblbarangay`;



CREATE TABLE `tblbarangay` (
  `id` int(11) NOT NULL,
  `barangay_name` varchar(100) NOT NULL,
  `city_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_barangay_city` (`city_id`),
  CONSTRAINT `fk_barangay_city` FOREIGN KEY (`city_id`) REFERENCES `tblcity` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblbarangay` */



insert  into `tblbarangay`(`id`,`barangay_name`,`city_id`) values (1,'Barangay 1',1),(2,'Barangay 2',2),(3,'Barangay 3',3),(4,'Barangay 4',4),(5,'Barangay 5',5);



/*Table structure for table `tblcity` */



DROP TABLE IF EXISTS `tblcity`;



CREATE TABLE `tblcity` (
  `id` int(11) NOT NULL,
  `city_name` varchar(100) NOT NULL,
  `province_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_city_province` (`province_id`),
  CONSTRAINT `fk_city_province` FOREIGN KEY (`province_id`) REFERENCES `tblprovince` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblcity` */



insert  into `tblcity`(`id`,`city_name`,`province_id`) values (1,'Manila',1),(2,'Quezon City',1),(3,'Makati',1),(4,'Dasmariñas',2),(5,'Santa Rosa',3);



/*Table structure for table `tblcountry` */



DROP TABLE IF EXISTS `tblcountry`;



CREATE TABLE `tblcountry` (
  `id` int(11) NOT NULL,
  `country_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblcountry` */



insert  into `tblcountry`(`id`,`country_name`) values (1,'Philippines');



/*Table structure for table `tblcurriculum_grade` */



DROP TABLE IF EXISTS `tblcurriculum_grade`;



CREATE TABLE `tblcurriculum_grade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `grade_level_id` int(11) NOT NULL,
  `strand` varchar(20) DEFAULT NULL,
  `subject_id` int(11) NOT NULL,
  `ww` tinyint(3) unsigned NOT NULL DEFAULT 30,
  `pt` tinyint(3) unsigned NOT NULL DEFAULT 50,
  `qa` tinyint(3) unsigned NOT NULL DEFAULT 20,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_grade_subject` (`grade_level_id`,`subject_id`),
  KEY `idx_curriculum_grade_level` (`grade_level_id`),
  KEY `idx_curriculum_subject` (`subject_id`),
  KEY `idx_tblcurriculum_grade_grade_strand` (`grade_level_id`,`strand`)
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblcurriculum_grade` */



insert  into `tblcurriculum_grade`(`id`,`grade_level_id`,`strand`,`subject_id`,`ww`,`pt`,`qa`,`is_active`,`created_at`,`updated_at`) values (1,1,NULL,1,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(2,1,NULL,2,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(3,1,NULL,3,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(4,1,NULL,4,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(5,1,NULL,5,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(6,1,NULL,6,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(7,2,NULL,7,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(8,2,NULL,8,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(9,2,NULL,9,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(10,2,NULL,10,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(11,2,NULL,11,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(12,2,NULL,12,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(13,2,NULL,13,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(14,3,NULL,14,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(15,3,NULL,15,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(16,3,NULL,16,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(17,3,NULL,17,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(18,3,NULL,18,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(19,3,NULL,19,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(20,3,NULL,20,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(21,4,NULL,21,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(22,4,NULL,22,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(23,4,NULL,23,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(24,4,NULL,24,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(25,4,NULL,25,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(26,4,NULL,26,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(27,4,NULL,27,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(28,4,NULL,28,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(29,5,NULL,29,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(30,5,NULL,30,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(31,5,NULL,31,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(32,5,NULL,32,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(33,5,NULL,33,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(34,5,NULL,34,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(35,5,NULL,35,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(36,6,NULL,36,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(37,6,NULL,37,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(38,6,NULL,38,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(39,6,NULL,39,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(40,6,NULL,40,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(41,6,NULL,41,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(42,6,NULL,42,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(43,7,NULL,43,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(44,7,NULL,44,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(45,7,NULL,45,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(46,7,NULL,46,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(47,7,NULL,47,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(48,7,NULL,48,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(49,7,NULL,49,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(50,8,NULL,50,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(51,8,NULL,51,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(52,8,NULL,52,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(53,8,NULL,53,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(54,8,NULL,54,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(55,8,NULL,55,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(56,8,NULL,56,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(57,8,NULL,57,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(58,9,NULL,58,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(59,9,NULL,59,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(60,9,NULL,60,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(61,9,NULL,61,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(62,9,NULL,62,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(63,9,NULL,63,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(64,9,NULL,64,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(65,9,NULL,65,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(66,10,NULL,66,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(67,10,NULL,67,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(68,10,NULL,68,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(69,10,NULL,69,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(70,10,NULL,70,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(71,10,NULL,71,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(72,10,NULL,72,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(73,10,NULL,73,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(74,11,NULL,74,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(75,11,NULL,75,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(76,11,NULL,76,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(77,11,NULL,77,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(78,11,NULL,78,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(79,11,NULL,79,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(80,11,NULL,80,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(81,11,NULL,81,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(82,12,NULL,82,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(83,12,NULL,83,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(84,12,NULL,84,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(85,12,NULL,85,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(86,12,NULL,86,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(87,12,NULL,87,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(88,12,NULL,88,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(89,12,'STEM',89,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(90,12,'STEM',90,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(91,12,'ABM',91,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(92,12,'ABM',92,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(93,12,'HUMSS',93,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(94,12,'TVL-ICT',94,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(95,12,NULL,95,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(96,12,NULL,96,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(97,12,NULL,97,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(98,12,NULL,98,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(99,12,NULL,99,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(100,12,NULL,100,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(101,12,NULL,101,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(102,12,'STEM',102,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(103,12,'STEM',103,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(104,12,'ABM',104,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(105,12,'HUMSS',105,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(106,12,'TVL-ICT',106,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(107,13,NULL,107,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(108,13,NULL,108,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(109,13,NULL,109,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(110,13,NULL,110,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(111,13,'STEM',111,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(112,13,'STEM',112,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(113,13,'ABM',113,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(114,13,'ABM',114,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(115,13,'HUMSS',115,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(116,13,'HUMSS',116,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(117,13,'TVL-ICT',117,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(118,13,NULL,118,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(119,13,NULL,119,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(120,13,NULL,120,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(121,13,'STEM',121,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(122,13,'STEM',122,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(123,13,'ABM',123,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(124,13,'ABM',124,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(125,13,'HUMSS',125,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(126,13,'HUMSS',126,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(127,13,'TVL-ICT',127,30,50,20,1,'2026-05-06 01:23:32','2026-05-06 01:23:32');



/*Table structure for table `tbldeadlines` */



DROP TABLE IF EXISTS `tbldeadlines`;



CREATE TABLE `tbldeadlines` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `quarter` tinyint(4) NOT NULL,
  `school_year` varchar(20) NOT NULL,
  `teacher_deadline` datetime NOT NULL,
  `adviser_deadline` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tbldeadlines` */



/*Table structure for table `tblenrollment` */



DROP TABLE IF EXISTS `tblenrollment`;



CREATE TABLE `tblenrollment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `academic_year_id` int(11) NOT NULL,
  `grade_level_id` int(11) NOT NULL,
  `enrollment_status` enum('ENROLLED','RETAINED','DROPPED','TRANSFERRED','GRADUATED') NOT NULL DEFAULT 'ENROLLED',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `enrolled_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_student_year` (`student_id`,`academic_year_id`),
  KEY `fk_enroll_year` (`academic_year_id`),
  KEY `fk_enroll_grade` (`grade_level_id`),
  CONSTRAINT `fk_enroll_grade` FOREIGN KEY (`grade_level_id`) REFERENCES `tblgradelevel` (`id`),
  CONSTRAINT `fk_enroll_student` FOREIGN KEY (`student_id`) REFERENCES `tblstudents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_enroll_year` FOREIGN KEY (`academic_year_id`) REFERENCES `tblacademicyear` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblenrollment` */



insert  into `tblenrollment`(`id`,`student_id`,`academic_year_id`,`grade_level_id`,`enrollment_status`,`is_active`,`enrolled_at`) values (36,1,1,3,'ENROLLED',1,'2026-04-25 12:14:09'),(37,2,1,3,'ENROLLED',1,'2026-04-25 12:15:34'),(38,3,1,4,'ENROLLED',1,'2026-04-25 12:15:34'),(39,4,1,4,'ENROLLED',1,'2026-04-25 12:15:34'),(40,5,1,3,'ENROLLED',1,'2026-04-25 12:15:34'),(41,6,1,4,'ENROLLED',1,'2026-04-25 12:15:34'),(42,7,1,4,'ENROLLED',1,'2026-04-25 12:15:34'),(43,8,1,4,'ENROLLED',1,'2026-04-25 12:15:34'),(44,9,1,3,'ENROLLED',1,'2026-04-25 12:15:34'),(45,10,1,3,'ENROLLED',1,'2026-04-25 12:15:34');



/*Table structure for table `tblgradelevel` */



DROP TABLE IF EXISTS `tblgradelevel`;



CREATE TABLE `tblgradelevel` (
  `id` int(11) NOT NULL,
  `grade_level_name` varchar(50) NOT NULL,
  `grade_level_code` int(11) GENERATED ALWAYS AS (cast(substr(`grade_level_name`,7) as unsigned)) STORED,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_last` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblgradelevel` */



insert  into `tblgradelevel`(`id`,`grade_level_name`,`grade_level_code`,`sort_order`,`is_last`) values (1,'Kindergarten',0,0,0),(2,'Grade 1',1,1,0),(3,'Grade 2',2,2,0),(4,'Grade 3',3,3,0),(5,'Grade 4',4,4,0),(6,'Grade 5',5,5,0),(7,'Grade 6',6,6,0),(8,'Grade 7',7,7,0),(9,'Grade 8',8,8,0),(10,'Grade 9',9,9,0),(11,'Grade 10',10,10,0),(12,'Grade 11',11,11,0),(13,'Grade 12',12,12,1);



/*Table structure for table `tblgrades` */



DROP TABLE IF EXISTS `tblgrades`;



CREATE TABLE `tblgrades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `quarter` tinyint(4) NOT NULL DEFAULT 1,
  `academic_year_id` int(11) NOT NULL DEFAULT 1,
  `ww_ps` decimal(6,2) DEFAULT 0.00,
  `pt_ps` decimal(6,2) DEFAULT 0.00,
  `qa_ps` decimal(6,2) DEFAULT 0.00,
  `ww_ws` decimal(6,2) DEFAULT 0.00,
  `pt_ws` decimal(6,2) DEFAULT 0.00,
  `qa_ws` decimal(6,2) DEFAULT 0.00,
  `ww_total` decimal(10,2) DEFAULT 0.00,
  `pt_total` decimal(10,2) DEFAULT 0.00,
  `qa_total` decimal(10,2) DEFAULT 0.00,
  `initial_grade` decimal(6,2) DEFAULT 0.00,
  `final_grade` int(11) DEFAULT 0,
  `remarks` varchar(20) DEFAULT 'Failed',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_grade` (`student_id`,`section_id`,`subject_id`,`quarter`,`academic_year_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_section` (`section_id`),
  KEY `idx_subject` (`subject_id`),
  KEY `idx_teacher` (`teacher_id`),
  KEY `idx_quarter` (`quarter`),
  KEY `idx_academic_year` (`academic_year_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



/*Data for the table `tblgrades` */



insert  into `tblgrades`(`id`,`student_id`,`section_id`,`subject_id`,`teacher_id`,`quarter`,`academic_year_id`,`ww_ps`,`pt_ps`,`qa_ps`,`ww_ws`,`pt_ws`,`qa_ws`,`ww_total`,`pt_total`,`qa_total`,`initial_grade`,`final_grade`,`remarks`,`created_at`,`updated_at`) values (1,10,24,17,5,1,1,'80.00','90.00','88.00','24.00','45.00','17.60','40.00','72.00','44.00','86.60',91,'Passed','2026-04-30 21:07:31','2026-05-06 03:38:34'),(2,2,24,17,5,1,1,'82.00','75.00','74.00','24.60','37.50','14.80','41.00','60.00','37.00','76.90',85,'Passed','2026-04-30 21:07:31','2026-05-06 03:38:34'),(3,1,24,17,5,1,1,'94.00','95.00','96.00','28.20','47.50','19.20','47.00','76.00','48.00','94.90',96,'Passed','2026-05-04 22:03:07','2026-05-06 03:38:34'),(4,9,24,17,5,1,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00',60,'Failed','2026-05-04 22:03:07','2026-05-06 03:38:34'),(5,10,24,18,6,1,1,'98.33','90.48','95.45','29.50','45.24','19.09','59.00','95.00','21.00','93.83',96,'Passed','2026-05-06 03:55:54','2026-05-06 03:55:56'),(6,2,24,18,6,1,1,'95.00','87.62','95.45','28.50','43.81','19.09','57.00','92.00','21.00','91.40',94,'Passed','2026-05-06 03:55:54','2026-05-06 03:55:56'),(7,1,24,18,6,1,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00',60,'Failed','2026-05-06 03:55:54','2026-05-06 03:55:56'),(8,9,24,18,6,1,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00',60,'Failed','2026-05-06 03:55:54','2026-05-06 03:55:56'),(9,10,24,10,5,1,1,'80.00','90.00','88.00','24.00','45.00','17.60','40.00','72.00','44.00','86.60',91,'Passed','2026-05-06 03:59:24','2026-05-06 03:59:24'),(10,2,24,10,5,1,1,'82.00','75.00','74.00','24.60','37.50','14.80','41.00','60.00','37.00','76.90',85,'Passed','2026-05-06 03:59:24','2026-05-06 03:59:24'),(11,1,24,10,5,1,1,'94.00','95.00','96.00','28.20','47.50','19.20','47.00','76.00','48.00','94.90',96,'Passed','2026-05-06 03:59:24','2026-05-06 03:59:24'),(12,9,24,10,5,1,1,'0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00','0.00',60,'Failed','2026-05-06 03:59:24','2026-05-06 03:59:24');



/*Table structure for table `tblpassword_resets` */



DROP TABLE IF EXISTS `tblpassword_resets`;



CREATE TABLE `tblpassword_resets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token_hash` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_token_hash` (`token_hash`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



/*Data for the table `tblpassword_resets` */



insert  into `tblpassword_resets`(`id`,`user_id`,`token_hash`,`expires_at`,`used`,`created_at`) values (22,13,'c78b33d94e90901e38b796f96bdda59778724ebddd08104acbff7938c8fa03e7','2026-04-27 05:56:09',0,'2026-04-27 05:46:09'),(23,8,'7ca1be38d0fecf5ab97c098671fe3f0dc8f420b7266cb261ba2b44aa780bf77c','2026-05-01 13:39:44',0,'2026-05-01 13:29:44'),(24,11,'da96fdee2707b869f7822840f49294c058739adb170b6d4949fea5d4e4b26280','2026-05-01 13:42:01',0,'2026-05-01 13:32:01');



/*Table structure for table `tblprovince` */



DROP TABLE IF EXISTS `tblprovince`;



CREATE TABLE `tblprovince` (
  `id` int(11) NOT NULL,
  `province_name` varchar(100) NOT NULL,
  `region_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_province_region` (`region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblprovince` */



insert  into `tblprovince`(`id`,`province_name`,`region_id`) values (1,'Metro Manila',1),(2,'Cavite',2),(3,'Laguna',2);



/*Table structure for table `tblquarters` */



DROP TABLE IF EXISTS `tblquarters`;



CREATE TABLE `tblquarters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `academic_year_id` int(11) NOT NULL,
  `quarter_number` int(11) NOT NULL COMMENT '1, 2, 3, or 4',
  `quarter_label` varchar(20) NOT NULL COMMENT '1st, 2nd, 3rd, 4th',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `is_closed` tinyint(1) DEFAULT 0 COMMENT 'Archive flag - 1 means closed/archived',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_quarter_per_year` (`academic_year_id`,`quarter_number`),
  KEY `idx_quarter_year` (`academic_year_id`),
  KEY `idx_quarter_active` (`is_active`),
  KEY `idx_quarter_closed` (`is_closed`),
  CONSTRAINT `tblquarters_ibfk_1` FOREIGN KEY (`academic_year_id`) REFERENCES `tblacademicyear` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblquarters` */



insert  into `tblquarters`(`id`,`academic_year_id`,`quarter_number`,`quarter_label`,`start_date`,`end_date`,`is_active`,`is_closed`,`created_at`,`updated_at`) values (1,1,1,'1st','2026-05-05','2026-05-06',1,0,'2026-04-18 16:28:58','2026-05-06 01:38:42'),(2,1,2,'2nd','2026-05-06','2026-05-07',0,0,'2026-04-18 16:28:58','2026-05-06 01:38:39'),(3,1,3,'3rd',NULL,NULL,0,0,'2026-04-18 16:28:58','2026-05-05 20:25:30'),(4,1,4,'4th',NULL,NULL,0,0,'2026-04-18 16:28:58','2026-05-05 20:25:33');



/*Table structure for table `tblregion` */



DROP TABLE IF EXISTS `tblregion`;



CREATE TABLE `tblregion` (
  `id` int(11) NOT NULL,
  `region_name` varchar(100) NOT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_region_country` (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblregion` */



insert  into `tblregion`(`id`,`region_name`,`country_id`) values (1,'National Capital Region (NCR)',1),(2,'Calabarzon (IV-A)',1);



/*Table structure for table `tblrole` */



DROP TABLE IF EXISTS `tblrole`;



CREATE TABLE `tblrole` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_name` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblrole` */



insert  into `tblrole`(`id`,`role_name`) values (1,'Admin'),(2,'Teacher');



/*Table structure for table `tblschedule` */



DROP TABLE IF EXISTS `tblschedule`;



CREATE TABLE `tblschedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `day_name` varchar(20) NOT NULL,
  `time_start` time NOT NULL,
  `time_end` time NOT NULL,
  `room` varchar(100) DEFAULT NULL,
  `semester` varchar(50) DEFAULT '1st Semester',
  `school_year` varchar(50) DEFAULT '2025-2026',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_schedule_section` (`section_id`),
  KEY `fk_schedule_subject` (`subject_id`),
  KEY `fk_schedule_teacher` (`teacher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblschedule` */



insert  into `tblschedule`(`id`,`section_id`,`subject_id`,`teacher_id`,`day_name`,`time_start`,`time_end`,`room`,`semester`,`school_year`,`is_active`,`created_at`,`updated_at`) values (6,24,10,5,'Monday','14:02:00','15:02:00','GYM','1st Semester','2026-2027',1,'2026-04-28 00:02:49','2026-04-28 00:02:49'),(7,16,23,5,'Monday','12:15:00','13:15:00','GYM','1st Semester','2026-2027',1,'2026-05-03 06:31:12','2026-05-03 06:31:12'),(8,16,23,5,'Wednesday','12:15:00','13:15:00','GYM','1st Semester','2026-2027',1,'2026-05-03 06:31:12','2026-05-03 06:31:12'),(12,24,18,6,'Monday','15:50:00','16:50:00','SDA','1st Semester','2026-2027',1,'2026-05-06 03:53:07','2026-05-06 03:53:07');



/*Table structure for table `tblsection` */



DROP TABLE IF EXISTS `tblsection`;



CREATE TABLE `tblsection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `grade_level_id` int(11) DEFAULT NULL,
  `strand` varchar(20) DEFAULT NULL,
  `section_code` varchar(30) NOT NULL,
  `section_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `section_code` (`section_code`),
  KEY `fk_tblsection_grade_level` (`grade_level_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblsection` */



insert  into `tblsection`(`id`,`grade_level_id`,`strand`,`section_code`,`section_name`,`description`,`is_active`,`created_at`,`updated_at`) values (15,11,NULL,'SEC-01','Ruby','Junior-high first-section track',1,'2025-11-22 22:36:10','2026-04-10 13:23:43'),(16,3,NULL,'SEC-02','Sapphire','Junior-high second-section track',1,'2025-11-22 22:36:10','2026-04-10 13:23:48'),(17,12,'TVL-ICT','SEC-03','Emerald','Junior-high third-section track',1,'2025-11-22 22:36:10','2026-05-06 02:15:28'),(18,4,NULL,'SEC-04','Diamond','Junior-high fourth-section track',1,'2025-11-22 22:36:10','2026-04-05 15:18:37'),(19,4,NULL,'SEC-05','Gold','Junior-high fifth-section track',1,'2025-11-22 22:36:10','2026-04-10 13:23:29'),(20,6,NULL,'SEC-06','Silver','Junior-high sixth-section track',1,'2025-11-22 22:36:10','2026-04-10 13:23:55'),(21,10,NULL,'SEC-07','Pearl','Junior-high seventh-section track',1,'2025-11-22 22:36:10','2026-04-10 13:23:35'),(22,11,NULL,'SEC-08','Onyx','Junior-high eighth-section track',1,'2025-11-22 22:36:10','2026-03-12 22:30:00'),(23,6,NULL,'SEC-09','Amethyst','Senior-high first-section track',1,'2025-11-22 22:36:10','2026-03-12 18:41:51'),(24,3,NULL,'SEC-10','Topaz','Senior-high second-section track',1,'2025-11-22 22:36:10','2026-03-12 18:40:44');



/*Table structure for table `tblsection_teacher_subject` */



DROP TABLE IF EXISTS `tblsection_teacher_subject`;



CREATE TABLE `tblsection_teacher_subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `weekly_sessions` int(11) DEFAULT 5,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_sts_section` (`section_id`),
  KEY `fk_sts_subject` (`subject_id`),
  KEY `fk_sts_teacher` (`teacher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblsection_teacher_subject` */



insert  into `tblsection_teacher_subject`(`id`,`section_id`,`subject_id`,`teacher_id`,`weekly_sessions`,`is_active`,`created_at`) values (1,24,13,2,5,1,'2026-03-12 08:48:10'),(2,24,16,12,3,1,'2026-03-12 08:49:42'),(3,23,17,2,5,1,'2026-03-12 10:03:55'),(4,22,16,13,5,1,'2026-03-12 14:29:24'),(6,22,8,11,5,1,'2026-03-12 14:29:42');



/*Table structure for table `tblsectionadviser` */



DROP TABLE IF EXISTS `tblsectionadviser`;



CREATE TABLE `tblsectionadviser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `academic_year_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_section_adviser` (`academic_year_id`,`section_id`),
  KEY `fk_sectionadviser_section` (`section_id`),
  KEY `fk_sectionadviser_teacher` (`teacher_id`),
  KEY `fk_sectionadviser_academic_year` (`academic_year_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblsectionadviser` */



insert  into `tblsectionadviser`(`id`,`academic_year_id`,`section_id`,`teacher_id`,`created_at`,`updated_at`) values (1,1,24,5,'2026-03-18 22:12:28','2026-04-10 13:23:08'),(2,1,15,3,'2026-03-19 02:26:45','2026-03-27 23:13:19'),(3,1,19,11,'2026-03-25 23:58:00','2026-03-27 23:53:00'),(4,1,18,1,'2026-04-05 18:47:15','2026-04-05 18:47:15'),(5,1,16,4,'2026-05-03 05:53:08','2026-05-03 05:53:08');



/*Table structure for table `tblsectionstudent` */



DROP TABLE IF EXISTS `tblsectionstudent`;



CREATE TABLE `tblsectionstudent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `academic_year_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_section_student_year` (`section_id`,`student_id`,`academic_year_id`),
  KEY `fk_sectionstudent_student` (`student_id`),
  KEY `fk_sectionstudent_section` (`section_id`),
  KEY `fk_sectionstudent_academic_year` (`academic_year_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblsectionstudent` */



insert  into `tblsectionstudent`(`id`,`section_id`,`student_id`,`academic_year_id`,`is_active`,`created_at`,`updated_at`) values (2,15,1,1,0,'2026-03-19 00:47:15','2026-03-19 03:05:24'),(8,15,4,1,1,'2026-03-19 02:28:34','2026-03-19 02:28:34'),(11,17,5,1,1,'2026-04-05 15:28:37','2026-04-05 15:28:37'),(16,24,10,1,1,'2026-04-27 23:08:07','2026-04-27 23:08:07'),(17,24,2,1,1,'2026-04-27 23:08:07','2026-04-27 23:08:07'),(18,24,1,1,1,'2026-05-03 06:51:49','2026-05-03 06:51:49'),(19,24,9,1,1,'2026-05-03 06:51:49','2026-05-03 06:51:49');



/*Table structure for table `tblstudent_archive` */



DROP TABLE IF EXISTS `tblstudent_archive`;



CREATE TABLE `tblstudent_archive` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `academic_year_id` int(11) NOT NULL,
  `grade_level_id` int(11) NOT NULL,
  `final_average` decimal(5,2) DEFAULT NULL,
  `status` enum('PROMOTED','RETAINED','DROPPED','TRANSFERRED','GRADUATED') NOT NULL,
  `archived_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `archived_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_archive_student` (`student_id`),
  KEY `fk_archive_year` (`academic_year_id`),
  KEY `fk_archive_grade` (`grade_level_id`),
  CONSTRAINT `fk_archive_grade` FOREIGN KEY (`grade_level_id`) REFERENCES `tblgradelevel` (`id`),
  CONSTRAINT `fk_archive_student` FOREIGN KEY (`student_id`) REFERENCES `tblstudents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_archive_year` FOREIGN KEY (`academic_year_id`) REFERENCES `tblacademicyear` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblstudent_archive` */



/*Table structure for table `tblstudents` */



DROP TABLE IF EXISTS `tblstudents`;



CREATE TABLE `tblstudents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lrn` varchar(12) DEFAULT NULL,
  `fname` varchar(100) DEFAULT NULL,
  `mname` varchar(100) DEFAULT NULL,
  `lname` varchar(100) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `citizenship` varchar(50) DEFAULT NULL,
  `grade_level_id` int(11) DEFAULT NULL,
  `strand` varchar(20) DEFAULT NULL,
  `fathers_name` varchar(100) DEFAULT NULL,
  `fathers_contact_num` varchar(20) DEFAULT NULL,
  `mothers_name` varchar(100) DEFAULT NULL,
  `mothers_contact_num` varchar(100) DEFAULT NULL,
  `guardian_name` varchar(100) DEFAULT NULL,
  `guardian_contact_num` varchar(20) DEFAULT NULL,
  `street_name` varchar(100) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `barangay_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `province_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lrn` (`lrn`),
  KEY `fk_name_grade` (`grade_level_id`),
  KEY `fk_name_barangay` (`barangay_id`),
  KEY `fk_name_city` (`city_id`),
  KEY `fk_name_region` (`region_id`),
  KEY `fk_name_province` (`province_id`),
  KEY `fk_name_country` (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblstudents` */



insert  into `tblstudents`(`id`,`lrn`,`fname`,`mname`,`lname`,`birthdate`,`gender`,`citizenship`,`grade_level_id`,`strand`,`fathers_name`,`fathers_contact_num`,`mothers_name`,`mothers_contact_num`,`guardian_name`,`guardian_contact_num`,`street_name`,`postal_code`,`barangay_id`,`city_id`,`region_id`,`province_id`,`country_id`,`email`,`is_active`) values (1,'010000000001','Andre','Delos','Santo','2001-01-15','Male','Filipino',2,NULL,'Pedro Santos','0917-111-1111','Maria Santos','84651','Maria Santos','0917-111-1111','123 Mabini St','1000',1,1,1,1,1,NULL,1),(2,'010000000002','Maria','Isabel','Reyes','2011-03-22','Female','Filipino',5,NULL,'Jose Reyes','0922-222-2222','Ana Reyes','7461','Ana Reyes','0922-222-2222','456 Quezon Ave','1100',2,2,1,1,1,NULL,1),(3,'010000000003','Carlos','Dim','Garcia','2009-07-08','Male','Filipino',7,NULL,'Ramon Garcia','0933-333-3333','Clara Garcia','09944','Clara Garcia','0933-333-3333','789 Rizal Blvd','1200',3,3,1,1,1,NULL,1),(4,'010000000004','Sophia','Lane','Mendoza','2012-11-30','Female','Filipino',4,NULL,'Miguel Mendoza','0944-444-4444','Elena Mendoza','096230','Elena Mendoza','0944-444-4444','321 Luna St','4114',4,4,2,2,1,NULL,1),(5,'010000000005','Andrew','Mark','Torres','2008-05-14','Male','Filipino',8,NULL,'Robert Torres','0955-555-5555','Liza Torres','098555','Liza Torres','0955-555-5555','654 Del Pilar','4026',5,5,2,3,1,NULL,1),(6,'010000000006','Angela','Rose','Cruz','2013-08-20','Female','Filipino',4,'','Danilo Cruz','0966-666-6666','Fe Cruz','096555','Fe Cruz','0966-666-6666','987 Bonifacio St','1000',1,1,1,1,1,NULL,1),(7,'010000000007','Mark','Paul','Lim','2007-12-03','Male','Filipino',9,NULL,'Arthur Lim','0977-777-7777','Grace Lim','08444','Grace Lim','0977-777-7777','147 Taft Ave','1100',2,2,1,1,1,NULL,1),(8,'010000000008','Jusipin','Kay','Flores','2014-02-28','Female','Filipino',2,NULL,'Ryan Flores','0988-888-8888','Cathy Flores','096666','Cathy Flores','0988-888-8888','258 Shaw Blvd','1200',3,3,1,1,1,NULL,1),(9,'010000000009','Bryan','James','Villanueva','2006-09-11','Male','Filipino',10,NULL,'Raul Villanueva','0999-999-9999','Nina Villanueva','092222','Nina Villanueva','0999-999-9999','369 Aguinaldo Hwy','4114',4,4,2,2,1,NULL,1),(10,'010000000010','Trisha','May','Delos','2015-06-17','Female','Filipino',2,NULL,'Leo Delos','0912-121-2121','Mila Delos','093333','Mila Delos','0912-121-2121','753 Bayan St','4026',5,5,2,3,1,NULL,1);



/*Table structure for table `tblsubjects` */



DROP TABLE IF EXISTS `tblsubjects`;



CREATE TABLE `tblsubjects` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `grade_level_id` int(11) unsigned NOT NULL,
  `strand` varchar(10) DEFAULT NULL,
  `semester` varchar(20) DEFAULT NULL COMMENT '1st Semester, 2nd Semester, or NULL for non-SHS',
  `subject_code` varchar(20) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `subject_type` enum('CORE','APPLIED','SPECIALIZED','ELECTIVE') NOT NULL DEFAULT 'CORE',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_grade_strand_name` (`grade_level_id`,`strand`,`subject_name`),
  KEY `idx_grade` (`grade_level_id`),
  KEY `idx_strand` (`strand`),
  KEY `idx_active` (`is_active`),
  KEY `idx_type` (`subject_type`),
  KEY `idx_semester` (`semester`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



/*Data for the table `tblsubjects` */



insert  into `tblsubjects`(`id`,`grade_level_id`,`strand`,`semester`,`subject_code`,`subject_name`,`subject_type`,`is_active`,`created_at`,`updated_at`) values (1,1,NULL,NULL,'Kinder LANGU DEVEL','Language Development','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(2,1,NULL,NULL,'Kinder LITERACY','Literacy','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(3,1,NULL,NULL,'Kinder NUMERACY','Numeracy','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(4,1,NULL,NULL,'Kinder PHYSI DEVEL','Physical Development','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(5,1,NULL,NULL,'Kinder SOCIO DEVEL','Socio-Emotional Development','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(6,1,NULL,NULL,'Kinder VALUE EDUCA','Values Education','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(7,2,NULL,NULL,'G1 MOTHE TONGU','Mother Tongue','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(8,2,NULL,NULL,'G1 ENGLISH','English','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(9,2,NULL,NULL,'G1 FILIPINO','Filipino','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(10,2,NULL,NULL,'G1 MATHEMATIC','Mathematics','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(11,2,NULL,NULL,'G1 ARALI PANLI','Araling Panlipunan','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(12,2,NULL,NULL,'G1 ESP','ESP','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(13,2,NULL,NULL,'G1 MAPEH','MAPEH','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(14,3,NULL,NULL,'G2 MOTHE TONGU','Mother Tongue','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(15,3,NULL,NULL,'G2 ENGLISH','English','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(16,3,NULL,NULL,'G2 FILIPINO','Filipino','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(17,3,NULL,NULL,'G2 MATHEMATIC','Mathematics','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(18,3,NULL,NULL,'G2 ARALI PANLI','Araling Panlipunan','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(19,3,NULL,NULL,'G2 ESP','ESP','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(20,3,NULL,NULL,'G2 MAPEH','MAPEH','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(21,4,NULL,NULL,'G3 MOTHE TONGU','Mother Tongue','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(22,4,NULL,NULL,'G3 ENGLISH','English','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(23,4,NULL,NULL,'G3 FILIPINO','Filipino','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(24,4,NULL,NULL,'G3 MATHEMATIC','Mathematics','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(25,4,NULL,NULL,'G3 SCIENCE','Science','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(26,4,NULL,NULL,'G3 ARALI PANLI','Araling Panlipunan','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(27,4,NULL,NULL,'G3 ESP','ESP','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(28,4,NULL,NULL,'G3 MAPEH','MAPEH','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(29,5,NULL,NULL,'G4 ENGLISH','English','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(30,5,NULL,NULL,'G4 FILIPINO','Filipino','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(31,5,NULL,NULL,'G4 MATHEMATIC','Mathematics','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(32,5,NULL,NULL,'G4 SCIENCE','Science','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(33,5,NULL,NULL,'G4 ARALI PANLI','Araling Panlipunan','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(34,5,NULL,NULL,'G4 ESP','ESP','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(35,5,NULL,NULL,'G4 MAPEH','MAPEH','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(36,6,NULL,NULL,'G5 ENGLISH','English','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(37,6,NULL,NULL,'G5 FILIPINO','Filipino','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(38,6,NULL,NULL,'G5 MATHEMATIC','Mathematics','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(39,6,NULL,NULL,'G5 SCIENCE','Science','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(40,6,NULL,NULL,'G5 ARALI PANLI','Araling Panlipunan','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(41,6,NULL,NULL,'G5 ESP','ESP','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(42,6,NULL,NULL,'G5 MAPEH','MAPEH','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(43,7,NULL,NULL,'G6 ENGLISH','English','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(44,7,NULL,NULL,'G6 FILIPINO','Filipino','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(45,7,NULL,NULL,'G6 MATHEMATIC','Mathematics','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(46,7,NULL,NULL,'G6 SCIENCE','Science','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(47,7,NULL,NULL,'G6 ARALI PANLI','Araling Panlipunan','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(48,7,NULL,NULL,'G6 ESP','ESP','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(49,7,NULL,NULL,'G6 MAPEH','MAPEH','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(50,8,NULL,NULL,'G7 ENGLISH','English','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(51,8,NULL,NULL,'G7 FILIPINO','Filipino','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(52,8,NULL,NULL,'G7 MATHEMATIC','Mathematics','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(53,8,NULL,NULL,'G7 SCIENCE','Science','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(54,8,NULL,NULL,'G7 ARALI PANLI','Araling Panlipunan','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(55,8,NULL,NULL,'G7 ESP','ESP','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(56,8,NULL,NULL,'G7 MAPEH','MAPEH','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(57,8,NULL,NULL,'G7 TLE','TLE','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(58,9,NULL,NULL,'G8 ENGLISH','English','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(59,9,NULL,NULL,'G8 FILIPINO','Filipino','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(60,9,NULL,NULL,'G8 MATHEMATIC','Mathematics','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(61,9,NULL,NULL,'G8 SCIENCE','Science','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(62,9,NULL,NULL,'G8 ARALI PANLI','Araling Panlipunan','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(63,9,NULL,NULL,'G8 ESP','ESP','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(64,9,NULL,NULL,'G8 MAPEH','MAPEH','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(65,9,NULL,NULL,'G8 TLE','TLE','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(66,10,NULL,NULL,'G9 ENGLISH','English','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(67,10,NULL,NULL,'G9 FILIPINO','Filipino','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(68,10,NULL,NULL,'G9 MATHEMATIC','Mathematics','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(69,10,NULL,NULL,'G9 SCIENCE','Science','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(70,10,NULL,NULL,'G9 ARALI PANLI','Araling Panlipunan','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(71,10,NULL,NULL,'G9 ESP','ESP','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(72,10,NULL,NULL,'G9 MAPEH','MAPEH','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(73,10,NULL,NULL,'G9 TLE','TLE','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(74,11,NULL,NULL,'G10 ENGLISH','English','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(75,11,NULL,NULL,'G10 FILIPINO','Filipino','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(76,11,NULL,NULL,'G10 MATHEMATIC','Mathematics','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(77,11,NULL,NULL,'G10 SCIENCE','Science','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(78,11,NULL,NULL,'G10 ARALI PANLI','Araling Panlipunan','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(79,11,NULL,NULL,'G10 ESP','ESP','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(80,11,NULL,NULL,'G10 MAPEH','MAPEH','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(81,11,NULL,NULL,'G10 TLE','TLE','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(82,12,NULL,'1st','G11 ORAL COMMU','Oral Communication','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(83,12,NULL,'1st','G11 GENER MATHE','General Mathematics','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(84,12,NULL,'1st','G11 EALS','Earth and Life Science','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(85,12,NULL,'1st','G11 UCSP','UCSP','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(86,12,NULL,'1st','G11 PERSO DEVEL','Personal Development','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(87,12,NULL,'1st','G11 PE 1','PE 1','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(88,12,NULL,'1st','G11 EMPOW TECHN','Empowerment Technologies','APPLIED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(89,12,'STEM','1st','G11 STEM PRE-CALCUL','Pre-Calculus','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(90,12,'STEM','1st','G11 STEM GB1','General Biology 1','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(91,12,'ABM','1st','G11 ABM BUSIN MATH','Business Math','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(92,12,'ABM','1st','G11 ABM OAM','Organization and Management','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(93,12,'HUMSS','1st','G11 HUMSS SOCIA SCIE','Social Sciences','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(94,12,'TVL-ICT','1st','G11 TVL CSS 1','CSS 1','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(95,12,NULL,'2nd','G11 RAW','Reading and Writing','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(96,12,NULL,'2nd','G11 STATISTICS','Statistics','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(97,12,NULL,'2nd','G11 PHYSI SCIEN','Physical Science','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(98,12,NULL,'2nd','G11 LITERATURE','Literature','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(99,12,NULL,'2nd','G11 PHILOSOPHY','Philosophy','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(100,12,NULL,'2nd','G11 PE 2','PE 2','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(101,12,NULL,'2nd','G11 PR1','Practical Research 1','APPLIED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(102,12,'STEM','2nd','G11 STEM BASIC CALCU','Basic Calculus','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(103,12,'STEM','2nd','G11 STEM GB2','General Biology 2','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(104,12,'ABM','2nd','G11 ABM FABM 1','FABM 1','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(105,12,'HUMSS','2nd','G11 HUMSS ASS','Applied Social Sci','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(106,12,'TVL-ICT','2nd','G11 TVL CSS 2','CSS 2','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(107,13,NULL,'1st','G12 MAIL','Media and Info Literacy','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(108,13,NULL,'1st','G12 PHILI ARTS','Philippine Arts','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(109,13,NULL,'1st','G12 PE 3','PE 3','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(110,13,NULL,'1st','G12 INQUIRIES','Inquiries','APPLIED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(111,13,'STEM','1st','G12 STEM CHEMI 1','Chemistry 1','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(112,13,'STEM','1st','G12 STEM PHYSI 1','Physics 1','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(113,13,'ABM','1st','G12 ABM FABM 2','FABM 2','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(114,13,'ABM','1st','G12 ABM BUSIN FINAN','Business Finance','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(115,13,'HUMSS','1st','G12 HUMSS CREAT WRIT','Creative Writing','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(116,13,'HUMSS','1st','G12 HUMSS POLITICS','Politics','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(117,13,'TVL-ICT','1st','G12 TVL PROGRAMMIN','Programming','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(118,13,NULL,'2nd','G12 PE 4','PE 4','CORE',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(119,13,NULL,'2nd','G12 PR2','Practical Research 2','APPLIED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(120,13,NULL,'2nd','G12 WORK IMMER','Work Immersion','APPLIED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(121,13,'STEM','2nd','G12 STEM CHEMI 2','Chemistry 2','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(122,13,'STEM','2nd','G12 STEM PHYSI 2','Physics 2','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(123,13,'ABM','2nd','G12 ABM APPLI ECONO','Applied Economics','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(124,13,'ABM','2nd','G12 ABM BUSIN ETHIC','Business Ethics','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(125,13,'HUMSS','2nd','G12 HUMSS TRENDS','Trends','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(126,13,'HUMSS','2nd','G12 HUMSS COMMU ENGA','Community Engagement','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32'),(127,13,'TVL-ICT','2nd','G12 TVL IMMERSION','Immersion','SPECIALIZED',1,'2026-05-06 01:23:32','2026-05-06 01:23:32');



/*Table structure for table `tblteacher` */



DROP TABLE IF EXISTS `tblteacher`;



CREATE TABLE `tblteacher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` varchar(30) NOT NULL,
  `email` varchar(255) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `mname` varchar(100) DEFAULT '',
  `lname` varchar(100) NOT NULL,
  `date_hired` date NOT NULL,
  `sex` enum('Male','Female') NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `teacher_id` (`teacher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblteacher` */



insert  into `tblteacher`(`id`,`teacher_id`,`email`,`fname`,`mname`,`lname`,`date_hired`,`sex`,`contact_no`,`is_active`) values (1,'T00001','maria.clara@example.com','Maria','','Clara','2025-11-27','Female','09123456789',1),(2,'T00002','jose.rizal@example.com','Jose','','Rizal','2025-11-27','Male','09223456789',1),(3,'T00003','andres.boni@example.com','Andres','','Bonifacio','2025-11-27','Male','09333456789',1),(4,'T00004','melchora.aquino@example.com','Melchora','','Aquino','2025-11-27','Female','09443456789',1),(5,'T00005','emilio.aguinaldo@example.com','Emilio','M','Aguinaldo','2025-11-27','Male','09553456789',1),(6,'T00006','gabriela.silang@example.com','Gabriela','','Silang','2025-11-27','Female','09663456789',1),(7,'T00007','apol.mabini@example.com','Apolinario','','Mabini','2025-11-27','Male','09773456789',1),(8,'T00008','lapu.datu@example.com','Lapu-Lapu','','Datu','2025-11-27','Male','09883456789',1),(9,'T00009','katherine.li@example.com','Katherine','','Li','2025-11-27','Female','09993456789',1),(10,'T00010','riz.torres@example.com','Rizalino','','Torres','2025-11-27','Male','09004567890',1),(11,'T00023','hechanova919@gmail.com','Justin ','','Hechanova','2025-11-27','Male','9771995088',1),(12,'T00044','lukenazaren@gmail.com','Luke','','San Jose','2025-11-27','Male','09771885768',1),(13,'T00099','CristineGonzales123@gmail.com','Cristines','','Gonzales','2025-11-27','Female','9886758464324',1),(17,'T00069','justinleonardcorrea@gmail.com','justin','Barreto','Correa','2026-04-10','Male','09184056051',1),(18,'T03402','andrejustin2005@gmail.com','Willy','Cruz','Wonka','2026-04-13','Male','9867897897',1),(19,'T00333','meepoheepo2005@gmail.com','Metro','Victor','Cruz','2026-04-27','Male','9867897897',1);



/*Table structure for table `tblteacher_submissions` */



DROP TABLE IF EXISTS `tblteacher_submissions`;



CREATE TABLE `tblteacher_submissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `teacher_id` bigint(20) unsigned NOT NULL,
  `section_id` bigint(20) unsigned NOT NULL,
  `subject_id` bigint(20) unsigned NOT NULL,
  `quarter` tinyint(4) NOT NULL,
  `school_year` varchar(20) NOT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



/*Data for the table `tblteacher_submissions` */



/*Table structure for table `tblusers` */



DROP TABLE IF EXISTS `tblusers`;



CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `must_change_password` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_reference` (`reference_id`),
  KEY `idx_role` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



/*Data for the table `tblusers` */



insert  into `tblusers`(`id`,`username`,`password_hash`,`role_id`,`reference_id`,`status`,`created_at`,`updated_at`,`must_change_password`) values (4,'admin','$2y$10$nw7Ah4oao/TjpSxaV6o8UO/EfPT2r3k/gsIFw2RxMWSgOUXaFCDc.',1,NULL,'Active','2025-11-25 00:37:53','2026-05-03 03:40:11',0),(6,'bonifaciot00003','$2y$10$xoWBnl.LW1OgIc78ELoDyuRSbiaU6Ju.F2xf6m9VJ4BWFsDhYMJ9u',2,6,'Active','2025-11-25 01:52:13','2025-11-26 13:50:01',0),(8,'aguinaldot00005','$2y$10$D66sRrEJM8XUzcedZw3B5.SdUm6EnHZvp8DoF0pXJKIEEgj37rsDy',2,5,'Active','2025-11-29 00:52:22','2026-05-06 02:21:47',0),(9,'gonzalest00099','$2y$10$Jjzw06koQ1b3xKTemgrXlOFCBtORrf2yaQAlBzGPKptps2GzFhnmy',2,13,'Active','2025-11-29 01:15:39','2025-11-29 01:15:39',1),(10,'Lukas','dodong',1,NULL,'Active','2026-01-12 11:18:13','2026-01-12 11:18:13',0),(11,'sanjoset00044','$2y$10$RBfyXIFOs7XcF/l35ioUiOd2Kf0xVZCvKUbTzyhEJOy0NammmELmK',2,12,'Active','2026-04-08 01:06:19','2026-04-08 01:06:19',1),(12,'correat00069','$2y$10$T392hNcLDF.6WB6Azz.F1.4F5dOWYcFuUZRvHvQKV2lNpAie1jQnO',2,17,'Active','2026-04-10 13:16:49','2026-04-10 13:16:49',1),(13,'wonkat03402','$2y$12$XYYboHTjF7nRccBz68N5juwxmH1B5XoxxrBdBvfAC79EAQrtaVdw2',2,18,'Active','2026-04-13 07:39:10','2026-04-27 05:31:50',0),(14,'cruzt00333','$2y$10$vm.QIKmb2Y5rWv5Ah1dsae97.HsQFGXdUuaAO5u4wp.cU.AuERO2m',2,19,'Active','2026-04-27 04:31:43','2026-04-27 04:32:50',0);



/*Table structure for table `vwstudentinfo` */



DROP TABLE IF EXISTS `vwstudentinfo`;



/*!50001 DROP VIEW IF EXISTS `vwstudentinfo` */;

/*!50001 DROP TABLE IF EXISTS `vwstudentinfo` */;


/*!50001 CREATE TABLE  `vwstudentinfo`(
 `id` int(11) ,
 `lrn` varchar(12) ,
 `fname` varchar(100) ,
 `mname` varchar(100) ,
 `lname` varchar(100) ,
 `birthdate` date ,
 `gender` varchar(10) ,
 `citizenship` varchar(50) ,
 `strand` varchar(20) ,
 `fathers_name` varchar(100) ,
 `fathers_contact_num` varchar(20) ,
 `mothers_name` varchar(100) ,
 `mothers_contact_num` varchar(100) ,
 `guardian_name` varchar(100) ,
 `guardian_contact_num` varchar(20) ,
 `street_name` varchar(100) ,
 `postal_code` varchar(20) ,
 `barangay_id` int(11) ,
 `is_active` tinyint(1) ,
 `enrollment_id` int(11) ,
 `grade_level_id` int(11) ,
 `enrollment_status` enum('ENROLLED','RETAINED','DROPPED','TRANSFERRED','GRADUATED') ,
 `academic_year_id` int(11) ,
 `grade_level_name` varchar(50) ,
 `grade_level_code` int(11) ,
 `academic_year_label` varchar(9) ,
 `year_is_active` tinyint(1) ,
 `barangay_name` varchar(100) ,
 `city_id` int(11) ,
 `city_name` varchar(100) ,
 `province_id` int(11) ,
 `province_name` varchar(100) ,
 `region_id` int(11) ,
 `region_name` varchar(100) ,
 `country_id` int(11) ,
 `country_name` varchar(100) ,
 `age` bigint(21) ,
 `full_address` text 
)*/;


/*View structure for view vwstudentinfo */



/*!50001 DROP TABLE IF EXISTS `vwstudentinfo` */;

/*!50001 DROP VIEW IF EXISTS `vwstudentinfo` */;



/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vwstudentinfo` AS select `s`.`id` AS `id`,`s`.`lrn` AS `lrn`,`s`.`fname` AS `fname`,`s`.`mname` AS `mname`,`s`.`lname` AS `lname`,`s`.`birthdate` AS `birthdate`,`s`.`gender` AS `gender`,`s`.`citizenship` AS `citizenship`,`s`.`strand` AS `strand`,`s`.`fathers_name` AS `fathers_name`,`s`.`fathers_contact_num` AS `fathers_contact_num`,`s`.`mothers_name` AS `mothers_name`,`s`.`mothers_contact_num` AS `mothers_contact_num`,`s`.`guardian_name` AS `guardian_name`,`s`.`guardian_contact_num` AS `guardian_contact_num`,`s`.`street_name` AS `street_name`,`s`.`postal_code` AS `postal_code`,`s`.`barangay_id` AS `barangay_id`,`s`.`is_active` AS `is_active`,`e`.`id` AS `enrollment_id`,`e`.`grade_level_id` AS `grade_level_id`,`e`.`enrollment_status` AS `enrollment_status`,`e`.`academic_year_id` AS `academic_year_id`,`gl`.`grade_level_name` AS `grade_level_name`,`gl`.`grade_level_code` AS `grade_level_code`,`ay`.`year_label` AS `academic_year_label`,`ay`.`is_active` AS `year_is_active`,`b`.`barangay_name` AS `barangay_name`,`c`.`id` AS `city_id`,`c`.`city_name` AS `city_name`,`p`.`id` AS `province_id`,`p`.`province_name` AS `province_name`,`r`.`id` AS `region_id`,`r`.`region_name` AS `region_name`,`co`.`id` AS `country_id`,`co`.`country_name` AS `country_name`,timestampdiff(YEAR,`s`.`birthdate`,curdate()) AS `age`,concat_ws(', ',nullif(`s`.`street_name`,''),nullif(`b`.`barangay_name`,''),nullif(`c`.`city_name`,''),nullif(`p`.`province_name`,''),nullif(`r`.`region_name`,''),nullif(`co`.`country_name`,'')) AS `full_address` from ((((((((`tblstudents` `s` left join `tblacademicyear` `ay` on(`ay`.`is_active` = 1)) left join `tblenrollment` `e` on(`e`.`student_id` = `s`.`id` and `e`.`academic_year_id` = `ay`.`id`)) left join `tblgradelevel` `gl` on(`gl`.`id` = `e`.`grade_level_id`)) left join `tblbarangay` `b` on(`b`.`id` = `s`.`barangay_id`)) left join `tblcity` `c` on(`c`.`id` = `b`.`city_id`)) left join `tblprovince` `p` on(`p`.`id` = `c`.`province_id`)) left join `tblregion` `r` on(`r`.`id` = `p`.`region_id`)) left join `tblcountry` `co` on(`co`.`id` = `r`.`country_id`)) */;



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;

/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;

/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;