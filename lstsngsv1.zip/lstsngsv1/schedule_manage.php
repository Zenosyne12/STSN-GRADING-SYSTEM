<?php

require_once __DIR__ . '/includes/auth.php';     
require_once __DIR__ . '/api/shared/db_connect.php';

$sectionId = isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0;
if ($sectionId <= 0) die('Invalid section.');
?>
<!doctype html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
    <meta charset="utf-8">
    <title>STSN Grading System | Manage Schedule</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <style>
        /* ============================================================
           THEME TOKENS — Light & Dark
           ============================================================ */
        :root,
        [data-bs-theme="light"] {
            --ay-bg: #f3f7fd;
            --ay-card: #ffffff;
            --ay-card-soft: #fafcff;
            --ay-border: #dce8f8;
            --ay-border-soft: #e8f0fb;
            --ay-text: #213a5e;
            --ay-text-strong: #132f62;
            --ay-text-muted: #7a93b8;
            --ay-text-dim: #9ab0c8;
            --ay-label: #3b5e96;
            --ay-head-bg: #f4f8ff;
            --ay-head-text: #3b5e96;
            --ay-row-border: #f0f5fc;
            --ay-row-hover: #f7fbff;
            --ay-input-bg: #ffffff;
            --ay-input-border: #dce8f8;
            --ay-input-text: #213a5e;

            --ay-pill-bg: #f0f6ff;
            --ay-pill-border: #c5d9f8;
            --ay-pill-text: #1a4a9a;
            --ay-pill-day: #1248a8;
            --ay-pill-sep: #a0b8d8;
            --ay-pill-time: #2e5b9a;

            --ay-warn-icon: #f59e0b;

            --ay-btn-light-bg: #ffffff;
            --ay-btn-light-text: #1248a8;
            --ay-btn-light-border: #b8d0fa;
            --ay-btn-light-hover-bg: #eef4ff;
            --ay-btn-light-hover-border: #8db5f7;

            --ay-btn-warning-bg: #fff7e8;
            --ay-btn-warning-text: #9a6200;
            --ay-btn-warning-border: #f6d28b;
            --ay-btn-warning-hover-bg: #ffefc7;
            --ay-btn-warning-hover-border: #efc361;

            --ay-btn-danger-bg: #fff0f1;
            --ay-btn-danger-text: #b42318;
            --ay-btn-danger-border: #f5b5ba;
            --ay-btn-danger-hover-bg: #ffe2e4;
            --ay-btn-danger-hover-border: #eb8f97;

            --ay-badge-active-bg: #e6f0ff;
            --ay-badge-active-text: #1248a8;
            --ay-badge-active-border: #b8d0fa;
            --ay-badge-inactive-bg: #f3f5f8;
            --ay-badge-inactive-text: #7a8ea8;
            --ay-badge-inactive-border: #dde4ee;
        }

        [data-bs-theme="dark"] {
            --ay-bg: #1a1a1a;
            --ay-card: #2D2D2D;
            --ay-card-soft: #262626;
            --ay-border: #3a3a3a;
            --ay-border-soft: #3a3a3a;
            --ay-text: #e4e6e8;
            --ay-text-strong: #ffffff;
            --ay-text-muted: #adb5bd;
            --ay-text-dim: #8b939a;
            --ay-label: #ffffff;
            --ay-head-bg: #2D2D2D;
            --ay-head-text: #e8eef7;
            --ay-row-border: #3a3a3a;
            --ay-row-hover: #343434;
            --ay-input-bg: #1f1f1f;
            --ay-input-border: #3a3a3a;
            --ay-input-text: #e4e6e8;

            --ay-pill-bg: #1e2a3d;
            --ay-pill-border: #2d4366;
            --ay-pill-text: #8ab4f8;
            --ay-pill-day: #8ab4f8;
            --ay-pill-sep: #5a7095;
            --ay-pill-time: #a5ccff;

            --ay-warn-icon: #fbbf24;

            --ay-btn-light-bg: #3a3a3a;
            --ay-btn-light-text: #8ab4f8;
            --ay-btn-light-border: #4a5a6e;
            --ay-btn-light-hover-bg: #4a4a4a;
            --ay-btn-light-hover-border: #6a7a8e;

            --ay-btn-warning-bg: #3a2f14;
            --ay-btn-warning-text: #ffcc66;
            --ay-btn-warning-border: #5c4820;
            --ay-btn-warning-hover-bg: #4a3c18;
            --ay-btn-warning-hover-border: #6e5830;

            --ay-btn-danger-bg: #3a1f24;
            --ay-btn-danger-text: #ff8b9e;
            --ay-btn-danger-border: #5c2d35;
            --ay-btn-danger-hover-bg: #4a262c;
            --ay-btn-danger-hover-border: #6e3640;

            --ay-badge-active-bg: #1e2a3d;
            --ay-badge-active-text: #8ab4f8;
            --ay-badge-active-border: #2d4366;
            --ay-badge-inactive-bg: #3a3a3a;
            --ay-badge-inactive-text: #a9b8cd;
            --ay-badge-inactive-border: #4a5a6e;
        }

        body { background: var(--ay-bg); color: var(--ay-text); }

        /* ============================================================
           PAGE HEADER (keep blue gradient)
           ============================================================ */
        .ay-page-header {
            background: linear-gradient(130deg,#1248a8 0%,#1a6ef5 100%);
            border-radius: 16px; padding: 1.4rem 1.6rem; color: #fff;
            margin-bottom: 1.25rem; display: flex; flex-wrap: wrap;
            align-items: center; justify-content: space-between; gap: 1rem;
        }
        .ay-page-header h3 { font-size:1.25rem; font-weight:700; margin:0 0 .2rem; }
        .ay-page-header p  { margin:0; font-size:.88rem; opacity:.85; }
        .ay-active-chip {
            display:inline-flex; align-items:center; gap:.45rem;
            background:rgba(255,255,255,.15); border:1.5px solid rgba(255,255,255,.3);
            border-radius:999px; padding:.45rem 1rem; font-size:.88rem; font-weight:700; color:#fff;
        }

        /* ============================================================
           CARDS
           ============================================================ */
        .ay-card {
            background: var(--ay-card); border: 1px solid var(--ay-border);
            border-radius:16px;
            box-shadow:0 2px 12px rgba(18,72,168,.06);
            overflow:hidden; margin-bottom:1.5rem;
        }
        [data-bs-theme="dark"] .ay-card {
            box-shadow: 0 2px 12px rgba(0,0,0,.35);
        }
        .ay-card-header {
            padding:1.1rem 1.4rem; border-bottom:1px solid var(--ay-border-soft);
            display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between;
            gap:.75rem; background:var(--ay-card);
        }
        .ay-card-title    { font-size:1rem; font-weight:700; color:var(--ay-text-strong); margin:0 0 .15rem; }
        .ay-card-subtitle { font-size:.8rem; color:var(--ay-text-muted); margin:0; }
        .ay-card-body     { padding:1.2rem 1.3rem; }

        /* ============================================================
           INFO GRID — labels visible on dark
           ============================================================ */
        .ay-info-grid { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:1rem; }
        .ay-info-label { font-size:.83rem; font-weight:700; color:var(--ay-label); margin-bottom:.45rem; }

        /* Robust dark mode label visibility (all mechanisms) */
        [data-bs-theme="dark"] .ay-info-label,
        html[data-bs-theme="dark"] .ay-info-label,
        body[data-bs-theme="dark"] .ay-info-label,
        html.dark .ay-info-label,
        html.dark-mode .ay-info-label,
        body.dark .ay-info-label,
        body.dark-mode .ay-info-label {
            color: #ffffff !important;
        }

        .ay-info-value {
            min-height:46px; display:flex; align-items:center;
            padding:.65rem .9rem; border:1px solid var(--ay-border); border-radius:12px;
            background:var(--ay-card); box-shadow:0 2px 8px rgba(18,72,168,.04);
            font-weight:600; color:var(--ay-text-strong);
        }
        [data-bs-theme="dark"] .ay-info-value {
            box-shadow: 0 2px 8px rgba(0,0,0,.25);
            color: #ffffff !important;
        }

        /* ============================================================
           BUTTONS
           ============================================================ */
        .btn-ay {
            font-weight:600; font-size:.82rem; border-radius:8px; padding:.42rem .9rem;
            cursor:pointer; transition:all .15s; border:1.5px solid transparent;
            line-height:1.4; text-decoration:none;
            display:inline-flex; align-items:center; justify-content:center; gap:.35rem;
        }
        .btn-ay-primary { background:linear-gradient(130deg,#1a6ef5,#1248a8); color:#fff; box-shadow:0 2px 8px rgba(26,110,245,.2); }
        .btn-ay-primary:hover { background:linear-gradient(130deg,#1560d8,#103d90); color:#fff; }

        .btn-ay-warning { background:var(--ay-btn-warning-bg); color:var(--ay-btn-warning-text); border-color:var(--ay-btn-warning-border); }
        .btn-ay-warning:hover { background:var(--ay-btn-warning-hover-bg); color:var(--ay-btn-warning-text); border-color:var(--ay-btn-warning-hover-border); }

        .btn-ay-danger  { background:var(--ay-btn-danger-bg); color:var(--ay-btn-danger-text); border-color:var(--ay-btn-danger-border); }
        .btn-ay-danger:hover  { background:var(--ay-btn-danger-hover-bg); color:var(--ay-btn-danger-text); border-color:var(--ay-btn-danger-hover-border); }

        .btn-ay-light   { background:var(--ay-btn-light-bg); color:var(--ay-btn-light-text); border-color:var(--ay-btn-light-border); }
        .btn-ay-light:hover   { background:var(--ay-btn-light-hover-bg); border-color:var(--ay-btn-light-hover-border); color:var(--ay-btn-light-text); }

        .btn-ay-ghost   { background:transparent; color:var(--ay-btn-danger-text); border-color:transparent; padding:.28rem .5rem; }
        .btn-ay-ghost:hover   { background:var(--ay-btn-danger-bg); border-color:var(--ay-btn-danger-border); }

        /* ============================================================
           SCHEDULE FORM MODAL — already has blue gradient header
           ============================================================ */
        #scheduleFormModal .modal-content {
            border-radius: 14px; border: none; overflow: hidden;
            background: var(--ay-card);
        }
        #scheduleFormModal .modal-header {
            background: linear-gradient(135deg, #0b3d91 0%, #1457b8 52%, #1d75e8 100%);
            color: #fff; border-bottom: none;
        }
        #scheduleFormModal .modal-title { color: #fff; font-weight: 700; }
        #scheduleFormModal .ay-modal-subtitle { color: #d7e8ff; font-size: 0.82rem; margin-top: 0.25rem; }
        #scheduleFormModal .modal-header .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%); opacity: 1;
        }
        #scheduleFormModal .modal-header i { color: #fff; }

        #scheduleFormModal .modal-body {
            background: var(--ay-card);
            color: var(--ay-text);
        }
        #scheduleFormModal .modal-footer {
            background: var(--ay-card-soft);
            border-top: 1px solid var(--ay-border-soft);
        }

        /* Force dark styles for form controls inside the modal */
        [data-bs-theme="dark"] #scheduleFormModal .form-control,
        [data-bs-theme="dark"] #scheduleFormModal .form-select {
            background: #1f1f1f !important;
            border-color: #3a3a3a !important;
            color: #e4e6e8 !important;
        }
        [data-bs-theme="dark"] #scheduleFormModal .form-control::placeholder {
            color: #8b939a !important;
            opacity: 1 !important;
        }
        [data-bs-theme="dark"] #scheduleFormModal .form-select option {
            background: #1f1f1f !important;
            color: #e4e6e8 !important;
        }
        [data-bs-theme="dark"] #scheduleFormModal .form-label {
            color: #ffffff !important;
        }
        [data-bs-theme="dark"] #scheduleFormModal .form-control:focus,
        [data-bs-theme="dark"] #scheduleFormModal .form-select:focus {
            background: #1f1f1f !important;
            border-color: #1a6ef5 !important;
            color: #ffffff !important;
            box-shadow: 0 0 0 3px rgba(26,110,245,.3) !important;
        }
        /* Date picker icon visible in dark */
        [data-bs-theme="dark"] #scheduleFormModal input[type="time"]::-webkit-calendar-picker-indicator {
            filter: invert(1);
            cursor: pointer;
        }

        /* ============================================================
           BADGES
           ============================================================ */
        .ay-badge {
            display:inline-flex; align-items:center; gap:.3rem;
            padding:.32rem .75rem; border-radius:999px; font-size:.78rem; font-weight:700;
        }
        .ay-badge-active   { background:var(--ay-badge-active-bg); color:var(--ay-badge-active-text); border:1.5px solid var(--ay-badge-active-border); }
        .ay-badge-inactive { background:var(--ay-badge-inactive-bg); color:var(--ay-badge-inactive-text); border:1.5px solid var(--ay-badge-inactive-border); }

        /* ============================================================
           SCHEDULE PILLS
           ============================================================ */
        .ay-sched-pills { display:flex; flex-direction:column; gap:.3rem; }
        .ay-sched-pill  {
            display:inline-flex; align-items:center; gap:.4rem;
            background:var(--ay-pill-bg); border:1px solid var(--ay-pill-border); border-radius:8px;
            padding:.22rem .6rem; font-size:.78rem; font-weight:600; color:var(--ay-pill-text); white-space:nowrap;
        }
        .ay-sched-pill-day  { font-weight:800; color:var(--ay-pill-day); min-width:2.6rem; }
        .ay-sched-pill-sep  { color:var(--ay-pill-sep); }
        .ay-sched-pill-time { color:var(--ay-pill-time); }

        /* ============================================================
           TABLE
           ============================================================ */
        .ay-table { width:100%; border-collapse:collapse; background:var(--ay-card); }
        .ay-table thead th {
            background:var(--ay-head-bg); color:var(--ay-head-text); font-size:.75rem; font-weight:700;
            text-transform:uppercase; letter-spacing:.06em; padding:.85rem 1rem;
            border-bottom:1.5px solid var(--ay-border); white-space:nowrap; text-align:center;
        }
        .ay-table tbody tr:not(:last-child) td { border-bottom:1px solid var(--ay-row-border); }
        .ay-table tbody tr:hover td { background:var(--ay-row-hover); }
        .ay-table tbody td {
            padding:.95rem 1rem; font-size:.92rem; color:var(--ay-text);
            vertical-align:middle; text-align:center; background:var(--ay-card);
        }
        [data-bs-theme="dark"] .ay-table tbody td { color: #ffffff !important; }
        .ay-left { text-align:left !important; }

        /* ============================================================
           DAY ROWS
           ============================================================ */
        .ay-day-rows { display:flex; flex-direction:column; gap:.55rem; }
        .ay-day-row {
            display:grid; grid-template-columns:1fr 1fr 1fr auto;
            gap:.5rem; align-items:center;
            background: var(--ay-card-soft); border:1.5px solid var(--ay-border);
            border-radius:12px; padding:.6rem .75rem;
            transition: border-color .15s;
        }
        .ay-day-row:focus-within { border-color:#8db5f7; }
        .ay-day-row select,
        .ay-day-row input[type="time"] {
            border:1.5px solid var(--ay-border); border-radius:8px; padding:.38rem .55rem;
            font-size:.85rem; color:var(--ay-input-text); background:var(--ay-input-bg); outline:none; width:100%;
            transition: border-color .15s;
        }
        .ay-day-row select:focus,
        .ay-day-row input[type="time"]:focus { border-color:#1a6ef5; }
        [data-bs-theme="dark"] .ay-day-row select option {
            background: #1f1f1f;
            color: #e4e6e8;
        }
        .ay-day-row-label { font-size:.72rem; font-weight:700; color:var(--ay-text-muted); text-transform:uppercase; letter-spacing:.05em; }

        /* ============================================================
           CONFIRM OVERLAY — SMOOTH FADE + SCALE ANIMATION
           ============================================================ */
        .ay-confirm-overlay {
            position: fixed; inset: 0;
            background: rgba(7, 22, 48, 0.22);
            display: flex; align-items: center; justify-content: center;
            z-index: 2000; padding: 1rem;

            /* hidden state */
            opacity: 0;
            visibility: hidden;
            pointer-events: none;
            backdrop-filter: blur(0px);
            -webkit-backdrop-filter: blur(0px);
            transition:
                opacity .22s ease,
                backdrop-filter .22s ease,
                -webkit-backdrop-filter .22s ease,
                visibility 0s linear .24s;
        }
        [data-bs-theme="dark"] .ay-confirm-overlay {
            background: rgba(0, 0, 0, 0.55);
        }
        .ay-confirm-overlay.show {
            opacity: 1;
            visibility: visible;
            pointer-events: auto;
            backdrop-filter: blur(3px);
            -webkit-backdrop-filter: blur(3px);
            transition:
                opacity .22s ease,
                backdrop-filter .22s ease,
                -webkit-backdrop-filter .22s ease,
                visibility 0s linear 0s;
        }

        .ay-confirm-dialog {
            width: min(480px, calc(100vw - 2rem));
            border-radius: 12px;
            background: var(--ay-card);
            box-shadow: 0 16px 40px rgba(0,0,0,0.28);
            overflow: hidden;
            border: 1px solid var(--ay-border);

            /* hidden state: slight scale + slide-down */
            transform: translateY(-14px) scale(.94);
            opacity: 0;
            transition:
                transform .28s cubic-bezier(.18,.9,.32,1.18),
                opacity   .22s ease;
        }
        .ay-confirm-overlay.show .ay-confirm-dialog {
            transform: translateY(0) scale(1);
            opacity: 1;
        }

        .ay-confirm-title {
            background: linear-gradient(135deg, #0b3d91 0%, #1457b8 52%, #1d75e8 100%);
            color: #fff; padding: .85rem 1rem;
            font-size: 1rem; font-weight: 700; letter-spacing: .02em;
            border-bottom: 1px solid rgba(255,255,255,.2);
            display: flex; align-items: center; gap: .65rem;
        }
        .ay-confirm-title-icon {
            width: 34px; height: 34px; border-radius: 50%;
            background: rgba(255,255,255,0.16);
            border: 1.5px solid rgba(255,255,255,0.8);
            display: flex; align-items: center; justify-content: center;
            color: #fff; font-size: 1rem;
            box-shadow: 0 0 0 2px rgba(255,255,255,0.08);
        }
        .ay-confirm-message {
            padding: 1rem 1rem .75rem;
            color: var(--ay-text); font-size: .93rem; line-height: 1.55;
        }
        .ay-confirm-actions {
            padding: .85rem 1rem 1rem;
            display: flex; justify-content: flex-end; align-items: center; gap: .6rem;
            background: var(--ay-card-soft); border-top: 1px solid var(--ay-border);
        }
        .ay-confirm-actions .btn-ay { min-width: 84px; }

        /* ============================================================
           ADD DAY BUTTON
           ============================================================ */
        .ay-add-day-btn {
            display:flex; align-items:center; justify-content:center; gap:.4rem;
            background:var(--ay-pill-bg); border:1.5px dashed var(--ay-pill-border);
            border-radius:10px; color:var(--ay-pill-text);
            font-size:.83rem; font-weight:700; padding:.5rem 1rem;
            cursor:pointer; transition:all .15s; width:100%;
        }
        .ay-add-day-btn:hover { background: var(--ay-pill-bg); filter: brightness(.95); border-color:#5a96f0; }

        /* ============================================================
           MOBILE CARDS
           ============================================================ */
        .ay-mobile-card {
            background:var(--ay-card); border:1.5px solid var(--ay-border);
            border-radius:14px; overflow:hidden;
            box-shadow:0 1px 6px rgba(18,72,168,.05);
        }
        .ay-mobile-card + .ay-mobile-card { margin-top:.75rem; }
        .ay-mobile-card-header {
            display:flex; align-items:center; justify-content:space-between;
            padding:.85rem 1rem; border-bottom:1px solid var(--ay-border-soft); background:var(--ay-card-soft); gap:.75rem;
        }
        .ay-mobile-card-title { font-weight:700; color:var(--ay-text-strong); font-size:.95rem; }
        .ay-mobile-card-body  { padding:.85rem 1rem; }
        .ay-mobile-row { display:flex; justify-content:space-between; gap:.75rem; padding:.25rem 0; font-size:.9rem; flex-wrap:wrap; color: var(--ay-text); }
        .ay-mobile-label { color:var(--ay-text-muted); font-weight:600; flex-shrink:0; }
        .ay-mobile-actions { display:grid; gap:.5rem; padding:0 1rem 1rem; }

        /* ============================================================
           EMPTY STATE
           ============================================================ */
        .ay-empty { text-align:center; padding:2.4rem 1.5rem; color:var(--ay-text-dim); }
        .ay-empty i { font-size:2.2rem; display:block; margin-bottom:.6rem; opacity:.5; }
        .ay-empty p { margin:0; font-size:.95rem; }
        [data-bs-theme="dark"] .ay-empty { color: #8b939a !important; }
        [data-bs-theme="dark"] .ay-empty i { color: #8b939a !important; }

        /* ============================================================
           GENERIC MODAL
           ============================================================ */
        .ay-modal .modal-content {
            border:0; border-radius:16px;
            box-shadow:0 8px 32px rgba(18,72,168,.16);
            overflow:hidden; background: var(--ay-card);
        }
        .ay-modal .modal-header  { background:var(--ay-head-bg); border-bottom:1px solid var(--ay-border); padding:1rem 1.25rem; }
        .ay-modal .modal-title   { font-size:1rem; font-weight:700; color:var(--ay-text-strong); }
        .ay-modal-subtitle       { font-size:.82rem; color:var(--ay-text-muted); }
        .ay-modal .modal-body    { background:var(--ay-card); padding:1.2rem; color: var(--ay-text); }
        .ay-modal .modal-footer  { padding:.95rem 1.2rem; border-top:1px solid var(--ay-border-soft); background:var(--ay-card-soft); }

        /* ============================================================
           COLUMN HEADERS
           ============================================================ */
        .ay-col-headers {
            display:grid; grid-template-columns:1fr 1fr 1fr auto;
            gap:.5rem; padding:0 .75rem .3rem;
        }

        /* ============================================================
           ADVISER WARNING ICON — Phosphor, dynamic color
           ============================================================ */
        .ay-adviser-warn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: var(--ay-warn-icon);
            transition: color .18s ease;
        }
        .ay-adviser-warn svg {
            width: 1.15rem;
            height: 1.15rem;
            display: block;
            color: currentColor;
        }

        /* ============================================================
           FORM CONTROLS (global dark mode)
           ============================================================ */
        .form-select, .form-control {
            color: var(--ay-input-text);
            background-color: var(--ay-input-bg);
            border-color: var(--ay-input-border);
        }
        .form-control::placeholder { color: var(--ay-text-muted); }

        [data-bs-theme="dark"] .form-select,
        [data-bs-theme="dark"] .form-control {
            color: #e4e6e8;
            background-color: #1f1f1f;
            border-color: #3a3a3a !important;
        }
        [data-bs-theme="dark"] .form-control::placeholder { color: #8b939a; opacity: 1; }
        [data-bs-theme="dark"] .form-select option { background: #1f1f1f; color: #e4e6e8; }
        [data-bs-theme="dark"] .form-label { color: #ffffff; }

        /* Input group border-radius fix inside dark */
        [data-bs-theme="dark"] #adviserTeacherId {
            background: #1f1f1f !important;
            color: #e4e6e8 !important;
            border-color: #3a3a3a !important;
        }
        [data-bs-theme="dark"] #adviserTeacherId option {
            background: #1f1f1f;
            color: #e4e6e8;
        }

        /* ============================================================
           RESPONSIVE
           ============================================================ */
        @media (max-width:991.98px) { .ay-info-grid { grid-template-columns:1fr; } }
        @media (max-width:767.98px) {
            .ay-page-header { padding:1.1rem 1.2rem; border-radius:14px; }
            .ay-day-row { grid-template-columns:1fr 1fr; }
            .ay-day-row > select:first-child { grid-column:1 / -1; }
            .ay-col-headers { display:none; }
        }

        /* Accessibility: respect prefers-reduced-motion */
        @media (prefers-reduced-motion: reduce) {
            .ay-confirm-overlay,
            .ay-confirm-dialog {
                transition: none !important;
            }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3">

                <div class="page-header">
                    <div>
                        <h3><i class="bi bi-calendar-check me-2"></i>Manage Section Schedule</h3>
                        <p>Assign advisers and manage subject schedule records for the selected section.</p>
                    </div>
                </div>

                <?php require_once __DIR__ . '/includes/breadcrumb.php'; renderBreadcrumb([
                    ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'],
                    ['label' => 'Maintenance', 'href' => 'schedule.php', 'icon' => 'bi bi-tools'],
                    ['label' => 'Scheduling', 'href' => 'schedule.php', 'icon' => 'bi bi-calendar-week'],
                    ['label' => 'Manage', 'icon' => 'bi bi-calendar-check']
                ]); ?>
                <div class="row">
                    <div class="col-lg-7 d-flex">
                        <div class="ay-card w-100">
                            <div class="ay-card-header">
                                <div>
                                    <p class="ay-card-title">Section Information</p>
                                    <p class="ay-card-subtitle">Basic information for the selected section.</p>
                                </div>
                            </div>
                            <div class="ay-card-body">
                                <div class="ay-info-grid">
                                    <div>
                                        <div class="ay-info-label">Grade Level</div>
                                        <div id="infoGradeLevel" class="ay-info-value">-</div>
                                    </div>
                                    <div>
                                        <div class="ay-info-label">Section Name</div>
                                        <div id="infoSectionName" class="ay-info-value">-</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-5 d-flex">
                        <div class="ay-card w-100">
                            <div class="ay-card-header">
                                <div>
                                    <p class="ay-card-title">Academic Setup</p>
                                    <p class="ay-card-subtitle">Assign the section adviser for the active academic year.</p>
                                </div>
                            </div>
                            <div class="ay-card-body">
                                <div class="d-none"><select id="academicYearId"></select></div>
                                <div>
                                    <label class="form-label fw-bold">Section Adviser</label>
                                    <div class="input-group">
                                        <div class="position-relative" style="flex:1 1 auto;">
                                            <select class="form-select" id="adviserTeacherId" style="border-radius:10px 0 0 10px;padding-right:2.8rem;"></select>
                                            <!-- Phosphor warning icon — dynamic color via currentColor -->
                                            <span id="adviserWarning" class="d-none ay-adviser-warn"
                                                  style="position:absolute;right:34px;top:50%;transform:translateY(-50%);z-index:4;cursor:default;pointer-events:none;"
                                                  title="No adviser assigned yet">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256" fill="currentColor" aria-hidden="true">
                                                    <path d="M236.8,188.09,149.35,36.22h0a24.76,24.76,0,0,0-42.7,0L19.2,188.09a23.51,23.51,0,0,0,0,23.72A24.35,24.35,0,0,0,40.55,224h174.9a24.35,24.35,0,0,0,21.33-12.19A23.51,23.51,0,0,0,236.8,188.09ZM120,104a8,8,0,0,1,16,0v40a8,8,0,0,1-16,0Zm8,88a12,12,0,1,1,12-12A12,12,0,0,1,128,192Z"/>
                                                </svg>
                                            </span>
                                        </div>
                                        <button class="btn-ay btn-ay-primary" type="button" onclick="saveAdviser()" style="border-radius:0 10px 10px 0;">
                                            <i class="bi bi-save"></i> Set Adviser
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="ay-card">
                    <div class="ay-card-header">
                        <div>
                            <p class="ay-card-title">Schedule Entries</p>
                            <p class="ay-card-subtitle">Grouped by subject &amp; teacher. Each entry can span multiple days with different times.</p>
                        </div>
                        <div class="d-flex flex-wrap gap-2">
                            <button class="btn-ay btn-ay-primary" type="button" id="autoGenerateBtn" onclick="autoGenerateSchedule()">
                                <i class="bi bi-wand2"></i> Auto Generate
                            </button>
                            <button class="btn-ay btn-ay-primary" type="button" onclick="openScheduleForm()">
                                <i class="bi bi-plus-circle"></i> New Schedule
                            </button>
                        </div>
                    </div>

                    <div class="table-responsive d-none d-md-block">
                        <table class="ay-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Subject</th>
                                    <th>Teacher</th>
                                    <th>Days &amp; Times</th>
                                    <th>Room</th>
                                    <th>Status</th>
                                    <th style="width:200px;">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="scheduleTableBody">
                                <tr><td colspan="7"><div class="ay-empty"><i class="bi bi-hourglass-split"></i><p>Loading schedules...</p></div></td></tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="d-block d-md-none p-3" id="scheduleCardView"></div>
                </div>

            </div>
        </div>
    </main>
    <?php require_once("includes/footer.php"); ?>
</div>


<div class="modal fade ay-modal" id="scheduleFormModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="false">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <form id="scheduleForm" novalidate>
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title" id="scheduleFormTitle">Add Schedule</h5>
                        <div class="ay-modal-subtitle">Select a subject &amp; teacher, then add one row per day with its own time.</div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <input type="hidden" id="scheduleGroupIds">
                    <div id="scheduleConflictAlert" class="alert alert-danger d-none" role="alert"></div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Subject <span class="text-danger">*</span></label>
                            <select class="form-select" id="subjectId">
                                <option value="">Select Subject</option>
                            </select>
                            <div id="subjectValidation" class="text-danger mt-1" style="font-size:.8rem;display:none;">Please select a subject.</div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Teacher <span class="text-danger">*</span></label>
                            <select class="form-select" id="teacherId">
                                <option value="">Select Teacher</option>
                            </select>
                            <div id="teacherValidation" class="text-danger mt-1" style="font-size:.8rem;display:none;">Please select a teacher.</div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Room</label>
                            <input type="text" class="form-control" id="room" placeholder="e.g. Room 101">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Status</label>
                            <select class="form-select" id="isActive">
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label class="form-label mb-1">Days &amp; Times <span class="text-danger">*</span></label>
                        <div class="ay-col-headers">
                            <span class="ay-day-row-label">Day</span>
                            <span class="ay-day-row-label">Start Time</span>
                            <span class="ay-day-row-label">End Time</span>
                            <span></span>
                        </div>
                        <div class="ay-day-rows" id="dayRowsContainer"></div>
                        <button type="button" class="ay-add-day-btn mt-2" onclick="addDayRow()">
                            <i class="bi bi-plus-circle"></i> Add Another Day
                        </button>
                        <div id="dayRowsValidation" class="text-danger mt-1" style="font-size:.8rem;display:none;">
                            Please add at least one day with a complete time range.
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn-ay btn-ay-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn-ay btn-ay-primary" id="saveScheduleBtn"><i class="bi bi-save"></i> Save Schedule</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="autoGenerateConfirmOverlay" class="ay-confirm-overlay" aria-hidden="true">
    <div class="ay-confirm-dialog">
        <div class="ay-confirm-title">
            <span class="ay-confirm-title-icon"><i class="bi bi-info-circle-fill"></i></span>
            <span>Auto Generate</span>
        </div>
        <div class="ay-confirm-message">Auto-generate schedule entries for this section? Existing scheduled subjects will be skipped.</div>
        <div class="ay-confirm-actions">
            <button type="button" class="btn-ay btn-ay-primary" id="autoGenerateConfirmOk">OK</button>
            <button type="button" class="btn-ay btn-ay-light" id="autoGenerateConfirmCancel">Cancel</button>
        </div>
    </div>
</div>

<!-- ============================================================
     ADVISER REMOVE CONFIRM — matches system's confirm style
     ============================================================ -->
<div id="adviserRemoveConfirmOverlay" class="ay-confirm-overlay" aria-hidden="true">
    <div class="ay-confirm-dialog">
        <div class="ay-confirm-title">
            <span class="ay-confirm-title-icon"><i class="bi bi-exclamation-triangle-fill"></i></span>
            <span>Remove Adviser</span>
        </div>
        <div class="ay-confirm-message">Remove the adviser from this section for the selected academic year?</div>
        <div class="ay-confirm-actions">
            <button type="button" class="btn-ay btn-ay-primary" id="adviserRemoveConfirmOk">OK</button>
            <button type="button" class="btn-ay btn-ay-light" id="adviserRemoveConfirmCancel">Cancel</button>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>
<script>
const SECTION_ID = <?php echo (int)$sectionId; ?>;
let currentSectionInfo = null;

const DAYS      = ['Monday','Tuesday','Wednesday','Thursday','Friday'];
const DAY_SHORT = { Monday:'Mon', Tuesday:'Tue', Wednesday:'Wed', Thursday:'Thu', Friday:'Fri' };
const DAY_ORDER = { Monday:0, Tuesday:1, Wednesday:2, Thursday:3, Friday:4 };

let hasScheduleConflict = false;
let conflictCheckTimer = null;
let conflictCheckToken = 0;


function esc(s) {
    return (s ?? '').toString()
        .replaceAll('&','&amp;').replaceAll('<','&lt;')
        .replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;');
}

function fmt12(t) {
    if (!t) return '-';
    const parts = t.split(':').map(Number);
    const h = parts[0], m = parts[1];
    return `${h % 12 || 12}:${String(m).padStart(2,'0')} ${h >= 12 ? 'PM' : 'AM'}`;
}

function showAlert(msg, type = 'success') {
    const cfg = {
        success: { title:'Success', color:'blue',   icon:'bi bi-check-circle-fill' },
        danger:  { title:'Error',   color:'red',    icon:'bi bi-exclamation-octagon-fill' },
        warning: { title:'Warning', color:'yellow', icon:'bi bi-exclamation-triangle-fill' },
        info:    { title:'Info',    color:'blue',   icon:'bi bi-info-circle-fill' }
    };
    const s = cfg[type] || cfg.success;
    iziToast.show({
        title: s.title, message: msg, color: s.color, icon: s.icon,
        iconColor: '#fff', theme: 'light', position: 'topRight', timeout: 4000,
        progressBar: true, close: true, pauseOnHover: true, drag: true,
        transitionIn: 'fadeInDown', transitionOut: 'fadeOutUp', maxWidth: 420
    });
}

async function fetchJson(url, opts = {}) {
    const res  = await fetch(url, opts);
    const text = await res.text();
    try { return JSON.parse(text); }
    catch(e) { console.error('Bad JSON from:', url, '\nRaw response:', text); throw new Error('Invalid server response'); }
}

/* ---- Generic smooth overlay open/close ---- */
function openOverlay(overlay) {
    overlay.classList.add('show');
    overlay.setAttribute('aria-hidden', 'false');
}
function closeOverlay(overlay, cb) {
    overlay.classList.remove('show');
    overlay.setAttribute('aria-hidden', 'true');
    // Wait for exit transition (~220ms) before firing callback
    if (typeof cb === 'function') setTimeout(cb, 160);
}


function dayOptions(selected = '') {
    return DAYS.map(d =>
        `<option value="${d}"${d === selected ? ' selected' : ''}>${d}</option>`
    ).join('');
}

function addDayRow(day = '', timeStart = '', timeEnd = '') {
    const div = document.createElement('div');
    div.className = 'ay-day-row';
    div.innerHTML = `
        <select class="day-select">
            <option value="">Select Day</option>
            ${dayOptions(day)}
        </select>
        <input type="time" class="time-start" value="${esc(timeStart)}">
        <input type="time" class="time-end"   value="${esc(timeEnd)}">
        <button type="button" class="btn-ay btn-ay-ghost" onclick="removeDayRow(this)" title="Remove row">
            <i class="bi bi-x-lg"></i>
        </button>`;
    document.getElementById('dayRowsContainer').appendChild(div);

    const scheduleCheck = () => queueScheduleConflictCheck();
    div.querySelector('.day-select').addEventListener('change', scheduleCheck);
    div.querySelector('.time-start').addEventListener('input', scheduleCheck);
    div.querySelector('.time-start').addEventListener('change', scheduleCheck);
    div.querySelector('.time-start').addEventListener('blur', scheduleCheck);
    div.querySelector('.time-end').addEventListener('input', scheduleCheck);
    div.querySelector('.time-end').addEventListener('change', scheduleCheck);
    div.querySelector('.time-end').addEventListener('blur', scheduleCheck);
}

function removeDayRow(btn) {
    if (document.querySelectorAll('#dayRowsContainer .ay-day-row').length <= 1) {
        showAlert('At least one day is required.', 'warning');
        return;
    }
    btn.closest('.ay-day-row').remove();
    queueScheduleConflictCheck();
}

function clearDayRows() {
    document.getElementById('dayRowsContainer').innerHTML = '';
}

function getDayRows() {
    return [...document.querySelectorAll('#dayRowsContainer .ay-day-row')].map(row => ({
        day:       row.querySelector('.day-select').value.trim(),
        timeStart: row.querySelector('.time-start').value.trim(),
        timeEnd:   row.querySelector('.time-end').value.trim(),
    }));
}

function getExcludedScheduleIds() {
    const value = document.getElementById('scheduleGroupIds').value.trim();
    if (!value) return [];
    return value.split(',').map(Number).filter(Boolean);
}

function setScheduleSaveDisabled(disabled) {
    const btn = document.getElementById('saveScheduleBtn');
    if (btn) btn.disabled = disabled;
}

function hideScheduleConflictAlert() {
    const alert = document.getElementById('scheduleConflictAlert');
    alert.classList.add('d-none');
    alert.innerHTML = '';
}

function showScheduleConflictAlert(message) {
    const alert = document.getElementById('scheduleConflictAlert');
    alert.classList.remove('d-none');
    alert.innerHTML = `<i class="bi bi-exclamation-triangle-fill me-1"></i>${esc(message)}`;
}

function resetScheduleConflictState() {
    hasScheduleConflict = false;
    conflictCheckToken++;
    if (conflictCheckTimer) {
        clearTimeout(conflictCheckTimer);
        conflictCheckTimer = null;
    }
    hideScheduleConflictAlert();
    setScheduleSaveDisabled(false);
}

function queueScheduleConflictCheck() {
    hasScheduleConflict = false;
    hideScheduleConflictAlert();
    setScheduleSaveDisabled(false);
    if (conflictCheckTimer) clearTimeout(conflictCheckTimer);
    conflictCheckTimer = setTimeout(() => {
        runScheduleConflictChecks().catch(err => {
            console.error(err);
            hasScheduleConflict = true;
            showScheduleConflictAlert('Unable to verify schedule conflicts. Please try again.');
            setScheduleSaveDisabled(true);
        });
    }, 250);
}

async function checkScheduleConflict(day, timeStart, timeEnd) {
    return fetchJson('api/schedule/check-conflict.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            section_id: SECTION_ID,
            academic_year_id: document.getElementById('academicYearId').value,
            day_name: day,
            time_start: timeStart,
            time_end: timeEnd,
            exclude_schedule_ids: getExcludedScheduleIds()
        })
    });
}

async function runScheduleConflictChecks() {
    if (conflictCheckTimer) {
        clearTimeout(conflictCheckTimer);
        conflictCheckTimer = null;
    }

    const token = ++conflictCheckToken;
    const rows = getDayRows().filter(r => r.day && r.timeStart && r.timeEnd && r.timeStart < r.timeEnd);

    hasScheduleConflict = false;
    hideScheduleConflictAlert();

    if (!rows.length) {
        setScheduleSaveDisabled(false);
        return true;
    }

    setScheduleSaveDisabled(true);

    for (const row of rows) {
        const data = await checkScheduleConflict(row.day, row.timeStart, row.timeEnd);
        if (token !== conflictCheckToken) return false;

        if (data.error) {
            hasScheduleConflict = true;
            showScheduleConflictAlert(data.error);
            setScheduleSaveDisabled(true);
            return false;
        }

        if (data.has_conflict) {
            hasScheduleConflict = true;
            const teacher = data.conflicting_teacher || 'A teacher';
            const subject = data.conflicting_subject || 'another subject';
            const start = data.conflicting_time_start || row.timeStart;
            const end = data.conflicting_time_end || row.timeEnd;
            showScheduleConflictAlert(`Conflict: ${teacher} is already teaching ${subject} on ${row.day} from ${fmt12(start)} to ${fmt12(end)}.`);
            setScheduleSaveDisabled(true);
            return false;
        }
    }

    hasScheduleConflict = false;
    hideScheduleConflictAlert();
    setScheduleSaveDisabled(false);
    return true;
}


function groupScheduleRows(rows) {
    const map = new Map();
    rows.forEach(r => {
        const key = `${r.subject_id}_${r.teacher_id}`;
        if (!map.has(key)) {
            map.set(key, {
                subject_id:   r.subject_id,
                subject_name: r.subject_name,
                subject_code: r.subject_code,
                teacher_id:   r.teacher_id,
                teacher_name: r.teacher_name,
                room:         r.room,
                is_active:    r.is_active,
                days:         []
            });
        }
        map.get(key).days.push({
            id:         r.id,
            day_name:   r.day_name,    
            time_start: r.time_start,
            time_end:   r.time_end
        });
    });
    return [...map.values()];
}

function renderDayTimePills(days) {
    const sorted = [...days].sort((a, b) =>
        (DAY_ORDER[a.day_name] ?? 9) - (DAY_ORDER[b.day_name] ?? 9)  
    );
    return `<div class="ay-sched-pills">${
        sorted.map(d => `
            <span class="ay-sched-pill">
                <span class="ay-sched-pill-day">${esc(DAY_SHORT[d.day_name] || d.day_name)}</span>
                <span class="ay-sched-pill-sep">|</span>
                <span class="ay-sched-pill-time">${fmt12(d.time_start)} – ${fmt12(d.time_end)}</span>
            </span>`).join('')
    }</div>`;
}


async function loadSectionInfo() {
    try {
        const data = await fetchJson(`api/schedule/fetch_section.php?id=${SECTION_ID}`);
        currentSectionInfo = data.data || data;

        document.getElementById('infoGradeLevel').textContent  = currentSectionInfo.grade_level_name || '-';
        document.getElementById('infoSectionName').textContent = currentSectionInfo.section_name     || '-';

        await loadAdviserTeachers();
        await loadAcademicYears(currentSectionInfo.default_academic_year_id || '');
        loadAdviser();
        loadSchedules();
    } catch(err) {
        console.error(err);
        showAlert('Failed to load section info: ' + err.message, 'danger');
    }
}

function loadAdviserTeachers() {
    return fetchJson('api/schedule/teachers.php').then(data => {
        const list = data.teachers || data.data || [];
        document.getElementById('adviserTeacherId').innerHTML =
            ['<option value="">— No Adviser (Remove) —</option>']
            .concat(list.map(t => `<option value="${t.id}">${esc(t.full_name)}</option>`))
            .join('');
    });
}

/* ---- Adviser warning icon — single source of truth ---- */
function updateAdviserWarning() {
    const tid = document.getElementById('adviserTeacherId').value;
    const warning = document.getElementById('adviserWarning');
    if (!tid) {
        warning.classList.remove('d-none');
    } else {
        warning.classList.add('d-none');
    }
}

/* Live-update warning as user changes dropdown (before clicking Set Adviser) */
document.getElementById('adviserTeacherId').addEventListener('change', updateAdviserWarning);

function loadTeacherOptions(selectedId = '') {
    const sel  = document.getElementById('teacherId');
    const ayId = document.getElementById('academicYearId').value;
    let url = `api/schedule/teachers.php?section_id=${SECTION_ID}`;
    if (ayId) url += `&academic_year_id=${encodeURIComponent(ayId)}`;
    sel.innerHTML = '<option value="">Loading...</option>';
    sel.disabled  = true;
    return fetchJson(url).then(data => {
        const list = data.teachers || data.data || [];
        sel.innerHTML = ['<option value="">Select Teacher</option>']
            .concat(list.map(t =>
                `<option value="${t.id}"${String(selectedId) === String(t.id) ? ' selected' : ''}>${esc(t.full_name)}</option>`
            )).join('');
        if (selectedId && !list.some(t => String(t.id) === String(selectedId))) sel.value = '';
    }).catch(err => {
        sel.innerHTML = '<option value="">Failed to load</option>';
        throw err;
    }).finally(() => { sel.disabled = false; });
}

function loadSubjects(selectedId = '', excludeIds = []) {
    const sel  = document.getElementById('subjectId');
    const ayId = document.getElementById('academicYearId').value;
    const glId = currentSectionInfo?.grade_level_id || '';
    if (!ayId || !glId) {
        sel.innerHTML = '<option value="">No subjects available</option>';
        return Promise.resolve();
    }
    sel.innerHTML = '<option value="">Loading...</option>';
    sel.disabled  = true;
    let url = `api/schedule/subjects.php?section_id=${SECTION_ID}&academic_year_id=${ayId}&grade_level_id=${glId}`;
    excludeIds.forEach(id => { url += `&exclude_schedule_id[]=${encodeURIComponent(id)}`; });
    return fetchJson(url).then(data => {
        const list = data.subjects || data.data || [];
        if (!list.length) {
            sel.innerHTML = '<option value="">No subjects available</option>';
            return;
        }
        sel.innerHTML = ['<option value="">Select Subject</option>']
            .concat(list.map(s =>
                `<option value="${s.id}"${String(selectedId) === String(s.id) ? ' selected' : ''}>${esc(s.subject_name)} (${esc(s.subject_code)})</option>`
            )).join('');
    }).catch(err => {
        sel.innerHTML = '<option value="">Failed to load</option>';
        throw err;
    }).finally(() => { sel.disabled = false; });
}

function loadAcademicYears(selectedId = '') {
    return fetchJson('api/schedule/academic_years.php').then(data => {
        const list = data.academic_years || data.data || [];
        document.getElementById('academicYearId').innerHTML = list.map(y =>
            `<option value="${y.id}"${String(selectedId) === String(y.id) ? ' selected' : ''}>${esc(y.year_label)}${y.is_active == 1 ? ' (Active)' : ''}</option>`
        ).join('');
    });
}

function loadAdviser() {
    const ayId = document.getElementById('academicYearId').value;
    if (!ayId) return;
    fetchJson(`api/schedule/adviser_get.php?section_id=${SECTION_ID}&academic_year_id=${ayId}`)
        .then(data => {
            document.getElementById('adviserTeacherId').value = data.teacher_id || '';
            updateAdviserWarning();
        })
        .catch(err => showAlert('Failed to load adviser: ' + err.message, 'danger'));
}

/* ---- Custom confirm for adviser removal (smooth animation) ---- */
function showAdviserRemoveConfirm(onOk) {
    const overlay   = document.getElementById('adviserRemoveConfirmOverlay');
    const okBtn     = document.getElementById('adviserRemoveConfirmOk');
    const cancelBtn = document.getElementById('adviserRemoveConfirmCancel');

    openOverlay(overlay);

    okBtn.onclick = () => {
        closeOverlay(overlay, onOk);   // fade out first, then run action
    };
    cancelBtn.onclick = () => {
        closeOverlay(overlay);         // just fade out
    };
}

function saveAdviser() {
    const ayId = document.getElementById('academicYearId').value;
    const tid  = document.getElementById('adviserTeacherId').value;
    const isRemoving = !tid;

    if (isRemoving) {
        showAdviserRemoveConfirm(() => performAdviserSave(ayId, null));
        return;
    }
    performAdviserSave(ayId, tid);
}

function performAdviserSave(ayId, teacherId) {
    const isRemoving = teacherId === null;

    fetchJson('api/schedule/adviser_save.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            section_id: SECTION_ID,
            academic_year_id: ayId,
            teacher_id: teacherId   // null = unassign
        })
    }).then(res => {
        if (res.success !== false) {
            showAlert(isRemoving ? 'Adviser removed.' : 'Adviser saved.', 'success');
            updateAdviserWarning();   // instant icon refresh, no page reload
        } else {
            showAlert(res.error || 'Failed.', 'danger');
        }
    }).catch(err => showAlert('Failed: ' + err.message, 'danger'));
}

function autoGenerateSchedule() {
    const ayId = document.getElementById('academicYearId').value;
    const btn = document.getElementById('autoGenerateBtn');

    if (!ayId) {
        showAlert('Please select an academic year first.', 'warning');
        return;
    }

    const overlay = document.getElementById('autoGenerateConfirmOverlay');
    const okBtn = document.getElementById('autoGenerateConfirmOk');
    const cancelBtn = document.getElementById('autoGenerateConfirmCancel');

    openOverlay(overlay);

    const proceed = () => {
        const originalHtml = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm" aria-hidden="true"></span> Generating...';

        fetchJson('api/schedule/auto-generate.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                section_id: SECTION_ID,
                academic_year_id: ayId
            })
        }).then(res => {
            if (res.success !== false) {
                showAlert(res.message || `${res.generated_count || 0} schedules generated successfully.`, 'success');
                loadSchedules();
            } else {
                showAlert(res.error || 'Auto-generation failed.', 'danger');
            }
        }).catch(err => {
            showAlert('Auto-generation failed: ' + err.message, 'danger');
        }).finally(() => {
            btn.disabled = false;
            btn.innerHTML = originalHtml;
        });
    };

    okBtn.onclick = () => closeOverlay(overlay, proceed);
    cancelBtn.onclick = () => closeOverlay(overlay);
}


function loadSchedules() {
    const ayId = document.getElementById('academicYearId').value;
    if (!ayId) return;

    fetchJson(`api/schedule/read.php?section_id=${SECTION_ID}&academic_year_id=${ayId}`)
        .then(data => {
            const rows    = data.schedules || data.data || [];
            const entries = groupScheduleRows(rows);

            const statusBadge = active =>
                String(active) === '1'
                    ? `<span class="ay-badge ay-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                    : `<span class="ay-badge ay-badge-inactive">Inactive</span>`;

            
            document.getElementById('scheduleTableBody').innerHTML = entries.length
                ? entries.map((e, i) => {
                    const gids = e.days.map(d => d.id).join(',');
                    return `<tr>
                        <td>${i + 1}</td>
                        <td class="ay-left">${esc(e.subject_name || '-')}</td>
                        <td>${esc(e.teacher_name || '-')}</td>
                        <td class="ay-left">${renderDayTimePills(e.days)}</td>
                        <td>${esc(e.room || '-')}</td>
                        <td>${statusBadge(e.is_active)}</td>
                        <td>
                            <div class="d-flex justify-content-center gap-2 flex-wrap">
                                <button class="btn-ay btn-ay-warning" type="button"
                                    onclick="editScheduleGroup('${gids}',${e.subject_id},${e.teacher_id})">
                                    <i class="bi bi-pencil-square"></i>
                                </button>
                                <button class="btn-ay btn-ay-danger" type="button"
                                    onclick="deleteScheduleGroup('${gids}')">
                                    <i class="bi bi-trash3"></i>
                                </button>
                            </div>
                        </td>
                    </tr>`;
                }).join('')
                : `<tr><td colspan="7"><div class="ay-empty"><i class="bi bi-calendar-x"></i><p>No schedule entries found.</p></div></td></tr>`;

            
            document.getElementById('scheduleCardView').innerHTML = entries.length
                ? entries.map((e, i) => {
                    const gids = e.days.map(d => d.id).join(',');
                    return `<div class="ay-mobile-card">
                        <div class="ay-mobile-card-header">
                            <span class="ay-mobile-card-title">${i + 1}. ${esc(e.subject_name || '-')}</span>
                            ${statusBadge(e.is_active)}
                        </div>
                        <div class="ay-mobile-card-body">
                            <div class="ay-mobile-row"><span class="ay-mobile-label">Teacher</span><span>${esc(e.teacher_name || '-')}</span></div>
                            <div class="ay-mobile-row"><span class="ay-mobile-label">Days &amp; Times</span><div>${renderDayTimePills(e.days)}</div></div>
                            <div class="ay-mobile-row"><span class="ay-mobile-label">Room</span><span>${esc(e.room || '-')}</span></div>
                        </div>
                        <div class="ay-mobile-actions">
                            <button class="btn-ay btn-ay-warning" type="button"
                                onclick="editScheduleGroup('${gids}',${e.subject_id},${e.teacher_id})">
                                <i class="bi bi-pencil-square"></i>
                            </button>
                            <button class="btn-ay btn-ay-danger" type="button"
                                onclick="deleteScheduleGroup('${gids}')">
                                <i class="bi bi-trash3"></i>
                            </button>
                        </div>
                    </div>`;
                }).join('')
                : `<div class="ay-empty"><i class="bi bi-calendar-x"></i><p>No schedule entries found.</p></div>`;
        })
        .catch(err => showAlert('Failed to load schedules: ' + err.message, 'danger'));
}


function resetValidationMessages() {
    document.getElementById('subjectValidation').style.display = 'none';
    document.getElementById('teacherValidation').style.display = 'none';
    document.getElementById('dayRowsValidation').style.display = 'none';
}

function openScheduleForm() {
    document.getElementById('scheduleForm').reset();
    document.getElementById('scheduleGroupIds').value = '';
    document.getElementById('scheduleFormTitle').textContent = 'Add Schedule';
    document.getElementById('isActive').value = '1';
    resetValidationMessages();
    resetScheduleConflictState();
    clearDayRows();
    addDayRow();
    Promise.all([loadSubjects(), loadTeacherOptions()])
        .then(() => new bootstrap.Modal(document.getElementById('scheduleFormModal')).show())
        .catch(err => showAlert('Failed to open form: ' + err.message, 'danger'));
}

function editScheduleGroup(groupIdsStr, subjectId, teacherId) {
    const ids = groupIdsStr.split(',').map(Number).filter(Boolean);
    if (!ids.length) return;
    const ayId = document.getElementById('academicYearId').value;

    fetchJson(`api/schedule/read.php?section_id=${SECTION_ID}&academic_year_id=${ayId}`)
        .then(async data => {
            const allRows   = data.schedules || data.data || [];
            const groupRows = allRows.filter(r => ids.includes(Number(r.id)));
            if (!groupRows.length) { showAlert('Could not find schedule data.', 'danger'); return; }

            const first = groupRows[0];
            document.getElementById('scheduleGroupIds').value       = groupIdsStr;
            document.getElementById('scheduleFormTitle').textContent = 'Edit Schedule';
            document.getElementById('room').value                   = first.room || '';
            document.getElementById('isActive').value               = String(first.is_active) ?? '1';
            resetValidationMessages();
            resetScheduleConflictState();

            
            const sorted = [...groupRows].sort((a, b) =>
                (DAY_ORDER[a.day_name] ?? 9) - (DAY_ORDER[b.day_name] ?? 9)
            );
            clearDayRows();
            sorted.forEach(r => addDayRow(r.day_name, r.time_start, r.time_end));

            await Promise.all([loadSubjects(subjectId, ids), loadTeacherOptions(teacherId)]);
            document.getElementById('subjectId').value = subjectId;
            document.getElementById('teacherId').value = teacherId;

            new bootstrap.Modal(document.getElementById('scheduleFormModal')).show();
            runScheduleConflictChecks().catch(err => {
                console.error(err);
                showScheduleConflictAlert('Unable to verify schedule conflicts. Please try again.');
                setScheduleSaveDisabled(true);
            });
        })
        .catch(err => showAlert('Failed to load schedule: ' + err.message, 'danger'));
}

function deleteScheduleGroup(groupIdsStr) {
    const ids = groupIdsStr.split(',').map(Number).filter(Boolean);
    if (!ids.length) return;
    const dayCount = ids.length;
    if (!confirm(`Delete this schedule entry (${dayCount} day${dayCount > 1 ? 's' : ''})?`)) return;

    fetchJson('api/schedule/delete.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids })
    }).then(res => {
        if (res.success !== false) { showAlert('Schedule deleted.', 'success'); loadSchedules(); }
        else showAlert(res.error || 'Delete failed.', 'danger');
    }).catch(err => showAlert('Delete failed: ' + err.message, 'danger'));
}


document.getElementById('scheduleForm').addEventListener('submit', async e => {
    e.preventDefault();

    const subjectId = document.getElementById('subjectId').value.trim();
    const teacherId = document.getElementById('teacherId').value.trim();
    const dayRows   = getDayRows();
    let hasError    = false;

    if (!subjectId) {
        document.getElementById('subjectValidation').style.display = 'block';
        hasError = true;
    } else {
        document.getElementById('subjectValidation').style.display = 'none';
    }

    if (!teacherId) {
        document.getElementById('teacherValidation').style.display = 'block';
        hasError = true;
    } else {
        document.getElementById('teacherValidation').style.display = 'none';
    }

    const allFilled = dayRows.length > 0 &&
        dayRows.every(r => r.day !== '' && r.timeStart !== '' && r.timeEnd !== '');

    if (!allFilled) {
        document.getElementById('dayRowsValidation').style.display = 'block';
        hasError = true;
    } else {
        document.getElementById('dayRowsValidation').style.display = 'none';
    }

    if (hasError) return;

    const daySet = new Set(dayRows.map(r => r.day));
    if (daySet.size !== dayRows.length) {
        showAlert('Duplicate days found. Each day can only appear once per schedule.', 'warning');
        return;
    }

    const badTime = dayRows.find(r => r.timeStart >= r.timeEnd);
    if (badTime) {
        showAlert(`Start time must be before end time on ${badTime.day}.`, 'warning');
        return;
    }

    if (hasScheduleConflict) {
        showAlert('Please resolve the schedule conflict before saving.', 'warning');
        return;
    }

    try {
        const conflictClear = await runScheduleConflictChecks();
        if (!conflictClear) {
            showAlert('Please resolve the schedule conflict before saving.', 'warning');
            return;
        }
    } catch (err) {
        console.error(err);
        showScheduleConflictAlert('Unable to verify schedule conflicts. Please try again.');
        setScheduleSaveDisabled(true);
        showAlert('Conflict check failed: ' + err.message, 'danger');
        return;
    }

    const groupIds = document.getElementById('scheduleGroupIds').value;

    fetchJson('api/schedule/save.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            group_ids:        groupIds ? groupIds.split(',').map(Number) : [],
            academic_year_id: document.getElementById('academicYearId').value,
            section_id:       SECTION_ID,
            subject_id:       subjectId,
            teacher_id:       teacherId,
            room:             document.getElementById('room').value.trim(),
            is_active:        document.getElementById('isActive').value,
            days: dayRows.map(r => ({
                day_name:   r.day,
                time_start: r.timeStart,
                time_end:   r.timeEnd,
            }))
        })
    }).then(res => {
        if (res.success !== false) {
            bootstrap.Modal.getInstance(document.getElementById('scheduleFormModal'))?.hide();
            showAlert('Schedule saved successfully.', 'success');
            loadSchedules();
        } else {
            showAlert(res.error || 'Save failed.', 'danger');
        }
    }).catch(err => showAlert('Save failed: ' + err.message, 'danger'));
});

document.getElementById('academicYearId').addEventListener('change', () => {
    loadAdviser();
    loadSchedules();
});

loadSectionInfo();
</script>
</body>
</html>