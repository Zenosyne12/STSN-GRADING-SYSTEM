<?php

require_once __DIR__ . '/includes/auth.php';     
require_once __DIR__ . '/api/shared/db_connect.php';

$sectionId = isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0;
if ($sectionId <= 0) die('Invalid section.');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Manage Schedule</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        body { background: #f3f7fd; }

        .ay-page-header {
            background: linear-gradient(130deg,#1248a8 0%,#1a6ef5 100%);
            border-radius: 16px; padding: 1.4rem 1.6rem; color: #fff;
            margin-bottom: 1.25rem; display: flex; flex-wrap: wrap;
            align-items: center; justify-content: space-between; gap: 1rem;
        }
        .ay-page-header h3 { font-size:1.25rem; font-weight:700; margin:0 0 .2rem; }
        .ay-page-header p  { margin:0; font-size:.88rem; opacity:.85; }
        .ay-active-chip {
            display:inline-flex; align-items:center; gap:.45rem;
            background:rgba(255,255,255,.15); border:1.5px solid rgba(255,255,255,.3);
            border-radius:999px; padding:.45rem 1rem; font-size:.88rem; font-weight:700; color:#fff;
        }

        .ay-card {
            background:#fff; border:1px solid #dce8f8; border-radius:16px;
            box-shadow:0 2px 12px rgba(18,72,168,.06); overflow:hidden; margin-bottom:1.5rem;
        }
        .ay-card-header {
            padding:1.1rem 1.4rem; border-bottom:1px solid #e8f0fb;
            display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between;
            gap:.75rem; background:#fff;
        }
        .ay-card-title    { font-size:1rem; font-weight:700; color:#132f62; margin:0 0 .15rem; }
        .ay-card-subtitle { font-size:.8rem; color:#7a93b8; margin:0; }
        .ay-card-body     { padding:1.2rem 1.3rem; }

        .ay-info-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:1rem; }
        .ay-info-label { font-size:.83rem; font-weight:700; color:#3b5e96; margin-bottom:.45rem; }
        .ay-info-value {
            min-height:46px; display:flex; align-items:center;
            padding:.65rem .9rem; border:1px solid #dce8f8; border-radius:12px;
            background:#fff; box-shadow:0 2px 8px rgba(18,72,168,.04);
            font-weight:600; color:#213a5e;
        }

        .btn-ay {
            font-weight:600; font-size:.82rem; border-radius:8px; padding:.42rem .9rem;
            cursor:pointer; transition:all .15s; border:1.5px solid transparent;
            line-height:1.4; text-decoration:none;
            display:inline-flex; align-items:center; justify-content:center; gap:.35rem;
        }
        .btn-ay-primary { background:linear-gradient(130deg,#1a6ef5,#1248a8); color:#fff; box-shadow:0 2px 8px rgba(26,110,245,.2); }
        .btn-ay-primary:hover { background:linear-gradient(130deg,#1560d8,#103d90); color:#fff; }
        .btn-ay-warning { background:#fff7e8; color:#9a6200; border-color:#f6d28b; }
        .btn-ay-warning:hover { background:#ffefc7; color:#845100; border-color:#efc361; }
        .btn-ay-danger  { background:#fff0f1; color:#b42318; border-color:#f5b5ba; }
        .btn-ay-danger:hover  { background:#ffe2e4; color:#9a1e14; border-color:#eb8f97; }
        .btn-ay-light   { background:#fff; color:#1248a8; border-color:#b8d0fa; }
        .btn-ay-light:hover   { background:#eef4ff; border-color:#8db5f7; color:#0f3d90; }
        .btn-ay-ghost   { background:transparent; color:#b42318; border-color:transparent; padding:.28rem .5rem; }
        .btn-ay-ghost:hover   { background:#fff0f1; border-color:#f5b5ba; }

        .ay-badge {
            display:inline-flex; align-items:center; gap:.3rem;
            padding:.32rem .75rem; border-radius:999px; font-size:.78rem; font-weight:700;
        }
        .ay-badge-active   { background:#e6f0ff; color:#1248a8; border:1.5px solid #b8d0fa; }
        .ay-badge-inactive { background:#f3f5f8; color:#7a8ea8;  border:1.5px solid #dde4ee; }

        .ay-sched-pills { display:flex; flex-direction:column; gap:.3rem; }
        .ay-sched-pill  {
            display:inline-flex; align-items:center; gap:.4rem;
            background:#f0f6ff; border:1px solid #c5d9f8; border-radius:8px;
            padding:.22rem .6rem; font-size:.78rem; font-weight:600; color:#1a4a9a; white-space:nowrap;
        }
        .ay-sched-pill-day  { font-weight:800; color:#1248a8; min-width:2.6rem; }
        .ay-sched-pill-sep  { color:#a0b8d8; }
        .ay-sched-pill-time { color:#2e5b9a; }

        .ay-table { width:100%; border-collapse:collapse; }
        .ay-table thead th {
            background:#f4f8ff; color:#3b5e96; font-size:.75rem; font-weight:700;
            text-transform:uppercase; letter-spacing:.06em; padding:.85rem 1rem;
            border-bottom:1.5px solid #dce8f8; white-space:nowrap; text-align:center;
        }
        .ay-table tbody tr:not(:last-child) td { border-bottom:1px solid #f0f5fc; }
        .ay-table tbody tr:hover td { background:#f7fbff; }
        .ay-table tbody td { padding:.95rem 1rem; font-size:.92rem; color:#213a5e; vertical-align:middle; text-align:center; }
        .ay-left { text-align:left !important; }

        .ay-day-rows { display:flex; flex-direction:column; gap:.55rem; }
        .ay-day-row {
            display:grid; grid-template-columns:1fr 1fr 1fr auto;
            gap:.5rem; align-items:center;
            background:#f7fbff; border:1.5px solid #dce8f8; border-radius:12px; padding:.6rem .75rem;
            transition: border-color .15s;
        }
        .ay-day-row:focus-within { border-color:#8db5f7; }
        .ay-day-row select,
        .ay-day-row input[type="time"] {
            border:1.5px solid #dce8f8; border-radius:8px; padding:.38rem .55rem;
            font-size:.85rem; color:#213a5e; background:#fff; outline:none; width:100%;
            transition: border-color .15s;
        }
        .ay-day-row select:focus,
        .ay-day-row input[type="time"]:focus { border-color:#1a6ef5; }
        .ay-day-row-label { font-size:.72rem; font-weight:700; color:#7a93b8; text-transform:uppercase; letter-spacing:.05em; }
        .ay-add-day-btn {
            display:flex; align-items:center; justify-content:center; gap:.4rem;
            background:#eef4ff; border:1.5px dashed #8db5f7; border-radius:10px;
            color:#1248a8; font-size:.83rem; font-weight:700; padding:.5rem 1rem;
            cursor:pointer; transition:all .15s; width:100%;
        }
        .ay-add-day-btn:hover { background:#ddeaff; border-color:#5a96f0; }

        .ay-mobile-card { background:#fff; border:1.5px solid #dce8f8; border-radius:14px; overflow:hidden; box-shadow:0 1px 6px rgba(18,72,168,.05); }
        .ay-mobile-card + .ay-mobile-card { margin-top:.75rem; }
        .ay-mobile-card-header { display:flex; align-items:center; justify-content:space-between; padding:.85rem 1rem; border-bottom:1px solid #edf3fc; background:#f9fbff; gap:.75rem; }
        .ay-mobile-card-title { font-weight:700; color:#132f62; font-size:.95rem; }
        .ay-mobile-card-body  { padding:.85rem 1rem; }
        .ay-mobile-row { display:flex; justify-content:space-between; gap:.75rem; padding:.25rem 0; font-size:.9rem; flex-wrap:wrap; }
        .ay-mobile-label { color:#7a93b8; font-weight:600; flex-shrink:0; }
        .ay-mobile-actions { display:grid; gap:.5rem; padding:0 1rem 1rem; }

        .ay-empty { text-align:center; padding:2.4rem 1.5rem; color:#9ab0c8; }
        .ay-empty i { font-size:2.2rem; display:block; margin-bottom:.6rem; opacity:.5; }
        .ay-empty p { margin:0; font-size:.95rem; }

        .ay-modal .modal-content { border:0; border-radius:16px; box-shadow:0 8px 32px rgba(18,72,168,.16); overflow:hidden; }
        .ay-modal .modal-header  { background:#f4f8ff; border-bottom:1px solid #dce8f8; padding:1rem 1.25rem; }
        .ay-modal .modal-title   { font-size:1rem; font-weight:700; color:#132f62; }
        .ay-modal-subtitle       { font-size:.82rem; color:#7a93b8; }
        .ay-modal .modal-body    { background:#fff; padding:1.2rem; }
        .ay-modal .modal-footer  { padding:.95rem 1.2rem; border-top:1px solid #e8f0fb; background:#fafcff; }

        .ay-col-headers {
            display:grid; grid-template-columns:1fr 1fr 1fr auto;
            gap:.5rem; padding:0 .75rem .3rem;
        }

        @media (max-width:991.98px) { .ay-info-grid { grid-template-columns:1fr; } }
        @media (max-width:767.98px) {
            .ay-page-header { padding:1.1rem 1.2rem; border-radius:14px; }
            .ay-day-row { grid-template-columns:1fr 1fr; }
            .ay-day-row > select:first-child { grid-column:1 / -1; }
            .ay-col-headers { display:none; }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3">

                <div class="ay-page-header">
                    <div>
                        <h3><i class="bi bi-calendar-check me-2"></i>Manage Section Schedule</h3>
                        <p>Assign advisers and manage subject schedule records for the selected section.</p>
                    </div>
                    <div class="ay-active-chip"><i class="bi bi-journal-check"></i> Schedule Management</div>
                </div>

                <div class="row">
                    <div class="col-lg-7 d-flex">
                        <div class="ay-card w-100">
                            <div class="ay-card-header">
                                <div>
                                    <p class="ay-card-title">Section Information</p>
                                    <p class="ay-card-subtitle">Basic information for the selected section.</p>
                                </div>
                            </div>
                            <div class="ay-card-body">
                                <div class="ay-info-grid">
                                    <div>
                                        <div class="ay-info-label">Grade Level</div>
                                        <div id="infoGradeLevel" class="ay-info-value">-</div>
                                    </div>
                                    <div>
                                        <div class="ay-info-label">Section Name</div>
                                        <div id="infoSectionName" class="ay-info-value">-</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-5 d-flex">
                        <div class="ay-card w-100">
                            <div class="ay-card-header">
                                <div>
                                    <p class="ay-card-title">Academic Setup</p>
                                    <p class="ay-card-subtitle">Assign the section adviser for the active academic year.</p>
                                </div>
                            </div>
                            <div class="ay-card-body">
                                <div class="d-none"><select id="academicYearId"></select></div>
                                <div>
                                    <label class="form-label fw-bold">Section Adviser</label>
                                    <div class="input-group">
                                        <select class="form-select" id="adviserTeacherId" style="border-radius:10px 0 0 10px;border:1.5px solid #dce8f8;"></select>
                                        <button class="btn-ay btn-ay-primary" type="button" onclick="saveAdviser()" style="border-radius:0 10px 10px 0;">
                                            <i class="bi bi-save"></i> Save Adviser
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="ay-card">
                    <div class="ay-card-header">
                        <div>
                            <p class="ay-card-title">Schedule Entries</p>
                            <p class="ay-card-subtitle">Grouped by subject &amp; teacher. Each entry can span multiple days with different times.</p>
                        </div>
                        <button class="btn-ay btn-ay-primary" type="button" onclick="openScheduleForm()">
                            <i class="bi bi-plus-circle"></i> New Schedule
                        </button>
                    </div>

                    <div class="table-responsive d-none d-md-block">
                        <table class="ay-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Subject</th>
                                    <th>Teacher</th>
                                    <th>Days &amp; Times</th>
                                    <th>Room</th>
                                    <th>Status</th>
                                    <th style="width:200px;">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="scheduleTableBody">
                                <tr><td colspan="7"><div class="ay-empty"><i class="bi bi-hourglass-split"></i><p>Loading schedules...</p></div></td></tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="d-block d-md-none p-3" id="scheduleCardView"></div>
                </div>

            </div>
        </div>
    </main>
    <?php require_once("includes/footer.php"); ?>
</div>

<!-- Schedule Modal -->
<div class="modal fade ay-modal" id="scheduleFormModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="false">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <form id="scheduleForm" novalidate>
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title" id="scheduleFormTitle">Add Schedule</h5>
                        <div class="ay-modal-subtitle">Select a subject &amp; teacher, then add one row per day with its own time.</div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <input type="hidden" id="scheduleGroupIds">

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Subject <span class="text-danger">*</span></label>
                            <select class="form-select" id="subjectId" style="border-radius:10px;border:1.5px solid #dce8f8;">
                                <option value="">Select Subject</option>
                            </select>
                            <div id="subjectValidation" class="text-danger mt-1" style="font-size:.8rem;display:none;">Please select a subject.</div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Teacher <span class="text-danger">*</span></label>
                            <select class="form-select" id="teacherId" style="border-radius:10px;border:1.5px solid #dce8f8;">
                                <option value="">Select Teacher</option>
                            </select>
                            <div id="teacherValidation" class="text-danger mt-1" style="font-size:.8rem;display:none;">Please select a teacher.</div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Room</label>
                            <input type="text" class="form-control" id="room" placeholder="e.g. Room 101" style="border-radius:10px;border:1.5px solid #dce8f8;">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Status</label>
                            <select class="form-select" id="isActive" style="border-radius:10px;border:1.5px solid #dce8f8;">
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label class="form-label mb-1">Days &amp; Times <span class="text-danger">*</span></label>
                        <div class="ay-col-headers">
                            <span class="ay-day-row-label">Day</span>
                            <span class="ay-day-row-label">Start Time</span>
                            <span class="ay-day-row-label">End Time</span>
                            <span></span>
                        </div>
                        <div class="ay-day-rows" id="dayRowsContainer"></div>
                        <button type="button" class="ay-add-day-btn mt-2" onclick="addDayRow()">
                            <i class="bi bi-plus-circle"></i> Add Another Day
                        </button>
                        <div id="dayRowsValidation" class="text-danger mt-1" style="font-size:.8rem;display:none;">
                            Please add at least one day with a complete time range.
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn-ay btn-ay-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn-ay btn-ay-primary"><i class="bi bi-save"></i> Save Schedule</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="./js/sweet-alerts.js"></script>
<script>
const SECTION_ID = <?php echo (int)$sectionId; ?>;
let currentSectionInfo = null;

const DAYS      = ['Monday','Tuesday','Wednesday','Thursday','Friday'];
const DAY_SHORT = { Monday:'Mon', Tuesday:'Tue', Wednesday:'Wed', Thursday:'Thu', Friday:'Fri' };
const DAY_ORDER = { Monday:0, Tuesday:1, Wednesday:2, Thursday:3, Friday:4 };

/* â”€â”€ Utilities â”€â”€ */
function esc(s) {
    return (s ?? '').toString()
        .replaceAll('&','&amp;').replaceAll('<','&lt;')
        .replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;');
}

function fmt12(t) {
    if (!t) return '-';
    const parts = t.split(':').map(Number);
    const h = parts[0], m = parts[1];
    return `${h % 12 || 12}:${String(m).padStart(2,'0')} ${h >= 12 ? 'PM' : 'AM'}`;
}

function showAlert(msg, type = 'success') {
    const cfg = {
        success: { title:'Success', color:'blue',   icon:'bi bi-check-circle-fill' },
        danger:  { title:'Error',   color:'red',    icon:'bi bi-exclamation-octagon-fill' },
        warning: { title:'Warning', color:'yellow', icon:'bi bi-exclamation-triangle-fill' },
        info:    { title:'Info',    color:'blue',   icon:'bi bi-info-circle-fill' }
    };
    const s = cfg[type] || cfg.success;
    iziToast.show({
        title: s.title, message: msg, color: s.color, icon: s.icon,
        iconColor: '#fff', theme: 'light', position: 'topRight', timeout: 4000,
        progressBar: true, close: true, pauseOnHover: true, drag: true,
        transitionIn: 'fadeInDown', transitionOut: 'fadeOutUp', maxWidth: 420
    });
}

async function fetchJson(url, opts = {}) {
    const res  = await fetch(url, opts);
    const text = await res.text();
    try { return JSON.parse(text); }
    catch(e) { console.error('Bad JSON from:', url, '\nRaw response:', text); throw new Error('Invalid server response'); }
}

/* â”€â”€ Day-row builder â”€â”€ */
function dayOptions(selected = '') {
    return DAYS.map(d =>
        `<option value="${d}"${d === selected ? ' selected' : ''}>${d}</option>`
    ).join('');
}

function addDayRow(day = '', timeStart = '', timeEnd = '') {
    const div = document.createElement('div');
    div.className = 'ay-day-row';
    div.innerHTML = `
        <select class="day-select">
            <option value="">Select Day</option>
            ${dayOptions(day)}
        </select>
        <input type="time" class="time-start" value="${esc(timeStart)}">
        <input type="time" class="time-end"   value="${esc(timeEnd)}">
        <button type="button" class="btn-ay btn-ay-ghost" onclick="removeDayRow(this)" title="Remove row">
            <i class="bi bi-x-lg"></i>
        </button>`;
    document.getElementById('dayRowsContainer').appendChild(div);
}

function removeDayRow(btn) {
    if (document.querySelectorAll('#dayRowsContainer .ay-day-row').length <= 1) {
        showAlert('At least one day is required.', 'warning');
        return;
    }
    btn.closest('.ay-day-row').remove();
}

function clearDayRows() {
    document.getElementById('dayRowsContainer').innerHTML = '';
}

function getDayRows() {
    return [...document.querySelectorAll('#dayRowsContainer .ay-day-row')].map(row => ({
        day:       row.querySelector('.day-select').value.trim(),
        timeStart: row.querySelector('.time-start').value.trim(),
        timeEnd:   row.querySelector('.time-end').value.trim(),
    }));
}

/* â”€â”€ Grouping helpers â”€â”€
 * KEY FIX: store and read `day_name` (not `day`) in grouped objects
 * so every part of the code uses the same field name as the DB/API.
 */
function groupScheduleRows(rows) {
    const map = new Map();
    rows.forEach(r => {
        const key = `${r.subject_id}_${r.teacher_id}`;
        if (!map.has(key)) {
            map.set(key, {
                subject_id:   r.subject_id,
                subject_name: r.subject_name,
                subject_code: r.subject_code,
                teacher_id:   r.teacher_id,
                teacher_name: r.teacher_name,
                room:         r.room,
                is_active:    r.is_active,
                days:         []
            });
        }
        map.get(key).days.push({
            id:         r.id,
            day_name:   r.day_name,    // read r.day_name from API row
            time_start: r.time_start,
            time_end:   r.time_end
        });
    });
    return [...map.values()];
}

function renderDayTimePills(days) {
    const sorted = [...days].sort((a, b) =>
        (DAY_ORDER[a.day_name] ?? 9) - (DAY_ORDER[b.day_name] ?? 9)  // use day_name
    );
    return `<div class="ay-sched-pills">${
        sorted.map(d => `
            <span class="ay-sched-pill">
                <span class="ay-sched-pill-day">${esc(DAY_SHORT[d.day_name] || d.day_name)}</span>
                <span class="ay-sched-pill-sep">|</span>
                <span class="ay-sched-pill-time">${fmt12(d.time_start)} – ${fmt12(d.time_end)}</span>
            </span>`).join('')
    }</div>`;
}

/* â”€â”€ Data loaders â”€â”€ */
async function loadSectionInfo() {
    try {
        const data = await fetchJson(`api/schedule/fetch_section.php?id=${SECTION_ID}`);
        currentSectionInfo = data.data || data;
        document.getElementById('infoGradeLevel').textContent  = currentSectionInfo.grade_level_name || '-';
        document.getElementById('infoSectionName').textContent = currentSectionInfo.section_name     || '-';
        await loadAdviserTeachers();
        await loadAcademicYears(currentSectionInfo.default_academic_year_id || '');
        loadAdviser();
        loadSchedules();
    } catch(err) {
        console.error(err);
        showAlert('Failed to load section info: ' + err.message, 'danger');
    }
}

function loadAdviserTeachers() {
    return fetchJson('api/schedule/teachers.php').then(data => {
        const list = data.teachers || data.data || [];
        document.getElementById('adviserTeacherId').innerHTML =
            ['<option value="">Select Teacher</option>']
            .concat(list.map(t => `<option value="${t.id}">${esc(t.full_name)}</option>`))
            .join('');
    });
}

function loadTeacherOptions(selectedId = '') {
    const sel  = document.getElementById('teacherId');
    const ayId = document.getElementById('academicYearId').value;
    let url = `api/schedule/teachers.php?section_id=${SECTION_ID}`;
    if (ayId) url += `&academic_year_id=${encodeURIComponent(ayId)}`;
    sel.innerHTML = '<option value="">Loading...</option>';
    sel.disabled  = true;
    return fetchJson(url).then(data => {
        const list = data.teachers || data.data || [];
        sel.innerHTML = ['<option value="">Select Teacher</option>']
            .concat(list.map(t =>
                `<option value="${t.id}"${String(selectedId) === String(t.id) ? ' selected' : ''}>${esc(t.full_name)}</option>`
            )).join('');
        if (selectedId && !list.some(t => String(t.id) === String(selectedId))) sel.value = '';
    }).catch(err => {
        sel.innerHTML = '<option value="">Failed to load</option>';
        throw err;
    }).finally(() => { sel.disabled = false; });
}

function loadSubjects(selectedId = '', excludeIds = []) {
    const sel  = document.getElementById('subjectId');
    const ayId = document.getElementById('academicYearId').value;
    const glId = currentSectionInfo?.grade_level_id || '';
    if (!ayId || !glId) {
        sel.innerHTML = '<option value="">No subjects available</option>';
        return Promise.resolve();
    }
    sel.innerHTML = '<option value="">Loading...</option>';
    sel.disabled  = true;
    let url = `api/schedule/subjects.php?section_id=${SECTION_ID}&academic_year_id=${ayId}&grade_level_id=${glId}`;
    excludeIds.forEach(id => { url += `&exclude_schedule_id[]=${encodeURIComponent(id)}`; });
    return fetchJson(url).then(data => {
        const list = data.subjects || data.data || [];
        if (!list.length) {
            sel.innerHTML = '<option value="">No subjects available</option>';
            return;
        }
        sel.innerHTML = ['<option value="">Select Subject</option>']
            .concat(list.map(s =>
                `<option value="${s.id}"${String(selectedId) === String(s.id) ? ' selected' : ''}>${esc(s.subject_name)} (${esc(s.subject_code)})</option>`
            )).join('');
    }).catch(err => {
        sel.innerHTML = '<option value="">Failed to load</option>';
        throw err;
    }).finally(() => { sel.disabled = false; });
}

function loadAcademicYears(selectedId = '') {
    return fetchJson('api/schedule/academic_years.php').then(data => {
        const list = data.academic_years || data.data || [];
        document.getElementById('academicYearId').innerHTML = list.map(y =>
            `<option value="${y.id}"${String(selectedId) === String(y.id) ? ' selected' : ''}>${esc(y.year_label)}${y.is_active == 1 ? ' (Active)' : ''}</option>`
        ).join('');
    });
}

function loadAdviser() {
    const ayId = document.getElementById('academicYearId').value;
    if (!ayId) return;
    fetchJson(`api/schedule/adviser_get.php?section_id=${SECTION_ID}&academic_year_id=${ayId}`)
        .then(data => { document.getElementById('adviserTeacherId').value = data.teacher_id || ''; })
        .catch(err => showAlert('Failed to load adviser: ' + err.message, 'danger'));
}

function saveAdviser() {
    const ayId = document.getElementById('academicYearId').value;
    const tid  = document.getElementById('adviserTeacherId').value;
    fetchJson('api/schedule/adviser_save.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ section_id: SECTION_ID, academic_year_id: ayId, teacher_id: tid })
    }).then(res => {
        if (res.success !== false) showAlert('Adviser saved.', 'success');
        else showAlert(res.error || 'Failed.', 'danger');
    }).catch(err => showAlert('Failed: ' + err.message, 'danger'));
}

/* â”€â”€ Schedule list â”€â”€ */
function loadSchedules() {
    const ayId = document.getElementById('academicYearId').value;
    if (!ayId) return;

    fetchJson(`api/schedule/read.php?section_id=${SECTION_ID}&academic_year_id=${ayId}`)
        .then(data => {
            const rows    = data.schedules || data.data || [];
            const entries = groupScheduleRows(rows);

            const statusBadge = active =>
                String(active) === '1'
                    ? `<span class="ay-badge ay-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                    : `<span class="ay-badge ay-badge-inactive">Inactive</span>`;

            /* Desktop table */
            document.getElementById('scheduleTableBody').innerHTML = entries.length
                ? entries.map((e, i) => {
                    const gids = e.days.map(d => d.id).join(',');
                    return `<tr>
                        <td>${i + 1}</td>
                        <td class="ay-left">${esc(e.subject_name || '-')}</td>
                        <td>${esc(e.teacher_name || '-')}</td>
                        <td class="ay-left">${renderDayTimePills(e.days)}</td>
                        <td>${esc(e.room || '-')}</td>
                        <td>${statusBadge(e.is_active)}</td>
                        <td>
                            <div class="d-flex justify-content-center gap-2 flex-wrap">
                                <button class="btn-ay btn-ay-warning" type="button"
                                    onclick="editScheduleGroup('${gids}',${e.subject_id},${e.teacher_id})">
                                    <i class="bi bi-pencil-square"></i> Edit
                                </button>
                                <button class="btn-ay btn-ay-danger" type="button"
                                    onclick="deleteScheduleGroup('${gids}')">
                                    <i class="bi bi-trash"></i> Delete
                                </button>
                            </div>
                        </td>
                    </tr>`;
                }).join('')
                : `<tr><td colspan="7"><div class="ay-empty"><i class="bi bi-calendar-x"></i><p>No schedule entries found.</p></div></td></tr>`;

            /* Mobile cards */
            document.getElementById('scheduleCardView').innerHTML = entries.length
                ? entries.map((e, i) => {
                    const gids = e.days.map(d => d.id).join(',');
                    return `<div class="ay-mobile-card">
                        <div class="ay-mobile-card-header">
                            <span class="ay-mobile-card-title">${i + 1}. ${esc(e.subject_name || '-')}</span>
                            ${statusBadge(e.is_active)}
                        </div>
                        <div class="ay-mobile-card-body">
                            <div class="ay-mobile-row"><span class="ay-mobile-label">Teacher</span><span>${esc(e.teacher_name || '-')}</span></div>
                            <div class="ay-mobile-row"><span class="ay-mobile-label">Days &amp; Times</span><div>${renderDayTimePills(e.days)}</div></div>
                            <div class="ay-mobile-row"><span class="ay-mobile-label">Room</span><span>${esc(e.room || '-')}</span></div>
                        </div>
                        <div class="ay-mobile-actions">
                            <button class="btn-ay btn-ay-warning" type="button"
                                onclick="editScheduleGroup('${gids}',${e.subject_id},${e.teacher_id})">
                                <i class="bi bi-pencil-square"></i> Edit
                            </button>
                            <button class="btn-ay btn-ay-danger" type="button"
                                onclick="deleteScheduleGroup('${gids}')">
                                <i class="bi bi-trash"></i> Delete
                            </button>
                        </div>
                    </div>`;
                }).join('')
                : `<div class="ay-empty"><i class="bi bi-calendar-x"></i><p>No schedule entries found.</p></div>`;
        })
        .catch(err => showAlert('Failed to load schedules: ' + err.message, 'danger'));
}

/* â”€â”€ Form open / edit / delete â”€â”€ */
function resetValidationMessages() {
    document.getElementById('subjectValidation').style.display = 'none';
    document.getElementById('teacherValidation').style.display = 'none';
    document.getElementById('dayRowsValidation').style.display = 'none';
}

function openScheduleForm() {
    document.getElementById('scheduleForm').reset();
    document.getElementById('scheduleGroupIds').value = '';
    document.getElementById('scheduleFormTitle').textContent = 'Add Schedule';
    document.getElementById('isActive').value = '1';
    resetValidationMessages();
    clearDayRows();
    addDayRow();
    Promise.all([loadSubjects(), loadTeacherOptions()])
        .then(() => new bootstrap.Modal(document.getElementById('scheduleFormModal')).show())
        .catch(err => showAlert('Failed to open form: ' + err.message, 'danger'));
}

function editScheduleGroup(groupIdsStr, subjectId, teacherId) {
    const ids = groupIdsStr.split(',').map(Number).filter(Boolean);
    if (!ids.length) return;
    const ayId = document.getElementById('academicYearId').value;

    fetchJson(`api/schedule/read.php?section_id=${SECTION_ID}&academic_year_id=${ayId}`)
        .then(async data => {
            const allRows   = data.schedules || data.data || [];
            const groupRows = allRows.filter(r => ids.includes(Number(r.id)));
            if (!groupRows.length) { showAlert('Could not find schedule data.', 'danger'); return; }

            const first = groupRows[0];
            document.getElementById('scheduleGroupIds').value       = groupIdsStr;
            document.getElementById('scheduleFormTitle').textContent = 'Edit Schedule';
            document.getElementById('room').value                   = first.room || '';
            document.getElementById('isActive').value               = String(first.is_active) ?? '1';
            resetValidationMessages();

            /* sort using r.day_name (from the raw API row, before grouping) */
            const sorted = [...groupRows].sort((a, b) =>
                (DAY_ORDER[a.day_name] ?? 9) - (DAY_ORDER[b.day_name] ?? 9)
            );
            clearDayRows();
            sorted.forEach(r => addDayRow(r.day_name, r.time_start, r.time_end));

            await Promise.all([loadSubjects(subjectId, ids), loadTeacherOptions(teacherId)]);
            document.getElementById('subjectId').value = subjectId;
            document.getElementById('teacherId').value = teacherId;

            new bootstrap.Modal(document.getElementById('scheduleFormModal')).show();
        })
        .catch(err => showAlert('Failed to load schedule: ' + err.message, 'danger'));
}

function deleteScheduleGroup(groupIdsStr) {
    const ids = groupIdsStr.split(',').map(Number).filter(Boolean);
    if (!ids.length) return;
    const dayCount = ids.length;
    if (!confirm(`Delete this schedule entry (${dayCount} day${dayCount > 1 ? 's' : ''})?`)) return;

    fetchJson('api/schedule/delete.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids })
    }).then(res => {
        if (res.success !== false) { showAlert('Schedule deleted.', 'success'); loadSchedules(); }
        else showAlert(res.error || 'Delete failed.', 'danger');
    }).catch(err => showAlert('Delete failed: ' + err.message, 'danger'));
}

/* â”€â”€ Form submit â”€â”€ */
document.getElementById('scheduleForm').addEventListener('submit', e => {
    e.preventDefault();

    const subjectId = document.getElementById('subjectId').value.trim();
    const teacherId = document.getElementById('teacherId').value.trim();
    const dayRows   = getDayRows();
    let hasError    = false;

    if (!subjectId) {
        document.getElementById('subjectValidation').style.display = 'block';
        hasError = true;
    } else {
        document.getElementById('subjectValidation').style.display = 'none';
    }

    if (!teacherId) {
        document.getElementById('teacherValidation').style.display = 'block';
        hasError = true;
    } else {
        document.getElementById('teacherValidation').style.display = 'none';
    }

    const allFilled = dayRows.length > 0 &&
        dayRows.every(r => r.day !== '' && r.timeStart !== '' && r.timeEnd !== '');

    if (!allFilled) {
        document.getElementById('dayRowsValidation').style.display = 'block';
        hasError = true;
    } else {
        document.getElementById('dayRowsValidation').style.display = 'none';
    }

    if (hasError) return;

    const daySet = new Set(dayRows.map(r => r.day));
    if (daySet.size !== dayRows.length) {
        showAlert('Duplicate days found. Each day can only appear once per schedule.', 'warning');
        return;
    }

    const badTime = dayRows.find(r => r.timeStart >= r.timeEnd);
    if (badTime) {
        showAlert(`Start time must be before end time on ${badTime.day}.`, 'warning');
        return;
    }

    const groupIds = document.getElementById('scheduleGroupIds').value;

    fetchJson('api/schedule/save.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            group_ids:        groupIds ? groupIds.split(',').map(Number) : [],
            academic_year_id: document.getElementById('academicYearId').value,
            section_id:       SECTION_ID,
            subject_id:       subjectId,
            teacher_id:       teacherId,
            room:             document.getElementById('room').value.trim(),
            is_active:        document.getElementById('isActive').value,
            days: dayRows.map(r => ({
                day_name:   r.day,
                time_start: r.timeStart,
                time_end:   r.timeEnd,
            }))
        })
    }).then(res => {
        if (res.success !== false) {
            bootstrap.Modal.getInstance(document.getElementById('scheduleFormModal'))?.hide();
            showAlert('Schedule saved successfully.', 'success');
            loadSchedules();
        } else {
            showAlert(res.error || 'Save failed.', 'danger');
        }
    }).catch(err => showAlert('Save failed: ' + err.message, 'danger'));
});

document.getElementById('academicYearId').addEventListener('change', () => {
    loadAdviser();
    loadSchedules();
});

loadSectionInfo();
</script>
</body>
</html>
