<?php
require_once 'includes/auth.php';
requireLogin();
if (!isAdminSession() && !isSuperAdminSession()) {
    redirectTo('/lstsngsv1/login.php');
}
require_once __DIR__ . '/includes/get_active_year.php';
require_once 'api/shared/db_connect.php';
$activeYear = getActiveYear($pdo);
$allYears = [];
$activeCurriculum = null;
$eligibleYears = [];
$previousYears = [];

/* ============================================================
   Curriculum-years data (card-based management)
   ============================================================ */

// All academic years with their curriculum state.
if ($activeYear) {
    $yearsStmt = $pdo->query("
    SELECT id, year_label, start_date, end_date,
           is_active, archived_at, curriculum_status,
           curriculum_created_at, curriculum_archived_at,
           (SELECT COUNT(*) FROM tblsubjects s WHERE s.academic_year_id = tblacademicyear.id) AS subject_count
    FROM tblacademicyear
    ORDER BY start_date DESC, id DESC
");
    $allYears = $yearsStmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($allYears as $y) {
        if ((int) $y['id'] !== (int) $activeYear['id']) {
            if (
                in_array($y['curriculum_status'] ?? 'NONE', ['ACTIVE', 'ARCHIVED'], true)
                && (int) ($y['subject_count'] ?? 0) > 0
                && (int) $y['id'] < (int) $activeYear['id']
            ) {
                $previousYears[] = $y;
            }
            continue;
        }

        $status = $y['curriculum_status'] ?? 'NONE';
        if ($status === 'ACTIVE') {
            $activeCurriculum = $y;
        } elseif ($status === 'NONE') {
            $eligibleYears[] = $y;
        }
    }
}

// Per-curriculum counters (subjects, students, sections, grade rows).
if (!function_exists('getCurriculumStats')) {
    function getCurriculumStats(PDO $pdo, int $yearId): array
    {
        $stats = ['subjects' => 0, 'students' => 0, 'sections' => 0, 'grades' => 0];

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM tblsubjects WHERE academic_year_id = ?");
        $stmt->execute([$yearId]);
        $stats['subjects'] = (int) $stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT COUNT(DISTINCT student_id) FROM tblsectionstudent WHERE academic_year_id = ? AND is_active = 1");
        $stmt->execute([$yearId]);
        $stats['students'] = (int) $stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM tblsection WHERE is_active = 1");
        $stmt->execute();
        $stats['sections'] = (int) $stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM tblgrades WHERE academic_year_id = ?");
        $stmt->execute([$yearId]);
        $stats['grades'] = (int) $stmt->fetchColumn();

        return $stats;
    }
}

$archiveMode = 'AUTO';
if ($activeYear) {
    try {
        $stmtArchiveMode = $pdo->prepare("SELECT mode FROM tblarchive_settings WHERE id = 1 LIMIT 1");
        $stmtArchiveMode->execute();
        $val = $stmtArchiveMode->fetchColumn();
        if ($val === 'MANUAL' || $val === 'AUTO') {
            $archiveMode = $val;
        }
    } catch (Throwable $e) {
        $archiveMode = 'AUTO';
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
    <meta charset="utf-8">
    <title>Subjects</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <style>
        :root,
        [data-bs-theme="light"] {
            --cy-bg: #f3f7fd;
            --cy-card: #ffffff;
            --cy-card-soft: #fafcff;
            --cy-border: #dce8f8;
            --cy-border-soft: #e8f0fb;
            --cy-text: #213a5e;
            --cy-text-strong: #132f62;
            --cy-text-muted: #7a93b8;
            --cy-text-dim: #9ab0c8;
            --cy-tree-active-bg: #eef4ff;
            --cy-input-bg: #ffffff;
            --cy-input-border: #c8daf8;
            --cy-input-text: #213a5e;
            --cy-shadow: rgba(18,72,168,.06);
        }

        [data-bs-theme="dark"] {
            --cy-bg: #1a1a1a;
            --cy-card: #2D2D2D;
            --cy-card-soft: #262626;
            --cy-border: #3a3a3a;
            --cy-border-soft: #3a3a3a;
            --cy-text: #e4e6e8;
            --cy-text-strong: #f1f3f5;
            --cy-text-muted: #adb5bd;
            --cy-text-dim: #8b939a;
            --cy-tree-active-bg: #343434;
            --cy-input-bg: #3a3a3a;
            --cy-input-border: #4a5a6e;
            --cy-input-text: #e8eef7;
            --cy-shadow: rgba(0,0,0,.35);
        }

        body { background: var(--cy-bg); }

        .ay-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px; padding: 1.4rem 1.6rem; color: #fff;
            margin-bottom: 1.25rem; display: flex; flex-wrap: wrap;
            align-items: center; justify-content: space-between; gap: 1rem;
        }
        .ay-page-header h3 { font-size: 1.25rem; font-weight: 700; margin: 0 0 .2rem; letter-spacing: .01em; }
        .ay-page-header p { margin: 0; font-size: .88rem; opacity: .85; }

        .ay-layout {
            display: grid; grid-template-columns: 290px 1fr;
            gap: 1.2rem; align-items: start;
        }
        @media (max-width: 991px) { .ay-layout { grid-template-columns: 1fr; } }

        .ay-card {
            background: var(--cy-card); border: 1px solid var(--cy-border);
            border-radius: 16px; box-shadow: 0 2px 12px var(--cy-shadow); overflow: hidden;
            margin-bottom: 1.5rem;
        }
        .ay-card-header {
            padding: 1.1rem 1.4rem; border-bottom: 1px solid var(--cy-border-soft);
            display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between;
            gap: .75rem; background: var(--cy-card);
        }
        .ay-card-title { font-size: 1rem; font-weight: 700; color: var(--cy-text-strong); margin: 0 0 .15rem; }
        .ay-card-subtitle { font-size: .8rem; color: var(--cy-text-muted); margin: 0; }
        .ay-card-footer {
            padding: .75rem 1.2rem; border-top: 1px solid var(--cy-border-soft);
            background: var(--cy-card-soft); display: flex; justify-content: space-between;
            align-items: center; gap: .75rem; flex-wrap: wrap;
        }
        .ay-footer-note { font-size: .82rem; color: var(--cy-text-muted); }

        /* BUTTONS */
        .btn-ay {
            font-weight: 600; font-size: .82rem; border-radius: 8px;
            padding: .42rem .9rem; cursor: pointer; transition: all .14s;
            border: 1.5px solid transparent; line-height: 1.4;
        }
        .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff; box-shadow: 0 2px 8px rgba(26,110,245,.2);
        }
        .btn-ay-primary:hover { background: linear-gradient(130deg, #1560d8, #103d90); color: #fff; }
        .btn-ay-primary:disabled,
        .btn-ay-primary.disabled {
            background: #dce8f8;
            color: #94a3b8;
            border-color: #dce8f8;
            box-shadow: none;
            cursor: not-allowed;
            opacity: 1;
        }
        [data-bs-theme="dark"] .btn-ay-primary:disabled,
        [data-bs-theme="dark"] .btn-ay-primary.disabled {
            background: #3a3a3a;
            color: #8b939a;
            border-color: #3a3a3a;
        }
        .btn-ay-outline { background: var(--cy-card); color: #1a6ef5; border-color: var(--cy-border); }
        .btn-ay-outline:hover { background: var(--cy-tree-active-bg); border-color: #9cc2fc; }
        [data-bs-theme="dark"] .btn-ay-outline { color: #7ab7ff; }
        [data-bs-theme="dark"] .btn-ay-outline:hover { background: #343434; color: #a5ccff; }

        .btn-ay-danger { background: #fff5f5; color: #d64545; border-color: #f3c2c2; }
        .btn-ay-danger:hover { background: #ffe8e8; color: #bb2d3b; border-color: #e9a8a8; }
        [data-bs-theme="dark"] .btn-ay-danger { background: #3a1f24; color: #ff8b9e; border-color: #5c2d35; }
        [data-bs-theme="dark"] .btn-ay-danger:hover { background: #4a262c; border-color: #6e3640; color: #ffb0be; }

        /* ============================================================
           MODAL — Light mode default
           ============================================================ */
        .ay-modal .modal-content {
            border: 0; border-radius: 16px;
            box-shadow: 0 8px 32px rgba(18,72,168,.16);
            background: var(--cy-card);
        }
        .ay-modal .modal-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-bottom: 0;
            border-radius: 16px 16px 0 0;
            padding: 1rem 1.3rem;
        }
        .ay-modal .modal-title { font-size: 1rem; font-weight: 700; color: #fff; }
        .ay-modal .modal-header .btn-close { filter: brightness(0) invert(1); opacity: .9; }
        .ay-modal .modal-header .btn-close:hover { opacity: 1; }
        .ay-modal .modal-body { padding: 1.3rem; background: var(--cy-card); color: var(--cy-text); }
        .ay-modal .modal-footer {
            border-top: 1px solid var(--cy-border-soft); padding: .9rem 1.3rem;
            background: var(--cy-card-soft); border-radius: 0 0 16px 16px;
        }
        .ay-modal .form-label { font-size: .85rem; font-weight: 700; color: var(--cy-text-muted); margin-bottom: .4rem; }
        .ay-modal .form-control,
        .ay-modal .form-select {
            border-radius: 10px; border: 1.5px solid var(--cy-input-border);
            min-height: 42px; font-size: .9rem; color: var(--cy-input-text);
            padding: .45rem .85rem; background: var(--cy-input-bg);
        }
        .ay-modal .form-control:focus,
        .ay-modal .form-select:focus { border-color: #1a6ef5; box-shadow: 0 0 0 3px rgba(26,110,245,.12); }

        #copyOptions {
            overflow: hidden;
            max-height: 0;
            opacity: 0;
            transition: max-height 280ms cubic-bezier(0.22, 1, 0.36, 1),
                        opacity 180ms cubic-bezier(0.22, 1, 0.36, 1),
                        margin-top 280ms cubic-bezier(0.22, 1, 0.36, 1);
            margin-top: 0;
        }
        #copyOptions.is-open {
            max-height: 400px;
            opacity: 1;
            margin-top: 0.75rem;
        }
        @media (prefers-reduced-motion: reduce) {
            #copyOptions { transition: none; }
        }

        /* ============================================================
           MODAL — DARK MODE
           Keep blue gradient header, rest is #2D2D2D
           ============================================================ */
        [data-bs-theme="dark"] .ay-modal .modal-content {
            background: #2D2D2D !important;
            border: 1px solid #3a3a3a !important;
            box-shadow: 0 8px 32px rgba(0, 0, 0, .75) !important;
        }

        /* Force the blue gradient header even in dark mode */
        [data-bs-theme="dark"] .ay-modal .modal-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%) !important;
            border-bottom: 0 !important;
            border-radius: 16px 16px 0 0 !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-title {
            color: #ffffff !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-header .btn-close {
            filter: brightness(0) invert(1) !important;
            opacity: 0.9 !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-header .btn-close:hover {
            opacity: 1 !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-body {
            background: #2D2D2D !important;
            color: #e4e6e8 !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-footer {
            background: #262626 !important;
            border-top: 1px solid #3a3a3a !important;
            border-radius: 0 0 16px 16px !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-label {
            color: #e4e6e8 !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-control,
        [data-bs-theme="dark"] .ay-modal .form-select {
            background: #1f1f1f !important;
            border-color: #3a3a3a !important;
            color: #e4e6e8 !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-control::placeholder {
            color: #8b939a !important;
            opacity: 1 !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-select option {
            background: #1f1f1f !important;
            color: #e4e6e8 !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-control:focus,
        [data-bs-theme="dark"] .ay-modal .form-select:focus {
            background: #1f1f1f !important;
            border-color: #1a6ef5 !important;
            color: #ffffff !important;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.35) !important;
        }

        [data-bs-theme="dark"] .ay-modal .text-danger {
            color: #ff6b81 !important;
        }

        /* Cancel button visible on dark */
        [data-bs-theme="dark"] .ay-modal .btn-ay-outline {
            background: #3a3a3a !important;
            color: #e4e6e8 !important;
            border-color: #4a4a4a !important;
        }

        [data-bs-theme="dark"] .ay-modal .btn-ay-outline:hover {
            background: #4a4a4a !important;
            border-color: #5a5a5a !important;
            color: #ffffff !important;
        }

        /* Modal backdrop */
        [data-bs-theme="dark"] .modal-backdrop {
            background-color: #000 !important;
        }

        #createCurriculumModal.ay-modal--transition.fade .modal-dialog {
            transition:
                transform var(--stsn-anim-duration) var(--stsn-anim-easing),
                opacity var(--stsn-anim-duration-fast) ease-out !important;
            transform: translateY(var(--stsn-anim-distance)) scale(var(--stsn-anim-scale-from)) !important;
            opacity: 0;
        }

        #createCurriculumModal.ay-modal--transition.show .modal-dialog {
            transform: translateY(0) scale(1) !important;
            opacity: 1 !important;
        }

        @media (prefers-reduced-motion: reduce) {
            #createCurriculumModal.ay-modal--transition.fade .modal-dialog {
                transition: none !important;
            }
        }

        /* MOBILE CARDS */
        /* ============================================================
           CURRICULUM CARDS (one card per academic year)
           ============================================================ */
        /* Compact grid — "baraha" (playing-card) layout: 3-4 per row */
        .curriculum-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(560px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        .curriculum-card {
            background: var(--cy-card);
            border: 1.5px solid #dce8f8;
            border-radius: 14px;
            box-shadow: 0 2px 10px rgba(18,72,168,0.06);
            overflow: hidden;
            transition: all 0.18s ease;
            display: flex;
            flex-direction: column;
            height: 100%;
        }

        /* Clickable card behavior */
        .curriculum-card--clickable {
            cursor: pointer;
            user-select: none;
        }
        .curriculum-card--clickable:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 28px rgba(18,72,168,0.12);
            border-color: #b8d0fa;
        }
        .curriculum-card--clickable:active {
            transform: translateY(-1px);
            box-shadow: 0 4px 14px rgba(18,72,168,0.15);
        }
        .curriculum-card--clickable:focus {
            outline: none;
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26,110,245,0.15),
                        0 10px 28px rgba(18,72,168,0.12);
        }
        .curriculum-card--clickable:focus-visible {
            outline: 2px solid #1a6ef5;
            outline-offset: 2px;
        }

        /* Buttons inside clickable cards should not trigger card click */
        .curriculum-card--clickable .curriculum-card-footer a,
        .curriculum-card--clickable .curriculum-card-footer button {
            cursor: pointer;
            position: relative;
            z-index: 2;
        }

        /* Dark mode */
        [data-bs-theme="dark"] .curriculum-card--clickable:hover {
            border-color: #4a5a6e;
        }

        .curriculum-card--active {
            border-color: #1a6ef5;
            box-shadow: 0 4px 20px rgba(26,110,245,0.15);
        }
        .curriculum-card--archived { opacity: 0.92; }
        .curriculum-card--archived:hover {
            opacity: 1;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(18,72,168,0.12);
        }

        .curriculum-card-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            padding: 1.5rem 2rem;
            border-bottom: 1px solid #e8f0fb;
            background: #fafcff;
            gap: 0.5rem;
        }
        .curriculum-card--active .curriculum-card-header {
            background: linear-gradient(135deg, #f0f6ff 0%, #e6f0ff 100%);
        }

        .curriculum-icon {
            width: 56px;
            height: 56px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.6rem;
            flex-shrink: 0;
        }
        .curriculum-icon--active { background: linear-gradient(135deg, #1a6ef5, #1248a8); color: #fff; }
        .curriculum-icon--archived { background: #f3f5f8; color: #7a8ea8; }

        .curriculum-card-title { font-size: 1.4rem; font-weight: 800; color: #132f62; line-height: 1.25; margin: 0 0 .15rem; }
        .curriculum-card-sub { font-size: 0.9rem; color: #7a93b8; line-height: 1.3; margin: 0; }

        .curriculum-status-badge {
            display: inline-flex;
            align-items: center;
            padding: 0.25rem 0.6rem;
            border-radius: 999px;
            font-size: 0.65rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            white-space: nowrap;
            flex-shrink: 0;
        }
        .curriculum-status--active {
            background: #d1fae5;
            color: #065f46;
            border: 1.5px solid #6ee7b7;
        }
        .curriculum-status--archived {
            background: #f3f5f8;
            color: #7a8ea8;
            border: 1.5px solid #dde4ee;
        }
        .curriculum-status--none {
            background: #f3f5f8;
            color: #64748b;
            border: 1.5px solid #dde4ee;
        }

        .curriculum-card-body { padding: 1.75rem 2rem; flex: 1 1 auto; }
        .curriculum-card-footer {
            display: flex;
            gap: 0.4rem;
            padding: 1.25rem 2rem;
            border-top: 1px solid #e8f0fb;
            background: #fafcff;
            flex-wrap: wrap;
        }
        .curriculum-card-footer .btn {
            font-size: 0.95rem;
            padding: 0.65rem 1.25rem;
            flex: 1 1 auto;
            justify-content: center;
            min-width: 0;
        }
        @media (max-width: 767.98px) {
            .curriculum-grid { grid-template-columns: 1fr; }
        }

        .archived-section-title {
            font-size: 1rem;
            font-weight: 800;
            color: #7a93b8;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            margin-bottom: 1rem;
        }

        /* Dark mode support */
        [data-bs-theme="dark"] .curriculum-card { background: #2D2D2D; border-color: #3a3a3a; }
        [data-bs-theme="dark"] .curriculum-card-header { background: #262626; border-bottom-color: #3a3a3a; }
        [data-bs-theme="dark"] .curriculum-card--active .curriculum-card-header { background: #22304a; }
        [data-bs-theme="dark"] .curriculum-card-title { color: #ffffff; }
        [data-bs-theme="dark"] .curriculum-card-sub { color: #adb5bd; }
        [data-bs-theme="dark"] .curriculum-card-footer { background: #262626; border-top-color: #3a3a3a; }
        [data-bs-theme="dark"] .curriculum-status--archived { background: #333; color: #adb5bd; border-color: #444; }
        [data-bs-theme="dark"] .curriculum-status--none { background: #333; color: #adb5bd; border-color: #444; }

        @media (max-width: 767.98px) {
            .ay-page-header { padding: 1.1rem 1.2rem; border-radius: 14px; }
            .ay-card-footer { justify-content: center; }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3">

                <div class="page-header">
                    <div>
                        <h3><i class="bi bi-journal-bookmark-fill me-2"></i>Curriculum Management</h3>
                        <p>Manage subjects per academic year. Only one curriculum can be active at a time.</p>
                    </div>
                </div>

                <?php require_once __DIR__ . '/includes/breadcrumb.php'; renderBreadcrumb([['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'], ['label' => 'Maintenance', 'icon' => 'bi bi-tools'], ['label' => 'Curriculum', 'icon' => 'bi bi-journal-bookmark-fill']]); ?>
                <?php if (!$activeYear): ?>
                    <div class="text-center text-white py-4 px-4 mb-3 stsn-anim-fade-in-up"
                         style="background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%); border-radius: 16px;">
                        <i class="bi bi-calendar-x" style="font-size: 2.5rem; opacity: 0.9;"></i>
                        <h5 class="text-white mt-3 mb-2 fw-bold">No Active Academic Year</h5>
                        <p class="text-white-50 mb-3 small" style="max-width: 480px; margin: 0 auto;">
                            Create a new academic year to continue.
                        </p>
                        <a href="academic_year.php" class="btn btn-light fw-semibold px-3">
                            <i class="bi bi-plus-circle me-2"></i>Create Academic Year
                        </a>
                    </div>
                <?php else: ?>
                <!-- Toolbar -->
                <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                    <div>
                        <?php if ($activeYear): ?>
                            <span class="text-muted small">
                                <i class="bi bi-check-circle-fill text-success me-1"></i>
                                Active: S.Y. <?= htmlspecialchars($activeYear['year_label']) ?>
                            </span>
                        <?php else: ?>
                            <span class="text-muted small">
                                <i class="bi bi-calendar-x me-1"></i>
                                No active year.
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- ACTIVE CURRICULUM CARD -->
                <?php if ($activeCurriculum):
                    $stats = getCurriculumStats($pdo, (int) $activeCurriculum['id']);
                ?>
                <div class="curriculum-grid">
                <div class="curriculum-card curriculum-card--active curriculum-card--clickable"
                     tabindex="0"
                     role="button"
                     aria-label="Open curriculum for S.Y. <?= htmlspecialchars($activeCurriculum['year_label']) ?>"
                     onclick="window.location.href='Curriculum-Year.php?year_id=<?= (int) $activeCurriculum['id'] ?>'"
                     onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();window.location.href='Curriculum-Year.php?year_id=<?= (int) $activeCurriculum['id'] ?>';}">
                    <div class="curriculum-card-header">
                        <div class="d-flex align-items-center gap-3">
                            <div class="curriculum-icon curriculum-icon--active">
                                <i class="bi bi-journal-bookmark-fill"></i>
                            </div>
                            <div>
                                <h4 class="curriculum-card-title mb-0">
                                    S.Y. <?= htmlspecialchars($activeCurriculum['year_label']) ?>
                                </h4>
                                <p class="curriculum-card-sub mb-0">
                                    <i class="bi bi-calendar3 me-1"></i>
                                    <?= htmlspecialchars((string) $activeCurriculum['start_date']) ?>
                                    &rarr;
                                    <?= htmlspecialchars((string) $activeCurriculum['end_date']) ?>
                                </p>
                            </div>
                        </div>
                        <div>
                            <span class="curriculum-status-badge curriculum-status--active">
                                <i class="bi bi-check-circle-fill me-1"></i> Active
                            </span>
                        </div>
                    </div>

                    <div class="curriculum-card-body">
                        <div class="text-center py-3">
                            <div class="fs-3 fw-bold text-primary"><?= $stats['subjects'] ?></div>
                            <div class="text-muted small text-uppercase">Subjects</div>
                        </div>
                    </div>

                    <div class="curriculum-card-footer">
                        <?php if ($archiveMode === 'MANUAL'): ?>
                        <button class="btn btn-ay btn-ay-danger" onclick="event.stopPropagation(); deactivateCurriculum(<?= (int) $activeCurriculum['id'] ?>)">
                            <i class="bi bi-archive me-1"></i> Deactivate &amp; Archive
                        </button>
                        <?php endif; ?>
                    </div>
                </div>
                </div><!-- /.curriculum-grid -->
                <?php endif; ?>
                <?php if (!$activeCurriculum): ?>
                <div class="curriculum-grid">
                    <div class="curriculum-card curriculum-card--active">
                        <div class="curriculum-card-header">
                            <div class="d-flex align-items-center gap-3">
                                <div class="curriculum-icon curriculum-icon--active">
                                    <i class="bi bi-journal-bookmark-fill"></i>
                                </div>
                                <div>
                                    <h4 class="curriculum-card-title mb-0">
                                        S.Y. <?= htmlspecialchars($activeYear['year_label']) ?>
                                    </h4>
                                    <p class="curriculum-card-sub mb-0">No curriculum has been set up for this year yet.</p>
                                </div>
                            </div>
                            <span class="curriculum-status-badge curriculum-status--none">None</span>
                        </div>
                        <div class="curriculum-card-footer">
                            <button type="button" class="btn btn-ay btn-ay-outline" id="createCurriculumEmptyStateBtn">
                                <i class="bi bi-plus-circle me-1"></i> Create Curriculum
                            </button>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <!-- CREATE NEW CURRICULUM MODAL -->
                <div class="modal fade ay-modal ay-modal--transition" id="createCurriculumModal" tabindex="-1" data-bs-backdrop="static">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <form id="createCurriculumForm">
                                <div class="modal-header">
                                    <h5 class="modal-title"><i class="bi bi-plus-circle-fill me-2"></i>Create New Curriculum</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div id="curriculumSetupFields">
                                        <div class="mb-3">
                                            <label class="form-label">Academic Year <span class="text-danger">*</span></label>
                                            <select class="form-select" name="academic_year_id" required>
                                                <option value="">&mdash; Select Year &mdash;</option>
                                                <?php foreach ($eligibleYears as $y): ?>
                                                    <option value="<?= (int) $y['id'] ?>">S.Y. <?= htmlspecialchars($y['year_label']) ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <div class="form-text">
                                                <?= empty($eligibleYears) ? 'No available years. Create one in Academic Year settings first.' : 'Only years without a curriculum are shown.' ?>
                                            </div>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label">Curriculum Setup</label>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio"
                                                       name="setup_mode" id="modeManual" value="manual" checked>
                                                <label class="form-check-label" for="modeManual">
                                                    Start Empty — Add subjects manually
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio"
                                                       name="setup_mode" id="modeCopy" value="copy"
                                                       <?= empty($previousYears) ? 'disabled' : '' ?>>
                                                <label class="form-check-label" for="modeCopy">
                                                    Copy from Series (Previous Year)
                                                </label>
                                            </div>
                                        </div>

                                        <div id="copyOptions" class="mb-3 ps-3 border-start">
                                            <label class="form-label small" for="sourceYearId">Copy from series of:</label>
                                            <select id="sourceYearId" name="source_year_id" class="form-select form-select-sm" disabled>
                                                <option value="">Select a year...</option>
                                                <?php foreach ($previousYears as $y): ?>
                                                    <option value="<?= (int) $y['id'] ?>">
                                                        S.Y. <?= htmlspecialchars($y['year_label']) ?>
                                                        (<?= (int) $y['subject_count'] ?> subjects)
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                            <?php if (empty($previousYears)): ?>
                                                <div class="form-text">No previous curriculum with subjects is available to copy.</div>
                                            <?php endif; ?>
                                            <div id="copyPreview" class="mt-2 small" aria-live="polite"></div>
                                            <div id="copyConfirm" class="form-check mt-2" style="display:none;">
                                                <input class="form-check-input" type="checkbox" id="ackWarnings">
                                                <label class="form-check-label small" for="ackWarnings">
                                                    I understand some subjects will be skipped
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="copyResult" class="alert alert-warning d-none mb-0" role="alert"></div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-ay btn-ay-outline" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-ay btn-ay-primary">
                                        <i class="bi bi-check-circle me-1"></i> Create Curriculum
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Tree UI moved to Curriculum-Year.php -->

                <?php endif; ?>
            </div>
        </div>
    </main>
    <?php require_once("includes/footer.php"); ?>
</div>


<?php if ($activeYear): ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>
<script>
const APP_BASE = (window.location.pathname.replace(/\/[^\/]*$/, '')) || '';

/* ---- Curriculum-year context (injected by PHP) ---- */
function toast(msg, type = 'success') {
    SystemAlerts.show(msg, type === 'danger' ? 'error' : type);
}

async function api(url, opts = {}) {
    const response = await fetch(url, opts);
    const raw = await response.text();
    if (!response.ok) {
        let msg = `HTTP ${response.status}`;
        try { const j = JSON.parse(raw); if (j && j.error) msg = j.error; } catch (e) { /* not JSON */ }
        console.error('API error:', url, response.status, raw);
        throw new Error(msg);
    }
    try { return JSON.parse(raw); }
    catch (err) {
        console.error('Invalid server response from', url, ':', raw);
        throw new Error(`Invalid server response from ${url}`);
    }
}

/* ============================================================
   Curriculum lifecycle (create / archive)
   ============================================================ */
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('#createCurriculumEmptyStateBtn').forEach(createBtn => {
        if (!createBtn.disabled) {
            createBtn.addEventListener('click', function () {
                const modalEl = document.getElementById('createCurriculumModal');
                if (modalEl) bootstrap.Modal.getOrCreateInstance(modalEl).show();
            });
        }
    });

    const createForm = document.getElementById('createCurriculumForm');
    if (createForm) {
        const manualMode = document.getElementById('modeManual');
        const copyMode = document.getElementById('modeCopy');
        const copyOptions = document.getElementById('copyOptions');
        const sourceYearSelect = document.getElementById('sourceYearId');
        const targetYearSelect = createForm.querySelector('[name="academic_year_id"]');
        const copyPreview = document.getElementById('copyPreview');
        const copyConfirm = document.getElementById('copyConfirm');
        const ackWarnings = document.getElementById('ackWarnings');
        const copyResult = document.getElementById('copyResult');
        const setupFields = document.getElementById('curriculumSetupFields');
        const submitBtn = createForm.querySelector('button[type="submit"]');
        const modalEl = document.getElementById('createCurriculumModal');
        let previewSequence = 0;
        let copyPreviewResult = null;
        let isSubmitting = false;
        let curriculumCreated = false;

        function updateCreateButton() {
            if (!submitBtn) return;
            if (copyMode && copyMode.checked) {
                const warnings = copyPreviewResult && Array.isArray(copyPreviewResult.warnings)
                    ? copyPreviewResult.warnings
                    : [];
                submitBtn.disabled = isSubmitting
                    || !sourceYearSelect.value
                    || !copyPreviewResult
                    || (warnings.length > 0 && !ackWarnings.checked);
            } else {
                submitBtn.disabled = isSubmitting;
            }
        }

        function renderCopyPreview(data) {
            copyPreview.replaceChildren();
            copyConfirm.style.display = data.warnings.length > 0 ? '' : 'none';
            ackWarnings.checked = false;

            const summary = document.createElement('div');
            summary.className = 'alert alert-info small mb-2';
            const count = document.createElement('strong');
            count.textContent = `${data.will_copy} of ${data.total_source_subjects} subjects will be copied.`;
            summary.append(count);
            if (data.will_skip > 0) {
                summary.append(document.createElement('br'), document.createTextNode(`${data.will_skip} subject${data.will_skip === 1 ? '' : 's'} will be skipped (see below).`));
            }
            copyPreview.append(summary);

            if (data.skipped.length > 0) {
                const details = document.createElement('details');
                const summaryLabel = document.createElement('summary');
                summaryLabel.className = 'text-danger';
                summaryLabel.textContent = `View ${data.skipped.length} skipped subject${data.skipped.length === 1 ? '' : 's'}`;
                const list = document.createElement('ul');
                list.className = 'small mt-2 mb-0';
                data.skipped.forEach(item => {
                    const entry = document.createElement('li');
                    entry.textContent = `${item.subject_name} — ${item.reason}`;
                    list.append(entry);
                });
                details.append(summaryLabel, list);
                copyPreview.append(details);
            }

            if (data.warnings.length > 0) {
                const warning = document.createElement('div');
                warning.className = 'alert alert-warning small mt-2 mb-0';
                const icon = document.createElement('i');
                icon.className = 'bi bi-exclamation-triangle-fill me-1';
                warning.append(icon, document.createTextNode(data.warnings.join(' ')));
                copyPreview.append(warning);
            }
        }

        function showCopyResult(result, targetYearId) {
            copyResult.replaceChildren();
            const icon = document.createElement('i');
            icon.className = 'bi bi-exclamation-triangle me-1';
            const heading = document.createElement('strong');
            heading.textContent = `Curriculum created with ${result.copied} subjects.`;
            copyResult.append(icon, heading);

            const skipped = result.skipped_subjects || [];
            if (skipped.length > 0) {
                copyResult.append(document.createElement('br'), document.createTextNode(`${result.skipped} subject${result.skipped === 1 ? '' : 's'} were skipped:`));
                const list = document.createElement('ul');
                list.className = 'mb-2 mt-2';
                skipped.forEach(item => {
                    const entry = document.createElement('li');
                    entry.textContent = `${item.subject_name} — ${item.reason}`;
                    list.append(entry);
                });
                copyResult.append(list);

                const reviewLink = document.createElement('a');
                reviewLink.href = `Curriculum-Year.php?year_id=${encodeURIComponent(targetYearId)}`;
                reviewLink.textContent = 'Review & add skipped subjects manually →';
                copyResult.append(reviewLink);
            }

            copyResult.classList.remove('d-none');
            setupFields.classList.add('d-none');
            if (submitBtn) submitBtn.classList.add('d-none');
            const closeButton = modalEl.querySelector('.modal-footer [data-bs-dismiss="modal"]');
            if (closeButton) closeButton.textContent = 'Done';
            curriculumCreated = true;
        }

        async function previewCopy() {
            const sequence = ++previewSequence;
            copyPreviewResult = null;
            ackWarnings.checked = false;
            copyConfirm.style.display = 'none';
            copyPreview.replaceChildren();
            updateCreateButton();

            const sourceYearId = sourceYearSelect.value;
            const targetYearId = targetYearSelect.value;
            if (!sourceYearId || !targetYearId) {
                copyPreview.textContent = 'Choose a target and source year to preview the copy.';
                return;
            }

            copyPreview.textContent = 'Checking source curriculum…';
            try {
                const url = `${APP_BASE}/api/curriculum/copy-preview.php?source_year_id=${encodeURIComponent(sourceYearId)}&target_year_id=${encodeURIComponent(targetYearId)}`;
                const result = await api(url);
                if (sequence !== previewSequence) return;
                if (!result.success) throw new Error(result.error || 'Unable to preview this curriculum copy.');
                renderCopyPreview(result);
                copyPreviewResult = result;
            } catch (err) {
                if (sequence !== previewSequence) return;
                const error = document.createElement('div');
                error.className = 'alert alert-danger small mb-0';
                error.textContent = err.message;
                copyPreview.append(error);
            }
            updateCreateButton();
        }

        function updateCopyMode() {
            const isCopy = copyMode && copyMode.checked;
            copyOptions.classList.toggle('is-open', isCopy);
            sourceYearSelect.disabled = !isCopy;
            sourceYearSelect.required = !!isCopy;
            if (isCopy) previewCopy();
            else {
                previewSequence++;
                copyPreviewResult = null;
                ackWarnings.checked = false;
                copyConfirm.style.display = 'none';
                updateCreateButton();
            }
        }

        manualMode.addEventListener('change', updateCopyMode);
        if (copyMode) copyMode.addEventListener('change', updateCopyMode);
        sourceYearSelect.addEventListener('change', previewCopy);
        targetYearSelect.addEventListener('change', function () {
            if (copyMode && copyMode.checked) previewCopy();
        });
        ackWarnings.addEventListener('change', updateCreateButton);
        modalEl.addEventListener('hidden.bs.modal', function () {
            if (curriculumCreated) location.reload();
        });

        createForm.addEventListener('submit', async function (e) {
            e.preventDefault();
            const fd = new FormData(createForm);
            const payload = {
                academic_year_id: parseInt(fd.get('academic_year_id'), 10) || 0,
                setup_mode: fd.get('setup_mode') || 'manual',
                source_year_id: parseInt(fd.get('source_year_id'), 10) || 0,
                acknowledge_skips: ackWarnings.checked
            };

            isSubmitting = true;
            updateCreateButton();
            if (submitBtn) submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Creating...';

            try {
                const res = await api(`${APP_BASE}/api/curriculum/create.php`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
                    body: JSON.stringify(payload)
                });
                if (res.success) {
                    if (res.skipped > 0) {
                        showCopyResult(res, payload.academic_year_id);
                        return;
                    }
                    location.reload();
                } else if (res.requires_acknowledgement && res.preview) {
                    renderCopyPreview(res.preview);
                    copyPreviewResult = res.preview;
                    toast('The source changed after preview. Review the updated skipped subjects and acknowledge before creating.', 'danger');
                } else {
                    toast(res.error || 'Failed to create curriculum.', 'danger');
                }
            } catch (err) {
                toast(err.message, 'danger');
            } finally {
                isSubmitting = false;
                if (submitBtn) {
                    submitBtn.innerHTML = '<i class="bi bi-check-circle me-1"></i> Create Curriculum';
                }
                updateCreateButton();
            }
        });
    }
});

async function deactivateCurriculum(yearId) {
    if (!await SystemAlerts.confirm({ title: 'Archive curriculum', message: 'Archive this curriculum? All subjects and grade records will become read-only. This cannot be undone.', confirmText: 'Archive' })) return;

    try {
        const res = await api(`${APP_BASE}/api/curriculum/deactivate.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            body: JSON.stringify({ academic_year_id: yearId })
        });
        if (res.success) {
            location.reload();
        } else {
            toast(res.error || 'Failed to archive curriculum.', 'danger');
        }
    } catch (err) {
        toast(err.message, 'danger');
    }
}

</script>
<?php endif; ?>
</body>
</html>