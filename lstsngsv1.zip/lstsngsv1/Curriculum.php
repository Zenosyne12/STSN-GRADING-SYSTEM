<?php
require_once 'includes/auth.php';
requireAdmin();
require_once 'api/shared/db_connect.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Subjects</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        body { background: #f3f7fd; }

        .ay-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px; padding: 1.4rem 1.6rem; color: #fff;
            margin-bottom: 1.25rem; display: flex; flex-wrap: wrap;
            align-items: center; justify-content: space-between; gap: 1rem;
        }
        .ay-page-header h3 { font-size: 1.25rem; font-weight: 700; margin: 0 0 .2rem; letter-spacing: .01em; }
        .ay-page-header p { margin: 0; font-size: .88rem; opacity: .85; }

        .ay-active-chip {
            display: inline-flex; align-items: center; gap: .45rem;
            background: rgba(255,255,255,.15); border: 1.5px solid rgba(255,255,255,.3);
            border-radius: 999px; padding: .45rem 1rem;
            font-size: .88rem; font-weight: 700; color: #fff; white-space: nowrap;
        }

        .ay-layout {
            display: grid; grid-template-columns: 290px 1fr;
            gap: 1.2rem; align-items: start;
        }
        @media (max-width: 991px) { .ay-layout { grid-template-columns: 1fr; } }

        .ay-card {
            background: #fff; border: 1px solid #dce8f8;
            border-radius: 16px; box-shadow: 0 2px 12px rgba(18,72,168,.06); overflow: hidden;
            margin-bottom: 1.5rem;
        }
        .ay-card-header {
            padding: 1.1rem 1.4rem; border-bottom: 1px solid #e8f0fb;
            display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between;
            gap: .75rem; background: #fff;
        }
        .ay-card-title { font-size: 1rem; font-weight: 700; color: #132f62; margin: 0 0 .15rem; }
        .ay-card-subtitle { font-size: .8rem; color: #7a93b8; margin: 0; }
        .ay-card-footer {
            padding: .75rem 1.2rem; border-top: 1px solid #e8f0fb;
            background: #fafcff; display: flex; justify-content: space-between;
            align-items: center; gap: .75rem; flex-wrap: wrap;
        }
        .ay-footer-note { font-size: .82rem; color: #7a93b8; }

        .ay-tree-wrap { padding: .6rem; }
        .ay-tree-level { margin-bottom: .35rem; }
        .ay-tree-level > summary {
            cursor: pointer; display: flex; align-items: center; gap: .45rem;
            padding: .65rem .75rem; border-radius: 10px; font-weight: 700;
            font-size: .8rem; color: #1248a8; text-transform: uppercase;
            letter-spacing: .05em; user-select: none; list-style: none;
        }
        .ay-tree-level > summary:hover { background: #eef4ff; }
        .ay-tree-level > summary::marker,
        .ay-tree-level > summary::-webkit-details-marker { display: none; }
        .ay-caret { transition: transform .18s; font-size: .75rem; color: #6b84a2; }
        .ay-tree-level[open] > summary .ay-caret { transform: rotate(90deg); }

        .ay-grade-item,
        .ay-strand-item {
            display: flex; align-items: center; gap: .45rem;
            padding: .55rem .75rem .55rem 1.2rem;
            border-radius: 10px; cursor: pointer;
            font-size: .9rem; color: #3a5a82;
            transition: background .12s, color .12s, transform .12s;
            margin-bottom: .2rem;
        }
        .ay-grade-item:hover,
        .ay-strand-item:hover {
            background: #eef4ff; color: #1a6ef5; transform: translateX(2px);
        }
        .ay-grade-item.active,
        .ay-strand-item.active {
            background: linear-gradient(135deg, #1a6ef5, #2a74ef);
            color: #fff; font-weight: 700;
            box-shadow: 0 8px 16px rgba(26,110,245,.18);
        }
        .ay-grade-dot, .ay-strand-dot {
            width: 6px; height: 6px; border-radius: 50%;
            background: #1a6ef5; flex-shrink: 0;
        }
        .ay-grade-item .ay-grade-dot { margin-top: .12rem; }
        .ay-grade-item.active .ay-grade-dot,
        .ay-strand-item.active .ay-strand-dot { background: #fff; }

        .ay-shs-grade { margin-bottom: .3rem; }
        .ay-shs-grade > summary {
            cursor: pointer; display: flex; align-items: center; gap: .45rem;
            padding: .55rem .75rem .55rem 1.2rem; border-radius: 10px;
            font-weight: 700; font-size: .9rem; color: #3a5a82;
            user-select: none; list-style: none;
        }
        .ay-shs-grade > summary:hover { background: #eef4ff; color: #1a6ef5; }
        .ay-shs-grade > summary::marker,
        .ay-shs-grade > summary::-webkit-details-marker { display: none; }
        .ay-shs-grade[open] > summary .ay-caret { transform: rotate(90deg); }
        .ay-shs-grade-list { padding-left: .9rem; padding-top: .15rem; }

        .ay-table { width: 100%; border-collapse: collapse; }
        .ay-table thead th {
            background: #f4f8ff; color: #3b5e96; font-size: .75rem;
            font-weight: 700; text-transform: uppercase; letter-spacing: .06em;
            padding: .85rem 1.2rem; border-bottom: 1.5px solid #dce8f8; white-space: nowrap;
        }
        .ay-table tbody tr:not(:last-child) td { border-bottom: 1px solid #f0f5fc; }
        .ay-table tbody tr:hover td { background: #f7fbff; }
        .ay-table tbody td { padding: .9rem 1.2rem; font-size: .93rem; color: #213a5e; vertical-align: middle; }

        .ay-empty { text-align: center; padding: 2.5rem 1.5rem; color: #9ab0c8; }
        .ay-empty i { font-size: 2.2rem; display: block; margin-bottom: .6rem; opacity: .5; }
        .ay-empty p { margin: 0; font-size: .95rem; }

        .ay-badge {
            display: inline-flex; align-items: center; gap: .3rem;
            padding: .32rem .75rem; border-radius: 999px;
            font-size: .78rem; font-weight: 700; letter-spacing: .03em;
        }
        .ay-badge-active { background: #e6f0ff; color: #1248a8; border: 1.5px solid #b8d0fa; }
        .ay-badge-inactive { background: #f3f5f8; color: #7a8ea8; border: 1.5px solid #dde4ee; }
        .ay-badge-core { background: #eaf2ff; color: #1248a8; border: 1.5px solid #bdd4fb; }
        .ay-badge-applied { background: #e8fbf2; color: #0a6b47; border: 1.5px solid #a9e2ca; }
        .ay-badge-specialized { background: #fff4e9; color: #8a4800; border: 1.5px solid #f8cf98; }
        .ay-badge-elective { background: #f5ebff; color: #5b1a96; border: 1.5px solid #d9b6ff; }

        .btn-ay {
            font-weight: 600; font-size: .82rem; border-radius: 8px;
            padding: .42rem .9rem; cursor: pointer; transition: all .14s;
            border: 1.5px solid transparent; line-height: 1.4;
        }
        .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff; box-shadow: 0 2px 8px rgba(26,110,245,.2);
        }
        .btn-ay-primary:hover { background: linear-gradient(130deg, #1560d8, #103d90); color: #fff; }
        .btn-ay-outline { background: #fff; color: #1a6ef5; border-color: #dce8f8; }
        .btn-ay-outline:hover { background: #eef4ff; border-color: #9cc2fc; }
        .btn-ay-danger { background: #fff5f5; color: #d64545; border-color: #f3c2c2; }
        .btn-ay-danger:hover { background: #ffe8e8; color: #bb2d3b; border-color: #e9a8a8; }
        .btn-ay-sm { padding: .28rem .65rem; font-size: .78rem; }
        .btn-ay-icon { width: 32px; height: 32px; padding: 0; border-radius: 8px;
                       display: inline-flex; align-items: center; justify-content: center; font-size: .85rem; }

        .ay-search {
            border: 1.5px solid #c8daf8; border-radius: 10px;
            padding: .42rem .85rem; font-size: .88rem; color: #213a5e; min-width: 220px;
        }
        .ay-search:focus { border-color: #1a6ef5; outline: none; box-shadow: 0 0 0 3px rgba(26,110,245,.1); }

        .ay-pagination {
            display: flex; gap: .3rem; list-style: none; margin: 0; padding: 0;
            justify-content: flex-end; align-items: center; flex-wrap: wrap;
        }
        .ay-pagination .ay-page-item .ay-page-link {
            display: inline-flex; align-items: center; justify-content: center;
            min-width: 32px; height: 32px; border-radius: 7px; font-size: .83rem;
            font-weight: 600; cursor: pointer; border: 1.5px solid #dce8f8;
            color: #1a6ef5; background: #fff; transition: all .13s; padding: 0 .65rem;
        }
        .ay-pagination .ay-page-item .ay-page-link:hover { background: #eef4ff; border-color: #9cc2fc; }
        .ay-pagination .ay-page-item.active .ay-page-link {
            background: #1a6ef5; border-color: #1a6ef5; color: #fff;
        }
        .ay-pagination .ay-page-item.disabled .ay-page-link {
            background: #f8fbff; border-color: #e2ebf8; color: #9ab0c8;
            cursor: not-allowed; pointer-events: none;
        }

        .ay-context { display: flex; align-items: center; gap: .4rem; flex-wrap: wrap; font-size: .8rem; color: #6b84a2; }
        .ay-context-pill {
            background: #eef4ff; color: #1248a8; border-radius: 999px;
            padding: .2rem .65rem; font-weight: 700; font-size: .76rem;
        }

        .ay-modal .modal-content { border: 0; border-radius: 16px; box-shadow: 0 8px 32px rgba(18,72,168,.16); }
        .ay-modal .modal-header {
            background: #f4f8ff; border-bottom: 1px solid #dce8f8;
            border-radius: 16px 16px 0 0; padding: 1rem 1.3rem;
        }
        .ay-modal .modal-title { font-size: 1rem; font-weight: 700; color: #132f62; }
        .ay-modal .modal-body { padding: 1.3rem; }
        .ay-modal .modal-footer {
            border-top: 1px solid #e8f0fb; padding: .9rem 1.3rem;
            background: #fafcff; border-radius: 0 0 16px 16px;
        }
        .ay-modal .form-label { font-size: .85rem; font-weight: 700; color: #3b5e96; margin-bottom: .4rem; }
        .ay-modal .form-control,
        .ay-modal .form-select {
            border-radius: 10px; border: 1.5px solid #c8daf8;
            min-height: 42px; font-size: .9rem; color: #213a5e; padding: .45rem .85rem;
        }
        .ay-modal .form-control:focus,
        .ay-modal .form-select:focus { border-color: #1a6ef5; box-shadow: 0 0 0 3px rgba(26,110,245,.12); }

        .ay-mobile-card {
            background: #fff; border: 1.5px solid #dce8f8;
            border-radius: 14px; overflow: hidden;
            box-shadow: 0 1px 6px rgba(18,72,168,.05);
        }
        .ay-mobile-card + .ay-mobile-card { margin-top: .75rem; }
        .ay-mobile-card-header {
            display: flex; align-items: center; justify-content: space-between;
            padding: .85rem 1rem; border-bottom: 1px solid #edf3fc; background: #f9fbff;
        }
        .ay-mobile-card-title { font-weight: 700; color: #132f62; font-size: .95rem; }
        .ay-mobile-card-body { padding: .85rem 1rem; }
        .ay-mobile-card-body .grade-label { font-size: .82rem; color: #6b84a2; margin-bottom: .65rem; }

        @media (max-width: 767.98px) {
            .ay-page-header { padding: 1.1rem 1.2rem; border-radius: 14px; }
            .ay-card-footer { justify-content: center; }
            .ay-pagination { justify-content: center; }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3">

                <div class="ay-page-header">
                    <div>
                        <h3><i class="bi bi-journal-bookmark-fill me-2"></i>Curriculum Management</h3>
                        <p>Manage grade subjectsy.</p>
                    </div>
                    <div class="ay-active-chip">
                        <i class="bi bi-mortarboard-fill"></i>
                        Curriculum Maintenance
                    </div>
                </div>

                <div class="ay-layout">
                    <!-- Left: Grade Tree -->
                    <div>
                        <div class="ay-card" style="margin-bottom:0;">
                            <div class="ay-card-header">
                                <div>
                                    <p class="ay-card-title"><i class="bi bi-diagram-3 me-1"></i>Grade Levels</p>
                                    <p class="ay-card-subtitle">Select a grade or strand to manage subjects</p>
                                </div>
                                <span id="navSpinner" class="spinner-border spinner-border-sm text-primary" style="display:none;"></span>
                            </div>
                            <div class="ay-tree-wrap" id="gradeNavWrapper">
                                <div class="ay-empty" style="padding:1.6rem 1rem;">
                                    <span class="spinner-border spinner-border-sm me-1"></span> Loading...
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Right: Subjects Panel -->
                    <div>
                        <div class="ay-card" style="margin-bottom:0;">
                            <div class="ay-card-header">
                                <div>
                                    <p class="ay-card-title mb-1" id="subjectsPanelTitle">Select a grade level</p>
                                    <div class="ay-context" id="subjectsCtx"></div>
                                </div>
                                <div style="display:flex;gap:.5rem;align-items:center;flex-wrap:wrap;" id="subjectsActions"></div>
                            </div>

                            <div class="d-none d-md-block">
                                <table class="ay-table" id="subjectsTable">
                                    <thead>
                                        <tr>
                                            <th style="width:56px;text-align:center;">#</th>
                                            <th>Subject / Learning Area</th>
                                            <th style="width:120px;">Type</th>
                                            <th style="width:120px;text-align:center;">Status</th>
                                            <th style="width:180px;text-align:center;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="subjectsTableBody">
                                        <tr>
                                            <td colspan="5">
                                                <div class="ay-empty">
                                                    <i class="bi bi-arrow-left-circle"></i>
                                                    <p>Choose a grade or strand from the left panel.</p>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <div class="d-block d-md-none p-3" id="subjectsCards"></div>

                            <div class="ay-card-footer">
                                <div class="ay-footer-note" id="subjectsCountText"></div>
                                <ul class="ay-pagination" id="subjectsPagination"></ul>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </main>
    <?php require_once("includes/footer.php"); ?>
</div>

<!-- Subject Modal -->
<div class="modal fade ay-modal" id="subjectModal" tabindex="-1" data-bs-backdrop="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="subjectForm" novalidate>
                <div class="modal-header">
                    <h5 class="modal-title" id="subjectModalTitle"><i class="bi bi-plus-circle me-2"></i>Add Subject</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="sfCurriculumId">
                    <input type="hidden" id="sfGradeLevelId">
                    <input type="hidden" id="sfStrand" value="">
                    <input type="hidden" id="sfCode">

                    <div class="mb-3">
                        <label class="form-label">Subject Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="sfName" maxlength="150" required>
                    </div>

                    <div class="mb-3" id="sfTypeWrap">
                        <label class="form-label">Type</label>
                        <select class="form-select" id="sfType">
                            <option value="CORE">Core</option>
                            <option value="APPLIED">Applied</option>
                            <option value="SPECIALIZED">Specialized</option>
                            <option value="ELECTIVE">Elective</option>
                        </select>
                    </div>

                    <div class="mb-3" id="sfActiveWrap">
                        <label class="form-label">Status</label>
                        <select class="form-select" id="sfActive">
                            <option value="1">Active</option>
                            <option value="0">Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-ay btn-ay-outline" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-ay btn-ay-primary" id="btnSaveSubject">
                        <i class="bi bi-check-circle me-1"></i> Save Subject
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="./js/sweet-alerts.js"></script>
<script>
const APP_BASE = '/Lstsngsv1';

let activeGradeId = null;
let activeStrand  = null;
let activeGrade   = null;
let subjectsCache = [];
let currentPage   = 1;
let searchTerm    = '';
const rowsPerPage = 5;

function toast(msg, type = 'success') {
    const map = {
        success: { title: 'Success', color: 'green',  icon: 'bi bi-check-circle-fill' },
        danger:  { title: 'Error',   color: 'red',    icon: 'bi bi-exclamation-octagon-fill' },
        warning: { title: 'Warning', color: 'yellow', icon: 'bi bi-exclamation-triangle-fill' },
        info:    { title: 'Info',    color: 'blue',   icon: 'bi bi-info-circle-fill' },
    };
    const c = map[type] || map.success;
    iziToast.show({
        title: c.title, message: msg, color: c.color, icon: c.icon,
        iconColor: '#fff', theme: 'light', position: 'topRight',
        timeout: 4000, progressBar: true, close: true, pauseOnHover: true,
        transitionIn: 'fadeInDown', transitionOut: 'fadeOutUp'
    });
}

function confirmAction(message, onYes) {
    iziToast.destroy();
    iziToast.question({
        timeout: 20000, close: false, overlay: true, displayMode: 'once',
        zindex: 99999, title: 'Confirm Delete', message: message,
        position: 'center', color: 'blue', icon: 'bi bi-question-circle-fill', drag: false,
        buttons: [
            ['<button><b>Yes, Delete</b></button>',
                function (instance, toastRef) {
                    instance.hide({ transitionOut: 'fadeOut' }, toastRef, 'button');
                    onYes();
                }, true],
            ['<button>Cancel</button>',
                function (instance, toastRef) {
                    instance.hide({ transitionOut: 'fadeOut' }, toastRef, 'button');
                }]
        ]
    });
}

async function api(url, opts = {}) {
    const response = await fetch(url, opts);
    const raw = await response.text();
    try { return JSON.parse(raw); }
    catch (err) { throw new Error(`Invalid server response from ${url}`); }
}

function escapeHtml(v) {
    return String(v ?? '')
        .replaceAll('&','&amp;').replaceAll('<','&lt;')
        .replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'","&#039;");
}

function typeBadge(type) {
    const m = {
        CORE:        ['ay-badge-core',        'Core'],
        APPLIED:     ['ay-badge-applied',     'Applied'],
        SPECIALIZED: ['ay-badge-specialized', 'Specialized'],
        ELECTIVE:    ['ay-badge-elective',    'Elective'],
    };
    const [cls, lbl] = m[type] || m.CORE;
    return `<span class="ay-badge ${cls}">${lbl}</span>`;
}

function deriveLevelLabel(id) {
    if (id === 1) return 'Kinder';
    if (id >= 2 && id <= 7) return 'Elementary';
    if (id >= 8 && id <= 11) return 'Junior High School';
    if (id >= 12 && id <= 13) return 'Senior High School';
    return '';
}

function isShsGrade(id) {
    return Number(id) === 12 || Number(id) === 13;
}

function buildAutoSubjectCode(name) {
    const code = String(name || '').trim().toUpperCase()
        .replace(/[^A-Z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 50);
    return code || 'SUBJECT';
}

function renderTypeForGrade(type, gradeId) {
    return isShsGrade(gradeId) ? typeBadge(type) : `<span style="color:#9ab0c8;">—</span>`;
}

function clearNavSelection() {
    document.querySelectorAll('.ay-grade-item, .ay-strand-item').forEach(el => el.classList.remove('active'));
}

function openNavPath(sourceEl) {
    const wrapper = document.getElementById('gradeNavWrapper');
    const topLevel = sourceEl.closest('.ay-tree-level');
    const shsGrade = sourceEl.closest('.ay-shs-grade');
    wrapper.querySelectorAll('.ay-tree-level').forEach(det => { det.open = det === topLevel; });
    if (topLevel) {
        topLevel.querySelectorAll('.ay-shs-grade').forEach(det => {
            det.open = shsGrade ? det === shsGrade : false;
        });
    }
}

function wireTreeAccordion(wrapper) {
    const topLevels = Array.from(wrapper.querySelectorAll('.ay-tree-level'));
    topLevels.forEach(det => {
        det.addEventListener('toggle', function () {
            if (this.open) topLevels.forEach(other => { if (other !== this) other.open = false; });
        });
    });
    wrapper.querySelectorAll('.ay-shs-grade').forEach(det => {
        det.addEventListener('toggle', function () {
            if (this.open) {
                const parentTop = this.closest('.ay-tree-level');
                if (!parentTop) return;
                parentTop.querySelectorAll('.ay-shs-grade').forEach(other => {
                    if (other !== this) other.open = false;
                });
            }
        });
    });
}

async function loadTree() {
    document.getElementById('navSpinner').style.display = 'inline-block';
    try {
        const d = await api(`${APP_BASE}/api/curriculum/structure.php`);
        if (!d.success) throw new Error(d.error || 'Failed to load structure.');
        renderTree(d.data || []);
    } catch (e) {
        toast(e.message, 'danger');
        document.getElementById('gradeNavWrapper').innerHTML =
            `<div class="ay-empty"><i class="bi bi-exclamation-circle"></i><p>${escapeHtml(e.message)}</p></div>`;
    } finally {
        document.getElementById('navSpinner').style.display = 'none';
    }
}

function renderTree(tree) {
    const wrap = document.getElementById('gradeNavWrapper');
    wrap.innerHTML = '';
    const icons = { KINDER: 'bi-emoji-smile', ELEM: 'bi-123', JHS: 'bi-building', SHS: 'bi-mortarboard' };
    tree.forEach(level => {
        const det = document.createElement('details');
        det.className = 'ay-tree-level'; det.open = false;
        const sum = document.createElement('summary');
        sum.innerHTML = `<i class="bi bi-chevron-right ay-caret"></i><i class="bi ${icons[level.code] || 'bi-circle'} me-1"></i>${escapeHtml(level.label)}`;
        det.appendChild(sum);
        (level.grades || []).forEach(g => {
            if (g.id === 12 || g.id === 13) det.appendChild(renderShsGradeNode(g));
            else det.appendChild(gradeItem(g));
        });
        wrap.appendChild(det);
    });
    wireTreeAccordion(wrap);
}

function gradeItem(g) {
    const d = document.createElement('div');
    d.className = 'ay-grade-item'; d.dataset.gid = g.id;
    d.innerHTML = `<span class="ay-grade-dot"></span><span>${escapeHtml(g.grade_label)}</span>`;
    d.addEventListener('click', () => selectGrade(g, d));
    return d;
}

function renderShsGradeNode(g) {
    const det = document.createElement('details');
    det.className = 'ay-shs-grade'; det.open = false;
    const sum = document.createElement('summary');
    sum.innerHTML = `<i class="bi bi-chevron-right ay-caret"></i><span class="ay-grade-dot"></span><span>${escapeHtml(g.grade_label)}</span>`;
    det.appendChild(sum);
    const list = document.createElement('div');
    list.className = 'ay-shs-grade-list';
    ['ABM', 'STEM', 'GAS', 'HUMSS'].forEach(strand => {
        const item = document.createElement('div');
        item.className = 'ay-strand-item';
        item.dataset.gid = g.id; item.dataset.strand = strand;
        item.innerHTML = `<span class="ay-strand-dot"></span><span>${strand}</span>`;
        item.addEventListener('click', (e) => { e.stopPropagation(); selectStrand(g, strand, item); });
        list.appendChild(item);
    });
    det.appendChild(list);
    return det;
}

function selectGrade(g, sourceEl = null) {
    activeStrand = null;
    activeGradeId = Number(g.id);
    activeGrade = { id: Number(g.id), grade_label: g.grade_label, level_label: deriveLevelLabel(Number(g.id)) };
    clearNavSelection();
    if (sourceEl) { sourceEl.classList.add('active'); openNavPath(sourceEl); }
    else document.querySelector(`.ay-grade-item[data-gid="${g.id}"]`)?.classList.add('active');
    currentPage = 1; searchTerm = '';
    loadAssignedSubjects(activeGradeId, null);
}

function selectStrand(g, strand, sourceEl) {
    activeGradeId = Number(g.id); activeStrand = strand;
    activeGrade = { id: Number(g.id), grade_label: g.grade_label, level_label: deriveLevelLabel(Number(g.id)) };
    clearNavSelection(); sourceEl.classList.add('active'); openNavPath(sourceEl);
    currentPage = 1; searchTerm = '';
    loadAssignedSubjects(activeGradeId, activeStrand);
}

function updateSubjectTypeVisibility(gradeId) {
    const typeWrap = document.getElementById('sfTypeWrap');
    const typeSelect = document.getElementById('sfType');
    if (isShsGrade(gradeId)) {
        typeWrap.style.display = '';
    } else {
        typeWrap.style.display = 'none';
        typeSelect.value = 'CORE';
    }
}

function updateSubjectsCount(page, listLength, total) {
    const countEl = document.getElementById('subjectsCountText');
    if (!countEl) return;
    if (total === 0) { countEl.textContent = 'No subjects to display.'; return; }
    const start = ((page - 1) * rowsPerPage) + 1;
    const end = start + listLength - 1;
    countEl.textContent = `Showing ${start}-${end} of ${total} subjects`;
}

async function loadAssignedSubjects(gradeId, strand = null) {
    document.getElementById('subjectsTableBody').innerHTML =
        `<tr><td colspan="5"><div class="ay-empty"><span class="spinner-border spinner-border-sm me-1"></span>Loading...</div></td></tr>`;
    try {
        let url = `${APP_BASE}/api/curriculum/assigned_subjects.php?grade_id=${gradeId}`;
        if (strand && isShsGrade(gradeId)) url += `&strand=${encodeURIComponent(strand)}`;
        const d = await api(url);
        if (!d.success) throw new Error(d.error || 'Failed to load subjects.');
        activeGrade = d.grade || activeGrade;
        subjectsCache = d.subjects || [];
        renderAssignedSubjects(subjectsCache, activeGrade, strand);
    } catch (e) { toast(e.message, 'danger'); }
}

function paginate(list, page) {
    const total = list.length;
    const pages = Math.ceil(total / rowsPerPage) || 1;
    const safePage = Math.min(Math.max(page, 1), pages);
    const start = (safePage - 1) * rowsPerPage;
    const paginated = list.slice(start, start + rowsPerPage);
    return { paginated, page: safePage, pages, total };
}

function renderAssignedSubjects(list, grade, strand) {
    let title = `${grade.grade_label || ''} — Assigned Subjects`;
    if (strand) title = `${grade.grade_label || ''} — ${strand} Strand — Assigned Subjects`;
    document.getElementById('subjectsPanelTitle').textContent = title;

    let ctxHtml = grade.level_label ? `<span class="ay-context-pill">${escapeHtml(grade.level_label)}</span>` : '';
    if (strand) ctxHtml += `<span class="ay-context-pill">Strand: ${escapeHtml(strand)}</span>`;
    else if (isShsGrade(grade.id)) ctxHtml += `<span class="ay-context-pill">All Strands</span>`;
    document.getElementById('subjectsCtx').innerHTML = ctxHtml;

    document.getElementById('subjectsActions').innerHTML = `
        <input class="ay-search" type="search" id="searchInput" placeholder="Search subjects...">
        <button type="button" class="btn btn-ay btn-ay-primary" onclick="openSubjectModal()">
            <i class="bi bi-plus-circle me-1"></i> Add Subject
        </button>
    `;

    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.value = searchTerm;
        searchInput.addEventListener('input', e => {
            clearTimeout(window.searchDebounce);
            window.searchDebounce = setTimeout(() => {
                searchTerm = e.target.value.trim().toLowerCase();
                currentPage = 1;
                renderAssignedSubjects(subjectsCache, activeGrade, activeStrand);
            }, 300);
        });
    }

    let filtered = list;
    if (searchTerm) {
        filtered = list.filter(s =>
            (s.subject_name || '').toLowerCase().includes(searchTerm) ||
            (s.subject_code || '').toLowerCase().includes(searchTerm)
        );
    }

    const { paginated, page, pages, total } = paginate(filtered, currentPage);
    const tbody = document.getElementById('subjectsTableBody');
    const cards = document.getElementById('subjectsCards');

    updateSubjectsCount(page, paginated.length, total);

    if (!paginated.length) {
        const emptyHtml = `<div class="ay-empty"><i class="bi bi-book"></i><p>No subjects found.</p></div>`;
        tbody.innerHTML = `<tr><td colspan="5">${emptyHtml}</td></tr>`;
        cards.innerHTML = emptyHtml;
        renderPagination(1, 1, 'subjectsPagination');
        return;
    }

    const offset = (page - 1) * rowsPerPage;

    tbody.innerHTML = paginated.map((s, i) => `
        <tr>
            <td style="text-align:center;color:#9ab0c8;font-size:.82rem;">${offset + i + 1}</td>
            <td>
                <div style="font-weight:700;color:#132f62;">${escapeHtml(s.subject_name)}</div>
                <div style="font-size:.76rem;color:#6b84a2;">${escapeHtml(s.subject_code)}</div>
            </td>
            <td>${renderTypeForGrade(s.subject_type, grade.id)}</td>
            <td style="text-align:center;">
                <span class="ay-badge ${Number(s.is_active) === 1 ? 'ay-badge-active' : 'ay-badge-inactive'}">
                    ${Number(s.is_active) === 1 ? '<i class="bi bi-check-circle-fill"></i> Active' : 'Inactive'}
                </span>
            </td>
            <td style="text-align:center;">
                <div style="display:inline-flex;gap:.35rem;flex-wrap:wrap;">
                    <button type="button" class="btn btn-ay btn-ay-outline btn-ay-icon js-edit-subject"
                        data-id="${Number(s.curriculum_id)}" title="Edit">
                        <i class="bi bi-pencil-square"></i>
                    </button>
                    <button type="button" class="btn btn-ay btn-ay-danger btn-ay-icon js-delete-subject"
                        data-id="${Number(s.curriculum_id)}" data-name="${escapeHtml(s.subject_name)}" title="Delete">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');

    cards.innerHTML = paginated.map((s, i) => `
        <div class="ay-mobile-card">
            <div class="ay-mobile-card-header">
                <span class="ay-mobile-card-title">${offset + i + 1}. ${escapeHtml(s.subject_name)}</span>
                ${renderTypeForGrade(s.subject_type, grade.id)}
            </div>
            <div class="ay-mobile-card-body">
                <div class="grade-label"><i class="bi bi-upc-scan me-1"></i>${escapeHtml(s.subject_code)}</div>
                <div style="display:flex;gap:.4rem;flex-wrap:wrap;align-items:center;">
                    <span class="ay-badge ${Number(s.is_active) === 1 ? 'ay-badge-active' : 'ay-badge-inactive'}">
                        ${Number(s.is_active) === 1 ? 'Active' : 'Inactive'}
                    </span>
                    <button type="button" class="btn btn-ay btn-ay-outline btn-ay-sm js-edit-subject"
                        data-id="${Number(s.curriculum_id)}">
                        <i class="bi bi-pencil-square me-1"></i>Edit
                    </button>
                    <button type="button" class="btn btn-ay btn-ay-danger btn-ay-sm js-delete-subject"
                        data-id="${Number(s.curriculum_id)}" data-name="${escapeHtml(s.subject_name)}">
                        <i class="bi bi-trash me-1"></i>Delete
                    </button>
                </div>
            </div>
        </div>
    `).join('');

    renderPagination(page, pages, 'subjectsPagination');
}

function renderPagination(page, pages, elementId) {
    const pagination = document.getElementById(elementId);
    if (!pagination) return;
    if (pages <= 1) { pagination.innerHTML = ''; return; }

    let html = '';
    html += `<li class="ay-page-item ${page <= 1 ? 'disabled' : ''}">
        <a class="ay-page-link" onclick="${page > 1 ? `goToPage(${page - 1})` : 'return false;'}">Previous</a>
    </li>`;
    for (let n = 1; n <= pages; n++) {
        html += `<li class="ay-page-item ${n === page ? 'active' : ''}">
            <a class="ay-page-link" onclick="goToPage(${n})">${n}</a>
        </li>`;
    }
    html += `<li class="ay-page-item ${page >= pages ? 'disabled' : ''}">
        <a class="ay-page-link" onclick="${page < pages ? `goToPage(${page + 1})` : 'return false;'}">Next</a>
    </li>`;
    pagination.innerHTML = html;
}

function goToPage(page) {
    currentPage = page;
    renderAssignedSubjects(subjectsCache, activeGrade, activeStrand);
}

function openSubjectModalById(id) {
    const row = subjectsCache.find(x => Number(x.curriculum_id) === Number(id));
    if (!row) { toast('Subject not found.', 'warning'); return; }
    openSubjectModal(row);
}

function openSubjectModal(row = null) {
    if (!activeGradeId) { toast('Select a grade or strand first.', 'warning'); return; }
    const gradeId = Number(row ? (row.grade_level_id || activeGradeId) : activeGradeId);
    const strand = row ? (row.strand || activeStrand) : activeStrand;

    document.getElementById('sfCurriculumId').value = row ? row.curriculum_id : '';
    document.getElementById('sfGradeLevelId').value = gradeId;
    document.getElementById('sfStrand').value = strand || '';
    document.getElementById('sfCode').value = row ? (row.subject_code || '') : '';
    document.getElementById('sfName').value = row ? (row.subject_name || '') : '';
    document.getElementById('sfType').value = row ? (row.subject_type || 'CORE') : 'CORE';
    document.getElementById('sfActive').value = row ? Number(row.is_active ?? 1) : 1;

    updateSubjectTypeVisibility(gradeId);

    document.getElementById('subjectModalTitle').innerHTML = row
        ? '<i class="bi bi-pencil-square me-2"></i>Edit Subject'
        : '<i class="bi bi-plus-circle me-2"></i>Add Subject';

    bootstrap.Modal.getOrCreateInstance(document.getElementById('subjectModal')).show();
}

document.getElementById('subjectForm').addEventListener('submit', async function (e) {
    e.preventDefault();
    const gradeId = Number(document.getElementById('sfGradeLevelId').value || 0);
    const subjectName = document.getElementById('sfName').value.trim();
    const strand = document.getElementById('sfStrand').value || null;

    const payload = {
        curriculum_id: document.getElementById('sfCurriculumId').value || null,
        grade_level_id: gradeId,
        strand: strand,
        subject_code: document.getElementById('sfCode').value.trim() || buildAutoSubjectCode(subjectName),
        subject_name: subjectName,
        subject_type: isShsGrade(gradeId) ? document.getElementById('sfType').value : 'CORE',
        is_active: Number(document.getElementById('sfActive').value || 1),
    };

    const btn = document.getElementById('btnSaveSubject');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Saving...';

    try {
        const res = await api(`${APP_BASE}/api/curriculum/save_subject.php`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
        });
        if (res.success) {
            bootstrap.Modal.getInstance(document.getElementById('subjectModal')).hide();
            toast(res.message || 'Subject saved.');
            loadAssignedSubjects(activeGradeId, activeStrand);
        } else { toast(res.error || 'Save failed.', 'danger'); }
    } catch (err) { toast(err.message, 'danger'); }
    finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-check-circle me-1"></i> Save Subject';
    }
});

document.addEventListener('click', function (e) {
    const editBtn = e.target.closest('.js-edit-subject');
    if (editBtn) {
        const id = Number(editBtn.dataset.id || 0);
        if (id > 0) openSubjectModalById(id);
        return;
    }
    const deleteBtn = e.target.closest('.js-delete-subject');
    if (deleteBtn) {
        const id = Number(deleteBtn.dataset.id || 0);
        const name = deleteBtn.dataset.name || '';
        if (id <= 0) { toast('Invalid subject record.', 'danger'); return; }
        confirmAction(`Delete <b>${name}</b> from this grade/strand?`, async () => {
            try {
                const res = await api(`${APP_BASE}/api/curriculum/delete_subject.php`, {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ curriculum_id: id })
                });
                if (res.success) {
                    toast(res.message || 'Deleted.');
                    loadAssignedSubjects(activeGradeId, activeStrand);
                } else { toast(res.error || 'Delete failed.', 'danger'); }
            } catch (err) { toast(err.message || 'Delete request failed.', 'danger'); }
        });
        return;
    }
});

document.getElementById('subjectModal').addEventListener('hidden.bs.modal', () => {
    document.getElementById('subjectForm').reset();
    document.getElementById('sfCurriculumId').value = '';
    document.getElementById('subjectModalTitle').innerHTML = '<i class="bi bi-plus-circle me-2"></i>Add Subject';
});

loadTree();
</script>
</body>
</html>
