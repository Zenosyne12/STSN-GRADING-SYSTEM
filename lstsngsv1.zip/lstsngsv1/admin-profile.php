<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/api/shared/db_connect.php';

requireAdmin();

$adminId = (int) ($_SESSION['user_id'] ?? 0);
$adminData = [];

if ($adminId > 0 && isset($pdo)) {
    try {
        $stmt = $pdo->prepare("
            SELECT u.id, u.username, u.role_id, u.status, u.created_at, u.updated_at, u.must_change_password, r.role_name
            FROM tblusers u
            LEFT JOIN tblrole r ON r.id = u.role_id
            WHERE u.id = ? AND u.role_id = 1
            LIMIT 1
        ");
        $stmt->execute([$adminId]);
        $adminData = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Admin Profile DB Error: " . $e->getMessage());
    }
}

function e($str) {
    return htmlspecialchars($str ?? '-');
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>My Profile | STSN Grading System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="./css/adminlte.css">

  <style>
    .profile-hero-card {
      background: linear-gradient(135deg, #0A2F44 0%, #1a4a6b 100%);
      border-radius: 12px;
      padding: 2rem;
      color: #fff;
      position: relative;
      overflow: hidden;
      margin-bottom: 1.5rem;
    }
    .profile-hero-card::before {
      content: '';
      position: absolute;
      top: -50%;
      right: -10%;
      width: 400px;
      height: 400px;
      background: rgba(255,255,255,0.03);
      border-radius: 50%;
    }
    .profile-avatar {
      width: 90px;
      height: 90px;
      border-radius: 50%;
      background: rgba(255,255,255,0.15);
      border: 3px solid rgba(255,255,255,0.3);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 36px;
      font-weight: 800;
      color: #fff;
      position: relative;
    }
    .profile-avatar-badge {
      position: absolute;
      bottom: 2px;
      right: 2px;
      width: 22px;
      height: 22px;
      background: #198754;
      border-radius: 50%;
      border: 2px solid #0A2F44;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .profile-avatar-badge i { font-size: 10px; color: #fff; }
    .profile-name { font-size: 1.5rem; font-weight: 700; margin-bottom: 0.25rem; }
    .profile-role { font-size: 0.9rem; opacity: 0.85; display: flex; align-items: center; gap: 0.4rem; }
    .profile-meta { display: flex; flex-wrap: wrap; gap: 0.5rem; margin-top: 1rem; }
    .profile-meta-chip {
      background: rgba(255,255,255,0.12);
      border: 1px solid rgba(255,255,255,0.2);
      border-radius: 999px;
      padding: 0.35rem 0.85rem;
      font-size: 0.8rem;
      color: #fff;
      display: inline-flex;
      align-items: center;
      gap: 0.35rem;
    }
    .info-card { border: none; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); height: 100%; }
    .info-card .card-header { background: transparent; border-bottom: 1px solid #e9ecef; padding: 1rem 1.25rem; }
    .info-card .card-header h5 { font-size: 1rem; font-weight: 700; color: #0A2F44; margin: 0; display: flex; align-items: center; gap: 0.5rem; }
    .info-card .card-header h5 i { color: #C5A028; }
    .info-card .card-header small { color: #6c757d; font-size: 0.82rem; }
    .info-card .card-body { padding: 0; }
    .field-row { display: flex; justify-content: space-between; align-items: center; padding: 0.85rem 1.25rem; border-bottom: 1px solid #f0f2f5; gap: 1rem; }
    .field-row:last-child { border-bottom: none; }
    .field-label { font-size: 0.78rem; color: #6c757d; font-weight: 600; text-transform: uppercase; letter-spacing: 0.04em; flex-shrink: 0; }
    .field-value { font-size: 0.92rem; color: #1E2A3E; font-weight: 500; text-align: right; }
    .field-value.muted { color: #6c757d; }
    .badge-pill { display: inline-flex; align-items: center; gap: 0.3rem; padding: 0.25rem 0.65rem; border-radius: 999px; font-size: 0.75rem; font-weight: 700; }
    .badge-success { background: rgba(25,135,84,0.1); color: #198754; }
    .badge-danger  { background: rgba(220,53,69,0.1); color: #dc3545; }
    .badge-warning { background: rgba(245,158,11,0.1); color: #b96f00; }
    .edit-card { border: none; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); }
    .edit-card .card-header { background: transparent; border-bottom: 1px solid #e9ecef; padding: 1rem 1.25rem; }
    .edit-card .card-header h5 { font-size: 1rem; font-weight: 700; color: #0A2F44; margin: 0; display: flex; align-items: center; gap: 0.5rem; }
    .edit-card .card-header h5 i { color: #C5A028; }
    .form-label-custom { font-size: 0.78rem; color: #6c757d; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 0.4rem; }
    .form-control-custom { border: 1px solid #e9ecef; border-radius: 10px; padding: 0.65rem 0.9rem; font-size: 0.92rem; transition: border-color 0.15s, box-shadow 0.15s; }
    .form-control-custom:focus { border-color: #0A2F44; box-shadow: 0 0 0 3px rgba(10,47,68,0.08); }
    .pw-wrap { position: relative; }
    .pw-wrap .form-control-custom { padding-right: 2.5rem; }
    .toggle-pw { position: absolute; right: 0.6rem; top: 50%; transform: translateY(-50%); background: none; border: none; color: #6c757d; cursor: pointer; padding: 0.25rem; font-size: 14px; }
    .toggle-pw:hover { color: #0A2F44; }
    .btn-save { background: #0A2F44; color: #fff; border: none; border-radius: 10px; padding: 0.6rem 1.2rem; font-weight: 600; font-size: 0.9rem; transition: opacity 0.15s; }
    .btn-save:hover { opacity: 0.9; }
    .btn-cancel { background: #f8f9fa; color: #6c757d; border: 1px solid #e9ecef; border-radius: 10px; padding: 0.6rem 1.2rem; font-weight: 600; font-size: 0.9rem; }
    .btn-cancel:hover { background: #e9ecef; }
    .section-divider { font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: #6c757d; display: flex; align-items: center; gap: 0.65rem; margin: 1.5rem 1.25rem 1rem; }
    .section-divider::after { content: ''; flex: 1; height: 1px; background: #e9ecef; }
    .is-invalid { border-color: #dc3545 !important; }
    .invalid-feedback { color: #dc3545; font-size: 0.8rem; margin-top: 0.25rem; display: none; }
    .is-invalid ~ .invalid-feedback { display: block; }
  </style>
</head>

<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">
  <div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
      <div class="app-content-header">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-6">
              <h3 class="mb-0">My Profile</h3>
            </div>
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-end">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Profile</li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div class="app-content">
        <div class="container-fluid">

          <!-- Profile Hero -->
          <div class="profile-hero-card">
            <div class="row align-items-center">
              <div class="col-auto">
                <div class="profile-avatar">
                  <?php
                  $initials = '';
                  $username = $adminData['username'] ?? '';
                  if (!empty($username)) {
                      $parts = preg_split('/[.\s_-]+/', $username);
                      foreach ($parts as $part) {
                          if (!empty($part)) $initials .= strtoupper(substr($part, 0, 1));
                      }
                  }
                  echo substr($initials, 0, 2) ?: 'A';
                  ?>
                  <div class="profile-avatar-badge"><i class="bi bi-check-lg"></i></div>
                </div>
              </div>
              <div class="col">
                <div class="profile-name"><?php echo e($adminData['username'] ?? 'Administrator'); ?></div>
                <div class="profile-role">
                  <i class="bi bi-shield-check"></i>
                  <?php echo e($adminData['role_name'] ?? 'System Administrator'); ?>
                </div>
                <div class="profile-meta">
                  <span class="profile-meta-chip"><i class="bi bi-person-badge"></i> ID: <?php echo e($adminData['id'] ?? '-'); ?></span>
                  <span class="profile-meta-chip"><i class="bi bi-circle-fill" style="font-size:6px"></i> <?php echo e($adminData['status'] ?? 'Active'); ?></span>
                  <span class="profile-meta-chip"><i class="bi bi-calendar3"></i> Since <?php echo !empty($adminData['created_at']) ? date('M Y', strtotime($adminData['created_at'])) : '-'; ?></span>
                </div>
              </div>
              <div class="col-auto d-none d-md-block">
                <button class="btn btn-light" onclick="document.getElementById('edit-section').scrollIntoView({behavior:'smooth'})">
                  <i class="bi bi-pencil-fill"></i> Edit Profile
                </button>
              </div>
            </div>
          </div>

          <!-- Info Cards Row -->
          <div class="row">
            <!-- Account Information -->
            <div class="col-md-6 mb-4">
              <div class="card info-card">
                <div class="card-header">
                  <h5><i class="bi bi-person-lines-fill"></i> Account Information</h5>
                  <small>Your login credentials and account status.</small>
                </div>
                <div class="card-body">
                  <div class="field-row">
                    <span class="field-label">User ID</span>
                    <span class="field-value"><?php echo e($adminData['id']); ?></span>
                  </div>
                  <div class="field-row">
                    <span class="field-label">Username</span>
                    <span class="field-value"><?php echo e($adminData['username']); ?></span>
                  </div>
                  <div class="field-row">
                    <span class="field-label">Role</span>
                    <span class="field-value"><?php echo e($adminData['role_name'] ?? 'Admin'); ?></span>
                  </div>
                  <div class="field-row">
                    <span class="field-label">Status</span>
                    <span class="field-value">
                      <span class="badge-pill <?php echo ($adminData['status'] ?? 'Active') === 'Active' ? 'badge-success' : 'badge-danger'; ?>">
                        <i class="bi bi-circle-fill" style="font-size:6px"></i> <?php echo e($adminData['status'] ?? 'Active'); ?>
                      </span>
                    </span>
                  </div>
                  <div class="field-row">
                    <span class="field-label">Must Change Password</span>
                    <span class="field-value">
                      <span class="badge-pill <?php echo ($adminData['must_change_password'] ?? 0) ? 'badge-warning' : 'badge-success'; ?>">
                        <?php echo ($adminData['must_change_password'] ?? 0) ? 'Yes' : 'No'; ?>
                      </span>
                    </span>
                  </div>
                  <div class="field-row">
                    <span class="field-label">Created</span>
                    <span class="field-value muted"><?php echo !empty($adminData['created_at']) ? date('F j, Y g:i A', strtotime($adminData['created_at'])) : '-'; ?></span>
                  </div>
                  <div class="field-row">
                    <span class="field-label">Last Updated</span>
                    <span class="field-value muted"><?php echo !empty($adminData['updated_at']) ? date('F j, Y g:i A', strtotime($adminData['updated_at'])) : '-'; ?></span>
                  </div>
                </div>
              </div>
            </div>

            <!-- Activity Summary -->
            <div class="col-md-6 mb-4">
              <div class="card info-card">
                <div class="card-header">
                  <h5><i class="bi bi-activity"></i> System Overview</h5>
                  <small>Current system statistics at a glance.</small>
                </div>
                <div class="card-body" id="systemOverviewBody">
                  <div class="field-row">
                    <span class="field-label">Total Teachers</span>
                    <span class="field-value" id="totalTeachers"><i class="bi bi-hourglass-split"></i></span>
                  </div>
                  <div class="field-row">
                    <span class="field-label">Total Students</span>
                    <span class="field-value" id="totalStudents"><i class="bi bi-hourglass-split"></i></span>
                  </div>
                  <div class="field-row">
                    <span class="field-label">Total Subjects</span>
                    <span class="field-value" id="totalSubjects"><i class="bi bi-hourglass-split"></i></span>
                  </div>
                  <div class="field-row">
                    <span class="field-label">Total Sections</span>
                    <span class="field-value" id="totalSections"><i class="bi bi-hourglass-split"></i></span>
                  </div>
                  <div class="field-row">
                    <span class="field-label">Active School Year</span>
                    <span class="field-value" id="activeYear"><i class="bi bi-hourglass-split"></i></span>
                  </div>
                  <div class="field-row">
                    <span class="field-label">Active Quarter</span>
                    <span class="field-value" id="activeQuarter"><i class="bi bi-hourglass-split"></i></span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Edit Profile Form -->
          <div class="row">
            <div class="col-12">
              <div class="card edit-card" id="edit-section">
                <div class="card-header">
                  <h5><i class="bi bi-pencil-square"></i> Edit Profile</h5>
                  <small>Update your username and password.</small>
                </div>
                <div class="card-body p-4">
                  <form id="profileForm" action="api/profile/update_admin.php" method="POST">
                    <input type="hidden" name="user_id" value="<?php echo e($adminData['id'] ?? ''); ?>">

                    <div class="row g-3">
                      <div class="col-md-12">
                        <label class="form-label-custom">Username</label>
                        <input type="text" class="form-control form-control-custom" name="username" id="usernameInput"
                               value="<?php echo e($adminData['username'] ?? ''); ?>" required>
                        <div class="invalid-feedback">Username is required.</div>
                      </div>
                    </div>

                    <div class="section-divider">Change Password (leave blank to keep current)</div>

                    <div class="row g-3">
                      <div class="col-md-4">
                        <label class="form-label-custom">Current Password</label>
                        <div class="pw-wrap">
                          <input type="password" class="form-control form-control-custom" id="currentPassword" name="current_password" placeholder="Required to change password">
                          <button type="button" class="toggle-pw" onclick="togglePassword('currentPassword', this)">
                            <i class="bi bi-eye"></i>
                          </button>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <label class="form-label-custom">New Password</label>
                        <div class="pw-wrap">
                          <input type="password" class="form-control form-control-custom" id="newPassword" name="new_password" placeholder="Min 6 characters">
                          <button type="button" class="toggle-pw" onclick="togglePassword('newPassword', this)">
                            <i class="bi bi-eye"></i>
                          </button>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <label class="form-label-custom">Confirm Password</label>
                        <div class="pw-wrap">
                          <input type="password" class="form-control form-control-custom" id="confirmPassword" name="confirm_password" placeholder="Confirm new password">
                          <button type="button" class="toggle-pw" onclick="togglePassword('confirmPassword', this)">
                            <i class="bi bi-eye"></i>
                          </button>
                        </div>
                        <div class="invalid-feedback" id="passwordMatchError">Passwords do not match.</div>
                      </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4">
                      <button type="button" class="btn-cancel" onclick="location.reload()">Cancel</button>
                      <button type="submit" class="btn-save" id="saveBtn"><i class="bi bi-check-lg"></i> Save Changes</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </main>

    <?php require_once("includes/footer.php"); ?>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="./js/adminlte.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="./js/sweet-alerts.js"></script>

  <script>
    // â”€â”€ Load System Stats â”€â”€
    async function loadSystemStats() {
      try {
        const res = await fetch('api/profile/stats.php');
        const data = await res.json();
        if (data.success) {
          document.getElementById('totalTeachers').textContent = data.teachers ?? '—';
          document.getElementById('totalStudents').textContent = data.students ?? '—';
          document.getElementById('totalSubjects').textContent = data.subjects ?? '—';
          document.getElementById('totalSections').textContent = data.sections ?? '—';
          document.getElementById('activeYear').textContent = data.active_year ?? '—';
          document.getElementById('activeQuarter').textContent = data.active_quarter ?? '—';
        }
      } catch(e) {
        console.error('Stats load failed:', e);
      }
    }
    loadSystemStats();

    // â”€â”€ Form Validation â”€â”€
    document.getElementById('profileForm').addEventListener('submit', function(e) {
      let valid = true;
      const username = document.getElementById('usernameInput');
      const newPw = document.getElementById('newPassword');
      const confirmPw = document.getElementById('confirmPassword');
      const currentPw = document.getElementById('currentPassword');

      // Username required
      if (!username.value.trim()) {
        username.classList.add('is-invalid');
        valid = false;
      } else {
        username.classList.remove('is-invalid');
      }

      // Password match check (only if new password is entered)
      if (newPw.value || confirmPw.value) {
        if (newPw.value !== confirmPw.value) {
          confirmPw.classList.add('is-invalid');
          document.getElementById('passwordMatchError').style.display = 'block';
          valid = false;
        } else {
          confirmPw.classList.remove('is-invalid');
          document.getElementById('passwordMatchError').style.display = 'none';
        }
        if (!currentPw.value) {
          currentPw.classList.add('is-invalid');
          valid = false;
        } else {
          currentPw.classList.remove('is-invalid');
        }
        if (newPw.value && newPw.value.length < 6) {
          newPw.classList.add('is-invalid');
          valid = false;
        } else {
          newPw.classList.remove('is-invalid');
        }
      }

      if (!valid) e.preventDefault();
    });

    // â”€â”€ Password Toggle â”€â”€
    function togglePassword(inputId, btn) {
      const input = document.getElementById(inputId);
      const icon = btn.querySelector('i');
      if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('bi-eye');
        icon.classList.add('bi-eye-slash');
      } else {
        input.type = 'password';
        icon.classList.remove('bi-eye-slash');
        icon.classList.add('bi-eye');
      }
    }

    // â”€â”€ Show Toast Messages from URL params â”€â”€
    const urlParams = new URLSearchParams(window.location.search);
    const successMsg = urlParams.get('success');
    const errorMsg = urlParams.get('error');

    if (successMsg) {
      iziToast.success({
        title: 'Success',
        message: decodeURIComponent(successMsg),
        position: 'topRight',
        timeout: 4000
      });
      window.history.replaceState({}, document.title, window.location.pathname);
    }
    if (errorMsg) {
      iziToast.error({
        title: 'Error',
        message: decodeURIComponent(errorMsg),
        position: 'topRight',
        timeout: 5000
      });
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  </script>
</body>
</html>

