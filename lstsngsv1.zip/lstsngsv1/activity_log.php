<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/api/shared/db_connect.php';

/*
|--------------------------------------------------------------------------
| ACTIVITY LOG
|--------------------------------------------------------------------------
| UI redesigned to match historical_records.php
|--------------------------------------------------------------------------
*/

$search    = trim((string) ($_GET['search'] ?? ''));
$role      = trim((string) ($_GET['role'] ?? ''));
$action    = trim((string) ($_GET['action'] ?? ''));
$startDate = trim((string) ($_GET['start_date'] ?? ''));
$endDate   = trim((string) ($_GET['end_date'] ?? ''));

/*
|--------------------------------------------------------------------------
| Activity Data
|--------------------------------------------------------------------------
*/

$activities = [
    [
        'id' => 1,
        'user' => 'Ricardo Mendoza',
        'initials' => 'RM',
        'role' => 'Admin',
        'action_type' => 'Create',
        'action' => 'Added new student: Juan Dela Cruz',
        'date' => '2026-09-11',
        'time' => '10:21 AM',
        'datetime' => 'Sep 11, 2026, 10:21 AM'
    ],
    [
        'id' => 2,
        'user' => 'Ana Reyes',
        'initials' => 'AR',
        'role' => 'Faculty',
        'action_type' => 'Update',
        'action' => 'Updated grade for Maria Santos — Math Q1',
        'date' => '2026-09-11',
        'time' => '10:05 AM',
        'datetime' => 'Sep 11, 2026, 10:05 AM'
    ],
    [
        'id' => 3,
        'user' => 'Ricardo Mendoza',
        'initials' => 'RM',
        'role' => 'Admin',
        'action_type' => 'Delete',
        'action' => 'Deleted user account: Carlos Bautista',
        'date' => '2026-09-11',
        'time' => '9:47 AM',
        'datetime' => 'Sep 11, 2026, 9:47 AM'
    ],
    [
        'id' => 4,
        'user' => 'Lorna Castillo',
        'initials' => 'LC',
        'role' => 'Faculty',
        'action_type' => 'Login',
        'action' => 'Logged in',
        'date' => '2026-09-11',
        'time' => '9:31 AM',
        'datetime' => 'Sep 11, 2026, 9:31 AM'
    ],
    [
        'id' => 5,
        'user' => 'Ana Reyes',
        'initials' => 'AR',
        'role' => 'Faculty',
        'action_type' => 'Create',
        'action' => 'Submitted grades for Section 10-A — Science Q1',
        'date' => '2026-09-11',
        'time' => '9:14 AM',
        'datetime' => 'Sep 11, 2026, 9:14 AM'
    ],
    [
        'id' => 6,
        'user' => 'Ricardo Mendoza',
        'initials' => 'RM',
        'role' => 'Admin',
        'action_type' => 'Update',
        'action' => 'Updated school year settings: 2026-2027',
        'date' => '2026-09-10',
        'time' => '4:52 PM',
        'datetime' => 'Sep 10, 2026, 4:52 PM'
    ],
    [
        'id' => 7,
        'user' => 'Mark Villanueva',
        'initials' => 'MV',
        'role' => 'Faculty',
        'action_type' => 'Update',
        'action' => 'Updated grade for Jose Marasigan — English Q2',
        'date' => '2026-09-10',
        'time' => '4:33 PM',
        'datetime' => 'Sep 10, 2026, 4:33 PM'
    ],
    [
        'id' => 8,
        'user' => 'Lorna Castillo',
        'initials' => 'LC',
        'role' => 'Faculty',
        'action_type' => 'Create',
        'action' => 'Added attendance record for Section 9-B',
        'date' => '2026-09-10',
        'time' => '3:58 PM',
        'datetime' => 'Sep 10, 2026, 3:58 PM'
    ]
];

/*
|--------------------------------------------------------------------------
| Filter Activities
|--------------------------------------------------------------------------
*/

$filteredActivities = array_values(array_filter(
    $activities,
    static function ($item) use ($search, $role, $action, $startDate, $endDate) {
        $itemRole   = $item['role'] ?? '';
        $itemAction = $item['action_type'] ?? '';
        $itemDate   = $item['date'] ?? '';

        if ($role !== '' && $itemRole !== $role) return false;
        if ($action !== '' && $itemAction !== $action) return false;
        if ($startDate !== '' && $itemDate < $startDate) return false;
        if ($endDate !== '' && $itemDate > $endDate) return false;

        if ($search !== '') {
            $haystack = strtolower(
                ($item['user'] ?? '') . ' ' . $itemRole . ' ' . $itemAction . ' ' . ($item['action'] ?? '')
            );
            if (strpos($haystack, strtolower($search)) === false) return false;
        }
        return true;
    }
));

$totalActivities = count($filteredActivities);

function e($value): string {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>STSN Grading System | Activity Log</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="./css/historical-records.css">

    <style>
        /* ============================================================
           ACTIVITY LOG — LIGHT MODE (default)
           ============================================================ */
        :root,
        [data-bs-theme="light"] {
            --al-card-bg: #ffffff;
            --al-card-soft: #fafcff;
            --al-border: #dce8f8;
            --al-border-soft: #e8f0fb;
            --al-text: #213a5e;
            --al-text-strong: #132f62;
            --al-text-muted: #7a93b8;
            --al-text-dim: #9ab0c8;
            --al-shadow: rgba(18, 72, 168, 0.04);

            --al-avatar-admin-bg: #eef5ff;
            --al-avatar-admin-text: #1769e0;
            --al-avatar-admin-border: #cbdff6;
            --al-avatar-faculty-bg: #fff3f5;
            --al-avatar-faculty-text: #ad5d6d;
            --al-avatar-faculty-border: #f1c8d0;

            --al-badge-create-bg: #ecfaf2;
            --al-badge-create-text: #20804a;
            --al-badge-create-border: #b6e3c9;
            --al-badge-update-bg: #fff8e9;
            --al-badge-update-text: #966b16;
            --al-badge-update-border: #ebd39c;
            --al-badge-delete-bg: #fff0f2;
            --al-badge-delete-text: #bf4b5c;
            --al-badge-delete-border: #edb3bc;
            --al-badge-login-bg: #edf6ff;
            --al-badge-login-text: #2670b9;
            --al-badge-login-border: #b6d8f6;

            --al-search-bg: #ffffff;
            --al-search-border: #c8daf8;
            --al-search-icon: #7a93b8;
            --al-search-placeholder: #9ab0c8;
        }

        /* ============================================================
           ACTIVITY LOG — DARK MODE
           ============================================================ */
        [data-bs-theme="dark"] {
            --al-card-bg: #2D2D2D;
            --al-card-soft: #262626;
            --al-border: #3a3a3a;
            --al-border-soft: #3a3a3a;
            --al-text: #e4e6e8;
            --al-text-strong: #ffffff;
            --al-text-muted: #adb5bd;
            --al-text-dim: #8b939a;
            --al-shadow: rgba(0, 0, 0, 0.35);

            --al-avatar-admin-bg: #1e2a3d;
            --al-avatar-admin-text: #8ab4f8;
            --al-avatar-admin-border: #2d4366;
            --al-avatar-faculty-bg: #3a2430;
            --al-avatar-faculty-text: #f4a6b6;
            --al-avatar-faculty-border: #5a3543;

            --al-badge-create-bg: #17351f;
            --al-badge-create-text: #6ee7a0;
            --al-badge-create-border: #2a5438;
            --al-badge-update-bg: #3a2e13;
            --al-badge-update-text: #f5c56b;
            --al-badge-update-border: #5a4620;
            --al-badge-delete-bg: #3a1f24;
            --al-badge-delete-text: #ff8b9e;
            --al-badge-delete-border: #5a2f38;
            --al-badge-login-bg: #1e2a3d;
            --al-badge-login-text: #8ab4f8;
            --al-badge-login-border: #2d4366;

            --al-search-bg: #3a3a3a;
            --al-search-border: #4a5a6e;
            --al-search-icon: #adb5bd;
            --al-search-placeholder: #adb5bd;
        }

        /* Avatar */
        .activity-avatar {
            width: 36px;
            height: 36px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            font-size: 12px;
            font-weight: 700;
            transition: background 0.15s, color 0.15s, border-color 0.15s;
        }
        .activity-avatar.admin {
            background: var(--al-avatar-admin-bg);
            color: var(--al-avatar-admin-text);
            border: 1px solid var(--al-avatar-admin-border);
        }
        .activity-avatar.faculty {
            background: var(--al-avatar-faculty-bg);
            color: var(--al-avatar-faculty-text);
            border: 1px solid var(--al-avatar-faculty-border);
        }

        /* Action badges */
        .activity-action-badge {
            font-size: 11px;
            font-weight: 700;
            padding: 5px 10px;
            border-radius: 4px;
            transition: background 0.15s, color 0.15s, border-color 0.15s;
        }
        .activity-action-badge.create {
            background: var(--al-badge-create-bg);
            color: var(--al-badge-create-text);
            border: 1px solid var(--al-badge-create-border);
        }
        .activity-action-badge.update {
            background: var(--al-badge-update-bg);
            color: var(--al-badge-update-text);
            border: 1px solid var(--al-badge-update-border);
        }
        .activity-action-badge.delete {
            background: var(--al-badge-delete-bg);
            color: var(--al-badge-delete-text);
            border: 1px solid var(--al-badge-delete-border);
        }
        .activity-action-badge.login {
            background: var(--al-badge-login-bg);
            color: var(--al-badge-login-text);
            border: 1px solid var(--al-badge-login-border);
        }

        /* Toolbar / filter */
        .hr-archive-toolbar.d-block { display: block !important; padding: 15px; }

        .activity-filter-box {
            background: var(--al-card-bg);
            border: 1px solid var(--al-border);
            border-radius: 12px;
            box-shadow: 0 2px 10px var(--al-shadow);
            padding: 15px 16px;
            margin: 0 0 14px;
            color: var(--al-text);
        }
        .activity-filter-box .row { margin: 0; }
        .activity-filter-box .form-label {
            color: var(--al-text-muted) !important;
        }
        .activity-filter-box .form-control,
        .activity-filter-box .form-select {
            background: var(--al-card-bg);
            border-color: var(--al-border);
            color: var(--al-text);
        }
        .activity-filter-box .form-control:focus,
        .activity-filter-box .form-select:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.1);
            background: var(--al-card-bg);
            color: var(--al-text);
        }
        .activity-filter-box .form-select option {
            background: var(--al-card-bg);
            color: var(--al-text);
        }
        [data-bs-theme="dark"] .activity-filter-box .form-control[type="date"]::-webkit-calendar-picker-indicator {
            filter: invert(1);
            cursor: pointer;
        }

        /* ============================================================
           SEARCH INPUT — the main fix
           ============================================================ */
        .hr-archive-search {
            background: var(--al-search-bg) !important;
            border: 1px solid var(--al-search-border) !important;
            border-radius: 10px !important;
            color: var(--al-text) !important;
            transition: border-color 0.15s, box-shadow 0.15s, background 0.15s;
        }
        .hr-archive-search:focus-within {
            border-color: #1a6ef5 !important;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.15) !important;
        }
        .hr-archive-search i {
            color: var(--al-search-icon) !important;
        }
        .hr-archive-search input {
            background: transparent !important;
            border: 0 !important;
            color: var(--al-text) !important;
            width: 100%;
        }
        .hr-archive-search input::placeholder {
            color: var(--al-search-placeholder) !important;
            opacity: 1 !important;
        }

        /* Table cell padding helpers */
        .activity-date-tower { padding-left: 4px; padding-right: 16px; }
        .activity-details-cell { padding-left: 12px; }

        /* ============================================================
           DARK MODE — specific overrides for Bootstrap utility classes
           ============================================================ */
        [data-bs-theme="dark"] .text-dark {
            color: var(--al-text-strong) !important;
        }
        [data-bs-theme="dark"] .text-muted {
            color: var(--al-text-muted) !important;
        }
        [data-bs-theme="dark"] .text-secondary {
            color: var(--al-text-muted) !important;
        }
        [data-bs-theme="dark"] .text-primary {
            color: #8ab4f8 !important;
        }
        [data-bs-theme="dark"] .bg-light {
            background: var(--al-card-soft) !important;
            color: var(--al-text) !important;
        }

        /* Table text colors */
        [data-bs-theme="dark"] .hr-archive-table tbody td {
            color: var(--al-text) !important;
        }
        [data-bs-theme="dark"] .hr-archive-table tbody td .fw-bold {
            color: var(--al-text-strong) !important;
        }

        /* Modal */
        [data-bs-theme="dark"] .modal-content {
            background: var(--al-card-bg) !important;
            color: var(--al-text) !important;
            border: 1px solid var(--al-border) !important;
        }
        [data-bs-theme="dark"] .modal-header,
        [data-bs-theme="dark"] .modal-footer {
            background: var(--al-card-soft) !important;
            color: var(--al-text) !important;
            border-color: var(--al-border) !important;
        }
        [data-bs-theme="dark"] .modal-title {
            color: #8ab4f8 !important;
        }
        [data-bs-theme="dark"] .modal-body {
            background: var(--al-card-bg) !important;
            color: var(--al-text) !important;
        }
        [data-bs-theme="dark"] .modal-body .bg-light {
            background: var(--al-card-soft) !important;
            border-color: var(--al-border) !important;
            color: var(--al-text-muted) !important;
        }
        [data-bs-theme="dark"] .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%);
        }

        /* Page header */
        [data-bs-theme="dark"] .page-header {
            background: linear-gradient(130deg, #0f3573 0%, #0f4fb8 100%) !important;
            color: #ffffff !important;
        }
        [data-bs-theme="dark"] .page-header h3,
        [data-bs-theme="dark"] .page-header p {
            color: #ffffff !important;
        }

        /* Breadcrumb */
        [data-bs-theme="dark"] .breadcrumb,
        [data-bs-theme="dark"] .breadcrumb-wrapper,
        [data-bs-theme="dark"] .hr-breadcrumb {
            background: var(--al-card-bg) !important;
            border-color: var(--al-border) !important;
            color: var(--al-text) !important;
        }
        [data-bs-theme="dark"] .breadcrumb a,
        [data-bs-theme="dark"] .breadcrumb-item a {
            color: #8ab4f8 !important;
        }
        [data-bs-theme="dark"] .breadcrumb-item.active,
        [data-bs-theme="dark"] .breadcrumb-item + .breadcrumb-item::before {
            color: var(--al-text-muted) !important;
        }

        /* Table card & footer */
        [data-bs-theme="dark"] .hr-archive-table-card {
            background: var(--al-card-bg) !important;
            border-color: var(--al-border) !important;
            box-shadow: 0 2px 12px var(--al-shadow) !important;
        }
        [data-bs-theme="dark"] .hr-archive-table thead th {
            background: var(--al-card-soft) !important;
            color: var(--al-text-strong) !important;
            border-bottom-color: var(--al-border) !important;
        }
        [data-bs-theme="dark"] .hr-archive-table tbody tr:hover td {
            background: #353535 !important;
        }
        [data-bs-theme="dark"] .hr-archive-footer {
            background: var(--al-card-soft) !important;
            color: var(--al-text-muted) !important;
            border-top-color: var(--al-border) !important;
        }

        /* Role badge (uses .hr-archive-status) */
        [data-bs-theme="dark"] .hr-archive-status {
            background: #1e2a3d !important;
            color: #8ab4f8 !important;
        }
        [data-bs-theme="dark"] .hr-archive-status.active {
            background: #17351f !important;
            color: #6ee7a0 !important;
        }

        /* View button */
        [data-bs-theme="dark"] .hr-archive-view {
            background: linear-gradient(130deg, #1a6ef5, #1248a8) !important;
            color: #ffffff !important;
        }

        /* Pagination buttons */
        [data-bs-theme="dark"] .btn-outline-secondary {
            color: #adb5bd !important;
            border-color: #4a5a6e !important;
            background: transparent !important;
        }
        [data-bs-theme="dark"] .btn-outline-secondary:hover:not(:disabled) {
            background: #3a3a3a !important;
            color: #ffffff !important;
        }
        [data-bs-theme="dark"] .btn-outline-secondary:disabled {
            color: #5a5a5a !important;
            border-color: #3a3a3a !important;
        }

        /* Page background */
        [data-bs-theme="dark"] .hr-archive-page {
            color: var(--al-text);
        }

        /* Sidebar */
        [data-bs-theme="dark"] .sidebar-wrapper,
        [data-bs-theme="dark"] .app-sidebar,
        [data-bs-theme="dark"] .main-sidebar,
        [data-bs-theme="dark"] .custom-sidebar {
            background-color: #2D2D2D !important;
            color: #e4e6e8 !important;
        }
        [data-bs-theme="dark"] .sidebar-wrapper a,
        [data-bs-theme="dark"] .sidebar-wrapper .nav-link,
        [data-bs-theme="dark"] .sidebar-wrapper .sidebar-brand-text {
            color: #e4e6e8 !important;
        }
        [data-bs-theme="dark"] .sidebar-wrapper .nav-link:hover,
        [data-bs-theme="dark"] .sidebar-wrapper .nav-link.active {
            background-color: #3a3a3a !important;
            color: #ffffff !important;
        }

        /* Footer */
        [data-bs-theme="dark"] .app-footer,
        [data-bs-theme="dark"] footer.main-footer {
            background: #2D2D2D !important;
            color: #adb5bd !important;
            border-top-color: #3a3a3a !important;
        }
    </style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once __DIR__ . '/includes/header.php'; ?>
    <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3 hr-archive-page">

                <!-- PAGE HEADER -->
                <div class="page-header">
                    <div>
                        <h3><i class="bi bi-clock-history me-2"></i>Activity Log</h3>
                        <p>Monitor user actions to ensure system accountability.</p>
                    </div>
                </div>

                <!-- BREADCRUMB -->
                <?php require_once __DIR__ . '/includes/breadcrumb.php'; renderBreadcrumb([
                    ['label' => 'Dashboard', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door'],
                    ['label' => 'System Settings', 'href' => 'admin_settings.php', 'icon' => 'bi bi-gear'],
                    ['label' => 'Activity Log', 'icon' => 'bi bi-clock-history']
                ]); ?>

                <!-- TOOLBAR / FILTERS -->
                <form class="hr-archive-toolbar d-block activity-filter-box" method="get" id="activityFilterForm">
                    <div class="row g-2 align-items-end">
                        <div class="col-md-2">
                            <label class="form-label text-muted small fw-bold mb-1">Role</label>
                            <select name="role" class="form-select form-select-sm">
                                <option value="">All Roles</option>
                                <option value="Admin" <?= $role === 'Admin' ? 'selected' : '' ?>>Admin</option>
                                <option value="Faculty" <?= $role === 'Faculty' ? 'selected' : '' ?>>Faculty</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label text-muted small fw-bold mb-1">Action Type</label>
                            <select name="action" class="form-select form-select-sm">
                                <option value="">All Types</option>
                                <option value="Create" <?= $action === 'Create' ? 'selected' : '' ?>>Create</option>
                                <option value="Update" <?= $action === 'Update' ? 'selected' : '' ?>>Update</option>
                                <option value="Delete" <?= $action === 'Delete' ? 'selected' : '' ?>>Delete</option>
                                <option value="Login" <?= $action === 'Login' ? 'selected' : '' ?>>Login</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label text-muted small fw-bold mb-1">Start Date</label>
                            <input type="date" name="start_date" id="startDate" class="form-control form-control-sm" value="<?= e($startDate) ?>">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label text-muted small fw-bold mb-1">End Date</label>
                            <input type="date" name="end_date" id="endDate" class="form-control form-control-sm" value="<?= e($endDate) ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label text-muted small fw-bold mb-1">Search</label>
                            <div class="hr-archive-search">
                                <i class="bi bi-search"></i>
                                <input type="search" name="search" value="<?= e($search) ?>" placeholder="Name or action...">
                            </div>
                        </div>
                        <div class="col-md-1 d-flex gap-1">
                            <button type="submit" class="btn btn-primary btn-sm w-100 fw-bold">Filter</button>
                        </div>
                    </div>
                </form>

                <!-- TABLE CARD -->
                <section class="hr-archive-table-card">
                    <div class="table-responsive">
                        <table class="hr-archive-table" id="activityTable">
                            <thead>
                                <tr>
                                    <th style="width: 20%;">User</th>
                                    <th style="width: 12%;">Role</th>
                                    <th style="width: 40%;">Action</th>
                                    <th style="width: 18%;">Date &amp; Time</th>
                                    <th style="width: 10%;" class="text-end">Details</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if (!$filteredActivities): ?>
                                <tr>
                                    <td colspan="5" class="hr-archive-empty text-center py-4 text-muted">
                                        No activities found.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($filteredActivities as $activity): ?>
                                    <?php
                                    $roleClass = strtolower((string) ($activity['role'] ?? ''));
                                    $actionClass = strtolower((string) ($activity['action_type'] ?? ''));
                                    ?>
                                    <tr
                                        data-role="<?= e($activity['role'] ?? '') ?>"
                                        data-action="<?= e($activity['action_type'] ?? '') ?>"
                                        data-date="<?= e($activity['date'] ?? '') ?>"
                                        data-user="<?= e($activity['user'] ?? '') ?>"
                                        data-description="<?= e($activity['action'] ?? '') ?>"
                                        data-datetime="<?= e($activity['datetime'] ?? '') ?>"
                                    >
                                        <!-- USER -->
                                        <td>
                                            <div class="d-flex align-items-center gap-2">
                                                <span class="activity-avatar <?= $roleClass ?>">
                                                    <?= e($activity['initials'] ?? '') ?>
                                                </span>
                                                <span class="fw-bold text-dark text-truncate" style="max-width: 150px;">
                                                    <?= e($activity['user'] ?? '') ?>
                                                </span>
                                            </div>
                                        </td>

                                        <!-- ROLE -->
                                        <td>
                                            <span class="hr-archive-status <?= $roleClass === 'admin' ? 'active' : '' ?>" style="font-size: 11px;">
                                                <?= e($activity['role'] ?? '') ?>
                                            </span>
                                        </td>

                                        <!-- ACTION -->
                                        <td>
                                            <div class="d-flex align-items-center gap-2">
                                                <span class="activity-action-badge <?= $actionClass ?> flex-shrink-0">
                                                    <?php if ($actionClass === 'create'): ?>
                                                        + Create
                                                    <?php elseif ($actionClass === 'update'): ?>
                                                        <i class="bi bi-pencil me-1"></i> Update
                                                    <?php elseif ($actionClass === 'delete'): ?>
                                                        × Delete
                                                    <?php elseif ($actionClass === 'login'): ?>
                                                        <i class="bi bi-box-arrow-in-right me-1"></i> Login
                                                    <?php else: ?>
                                                        <?= e($activity['action_type'] ?? '') ?>
                                                    <?php endif; ?>
                                                </span>
                                                <span class="text-muted small text-truncate" title="<?= e($activity['action'] ?? '') ?>">
                                                    <?= e($activity['action'] ?? '') ?>
                                                </span>
                                            </div>
                                        </td>

                                        <!-- DATE -->
                                        <td class="text-muted small activity-date-tower">
                                            <?= e($activity['datetime'] ?? '') ?>
                                        </td>

                                        <!-- DETAILS -->
                                        <td class="text-end activity-details-cell">
                                            <button type="button" class="hr-archive-view" onclick="viewActivity(this)">
                                                View
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- FOOTER -->
                    <footer class="hr-archive-footer">
                        <span id="activityCount">
                            <?= $totalActivities ?> activit<?= $totalActivities === 1 ? 'y' : 'ies' ?> found
                        </span>
                        <div class="d-flex align-items-center gap-2">
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="prevPage" disabled>Previous</button>
                            <span class="btn btn-sm btn-primary disabled" id="pageNumber">1</span>
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="nextPage" disabled>Next</button>
                        </div>
                    </footer>
                </section>
            </div>
        </div>
    </main>

    <?php require_once __DIR__ . '/includes/footer.php'; ?>
</div>

<!-- ACTIVITY DETAILS MODAL -->
<div class="modal fade" id="activityDetailModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-light">
                <h5 class="modal-title fw-bold text-primary"><i class="bi bi-clock-history me-2"></i>Activity Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4">
                <div class="row g-4">
                    <div class="col-6">
                        <div class="text-muted small fw-bold text-uppercase mb-1">User</div>
                        <div class="fw-bold text-dark" id="modalUser"></div>
                    </div>
                    <div class="col-6">
                        <div class="text-muted small fw-bold text-uppercase mb-1">Role</div>
                        <div class="fw-bold text-dark" id="modalRole"></div>
                    </div>
                    <div class="col-6">
                        <div class="text-muted small fw-bold text-uppercase mb-1">Action Type</div>
                        <div class="fw-bold text-dark" id="modalActionType"></div>
                    </div>
                    <div class="col-6">
                        <div class="text-muted small fw-bold text-uppercase mb-1">Date & Time</div>
                        <div class="fw-bold text-dark" id="modalDateTime"></div>
                    </div>
                    <div class="col-12">
                        <div class="text-muted small fw-bold text-uppercase mb-1">Activity Description</div>
                        <div class="p-3 bg-light rounded border text-secondary" id="modalDescription"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- SCRIPTS -->
<script src="./vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>

<script>
/*
|--------------------------------------------------------------------------
| VIEW ACTIVITY
|--------------------------------------------------------------------------
*/
function viewActivity(button) {
    const row = button.closest('tr');
    if (!row) return;

    document.getElementById('modalUser').textContent = row.dataset.user || '';
    document.getElementById('modalRole').textContent = row.dataset.role || '';
    document.getElementById('modalActionType').textContent = row.dataset.action || '';
    document.getElementById('modalDateTime').textContent = row.dataset.datetime || '';
    document.getElementById('modalDescription').textContent = row.dataset.description || '';

    const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('activityDetailModal'));
    modal.show();
}

/*
|--------------------------------------------------------------------------
| RESET (optional)
|--------------------------------------------------------------------------
*/
(function () {
    const resetBtn = document.getElementById('resetBtn');
    if (resetBtn) {
        resetBtn.addEventListener('click', function () {
            window.location.href = 'activity_log.php';
        });
    }
})();

/*
|--------------------------------------------------------------------------
| EXPORT CSV (optional)
|--------------------------------------------------------------------------
*/
(function () {
    const exportCsvBtn = document.getElementById('exportCsvBtn');
    if (!exportCsvBtn) return;

    exportCsvBtn.addEventListener('click', function () {
        const table = document.getElementById('activityTable');
        const rows = table.querySelectorAll('tr');
        let csv = [];

        rows.forEach(function (row) {
            const cells = row.querySelectorAll('th, td');
            let rowData = [];
            cells.forEach(function (cell) {
                let text = cell.innerText.replace(/\s+/g, ' ').trim();
                rowData.push('"' + text.replace(/"/g, '""') + '"');
            });
            if (rowData.length > 0) csv.push(rowData.join(','));
        });

        const blob = new Blob([csv.join('\n')], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'stsn_activity_log_' + new Date().toISOString().slice(0, 10) + '.csv';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    });
})();

/*
|--------------------------------------------------------------------------
| SIMPLE PAGINATION DISPLAY
|--------------------------------------------------------------------------
*/
(function () {
    const rows = Array.from(document.querySelectorAll('#activityTable tbody tr'));
    const validRows = rows.filter(row => !row.querySelector('.hr-archive-empty'));

    const pageSize = 8;
    let currentPage = 1;
    const totalPages = Math.max(1, Math.ceil(validRows.length / pageSize));

    const previous = document.getElementById('prevPage');
    const next = document.getElementById('nextPage');
    const pageNumber = document.getElementById('pageNumber');

    function renderPage() {
        validRows.forEach(function (row, index) {
            const first = (currentPage - 1) * pageSize;
            const last = first + pageSize;
            row.style.display = (index >= first && index < last) ? '' : 'none';
        });

        pageNumber.textContent = currentPage;
        previous.disabled = currentPage <= 1;
        next.disabled = currentPage >= totalPages;
    }

    previous.addEventListener('click', function () {
        if (currentPage > 1) { currentPage--; renderPage(); }
    });

    next.addEventListener('click', function () {
        if (currentPage < totalPages) { currentPage++; renderPage(); }
    });

    renderPage();
})();
</script>

</body>
</html>