<?php
require_once 'includes/auth.php';
requireLogin();
if (!isAdminSession() && !isSuperAdminSession()) {
    redirectTo('/lstsngsv1/login.php');
}
require_once 'api/shared/db_connect.php';

$totalArchivedCount = 0;
try {
    $stmtArchivedTeachers = $pdo->query("SELECT COUNT(*) FROM tblteacher WHERE COALESCE(is_active, 1) = 0");
    $totalArchivedCount = (int) ($stmtArchivedTeachers ? $stmtArchivedTeachers->fetchColumn() : 0);
} catch (Throwable $e) {
    $totalArchivedCount = 0;
}

$defaultTab = isset($_GET['tab']) && $_GET['tab'] === 'archive' ? 'archive' : 'teachers';
?>
<!doctype html>
<html lang="en">
<head>
    <?php require_once __DIR__ . '/includes/theme_head.php'; ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
    <meta charset="utf-8">
    <title>STSN Grading System | Faculty</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="./css/students.css">
    <style>
        .page-header {
            display: none;
        }

        /* ============================================================
           THEME TOKENS — Light & Dark
           ============================================================ */
        :root,
        [data-bs-theme="light"] {
            --ay-bg: #ffffff;
            --ay-bg-soft: #f7fafe;
            --ay-bg-alt: #eef4ff;
            --ay-bg-hover: #f9fbff;
            --ay-border: #e8f0fb;
            --ay-border-soft: #dce8f8;
            --ay-border-input: #c8daf8;
            --ay-text: #213a5e;
            --ay-text-strong: #132f62;
            --ay-text-muted: #7a93b8;
            --ay-text-dim: #9ab0c8;
            --ay-head-bg: #ffffff;
            --ay-head-text: #e8eef7;
            --ay-input-bg: #ffffff;
            --ay-input-text: #213a5e;
            --ay-row-hover: #f7fafe;
            --ay-shadow: rgba(18, 72, 168, .05);
        }

        [data-bs-theme="dark"] {
            --ay-bg: #2D2D2D;
            --ay-bg-soft: #262626;
            --ay-bg-alt: #343434;
            --ay-bg-hover: #343434;
            --ay-border: #3a3a3a;
            --ay-border-soft: #4a5a6e;
            --ay-border-input: #4a5a6e;
            --ay-text: #c8d4e0;
            --ay-text-strong: #e8eef7;
            --ay-text-muted: #94a7bf;
            --ay-text-dim: #6d7f94;
            --ay-head-bg: #2D2D2D;
            --ay-head-text: #e8eef7;
            --ay-input-bg: #3a3a3a;
            --ay-input-text: #e8eef7;
            --ay-row-hover: #343434;
            --ay-shadow: rgba(0, 0, 0, .35);
        }

        body,
        .students-card,
        .ay-card,
        .ay-card-header,
        .ay-card-footer,
        .ay-table,
        .ay-table thead th,
        .ay-table tbody td,
        .ay-search,
        .archive-filter-control,
        .ay-mobile-card {
            transition: background-color .18s ease, color .18s ease, border-color .18s ease;
        }

        /* ============================================================
           PAGE HEADER
           ============================================================ */
        .ay-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            box-shadow: 0 4px 16px rgba(18, 72, 168, .18);
        }

        .ay-page-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 0.2rem;
            letter-spacing: 0.01em;
            color: #fff;
        }

        .ay-page-header p {
            margin: 0;
            font-size: 0.88rem;
            opacity: 0.88;
            color: #fff;
        }

        /* ============================================================
           CARDS
           ============================================================ */
        .students-card,
        .ay-card {
            background: var(--ay-bg);
            border: 1px solid var(--ay-border);
            border-radius: 16px;
            box-shadow: 0 1px 6px var(--ay-shadow);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }

        .ay-card-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid var(--ay-border);
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
            background: var(--ay-bg);
        }

        .ay-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: var(--ay-text-strong);
            margin: 0 0 0.15rem;
        }

        .ay-card-subtitle {
            font-size: 0.8rem;
            color: var(--ay-text-muted);
            margin: 0;
        }

        .ay-toolbar {
            display: flex;
            gap: 0.6rem;
            flex-wrap: wrap;
            align-items: center;
        }

        .ay-search-wrap {
            position: relative;
            min-width: 260px;
        }

        .ay-search-wrap i {
            position: absolute;
            left: 0.95rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--ay-text-muted);
            font-size: 0.9rem;
            pointer-events: none;
        }

        .ay-search {
            width: 100%;
            border-radius: 10px;
            border: 1.5px solid var(--ay-border-input);
            min-height: 42px;
            font-size: 0.9rem;
            color: var(--ay-input-text);
            padding: 0.45rem 0.85rem 0.45rem 2.45rem;
            background: var(--ay-input-bg);
        }

        .ay-search::placeholder {
            color: var(--ay-text-dim);
        }

        .ay-search:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.12);
            outline: none;
            background: var(--ay-input-bg);
            color: var(--ay-input-text);
        }

        .ay-card-body {
            padding: 0;
            overflow-x: auto;
            background: var(--ay-bg);
        }

        #teacherTable {
            min-width: 1180px;
        }

        /* ============================================================
           ARCHIVE FILTER BAR
           ============================================================ */
        .archive-filter-bar {
            display: flex;
            flex-wrap: wrap;
            align-items: flex-end;
            gap: 0.75rem;
            padding: 1rem 1.2rem;
            background: var(--ay-bg-soft);
            border-bottom: 1px solid var(--ay-border);
        }

        .archive-filter-group {
            flex: 1 1 260px;
        }

        .archive-filter-label {
            display: block;
            font-size: 0.78rem;
            font-weight: 700;
            color: var(--ay-text-muted);
            margin-bottom: 0.35rem;
        }

        .archive-filter-control {
            width: 100%;
            border-radius: 10px;
            border: 1.5px solid var(--ay-border-input);
            min-height: 42px;
            font-size: 0.9rem;
            color: var(--ay-input-text);
            padding: 0.45rem 0.85rem;
            background: var(--ay-input-bg);
        }

        .archive-filter-control::placeholder {
            color: var(--ay-text-dim);
        }

        .archive-filter-control:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.12);
            outline: none;
            background: var(--ay-input-bg);
            color: var(--ay-input-text);
        }

        .archive-name {
            font-weight: 700;
            color: var(--ay-text-strong);
            line-height: 1.25;
        }

        .archive-subtext {
            color: var(--ay-text-muted);
            font-size: 0.79rem;
            line-height: 1.35;
        }

        .archive-date {
            white-space: nowrap;
            font-weight: 600;
            color: var(--ay-text);
            font-size: 0.85rem;
        }

        .archive-actions {
            display: flex;
            gap: 0.5rem;
            justify-content: center;
            flex-wrap: nowrap;
        }

        /* ============================================================
           CARD FOOTER
           ============================================================ */
        .ay-card-footer {
            padding: 0.75rem 1.2rem;
            border-top: 1px solid var(--ay-border);
            background: var(--ay-bg);
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 0.75rem;
            flex-wrap: wrap;
        }

        .ay-footer-note {
            font-size: 0.82rem;
            color: var(--ay-text-muted);
        }

        /* ============================================================
           TABLE
           ============================================================ */
        .ay-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
            background: var(--ay-bg);
        }

        .ay-table thead th {
            background: var(--ay-bg) !important;
            color: var(--ay-text-muted) !important;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 0.85rem 1.2rem;
            border-bottom: 1.5px solid var(--ay-border) !important;
            white-space: nowrap;
            text-align: center;
        }

        [data-bs-theme="dark"] .ay-table thead th {
            color: #e8eef7 !important;
        }

        .ay-table tbody tr {
            transition: background 0.12s;
        }

        .ay-table tbody tr:not(:last-child) td {
            border-bottom: 1px solid var(--ay-border) !important;
        }

        .ay-table tbody tr:hover td {
            background: var(--ay-row-hover) !important;
        }

        .ay-table tbody td {
            padding: 0.95rem 1.2rem;
            font-size: 0.93rem;
            color: var(--ay-text) !important;
            vertical-align: middle;
            background: var(--ay-bg);
        }

        .ay-table tbody td .row-num {
            color: var(--ay-text-muted);
            font-size: 0.82rem;
            font-weight: 600;
        }

        .ay-table tbody td a {
            color: #1a6ef5 !important;
            text-decoration: none;
        }

        [data-bs-theme="dark"] .ay-table tbody td a {
            color: #7ab7ff !important;
        }

        .ay-table tbody td a:hover {
            color: #1248a8 !important;
        }

        [data-bs-theme="dark"] .ay-table tbody td a:hover {
            color: #a5ccff !important;
        }

        .teacher-name {
            font-weight: 700;
            color: var(--ay-text-strong);
            line-height: 1.25;
        }

        /* ============================================================
           BADGES
           ============================================================ */
        .ay-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.34rem 0.78rem;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }

        .ay-badge-active {
            background: #e6f9ee;
            color: #178a4c;
            border: 1.5px solid #b6e9cd;
        }

        [data-bs-theme="dark"] .ay-badge-active {
            background: #17351f;
            color: #6ee7a0;
            border-color: #2b5c38;
        }

        .ay-badge-inactive {
            background: #f3f5f8;
            color: #7a8ea8;
            border: 1.5px solid #dde4ee;
        }

        [data-bs-theme="dark"] .ay-badge-inactive {
            background: #3a3a3a;
            color: #a9b8cd;
            border-color: #4a5a6e;
        }

        /* ============================================================
           BUTTONS
           ============================================================ */
        .btn-ay {
            font-weight: 600;
            font-size: 0.82rem;
            border-radius: 8px;
            padding: 0.44rem 0.9rem;
            cursor: pointer;
            transition: background 0.15s, border-color 0.15s, color 0.15s, box-shadow 0.15s, transform 0.15s;
            border: 1.5px solid transparent;
            line-height: 1.4;
        }

        .btn-ay:hover {
            transform: translateY(-1px);
        }

        .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            border-color: transparent;
            box-shadow: 0 2px 8px rgba(26, 110, 245, 0.2);
        }

        .btn-ay-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
            box-shadow: 0 3px 12px rgba(26, 110, 245, 0.3);
        }

        .btn-ay-edit {
            background: #fff8e6;
            color: #8a5c00;
            border-color: #f5d98a;
        }

        .btn-ay-edit:hover {
            background: #fff0c0;
            border-color: #f0c832;
            color: #6e4900;
        }

        [data-bs-theme="dark"] .btn-ay-edit {
            background: #3a2f14;
            color: #ffcc66;
            border-color: #5c4820;
        }

        [data-bs-theme="dark"] .btn-ay-edit:hover {
            background: #4a3c1a;
            border-color: #6e5628;
            color: #ffdd88;
        }

        .btn-ay-activate {
            background: #1a6ef5;
            color: #fff;
            border-color: #1a6ef5;
        }

        .btn-ay-activate:hover {
            background: #1560d8;
            border-color: #1560d8;
            color: #fff;
        }

        .btn-ay-deactivate {
            background: var(--ay-bg);
            color: #1248a8;
            border-color: #b8d0fa;
        }

        .btn-ay-deactivate:hover {
            background: var(--ay-bg-alt);
            border-color: #8db5f7;
            color: #0f3d90;
        }

        [data-bs-theme="dark"] .btn-ay-deactivate {
            background: #3a3a3a;
            color: #7ab7ff;
            border-color: #4a5a6e;
        }

        [data-bs-theme="dark"] .btn-ay-deactivate:hover {
            background: #454545;
            border-color: #5a6a7e;
            color: #a5ccff;
        }

        .btn-ay-archive,
        .btn-ay-delete {
            background: #fdecee;
            color: #b3283f;
            border-color: #f5c2cb;
        }

        .btn-ay-archive:hover,
        .btn-ay-delete:hover {
            background: #fbdbe0;
            border-color: #eda4b1;
            color: #931f31;
        }

        [data-bs-theme="dark"] .btn-ay-archive,
        [data-bs-theme="dark"] .btn-ay-delete {
            background: #3a1f24;
            color: #ff8b9e;
            border-color: #5c2d35;
        }

        [data-bs-theme="dark"] .btn-ay-archive:hover,
        [data-bs-theme="dark"] .btn-ay-delete:hover {
            background: #4a262c;
            border-color: #6e3640;
            color: #ffb0be;
        }

        .btn-ay-info {
            background: var(--ay-bg);
            color: #1a6ef5;
            border-color: var(--ay-border-soft);
        }

        .btn-ay-info:hover {
            background: var(--ay-bg-alt);
            border-color: #9cc2fc;
            color: #1248a8;
        }

        [data-bs-theme="dark"] .btn-ay-info {
            background: #3a3a3a;
            color: #7ab7ff;
            border-color: #4a5a6e;
        }

        [data-bs-theme="dark"] .btn-ay-info:hover {
            background: #454545;
            border-color: #5a6a7e;
            color: #a5ccff;
        }

        .ay-action-group {
            display: flex;
            justify-content: center;
            flex-wrap: nowrap;
            gap: 0.4rem;
            min-width: 116px;
            white-space: nowrap;
        }

        .ay-action-group .btn-ay {
            flex: 0 0 36px;
            width: 36px;
            height: 36px;
            padding: 0;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .ay-action-group .btn-ay i {
            margin: 0 !important;
        }

        .ay-table th:last-child,
        .ay-table td:last-child {
            min-width: 150px;
            white-space: nowrap;
        }

        .ay-mobile-actions {
            display: flex;
            flex-wrap: nowrap;
            gap: 0.4rem;
        }

        .ay-mobile-actions .btn-ay {
            flex: 0 0 36px;
            width: 36px;
            height: 36px;
            padding: 0;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .ay-mobile-actions .btn-ay i {
            margin: 0 !important;
        }

        /* ============================================================
           TOASTS
           ============================================================ */
        .iziToast-wrapper {
            z-index: 10000 !important;
        }

        .iziToast {
            background: var(--ay-bg) !important;
            background-color: var(--ay-bg) !important;
            border: 1px solid var(--ay-border) !important;
            border-radius: 10px !important;
            box-shadow: 0 8px 24px rgba(18, 72, 168, 0.14) !important;
            opacity: 1 !important;
            z-index: 10000 !important;
        }

        .iziToast .iziToast-body,
        .iziToast .iziToast-texts {
            background: var(--ay-bg) !important;
        }

        .iziToast .iziToast-title,
        .iziToast .iziToast-message {
            color: var(--ay-text) !important;
        }

        [data-bs-theme="dark"] .iziToast {
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.55) !important;
        }

        /* ============================================================
           PAGINATION
           ============================================================ */
        .ay-pagination {
            display: flex;
            gap: 0.3rem;
            list-style: none;
            margin: 0;
            padding: 0;
            justify-content: flex-end;
            align-items: center;
            flex-wrap: wrap;
        }

        .ay-pagination .ay-page-item .ay-page-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
            border-radius: 7px;
            font-size: 0.83rem;
            font-weight: 600;
            cursor: pointer;
            border: 1.5px solid var(--ay-border-soft);
            color: #1a6ef5;
            background: var(--ay-bg);
            transition: all 0.13s;
            padding: 0 0.65rem;
            text-decoration: none;
        }

        .ay-pagination .ay-page-item .ay-page-link:hover {
            background: var(--ay-bg-alt);
            border-color: #9cc2fc;
        }

        .ay-pagination .ay-page-item.active .ay-page-link {
            background: #1a6ef5;
            border-color: #1a6ef5;
            color: #fff;
        }

        .ay-pagination .ay-page-item.disabled .ay-page-link {
            background: var(--ay-bg-soft);
            border-color: var(--ay-border);
            color: var(--ay-text-dim);
            cursor: not-allowed;
            pointer-events: none;
        }

        [data-bs-theme="dark"] .ay-pagination .ay-page-item .ay-page-link {
            color: #7ab7ff;
        }

        [data-bs-theme="dark"] .ay-pagination .ay-page-item.disabled .ay-page-link {
            color: #5d6b7d;
        }

        /* ============================================================
           EMPTY STATE
           ============================================================ */
        .ay-empty {
            text-align: center;
            padding: 2.8rem 1.5rem;
            color: var(--ay-text-dim);
        }

        .ay-empty i {
            font-size: 2.35rem;
            display: block;
            margin-bottom: 0.7rem;
            opacity: 0.55;
        }

        .ay-empty p {
            margin: 0;
            font-size: 0.95rem;
        }

        /* ============================================================
           MODALS
           ============================================================ */
        .ay-modal .modal-content {
            border: 0;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(18, 72, 168, .16);
            background: var(--ay-bg);
        }

        .ay-modal .modal-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-bottom: 0;
            border-radius: 16px 16px 0 0;
            padding: 1.15rem 1.3rem;
        }

        .ay-modal .modal-title {
            font-size: 1rem;
            font-weight: 700;
            color: #fff;
        }

        .ay-modal .modal-header .btn-close {
            filter: none;
            opacity: .9;
        }

        .ay-modal .modal-header .btn-close:hover {
            opacity: 1;
        }

        .ay-modal .modal-body {
            padding: 1.3rem;
            background: var(--ay-bg);
            color: var(--ay-text);
        }

        .ay-modal .modal-footer {
            border-top: 1px solid var(--ay-border);
            padding: 0.9rem 1.3rem;
            background: var(--ay-bg-soft);
            border-radius: 0 0 16px 16px;
        }

        .ay-modal .form-label {
            font-size: 0.85rem;
            font-weight: 700;
            color: var(--ay-text-muted);
            margin-bottom: 0.4rem;
        }

        .ay-modal .form-control,
        .ay-modal .form-select {
            border-radius: 10px;
            border: 1.5px solid var(--ay-border-input);
            min-height: 42px;
            font-size: 0.9rem;
            color: var(--ay-input-text);
            padding: 0.45rem 0.85rem;
            background: var(--ay-input-bg);
        }

        .ay-modal .form-control::placeholder {
            color: var(--ay-text-dim);
        }

        .ay-modal .form-control:focus,
        .ay-modal .form-select:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.12);
            background: var(--ay-input-bg);
            color: var(--ay-input-text);
        }

        .ay-modal .form-text {
            font-size: 0.8rem;
            color: var(--ay-text-muted);
            margin-top: 0.45rem;
        }

        /* ============================================================
           MOBILE CARDS
           ============================================================ */
        .ay-mobile-card {
            background: var(--ay-bg);
            border: 1.5px solid var(--ay-border-soft);
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 1px 6px var(--ay-shadow);
        }

        .ay-mobile-card + .ay-mobile-card {
            margin-top: 0.75rem;
        }

        .ay-mobile-card-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            padding: 0.95rem 1rem;
            border-bottom: 1px solid var(--ay-border);
            background: var(--ay-bg-soft);
            gap: 0.75rem;
        }

        .ay-mobile-card-title {
            font-weight: 700;
            color: var(--ay-text-strong);
            font-size: 0.96rem;
            line-height: 1.25;
        }

        .ay-mobile-card-subtitle {
            font-size: 0.82rem;
            color: var(--ay-text-muted);
            margin-top: 0.16rem;
        }

        .ay-mobile-card-body {
            padding: 0.9rem 1rem 0.35rem;
        }

        .ay-mobile-row {
            display: flex;
            justify-content: space-between;
            gap: 0.75rem;
            padding: 0.3rem 0;
            font-size: 0.9rem;
            color: var(--ay-text);
        }

        .ay-mobile-label {
            color: var(--ay-text-muted);
            font-weight: 600;
        }

        .ay-mobile-actions {
            display: grid;
            gap: 0.5rem;
            padding: 0.8rem 1rem 1rem;
        }

        @media (max-width: 767.98px) {
            .ay-page-header {
                padding: 1.1rem 1.2rem;
                border-radius: 14px;
            }
            .ay-search-wrap {
                min-width: 100%;
            }
            .ay-card-footer {
                justify-content: center;
            }
            .archive-actions {
                flex-wrap: wrap;
            }
            .ay-pagination {
                justify-content: center;
            }
        }

        /* ============================================================
           BREADCRUMB — light/dark
           ============================================================ */
        .breadcrumb {
            background: var(--ay-bg) !important;
            border-color: var(--ay-border) !important;
        }

        /* ============================================================
           MODAL — DARK MODE
           Keep blue gradient header, rest is #2D2D2D
           ============================================================ */
        [data-bs-theme="dark"] .ay-modal .modal-content {
            background: #2D2D2D !important;
            border: 1px solid #3a3a3a !important;
            box-shadow: 0 8px 32px rgba(0, 0, 0, .75) !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%) !important;
            border-bottom: 0 !important;
            border-radius: 16px 16px 0 0 !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-title {
            color: #ffffff !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-header .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%) !important;
            opacity: 0.9 !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-header .btn-close:hover {
            opacity: 1 !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-body {
            background: #2D2D2D !important;
            color: #e4e6e8 !important;
        }

        [data-bs-theme="dark"] .ay-modal .modal-footer {
            background: #262626 !important;
            border-top: 1px solid #3a3a3a !important;
            border-radius: 0 0 16px 16px !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-label {
            color: #e4e6e8 !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-control,
        [data-bs-theme="dark"] .ay-modal .form-select {
            background: #1f1f1f !important;
            border-color: #3a3a3a !important;
            color: #e4e6e8 !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-control::placeholder {
            color: #8b939a !important;
            opacity: 1 !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-select option {
            background: #1f1f1f !important;
            color: #e4e6e8 !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-control:focus,
        [data-bs-theme="dark"] .ay-modal .form-select:focus {
            background: #1f1f1f !important;
            border-color: #1a6ef5 !important;
            color: #ffffff !important;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.35) !important;
        }

        [data-bs-theme="dark"] .ay-modal .form-text {
            color: #adb5bd !important;
        }

        [data-bs-theme="dark"] .ay-modal .text-danger {
            color: #ff6b81 !important;
        }

        /* ============================================================
           DATE PICKER ICON — DARK MODE (WHITE)
           ============================================================ */
        [data-bs-theme="dark"] .ay-modal input[type="date"],
        [data-bs-theme="dark"] .ay-modal input[type="time"],
        [data-bs-theme="dark"] .ay-modal input[type="datetime-local"],
        [data-bs-theme="dark"] .ay-modal input[type="month"],
        [data-bs-theme="dark"] .ay-modal input[type="week"] {
            color-scheme: dark !important;
        }

        [data-bs-theme="dark"] .ay-modal input[type="date"]::-webkit-calendar-picker-indicator,
        [data-bs-theme="dark"] .ay-modal input[type="time"]::-webkit-calendar-picker-indicator,
        [data-bs-theme="dark"] .ay-modal input[type="datetime-local"]::-webkit-calendar-picker-indicator,
        [data-bs-theme="dark"] .ay-modal input[type="month"]::-webkit-calendar-picker-indicator,
        [data-bs-theme="dark"] .ay-modal input[type="week"]::-webkit-calendar-picker-indicator {
            background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23ffffff'%3E%3Cpath d='M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4H1z'/%3E%3C/svg%3E") !important;
            background-repeat: no-repeat !important;
            background-position: center !important;
            background-size: 16px 16px !important;
            filter: none !important;
            opacity: 1 !important;
            cursor: pointer !important;
            width: 16px !important;
            height: 16px !important;
        }

        /* Also handle inputs outside modal (filter bars, etc.) */
        [data-bs-theme="dark"] input[type="date"],
        [data-bs-theme="dark"] input[type="time"],
        [data-bs-theme="dark"] input[type="datetime-local"] {
            color-scheme: dark;
        }

        [data-bs-theme="dark"] input[type="date"]::-webkit-calendar-picker-indicator,
        [data-bs-theme="dark"] input[type="time"]::-webkit-calendar-picker-indicator,
        [data-bs-theme="dark"] input[type="datetime-local"]::-webkit-calendar-picker-indicator {
            background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23ffffff'%3E%3Cpath d='M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4H1z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: center;
            background-size: 16px 16px;
            filter: none;
            cursor: pointer;
        }

        /* Cancel button in modal footer visible on dark */
        [data-bs-theme="dark"] .ay-modal .btn-ay-deactivate {
            background: #3a3a3a !important;
            color: #e4e6e8 !important;
            border-color: #4a4a4a !important;
        }

        [data-bs-theme="dark"] .ay-modal .btn-ay-deactivate:hover {
            background: #4a4a4a !important;
            border-color: #5a5a5a !important;
            color: #ffffff !important;
        }

        /* Modal backdrop */
        [data-bs-theme="dark"] .modal-backdrop {
            background-color: #000 !important;
        }

        /* Account information panel inside edit modal */
        [data-bs-theme="dark"] #editAccountDetails .border-top {
            border-top-color: #3a3a3a !important;
        }

        [data-bs-theme="dark"] #editAccountDetails .text-muted {
            color: #94a7bf !important;
        }
    /* ============================================================
   Standardized Deactivate Button (pill design)
   ============================================================ */
.btn-deactivate {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.42rem 1rem;
    background: #ffffff;
    color: #1248a8;
    border: 1.5px solid #b8d0fa;
    border-radius: 999px;
    font-size: 0.88rem;
    font-weight: 600;
    line-height: 1.4;
    cursor: pointer;
    transition: all 0.15s ease;
    text-decoration: none;
}
.btn-deactivate:hover {
    background: #eef4ff;
    border-color: #8db5f7;
    color: #1248a8;
}
.btn-deactivate:active {
    background: #dde8ff;
    border-color: #6ba3f0;
}
.btn-deactivate i {
    font-size: 1rem;
    line-height: 1;
}
/* Active state (currently active — to deactivate) */
.btn-deactivate.is-active-state {
    color: #1248a8;
    border-color: #b8d0fa;
}
/* Inactive state (currently inactive — to activate) */
.btn-deactivate.is-inactive-state {
    color: #0F6E56;
    border-color: #a8e6c8;
}
.btn-deactivate.is-inactive-state:hover {
    background: #e8f9f2;
    border-color: #6bd49b;
}

/* ============================================================
   Deactivate / Activate action buttons (btn-am)
   ============================================================ */
.btn-am {
    font-weight: 600; font-size: 0.82rem;
    border-radius: 8px; padding: 0.42rem 0.9rem;
    cursor: pointer; transition: all 0.14s;
    border: 1.5px solid transparent; line-height: 1.4;
    display: inline-flex; align-items: center; gap: 0.35rem;
}
.btn-am-deactivate {
    background: #fff; color: #1248a8; border-color: #b8d0fa;
}
.btn-am-deactivate:hover { background: #eef4ff; border-color: #8db5f7; }
.btn-am-activate {
    background: #e8f9f2; color: #0F6E56; border-color: #a8e6c8;
}
.btn-am-activate:hover { background: #d8f3e5; border-color: #6bd49b; }
</style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3">
                <div class="ay-page-header">
                    <div>
                        <h3><i class="bi bi-person-badge-fill me-2"></i>Faculty Management</h3>
                        <p>Manage, add, and update faculty records</p>
                    </div>
                </div>

                <?php require_once __DIR__ . '/includes/breadcrumb.php'; renderBreadcrumb([['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'], ['label' => 'Users', 'href' => 'manageA.php', 'icon' => 'bi bi-people'], ['label' => 'Faculty', 'icon' => 'bi bi-person-badge-fill']]); ?>

                <div class="students-card">
                    <!-- TEACHERS PANE -->
                    <div id="pane-teachers">
                        <div class="ay-card-header">
                            <div>
                                <p class="ay-card-title">Faculty List</p>
                                <p class="ay-card-subtitle">Add, edit, search, and manage faculty accounts.</p>
                            </div>
                            <div class="ay-toolbar">
                                <div class="ay-search-wrap">
                                    <i class="bi bi-search"></i>
                                    <input type="search" class="ay-search" id="searchInput" placeholder="Search faculty name, ID, or email...">
                                </div>
                                <button type="button" class="btn btn-ay btn-ay-primary" onclick="openCreateTeacher()" data-bs-toggle="modal" data-bs-target="#teacherModal">
                                    <i class="bi bi-plus-circle me-1"></i> New Faculty
                                </button>
                            </div>
                        </div>

                        <div class="ay-card-body">
                            <div class="d-none d-md-block">
                                <table class="ay-table" id="teacherTable">
                                    <thead>
                                        <tr>
                                            <th style="width:64px;">#</th>
                                            <th>Teacher ID / Employee ID</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Sex</th>
                                            <th>Contact</th>
                                            <th>Date Hired</th>
                                            <th>Account Status</th>
                                            <th>Created</th>
                                            <th style="width:230px;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="teacherTableBody">
                                        <tr>
                                            <td colspan="10">
                                                <div class="ay-empty">
                                                    <i class="bi bi-hourglass-split"></i>
                                                    <p>Loading teachers...</p>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="d-block d-md-none p-3" id="teacherCardView"></div>
                        </div>

                        <div class="ay-card-footer">
                            <div class="ay-footer-note" id="teacherCountText"></div>
                            <ul class="ay-pagination" id="pagination"></ul>
                        </div>
                    </div>

                    <!-- ARCHIVE PANE (hidden from UI) -->
                    <div id="pane-archive" style="display:none !important;">
                        <div class="archive-filter-bar">
                            <div class="archive-filter-group">
                                <label for="archiveSearchInput" class="archive-filter-label">Search</label>
                                <input type="text" id="archiveSearchInput" class="archive-filter-control" placeholder="Search archived teacher name, ID, or email...">
                            </div>
                            <div class="archive-filter-group" style="flex: 0 0 auto; min-width: 140px;">
                                <label class="archive-filter-label">&nbsp;</label>
                                <button type="button" class="btn btn-ay btn-ay-deactivate w-100" id="clearArchiveFiltersBtn">
                                    <i class="bi bi-x-circle me-1"></i> Clear
                                </button>
                            </div>
                        </div>

                        <div class="ay-card-header">
                            <div>
                                <p class="ay-card-title">Teacher Archive</p>
                                <p class="ay-card-subtitle">View, restore, or permanently delete archived teacher records.</p>
                            </div>
                        </div>

                        <div class="ay-card-body">
                            <div class="d-none d-md-block">
                                <table class="ay-table" id="archiveTable">
                                    <thead>
                                        <tr>
                                            <th style="width:64px;">#</th>
                                            <th>Teacher ID / Employee ID</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th style="width:150px;">Archive Type</th>
                                            <th style="width:180px;">Archived Date</th>
                                            <th style="width:220px;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="archiveTableBody">
                                        <tr>
                                            <td colspan="7">
                                                <div class="ay-empty">
                                                    <i class="bi bi-hourglass-split"></i>
                                                    <p>Loading archived teachers...</p>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="d-block d-md-none p-3" id="archiveCardView"></div>
                        </div>

                        <div class="ay-card-footer">
                            <div class="ay-footer-note" id="archiveCountText"></div>
                            <ul class="ay-pagination" id="archivePagination"></ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php require_once("includes/footer.php"); ?>
</div>

<div class="modal fade ay-modal" id="teacherModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="false">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <form id="teacherForm">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle"><i class="bi bi-person-plus me-2"></i>Add Teacher</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="teacherRecId">
                    <input type="hidden" id="isActive" value="1">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Teacher ID / Employee ID <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="teacherId" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="email" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">First Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="fname" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Middle Name</label>
                            <input type="text" class="form-control" id="mname">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Last Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="lname" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Date Hired <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="dateHired" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Sex <span class="text-danger">*</span></label>
                            <select class="form-select" id="sex" required>
                                <option value="">— Select sex —</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Contact No <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="contactNo" required>
                        </div>
                        <div class="col-12" id="editAccountDetails" style="display:none;"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-ay btn-ay-deactivate" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle me-1"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-ay btn-ay-primary" id="teacherSubmitButton">
                        <i class="bi bi-envelope-arrow-up me-1"></i> Save &amp; Send Email
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>
<script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>
<script>
    let currentPage = 1;
    let searchTerm = '';
    let totalTeachers = 0;
    const rowsPerPage = 5;
    let searchTimer = null;
    let currentArchivePage = 1;
    let archiveSearchTerm = '';
    let archiveSearchTimer = null;

    function esc(str) {
        return (str ?? '').toString()
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');
    }

    function showAlert(message, type = 'success') {
        const config = {
            success: { title: 'Success', color: 'blue', icon: 'bi bi-check-circle-fill' },
            danger: { title: 'Error', color: 'red', icon: 'bi bi-exclamation-octagon-fill' },
            warning: { title: 'Warning', color: 'yellow', icon: 'bi bi-exclamation-triangle-fill' },
            info: { title: 'Info', color: 'blue', icon: 'bi bi-info-circle-fill' }
        };
        const selected = config[type] || config.success;
        iziToast.show({
            title: selected.title,
            message: message,
            color: selected.color,
            icon: selected.icon,
            iconColor: '#fff',
            theme: 'light',
            position: 'topRight',
            timeout: 4000,
            progressBar: true,
            close: true,
            pauseOnHover: true,
            drag: true,
            transitionIn: 'fadeInDown',
            transitionOut: 'fadeOutUp',
            maxWidth: 420,
            zindex: 10000
        });
    }

    function showConfirm(action, onYes) {
        iziToast.question({
            timeout: 20000,
            close: false,
            overlay: true,
            displayMode: 'once',
            id: 'teacher-confirm',
            zindex: 9999,
            title: 'Confirm Action',
            message: `Are you sure you want to ${action}?`,
            position: 'center',
            color: 'blue',
            icon: 'bi bi-question-circle-fill',
            buttons: [
                [
                    '<button><b>Yes</b></button>',
                    async function(instance, toast) {
                        instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');
                        await onYes();
                    },
                    true
                ],
                [
                    '<button>No</button>',
                    function(instance, toast) {
                        instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');
                    }
                ]
            ]
        });
    }

    async function fetchJson(url, options = {}) {
        const response = await fetch(url, options);
        const raw = await response.text();

        try {
            return JSON.parse(raw);
        } catch (e) {
            console.error('Non-JSON response:', raw);
            throw new Error('Server returned an invalid response.');
        }
    }

    function buildFullName(t) {
        return [t.fname, t.mname, t.lname]
            .filter(part => part && String(part).trim() !== '')
            .join(' ')
            .replace(/\s+/g, ' ')
            .trim();
    }

    function formatDate(value) {
        if (!value) return 'Not recorded';
        const date = new Date(String(value).replace(' ', 'T'));
        if (Number.isNaN(date.getTime())) return value;
        return date.toLocaleDateString(undefined, {
            year: 'numeric',
            month: 'short',
            day: '2-digit'
        });
    }

    function updateTeacherCount(page, listLength) {
        const countEl = document.getElementById('teacherCountText');

        if (!countEl) return;

        if (totalTeachers === 0) {
            countEl.textContent = 'No teachers to display.';
            return;
        }

        const start = ((page - 1) * rowsPerPage) + 1;
        const end = start + listLength - 1;

        countEl.textContent = `Showing ${start}-${end} of ${totalTeachers} teachers`;
    }

    function updateArchiveCount(total = 0) {
        const countEl = document.getElementById('archiveCountText');
        if (!countEl) return;

        if (total === 0) {
            countEl.textContent = 'No archived teachers to display.';
        }
    }

    async function loadTeachers(page = 1) {
        currentPage = page;
        try {
            const data = await fetchJson(`api/teacher/read.php?p=${page}&s=${encodeURIComponent(searchTerm)}`);
            totalTeachers = Number(data.total || 0);
            render(data.teachers || [], data.page || 1, data.pages || 1);
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    function render(list, page, pages) {
        const tableBody = document.getElementById('teacherTableBody');
        const cardView = document.getElementById('teacherCardView');
        const pagination = document.getElementById('pagination');

        updateTeacherCount(page, list.length);

        if (!list.length) {
            const emptyText = searchTerm.trim() ? 'No teachers matched your search.' : 'No teachers found.';
            const emptyHtml = `
                <div class="ay-empty">
                    <i class="bi bi-person-x"></i>
                    <p>${emptyText}</p>
                </div>
            `;
            tableBody.innerHTML = `<tr><td colspan="10">${emptyHtml}</td></tr>`;
            cardView.innerHTML = emptyHtml;
            pagination.innerHTML = '';
            return;
        }

        const offset = (page - 1) * rowsPerPage;

        tableBody.innerHTML = list.map((t, i) => {
            const fullName = buildFullName(t);
            const toggleBtn = Number(t.is_active) === 1
                ? `<button class="btn-am btn-am-deactivate" onclick="toggleTeacher(${t.id}, 0)" title="Deactivate (archive)" aria-label="Deactivate"><i class="bi bi-power"></i> Deactivate</button>`
                : `<button class="btn-am btn-am-activate" onclick="toggleTeacher(${t.id}, 1)"><i class="bi bi-play-circle"></i> Activate</button>`;
            const accountStatus = t.account_id
                ? (t.account_status === 'Active'
                    ? '<span class="ay-badge ay-badge-active">Active</span>'
                    : '<span class="ay-badge ay-badge-inactive">Inactive</span>')
                : '<span class="ay-badge ay-badge-inactive">No Account</span>';
            const accountAction = t.account_id
                ? `<button class="btn btn-ay btn-ay-info" onclick="resendTeacherCredentials(${t.account_id})" title="Resend credentials" aria-label="Resend credentials"><i class="bi bi-envelope-arrow-up"></i></button>`
                : `<button class="btn btn-ay btn-ay-info" onclick="createTeacherAccount(${t.id})" title="Create account" aria-label="Create account"><i class="bi bi-person-plus"></i></button>`;

            return `
                <tr>
                    <td style="text-align:center;"><span class="row-num">${offset + i + 1}</span></td>
                    <td style="text-align:center;">${esc(t.teacher_id || '-')}</td>
                    <td><div class="teacher-name">${esc(fullName || '-')}</div></td>
                    <td>${esc(t.email || '-')}</td>
                    <td style="text-align:center;">${esc(t.sex || '-')}</td>
                    <td style="text-align:center;">
                        ${t.contact_no ? `<a href="tel:${esc(t.contact_no)}" class="text-decoration-none">${esc(t.contact_no)}</a>` : '-'}
                    </td>
                    <td style="text-align:center;">${esc(t.date_hired || '-')}</td>
                    <td style="text-align:center;">${accountStatus}</td>
                    <td style="text-align:center;">${t.account_id ? esc(formatDate(t.account_created_at)) : '<span class="text-muted">No account</span>'}</td>
                    <td style="text-align:center;">
                        <div class="ay-action-group">
                            <button class="btn btn-ay btn-ay-edit" onclick="editTeacher(${t.id})">
                                <i class="bi bi-pencil-square"></i>
                            </button>
                            ${accountAction}
                            ${toggleBtn}
                        </div>
                    </td>
                </tr>
            `;
        }).join('');

        cardView.innerHTML = list.map((t, i) => {
            const fullName = buildFullName(t);
            const toggleBtn = Number(t.is_active) === 1
                ? `<button class="btn-am btn-am-deactivate w-100" onclick="toggleTeacher(${t.id}, 0)" title="Deactivate (archive)" aria-label="Deactivate"><i class="bi bi-power"></i> Deactivate</button>`
                : `<button class="btn-am btn-am-activate w-100" onclick="toggleTeacher(${t.id}, 1)"><i class="bi bi-play-circle"></i> Activate</button>`;
            const accountAction = t.account_id
                ? `<button class="btn btn-ay btn-ay-info" onclick="resendTeacherCredentials(${t.account_id})" title="Resend credentials" aria-label="Resend credentials"><i class="bi bi-envelope-arrow-up"></i></button>`
                : `<button class="btn btn-ay btn-ay-info" onclick="createTeacherAccount(${t.id})" title="Create account" aria-label="Create account"><i class="bi bi-person-plus"></i></button>`;

            return `
                <div class="ay-mobile-card">
                    <div class="ay-mobile-card-header">
                        <div>
                            <div class="ay-mobile-card-title">${offset + i + 1}. ${esc(fullName || '-')}</div>
                            <div class="ay-mobile-card-subtitle">${esc(t.teacher_id || '-')}</div>
                        </div>
                    </div>
                    <div class="ay-mobile-card-body">
                        <div class="ay-mobile-row">
                            <span class="ay-mobile-label">Email</span>
                            <span>${esc(t.email || '-')}</span>
                        </div>
                        <div class="ay-mobile-row">
                            <span class="ay-mobile-label">Sex</span>
                            <span>${esc(t.sex || '-')}</span>
                        </div>
                        <div class="ay-mobile-row">
                            <span class="ay-mobile-label">Contact</span>
                            <span>${esc(t.contact_no || '-')}</span>
                        </div>
                        <div class="ay-mobile-row">
                            <span class="ay-mobile-label">Date Hired</span>
                            <span>${esc(t.date_hired || '-')}</span>
                        </div>
                        <div class="ay-mobile-row">
                            <span class="ay-mobile-label">Account</span>
                            <span>${t.account_id ? esc(t.account_status || 'Active') : 'No account'}</span>
                        </div>
                    </div>
                    <div class="ay-mobile-actions">
                        <button class="btn btn-ay btn-ay-edit" onclick="editTeacher(${t.id})" title="Edit teacher" aria-label="Edit teacher">
                            <i class="bi bi-pencil-square"></i>
                        </button>
                        ${accountAction}
                        ${toggleBtn}
                    </div>
                </div>
            `;
        }).join('');

        let paginationHtml = '';

        paginationHtml += `
            <li class="ay-page-item ${page <= 1 ? 'disabled' : ''}">
                <a class="ay-page-link" onclick="${page > 1 ? `loadTeachers(${page - 1})` : 'return false;'}">Previous</a>
            </li>
        `;

        for (let n = 1; n <= pages; n++) {
            paginationHtml += `
                <li class="ay-page-item ${n === page ? 'active' : ''}">
                    <a class="ay-page-link" onclick="loadTeachers(${n})">${n}</a>
                </li>
            `;
        }

        paginationHtml += `
            <li class="ay-page-item ${page >= pages ? 'disabled' : ''}">
                <a class="ay-page-link" onclick="${page < pages ? `loadTeachers(${page + 1})` : 'return false;'}">Next</a>
            </li>
        `;

        pagination.innerHTML = paginationHtml;
    }

    function openCreateTeacher() {
        document.getElementById('teacherForm').reset();
        document.getElementById('teacherRecId').value = '';
        document.getElementById('modalTitle').innerHTML = '<i class="bi bi-person-plus me-2"></i>Add Teacher';
        document.getElementById('teacherSubmitButton').innerHTML = '<i class="bi bi-envelope-arrow-up me-1"></i> Save &amp; Send Email';
        document.getElementById('isActive').value = '1';
        document.getElementById('editAccountDetails').style.display = 'none';
        document.getElementById('editAccountDetails').innerHTML = '';
    }

    async function createTeacherAccount(teacherId) {
        showConfirm('create a login account for this teacher', async () => {
            try {
                const res = await fetchJson('api/accounts/create.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ teacher_db_id: teacherId })
                });
                showAlert(res.message || res.error || 'Account creation failed.', res.success ? (res.email_sent ? 'success' : 'warning') : 'danger');
                if (res.success) loadTeachers(currentPage);
            } catch (error) {
                showAlert(error.message, 'danger');
            }
        });
    }

    async function resendTeacherCredentials(accountId) {
        showConfirm('resend the login credentials to this teacher', async () => {
            try {
                const res = await fetchJson('api/accounts/reset_password.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: accountId })
                });
                showAlert(res.message || res.error || 'Credential resend failed.', res.success ? (res.email_sent ? 'success' : 'warning') : 'danger');
                if (res.success) loadTeachers(currentPage);
            } catch (error) {
                showAlert(error.message, 'danger');
            }
        });
    }

    document.getElementById('teacherForm').addEventListener('submit', async function(e) {
        e.preventDefault();

        const payload = {
            id: document.getElementById('teacherRecId').value || undefined,
            teacher_id: document.getElementById('teacherId').value.trim(),
            email: document.getElementById('email').value.trim(),
            fname: document.getElementById('fname').value.trim(),
            mname: document.getElementById('mname').value.trim(),
            lname: document.getElementById('lname').value.trim(),
            date_hired: document.getElementById('dateHired').value,
            sex: document.getElementById('sex').value,
            contact_no: document.getElementById('contactNo').value.trim(),
            is_active: parseInt(document.getElementById('isActive').value, 10)
        };

        try {
            const res = await fetchJson('api/teacher/save.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (res.success) {
                const modalElement = document.getElementById('teacherModal');
                const modalInstance = bootstrap.Modal.getInstance(modalElement);
                if (modalInstance) {
                    modalInstance.hide();
                }

                this.reset();
                showAlert(res.message || 'Teacher saved successfully.', res.warning || res.email_sent === false ? 'warning' : 'success');
                loadTeachers(1);
            } else {
                showAlert(res.error || res.message || 'Save failed.', 'danger');
            }
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    });

    async function editTeacher(id) {
        try {
            const t = await fetchJson(`api/teacher/fetch.php?id=${id}`);
            document.getElementById('teacherRecId').value = t.id || '';
            document.getElementById('teacherId').value = t.teacher_id || '';
            document.getElementById('email').value = t.email || '';
            document.getElementById('fname').value = t.fname || '';
            document.getElementById('mname').value = t.mname || '';
            document.getElementById('lname').value = t.lname || '';
            document.getElementById('dateHired').value = t.date_hired || '';
            document.getElementById('sex').value = t.sex || '';
            document.getElementById('contactNo').value = t.contact_no || '';
            document.getElementById('isActive').value = Number(t.is_active) === 1 ? '1' : '0';
            document.getElementById('modalTitle').innerHTML = '<i class="bi bi-pencil-square me-2"></i>Edit Teacher';
            document.getElementById('teacherSubmitButton').innerHTML = '<i class="bi bi-check-circle me-1"></i> Save';
            const accountDetails = document.getElementById('editAccountDetails');
            accountDetails.style.display = '';
            accountDetails.innerHTML = t.account_id
                ? `<div class="border-top pt-3 mt-1"><div class="fw-semibold mb-2">Account Information</div><div class="row g-2 small"><div class="col-md-3"><strong>Username</strong><br>${esc(t.username || '-')}</div><div class="col-md-3"><strong>Password</strong><br>${Number(t.must_change_password) === 1 ? 'Default' : 'Changed'}</div><div class="col-md-3"><strong>Status</strong><br>${esc(t.account_status || '-')}</div><div class="col-md-3"><strong>Created</strong><br>${esc(formatDate(t.account_created_at))}</div></div></div>`
                : '<div class="border-top pt-3 mt-1 text-muted small">No login account linked to this teacher.</div>';
            new bootstrap.Modal(document.getElementById('teacherModal')).show();
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    function toggleTeacher(id, newState) {
        const action = newState ? 'activate' : 'archive';

        showConfirm(action, async () => {
            try {
                const res = await fetchJson('api/teacher/delete.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        id: id,
                        new_state: newState
                    })
                });

                if (res.success) {
                    showAlert(res.message || `Teacher ${action}d successfully.`, 'success');
                    loadTeachers(currentPage);
                    loadArchive(currentArchivePage);
                } else {
                    showAlert(res.error || res.message || 'Status update failed.', 'danger');
                }
            } catch (error) {
                showAlert(error.message, 'danger');
            }
        });
    }

    async function loadArchive(page = 1) {
        currentArchivePage = page;
        const tableBody = document.getElementById('archiveTableBody');
        const cardView = document.getElementById('archiveCardView');

        if (tableBody) {
            tableBody.innerHTML = `<tr><td colspan="7"><div class="ay-empty"><i class="bi bi-hourglass-split"></i><p>Loading archived teachers...</p></div></td></tr>`;
        }
        if (cardView) cardView.innerHTML = '';

        try {
            const params = new URLSearchParams({
                page,
                role: 'teacher',
                type: 'teacher_record'
            });
            if (archiveSearchTerm.trim()) params.set('search', archiveSearchTerm.trim());

            const data = await fetchJson(`api/archive/read.php?${params.toString()}`);

            if (!data.success) {
                showAlert(data.error || 'Failed to load archive.', 'danger');
                if (tableBody) {
                    tableBody.innerHTML = `<tr><td colspan="7"><div class="ay-empty"><i class="bi bi-exclamation-triangle"></i><p>${esc(data.error || 'Failed to load archive.')}</p></div></td></tr>`;
                }
                return;
            }

            renderArchive(data.accounts || [], data.page || 1, data.pages || 1, data.filtered_count || 0);
        } catch (error) {
            showAlert(error.message, 'danger');
            if (tableBody) {
                tableBody.innerHTML = `<tr><td colspan="7"><div class="ay-empty"><i class="bi bi-exclamation-triangle"></i><p>${esc(error.message)}</p></div></td></tr>`;
            }
        }
    }

    function renderArchive(list, page, pages, totalCount) {
        const tableBody = document.getElementById('archiveTableBody');
        const cardView = document.getElementById('archiveCardView');
        const pagination = document.getElementById('archivePagination');
        const countEl = document.getElementById('archiveCountText');

        updateArchiveCount(totalCount);

        if (!Array.isArray(list) || !list.length) {
            const emptyHtml = `<div class="ay-empty"><i class="bi bi-archive"></i><p>No archived teachers found.</p></div>`;
            tableBody.innerHTML = `<tr><td colspan="7">${emptyHtml}</td></tr>`;
            cardView.innerHTML = emptyHtml;
            pagination.innerHTML = '';
            return;
        }

        const offset = (page - 1) * 10;
        if (countEl) {
            countEl.textContent = `Showing ${offset + 1}-${offset + list.length} of ${totalCount} archived teacher${totalCount === 1 ? '' : 's'}`;
        }

        tableBody.innerHTML = list.map((item, index) => {
            const rowNo = offset + index + 1;
            const teacherId = item.identifier_code || '-';
            const fullName = item.full_name || 'Unnamed teacher';

            return `
                <tr>
                    <td style="text-align:center;"><span class="row-num">${rowNo}</span></td>
                    <td style="text-align:center;">${esc(teacherId)}</td>
                    <td>
                        <div class="archive-name">${esc(fullName)}</div>
                        <div class="archive-subtext">${esc(item.role_label || 'Teacher')}</div>
                    </td>
                    <td>${esc(item.email || '-')}</td>
                    <td style="text-align:center;"><span class="ay-badge ay-badge-inactive"><i class="bi bi-archive"></i> ${esc(item.archive_type_label || 'Teacher Record')}</span></td>
                    <td style="text-align:center;"><span class="archive-date">${esc(formatDate(item.archived_at))}</span></td>
                    <td style="text-align:center;">
                        <div class="archive-actions">
                            <button class="btn btn-ay btn-ay-activate" onclick="restoreArchivedTeacher(${Number(item.id)}, '${esc(item.archive_type)}')">
                                <i class="bi bi-arrow-repeat me-1"></i> Restore
                            </button>
                            <button class="btn btn-ay btn-ay-delete" onclick="deleteArchivedTeacher(${Number(item.id)}, '${esc(item.archive_type)}')">
                                <i class="bi bi-trash3"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');

        cardView.innerHTML = list.map((item, index) => {
            const rowNo = offset + index + 1;
            const teacherId = item.identifier_code || '-';
            const fullName = item.full_name || 'Unnamed teacher';

            return `
                <div class="ay-mobile-card">
                    <div class="ay-mobile-card-header">
                        <div>
                            <div class="ay-mobile-card-title">${rowNo}. ${esc(fullName)}</div>
                            <div class="ay-mobile-card-subtitle">${esc(teacherId)}</div>
                        </div>
                        <span class="ay-badge ay-badge-inactive"><i class="bi bi-archive"></i> Archived</span>
                    </div>
                    <div class="ay-mobile-card-body">
                        <div class="ay-mobile-row">
                            <span class="ay-mobile-label">Email</span>
                            <span>${esc(item.email || '-')}</span>
                        </div>
                        <div class="ay-mobile-row">
                            <span class="ay-mobile-label">Archived</span>
                            <span>${esc(formatDate(item.archived_at))}</span>
                        </div>
                    </div>
                    <div class="ay-mobile-actions">
                        <button class="btn btn-ay btn-ay-activate w-100" onclick="restoreArchivedTeacher(${Number(item.id)}, '${esc(item.archive_type)}')">
                            <i class="bi bi-arrow-repeat me-1"></i> Restore Teacher
                        </button>
                        <button class="btn btn-ay btn-ay-delete w-100" onclick="deleteArchivedTeacher(${Number(item.id)}, '${esc(item.archive_type)}')">
                                <i class="bi bi-trash3"></i>
                        </button>
                    </div>
                </div>
            `;
        }).join('');

        let paginationHtml = `
            <li class="ay-page-item ${page <= 1 ? 'disabled' : ''}">
                <a class="ay-page-link" onclick="${page > 1 ? `loadArchive(${page - 1})` : 'return false;'}">Previous</a>
            </li>
        `;

        for (let n = 1; n <= pages; n++) {
            paginationHtml += `
                <li class="ay-page-item ${n === page ? 'active' : ''}">
                    <a class="ay-page-link" onclick="loadArchive(${n})">${n}</a>
                </li>
            `;
        }

        paginationHtml += `
            <li class="ay-page-item ${page >= pages ? 'disabled' : ''}">
                <a class="ay-page-link" onclick="${page < pages ? `loadArchive(${page + 1})` : 'return false;'}">Next</a>
            </li>
        `;

        pagination.innerHTML = paginationHtml;
    }

    function restoreArchivedTeacher(id, type = 'teacher_record') {
        iziToast.question({
            timeout: 20000,
            close: false,
            overlay: true,
            displayMode: 'once',
            id: 'restore-teacher-confirm',
            zindex: 9999,
            title: 'Confirm Restore',
            message: 'Restore this teacher to the active faculty list?',
            position: 'center',
            color: 'blue',
            icon: 'bi bi-arrow-repeat',
            buttons: [
                ['<button><b>Yes</b></button>', async function(instance, toast) {
                    instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');
                    try {
                        const res = await fetchJson('api/archive/restore.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ id, role: 'teacher', type })
                        });

                        if (res.success) {
                            showAlert(res.message || 'Teacher restored successfully.', 'success');
                            loadArchive(currentArchivePage);
                            loadTeachers(currentPage);
                        } else {
                            showAlert(res.error || res.message || 'Restore failed.', 'danger');
                        }
                    } catch (error) {
                        showAlert(error.message, 'danger');
                    }
                }, true],
                ['<button>No</button>', function(instance, toast) {
                    instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');
                    showAlert('Restore cancelled.', 'info');
                }]
            ]
        });
    }

    function deleteArchivedTeacher(id, type = 'teacher_record') {
        iziToast.question({
            timeout: 25000,
            close: false,
            overlay: true,
            displayMode: 'once',
            id: 'delete-teacher-confirm',
            zindex: 9999,
            title: 'Permanent Delete',
            message: 'This will permanently delete the archived teacher record. This action cannot be undone.',
            position: 'center',
            color: 'red',
            icon: 'bi bi-exclamation-octagon-fill',
            buttons: [
                ['<button><b>Delete</b></button>', async function(instance, toast) {
                    instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');
                    try {
                        const res = await fetchJson('api/archive/delete.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ id, role: 'teacher', type })
                        });

                        if (res.success) {
                            showAlert(res.message || 'Archived teacher permanently deleted.', 'success');
                            loadArchive(currentArchivePage);
                        } else {
                            showAlert(res.error || res.message || 'Delete failed.', 'danger');
                        }
                    } catch (error) {
                        showAlert(error.message, 'danger');
                    }
                }, true],
                ['<button>Cancel</button>', function(instance, toast) {
                    instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');
                    showAlert('Delete cancelled.', 'info');
                }]
            ]
        });
    }

    document.getElementById('searchInput').addEventListener('input', e => {
        clearTimeout(searchTimer);
        searchTimer = setTimeout(() => {
            searchTerm = e.target.value.trim();
            currentPage = 1;
            loadTeachers(1);
        }, 350);
    });

    document.getElementById('archiveSearchInput').addEventListener('input', e => {
        clearTimeout(archiveSearchTimer);
        archiveSearchTimer = setTimeout(() => {
            archiveSearchTerm = e.target.value.trim();
            currentArchivePage = 1;
            loadArchive(1);
        }, 350);
    });

    document.getElementById('clearArchiveFiltersBtn').addEventListener('click', () => {
        document.getElementById('archiveSearchInput').value = '';
        archiveSearchTerm = '';
        currentArchivePage = 1;
        loadArchive(1);
    });

    document.getElementById('teacherModal').addEventListener('hidden.bs.modal', () => {
        document.getElementById('teacherForm').reset();
        document.getElementById('teacherRecId').value = '';
        document.getElementById('modalTitle').innerHTML = '<i class="bi bi-person-plus me-2"></i>Add Teacher';
        document.getElementById('teacherSubmitButton').innerHTML = '<i class="bi bi-envelope-arrow-up me-1"></i> Save &amp; Send Email';
        document.getElementById('editAccountDetails').style.display = 'none';
        document.getElementById('editAccountDetails').innerHTML = '';
    }); -

    openCreateTeacher();
    loadTeachers(1);
</script>
</body>
</html>