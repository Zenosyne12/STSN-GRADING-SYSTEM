<?php
require_once 'includes/auth.php';
requireAdmin();
require_once 'api/shared/db_connect.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Teachers</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        body {
            background: #f3f7fd;
        }
        .ay-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            box-shadow: 0 8px 24px rgba(18, 72, 168, 0.14);
        }
        .ay-page-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 0.2rem;
            letter-spacing: 0.01em;
        }
        .ay-page-header p {
            margin: 0;
            font-size: 0.88rem;
            opacity: 0.88;
        }
        .ay-active-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: rgba(255, 255, 255, 0.14);
            border: 1.5px solid rgba(255, 255, 255, 0.28);
            border-radius: 999px;
            padding: 0.5rem 1rem;
            font-size: 0.88rem;
            font-weight: 700;
            color: #fff;
            white-space: nowrap;
        }
        .ay-active-chip i {
            font-size: 0.95rem;
        }
        .ay-card {
            background: #fff;
            border: 1px solid #dce8f8;
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18, 72, 168, 0.06);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }
        .ay-card-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid #e8f0fb;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
            background: #fff;
        }
        .ay-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: #132f62;
            margin: 0 0 0.15rem;
        }
        .ay-card-subtitle {
            font-size: 0.8rem;
            color: #7a93b8;
            margin: 0;
        }
        .ay-toolbar {
            display: flex;
            gap: 0.6rem;
            flex-wrap: wrap;
            align-items: center;
        }
        .ay-search-wrap {
            position: relative;
            min-width: 260px;
        }
        .ay-search-wrap i {
            position: absolute;
            left: 0.95rem;
            top: 50%;
            transform: translateY(-50%);
            color: #7a93b8;
            font-size: 0.9rem;
            pointer-events: none;
        }
        .ay-search {
            width: 100%;
            border-radius: 10px;
            border: 1.5px solid #c8daf8;
            min-height: 42px;
            font-size: 0.9rem;
            color: #213a5e;
            padding: 0.45rem 0.85rem 0.45rem 2.45rem;
            background: #fff;
        }
        .ay-search:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.12);
            outline: none;
        }
        .ay-card-body {
            padding: 0;
        }
        .ay-card-footer {
            padding: 0.75rem 1.2rem;
            border-top: 1px solid #e8f0fb;
            background: #fafcff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 0.75rem;
            flex-wrap: wrap;
        }
        .ay-footer-note {
            font-size: 0.82rem;
            color: #7a93b8;
        }
        .ay-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
        }
        .ay-table thead th {
            background: #f4f8ff;
            color: #3b5e96;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 0.85rem 1.2rem;
            border-bottom: 1.5px solid #dce8f8;
            white-space: nowrap;
            text-align: center;
        }
        .ay-table tbody tr {
            transition: background 0.12s;
        }
        .ay-table tbody tr:not(:last-child) td {
            border-bottom: 1px solid #f0f5fc;
        }
        .ay-table tbody tr:hover td {
            background: #f7fbff;
        }
        .ay-table tbody td {
            padding: 0.95rem 1.2rem;
            font-size: 0.93rem;
            color: #213a5e;
            vertical-align: middle;
        }
        .ay-table tbody td .row-num {
            color: #a0b4cc;
            font-size: 0.82rem;
            font-weight: 600;
        }
        .teacher-name {
            font-weight: 700;
            color: #132f62;
            line-height: 1.25;
        }
        .ay-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.34rem 0.78rem;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }
        .ay-badge-active {
            background: #e6f6ec;
            color: #1c8b4d;
            border: 1.5px solid #b8e2c8;
        }
        .ay-badge-inactive {
            background: #f3f5f8;
            color: #7a8ea8;
            border: 1.5px solid #dde4ee;
        }
        .btn-ay {
            font-weight: 600;
            font-size: 0.82rem;
            border-radius: 8px;
            padding: 0.44rem 0.9rem;
            cursor: pointer;
            transition: background 0.15s, border-color 0.15s, color 0.15s, box-shadow 0.15s, transform 0.15s;
            border: 1.5px solid transparent;
            line-height: 1.4;
        }
        .btn-ay:hover {
            transform: translateY(-1px);
        }
        .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            border-color: transparent;
            box-shadow: 0 2px 8px rgba(26, 110, 245, 0.2);
        }
        .btn-ay-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
            box-shadow: 0 3px 12px rgba(26, 110, 245, 0.3);
        }
        .btn-ay-edit {
            background: #fff7e8;
            color: #9a6200;
            border-color: #f6d28b;
        }
        .btn-ay-edit:hover {
            background: #ffefc7;
            border-color: #efc361;
            color: #845100;
        }
        .btn-ay-activate {
            background: #1a6ef5;
            color: #fff;
            border-color: #1a6ef5;
        }
        .btn-ay-activate:hover {
            background: #1560d8;
            border-color: #1560d8;
            color: #fff;
        }
        .btn-ay-deactivate {
            background: #fff;
            color: #1248a8;
            border-color: #b8d0fa;
        }
        .btn-ay-deactivate:hover {
            background: #eef4ff;
            border-color: #8db5f7;
            color: #0f3d90;
        }
        .ay-action-group {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 0.5rem;
        }
        .ay-pagination {
            display: flex;
            gap: 0.3rem;
            list-style: none;
            margin: 0;
            padding: 0;
            justify-content: flex-end;
            align-items: center;
            flex-wrap: wrap;
        }
        .ay-pagination .ay-page-item .ay-page-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
            border-radius: 7px;
            font-size: 0.83rem;
            font-weight: 600;
            cursor: pointer;
            border: 1.5px solid #dce8f8;
            color: #1a6ef5;
            background: #fff;
            transition: all 0.13s;
            padding: 0 0.65rem;
            text-decoration: none;
        }
        .ay-pagination .ay-page-item .ay-page-link:hover {
            background: #eef4ff;
            border-color: #9cc2fc;
        }
        .ay-pagination .ay-page-item.active .ay-page-link {
            background: #1a6ef5;
            border-color: #1a6ef5;
            color: #fff;
        }
        .ay-pagination .ay-page-item.disabled .ay-page-link {
            background: #f8fbff;
            border-color: #e2ebf8;
            color: #9ab0c8;
            cursor: not-allowed;
            pointer-events: none;
        }
        .ay-empty {
            text-align: center;
            padding: 2.8rem 1.5rem;
            color: #9ab0c8;
        }
        .ay-empty i {
            font-size: 2.35rem;
            display: block;
            margin-bottom: 0.7rem;
            opacity: 0.55;
        }
        .ay-empty p {
            margin: 0;
            font-size: 0.95rem;
        }
        .ay-modal .modal-content {
            border: 0;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(18, 72, 168, 0.16);
        }
        .ay-modal .modal-header {
            background: #f4f8ff;
            border-bottom: 1px solid #dce8f8;
            border-radius: 16px 16px 0 0;
            padding: 1rem 1.3rem;
        }
        .ay-modal .modal-title {
            font-size: 1rem;
            font-weight: 700;
            color: #132f62;
        }
        .ay-modal .modal-body {
            padding: 1.3rem;
        }
        .ay-modal .modal-footer {
            border-top: 1px solid #e8f0fb;
            padding: 0.9rem 1.3rem;
            background: #fafcff;
            border-radius: 0 0 16px 16px;
        }
        .ay-modal .form-label {
            font-size: 0.85rem;
            font-weight: 700;
            color: #3b5e96;
            margin-bottom: 0.4rem;
        }
        .ay-modal .form-control,
        .ay-modal .form-select {
            border-radius: 10px;
            border: 1.5px solid #c8daf8;
            min-height: 42px;
            font-size: 0.9rem;
            color: #213a5e;
            padding: 0.45rem 0.85rem;
        }
        .ay-modal .form-control:focus,
        .ay-modal .form-select:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.12);
        }
        .ay-modal .form-text {
            font-size: 0.8rem;
            color: #8fa8c8;
            margin-top: 0.45rem;
        }
        .ay-mobile-card {
            background: #fff;
            border: 1.5px solid #dce8f8;
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 1px 6px rgba(18, 72, 168, 0.05);
        }
        .ay-mobile-card + .ay-mobile-card {
            margin-top: 0.75rem;
        }
        .ay-mobile-card-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            padding: 0.95rem 1rem;
            border-bottom: 1px solid #edf3fc;
            background: #f9fbff;
            gap: 0.75rem;
        }
        .ay-mobile-card-title {
            font-weight: 700;
            color: #132f62;
            font-size: 0.96rem;
            line-height: 1.25;
        }
        .ay-mobile-card-subtitle {
            font-size: 0.82rem;
            color: #7a93b8;
            margin-top: 0.16rem;
        }
        .ay-mobile-card-body {
            padding: 0.9rem 1rem 0.35rem;
        }
        .ay-mobile-row {
            display: flex;
            justify-content: space-between;
            gap: 0.75rem;
            padding: 0.3rem 0;
            font-size: 0.9rem;
        }
        .ay-mobile-label {
            color: #7a93b8;
            font-weight: 600;
        }
        .ay-mobile-actions {
            display: grid;
            gap: 0.5rem;
            padding: 0.8rem 1rem 1rem;
        }
        @media (max-width: 767.98px) {
            .ay-page-header {
                padding: 1.1rem 1.2rem;
                border-radius: 14px;
            }
            .ay-search-wrap {
                min-width: 100%;
            }
            .ay-card-footer {
                justify-content: center;
            }
            .ay-pagination {
                justify-content: center;
            }
        }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>

    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3">
                <div class="ay-page-header">
                    <div>
                        <h3><i class="bi bi-person-badge-fill me-2"></i>Teacher Management</h3>
                        <p>Manage, add, and update teacher records</p>
                    </div>
                    <div class="ay-active-chip">
                        <i class="bi bi-people-fill"></i> Faculty Directory
                    </div>
                </div>

                <div class="ay-card">
                    <div class="ay-card-header">
                        <div>
                            <p class="ay-card-title">Teacher List</p>
                            <p class="ay-card-subtitle">Add, edit, search, and manage teacher accounts.</p>
                        </div>
                        <div class="ay-toolbar">
                            <div class="ay-search-wrap">
                                <i class="bi bi-search"></i>
                                <input type="search" class="ay-search" id="searchInput" placeholder="Search teacher name, ID, or email...">
                            </div>
                            <button type="button" class="btn btn-ay btn-ay-primary" onclick="openCreateTeacher()" data-bs-toggle="modal" data-bs-target="#teacherModal">
                                <i class="bi bi-plus-circle me-1"></i> New Teacher
                            </button>
                        </div>
                    </div>

                    <div class="ay-card-body">
                        <div class="d-none d-md-block">
                            <table class="ay-table" id="teacherTable">
                                <thead>
                                    <tr>
                                        <th style="width:64px;">#</th>
                                        <th>Teacher ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Sex</th>
                                        <th>Contact</th>
                                        <th>Date Hired</th>
                                        <th style="width:130px;">Status</th>
                                        <th style="width:230px;">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="teacherTableBody">
                                    <tr>
                                        <td colspan="9">
                                            <div class="ay-empty">
                                                <i class="bi bi-hourglass-split"></i>
                                                <p>Loading teachers...</p>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="d-block d-md-none p-3" id="teacherCardView"></div>
                    </div>

                    <div class="ay-card-footer">
                        <div class="ay-footer-note" id="teacherCountText"></div>
                        <ul class="ay-pagination" id="pagination"></ul>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php require_once("includes/footer.php"); ?>
</div>

<div class="modal fade ay-modal" id="teacherModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="false">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <form id="teacherForm">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle"><i class="bi bi-person-plus me-2"></i>Add Teacher</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="teacherRecId">
                    <input type="hidden" id="isActive" value="1">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Teacher ID <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="teacherId" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="email" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">First Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="fname" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Middle Name</label>
                            <input type="text" class="form-control" id="mname">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Last Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="lname" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Date Hired <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="dateHired" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Sex <span class="text-danger">*</span></label>
                            <select class="form-select" id="sex" required>
                                <option value="">— Select sex —</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Contact No <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="contactNo" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-ay" style="border:1.5px solid #dce8f8; background:#fff; color:#5a7299;" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle me-1"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-ay btn-ay-primary">
                        <i class="bi bi-check-circle me-1"></i> Save Teacher
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="./js/sweet-alerts.js"></script>
<script>
    let currentPage = 1;
    let searchTerm = '';
    let totalTeachers = 0;
    const rowsPerPage = 5;
    let searchTimer = null;

    function esc(str) {
        return (str ?? '').toString()
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');
    }

    function showAlert(message, type = 'success') {
        const config = {
            success: { title: 'Success', color: 'blue', icon: 'bi bi-check-circle-fill' },
            danger: { title: 'Error', color: 'red', icon: 'bi bi-exclamation-octagon-fill' },
            warning: { title: 'Warning', color: 'yellow', icon: 'bi bi-exclamation-triangle-fill' },
            info: { title: 'Info', color: 'blue', icon: 'bi bi-info-circle-fill' }
        };
        const selected = config[type] || config.success;
        iziToast.show({
            title: selected.title,
            message: message,
            color: selected.color,
            icon: selected.icon,
            iconColor: '#fff',
            theme: 'light',
            position: 'topRight',
            timeout: 4000,
            progressBar: true,
            close: true,
            pauseOnHover: true,
            drag: true,
            transitionIn: 'fadeInDown',
            transitionOut: 'fadeOutUp',
            maxWidth: 420
        });
    }

    function showConfirm(action, onYes) {
        iziToast.question({
            timeout: 20000,
            close: false,
            overlay: true,
            displayMode: 'once',
            id: 'teacher-confirm',
            zindex: 9999,
            title: 'Confirm Action',
            message: `Are you sure you want to ${action} this teacher?`,
            position: 'center',
            color: 'blue',
            icon: 'bi bi-question-circle-fill',
            buttons: [
                [
                    '<button><b>Yes</b></button>',
                    async function(instance, toast) {
                        instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');
                        await onYes();
                    },
                    true
                ],
                [
                    '<button>No</button>',
                    function(instance, toast) {
                        instance.hide({ transitionOut: 'fadeOut' }, toast, 'button');
                        showAlert(`Teacher ${action} cancelled.`, 'info');
                    }
                ]
            ]
        });
    }

    async function fetchJson(url, options = {}) {
        const response = await fetch(url, options);
        const raw = await response.text();

        try {
            return JSON.parse(raw);
        } catch (e) {
            console.error('Non-JSON response:', raw);
            throw new Error('Server returned an invalid response.');
        }
    }

    function buildFullName(t) {
        return [t.fname, t.mname, t.lname]
            .filter(part => part && String(part).trim() !== '')
            .join(' ')
            .replace(/\s+/g, ' ')
            .trim();
    }

    function updateTeacherCount(page, listLength) {
        const countEl = document.getElementById('teacherCountText');

        if (!countEl) return;

        if (totalTeachers === 0) {
            countEl.textContent = 'No teachers to display.';
            return;
        }

        const start = ((page - 1) * rowsPerPage) + 1;
        const end = start + listLength - 1;

        countEl.textContent = `Showing ${start}-${end} of ${totalTeachers} teachers`;
    }

    async function loadTeachers(page = 1) {
        currentPage = page;
        try {
            const data = await fetchJson(`api/teacher/read.php?p=${page}&s=${encodeURIComponent(searchTerm)}`);
            totalTeachers = Number(data.total || 0);
            render(data.teachers || [], data.page || 1, data.pages || 1);
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    function render(list, page, pages) {
        const tableBody = document.getElementById('teacherTableBody');
        const cardView = document.getElementById('teacherCardView');
        const pagination = document.getElementById('pagination');

        updateTeacherCount(page, list.length);

        if (!list.length) {
            const emptyText = searchTerm.trim() ? 'No teachers matched your search.' : 'No teachers found.';
            const emptyHtml = `
                <div class="ay-empty">
                    <i class="bi bi-person-x"></i>
                    <p>${emptyText}</p>
                </div>
            `;
            tableBody.innerHTML = `<tr><td colspan="9">${emptyHtml}</td></tr>`;
            cardView.innerHTML = emptyHtml;
            pagination.innerHTML = '';
            return;
        }

        const offset = (page - 1) * rowsPerPage;

        tableBody.innerHTML = list.map((t, i) => {
            const isActive = Number(t.is_active) === 1;
            const fullName = buildFullName(t);
            const badge = isActive
                ? `<span class="ay-badge ay-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                : `<span class="ay-badge ay-badge-inactive"><i class="bi bi-dash-circle"></i> Inactive</span>`;
            const toggleBtn = isActive
                ? `<button class="btn btn-ay btn-ay-deactivate" onclick="toggleTeacher(${t.id}, 0)"><i class="bi bi-pause-circle me-1"></i> Deactivate</button>`
                : `<button class="btn btn-ay btn-ay-activate" onclick="toggleTeacher(${t.id}, 1)"><i class="bi bi-check-circle me-1"></i> Activate</button>`;

            return `
                <tr>
                    <td style="text-align:center;"><span class="row-num">${offset + i + 1}</span></td>
                    <td style="text-align:center;">${esc(t.teacher_id || '-')}</td>
                    <td><div class="teacher-name">${esc(fullName || '-')}</div></td>
                    <td>${esc(t.email || '-')}</td>
                    <td style="text-align:center;">${esc(t.sex || '-')}</td>
                    <td style="text-align:center;">
                        ${t.contact_no ? `<a href="tel:${esc(t.contact_no)}" class="text-decoration-none">${esc(t.contact_no)}</a>` : '-'}
                    </td>
                    <td style="text-align:center;">${esc(t.date_hired || '-')}</td>
                    <td style="text-align:center;">${badge}</td>
                    <td style="text-align:center;">
                        <div class="ay-action-group">
                            <button class="btn btn-ay btn-ay-edit" onclick="editTeacher(${t.id})">
                                <i class="bi bi-pencil-square me-1"></i> Edit
                            </button>
                            ${toggleBtn}
                        </div>
                    </td>
                </tr>
            `;
        }).join('');

        cardView.innerHTML = list.map((t, i) => {
            const isActive = Number(t.is_active) === 1;
            const fullName = buildFullName(t);
            const badge = isActive
                ? `<span class="ay-badge ay-badge-active"><i class="bi bi-check-circle-fill"></i> Active</span>`
                : `<span class="ay-badge ay-badge-inactive"><i class="bi bi-dash-circle"></i> Inactive</span>`;
            const toggleBtn = isActive
                ? `<button class="btn btn-ay btn-ay-deactivate w-100" onclick="toggleTeacher(${t.id}, 0)"><i class="bi bi-pause-circle me-1"></i> Deactivate</button>`
                : `<button class="btn btn-ay btn-ay-activate w-100" onclick="toggleTeacher(${t.id}, 1)"><i class="bi bi-check-circle me-1"></i> Activate</button>`;

            return `
                <div class="ay-mobile-card">
                    <div class="ay-mobile-card-header">
                        <div>
                            <div class="ay-mobile-card-title">${offset + i + 1}. ${esc(fullName || '-')}</div>
                            <div class="ay-mobile-card-subtitle">${esc(t.teacher_id || '-')}</div>
                        </div>
                        ${badge}
                    </div>
                    <div class="ay-mobile-card-body">
                        <div class="ay-mobile-row">
                            <span class="ay-mobile-label">Email</span>
                            <span>${esc(t.email || '-')}</span>
                        </div>
                        <div class="ay-mobile-row">
                            <span class="ay-mobile-label">Sex</span>
                            <span>${esc(t.sex || '-')}</span>
                        </div>
                        <div class="ay-mobile-row">
                            <span class="ay-mobile-label">Contact</span>
                            <span>${esc(t.contact_no || '-')}</span>
                        </div>
                        <div class="ay-mobile-row">
                            <span class="ay-mobile-label">Date Hired</span>
                            <span>${esc(t.date_hired || '-')}</span>
                        </div>
                    </div>
                    <div class="ay-mobile-actions">
                        <button class="btn btn-ay btn-ay-edit w-100" onclick="editTeacher(${t.id})">
                            <i class="bi bi-pencil-square me-1"></i> Edit
                        </button>
                        ${toggleBtn}
                    </div>
                </div>
            `;
        }).join('');

        let paginationHtml = '';

        paginationHtml += `
            <li class="ay-page-item ${page <= 1 ? 'disabled' : ''}">
                <a class="ay-page-link" onclick="${page > 1 ? `loadTeachers(${page - 1})` : 'return false;'}">Previous</a>
            </li>
        `;

        for (let n = 1; n <= pages; n++) {
            paginationHtml += `
                <li class="ay-page-item ${n === page ? 'active' : ''}">
                    <a class="ay-page-link" onclick="loadTeachers(${n})">${n}</a>
                </li>
            `;
        }

        paginationHtml += `
            <li class="ay-page-item ${page >= pages ? 'disabled' : ''}">
                <a class="ay-page-link" onclick="${page < pages ? `loadTeachers(${page + 1})` : 'return false;'}">Next</a>
            </li>
        `;

        pagination.innerHTML = paginationHtml;
    }

    function openCreateTeacher() {
        document.getElementById('teacherForm').reset();
        document.getElementById('teacherRecId').value = '';
        document.getElementById('modalTitle').innerHTML = '<i class="bi bi-person-plus me-2"></i>Add Teacher';
        document.getElementById('isActive').value = '1';
    }

    document.getElementById('teacherForm').addEventListener('submit', async function(e) {
        e.preventDefault();

        const payload = {
            id: document.getElementById('teacherRecId').value || undefined,
            teacher_id: document.getElementById('teacherId').value.trim(),
            email: document.getElementById('email').value.trim(),
            fname: document.getElementById('fname').value.trim(),
            mname: document.getElementById('mname').value.trim(),
            lname: document.getElementById('lname').value.trim(),
            date_hired: document.getElementById('dateHired').value,
            sex: document.getElementById('sex').value,
            contact_no: document.getElementById('contactNo').value.trim(),
            is_active: parseInt(document.getElementById('isActive').value, 10)
        };

        try {
            const res = await fetchJson('api/teacher/save.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (res.success) {
                const modalElement = document.getElementById('teacherModal');
                const modalInstance = bootstrap.Modal.getInstance(modalElement);
                if (modalInstance) {
                    modalInstance.hide();
                }

                this.reset();
                showAlert(res.message || 'Teacher saved successfully.', 'success');
                loadTeachers(1);
            } else {
                showAlert(res.error || res.message || 'Save failed.', 'danger');
            }
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    });

    async function editTeacher(id) {
        try {
            const t = await fetchJson(`api/teacher/fetch.php?id=${id}`);
            document.getElementById('teacherRecId').value = t.id || '';
            document.getElementById('teacherId').value = t.teacher_id || '';
            document.getElementById('email').value = t.email || '';
            document.getElementById('fname').value = t.fname || '';
            document.getElementById('mname').value = t.mname || '';
            document.getElementById('lname').value = t.lname || '';
            document.getElementById('dateHired').value = t.date_hired || '';
            document.getElementById('sex').value = t.sex || '';
            document.getElementById('contactNo').value = t.contact_no || '';
            document.getElementById('isActive').value = Number(t.is_active) === 1 ? '1' : '0';
            document.getElementById('modalTitle').innerHTML = '<i class="bi bi-pencil-square me-2"></i>Edit Teacher';
            new bootstrap.Modal(document.getElementById('teacherModal')).show();
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    function toggleTeacher(id, newState) {
        const action = newState ? 'activate' : 'deactivate';

        showConfirm(action, async () => {
            try {
                const res = await fetchJson('api/teacher/delete.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        id: id,
                        new_state: newState
                    })
                });

                if (res.success) {
                    showAlert(res.message || `Teacher ${action}d successfully.`, 'success');
                    loadTeachers(currentPage);
                } else {
                    showAlert(res.error || res.message || 'Status update failed.', 'danger');
                }
            } catch (error) {
                showAlert(error.message, 'danger');
            }
        });
    }

    document.getElementById('searchInput').addEventListener('input', e => {
        clearTimeout(searchTimer);
        searchTimer = setTimeout(() => {
            searchTerm = e.target.value.trim();
            currentPage = 1;
            loadTeachers(1);
        }, 350);
    });

    document.getElementById('teacherModal').addEventListener('hidden.bs.modal', () => {
        document.getElementById('teacherForm').reset();
        document.getElementById('teacherRecId').value = '';
        document.getElementById('modalTitle').innerHTML = '<i class="bi bi-person-plus me-2"></i>Add Teacher';
    });

    openCreateTeacher();
    loadTeachers(1);
</script>
</body>
</html>
