<?php
session_start();
require_once __DIR__ . '/api/shared/CSRFToken.php';

// Check if code was verified
if (!isset($_SESSION['code_verified']) || !isset($_SESSION['reset_user_id'])) {
    header("Location: forgot_password.php");
    exit;
}

$csrfToken = CSRFToken::generate();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - STSN Grading System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="css/login.css">

    <style>
        :root {
            --maroon: #9e112d;
            --maroon-dark: #7d0d24;
            --success: #198754;
            --danger: #dc3545;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f7f6; /* fallback – login.css provides the background */
        }

        /* Smooth fade-in */
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(24px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .reset-card {
            animation: fadeInUp 0.45s ease both;
        }

        .main-wrapper {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }
        .reset-card {
            width: 100%;
            max-width: 450px;
            background: rgba(255, 255, 255, 0.97);
            border-radius: 22px;
            padding: 40px;
            box-shadow: 0 22px 50px rgba(0,0,0,0.18);
            border: 1px solid rgba(255,255,255,0.5);
        }
        .brand {
            text-align: center;
            margin-bottom: 28px;
        }
        .brand-logo {
            width: 68px; height: 68px; margin: 0 auto 12px;
            border-radius: 15px; background: linear-gradient(145deg, #fff, #f7efef);
            border: 1px solid #e6d9dc; display: flex; align-items: center; justify-content: center;
            box-shadow: 0 8px 18px rgba(158,17,45,0.07);
        }
        .brand-logo img { width: 44px; height: 44px; object-fit: contain; }
        .brand h1 { margin: 0; font-size: 1.8rem; font-weight: 700; color: var(--maroon); }
        .brand p { margin: 6px 0 0; font-size: 0.88rem; color: #777; }

        /* Inline alert (simple box inside the card) */
        .inline-alert {
            display: flex; align-items: center; gap: 10px;
            background: #fef2f2; color: #b91c1c; border: 1px solid #fecaca;
            border-radius: 12px; padding: 12px 14px; margin-bottom: 18px;
            font-size: 0.85rem; font-weight: 500;
        }
        .inline-alert.success {
            background: #f0fdf4; color: #166534; border-color: #bbf7d0;
        }
        .inline-alert i { font-size: 1.1rem; flex-shrink: 0; }

        .hint-box {
            background: #fff8eb; border: 1px solid #f1dfb6; color: #7a5d23;
            border-radius: 12px; padding: 12px; margin-bottom: 18px;
            font-size: 0.83rem; display: flex; align-items: center; gap: 8px;
        }

        .form-group { margin-bottom: 16px; }
        .form-label { display: block; margin-bottom: 6px; font-size: 0.88rem; font-weight: 600; color: #333; }
        .input-wrap { position: relative; }
        .form-control {
            width: 100%; height: 46px; border: 1.5px solid #e6d9dc; border-radius: 11px;
            background: rgba(255,255,255,0.93); padding: 0 48px 0 14px;
            font-size: 0.93rem; color: #2b2b2b; transition: 0.15s ease;
        }
        .form-control:focus {
            border-color: rgba(158,17,45,0.45); box-shadow: 0 0 0 3px rgba(158,17,45,0.06);
            background: #fff; outline: none;
        }
        .toggle-pwd {
            position: absolute; top: 50%; right: 12px; transform: translateY(-50%);
            background: none; border: none; color: #988b8d; cursor: pointer; padding: 0; font-size: 1rem;
        }

        .strength-box {
            background: #fafafa; border: 1px solid #eaeaea; border-radius: 11px;
            padding: 12px; margin-top: 10px; display: none;
        }
        .strength-box.show { display: block; }
        .strength-title { font-size: 0.78rem; font-weight: 700; color: #333; margin-bottom: 8px; }
        .strength-meter { width: 100%; height: 6px; background: #e5e5e5; border-radius: 3px; overflow: hidden; margin-bottom: 6px; }
        .strength-bar { height: 100%; width: 0; transition: width 0.3s, background 0.3s; }
        .strength-bar.weak { background: var(--danger); width: 33%; }
        .strength-bar.fair { background: #f59e0b; width: 66%; }
        .strength-bar.strong { background: var(--success); width: 100%; }
        .strength-label { font-size: 0.75rem; font-weight: 600; }
        .strength-label.weak { color: var(--danger); }
        .strength-label.fair { color: #f59e0b; }
        .strength-label.strong { color: var(--success); }

        .requirements { font-size: 0.73rem; margin-top: 8px; }
        .requirement { display: flex; align-items: center; gap: 6px; margin: 4px 0; color: #999; }
        .requirement.met { color: var(--success); }
        .requirement.unmet { color: var(--danger); }

        .match-text { min-height: 18px; font-size: 0.8rem; font-weight: 600; margin-top: 5px; text-align: right; }
        .match-ok { color: var(--success); }
        .match-bad { color: var(--danger); }

        .btn-primary {
            width: 100%; height: 46px; border: none; border-radius: 11px; color: #fff;
            font-weight: 700; font-size: 0.95rem; cursor: pointer;
            background: linear-gradient(135deg, var(--maroon), var(--maroon-dark));
            box-shadow: 0 8px 20px rgba(158,17,45,0.18);
            transition: 0.15s ease; display: inline-flex; align-items: center; justify-content: center; gap: 0.4rem;
        }
        .btn-primary:hover:not(:disabled) {
            transform: translateY(-1px); box-shadow: 0 10px 24px rgba(158,17,45,0.25);
        }
        .btn-primary:disabled { opacity: 0.55; cursor: not-allowed; box-shadow: none; transform: none; }

        .back-link {
            display: block; text-align: center; margin-top: 22px;
            color: var(--maroon); text-decoration: none; font-weight: 600; font-size: 0.88rem;
        }
        .back-link:hover { text-decoration: underline; }

        @media (max-width: 480px) {
            .reset-card { padding: 28px 18px; }
            .brand h1 { font-size: 1.6rem; }
        }
    </style>
</head>
<body class="login-page">
<div class="main-wrapper">
    <div class="reset-card">
        <div class="brand">
            <div class="brand-logo"><img src="assets/img/stsn logo.png" alt="STSN Logo"></div>
            <h1>Reset Password</h1>
            <p>Create a strong new password</p>
        </div>

        <!-- Inline alert container (hidden by default) -->
        <div id="alertBox" class="inline-alert" style="display: none;">
            <i class="bi" id="alertIcon"></i>
            <span id="alertMessage"></span>
        </div>

        <div class="hint-box">
            <i class="bi bi-shield-check"></i>
            <span>8+ characters, uppercase, lowercase, number, special character. No sequential patterns like "abc" or "123".</span>
        </div>

        <form id="resetForm" novalidate>
            <input type="hidden" name="_csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">

            <div class="form-group">
                <label class="form-label" for="new_password">
                    <i class="bi bi-lock-fill"></i> New Password
                </label>
                <div class="input-wrap">
                    <input type="password" class="form-control" id="new_password"
                           placeholder="Enter new password" required minlength="8" maxlength="128" autofocus>
                    <button type="button" class="toggle-pwd" data-target="new_password"><i class="bi bi-eye"></i></button>
                </div>

                <!-- Strength meter -->
                <div class="strength-box" id="strengthBox">
                    <div class="strength-title">Password Strength</div>
                    <div class="strength-meter"><div class="strength-bar" id="strengthBar"></div></div>
                    <div class="strength-label" id="strengthLabel"></div>
                    <div class="requirements">
                        <div class="requirement" id="req-length"><i class="bi bi-circle-fill"></i> At least 8 characters</div>
                        <div class="requirement" id="req-upper"><i class="bi bi-circle-fill"></i> One uppercase letter</div>
                        <div class="requirement" id="req-lower"><i class="bi bi-circle-fill"></i> One lowercase letter</div>
                        <div class="requirement" id="req-number"><i class="bi bi-circle-fill"></i> One number</div>
                        <div class="requirement" id="req-special"><i class="bi bi-circle-fill"></i> One special character</div>
                        <div class="requirement" id="req-noseq"><i class="bi bi-circle-fill"></i> No sequential pattern</div>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="confirm_password">
                    <i class="bi bi-shield-check"></i> Confirm Password
                </label>
                <div class="input-wrap">
                    <input type="password" class="form-control" id="confirm_password"
                           placeholder="Confirm new password" required minlength="8" maxlength="128">
                    <button type="button" class="toggle-pwd" data-target="confirm_password"><i class="bi bi-eye"></i></button>
                </div>
                <div id="matchText" class="match-text"></div>
            </div>

            <button type="submit" class="btn-primary" id="submitBtn" disabled>
                <i class="bi bi-arrow-repeat"></i> RESET PASSWORD
            </button>
        </form>

        <a href="login.php" class="back-link"><i class="bi bi-arrow-left"></i> Back to Login</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const newPwd = document.getElementById('new_password');
    const confirmPwd = document.getElementById('confirm_password');
    const matchText = document.getElementById('matchText');
    const submitBtn = document.getElementById('submitBtn');
    const form = document.getElementById('resetForm');
    const strengthBox = document.getElementById('strengthBox');
    const alertBox = document.getElementById('alertBox');
    const alertIcon = document.getElementById('alertIcon');
    const alertMsg = document.getElementById('alertMessage');

    // Inline alert helper
    function showInlineAlert(message, type = 'error') {
        alertBox.style.display = 'flex';
        alertBox.className = 'inline-alert' + (type === 'success' ? ' success' : '');
        alertIcon.className = 'bi ' + (type === 'success' ? 'bi-check-circle-fill' : 'bi-exclamation-triangle-fill');
        alertMsg.textContent = message;
    }
    function hideInlineAlert() {
        alertBox.style.display = 'none';
    }

    // Requirements (frontend version to enable submit enabling, plus sequential check)
    const requirements = {
        length: { elem: document.getElementById('req-length'), regex: /.{8,}/, met: false },
        upper: { elem: document.getElementById('req-upper'), regex: /[A-Z]/, met: false },
        lower: { elem: document.getElementById('req-lower'), regex: /[a-z]/, met: false },
        number: { elem: document.getElementById('req-number'), regex: /[0-9]/, met: false },
        special: { elem: document.getElementById('req-special'), regex: /[!@#$%^&*()_\-+=\[\]{};:\'",.<>?\/\\|`~]/, met: false },
        noseq: { elem: document.getElementById('req-noseq'), met: true } // will be checked manually
    };

    function checkSequential(password) {
        // Check for ascending/descending sequences of 3+ characters (letters or digits, case‑insensitive)
        const seq = 'abcdefghijklmnopqrstuvwxyz0123456789';
        const p = password.toLowerCase();
        for (let i = 0; i < p.length - 2; i++) {
            const sub = p.substring(i, i + 3);
            if (seq.includes(sub) || seq.includes(sub.split('').reverse().join(''))) {
                return false;
            }
        }
        return true;
    }

    function updateStrength(password) {
        const bar = document.getElementById('strengthBar');
        const label = document.getElementById('strengthLabel');
        if (!password) {
            strengthBox.classList.remove('show');
            return;
        }
        strengthBox.classList.add('show');
        let metCount = 0;
        for (const [key, req] of Object.entries(requirements)) {
            if (key === 'noseq') {
                req.met = checkSequential(password);
            } else {
                req.met = req.regex.test(password);
            }
            metCount += req.met ? 1 : 0;
            req.elem.classList.remove('met', 'unmet');
            req.elem.classList.add(req.met ? 'met' : (password.length > 0 ? 'unmet' : ''));
        }
        bar.className = 'strength-bar';
        label.className = 'strength-label';
        if (metCount < 3) {
            bar.classList.add('weak');
            label.classList.add('weak');
            label.textContent = 'Weak';
        } else if (metCount < 6) {
            bar.classList.add('fair');
            label.classList.add('fair');
            label.textContent = 'Fair';
        } else {
            bar.classList.add('strong');
            label.classList.add('strong');
            label.textContent = 'Strong';
        }
    }

    function updateMatch() {
        const a = newPwd.value, b = confirmPwd.value;
        matchText.textContent = ''; matchText.className = 'match-text';
        if (!a || !b) return;
        if (a === b) { matchText.textContent = '✓ Passwords match'; matchText.classList.add('match-ok'); }
        else { matchText.textContent = '✗ Passwords do not match'; matchText.classList.add('match-bad'); }
    }

    function updateSubmit() {
        const allMet = Object.values(requirements).every(r => r.met);
        const pwdMatch = newPwd.value === confirmPwd.value;
        submitBtn.disabled = !(allMet && pwdMatch && newPwd.value.length > 0);
    }

    newPwd.addEventListener('input', () => {
        updateStrength(newPwd.value);
        updateMatch();
        updateSubmit();
    });
    confirmPwd.addEventListener('input', () => {
        updateMatch();
        updateSubmit();
    });

    // Toggle password visibility
    document.querySelectorAll('.toggle-pwd').forEach(btn => {
        btn.addEventListener('click', () => {
            const target = document.getElementById(btn.dataset.target);
            const icon = btn.querySelector('i');
            const show = target.type === 'password';
            target.type = show ? 'text' : 'password';
            icon.className = show ? 'bi bi-eye-slash' : 'bi bi-eye';
        });
    });

    // Submit
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        hideInlineAlert();

        if (!Object.values(requirements).every(r => r.met)) {
            showInlineAlert('Please meet all password requirements (including no sequential patterns).', 'error');
            return;
        }
        if (newPwd.value !== confirmPwd.value) {
            showInlineAlert('Passwords do not match.', 'error');
            return;
        }

        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status"></span> Resetting...';

        try {
            const resp = await fetch('api/login/do_reset_password.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'new_password=' + encodeURIComponent(newPwd.value) +
                      '&_csrf_token=' + encodeURIComponent(document.querySelector('input[name="_csrf_token"]').value)
            });
            const text = await resp.text();
            let data;
            try { data = JSON.parse(text); }
            catch { throw new Error(text || 'Invalid server response'); }

            if (data.success) {
                showInlineAlert(data.message || 'Password reset successfully! Redirecting...', 'success');
                setTimeout(() => window.location.href = 'login.php?success=password_reset', 1500);
            } else {
                showInlineAlert(data.error || 'Password reset failed.', 'error');
            }
        } catch (err) {
            showInlineAlert(err.message || 'An error occurred. Please try again.', 'error');
        } finally {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="bi bi-arrow-repeat"></i> RESET PASSWORD';
        }
    });
});
</script>
</body>
</html>