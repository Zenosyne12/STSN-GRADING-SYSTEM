<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/api/shared/db_connect.php';

$totalStudentAccounts = 0;
try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM tblusers WHERE role_id = 3");
    $totalStudentAccounts = (int) ($stmt ? $stmt->fetchColumn() : 0);
} catch (Throwable $e) {
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Student Mobile Accounts</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        body {
            background: #f3f7fd;
        }

        .am-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }

        .am-page-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 0.2rem;
        }

        .am-page-header p {
            margin: 0;
            font-size: 0.88rem;
            opacity: 0.85;
        }

        .am-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            background: rgba(255, 255, 255, 0.15);
            border: 1.5px solid rgba(255, 255, 255, 0.3);
            border-radius: 999px;
            padding: 0.45rem 1rem;
            font-size: 0.88rem;
            font-weight: 700;
            color: #fff;
        }

        .am-card {
            background: #fff;
            border: 1px solid #dce8f8;
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18, 72, 168, 0.06);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }

        .am-card-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid #e8f0fb;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
        }

        .am-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: #132f62;
            margin: 0 0 0.15rem;
        }

        .am-card-subtitle {
            font-size: 0.8rem;
            color: #7a93b8;
            margin: 0;
        }

        .am-card-footer {
            padding: 0.75rem 1.2rem;
            border-top: 1px solid #e8f0fb;
            background: #fafcff;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: .5rem;
        }

        .btn-am {
            font-weight: 600;
            font-size: 0.82rem;
            border-radius: 8px;
            padding: 0.42rem 0.9rem;
            cursor: pointer;
            border: 1.5px solid transparent;
            line-height: 1.4;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: .35rem;
            white-space: nowrap;
            transition: all 0.15s;
        }

        .btn-am-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            box-shadow: 0 2px 8px rgba(26, 110, 245, 0.2);
        }

        .btn-am-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
        }

        .btn-am-info {
            background: #eef4ff;
            color: #1248a8;
            border-color: #cfe0fb;
        }

        .btn-am-info:hover {
            background: #dfeaff;
            color: #0f3d90;
        }

        .btn-am-danger {
            background: #fff0f1;
            color: #b42318;
            border-color: #f5b5ba;
        }

        .btn-am-danger:hover {
            background: #ffe2e4;
        }

        .btn-am-success {
            background: #e6f6ea;
            color: #16794b;
            border-color: #bfe8ce;
        }

        .btn-am-success:hover {
            background: #d7f0df;
        }

        .btn-am-light {
            background: #fff;
            color: #1248a8;
            border-color: #b8d0fa;
        }

        .btn-am-light:hover {
            background: #eef4ff;
            border-color: #8db5f7;
        }

        .btn-am-sm {
            padding: 0.28rem 0.65rem;
            font-size: 0.78rem;
        }

        .am-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
        }

        .am-table thead th {
            background: #f4f8ff;
            color: #3b5e96;
            font-size: 0.73rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 0.85rem 1rem;
            border-bottom: 1.5px solid #dce8f8;
        }

        .am-table tbody tr:not(:last-child) td {
            border-bottom: 1px solid #f0f5fc;
        }

        .am-table tbody tr:hover td {
            background: #f7fbff;
        }

        .am-table tbody td {
            padding: 0.9rem 1rem;
            font-size: 0.92rem;
            color: #213a5e;
            vertical-align: middle;
        }

        .am-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.32rem 0.75rem;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 700;
        }

        .am-badge-success {
            background: #e6f6ea;
            color: #16794b;
            border: 1.5px solid #bfe8ce;
        }

        .am-badge-warning {
            background: #fff7e8;
            color: #9a6200;
            border: 1.5px solid #f6d28b;
        }

        .am-badge-neutral {
            background: #f3f5f8;
            color: #7a8ea8;
            border: 1.5px solid #dde4ee;
        }

        .am-badge-primary {
            background: #eef4ff;
            color: #1248a8;
            border: 1.5px solid #cfe0fb;
        }

        .am-pagination {
            display: flex;
            gap: 0.3rem;
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .am-pagination .am-page-item .am-page-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
            border-radius: 7px;
            font-size: 0.83rem;
            font-weight: 600;
            cursor: pointer;
            border: 1.5px solid #dce8f8;
            color: #1a6ef5;
            background: #fff;
            transition: all 0.13s;
            padding: 0 0.65rem;
            text-decoration: none;
        }

        .am-pagination .am-page-item .am-page-link:hover {
            background: #eef4ff;
            border-color: #9cc2fc;
        }

        .am-pagination .am-page-item.active .am-page-link {
            background: #1a6ef5;
            border-color: #1a6ef5;
            color: #fff;
        }

        .am-pagination .am-page-item.disabled .am-page-link {
            background: #f8fbff;
            border-color: #e2ebf8;
            color: #9ab0c8;
            cursor: not-allowed;
            pointer-events: none;
        }

        .am-empty {
            text-align: center;
            padding: 2.5rem 1.5rem;
            color: #9ab0c8;
        }

        .am-empty i {
            font-size: 2.2rem;
            display: block;
            margin-bottom: 0.6rem;
            opacity: 0.5;
        }

        .am-footer-note {
            font-size: 0.82rem;
            color: #7a93b8;
        }

        .action-wrap {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: .45rem;
            flex-wrap: nowrap;
        }

        .am-modal .modal-content {
            border: 0;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(18, 72, 168, 0.16);
            overflow: hidden;
        }

        .am-modal .modal-header {
            background: #f4f8ff;
            border-bottom: 1px solid #dce8f8;
            padding: 1rem 1.25rem;
        }

        .am-modal .modal-title {
            font-size: 1rem;
            font-weight: 700;
            color: #132f62;
        }

        .am-modal .modal-body {
            background: #fff;
            padding: 1.2rem;
        }

        .am-modal .modal-footer {
            padding: 0.9rem 1.2rem;
            border-top: 1px solid #e8f0fb;
            background: #fafcff;
        }

        .am-modal .form-label {
            font-size: 0.82rem;
            font-weight: 700;
            color: #3b5e96;
            margin-bottom: 0.35rem;
        }

        .am-modal .form-control,
        .am-modal .form-select {
            border-radius: 10px;
            border: 1.5px solid #c8daf8;
            font-size: 0.9rem;
            color: #213a5e;
            min-height: 42px;
            padding: 0.42rem 0.85rem;
        }

        .am-view-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 1rem;
        }

        .am-view-card {
            border: 1px solid #dce8f8;
            border-radius: 12px;
            background: #fff;
            padding: 0.95rem 1rem;
        }

        .am-view-label {
            color: #7a93b8;
            font-size: 0.76rem;
            font-weight: 700;
            margin-bottom: 0.35rem;
            text-transform: uppercase;
        }

        .am-view-value {
            color: #132f62;
            font-size: 0.93rem;
            font-weight: 600;
            word-break: break-word;
        }

        @media(max-width:767px) {
            .am-view-grid {
                grid-template-columns: 1fr;
            }

            .action-wrap {
                flex-wrap: wrap;
            }
        }
    </style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <div class="app-wrapper">
        <?php require_once("includes/header.php"); ?>
        <?php require_once("includes/sidebar.php"); ?>
        <main class="app-main">
            <div class="app-content">
                <div class="container-fluid py-3">

                    <div class="am-page-header">
                        <div>
                            <h3><i class="bi bi-phone me-2"></i>Student Mobile Accounts</h3>
                            <p>Manage student accounts for the STSN Grade Viewer mobile app</p>
                        </div>
                        <div class="d-flex gap-2 align-items-center flex-wrap">
                            <div class="am-chip">
                                <i class="bi bi-people-fill"></i>
                                Total Accounts: <span id="totalCount"><?= $totalStudentAccounts ?></span>
                            </div>
                        </div>
                    </div>

                    <div class="am-card">
                        <div class="am-card-header">
                            <div>
                                <p class="am-card-title">Student Account List</p>
                                <p class="am-card-subtitle">Students log in using their generated username (FirstnameLastnameBirthYear).</p>
                            </div>
                            <button class="btn-am btn-am-primary" onclick="openAddModal()">
                                <i class="bi bi-plus-circle"></i> Create Account
                            </button>
                        </div>

                        <div class="p-3 border-bottom" style="background:#fafcff;">
                            <input type="text" id="searchInput" class="form-control"
                                placeholder="Search by name or LRN..."
                                style="border-radius:10px; border:1.5px solid #c8daf8; max-width:400px;">
                        </div>

                        <div class="am-card-body">
                            <div class="d-none d-md-block">
                                <table class="am-table">
                                    <thead>
                                        <tr>
                                            <th style="width:50px;">#</th>
                                            <th>LRN</th>
                                            <th>Student Name</th>
                                            <th>Username</th>
                                            <th>Grade Level</th>
                                            <th>Password Status</th>
                                            <th>Status</th>
                                            <th>Created</th>
                                            <th style="width:200px;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="tableBody">
                                        <tr>
                                            <td colspan="9">
                                                <div class="am-empty">
                                                    <i class="bi bi-hourglass-split"></i>
                                                    <p>Loading accounts…</p>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="d-block d-md-none p-3" id="cardView"></div>
                        </div>

                        <div class="am-card-footer">
                            <div class="am-footer-note" id="countText"></div>
                            <ul class="am-pagination" id="pagination"></ul>
                        </div>
                    </div>

                </div>
            </div>
        </main>
        <?php require_once("includes/footer.php"); ?>
    </div>

    <!-- â”€â”€ CREATE ACCOUNT MODAL â”€â”€ -->
    <div class="modal fade am-modal" id="addModal" tabindex="-1" data-bs-backdrop="false">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-phone me-2"></i>Create Student Mobile Account</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Select Student <span class="text-danger">*</span></label>
                        <select id="studentSelect" class="form-select" onchange="onStudentSelect()">
                            <option value="">— Loading students… —</option>
                        </select>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-md-6">
                            <label class="form-label">First Name</label>
                            <input type="text" id="fnameInput" class="form-control" readonly>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Last Name</label>
                            <input type="text" id="lnameInput" class="form-control" readonly>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">LRN</label>
                            <input type="text" id="lrnInput" class="form-control" readonly>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Grade Level</label>
                            <input type="text" id="gradeInput" class="form-control" readonly>
                        </div>
                    </div>
                    <div class="mb-1">
                        <label class="form-label">Generated Username</label>
                        <input type="text" id="usernameInput" class="form-control" readonly>
                        <div class="mt-2 text-muted" style="font-size:.82rem;">
                            <i class="bi bi-info-circle me-1"></i>
                            Format: <strong>FirstnameLastnameBirthYear</strong> (e.g. AndreHechanova2005)
                        </div>
                        <div class="mt-1 text-muted" style="font-size:.82rem;">
                            <i class="bi bi-envelope me-1"></i>
                            A temporary password will be sent to the student's registered email.
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-am btn-am-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn-am btn-am-primary" id="btnCreate" onclick="createAccount()"
                        disabled>
                        <i class="bi bi-check-circle me-1"></i> Create & Send Email
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- â”€â”€ VIEW MODAL â”€â”€ -->
    <div class="modal fade am-modal" id="viewModal" tabindex="-1" data-bs-backdrop="false">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-person-circle me-2"></i>Account Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="viewModalBody">
                    <div class="am-empty"><span class="spinner-border spinner-border-sm"></span> Loading…</div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-am btn-am-light" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- â”€â”€ SUCCESS MODAL â”€â”€ -->
    <div class="modal fade am-modal" id="successModal" tabindex="-1" data-bs-backdrop="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-check-circle-fill text-success me-2"></i>Account Created</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="am-view-card mb-3">
                        <div class="am-view-label">Username</div>
                        <div class="am-view-value" id="newUsername" style="font-family:monospace;">—</div>
                    </div>
                    <div id="successMsg" style="font-size:.87rem; color:#5a7299;">
                        <i class="bi bi-envelope-check me-1"></i> Temporary password sent via email.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-am btn-am-light" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./js/adminlte.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="./js/sweet-alerts.js"></script>
    <script>
        function esc(v) {
            return String(v ?? '')
                .replace(/&/g, '&amp;').replace(/</g, '&lt;')
                .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
        }

        function showAlert(msg, type) {
            AppAlerts.showToast(msg, type);
        }

        function confirmAction(msg, onYes, opts = {}) {
            AppAlerts.confirmAction({
                title: opts.title || 'Confirm',
                text: msg,
                icon: opts.icon || 'question',
                confirmButtonText: opts.confirmText || 'Yes'
            }).then(r => { if (r.isConfirmed) onYes(); });
        }

        async function apiCall(url, opts) {
            const res = await fetch(url, opts || {});
            const text = await res.text();
            try { return JSON.parse(text); }
            catch (e) { console.error('Bad JSON:', text); throw new Error('Invalid server response.'); }
        }

        // â”€â”€ Generate username: FirstnameLastnameBirthYear â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        function generateUsername(fname, lname, birthdate) {
            const clean = str => str.replace(/\s+/g, '').replace(/[^a-zA-Z]/g, '');
            const birthYear = birthdate ? new Date(birthdate).getFullYear() : '';
            return clean(fname) + clean(lname) + birthYear;
        }

        // â”€â”€ TABLE â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        let currentPage = 1;
        let currentSearch = '';
        let searchTimer = null;
        let totalCount = 0;
        const rowsPerPage = 10;

        async function fetchAccounts(page = 1) {
            currentPage = page;
            const params = new URLSearchParams({ page, search: currentSearch });
            try {
                const json = await apiCall(`api/student_accounts/list.php?${params}`);
                const list = json.data || [];
                totalCount = Number(json.total || 0);
                const pages = Number(json.pages || 1);
                const offset = (page - 1) * rowsPerPage;

                document.getElementById('totalCount').textContent = totalCount;
                document.getElementById('countText').textContent =
                    totalCount ? `Showing ${offset + 1}–${Math.min(offset + list.length, totalCount)} of ${totalCount} accounts` : 'No accounts found.';

                const tbody = document.getElementById('tableBody');
                const cardView = document.getElementById('cardView');

                if (!list.length) {
                    const empty = `<div class="am-empty"><i class="bi bi-people"></i><p>No student accounts found.</p></div>`;
                    tbody.innerHTML = `<tr><td colspan="9">${empty}</td></tr>`;
                    cardView.innerHTML = empty;
                    document.getElementById('pagination').innerHTML = '';
                    return;
                }

                tbody.innerHTML = list.map((acc, i) => {
                    const active = String(acc.status || 'Active').toLowerCase() === 'active';
                    const pwBadge = acc.must_change_password == 1
                        ? '<span class="am-badge am-badge-warning">Default</span>'
                        : '<span class="am-badge am-badge-success">Changed</span>';
                    return `<tr>
                        <td>${offset + i + 1}</td>
                        <td>${esc(acc.lrn || '—')}</td>
                        <td style="font-weight:600;">${esc(acc.full_name || '—')}</td>
                        <td style="font-family:monospace;">${esc(acc.username || '—')}</td>
                        <td>${esc(acc.grade_level || '—')}</td>
                        <td>${pwBadge}</td>
                        <td><span class="am-badge ${active ? 'am-badge-success' : 'am-badge-warning'}">${esc(acc.status || 'Active')}</span></td>
                        <td style="font-size:.83rem;color:#6b84a2;">${esc(acc.created_at || '—')}</td>
                        <td>
                            <div class="action-wrap">
                                <button class="btn-am btn-am-info btn-am-sm" onclick="viewAccount(${acc.id})">
                                    <i class="bi bi-eye"></i> View
                                </button>
                                <button class="btn-am ${active ? 'btn-am-danger' : 'btn-am-success'} btn-am-sm"
                                    onclick='toggleStatus(${acc.id}, "${esc(acc.status || 'Active')}")'>
                                    <i class="bi ${active ? 'bi-person-dash' : 'bi-person-check'}"></i>
                                    ${active ? 'Disable' : 'Enable'}
                                </button>
                            </div>
                        </td>
                    </tr>`;
                }).join('');

                cardView.innerHTML = list.map((acc, i) => {
                    const active = String(acc.status || 'Active').toLowerCase() === 'active';
                    return `<div class="border rounded-3 p-3 mb-3" style="background:#fff;">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <div>
                                <div style="font-weight:700;">${offset + i + 1}. ${esc(acc.full_name || '—')}</div>
                                <div style="font-size:.82rem;color:#7a93b8;">LRN: ${esc(acc.lrn || '—')}</div>
                            </div>
                            <span class="am-badge ${active ? 'am-badge-success' : 'am-badge-warning'}">${esc(acc.status || 'Active')}</span>
                        </div>
                        <div style="font-size:.84rem;color:#4f678d;margin-bottom:.75rem;">
                            <strong>Grade:</strong> ${esc(acc.grade_level || '—')}<br>
                            <strong>Username:</strong> ${esc(acc.username || '—')}
                        </div>
                        <div class="d-grid gap-2">
                            <button class="btn-am btn-am-info w-100" onclick="viewAccount(${acc.id})"><i class="bi bi-eye"></i> View</button>
                            <button class="btn-am ${active ? 'btn-am-danger' : 'btn-am-success'} w-100"
                                onclick='toggleStatus(${acc.id}, "${esc(acc.status || 'Active')}")'>
                                <i class="bi ${active ? 'bi-person-dash' : 'bi-person-check'}"></i> ${active ? 'Disable' : 'Enable'}
                            </button>
                        </div>
                    </div>`;
                }).join('');

                let pHtml = `<li class="am-page-item ${page <= 1 ? 'disabled' : ''}">
                    <a class="am-page-link" onclick="${page > 1 ? `fetchAccounts(${page - 1})` : ''}">Prev</a></li>`;
                for (let n = 1; n <= pages; n++) {
                    pHtml += `<li class="am-page-item ${n === page ? 'active' : ''}">
                        <a class="am-page-link" onclick="fetchAccounts(${n})">${n}</a></li>`;
                }
                pHtml += `<li class="am-page-item ${page >= pages ? 'disabled' : ''}">
                    <a class="am-page-link" onclick="${page < pages ? `fetchAccounts(${page + 1})` : ''}">Next</a></li>`;
                document.getElementById('pagination').innerHTML = pHtml;

            } catch (e) {
                document.getElementById('tableBody').innerHTML =
                    `<tr><td colspan="9"><div class="am-empty"><i class="bi bi-exclamation-octagon"></i><p>${esc(e.message)}</p></div></td></tr>`;
            }
        }

        document.getElementById('searchInput').addEventListener('input', function () {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => {
                currentSearch = this.value.trim();
                fetchAccounts(1);
            }, 400);
        });

        function toggleStatus(id, current) {
            const newStatus = current.toLowerCase() === 'active' ? 'Inactive' : 'Active';
            confirmAction(`This will mark the account as ${newStatus}.`, async () => {
                try {
                    const json = await apiCall('api/student_accounts/update.php', {
                        method: 'POST', headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id, status: newStatus })
                    });
                    if (json.success !== false) {
                        showAlert(`Account marked as ${newStatus}.`, 'success');
                        fetchAccounts(currentPage);
                    } else { showAlert(json.error || 'Update failed.', 'danger'); }
                } catch (e) { showAlert(e.message, 'danger'); }
            }, { title: newStatus === 'Active' ? 'Enable account?' : 'Disable account?', confirmText: newStatus });
        }

        async function viewAccount(id) {
            const body = document.getElementById('viewModalBody');
            body.innerHTML = '<div class="am-empty"><span class="spinner-border spinner-border-sm"></span> Loading…</div>';
            bootstrap.Modal.getOrCreateInstance(document.getElementById('viewModal')).show();
            try {
                const json = await apiCall(`api/student_accounts/view.php?id=${id}`);
                const a = json.data || {};
                const active = String(a.status || 'Active').toLowerCase() === 'active';
                body.innerHTML = `<div class="am-view-grid">
                    <div class="am-view-card"><div class="am-view-label">Full Name</div><div class="am-view-value">${esc(a.full_name || '—')}</div></div>
                    <div class="am-view-card"><div class="am-view-label">LRN</div><div class="am-view-value">${esc(a.lrn || '—')}</div></div>
                    <div class="am-view-card"><div class="am-view-label">Username</div><div class="am-view-value" style="font-family:monospace;">${esc(a.username || '—')}</div></div>
                    <div class="am-view-card"><div class="am-view-label">Grade Level</div><div class="am-view-value">${esc(a.grade_level || '—')}</div></div>
                    <div class="am-view-card"><div class="am-view-label">Status</div><div class="am-view-value"><span class="am-badge ${active ? 'am-badge-success' : 'am-badge-warning'}">${esc(a.status || '—')}</span></div></div>
                    <div class="am-view-card"><div class="am-view-label">Password Status</div><div class="am-view-value">${a.must_change_password == 1 ? '<span class="am-badge am-badge-warning">Default</span>' : '<span class="am-badge am-badge-success">Changed</span>'}</div></div>
                    <div class="am-view-card"><div class="am-view-label">Created</div><div class="am-view-value">${esc(a.created_at || '—')}</div></div>
                </div>`;
            } catch (e) {
                body.innerHTML = `<div class="am-empty"><i class="bi bi-exclamation-circle"></i><p>${esc(e.message)}</p></div>`;
            }
        }

        async function openAddModal() {
            clearAddForm();
            const sel = document.getElementById('studentSelect');
            sel.innerHTML = '<option value="">— Loading… —</option>';
            bootstrap.Modal.getOrCreateInstance(document.getElementById('addModal')).show();
            try {
                const json = await apiCall('api/student_accounts/get_students.php');
                const students = json.students || [];
                if (!students.length) {
                    sel.innerHTML = '<option value="">— No students without accounts —</option>';
                    return;
                }
                sel.innerHTML = '<option value="">— Select a Student —</option>';
                students.forEach(s => {
                    const opt = document.createElement('option');
                    opt.value = s.id;
                    opt.textContent = `${s.lrn} — ${s.full_name}`;
                    opt.dataset.lrn       = s.lrn || '';
                    opt.dataset.fname     = s.fname || '';
                    opt.dataset.lname     = s.lname || '';
                    opt.dataset.grade     = s.grade_level || '';
                    opt.dataset.birthdate = s.birthdate || ''; // âœ… birthdate now included
                    sel.appendChild(opt);
                });
            } catch (e) {
                sel.innerHTML = '<option value="">— Error loading —</option>';
                showAlert('Failed to load students.', 'danger');
            }
        }

        function onStudentSelect() {
            const sel = document.getElementById('studentSelect');
            const opt = sel.options[sel.selectedIndex];
            clearAddForm();
            if (!opt || !opt.value) return;

            const fname     = opt.dataset.fname;
            const lname     = opt.dataset.lname;
            const birthdate = opt.dataset.birthdate;

            // âœ… Generate username as FirstnameLastnameBirthYear
            const username = generateUsername(fname, lname, birthdate);

            document.getElementById('fnameInput').value    = fname;
            document.getElementById('lnameInput').value    = lname;
            document.getElementById('lrnInput').value      = opt.dataset.lrn;
            document.getElementById('gradeInput').value    = opt.dataset.grade;
            document.getElementById('usernameInput').value = username;
            document.getElementById('btnCreate').disabled  = false;
        }

        function clearAddForm() {
            ['fnameInput', 'lnameInput', 'lrnInput', 'gradeInput', 'usernameInput'].forEach(id => {
                document.getElementById(id).value = '';
            });
            document.getElementById('btnCreate').disabled = true;
        }

        async function createAccount() {
            const sel       = document.getElementById('studentSelect');
            const studentId = sel.value;
            const username  = document.getElementById('usernameInput').value;

            if (!studentId) { showAlert('Please select a student.', 'warning'); return; }
            if (!username)  { showAlert('Username could not be generated. Check student birthdate.', 'warning'); return; }

            const btn = document.getElementById('btnCreate');
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Creating…';

            try {
                const json = await apiCall('api/student_accounts/create.php', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ student_id: parseInt(studentId), username: username })
                });
                if (json.success !== false) {
                    bootstrap.Modal.getInstance(document.getElementById('addModal'))?.hide();
                    document.getElementById('newUsername').textContent = json.username || username;
                    document.getElementById('successMsg').innerHTML =
                        `<i class="bi bi-envelope-check me-1"></i>${esc(json.message || 'Temporary password sent via email.')}`;
                    bootstrap.Modal.getOrCreateInstance(document.getElementById('successModal')).show();
                    fetchAccounts(1);
                } else { showAlert(json.error || 'Creation failed.', 'danger'); }
            } catch (e) { showAlert('Failed: ' + e.message, 'danger'); }
            finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="bi bi-check-circle me-1"></i> Create & Send Email';
            }
        }

        document.getElementById('addModal').addEventListener('hidden.bs.modal', clearAddForm);

        fetchAccounts(1);
    </script>
</body>
</html>




