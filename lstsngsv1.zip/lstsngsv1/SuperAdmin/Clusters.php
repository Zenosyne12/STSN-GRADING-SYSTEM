<?php
session_start();

if (!isset($_SESSION['user_id']) || (int) ($_SESSION['role_id'] ?? 0) !== 4) {
    header('Location: ../login.php');
    exit;
}

require_once __DIR__ . '/../api/shared/db_connect.php';
require_once __DIR__ . '/../includes/breadcrumb.php';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn = null;
$pageError = '';
try {
    $conn = new mysqli($host, $user, $pass, $db);
    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    $pageError = 'Unable to connect to the database.';
}

if (!isset($_SESSION['clusters_csrf'])) {
    $_SESSION['clusters_csrf'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $flashMessage = '';
    $flashType = 'success';

    try {
        if (!hash_equals($_SESSION['clusters_csrf'], (string) ($_POST['csrf_token'] ?? ''))) {
            throw new InvalidArgumentException('Your session token has expired. Please try again.');
        }
        if (!$conn) {
            throw new RuntimeException('The database is currently unavailable.');
        }

        $action = (string) ($_POST['action'] ?? '');
        if ($action === 'add' || $action === 'edit') {
            $clusterName = trim((string) ($_POST['cluster_name'] ?? ''));
            if ($clusterName === '' || mb_strlen($clusterName) > 255) {
                throw new InvalidArgumentException('Cluster name is required and must be 255 characters or fewer.');
            }
            $track = trim((string) ($_POST['track'] ?? ''));
            if (!in_array($track, ['Academic', 'Tech-Pro'], true)) {
                throw new InvalidArgumentException('Select a valid Track.');
            }

            $clusterId = (int) ($_POST['id'] ?? 0);
            if ($action === 'edit' && $clusterId < 1) {
                throw new InvalidArgumentException('Select a valid cluster to edit.');
            }

            if ($action === 'edit') {
                $duplicate = $conn->prepare('SELECT id FROM tblclusters WHERE cluster_name = ? AND id <> ? LIMIT 1');
                $duplicate->bind_param('si', $clusterName, $clusterId);
            } else {
                $duplicate = $conn->prepare('SELECT id FROM tblclusters WHERE cluster_name = ? LIMIT 1');
                $duplicate->bind_param('s', $clusterName);
            }
            $duplicate->execute();
            $duplicate->store_result();
            $hasDuplicate = $duplicate->num_rows > 0;
            $duplicate->close();
            if ($hasDuplicate) {
                throw new InvalidArgumentException('A cluster with that name already exists.');
            }

            if ($action === 'add') {
                $stmt = $conn->prepare('INSERT INTO tblclusters (cluster_name, track) VALUES (?, ?)');
                $stmt->bind_param('ss', $clusterName, $track);
                $stmt->execute();
                $stmt->close();
                $flashMessage = 'Cluster added successfully.';
            } else {
                $stmt = $conn->prepare('UPDATE tblclusters SET cluster_name = ?, track = ? WHERE id = ?');
                $stmt->bind_param('ssi', $clusterName, $track, $clusterId);
                $stmt->execute();
                $stmt->close();
                $flashMessage = 'Cluster updated successfully.';
            }
        } elseif ($action === 'delete' && isset($_POST['delete_cluster'])) {
            $clusterId = (int) ($_POST['id'] ?? 0);
            if ($clusterId < 1) {
                throw new InvalidArgumentException('Select a valid cluster.');
            }
          $stmt = $conn->prepare('DELETE FROM tblclusters WHERE id = ?');
            $stmt->bind_param('i', $clusterId);
            $stmt->execute();
          $deleted = $stmt->affected_rows > 0;
            $stmt->close();
          if (!$deleted) {
                throw new InvalidArgumentException('Cluster not found.');
            }
          $flashMessage = 'Cluster deleted successfully.';
        } else {
            throw new InvalidArgumentException('Invalid cluster action.');
        }
    } catch (InvalidArgumentException $e) {
        $flashMessage = $e->getMessage();
        $flashType = 'danger';
    } catch (Throwable $e) {
        $flashMessage = 'Unable to save the cluster. Please try again.';
        $flashType = 'danger';
    }

    $_SESSION['clusters_flash'] = ['message' => $flashMessage, 'type' => $flashType];
    header('Location: Clusters.php');
    exit;
}

$flash = $_SESSION['clusters_flash'] ?? null;
unset($_SESSION['clusters_flash']);
$clusters = [];
if ($conn) {
    try {
        $result = $conn->query('SELECT id, cluster_name, track FROM tblclusters ORDER BY track ASC, cluster_name ASC, id ASC');
        $clusters = $result->fetch_all(MYSQLI_ASSOC);
        $result->free();
    } catch (mysqli_sql_exception $e) {
        $pageError = 'Unable to load clusters. Confirm that the tblclusters migration has been applied.';
    }
}

$escape = static fn($value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="color-scheme" content="light dark">
  <title>STSN Super Admin | Clusters</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="../css/adminlte.css">
  <link rel="stylesheet" href="../css/dark-mode.css">
  <link rel="stylesheet" href="../css/admin-responsive.css">
  <link rel="stylesheet" href="../css/superadmin-theme.css">
  <script src="../js/theme.js" defer></script>
  <style>
    .cluster-card { background: var(--bs-body-bg); border: 1px solid var(--bs-border-color); border-radius: 10px; overflow: hidden; }
    .cluster-card-header { display: flex; justify-content: space-between; align-items: center; gap: 1rem; flex-wrap: wrap; padding: 1rem 1.25rem; border-bottom: 1px solid var(--bs-border-color); }
    .cluster-card-header h2 { margin: 0; font-size: 1.05rem; font-weight: 700; }
    .cluster-table th { white-space: nowrap; color: var(--bs-secondary-color); font-size: .78rem; text-transform: uppercase; }
    .cluster-table td, .cluster-table th { vertical-align: middle; }
    .cluster-actions { display: flex; align-items: center; gap: .5rem; flex-wrap: wrap; }
  </style>
</head>
<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">
<div class="app-wrapper">
  <?php include_once __DIR__ . '/../includes/header.php'; ?>
  <?php include_once __DIR__ . '/../includes/sAdmin_sidebar.php'; ?>

  <main class="app-main">
    <div class="app-content">
      <div class="container-fluid p-4">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3 p-4 text-white sa-page-header">
          <div class="d-flex align-items-center gap-3">
            <i class="bi bi-diagram-3" style="font-size:1.5rem;"></i>
            <div>
              <h1 class="mb-0" style="font-size:1.5rem;font-weight:600;">Clusters</h1>
              <p class="mb-0" style="font-size:.85rem;opacity:.85;">Manage subject clusters and their availability</p>
            </div>
          </div>
        </div>

        <?php renderBreadcrumb([
          ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'],
          ['label' => 'System Configuration', 'href' => '#', 'icon' => 'bi bi-gear'],
          ['label' => 'Clusters', 'icon' => 'bi bi-diagram-3'],
        ]); ?>

        <?php if ($flash): ?>
          <div class="alert alert-<?= $escape($flash['type']) ?> alert-dismissible fade show" role="alert">
            <?= $escape($flash['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
        <?php endif; ?>
        <?php if ($pageError !== ''): ?>
          <div class="alert alert-danger" role="alert"><?= $escape($pageError) ?></div>
        <?php endif; ?>

        <section class="cluster-card">
          <div class="cluster-card-header">
            <h2>Cluster List</h2>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addClusterModal">
              <i class="bi bi-plus-lg me-1"></i> Add Cluster
            </button>
          </div>
          <div class="table-responsive">
            <table class="table table-hover mb-0 cluster-table">
              <thead>
                <tr><th scope="col">ID</th><th scope="col">Cluster Name</th><th scope="col">Actions</th></tr>
              </thead>
              <tbody>
                <?php if (!$clusters): ?>
                  <tr><td colspan="3" class="text-center text-body-secondary py-4">No clusters found.</td></tr>
                <?php else: ?>
                  <?php
                  $grouped = ['Academic' => [], 'Tech-Pro' => [], '(Unassigned)' => []];
                  foreach ($clusters as $cluster) {
                      $trackName = $cluster['track'] ?? '';
                      if ($trackName === 'Academic' || $trackName === 'Tech-Pro') {
                          $grouped[$trackName][] = $cluster;
                      } else {
                          $grouped['(Unassigned)'][] = $cluster;
                      }
                  }
                  ?>
                  <?php foreach ($grouped as $trackName => $rows): ?>
                    <?php if (empty($rows)) continue; ?>
                    <tr>
                      <th colspan="3" style="background:#f5f7fa;font-weight:800;padding:.6rem .9rem;">
                        <?= $escape($trackName) ?> Track
                        <span class="text-muted" style="font-weight:500;font-size:.85rem;">
                          (<?= count($rows) ?>)
                        </span>
                      </th>
                    </tr>
                    <?php foreach ($rows as $cluster): ?>
                      <tr>
                        <td><?= (int) $cluster['id'] ?></td>
                        <td><?= $escape($cluster['cluster_name']) ?></td>
                        <td>
                          <div class="cluster-actions">
                            <button type="button" class="btn btn-sm btn-outline-primary edit-cluster-btn"
                                    data-id="<?= (int) $cluster['id'] ?>"
                                    data-name="<?= $escape($cluster['cluster_name']) ?>"
                                    data-track="<?= $escape($cluster['track'] ?? '') ?>"
                                    data-bs-toggle="modal" data-bs-target="#editClusterModal">
                              <i class="bi bi-pencil me-1"></i> Edit
                            </button>
                            <form method="post" action="Clusters.php" class="m-0">
                              <input type="hidden" name="csrf_token" value="<?= $escape($_SESSION['clusters_csrf']) ?>">
                              <input type="hidden" name="action" value="delete">
                              <input type="hidden" name="delete_cluster" value="1">
                              <input type="hidden" name="id" value="<?= (int) $cluster['id'] ?>">
                              <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this cluster? This action cannot be undone.');">
                                <i class="bi bi-trash"></i> Delete
                              </button>
                            </form>
                          </div>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  </main>

  <?php include_once __DIR__ . '/../includes/footer.php'; ?>
</div>

<div class="modal fade" id="addClusterModal" tabindex="-1" aria-labelledby="addClusterModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <form method="post" action="Clusters.php" class="modal-content">
      <div class="modal-header">
        <h2 class="modal-title fs-5" id="addClusterModalLabel">Add Cluster</h2>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= $escape($_SESSION['clusters_csrf']) ?>">
        <input type="hidden" name="action" value="add">
        <label class="form-label" for="newClusterName">Cluster Name</label>
        <input type="text" class="form-control" id="newClusterName" name="cluster_name" maxlength="255" required>
        <div class="mb-3">
          <label class="form-label" for="newClusterTrack">Track <span class="text-danger">*</span></label>
          <select class="form-select" id="newClusterTrack" name="track" required>
            <option value="">— Select Track —</option>
            <option value="Academic">Academic Track</option>
            <option value="Tech-Pro">Technical-Professional (Tech-Pro)</option>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i> Add Cluster</button>
      </div>
    </form>
  </div>
</div>

<div class="modal fade" id="editClusterModal" tabindex="-1" aria-labelledby="editClusterModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <form method="post" action="Clusters.php" class="modal-content">
      <div class="modal-header">
        <h2 class="modal-title fs-5" id="editClusterModalLabel">Edit Cluster</h2>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= $escape($_SESSION['clusters_csrf']) ?>">
        <input type="hidden" name="action" value="edit">
        <input type="hidden" name="id" id="editClusterId">
        <label class="form-label" for="editClusterName">Cluster Name</label>
        <input type="text" class="form-control" id="editClusterName" name="cluster_name" maxlength="255" required>
        <div class="mb-3">
          <label class="form-label" for="editClusterTrack">Track <span class="text-danger">*</span></label>
          <select class="form-select" id="editClusterTrack" name="track" required>
            <option value="">— Select Track —</option>
            <option value="Academic">Academic Track</option>
            <option value="Tech-Pro">Technical-Professional (Tech-Pro)</option>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg me-1"></i> Save Changes</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js"></script>
<script src="../js/adminlte.js"></script>
<script src="../js/system-alerts.js"></script>
<script src="../js/superadmin-alerts.js"></script>
<script>
  document.querySelectorAll('.edit-cluster-btn').forEach(function (button) {
    button.addEventListener('click', function () {
      document.getElementById('editClusterId').value = button.dataset.id || '';
      document.getElementById('editClusterName').value = button.dataset.name || '';
      document.getElementById('editClusterTrack').value = button.dataset.track || '';
    });
  });
</script>
</body>
</html>
