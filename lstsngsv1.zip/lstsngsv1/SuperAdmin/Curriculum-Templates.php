<?php
session_start();

// Auth guard: must be logged in as Super Admin (role_id = 4)
if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 4) {
    header('Location: ../login.php');
    exit;
}

require_once __DIR__ . '/../api/shared/db_connect.php';
require_once __DIR__ . '/../includes/breadcrumb.php';

// ---------------------------------------------------------------------------
// Grade levels (grouped into education stages for the left tree panel)
// ---------------------------------------------------------------------------
$gradeLevels = [];
$stmt = $pdo->prepare('SELECT id, grade_level_name, sort_order FROM tblgradelevel ORDER BY sort_order ASC');
$stmt->execute();
$gradeLevels = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Group grade levels into stages: Kindergarten / Elementary (1-6) / JHS (7-10) / SHS (11-12)
$stages = [
    'kindergarten' => ['label' => 'Kindergarten',       'icon' => 'bi-balloon',     'grades' => []],
    'elementary'   => ['label' => 'Elementary',         'icon' => 'bi-backpack',    'grades' => []],
    'jhs'          => ['label' => 'Junior High School', 'icon' => 'bi-book',        'grades' => []],
    'shs'          => ['label' => 'Senior High School', 'icon' => 'bi-mortarboard', 'grades' => []],
];

foreach ($gradeLevels as $gl) {
    $name = $gl['grade_level_name'];
    if (preg_match('/^Grade\s+(\d+)$/i', $name, $m)) {
        $num = (int)$m[1];
        if ($num >= 1 && $num <= 6) {
            $stages['elementary']['grades'][] = $gl;
        } elseif ($num >= 7 && $num <= 10) {
            $stages['jhs']['grades'][] = $gl;
        } else {
            $stages['shs']['grades'][] = $gl;
        }
    } else {
        $stages['kindergarten']['grades'][] = $gl;
    }
}

// ---------------------------------------------------------------------------
// Selected grade level (view-only hub: no POST handlers)
// ---------------------------------------------------------------------------
$selectedGradeId = isset($_GET['grade_id']) ? (int)$_GET['grade_id'] : 0;

$selectedGrade = null;
if ($selectedGradeId > 0) {
    $stmt = $pdo->prepare('SELECT id, grade_level_name FROM tblgradelevel WHERE id = ? LIMIT 1');
    $stmt->execute([$selectedGradeId]);
    $selectedGrade = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$selectedGrade) {
        $selectedGradeId = 0;
    }
}

$selectedIsShs = false;
if ($selectedGrade && preg_match('/^Grade\s+1[12]$/i', $selectedGrade['grade_level_name'])) {
    $selectedIsShs = true;
}

// Subjects of the selected grade level — same query as the admin's Curriculum.php
$subjects = [];
if ($selectedGradeId > 0) {
    $stmt = $pdo->prepare('SELECT * FROM tblsubjects WHERE grade_level_id = ? AND is_active = 1 ORDER BY subject_code');
    $stmt->execute([$selectedGradeId]);
    $subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function saTypeBadge($type)
{
    $map = [
        'CORE'        => ['bg-secondary', 'Core'],
        'APPLIED'     => ['bg-info text-dark', 'Applied'],
        'SPECIALIZED' => ['bg-dark', 'Specialized'],
        'ELECTIVE'    => ['bg-warning text-dark', 'Elective'],
    ];
    return $map[$type] ?? $map['CORE'];
}
?>


<!doctype html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>STSN Grading System | Curriculum Templates</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <meta name="color-scheme" content="light dark" />
  <meta name="theme-color" content="#8B1A1A" media="(prefers-color-scheme: light)" />
  <meta name="theme-color" content="#8B1A1A" />
  <meta name="title" content="STSN | Curriculum Templates" />
  <meta name="author" content="G" />
  <meta name="description"
    content="STSN Grading System - A modern and accessible Bootstrap 5-based grading and student management platform for Schools. Secure, fast, and WCAG 2.1 AA compliant." />
  <meta name="keywords"
    content="STSN, STSN Grading System, school grading system, student information system, bootstrap 5 admin dashboard, grading dashboard, student records, class management, teacher tools, accessible admin panel" />
  <meta name="supported-color-schemes" content="light dark" />
  <link rel="preload" href="../css/adminlte.css" as="style" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
    integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
    onload="this.media='all'" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="../css/adminlte.css" />
  <link rel="stylesheet" href="../css/dark-mode.css" />
  <link rel="stylesheet" href="../css/admin-responsive.css" />
  <link rel="stylesheet" href="../css/system-alerts.css" />
  <link rel="stylesheet" href="../css/superadmin-theme.css" />

  <style>
    .sa-table thead th {
      font-size: 0.72rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--muted, #6C757D);
      font-weight: 700;
      white-space: nowrap;
    }
    .sa-table td {
      vertical-align: middle;
    }

    /* Grade level tree (left panel) */
    .sa-grade-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 0.5rem;
      padding: 0.55rem 0.9rem;
      border-radius: 8px;
      color: inherit;
      text-decoration: none;
      font-size: 0.9rem;
      font-weight: 500;
      transition: background 0.15s ease, color 0.15s ease;
    }
    .sa-grade-item:hover {
      background: rgba(139, 26, 26, 0.08);
      color: #8B1A1A;
    }
    .sa-grade-item.active {
      background: #8B1A1A;
      color: #fff;
    }
    .sa-stage-header {
      font-size: 0.78rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      font-weight: 700;
      color: #8B1A1A;
    }
    .sa-stage-header .accordion-button {
      background: transparent;
      color: inherit;
      font: inherit;
      padding: 0.6rem 0.75rem;
      box-shadow: none;
    }
    .sa-stage-header .accordion-button:not(.collapsed) {
      background: transparent;
      color: inherit;
    }
    .sa-stage-header .accordion-button::after {
      width: 0.9rem;
      height: 0.9rem;
      background-size: 0.9rem;
    }

    /* Dark mode support */
     [data-bs-theme="dark"] .sa-table thead th { color: #adb5bd; } 
 [data-bs-theme="dark"] .sa-stage-header { color: #e58a8a; } 
 [data-bs-theme="dark"] .sa-grade-item:hover { background: rgba(229, 138, 138, 0.12);
        color: #e58a8a; } 

  </style>

  <script src="../js/theme.js" defer></script>
</head>

<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">

  <div class="app-wrapper">
    <?php
    include_once '../includes/header.php';
    include_once '../includes/sAdmin_sidebar.php';
    ?>

    <main class="app-main">

      <div class="app-content-header">
      </div>
      <div class="app-content">
        <div class="container-fluid p-4">

          <!-- Page Header Banner -->
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3 p-4 text-white sa-page-header">
            <div class="d-flex align-items-center gap-3">
              <i class="bi bi-journals" style="font-size:1.5rem;"></i>
              <div>
                <h1 class="mb-0" style="font-size:1.5rem; font-weight:600;">Curriculum Templates</h1>
                <p class="mb-0" style="font-size:0.85rem; opacity:0.85;">Manage subjects per grade level and track</p>
              </div>
            </div>
          </div>

          <!-- Breadcrumb -->
          <?php renderBreadcrumb([
            ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'],
            ['label' => 'System Configuration', 'href' => '#', 'icon' => 'bi bi-gear'],
            ['label' => 'Curriculum Templates', 'icon' => 'bi bi-journals'],
          ]); ?>

          <!-- Info Banner -->
          <div class="alert alert-info d-flex align-items-start gap-2 small mb-3" role="alert">
            <i class="bi bi-info-circle mt-1"></i>
            <div>
              This is a view-only curriculum hub. Select a grade level from the left panel to see its subjects, or manage
              subject records in the <a href="Subjects.php" class="fw-semibold">Subject Master</a> page.
            </div>
          </div>

          <div class="row g-3">

            <!-- ===================== Left card: Grade Levels tree ===================== -->
            <div class="col-12 col-lg-4 col-xl-3">
              <div class="card h-100">
                <div class="card-header d-flex align-items-center gap-2">
                  <i class="bi bi-diagram-3"></i>
                  <strong>Grade Levels</strong>
                </div>
                <div class="card-body p-2">
                  <div class="accordion accordion-flush" id="gradeTreeAccordion">
                    <?php $stageIndex = 0; foreach ($stages as $stageKey => $stage): ?>
                      <?php if (empty($stage['grades'])) { continue; } ?>
                      <?php $stageIndex++; ?>
                      <div class="accordion-item">
                        <h2 class="accordion-header sa-stage-header" id="stageHeading<?= $stageIndex ?>">
                          <button class="accordion-button <?= $stageIndex > 1 ? 'collapsed' : '' ?>" type="button"
                            data-bs-toggle="collapse" data-bs-target="#stageCollapse<?= $stageIndex ?>"
                            aria-expanded="<?= $stageIndex > 1 ? 'false' : 'true' ?>"
                            aria-controls="stageCollapse<?= $stageIndex ?>">
                            <i class="bi <?= htmlspecialchars($stage['icon']) ?> me-2"></i>
                            <?= htmlspecialchars($stage['label']) ?>
                            <?php if ($stageKey === 'elementary'): ?>
                              <span class="badge bg-secondary ms-auto">Grades 1-6</span>
                            <?php elseif ($stageKey === 'jhs'): ?>
                              <span class="badge bg-secondary ms-auto">Grades 7-10</span>
                            <?php elseif ($stageKey === 'shs'): ?>
                              <span class="badge bg-secondary ms-auto">Grades 11-12</span>
                            <?php endif; ?>
                          </button>
                        </h2>
                        <div id="stageCollapse<?= $stageIndex ?>"
                          class="accordion-collapse collapse <?= $stageIndex === 1 ? 'show' : '' ?>"
                          aria-labelledby="stageHeading<?= $stageIndex ?>" data-bs-parent="#gradeTreeAccordion">
                          <div class="accordion-body p-2">
                            <?php foreach ($stage['grades'] as $gl): ?>
                              <a href="?grade_id=<?= (int)$gl['id'] ?>"
                                class="sa-grade-item <?= (int)$gl['id'] === $selectedGradeId ? 'active' : '' ?>">
                                <span><i class="bi bi-journal-text me-2"></i><?= htmlspecialchars($gl['grade_level_name']) ?></span>
                              </a>
                            <?php endforeach; ?>
                          </div>
                        </div>
                      </div>
                    <?php endforeach; ?>
                  </div>
                </div>
              </div>
            </div>

            <!-- ===================== Right card: Subjects per Grade Level ===================== -->
            <div class="col-12 col-lg-8 col-xl-9">
              <div class="card h-100">
                <div class="card-header d-flex align-items-center gap-2">
                  <i class="bi bi-book"></i>
                  <strong>
                    <?= $selectedGrade ? htmlspecialchars($selectedGrade['grade_level_name']) . ' — Subjects' : 'Select a grade level' ?>
                  </strong>
                  <?php if ($selectedGrade): ?>
                    <span class="badge bg-secondary ms-2"><?= count($subjects) ?> subject<?= count($subjects) === 1 ? '' : 's' ?></span>
                  <?php endif; ?>
                </div>
                <div class="card-body p-0">

                  <?php if (!$selectedGrade): ?>
                    <!-- No grade selected -->
                    <div class="text-center py-5 px-3">
                      <i class="bi bi-arrow-left-square" style="font-size:2.5rem; color:#8B1A1A;"></i>
                      <p class="mt-3 mb-1 fw-semibold">Choose a grade level from the left panel</p>
                      <p class="text-muted small mb-0">Click Kindergarten, Elementary, Junior High School or Senior High School to expand its grade levels.</p>
                    </div>
                  <?php elseif (empty($subjects)): ?>
                    <!-- Grade selected but no active subjects -->
                    <div class="text-center py-5 px-3">
                      <i class="bi bi-inbox" style="font-size:2.5rem; color:#8B1A1A;"></i>
                      <p class="mt-3 mb-1 fw-semibold">No active subjects found for <?= htmlspecialchars($selectedGrade['grade_level_name']) ?></p>
                      <p class="text-muted small mb-0">Add subjects for this grade level in the Subject Master page.</p>
                    </div>
                  <?php else: ?>
                    <div class="table-responsive">
                      <table class="table table-hover align-middle mb-0 sa-table">
                        <thead>
                          <tr>
                            <th style="width:56px;" class="text-center">#</th>
                            <th>Subject Code</th>
                            <th>Subject Name</th>
                            <th style="width:130px;">Type</th>
                            <th style="width:110px;" class="text-center">Status</th>
                            <th class="text-end" style="width:110px;">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php foreach ($subjects as $i => $subj): ?>
                            <?php $badge = saTypeBadge($subj['subject_type']); ?>
                            <tr>
                              <td class="text-center text-muted"><?= $i + 1 ?></td>
                              <td class="fw-semibold"><?= htmlspecialchars($subj['subject_code']) ?></td>
                              <td><?= htmlspecialchars($subj['subject_name']) ?></td>
                              <td>
                                <?php if ($selectedIsShs): ?>
                                  <span class="badge <?= htmlspecialchars($badge[0]) ?>"><?= htmlspecialchars($badge[1]) ?></span>
                                <?php else: ?>
                                  <span class="text-muted">&mdash;</span>
                                <?php endif; ?>
                              </td>
                              <td class="text-center">
                                <?php if ((int)$subj['is_active'] === 1): ?>
                                  <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                  <span class="badge bg-secondary">Inactive</span>
                                <?php endif; ?>
                              </td>
                              <td class="text-end">
                                <a href="Subjects.php?edit_id=<?= (int)$subj['id'] ?>" class="btn btn-outline-primary btn-sm">
                                  <i class="bi bi-pencil-square me-1"></i> Edit
                                </a>
                              </td>
                            </tr>
                          <?php endforeach; ?>
                        </tbody>
                      </table>
                    </div>
                  <?php endif; ?>

                </div>
              </div>
            </div>

          </div>

        </div>
      </div>

    </main>

    <?php
    include_once '../includes/footer.php';
    ?>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>

  <script src="../js/adminlte.js"></script>

  <script src="../js/system-alerts.js"></script>
  <script src="../js/superadmin-alerts.js"></script>

  <script>
    const SELECTOR_SIDEBAR_WRAPPER = '.sidebar-wrapper';
    const Default = {
      scrollbarTheme: 'os-theme-light',
      scrollbarAutoHide: 'leave',
      scrollbarClickScroll: true,
    };
    document.addEventListener('DOMContentLoaded', function () {
      const sidebarWrapper = document.querySelector(SELECTOR_SIDEBAR_WRAPPER);
      if (sidebarWrapper && OverlayScrollbarsGlobal?.OverlayScrollbars !== undefined) {
        OverlayScrollbarsGlobal.OverlayScrollbars(sidebarWrapper, {
          scrollbars: {
            theme: Default.scrollbarTheme,
            autoHide: Default.scrollbarAutoHide,
            clickScroll: Default.scrollbarClickScroll,
          },
        });
      }
    });
  </script>

</body>

</html>

