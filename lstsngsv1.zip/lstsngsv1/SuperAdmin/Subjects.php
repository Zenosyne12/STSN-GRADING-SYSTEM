<?php
session_start();

// Auth guard: must be logged in as Super Admin (role_id = 4)
if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 4) {
    header('Location: ../login.php');
    exit;
}

require_once '../api/shared/db_connect.php';
require_once __DIR__ . '/../includes/breadcrumb.php';

$trackOptions    = ['Academic', 'Tech-Pro'];
$semesterOptions = ['1st Semester', '2nd Semester'];
$typeOptions     = ['CORE', 'APPLIED', 'SPECIALIZED', 'ELECTIVE'];
$hoursOptions    = [80, 160, 320, 640];

$gradeLevels = $pdo->query('SELECT id, grade_level_name FROM tblgradelevel ORDER BY sort_order ASC')->fetchAll(PDO::FETCH_ASSOC);
$validGradeLevelIds = array_map('intval', array_column($gradeLevels, 'id'));

$clusterOptions = [];
$stmtClusters = $pdo->query("SELECT DISTINCT cluster FROM tblsubjects WHERE cluster IS NOT NULL AND cluster <> '' ORDER BY cluster ASC");
foreach ($stmtClusters as $row) {
    $clusterOptions[] = (string)$row['cluster'];
}

$fGrade   = (isset($_GET['grade_level_id']) && ctype_digit((string)$_GET['grade_level_id'])) ? (int)$_GET['grade_level_id'] : 0;
$fTrack   = in_array($_GET['track'] ?? '', $trackOptions, true) ? (string)$_GET['track'] : '';
$fCluster = in_array($_GET['cluster'] ?? '', $clusterOptions, true) ? (string)$_GET['cluster'] : '';
$fQ       = trim((string)($_GET['q'] ?? ''));
if (mb_strlen($fQ) > 100) {
    $fQ = mb_substr($fQ, 0, 100);
}

// Fixed page size: 25 per page (variables use a $subj prefix so that included
// files like sAdmin_sidebar.php can never overwrite them by accident)
$subjPerPage = 25;

function subjectsRedirect(): void
{
    global $fGrade, $fTrack, $fCluster, $fQ;
    $params = array_filter([
        'grade_level_id' => $fGrade > 0 ? $fGrade : null,
        'track'          => $fTrack !== '' ? $fTrack : null,
        'cluster'        => $fCluster !== '' ? $fCluster : null,
        'q'              => $fQ !== '' ? $fQ : null,
    ], static fn($v) => $v !== null);
    $qs = http_build_query($params);
    header('Location: Subjects.php' . ($qs !== '' ? '?' . $qs : ''));
    exit;
}

function subjectsSetFlash(string $message, string $type = 'success'): void
{
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type']    = $type;
}

function subjectsValidate(array $post, array $validGradeLevelIds, array $trackOptions, array $semesterOptions, array $typeOptions, array $hoursOptions, int $ignoreId = 0): array
{
    global $pdo;
    $code     = strtoupper(trim((string)($post['subject_code'] ?? '')));
    $name     = trim((string)($post['subject_name'] ?? ''));
    $gradeId  = (int)($post['grade_level_id'] ?? 0);
    $track    = trim((string)($post['track'] ?? ''));
    $cluster  = trim((string)($post['cluster'] ?? ''));
    $hoursRaw = trim((string)($post['hours'] ?? ''));
    $semester = trim((string)($post['semester'] ?? ''));
    $type     = strtoupper(trim((string)($post['subject_type'] ?? 'CORE')));
    $tesda    = trim((string)($post['tesda_nc_level'] ?? ''));
    $prereq   = trim((string)($post['prerequisites'] ?? ''));
    $isActive = isset($post['is_active']) ? 1 : 0;

    if ($code !== '' && mb_strlen($code) > 20) { return [false, 'Subject code must be at most 20 characters.']; }
    if ($name === '' || mb_strlen($name) > 100) { return [false, 'Subject name is required and must be at most 100 characters.']; }
    if (!in_array($gradeId, $validGradeLevelIds, true)) { return [false, 'Please select a valid grade level.']; }
    if ($track !== '' && !in_array($track, $trackOptions, true)) { return [false, 'Invalid track selected.']; }
    if (mb_strlen($cluster) > 100) { return [false, 'Cluster must be at most 100 characters.']; }
    $hours = $hoursRaw === '' ? 80 : (ctype_digit($hoursRaw) ? (int)$hoursRaw : 0);
    if (!in_array($hours, $hoursOptions, true)) { return [false, 'Hours must be one of 80, 160, 320, or 640.']; }
    if ($semester !== '' && !in_array($semester, $semesterOptions, true)) { return [false, 'Invalid semester selected.']; }
    if (!in_array($type, $typeOptions, true)) { return [false, 'Invalid subject type selected.']; }
    if (mb_strlen($tesda) > 20) { return [false, 'TESDA NC Level must be at most 20 characters.']; }
    if (mb_strlen($prereq) > 255) { return [false, 'Prerequisites must be at most 255 characters.']; }

    if ($code === '') {
        if ($ignoreId > 0) {
            $curStmt = $pdo->prepare('SELECT subject_code FROM tblsubjects WHERE id = ?');
            $curStmt->execute([$ignoreId]);
            $code = strtoupper((string)$curStmt->fetchColumn());
        }
        if ($code === '') {
            $letters = strtoupper((string)preg_replace('/[^A-Za-z]/', '', $name));
            $base    = substr($letters !== '' ? $letters : 'SUBJ', 0, 3) . $gradeId;
            $code    = $base;
            $dupStmt   = $pdo->prepare('SELECT COUNT(*) FROM tblsubjects WHERE grade_level_id = ? AND subject_code = ? AND strand <=> ?');
            $dupParams = [$gradeId, $code, $track !== '' ? $track : null];
            $suffix    = 1;
            while (true) {
                $dupStmt->execute($dupParams);
                if ((int)$dupStmt->fetchColumn() === 0) { break; }
                $suffix++;
                $dupParams[1] = $base . '-' . $suffix;
                $code         = $dupParams[1];
            }
        }
    }

    $sql    = 'SELECT COUNT(*) FROM tblsubjects WHERE grade_level_id = ? AND subject_code = ? AND strand <=> ?' . ($ignoreId > 0 ? ' AND id <> ?' : '');
    $params = $ignoreId > 0 ? [$gradeId, $code, $track !== '' ? $track : null, $ignoreId] : [$gradeId, $code, $track !== '' ? $track : null];
    $stmt   = $pdo->prepare($sql);
    $stmt->execute($params);
    if ((int)$stmt->fetchColumn() > 0) {
        return [false, 'Subject code "' . $code . '" already exists for this grade level and track.'];
    }

    return [true, [
        'subject_code'     => $code,
        'subject_name'     => $name,
        'grade_level_id'   => $gradeId,
        'strand'           => $track !== '' ? $track : null,
        'cluster'          => $cluster !== '' ? $cluster : null,
        'hours'            => $hours,
        'semester'         => $semester !== '' ? $semester : null,
        'subject_type'     => $type,
        'tesda_nc_level'   => $tesda !== '' ? $tesda : null,
        'prerequisites'    => $prereq !== '' ? $prereq : null,
        'is_active'        => $isActive,
    ]];
}

// ------------------------- POST handlers (PRG) -------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');

    try {
        if ($action === 'create') {
            [$ok, $result] = subjectsValidate($_POST, $validGradeLevelIds, $trackOptions, $semesterOptions, $typeOptions, $hoursOptions);
            if (!$ok) { subjectsSetFlash($result, 'danger'); subjectsRedirect(); }
            $d = $result;
            $nameDupStmt = $pdo->prepare(
              'SELECT COUNT(*) FROM tblsubjects
               WHERE grade_level_id = ? AND strand <=> ?
                   AND LOWER(TRIM(subject_name)) = LOWER(TRIM(?))'
            );
            $nameDupStmt->execute([$d['grade_level_id'], $d['strand'], $d['subject_name']]);
            if ((int) $nameDupStmt->fetchColumn() > 0) {
              subjectsSetFlash('A subject with this name already exists for this grade level and track.', 'danger');
              subjectsRedirect();
            }
            $stmt = $pdo->prepare('INSERT INTO tblsubjects (grade_level_id, strand, cluster, hours, semester, subject_code, subject_name, subject_type, tesda_nc_level, prerequisites, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->execute([
                $d['grade_level_id'], $d['strand'], $d['cluster'], $d['hours'], $d['semester'],
                $d['subject_code'], $d['subject_name'], $d['subject_type'],
                $d['tesda_nc_level'], $d['prerequisites'], $d['is_active'],
            ]);
            subjectsSetFlash('Subject "' . $d['subject_code'] . '" created successfully.', 'success');
            subjectsRedirect();
        }

        if ($action === 'update') {
            $id = (int)($_POST['id'] ?? 0);
            $existsStmt = $pdo->prepare('SELECT COUNT(*) FROM tblsubjects WHERE id = ?');
            $existsStmt->execute([$id]);
            if ($id <= 0 || (int)$existsStmt->fetchColumn() === 0) {
                subjectsSetFlash('Subject not found.', 'danger'); subjectsRedirect();
            }
            [$ok, $result] = subjectsValidate($_POST, $validGradeLevelIds, $trackOptions, $semesterOptions, $typeOptions, $hoursOptions, $id);
            if (!$ok) { subjectsSetFlash($result, 'danger'); subjectsRedirect(); }
            $d = $result;
            $stmt = $pdo->prepare('UPDATE tblsubjects SET grade_level_id = ?, strand = ?, cluster = ?, hours = ?, semester = ?, subject_code = ?, subject_name = ?, subject_type = ?, tesda_nc_level = ?, prerequisites = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
            $stmt->execute([
                $d['grade_level_id'], $d['strand'], $d['cluster'], $d['hours'], $d['semester'],
                $d['subject_code'], $d['subject_name'], $d['subject_type'],
                $d['tesda_nc_level'], $d['prerequisites'], $d['is_active'], $id,
            ]);
            subjectsSetFlash('Subject "' . $d['subject_code'] . '" updated successfully.', 'success');
            subjectsRedirect();
        }

        if ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            $stmt = $pdo->prepare('UPDATE tblsubjects SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
            $stmt->execute([$id]);
            subjectsSetFlash($stmt->rowCount() > 0 ? 'Subject deleted (deactivated).' : 'Subject not found.', $stmt->rowCount() > 0 ? 'success' : 'danger');
            subjectsRedirect();
        }

        if ($action === 'toggle') {
            $id = (int)($_POST['id'] ?? 0);
            $stmt = $pdo->prepare('UPDATE tblsubjects SET is_active = 1 - is_active, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
            $stmt->execute([$id]);
            subjectsSetFlash($stmt->rowCount() > 0 ? 'Subject status updated.' : 'Subject not found.', $stmt->rowCount() > 0 ? 'success' : 'danger');
            subjectsRedirect();
        }

        subjectsSetFlash('Unknown action.', 'danger');
        subjectsRedirect();
    } catch (PDOException $e) {
        error_log('Subjects.php POST error: ' . $e->getMessage());
        subjectsSetFlash('Database error: the operation could not be completed.', 'danger');
        subjectsRedirect();
    }
}

$flashMessage = (string)($_SESSION['flash_message'] ?? '');
$flashType    = (string)($_SESSION['flash_type'] ?? 'success');
unset($_SESSION['flash_message'], $_SESSION['flash_type']);

// ------------------------- Fetch subjects -------------------------
$where  = [];
$params = [];
if ($fGrade > 0) { $where[] = 's.grade_level_id = ?'; $params[] = $fGrade; }
if ($fTrack !== '') { $where[] = 's.strand = ?'; $params[] = $fTrack; }
if ($fCluster !== '') { $where[] = 's.cluster = ?'; $params[] = $fCluster; }
if ($fQ !== '') {
    $where[] = '(s.subject_code LIKE ? OR s.subject_name LIKE ?)';
    $params[] = '%' . $fQ . '%';
    $params[] = '%' . $fQ . '%';
}
$whereSql = $where !== [] ? ' WHERE ' . implode(' AND ', $where) : '';

$sql = 'SELECT s.*, g.grade_level_name
        FROM tblsubjects s
        LEFT JOIN tblgradelevel g ON g.id = s.grade_level_id'
        . $whereSql .
        ' ORDER BY s.grade_level_id ASC, s.subject_name ASC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ------------------------- Pagination (fixed 25 per page, always visible) -------------------------
// NOTE: pagination variables are $subj-prefixed. They are computed BEFORE the
// header/sidebar includes, which previously overwrote the page's $currentPage
// with a string and caused a fatal TypeError at the pagination footer.
$totalSubjects  = count($subjects);
$subjTotalPages = max(1, (int)ceil($totalSubjects / $subjPerPage));
$subjPage       = max(1, min($subjTotalPages, (int)($_GET['page'] ?? 1)));
$subjOffset     = ($subjPage - 1) * $subjPerPage;
$subjPageRows   = array_slice($subjects, $subjOffset, $subjPerPage);
$subjStartNum   = $totalSubjects > 0 ? $subjOffset + 1 : 0;
$subjEndNum     = min($subjOffset + $subjPerPage, $totalSubjects);

function subjectPageUrl(int $page): string
{
    global $fGrade, $fTrack, $fCluster, $fQ;
    $params = array_filter([
        'grade_level_id' => $fGrade > 0 ? $fGrade : null,
        'track'          => $fTrack !== '' ? $fTrack : null,
        'cluster'        => $fCluster !== '' ? $fCluster : null,
        'q'              => $fQ !== '' ? $fQ : null,
        'page'           => $page > 1 ? $page : null,
    ], static fn($v) => $v !== null);
    $qs = http_build_query($params);
    return 'Subjects.php' . ($qs !== '' ? '?' . $qs : '');
}

$subjPagesList = [];
if ($subjTotalPages <= 7) {
    $subjPagesList = range(1, $subjTotalPages);
} else {
    $subjPagesList[] = 1;
    if ($subjPage > 4) { $subjPagesList[] = '...'; }
    for ($i = max(2, $subjPage - 1); $i <= min($subjTotalPages - 1, $subjPage + 1); $i++) {
        $subjPagesList[] = $i;
    }
    if ($subjPage < $subjTotalPages - 3) { $subjPagesList[] = '...'; }
    $subjPagesList[] = $subjTotalPages;
}

// Keep current filters/page when the add/edit form is submitted
$currentQuery = (string)($_SERVER['QUERY_STRING'] ?? '');
$formAction   = 'Subjects.php' . ($currentQuery !== '' ? '?' . $currentQuery : '');

$gradeLevelNameMap = [];
foreach ($gradeLevels as $gl) {
    $gradeLevelNameMap[(int)$gl['id']] = $gl['grade_level_name'];
}

$typeBadgeClasses = [
    'CORE'        => 'bg-primary-subtle text-primary-emphasis',
    'APPLIED'     => 'bg-info-subtle text-info-emphasis',
    'SPECIALIZED' => 'bg-warning-subtle text-warning-emphasis',
    'ELECTIVE'    => 'bg-secondary-subtle text-secondary-emphasis',
];

$trackBadgeClasses = [
    'Academic' => 'bg-primary-subtle text-primary-emphasis',
    'Tech-Pro' => 'bg-info-subtle text-info-emphasis',
];
?>
<!doctype html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>STSN Grading System | Subject Master</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <meta name="color-scheme" content="light dark" />
  <meta name="theme-color" content="#8B1A1A" media="(prefers-color-scheme: light)" />
  <meta name="theme-color" content="#8B1A1A" />
  <meta name="title" content="STSN | Subject Master" />
  <meta name="author" content="G" />
  <meta name="supported-color-schemes" content="light dark" />
  <link rel="preload" href="../css/adminlte.css" as="style" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
    integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
    onload="this.media='all'" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
    crossorigin="anonymous" />

  <link rel="icon" href="data:," />
  <link rel="stylesheet" href="../css/adminlte.css" />
  <link rel="stylesheet" href="../css/system-alerts.css" />
  <link rel="stylesheet" href="../css/superadmin-theme.css" />

  <style>
    /* (Removed) bespoke confirm-modal styles — all SuperAdmin pages now use the
       shared ay-confirm dialog injected by js/superadmin-alerts.js */

    /* ============================================================
       Pagination — always visible, maroon
       ============================================================ */
    .subject-pagination-footer {
      display: flex !important;
      justify-content: space-between !important;
      align-items: center !important;
      gap: 1rem !important;
      flex-wrap: nowrap !important;
      padding: 1rem 1.25rem !important;
      border-top: 1px solid #E9ECEF !important;
      background: #FAFBFC !important;
      visibility: visible !important;
      opacity: 1 !important;
      height: auto !important;
    }
    .subject-pagination-info {
      font-size: 0.85rem;
      color: #6C757D;
      white-space: nowrap !important;
    }
    .subject-pagination-controls {
      display: flex !important;
      gap: 0.35rem !important;
      align-items: center !important;
      flex-wrap: wrap;
      visibility: visible !important;
    }
    .subject-page-btn {
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
      min-width: 38px !important;
      height: 38px !important;
      padding: 0 0.85rem !important;
      border: 1.5px solid #F5BCBC !important;
      background: #FFFFFF !important;
      color: #8B1A1A !important;
      font-weight: 600 !important;
      font-size: 0.85rem !important;
      border-radius: 8px !important;
      text-decoration: none !important;
      transition: all 0.15s ease !important;
      gap: 4px !important;
      line-height: 1 !important;
      visibility: visible !important;
    }
    .subject-page-btn:hover:not(.active):not(.disabled) {
      background: #FDF2F2 !important;
      border-color: #8B1A1A !important;
      transform: translateY(-1px);
      box-shadow: 0 3px 8px rgba(139, 26, 26, 0.15);
    }
    .subject-page-btn.active {
      background: #8B1A1A !important;
      border-color: #8B1A1A !important;
      color: #FFFFFF !important;
      box-shadow: 0 3px 10px rgba(139, 26, 26, 0.3);
      pointer-events: none;
    }
    .subject-page-btn.disabled {
      background: #F8F9FA !important;
      border-color: #E9ECEF !important;
      color: #C8CFD8 !important;
      cursor: not-allowed;
      pointer-events: none;
    }
    .subject-page-ellipsis {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 38px;
      height: 38px;
      color: #8B1A1A;
      font-weight: 700;
    }

    /* Dark mode */
    [data-bs-theme="dark"] .sa-confirm-box { background: #2D2D2D; }
    [data-bs-theme="dark"] .sa-confirm-body { color: #E4E6E8; }
    [data-bs-theme="dark"] .sa-confirm-footer { background: #262626; border-top-color: #3A3A3A; }
    [data-bs-theme="dark"] .sa-btn-cancel { background: #3A3A3A; color: #ADB5BD; border-color: #4A4A4A; }
    [data-bs-theme="dark"] .sa-btn-cancel:hover { background: #4A4A4A; color: #FFFFFF; }
    [data-bs-theme="dark"] .subject-pagination-footer { background: #262626 !important; border-top-color: #3A3A3A !important; }
    [data-bs-theme="dark"] .subject-pagination-info { color: #ADB5BD; }
    [data-bs-theme="dark"] .subject-page-btn { background: #2D2D2D !important; border-color: #5C2D35 !important; color: #FFA8A8 !important; }
    [data-bs-theme="dark"] .subject-page-btn:hover:not(.active):not(.disabled) { background: #3A2A2A !important; border-color: #8B1A1A !important; }
    [data-bs-theme="dark"] .subject-page-btn.active { background: #8B1A1A !important; border-color: #8B1A1A !important; color: #FFFFFF !important; }
    [data-bs-theme="dark"] .subject-page-btn.disabled { background: #262626 !important; border-color: #3A3A3A !important; color: #6C757D !important; }
  </style>
</head>

<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">

  <div class="app-wrapper">
    <?php
    include_once '../includes/header.php';
    include_once '../includes/sAdmin_sidebar.php';
    ?>

    <main class="app-main">

      <div class="app-content-header"></div>
      <div class="app-content">
        <div class="container-fluid p-4">

          <!-- Page Header Banner -->
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3 p-4 text-white sa-page-header">
            <div class="d-flex align-items-center gap-3">
              <i class="bi bi-book" style="font-size:1.5rem;"></i>
              <div>
                <h1 class="mb-0" style="font-size:1.5rem; font-weight:600;">Subject Master</h1>
                <p class="mb-0" style="font-size:0.85rem; opacity:0.85;">Manage subjects per grade level</p>
              </div>
            </div>
          </div>

          <!-- Breadcrumb -->
          <?php renderBreadcrumb([
            ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'],
            ['label' => 'System Configuration', 'href' => '#', 'icon' => 'bi bi-sliders'],
            ['label' => 'Subject Master', 'icon' => 'bi bi-book'],
          ]); ?>

          <?php if ($flashMessage !== ''): ?>
            <div data-sa-flash="<?= htmlspecialchars($flashType) ?>"
                 data-sa-flash-message="<?= htmlspecialchars($flashMessage) ?>"
                 style="display:none"></div>
          <?php endif; ?>

          <!-- Filter Row -->
          <div class="card mb-3">
            <div class="card-body p-3">
              <form method="get" action="Subjects.php" id="filterForm">
                <div class="row g-2 align-items-end">
                  <div class="col-md-3">
                    <label class="form-label text-muted mb-1" for="filterGrade">Grade Level</label>
                    <select class="form-select" id="filterGrade" name="grade_level_id" data-autosubmit>
                      <option value="">All Grade Levels</option>
                      <?php foreach ($gradeLevels as $gl): ?>
                        <option value="<?= (int)$gl['id'] ?>" <?= $fGrade === (int)$gl['id'] ? 'selected' : '' ?>>
                          <?= htmlspecialchars($gl['grade_level_name']) ?>
                        </option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                  <div class="col-md-2">
                    <label class="form-label text-muted mb-1" for="filterTrack">Track</label>
                    <select class="form-select" id="filterTrack" name="track" data-autosubmit>
                      <option value="">All Tracks</option>
                      <?php foreach ($trackOptions as $trackOption): ?>
                        <option value="<?= htmlspecialchars($trackOption) ?>" <?= $fTrack === $trackOption ? 'selected' : '' ?>>
                          <?= htmlspecialchars($trackOption) ?>
                        </option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                  <div class="col-md-2">
                    <label class="form-label text-muted mb-1" for="filterCluster">Cluster</label>
                    <select class="form-select" id="filterCluster" name="cluster" data-autosubmit>
                      <option value="">All Clusters</option>
                      <?php foreach ($clusterOptions as $clusterOption): ?>
                        <option value="<?= htmlspecialchars($clusterOption) ?>" <?= $fCluster === $clusterOption ? 'selected' : '' ?>>
                          <?= htmlspecialchars($clusterOption) ?>
                        </option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                  <div class="col-md-3">
                    <label class="form-label text-muted mb-1" for="filterSearch">Search</label>
                    <input type="text" class="form-control" id="filterSearch" name="q" placeholder="Subject name..."
                           value="<?= htmlspecialchars($fQ) ?>" maxlength="100" autocomplete="off">
                  </div>
                  <div class="col-md-2 d-grid">
                    <button type="button" class="btn btn-primary py-2" id="addSubjectBtn" onclick="openAddSubject()">
                      <i class="bi bi-plus-lg me-1"></i> Add Subject
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>

          <!-- Main Card: Subject List -->
          <div class="card">
            <div class="card-header d-flex align-items-center justify-content-between">
              <div class="d-flex align-items-center gap-2">
                <i class="bi bi-list-ul"></i>
                <strong>Subject List</strong>
              </div>
              <span class="badge bg-primary-subtle text-primary-emphasis"><?= $totalSubjects ?> subjects</span>
            </div>

            <div class="card-body p-0">
              <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                  <thead>
                    <tr>
                      <th>Subject Name</th>
                      <th>Grade Level</th>
                      <th>Track</th>
                      <th>Cluster</th>
                      <th>Hours</th>
                      <th>Semester</th>
                      <th>Type</th>
                      <th>Status</th>
                      <th class="text-end">Actions</th>
                    </tr>
                  </thead>
                  <tbody>

                    <?php if ($subjects === []): ?>
                      <tr>
                        <td colspan="9" class="text-center py-5">
                          <i class="bi bi-inbox text-muted mb-2 d-block" style="font-size:3rem;"></i>
                          <div class="text-body">No subjects found</div>
                          <div class="text-muted" style="font-size:0.85rem;">Try adjusting the filters or add a new subject.</div>
                        </td>
                      </tr>
                    <?php else: ?>
                      <?php foreach ($subjPageRows as $subject): ?>
                        <?php
                        $subjectId     = (int)$subject['id'];
                        $subjectCode   = (string)$subject['subject_code'];
                        $subjectName   = (string)$subject['subject_name'];
                        $subjectTrack  = (string)($subject['strand'] ?? '');
                        $subjectClus   = (string)($subject['cluster'] ?? '');
                        $subjectHours  = $subject['hours'] !== null ? (int)$subject['hours'] : 0;
                        $subjectSem    = (string)($subject['semester'] ?? '');
                        $subjectType   = (string)$subject['subject_type'];
                        $subjectActive = (int)$subject['is_active'] === 1;
                        $gradeName     = (string)($subject['grade_level_name'] ?? ($gradeLevelNameMap[(int)$subject['grade_level_id']] ?? 'N/A'));
                        $clusterDisplay = $subjectClus !== ''
                          ? htmlspecialchars(mb_strlen($subjectClus) > 30 ? mb_substr($subjectClus, 0, 30) : $subjectClus) . (mb_strlen($subjectClus) > 30 ? '&hellip;' : '')
                          : '';
                        ?>
                        <tr>
                          <td class="text-body"><?= htmlspecialchars($subjectName) ?></td>
                          <td><span class="badge bg-secondary-subtle text-secondary-emphasis"><?= htmlspecialchars($gradeName) ?></span></td>
                          <td>
                            <?php if ($subjectTrack !== ''): ?>
                              <span class="badge <?= $trackBadgeClasses[$subjectTrack] ?? 'bg-primary-subtle text-primary-emphasis' ?>"><?= htmlspecialchars($subjectTrack) ?></span>
                            <?php else: ?>
                              <span class="text-muted">&mdash;</span>
                            <?php endif; ?>
                          </td>
                          <td>
                            <?php if ($clusterDisplay !== ''): ?>
                              <span class="text-body" title="<?= htmlspecialchars($subjectClus) ?>"><?= $clusterDisplay ?></span>
                            <?php else: ?>
                              <span class="text-muted">&mdash;</span>
                            <?php endif; ?>
                          </td>
                          <td>
                            <?php if ($subjectHours > 0): ?>
                              <span class="badge bg-warning-subtle text-warning-emphasis"><?= $subjectHours ?> hrs</span>
                            <?php else: ?>
                              <span class="text-muted">&mdash;</span>
                            <?php endif; ?>
                          </td>
                          <td>
                            <?php if ($subjectSem !== ''): ?>
                              <span class="badge bg-info-subtle text-info-emphasis"><?= htmlspecialchars($subjectSem) ?></span>
                            <?php else: ?>
                              <span class="text-muted">&mdash;</span>
                            <?php endif; ?>
                          </td>
                          <td>
                            <span class="badge <?= $typeBadgeClasses[$subjectType] ?? 'bg-secondary-subtle text-secondary-emphasis' ?>">
                              <?= htmlspecialchars($subjectType) ?>
                            </span>
                          </td>
                          <td>
                            <?php if ($subjectActive): ?>
                              <span class="badge bg-success-subtle text-success-emphasis">Active</span>
                            <?php else: ?>
                              <span class="badge bg-secondary-subtle text-secondary-emphasis">Inactive</span>
                            <?php endif; ?>
                          </td>
                          <td class="text-end text-nowrap">
                            <div class="d-flex justify-content-end gap-1">
                              <button type="button" class="btn btn-outline-primary btn-sm edit-subject-btn" title="Edit"
                                      onclick="openEditSubject(this)"
                                      data-id="<?= $subjectId ?>"
                                      data-code="<?= htmlspecialchars($subjectCode) ?>"
                                      data-name="<?= htmlspecialchars($subjectName) ?>"
                                      data-grade="<?= (int)$subject['grade_level_id'] ?>"
                                      data-track="<?= htmlspecialchars($subjectTrack) ?>"
                                      data-cluster="<?= htmlspecialchars($subjectClus) ?>"
                                      data-hours="<?= $subjectHours > 0 ? $subjectHours : 80 ?>"
                                      data-semester="<?= htmlspecialchars($subjectSem) ?>"
                                      data-tesda="<?= htmlspecialchars((string)($subject['tesda_nc_level'] ?? '')) ?>"
                                      data-prereq="<?= htmlspecialchars((string)($subject['prerequisites'] ?? '')) ?>"
                                      data-type="<?= htmlspecialchars($subjectType) ?>"
                                      data-active="<?= $subjectActive ? '1' : '0' ?>">
                                <i class="bi bi-pencil-square"></i>
                              </button>
                              <button type="button" class="btn btn-outline-warning btn-sm"
                                      title="<?= $subjectActive ? 'Deactivate' : 'Activate' ?>"
                                      onclick="confirmToggleSubject(this)"
                                      data-id="<?= $subjectId ?>"
                                      data-name="<?= htmlspecialchars($subjectName) ?>"
                                      data-active="<?= $subjectActive ? '1' : '0' ?>">
                                <i class="bi bi-arrow-repeat"></i>
                              </button>
                              <button type="button" class="btn btn-outline-danger btn-sm" title="Delete"
                                      onclick="confirmDeleteSubject(this)"
                                      data-id="<?= $subjectId ?>"
                                      data-name="<?= htmlspecialchars($subjectName) ?>">
                                <i class="bi bi-trash"></i>
                              </button>
                            </div>
                          </td>
                        </tr>
                      <?php endforeach; ?>
                    <?php endif; ?>

                  </tbody>
                </table>
              </div>
            </div><!-- /.card-body -->

            <!-- Pagination footer (always visible) -->
            <div class="card-footer subject-pagination-footer">
              <div class="subject-pagination-info">
                <?= $totalSubjects === 0
                  ? 'No subjects found.'
                  : 'Showing ' . $subjStartNum . '&ndash;' . $subjEndNum . ' of ' . $totalSubjects . ' subjects &middot; 25 per page' ?>
              </div>
              <div class="subject-pagination-controls">
                <a class="subject-page-btn <?= $subjPage === 1 ? 'disabled' : '' ?>"
                   href="<?= htmlspecialchars(subjectPageUrl(max(1, $subjPage - 1))) ?>">
                  <i class="bi bi-chevron-left"></i> Previous
                </a>
                <?php foreach ($subjPagesList as $p): ?>
                  <?php if ($p === '...'): ?>
                    <span class="subject-page-ellipsis">&hellip;</span>
                  <?php else: ?>
                    <a class="subject-page-btn <?= $p === $subjPage ? 'active' : '' ?>"
                       href="<?= htmlspecialchars(subjectPageUrl((int)$p)) ?>"><?= (int)$p ?></a>
                  <?php endif; ?>
                <?php endforeach; ?>
                <a class="subject-page-btn <?= $subjPage === $subjTotalPages ? 'disabled' : '' ?>"
                   href="<?= htmlspecialchars(subjectPageUrl(min($subjTotalPages, $subjPage + 1))) ?>">
                  Next <i class="bi bi-chevron-right"></i>
                </a>
              </div>
            </div><!-- /.subject-pagination-footer -->

          </div><!-- /.card -->

        </div>
      </div>

    </main>

    <?php include_once '../includes/footer.php'; ?>
  </div>

  <!-- Add/Edit Subject Modal (kept at body level so it is never trapped under the backdrop) -->
  <div class="modal fade" id="subjectModal" tabindex="-1" aria-labelledby="subjectModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
      <div class="modal-content">
        <form method="post" action="<?= htmlspecialchars($formAction) ?>" id="subjectForm" autocomplete="off">
          <div class="modal-header">
            <h5 class="modal-title" id="subjectModalLabel">Add Subject</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <input type="hidden" name="action" id="subjectAction" value="create">
            <input type="hidden" name="id" id="subjectId" value="">
            <div class="row g-3">
              <div class="col-md-12">
                <label class="form-label" for="subjectName">Subject Name <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="subjectName" name="subject_name"
                       maxlength="100" required placeholder="e.g. Filipino">
              </div>
              <div class="col-md-4">
                <label class="form-label" for="subjectGrade">Grade Level <span class="text-danger">*</span></label>
                <select class="form-select" id="subjectGrade" name="grade_level_id" required>
                  <option value="">-- Select Grade Level --</option>
                  <?php foreach ($gradeLevels as $gl): ?>
                    <option value="<?= (int)$gl['id'] ?>"><?= htmlspecialchars($gl['grade_level_name']) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-4">
                <label class="form-label" for="subjectTrack">Track</label>
                <select class="form-select" id="subjectTrack" name="track">
                  <option value="">-- None --</option>
                  <?php foreach ($trackOptions as $trackOption): ?>
                    <option value="<?= htmlspecialchars($trackOption) ?>"><?= htmlspecialchars($trackOption) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-4">
                <label class="form-label" for="subjectSemester">Semester</label>
                <select class="form-select" id="subjectSemester" name="semester">
                  <option value="">-- None --</option>
                  <?php foreach ($semesterOptions as $semesterOption): ?>
                    <option value="<?= htmlspecialchars($semesterOption) ?>"><?= htmlspecialchars($semesterOption) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-12">
                <label class="form-label" for="subjectCluster">Cluster</label>
                <input type="text" class="form-control" id="subjectCluster" name="cluster"
                       maxlength="100" placeholder="e.g. Science, Technology, Engineering and Mathematics">
              </div>
              <div class="col-md-3">
                <label class="form-label" for="subjectHours">Hours</label>
                <input type="number" class="form-control" id="subjectHours" name="hours"
                       min="80" max="640" value="80">
                <div class="form-text text-muted">80 / 160 / 320 / 640</div>
              </div>
              <div class="col-md-3">
                <label class="form-label" for="subjectTesda">TESDA NC Level</label>
                <input type="text" class="form-control" id="subjectTesda" name="tesda_nc_level"
                       maxlength="20" placeholder="e.g. NC II">
              </div>
              <div class="col-md-6">
                <label class="form-label" for="subjectPrereq">Prerequisites</label>
                <input type="text" class="form-control" id="subjectPrereq" name="prerequisites"
                       maxlength="255">
              </div>
              <div class="col-md-6">
                <label class="form-label" for="subjectType">Subject Type</label>
                <select class="form-select" id="subjectType" name="subject_type">
                  <?php foreach ($typeOptions as $typeOption): ?>
                    <option value="<?= htmlspecialchars($typeOption) ?>"><?= htmlspecialchars(ucwords(strtolower($typeOption))) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-6 d-flex align-items-end">
                <div class="form-check form-switch">
                  <input class="form-check-input" type="checkbox" role="switch" id="subjectActive" name="is_active" value="1" checked>
                  <label class="form-check-label" for="subjectActive">Active</label>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-check-lg me-1"></i> Save
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- (Removed) bespoke confirm modal — confirm dialogs now come from js/superadmin-alerts.js -->

  <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>

  <script src="../js/adminlte.js"></script>

  <script src="../js/system-alerts.js"></script>
  <script src="../js/superadmin-alerts.js"></script>

  <script>
    /* ============================================================
       GLOBAL functions (called from inline onclick="" handlers)
       ============================================================ */
    var subjectEditSource = null;      // button currently being edited (null when adding)

    function getSubjectModal() {
      return bootstrap.Modal.getOrCreateInstance(document.getElementById('subjectModal'));
    }

    function fillSubjectForm(btn) {
      document.getElementById('subjectAction').value   = 'update';
      document.getElementById('subjectId').value       = btn.getAttribute('data-id') || '';
      document.getElementById('subjectName').value     = btn.getAttribute('data-name') || '';
      document.getElementById('subjectGrade').value    = btn.getAttribute('data-grade') || '';
      document.getElementById('subjectTrack').value    = btn.getAttribute('data-track') || '';
      document.getElementById('subjectCluster').value  = btn.getAttribute('data-cluster') || '';
      document.getElementById('subjectHours').value    = btn.getAttribute('data-hours') || '80';
      document.getElementById('subjectSemester').value = btn.getAttribute('data-semester') || '';
      document.getElementById('subjectTesda').value    = btn.getAttribute('data-tesda') || '';
      document.getElementById('subjectPrereq').value   = btn.getAttribute('data-prereq') || '';
      document.getElementById('subjectType').value     = btn.getAttribute('data-type') || 'CORE';
      document.getElementById('subjectActive').checked = btn.getAttribute('data-active') === '1';
      document.getElementById('subjectModalLabel').textContent = 'Edit Subject';
    }

    function openAddSubject() {
      subjectEditSource = null;
      document.getElementById('subjectForm').reset();
      document.getElementById('subjectAction').value = 'create';
      document.getElementById('subjectId').value = '';
      document.getElementById('subjectHours').value = '80';
      document.getElementById('subjectActive').checked = true;
      document.getElementById('subjectModalLabel').textContent = 'Add Subject';
      getSubjectModal().show();
    }

    function openEditSubject(btn) {
      subjectEditSource = btn;
      fillSubjectForm(btn);
      getSubjectModal().show();
    }

    /* ---- Confirmations (toggle + delete) — shared ay-confirm dialog ---- */
    function submitSubjectAction(action, id) {
      var form = document.createElement('form');
      form.method = 'POST';
      form.action = window.location.href;   // keeps current filters
      form.style.display = 'none';

      var a = document.createElement('input');
      a.type = 'hidden'; a.name = 'action'; a.value = action;
      var i = document.createElement('input');
      i.type = 'hidden'; i.name = 'id'; i.value = id;
      form.appendChild(a);
      form.appendChild(i);
      document.body.appendChild(form);
      form.submit();
    }

    function confirmToggleSubject(btn) {
      var isActive = btn.getAttribute('data-active') === '1';
      var verb = isActive ? 'Deactivate' : 'Activate';
      var name = btn.getAttribute('data-name') || '';
      window.saConfirm('Are you sure you want to ' + verb.toLowerCase() + ' the subject "' + name + '"?', {
        title: verb + ' Subject'
      }).then(function (ok) {
        if (ok) { submitSubjectAction('toggle', btn.getAttribute('data-id')); }
      });
    }

    function confirmDeleteSubject(btn) {
      var name = btn.getAttribute('data-name') || '';
      window.saConfirm('Are you sure you want to delete the subject "' + name + '"? It will be deactivated.', {
        title: 'Delete Subject',
        variant: 'danger'
      }).then(function (ok) {
        if (ok) { submitSubjectAction('delete', btn.getAttribute('data-id')); }
      });
    }

    /* ============================================================
       Page init
       ============================================================ */
    document.addEventListener('DOMContentLoaded', function () {
      // Auto-dismiss bootstrap alerts (if any)
      document.querySelectorAll('.alert-dismissible').forEach(function (alertEl) {
        setTimeout(function () {
          if (window.bootstrap && bootstrap.Alert) {
            bootstrap.Alert.getOrCreateInstance(alertEl).close();
          }
        }, 4000);
      });

      // Filters: auto-submit on change, Enter to search
      document.querySelectorAll('#filterForm [data-autosubmit]').forEach(function (el) {
        el.addEventListener('change', function () {
          document.getElementById('filterForm').submit();
        });
      });

      var searchInput = document.getElementById('filterSearch');
      if (searchInput) {
        searchInput.addEventListener('keydown', function (e) {
          if (e.key === 'Enter') {
            e.preventDefault();
            document.getElementById('filterForm').submit();
          }
        });
      }

      // Safety net: re-apply edit values once the modal is fully shown,
      // in case any shared script resets the form during "show".
      var subjectModalEl = document.getElementById('subjectModal');
      if (subjectModalEl) {
        subjectModalEl.addEventListener('shown.bs.modal', function () {
          if (subjectEditSource) { fillSubjectForm(subjectEditSource); }
        });
        subjectModalEl.addEventListener('hidden.bs.modal', function () {
          subjectEditSource = null;
        });
      }

      // (Confirm-dialog Escape handling is built into js/superadmin-alerts.js)
    });
  </script>

</body>

</html>
