<?php
/**
 * Workflow-Configuration.php  (Super Admin)
 * PHASE B — per-school-year workflow builder.
 *
 * Each academic year owns exactly one workflow template. Every step can be
 * configured with: a label, a required position, an "allow mark checked"
 * toggle and a "can reject" toggle. A brand-new year can copy the previous
 * year's setup or start from the default 5-step chain.
 */
require_once __DIR__ . '/../includes/auth.php';
requireSuperAdmin();
require_once __DIR__ . '/../api/shared/db_connect.php';
require_once __DIR__ . '/../includes/breadcrumb.php';

$positionOptions = ['Teacher', 'Adviser', 'Subject Coordinator', 'Principal', 'Registrar'];

/* ---------------- Academic years (selector) ---------------- */
$years = [];
try {
    $years = $pdo->query(
        'SELECT id, year_label, is_active
           FROM tblacademicyear
          ORDER BY is_active DESC, year_label DESC'
    )->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    $years = [];
}

$selectedYearId = (int)($_GET['year_id'] ?? 0);
if ($selectedYearId <= 0 && $years) {
    $selectedYearId = (int)$years[0]['id'];
}

$selectedYear = null;
foreach ($years as $y) {
    if ((int)$y['id'] === $selectedYearId) { $selectedYear = $y; break; }
}

/* ---------------- Template + steps for the selected year ---------------- */
$template  = null;
$steps     = [];
$loadError = '';
if ($selectedYear) {
    try {
        $tStmt = $pdo->prepare(
            'SELECT * FROM tblworkflow_template
              WHERE academic_year_id = ?
              ORDER BY is_active DESC, id ASC
              LIMIT 1'
        );
        $tStmt->execute([$selectedYearId]);
        $template = $tStmt->fetch(PDO::FETCH_ASSOC) ?: null;

        if ($template) {
            $sStmt = $pdo->prepare(
                'SELECT * FROM tblworkflow_step WHERE template_id = ? ORDER BY step_order ASC'
            );
            $sStmt->execute([(int)$template['id']]);
            $steps = $sStmt->fetchAll(PDO::FETCH_ASSOC);
        }
    } catch (Throwable $e) {
        $template  = null;
        $steps     = [];
        $loadError = 'Workflow tables are not ready. Run sql/migration_workflow_per_year.sql first.';
    }
}

/* ---------------- Seed handed to the JS builder ---------------- */
$stepsSeed = [];
foreach ($steps as $s) {
    $stepsSeed[] = [
        'step_id'            => (int)$s['id'],
        'step_label'         => (string)$s['step_label'],
        'required_position'  => (string)$s['required_position'],
        'allow_mark_checked' => (int)($s['allow_mark_checked'] ?? 0),
        'can_reject'         => (int)($s['can_reject'] ?? 1),
    ];
}

/* ---------------- Flash (PRG) ---------------- */
$flashMap = [
    'saved'   => ['Workflow saved successfully.', 'success'],
    'created' => ['Workflow template created successfully.', 'success'],
    'error'   => ['Something went wrong. Please try again.', 'danger'],
];
$msgKey = (string)($_GET['msg'] ?? '');
$flashMessage = '';
$flashType    = 'success';
if ($msgKey !== '' && isset($flashMap[$msgKey])) {
    [$flashMessage, $flashType] = $flashMap[$msgKey];
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>STSN Grading System | Workflow Configuration</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <meta name="color-scheme" content="light dark" />
  <meta name="theme-color" content="#8B1A1A" media="(prefers-color-scheme: light)" />
  <meta name="theme-color" content="#8B1A1A" />
  <link rel="preload" href="../css/adminlte.css" as="style" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css" integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print" onload="this.media='all'" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css" crossorigin="anonymous" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css" crossorigin="anonymous" />
  <link rel="stylesheet" href="../css/adminlte.css" />
  <link rel="stylesheet" href="../css/dark-mode.css" />
  <link rel="stylesheet" href="../css/admin-responsive.css" />
  <link rel="stylesheet" href="../css/system-alerts.css" />
  <link rel="stylesheet" href="../css/superadmin-theme.css" />
  <style>
    :root { --wf-primary:#8B1A1A; --wf-primary-soft:#fdf2f2; --wf-primary-border:#f5bcbc; --wf-text:#2d1a1a; --wf-muted:#a97b7b; }
    .wf-card { background:#fff; border:1px solid var(--wf-primary-border); border-radius:14px; padding:1.25rem; margin-bottom:1rem; box-shadow:0 4px 12px rgba(139,26,26,.06); }
    .wf-step { display:grid; grid-template-columns:40px minmax(160px,1fr) 220px 96px 88px 42px; gap:.65rem; align-items:center; padding:.85rem 1rem; background:#fdf8f8; border:1.5px solid var(--wf-primary-border); border-radius:12px; margin-bottom:.65rem; }
    .wf-step-num { font-weight:800; color:var(--wf-primary); font-size:1.15rem; text-align:center; }
    .wf-step input[type=text], .wf-step select { width:100%; padding:.55rem .7rem; border:1.5px solid var(--wf-primary-border); border-radius:8px; font-family:inherit; font-size:.85rem; background:#fff; color:var(--wf-text); }
    .wf-step input[type=text]:focus, .wf-step select:focus { outline:none; border-color:var(--wf-primary); box-shadow:0 0 0 3px rgba(139,26,26,.12); }
    .wf-toggle { display:flex; align-items:center; gap:.35rem; font-size:.78rem; font-weight:700; color:var(--wf-text); cursor:pointer; margin:0; white-space:nowrap; }
    .wf-toggle input[type=checkbox] { accent-color:var(--wf-primary); width:18px; height:18px; cursor:pointer; }
    .wf-remove { width:34px; height:34px; border-radius:8px; border:1.5px solid #fecaca; background:#fee2e2; color:#b91c1c; cursor:pointer; display:flex; align-items:center; justify-content:center; }
    .wf-lock { width:34px; height:34px; border-radius:8px; border:1.5px solid var(--wf-primary-border); background:#fff; color:var(--wf-primary); display:flex; align-items:center; justify-content:center; }
    .wf-btn { display:inline-flex; align-items:center; gap:.4rem; padding:.55rem 1.1rem; border-radius:8px; font-family:inherit; font-weight:700; font-size:.85rem; cursor:pointer; border:none; text-decoration:none; }
    .wf-btn-primary { background:var(--wf-primary); color:#fff; }
    .wf-btn-primary:hover { background:#6d1414; color:#fff; }
    .wf-btn-outline { background:#fff; border:1.5px solid var(--wf-primary-border); color:var(--wf-primary); }
    .wf-btn-outline:hover { background:var(--wf-primary-soft); }
    .wf-empty { text-align:center; padding:3rem 1rem; color:var(--wf-muted); }
    .wf-empty i { font-size:3rem; display:block; margin-bottom:.75rem; }
    .wf-actions { display:flex; gap:.5rem; flex-wrap:wrap; margin-top:1rem; }
    @media (max-width:1100px){ .wf-step{ grid-template-columns:34px 1fr; } }
  </style>
  <script src="../js/theme.js" defer></script>
</head>
<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">
  <div class="app-wrapper">
    <?php
    include_once '../includes/header.php';
    include_once '../includes/sAdmin_sidebar.php';
    ?>
    <main class="app-main">
      <div class="app-content-header"></div>
      <div class="app-content">
        <div class="container-fluid p-4">

          <!-- Page header banner (matches existing SuperAdmin theme) -->
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3 p-4 text-white sa-page-header">
            <div class="d-flex align-items-center gap-3">
              <i class="bi bi-diagram-3-fill" style="font-size:1.5rem;"></i>
              <div>
                <h1 class="mb-0" style="font-size:1.5rem; font-weight:600;">Workflow Configuration</h1>
                <p class="mb-0" style="font-size:0.85rem; opacity:0.85;">Configure the approval workflow for each school year</p>
              </div>
            </div>
          </div>

          <!-- Breadcrumb -->
          <?php renderBreadcrumb([
            ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'],
            ['label' => 'System Configuration', 'href' => '#', 'icon' => 'bi bi-sliders'],
            ['label' => 'Workflow', 'icon' => 'bi bi-diagram-3-fill'],
          ]); ?>

          <?php if ($loadError !== ''): ?>
            <div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($loadError) ?></div>
          <?php endif; ?>

          <?php if ($flashMessage !== ''): ?>
            <div data-sa-flash="<?= htmlspecialchars($flashType) ?>"
                 data-sa-flash-message="<?= htmlspecialchars($flashMessage) ?>"
                 style="display:none"></div>
          <?php endif; ?>

          <?php if (!$selectedYear): ?>
            <div class="wf-card">
              <div class="wf-empty">
                <i class="bi bi-calendar-x"></i>
                <h5 style="color:var(--wf-primary);">No academic years found</h5>
                <p>Create an academic year first, then return here to configure its workflow.</p>
              </div>
            </div>
          <?php elseif (!$template): ?>
            <div class="wf-card">
              <div class="wf-empty">
                <i class="bi bi-diagram-3"></i>
                <h4 style="color:var(--wf-primary);margin:.5rem 0;">No workflow yet for <?= htmlspecialchars($selectedYear['year_label']) ?></h4>
                <p>Create one by copying the previous year&rsquo;s setup, or start from the default 5-step chain.</p>
                <div class="wf-actions" style="justify-content:center;">
                  <button type="button" class="wf-btn wf-btn-primary" onclick="wfCreateTemplate('copy')">
                    <i class="bi bi-files"></i> Create Template from Previous SY
                  </button>
                  <button type="button" class="wf-btn wf-btn-outline" onclick="wfCreateTemplate('empty')">
                    <i class="bi bi-plus-circle"></i> Start Empty
                  </button>
                </div>
              </div>
            </div>
          <?php else: ?>
            <div class="wf-card">
              <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
                <h5 class="mb-0" style="color:var(--wf-primary);font-size:1rem;">
                  <i class="bi bi-list-ol me-2"></i>Approval Steps for <?= htmlspecialchars($selectedYear['year_label']) ?>
                </h5>
                <span class="text-muted small">
                  Toggle <strong>Check</strong> to allow &ldquo;Mark as Checked&rdquo; on that step.
                </span>
              </div>

              <div id="wfSteps"></div>

              <div class="wf-actions">
                <button type="button" id="wfAddStepBtn" class="wf-btn wf-btn-outline" onclick="wfAddStep()" <?= count($stepsSeed) >= 6 ? 'disabled aria-disabled="true"' : '' ?>>
                  <i class="bi bi-plus-circle"></i> Add Step
                </button>
                <button type="button" class="wf-btn wf-btn-primary" onclick="wfSave()">
                  <i class="bi bi-save"></i> Save Workflow for <?= htmlspecialchars($selectedYear['year_label']) ?>
                </button>
              </div>
            </div>
          <?php endif; ?>

        </div>
      </div>
    </main>
    <?php
    include_once '../includes/footer.php';
    ?>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>
  <script src="../js/adminlte.js"></script>
  <script src="../js/system-alerts.js"></script>
  <script src="../js/superadmin-alerts.js"></script>

  <script>
    const WF_YEAR_ID     = <?= (int)$selectedYearId ?>;
    const WF_TEMPLATE_ID = <?= (int)($template['id'] ?? 0) ?>;
    const WF_POSITIONS   = <?= json_encode($positionOptions, JSON_UNESCAPED_SLASHES) ?>;
    const WF_SEED        = <?= json_encode($stepsSeed, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
    const WF_MAX_STEPS   = 6;

    function wfEsc(s) {
      return String(s == null ? '' : s)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
    }

    function wfRowHtml(d, index) {
      d = d || {};
      const id      = parseInt(d.step_id) || 0;
      const label   = (d.step_label != null) ? String(d.step_label) : '';
      const pos     = d.required_position || WF_POSITIONS[0];
      const checked = parseInt(d.allow_mark_checked) ? true : false;
      const reject  = (d.can_reject === undefined) ? true : !!parseInt(d.can_reject);
      const locked  = parseInt(d.step_order, 10) === 1 || index === 0;

      const opts = WF_POSITIONS.map(function (p) {
        return '<option value="' + wfEsc(p) + '"' + (p === pos ? ' selected' : '') + '>' + wfEsc(p) + '</option>';
      }).join('');

      return '' +
        '<div class="wf-step" data-step-id="' + id + '">' +
          '<div class="wf-step-num">1</div>' +
          '<input type="text" data-field="label" maxlength="50" placeholder="Step label" value="' + wfEsc(label) + '">' +
          '<select data-field="position">' + opts + '</select>' +
          '<label class="wf-toggle"><input type="checkbox" data-field="allow_mark_checked"' + (checked ? ' checked' : '') + '> Check</label>' +
          '<label class="wf-toggle"><input type="checkbox" data-field="can_reject"' + (reject ? ' checked' : '') + '> Reject</label>' +
          (locked
            ? '<span class="wf-lock" title="Required step"><i class="bi bi-lock-fill"></i></span>'
            : '<button type="button" class="wf-remove" title="Remove step" onclick="wfRemoveStep(this)"><i class="bi bi-x-lg"></i></button>') +
        '</div>';
    }

    function wfUpdateAddButton() {
      const btn = document.getElementById('wfAddStepBtn');
      if (!btn) return;
      const atLimit = document.querySelectorAll('#wfSteps .wf-step').length >= WF_MAX_STEPS;
      btn.disabled = atLimit;
      btn.setAttribute('aria-disabled', atLimit ? 'true' : 'false');
    }

    function wfRenumber() {
      document.querySelectorAll('#wfSteps .wf-step').forEach(function (el, i) {
        const n = el.querySelector('.wf-step-num');
        if (n) n.textContent = i + 1;
      });
      wfUpdateAddButton();
    }

    function wfAddStep() {
      if (document.querySelectorAll('#wfSteps .wf-step').length >= WF_MAX_STEPS) {
        alert('Maximum of 6 steps allowed.');
        return;
      }
      document.getElementById('wfSteps').insertAdjacentHTML('beforeend', wfRowHtml({}));
      wfRenumber();
    }

    function wfRemoveStep(btn) {
      const row = btn.closest('.wf-step');
      if (row === document.querySelector('#wfSteps .wf-step')) return;
      if (row) row.remove();
      wfRenumber();
    }

    async function wfSave() {
      const rows = document.querySelectorAll('#wfSteps .wf-step');
      const steps = [];
      rows.forEach(function (el, i) {
        steps.push({
          step_id:            parseInt(el.dataset.stepId) || 0,
          step_order:         i + 1,
          step_label:         el.querySelector('[data-field="label"]').value,
          required_position:  el.querySelector('[data-field="position"]').value,
          allow_mark_checked: el.querySelector('[data-field="allow_mark_checked"]').checked ? 1 : 0,
          can_reject:         el.querySelector('[data-field="can_reject"]').checked ? 1 : 0
        });
      });

      if (steps.length < 2) { alert('A workflow needs at least 2 steps.'); return; }
      if (steps.length > WF_MAX_STEPS) { alert('Maximum of 6 steps allowed.'); return; }
      if (!steps[0] || steps[0].required_position !== 'Teacher') {
        alert('Step 1 must be Teacher Encoding.');
        return;
      }

      try {
        const r = await fetch('../api/workflow/save_template.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ template_id: WF_TEMPLATE_ID, steps: steps })
        });
        const d = await r.json();
        if (d.success) {
          window.location.href = '?year_id=' + WF_YEAR_ID + '&msg=saved';
        } else {
          alert(d.message || 'Failed to save workflow.');
        }
      } catch (e) {
        alert('Network error while saving. Please try again.');
      }
    }

    async function wfCreateTemplate(mode) {
      try {
        const r = await fetch('../api/workflow/create_template_for_year.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ academic_year_id: WF_YEAR_ID, mode: mode })
        });
        const d = await r.json();
        if (d.success) {
          window.location.href = '?year_id=' + WF_YEAR_ID + '&msg=created';
        } else {
          alert(d.message || 'Failed to create template.');
        }
      } catch (e) {
        alert('Network error while creating template. Please try again.');
      }
    }

    document.addEventListener('DOMContentLoaded', function () {
      const container = document.getElementById('wfSteps');
      if (!container) return;

      if (Array.isArray(WF_SEED) && WF_SEED.length) {
        container.innerHTML = WF_SEED.map(wfRowHtml).join('');
      } else {
        container.innerHTML = wfRowHtml({ required_position: WF_POSITIONS[0] }, 0);
      }
      wfRenumber();
    });
  </script>
</body>
</html>




