<?php
session_start();

// Auth guard: must be logged in as Super Admin (role_id = 4)
if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 4) {
    header('Location: ../login.php');
    exit;
}

require_once __DIR__ . '/../api/shared/db_connect.php';
require_once __DIR__ . '/../includes/breadcrumb.php';

/* ============================================================
   Active tab (GET ?tab=domains|skills)
   ============================================================ */
$validTabs = ['domains', 'skills'];
$activeTab = (string)($_GET['tab'] ?? '');
if (!in_array($activeTab, $validTabs, true)) {
    // A domain filter in the URL means the user is looking at skills
    $activeTab = ((int)($_GET['domain_id'] ?? 0) > 0) ? 'skills' : 'domains';
}

/* ============================================================
   PRG redirect helper
   ============================================================ */
function ksRedirect(string $msg, string $tab = 'domains', int $domainId = 0): void
{
    $url = 'Kinder-Skills.php?msg=' . urlencode($msg) . '&tab=' . urlencode($tab);
    if ($domainId > 0) {
        $url .= '&domain_id=' . $domainId;
    }
    header('Location: ' . $url);
    exit;
}

/* ============================================================
   Fetch helpers
   ============================================================ */
function ksFetchDomain(PDO $pdo, int $id): ?array
{
    if ($id <= 0) {
        return null;
    }
    $stmt = $pdo->prepare('SELECT * FROM tblkinder_domains WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row === false ? null : $row;
}

function ksFetchSkill(PDO $pdo, int $id): ?array
{
    if ($id <= 0) {
        return null;
    }
    $stmt = $pdo->prepare('SELECT * FROM tblkinder_skills WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row === false ? null : $row;
}

/* ============================================================
   Validators
   ============================================================ */
function ksValidateDomainInput(array $post): array
{
    // Returns [ok(bool), data-array-or-error-code]
    $code = strtoupper(trim((string)($post['domain_code'] ?? '')));
    if ($code === '' || mb_strlen($code) > 10) {
        return [false, 'error_domain_code'];
    }
    $name = trim((string)($post['domain_name'] ?? ''));
    if ($name === '' || mb_strlen($name) > 100) {
        return [false, 'error_domain_name'];
    }
    $description = trim((string)($post['description'] ?? ''));

    $sortRaw = trim((string)($post['sort_order'] ?? ''));
    $sortOrder = ($sortRaw !== '' && ctype_digit($sortRaw)) ? (int)$sortRaw : 0;
    if ($sortOrder < 0 || $sortOrder > 255) {
        return [false, 'error_domain_input'];
    }
    $isActive = isset($post['is_active']) ? 1 : 0;

    return [true, [
        'domain_code' => $code,
        'domain_name' => $name,
        'description' => $description !== '' ? $description : null,
        'sort_order'  => $sortOrder,
        'is_active'   => $isActive,
    ]];
}

function ksValidateSkillInput(array $post): array
{
    // Returns [ok(bool), data-array-or-error-code]
    $domainId = (int)($post['domain_id'] ?? 0);
    if ($domainId <= 0) {
        return [false, 'error_skill_domain'];
    }
    $code = strtoupper(trim((string)($post['skill_code'] ?? '')));
    if ($code === '' || mb_strlen($code) > 20) {
        return [false, 'error_skill_code'];
    }
    $description = trim((string)($post['skill_description'] ?? ''));
    if ($description === '') {
        return [false, 'error_skill_description'];
    }

    $sortRaw = trim((string)($post['sort_order'] ?? ''));
    $sortOrder = ($sortRaw !== '' && ctype_digit($sortRaw)) ? (int)$sortRaw : 0;
    if ($sortOrder < 0 || $sortOrder > 255) {
        return [false, 'error_skill_input'];
    }
    $isActive = isset($post['is_active']) ? 1 : 0;

    return [true, [
        'domain_id'         => $domainId,
        'skill_code'        => $code,
        'skill_description' => $description,
        'sort_order'        => $sortOrder,
        'is_active'         => $isActive,
    ]];
}
?>

<?php
/* ============================================================
   POST handlers (PRG pattern — every branch ends in a redirect)
   ============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');

    try {
        /* ---------- A) add_domain ---------- */
        if ($action === 'add_domain') {
            [$ok, $result] = ksValidateDomainInput($_POST);
            if (!$ok) {
                ksRedirect($result, 'domains');
            }
            $pdo->prepare(
                'INSERT INTO tblkinder_domains
                    (domain_code, domain_name, description, sort_order, is_active)
                 VALUES (?, ?, ?, ?, ?)'
            )->execute([
                $result['domain_code'], $result['domain_name'], $result['description'],
                $result['sort_order'], $result['is_active'],
            ]);
            ksRedirect('domain_added', 'domains');
        }

        /* ---------- B) update_domain ---------- */
        if ($action === 'update_domain') {
            $domainId = (int)($_POST['id'] ?? 0);
            $existing = ksFetchDomain($pdo, $domainId);
            if ($existing === null) {
                ksRedirect('error_domain_not_found', 'domains');
            }
            [$ok, $result] = ksValidateDomainInput($_POST);
            if (!$ok) {
                ksRedirect($result, 'domains');
            }
            $pdo->prepare(
                'UPDATE tblkinder_domains
                 SET domain_code = ?, domain_name = ?, description = ?, sort_order = ?, is_active = ?
                 WHERE id = ?'
            )->execute([
                $result['domain_code'], $result['domain_name'], $result['description'],
                $result['sort_order'], $result['is_active'], $domainId,
            ]);
            ksRedirect('domain_updated', 'domains');
        }

        /* ---------- C) toggle_domain (Deactivate / Activate) ---------- */
        if ($action === 'toggle_domain') {
            $domainId = (int)($_POST['id'] ?? 0);
            $existing = ksFetchDomain($pdo, $domainId);
            if ($existing === null) {
                ksRedirect('error_domain_not_found', 'domains');
            }
            $newState = ((int)$existing['is_active'] === 1) ? 0 : 1;
            $pdo->prepare('UPDATE tblkinder_domains SET is_active = ? WHERE id = ?')->execute([$newState, $domainId]);
            ksRedirect('domain_toggled', 'domains');
        }

        /* ---------- D) add_skill ---------- */
        if ($action === 'add_skill') {
            [$ok, $result] = ksValidateSkillInput($_POST);
            if (!$ok) {
                ksRedirect($result, 'skills');
            }
            $domain = ksFetchDomain($pdo, $result['domain_id']);
            if ($domain === null) {
                ksRedirect('error_domain_not_found', 'skills');
            }
            $pdo->prepare(
                'INSERT INTO tblkinder_skills
                    (domain_id, skill_code, skill_description, sort_order, is_active)
                 VALUES (?, ?, ?, ?, ?)'
            )->execute([
                $result['domain_id'], $result['skill_code'], $result['skill_description'],
                $result['sort_order'], $result['is_active'],
            ]);
            ksRedirect('skill_added', 'skills', $result['domain_id']);
        }

        /* ---------- E) update_skill ---------- */
        if ($action === 'update_skill') {
            $skillId = (int)($_POST['id'] ?? 0);
            $existing = ksFetchSkill($pdo, $skillId);
            if ($existing === null) {
                ksRedirect('error_skill_not_found', 'skills');
            }
            [$ok, $result] = ksValidateSkillInput($_POST);
            if (!$ok) {
                ksRedirect($result, 'skills');
            }
            $domain = ksFetchDomain($pdo, $result['domain_id']);
            if ($domain === null) {
                ksRedirect('error_domain_not_found', 'skills');
            }
            $pdo->prepare(
                'UPDATE tblkinder_skills
                 SET domain_id = ?, skill_code = ?, skill_description = ?, sort_order = ?, is_active = ?
                 WHERE id = ?'
            )->execute([
                $result['domain_id'], $result['skill_code'], $result['skill_description'],
                $result['sort_order'], $result['is_active'], $skillId,
            ]);
            ksRedirect('skill_updated', 'skills', $result['domain_id']);
        }

        /* ---------- F) toggle_skill (Deactivate / Activate) ---------- */
        if ($action === 'toggle_skill') {
            $skillId = (int)($_POST['id'] ?? 0);
            $existing = ksFetchSkill($pdo, $skillId);
            if ($existing === null) {
                ksRedirect('error_skill_not_found', 'skills');
            }
            $newState = ((int)$existing['is_active'] === 1) ? 0 : 1;
            $pdo->prepare('UPDATE tblkinder_skills SET is_active = ? WHERE id = ?')->execute([$newState, $skillId]);
            ksRedirect('skill_toggled', 'skills', (int)$existing['domain_id']);
        }

        /* ---------- G) delete_skill ---------- */
        if ($action === 'delete_skill') {
            $skillId = (int)($_POST['id'] ?? 0);
            $existing = ksFetchSkill($pdo, $skillId);
            if ($existing === null) {
                ksRedirect('error_skill_not_found', 'skills');
            }
            $pdo->prepare('DELETE FROM tblkinder_skills WHERE id = ?')->execute([$skillId]);
            ksRedirect('skill_deleted', 'skills', (int)$existing['domain_id']);
        }

        ksRedirect('error_unknown_action', 'domains');
    } catch (PDOException $e) {
        error_log('Kinder-Skills.php POST error: ' . $e->getMessage());
        $errTab = (strpos($action, 'skill') !== false) ? 'skills' : 'domains';
        if ($e->getCode() === '23000') {
            // Duplicate key (domain_code / skill_code UNIQUE) or FK violation
            ksRedirect('error_duplicate', $errTab);
        }
        ksRedirect('error_db', $errTab);
    }
}
?>
<?php
// ------------------------- Flash message (mapped from ?msg= PRG code) -------------------------
$flashMap = [
    'domain_added'            => ['Domain added successfully.', 'success'],
    'domain_updated'          => ['Domain updated successfully.', 'success'],
    'domain_toggled'          => ['Domain status updated.', 'success'],
    'skill_added'             => ['Skill added successfully.', 'success'],
    'skill_updated'           => ['Skill updated successfully.', 'success'],
    'skill_toggled'           => ['Skill status updated.', 'success'],
    'skill_deleted'           => ['Skill deleted.', 'success'],
    'error_domain_code'       => ['Domain code is required and must be at most 10 characters.', 'danger'],
    'error_domain_name'       => ['Domain name is required and must be at most 100 characters.', 'danger'],
    'error_domain_input'      => ['Invalid domain values — sort order must be a whole number between 0 and 255.', 'danger'],
    'error_skill_domain'      => ['Please select a valid domain for the skill.', 'danger'],
    'error_skill_code'        => ['Skill code is required and must be at most 20 characters.', 'danger'],
    'error_skill_description' => ['Skill description is required.', 'danger'],
    'error_skill_input'       => ['Invalid skill values — sort order must be a whole number between 0 and 255.', 'danger'],
    'error_domain_not_found'  => ['Domain not found.', 'danger'],
    'error_skill_not_found'   => ['Skill not found.', 'danger'],
    'error_duplicate'         => ['Duplicate entry — the domain code or skill code already exists.', 'danger'],
    'error_db'                => ['Database error: the operation could not be completed.', 'danger'],
    'error_unknown_action'    => ['Unknown action.', 'danger'],
];
$msgKey = (string)($_GET['msg'] ?? '');
if ($msgKey !== '' && isset($flashMap[$msgKey])) {
    [$flashMessage, $flashType] = $flashMap[$msgKey];
} else {
    $flashMessage = '';
    $flashType    = 'success';
}

// ------------------------- Fetch domains, skills (with optional domain filter) -------------------------
$domains = $pdo->query("
    SELECT d.*,
           (SELECT COUNT(*) FROM tblkinder_skills WHERE domain_id = d.id) AS skill_count
    FROM tblkinder_domains d
    ORDER BY d.sort_order, d.domain_code
")->fetchAll(PDO::FETCH_ASSOC);

$filter_domain = max(0, (int)($_GET['domain_id'] ?? 0));
$skillsQuery = "SELECT s.*, d.domain_code, d.domain_name
                FROM tblkinder_skills s
                JOIN tblkinder_domains d ON d.id = s.domain_id";
if ($filter_domain > 0) $skillsQuery .= " WHERE s.domain_id = ?";
$skillsQuery .= " ORDER BY d.sort_order, s.sort_order, s.skill_code";
$skillsStmt = $pdo->prepare($skillsQuery);
$skillsStmt->execute($filter_domain > 0 ? [$filter_domain] : []);
$skills = $skillsStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!doctype html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>STSN Grading System | Kindergarten Skills</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <meta name="color-scheme" content="light dark" />
  <meta name="theme-color" content="#8B1A1A" media="(prefers-color-scheme: light)" />
  <meta name="theme-color" content="#8B1A1A" />
  <meta name="title" content="STSN | Kindergarten Skills" />
  <meta name="author" content="G" />
  <meta name="description"
    content="STSN Grading System - A modern and accessible Bootstrap 5-based grading and student management platform for Schools. Secure, fast, and WCAG 2.1 AA compliant." />
  <meta name="keywords"
    content="STSN, STSN Grading System, school grading system, student information system, bootstrap 5 admin dashboard, grading dashboard, student records, kindergarten skills, developmental domains" />
  <meta name="supported-color-schemes" content="light dark" />
  <link rel="preload" href="../css/adminlte.css" as="style" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
    integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
    onload="this.media='all'" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
    crossorigin="anonymous" />

  <link rel="icon" href="data:," />
  <link rel="stylesheet" href="../css/adminlte.css" />
  <link rel="stylesheet" href="../css/system-alerts.css" />
  <link rel="stylesheet" href="../css/superadmin-theme.css" />

  <style>
    .as-card {
      background: #fff;
      border: 1px solid var(--border, #E9ECEF);
      border-radius: 14px;
      box-shadow: 0 4px 12px rgba(10,47,68,0.06);
      margin-bottom: 1.25rem;
      overflow: hidden;
    }
    .as-card-header {
      padding: 1rem 1.25rem;
      border-bottom: 1px solid var(--border, #E9ECEF);
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 1rem;
      flex-wrap: wrap;
    }
    .as-card-title {
      font-size: 1.05rem;
      font-weight: 800;
      color: var(--primary, #0A2F44);
      display: flex;
      align-items: center;
      gap: 0.5rem;
      flex-wrap: wrap;
    }
    .as-card-title i { color: #C5A028; }
    .as-card-desc {
      font-size: 0.82rem;
      color: var(--muted, #6C757D);
      margin-top: 4px;
    }
    .as-card-body { padding: 1.25rem; }

    .ks-table thead th {
      font-size: 0.72rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--muted, #6C757D);
      font-weight: 700;
      white-space: nowrap;
    }
    .ks-domain-badge {
      min-width: 64px;
      font-weight: 700;
    }

    /* Tabs */
    .ks-tabs {
      border-bottom: 2px solid var(--border, #E9ECEF);
      gap: 0.25rem;
    }
    .ks-tabs .nav-link {
      border: none;
      border-bottom: 3px solid transparent;
      border-radius: 0;
      background: transparent;
      color: #6C757D;
      font-weight: 700;
      font-size: 0.9rem;
      padding: 0.65rem 1rem;
      margin-bottom: -2px;
    }
    .ks-tabs .nav-link:hover {
      color: #8B1A1A;
    }
    .ks-tabs .nav-link.active,
    .ks-tabs .nav-link.active:hover,
    .ks-tabs .nav-link.active:focus {
      background: transparent !important;
      color: #8B1A1A !important;
      border-radius: 0 !important;
      border-bottom-color: #8B1A1A !important;
      box-shadow: none !important;
    }

    /* Dark mode support */
    [data-bs-theme="dark"] .as-card { background: #1a1d21; border-color: #2b3035; }
    [data-bs-theme="dark"] .as-card-header { border-bottom-color: #2b3035; }
    [data-bs-theme="dark"] .as-card-title { color: #e9ecef; }
    [data-bs-theme="dark"] .ks-table thead th { color: #adb5bd; }
    [data-bs-theme="dark"] .ks-tabs { border-bottom-color: #2b3035; }
    [data-bs-theme="dark"] .ks-tabs .nav-link { color: #adb5bd; }
    [data-bs-theme="dark"] .ks-tabs .nav-link:hover { color: #e9ecef; }
    [data-bs-theme="dark"] .ks-tabs .nav-link.active,
    [data-bs-theme="dark"] .ks-tabs .nav-link.active:hover,
    [data-bs-theme="dark"] .ks-tabs .nav-link.active:focus { color: #FFA8A8 !important; border-bottom-color: #FFA8A8 !important; }
  </style>
</head>

<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">

  <div class="app-wrapper">
    <?php
    include_once '../includes/header.php';
    include_once '../includes/sAdmin_sidebar.php';
    ?>

    <main class="app-main">

      <div class="app-content-header">
      </div>
      <div class="app-content">
        <div class="container-fluid p-4">

          <!-- Page Header Banner -->
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3 p-4 text-white sa-page-header">
            <div class="d-flex align-items-center gap-3">
              <i class="bi bi-people-fill" style="font-size:1.5rem;"></i>
              <div>
                <h1 class="mb-0" style="font-size:1.5rem; font-weight:600;">Kindergarten Skills Configuration</h1>
                <p class="mb-0" style="font-size:0.85rem; opacity:0.85;">Manage developmental domains and skills for Kindergarten</p>
              </div>
            </div>
          </div>

          <!-- Breadcrumb -->
          <?php renderBreadcrumb([
            ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'],
            ['label' => 'System Settings', 'href' => 'System-Settings.php', 'icon' => 'bi bi-gear-fill'],
            ['label' => 'Kindergarten Skills', 'icon' => 'bi bi-people-fill'],
          ]); ?>

          <?php if ($flashMessage !== ''): ?>
            <div data-sa-flash="<?= htmlspecialchars($flashType) ?>"
                 data-sa-flash-message="<?= htmlspecialchars($flashMessage) ?>"
                 style="display:none"></div>
          <?php endif; ?>

          <!-- Tabs -->
          <ul class="nav nav-tabs ks-tabs mb-3" role="tablist">
            <li class="nav-item" role="presentation">
              <button class="nav-link<?= $activeTab === 'domains' ? ' active' : '' ?>" id="tabDomainsBtn"
                      data-bs-toggle="tab" data-bs-target="#tabDomains" type="button" role="tab"
                      aria-controls="tabDomains" aria-selected="<?= $activeTab === 'domains' ? 'true' : 'false' ?>">
                <i class="bi bi-diagram-3-fill me-1"></i> Developmental Domains
              </button>
            </li>
            <li class="nav-item" role="presentation">
              <button class="nav-link<?= $activeTab === 'skills' ? ' active' : '' ?>" id="tabSkillsBtn"
                      data-bs-toggle="tab" data-bs-target="#tabSkills" type="button" role="tab"
                      aria-controls="tabSkills" aria-selected="<?= $activeTab === 'skills' ? 'true' : 'false' ?>">
                <i class="bi bi-list-check me-1"></i> Skills
              </button>
            </li>
          </ul>

          <div class="tab-content">

            <!-- ============================ TAB 1: DOMAINS ============================ -->
            <div class="tab-pane fade<?= $activeTab === 'domains' ? ' show active' : '' ?>"
                 id="tabDomains" role="tabpanel" aria-labelledby="tabDomainsBtn" tabindex="0">

              <div class="as-card">
                <div class="as-card-header">
                  <div>
                    <div class="as-card-title">
                      <i class="bi bi-diagram-3-fill"></i> Developmental Domains
                    </div>
                  </div>
                  <button type="button" class="btn btn-primary" id="addDomainBtn">
                    <i class="bi bi-plus-lg me-1"></i> Add Domain
                  </button>
                </div>
                <div class="as-card-body p-0">
                  <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 ks-table">
                      <thead>
                        <tr>
                          <th class="text-nowrap">Domain Code</th>
                          <th class="text-nowrap">Domain Name</th>
                          <th>Description</th>
                          <th class="text-nowrap text-center">Skills Count</th>
                          <th class="text-nowrap text-center">Active</th>
                          <th class="text-end text-nowrap" style="width:1%;">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php if ($domains === []): ?>
                          <tr>
                            <td colspan="6" class="text-center py-5">
                              <i class="bi bi-inbox text-muted mb-2 d-block" style="font-size:3rem;"></i>
                              <div class="text-body">No domains yet</div>
                              <div class="text-muted" style="font-size:0.85rem;">Click &ldquo;Add Domain&rdquo; to create the first developmental domain.</div>
                            </td>
                          </tr>
                        <?php else: ?>
                          <?php foreach ($domains as $domain): ?>
                            <?php
                            $domainId   = (int)$domain['id'];
                            $isActiveD  = (int)$domain['is_active'] === 1;
                            $domDesc    = trim((string)($domain['description'] ?? ''));
                            $skillCount = (int)$domain['skill_count'];
                            ?>
                            <tr>
                              <td class="text-nowrap">
                                <span class="badge <?= $isActiveD ? 'bg-primary' : 'bg-secondary' ?> ks-domain-badge"><?= htmlspecialchars((string)$domain['domain_code']) ?></span>
                              </td>
                              <td class="fw-bold"><?= htmlspecialchars((string)$domain['domain_name']) ?></td>
                              <td class="text-muted small"><?= $domDesc !== '' ? htmlspecialchars($domDesc) : '<span class="text-muted">&mdash;</span>' ?></td>
                              <td class="text-center">
                                <span class="badge <?= $skillCount > 0 ? 'bg-success' : 'bg-secondary' ?>"><?= $skillCount ?></span>
                              </td>
                              <td class="text-center">
                                <?= $isActiveD
                                  ? '<span class="badge bg-success"><i class="bi bi-check-lg me-1"></i>Active</span>'
                                  : '<span class="badge bg-secondary"><i class="bi bi-slash-circle me-1"></i>Inactive</span>' ?>
                              </td>
                              <td class="text-end text-nowrap">
                                <button type="button" class="btn btn-outline-primary btn-sm edit-domain-btn" title="Edit"
                                        data-id="<?= $domainId ?>"
                                        data-code="<?= htmlspecialchars((string)$domain['domain_code']) ?>"
                                        data-name="<?= htmlspecialchars((string)$domain['domain_name']) ?>"
                                        data-description="<?= htmlspecialchars($domDesc) ?>"
                                        data-sort="<?= (int)$domain['sort_order'] ?>"
                                        data-active="<?= $isActiveD ? '1' : '0' ?>">
                                  <i class="bi bi-pencil-square me-1"></i> Edit
                                </button>

                                <button type="button" class="btn btn-outline-success btn-sm add-skill-for-btn" title="Add Skill"
                                        data-domain-id="<?= $domainId ?>">
                                  <i class="bi bi-plus-circle me-1"></i> Add Skill
                                </button>

                                <form method="post" action="Kinder-Skills.php" class="d-inline"
                                      data-confirm="<?= $isActiveD ? 'Deactivate this domain? Its skills will also be hidden from new assessments.' : 'Activate this domain?' ?>">
                                  <input type="hidden" name="action" value="toggle_domain">
                                  <input type="hidden" name="id" value="<?= $domainId ?>">
                                  <button type="submit" class="btn btn-outline-secondary btn-sm"
                                          title="<?= $isActiveD ? 'Deactivate' : 'Activate' ?>">
                                    <i class="bi bi-arrow-repeat me-1"></i> <?= $isActiveD ? 'Deactivate' : 'Activate' ?>
                                  </button>
                                </form>
                              </td>
                            </tr>
                          <?php endforeach; ?>
                        <?php endif; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

            </div>

            <!-- ============================ TAB 2: SKILLS ============================ -->
            <div class="tab-pane fade<?= $activeTab === 'skills' ? ' show active' : '' ?>"
                 id="tabSkills" role="tabpanel" aria-labelledby="tabSkillsBtn" tabindex="0">

              <div class="as-card">
                <div class="as-card-header">
                  <div>
                    <div class="as-card-title">
                      <i class="bi bi-list-check"></i> Skills
                    </div>
                  </div>
                  <button type="button" class="btn btn-primary" id="addSkillBtn">
                    <i class="bi bi-plus-lg me-1"></i> Add Skill
                  </button>
                </div>
                <div class="as-card-body p-0">

                  <!-- Domain filter -->
                  <form method="get" action="Kinder-Skills.php" id="skillFilterForm" class="px-3 pt-3">
                    <input type="hidden" name="tab" value="skills">
                    <div style="display:flex;gap:.5rem;">
                      <select name="domain_id" id="skillFilterSelect" class="form-select" onchange="this.form.submit()" style="max-width:260px;">
                        <option value="0">All Domains</option>
                        <?php foreach ($domains as $filterDomainRow): ?>
                          <option value="<?= (int)$filterDomainRow['id'] ?>"<?= $filter_domain === (int)$filterDomainRow['id'] ? ' selected' : '' ?>>
                            <?= htmlspecialchars((string)$filterDomainRow['domain_code']) ?> &mdash; <?= htmlspecialchars((string)$filterDomainRow['domain_name']) ?>
                          </option>
                        <?php endforeach; ?>
                      </select>
                    </div>
                  </form>

                  <div class="table-responsive p-3">
                    <table class="table table-hover align-middle mb-0 ks-table">
                      <thead>
                        <tr>
                          <th>Description</th>
                          <th class="text-nowrap">Domain</th>
                          <th class="text-nowrap text-center">Sort</th>
                          <th class="text-nowrap text-center">Active</th>
                          <th class="text-end text-nowrap" style="width:1%;">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php if ($skills === []): ?>
                          <tr>
                            <td colspan="5" class="text-center py-5">
                              <i class="bi bi-inbox text-muted mb-2 d-block" style="font-size:3rem;"></i>
                              <?php if ($domains === []): ?>
                                <div class="text-body">No domains yet</div>
                                <div class="text-muted" style="font-size:0.85rem;">Create a domain first, then add skills to it.</div>
                              <?php elseif ($filter_domain > 0): ?>
                                <div class="text-body">No skills for this domain</div>
                                <div class="text-muted" style="font-size:0.85rem;">Click &ldquo;Add Skill&rdquo; to add the first skill to this domain.</div>
                              <?php else: ?>
                                <div class="text-body">No skills yet</div>
                                <div class="text-muted" style="font-size:0.85rem;">Click &ldquo;Add Skill&rdquo; to create the first skill.</div>
                              <?php endif; ?>
                            </td>
                          </tr>
                        <?php else: ?>
                          <?php foreach ($skills as $skill): ?>
                            <?php
                            $skillId     = (int)$skill['id'];
                            $skillDomId  = (int)$skill['domain_id'];
                            $isActiveS   = (int)$skill['is_active'] === 1;
                            $skillDesc   = trim((string)$skill['skill_description']);
                            ?>
                            <tr>
                              <td class="small"><?= htmlspecialchars($skillDesc) ?></td>
                              <td class="text-nowrap">
                                <span class="badge <?= $isActiveS ? 'bg-primary' : 'bg-secondary' ?> ks-domain-badge"><?= htmlspecialchars((string)$skill['domain_code']) ?></span>
                                <span class="text-muted small ms-1"><?= htmlspecialchars((string)$skill['domain_name']) ?></span>
                              </td>
                              <td class="text-center text-muted"><?= (int)$skill['sort_order'] ?></td>
                              <td class="text-center">
                                <?= $isActiveS
                                  ? '<span class="badge bg-success"><i class="bi bi-check-lg me-1"></i>Active</span>'
                                  : '<span class="badge bg-secondary"><i class="bi bi-slash-circle me-1"></i>Inactive</span>' ?>
                              </td>
                              <td class="text-end text-nowrap">
                                <button type="button" class="btn btn-outline-primary btn-sm edit-skill-btn" title="Edit"
                                        data-id="<?= $skillId ?>"
                                        data-domain-id="<?= $skillDomId ?>"
                                        data-code="<?= htmlspecialchars((string)$skill['skill_code']) ?>"
                                        data-description="<?= htmlspecialchars($skillDesc) ?>"
                                        data-sort="<?= (int)$skill['sort_order'] ?>"
                                        data-active="<?= $isActiveS ? '1' : '0' ?>">
                                  <i class="bi bi-pencil-square"></i>
                                </button>

                                <form method="post" action="Kinder-Skills.php" class="d-inline"
                                      data-confirm="<?= $isActiveS ? 'Deactivate this skill?' : 'Activate this skill?' ?>">
                                  <input type="hidden" name="action" value="toggle_skill">
                                  <input type="hidden" name="id" value="<?= $skillId ?>">
                                  <button type="submit" class="btn btn-outline-secondary btn-sm"
                                          title="<?= $isActiveS ? 'Deactivate' : 'Activate' ?>">
                                    <i class="bi bi-arrow-repeat"></i>
                                  </button>
                                </form>

                                <form method="post" action="Kinder-Skills.php" class="d-inline"
                                      data-confirm="Delete this skill? Existing assessments that reference it will also be deleted. This cannot be undone.">
                                  <input type="hidden" name="action" value="delete_skill">
                                  <input type="hidden" name="id" value="<?= $skillId ?>">
                                  <button type="submit" class="btn btn-outline-danger btn-sm" title="Delete">
                                    <i class="bi bi-trash"></i>
                                  </button>
                                </form>
                              </td>
                            </tr>
                          <?php endforeach; ?>
                        <?php endif; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

            </div>

          </div><!-- /tab-content -->

        </div>
      </div>

    </main>

    <?php
    include_once '../includes/footer.php';
    ?>
  </div>

  <!-- Add/Edit Domain Modal -->
  <div class="modal fade" id="domainModal" tabindex="-1" aria-labelledby="domainModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <form method="post" action="Kinder-Skills.php" id="domainForm" autocomplete="off">
          <div class="modal-header">
            <h5 class="modal-title" id="domainModalLabel">Add Domain</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <input type="hidden" name="action" id="domainAction" value="add_domain">
            <input type="hidden" name="id" id="domainId" value="">
            <div class="row g-3">
              <div class="col-md-5">
                <label class="form-label" for="domainCode">Domain Code <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="domainCode" name="domain_code"
                       maxlength="10" required placeholder="e.g. PHYS" style="text-transform:uppercase;">
                <div class="form-text text-muted">Short unique code (max 10 chars).</div>
              </div>
              <div class="col-md-7">
                <label class="form-label" for="domainName">Domain Name <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="domainName" name="domain_name"
                       maxlength="100" required placeholder="e.g. Physical &amp; Motor Development">
              </div>
              <div class="col-md-12">
                <label class="form-label" for="domainDescription">Description</label>
                <textarea class="form-control" id="domainDescription" name="description" rows="2"
                          placeholder="Short description of this developmental domain"></textarea>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="domainSort">Sort Order</label>
                <input type="number" class="form-control" id="domainSort" name="sort_order"
                       min="0" max="255" value="0">
                <div class="form-text text-muted">Lower numbers appear first.</div>
              </div>
              <div class="col-md-6 d-flex align-items-end">
                <div class="form-check form-switch">
                  <input class="form-check-input" type="checkbox" id="domainActive" name="is_active" value="1" checked>
                  <label class="form-check-label" for="domainActive">Active</label>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-check-lg me-1"></i> Save Domain
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Add/Edit Skill Modal -->
  <div class="modal fade" id="skillModal" tabindex="-1" aria-labelledby="skillModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <form method="post" action="Kinder-Skills.php" id="skillForm" autocomplete="off">
          <div class="modal-header">
            <h5 class="modal-title" id="skillModalLabel">Add Skill</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <input type="hidden" name="action" id="skillAction" value="add_skill">
            <input type="hidden" name="id" id="skillId" value="">
            <div class="row g-3">
              <div class="col-md-12">
                <label class="form-label" for="skillDomain">Domain <span class="text-danger">*</span></label>
                <select class="form-select" id="skillDomain" name="domain_id" required>
                  <option value="">&mdash; Select Domain &mdash;</option>
                  <?php foreach ($domains as $domainOption): ?>
                    <option value="<?= (int)$domainOption['id'] ?>">
                      <?= htmlspecialchars((string)$domainOption['domain_code']) ?> &mdash; <?= htmlspecialchars((string)$domainOption['domain_name']) ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-12">
                <label class="form-label" for="skillCode">Skill Code <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="skillCode" name="skill_code"
                       maxlength="20" required placeholder="e.g. PHYS-01" style="text-transform:uppercase;">
                <div class="form-text text-muted">Unique code (max 20 chars).</div>
              </div>
              <div class="col-md-12">
                <label class="form-label" for="skillDescription">Skill Description <span class="text-danger">*</span></label>
                <textarea class="form-control" id="skillDescription" name="skill_description" rows="2" required
                          placeholder="e.g. Demonstrates gross motor skills (running, jumping, balancing)"></textarea>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="skillSort">Sort Order</label>
                <input type="number" class="form-control" id="skillSort" name="sort_order"
                       min="0" max="255" value="0">
                <div class="form-text text-muted">Lower numbers appear first.</div>
              </div>
              <div class="col-md-6 d-flex align-items-end">
                <div class="form-check form-switch">
                  <input class="form-check-input" type="checkbox" id="skillActive" name="is_active" value="1" checked>
                  <label class="form-check-label" for="skillActive">Active</label>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-check-lg me-1"></i> Save Skill
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>

  <script src="../js/adminlte.js"></script>

  <script src="../js/system-alerts.js"></script>
  <script src="../js/superadmin-alerts.js"></script>

  <script>
    document.addEventListener('DOMContentLoaded', function () {
      // Auto-dismiss flash messages after 4s
      document.querySelectorAll('.alert-dismissible').forEach(function (alertEl) {
        setTimeout(function () {
          if (window.bootstrap && bootstrap.Alert) {
            bootstrap.Alert.getOrCreateInstance(alertEl).close();
          }
        }, 4000);
      });

      // ------------------------- Domain Modal -------------------------
      var domainModalEl = document.getElementById('domainModal');

      // "+ Add Domain": open modal in create mode
      var addDomainBtn = document.getElementById('addDomainBtn');
      if (addDomainBtn) {
        addDomainBtn.addEventListener('click', function () {
          document.getElementById('domainForm').reset();
          document.getElementById('domainAction').value = 'add_domain';
          document.getElementById('domainId').value = '';
          document.getElementById('domainSort').value = '0';
          document.getElementById('domainActive').checked = true;
          document.getElementById('domainModalLabel').textContent = 'Add Domain';
          bootstrap.Modal.getOrCreateInstance(domainModalEl).show();
        });
      }

      // "Edit" domain: populate modal from data-* attributes
      document.querySelectorAll('.edit-domain-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
          document.getElementById('domainAction').value = 'update_domain';
          document.getElementById('domainId').value = btn.getAttribute('data-id');
          document.getElementById('domainCode').value = btn.getAttribute('data-code');
          document.getElementById('domainName').value = btn.getAttribute('data-name');
          document.getElementById('domainDescription').value = btn.getAttribute('data-description');
          document.getElementById('domainSort').value = btn.getAttribute('data-sort') || '0';
          document.getElementById('domainActive').checked = btn.getAttribute('data-active') === '1';
          document.getElementById('domainModalLabel').textContent = 'Edit Domain';
          bootstrap.Modal.getOrCreateInstance(domainModalEl).show();
        });
      });

      // ------------------------- Skill Modal -------------------------
      var skillModalEl = document.getElementById('skillModal');

      function openSkillModal(action, domainId) {
        document.getElementById('skillForm').reset();
        document.getElementById('skillAction').value = action;
        document.getElementById('skillId').value = '';
        document.getElementById('skillSort').value = '0';
        document.getElementById('skillActive').checked = true;
        if (domainId > 0) {
          document.getElementById('skillDomain').value = String(domainId);
        }
        document.getElementById('skillModalLabel').textContent = 'Add Skill';
        bootstrap.Modal.getOrCreateInstance(skillModalEl).show();
      }

      // "+ Add Skill": open modal in create mode (prefiltered domain)
      var addSkillBtn = document.getElementById('addSkillBtn');
      var skillFilterSelect = document.getElementById('skillFilterSelect');
      if (addSkillBtn) {
        addSkillBtn.addEventListener('click', function () {
          var preselect = (skillFilterSelect && parseInt(skillFilterSelect.value, 10) > 0)
            ? parseInt(skillFilterSelect.value, 10) : 0;
          openSkillModal('add_skill', preselect);
        });
      }

      // "Add Skill" per-domain button in the domains table
      document.querySelectorAll('.add-skill-for-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
          openSkillModal('add_skill', parseInt(btn.getAttribute('data-domain-id'), 10) || 0);
        });
      });

      // "Edit" skill: populate modal from data-* attributes
      document.querySelectorAll('.edit-skill-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
          document.getElementById('skillAction').value = 'update_skill';
          document.getElementById('skillId').value = btn.getAttribute('data-id');
          document.getElementById('skillDomain').value = btn.getAttribute('data-domain-id');
          document.getElementById('skillCode').value = btn.getAttribute('data-code');
          document.getElementById('skillDescription').value = btn.getAttribute('data-description');
          document.getElementById('skillSort').value = btn.getAttribute('data-sort') || '0';
          document.getElementById('skillActive').checked = btn.getAttribute('data-active') === '1';
          document.getElementById('skillModalLabel').textContent = 'Edit Skill';
          bootstrap.Modal.getOrCreateInstance(skillModalEl).show();
        });
      });
    });
  </script>

</body>

</html>
