<?php
session_start();

// Auth guard: Super Admin only (role_id = 4)
if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 4) {
    header('Location: ../login.php');
    exit;
}

require_once __DIR__ . '/../api/shared/db_connect.php';
require_once __DIR__ . '/../includes/breadcrumb.php';
require_once __DIR__ . '/../includes/get_active_year.php';

$activeYear = getActiveYear($pdo);
$viewYearId = $activeYear ? (int) $activeYear['id'] : 0;
$viewYearLabel = $activeYear ? (string) $activeYear['year_label'] : '';

// Terms are always shown for the active academic year.
$terms = [];
if ($activeYear !== null) {
    $termStmt = $pdo->prepare("
        SELECT id, academic_year_id, term_number, term_label, term_type,
               start_date, end_date, is_active, is_closed
        FROM tblconfig_terms
        WHERE academic_year_id = ?
        ORDER BY term_number ASC
    ");
    $termStmt->execute([$viewYearId]);
    $terms = $termStmt->fetchAll(PDO::FETCH_ASSOC);
}

// Flash message
$flashMessage = '';
$flashType = 'success';
$msg = (string)($_GET['msg'] ?? '');
if ($msg === 'saved') {
    $flashMessage = 'Term saved successfully.';
    $flashType = 'success';
} elseif ($msg === 'error') {
    $flashMessage = 'Failed to save term. Please try again.';
    $flashType = 'danger';
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>STSN Grading System | Terms Configuration</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <meta name="color-scheme" content="light dark" />
  <meta name="theme-color" content="#8B1A1A" media="(prefers-color-scheme: light)" />
  <meta name="theme-color" content="#8B1A1A" />

  <link rel="preload" href="../css/adminlte.css" as="style" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css" crossorigin="anonymous" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css" crossorigin="anonymous" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css" crossorigin="anonymous" />

  <link rel="stylesheet" href="../css/adminlte.css" />
  <link rel="stylesheet" href="../css/dark-mode.css" />
  <link rel="stylesheet" href="../css/admin-responsive.css" />
  <link rel="stylesheet" href="../css/system-alerts.css" />
  <link rel="stylesheet" href="../css/superadmin-theme.css" />

  <style>
    .tc-term-type { text-transform: uppercase; letter-spacing: 0.03em; }
    .tc-actions { white-space: nowrap; }
    .tc-empty i { font-size: 1.4rem; opacity: .55; }
  </style>

  <script src="../js/theme.js" defer></script>
</head>

<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">

  <div class="app-wrapper">
    <?php
    include_once '../includes/header.php';
    include_once '../includes/sAdmin_sidebar.php';
    ?>

    <main class="app-main">

      <div class="app-content-header"></div>
      <div class="app-content">
        <div class="container-fluid p-4">

          <!-- Page Header Banner -->
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3 p-4 text-white sa-page-header">
            <div class="d-flex align-items-center gap-3">
              <i class="bi bi-calendar3" style="font-size:1.5rem;"></i>
              <div>
                <h1 class="mb-0" style="font-size:1.5rem; font-weight:600;">Terms Configuration</h1>
                <p class="mb-0" style="font-size:0.85rem; opacity:0.85;">Configure term dates and settings per academic year</p>
              </div>
            </div>
          </div>

          <!-- Breadcrumb -->
          <?php renderBreadcrumb([
            ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'],
            ['label' => 'System Configuration', 'href' => '#', 'icon' => 'bi bi-sliders'],
            ['label' => 'Terms', 'icon' => 'bi bi-calendar3'],
          ]); ?>

          <?php if ($flashMessage !== ''): ?>
            <div data-sa-flash="<?= htmlspecialchars($flashType) ?>"
                 data-sa-flash-message="<?= htmlspecialchars($flashMessage) ?>"
                 style="display:none"></div>
          <?php endif; ?>

          <!-- Terms list -->
          <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
              <h5 class="mb-0">Terms for S.Y. <?= htmlspecialchars($viewYearLabel !== '' ? $viewYearLabel : '—') ?></h5>
              <button type="button" class="btn btn-add-term btn-primary"
                      <?= $activeYear === null ? 'disabled title="Activate an academic year first"' : '' ?>
                      onclick="openAddTermModal()">
                <i class="bi bi-plus-circle me-2"></i>Add Term
              </button>
            </div>
            <div class="card-body p-0">
              <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                  <thead>
                    <tr>
                      <th style="width:60px;">#</th>
                      <th>Term Label</th>
                      <th>Type</th>
                      <th>Status</th>
                      <th style="width:220px;">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php if (empty($terms)): ?>
                    <tr>
                      <td colspan="5" class="text-center py-4 text-muted tc-empty">
                        <i class="bi bi-calendar-x d-block mb-2"></i>
                        No terms configured for this year.
                      </td>
                    </tr>
                  <?php else: foreach ($terms as $i => $t): ?>
                    <tr>
                      <td><?= $i + 1 ?></td>
                      <td><strong><?= htmlspecialchars($t['term_label']) ?></strong></td>
                      <td><span class="badge bg-secondary tc-term-type"><?= htmlspecialchars($t['term_type']) ?></span></td>
                      <td>
                        <?php if ((int)$t['is_closed'] === 1): ?>
                          <span class="badge bg-secondary"><i class="bi bi-lock-fill me-1"></i>Closed</span>
                        <?php elseif ((int)$t['is_active'] === 1): ?>
                          <span class="badge bg-success"><i class="bi bi-check-circle-fill me-1"></i>Active</span>
                        <?php else: ?>
                          <span class="badge bg-light text-dark">Upcoming</span>
                        <?php endif; ?>
                      </td>
                      <td class="tc-actions">
                        <button type="button" class="btn btn-sm btn-outline-primary me-1"
                                onclick='openEditTermModal(<?= htmlspecialchars(json_encode($t), ENT_QUOTES, 'UTF-8') ?>)'>
                          <i class="bi bi-pencil-square"></i> Edit
                        </button>
                        <?php if ((int)$t['is_closed'] !== 1): ?>
                          <button type="button" class="btn btn-sm btn-outline-warning"
                                  onclick="toggleTerm(<?= (int)$t['id'] ?>, <?= (int)$t['is_active'] ?>)">
                            <i class="bi bi-arrow-repeat"></i>
                            <?= (int)$t['is_active'] === 1 ? 'Deactivate' : 'Activate' ?>
                          </button>
                        <?php endif; ?>
                      </td>
                    </tr>
                  <?php endforeach; endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
      </div>

    </main>

    <?php include_once '../includes/footer.php'; ?>
  </div>

  <!-- Add / Edit Term Modal -->
  <div class="modal fade" id="termModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <form method="POST" action="../api/terms/save.php" id="termForm">
          <div class="modal-header">
            <h5 class="modal-title" id="termModalTitle">Add Term</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <input type="hidden" name="action" id="termAction" value="create">
            <input type="hidden" name="id" id="termId" value="">
            <input type="hidden" name="academic_year_id" value="<?= $viewYearId ?>">

            <div class="mb-3">
              <label class="form-label" for="termLabel">Term Label *</label>
              <input type="text" class="form-control" name="term_label" id="termLabel" required maxlength="50" placeholder="e.g. 1st Term">
            </div>

            <div class="mb-3">
              <label class="form-label" for="termType">Term Type *</label>
              <select class="form-select" name="term_type" id="termType" required>
                <option value="TRIMESTER">Trimester</option>
                <option value="QUARTER">Quarter</option>
                <option value="SEMESTER">Semester</option>
              </select>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary">Save Term</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>
  <script src="../js/adminlte.js"></script>
  <script src="../js/system-alerts.js"></script>
  <script src="../js/superadmin-alerts.js"></script>

  <script>
    function openAddTermModal() {
      document.getElementById('termForm').reset();
      document.getElementById('termAction').value = 'create';
      document.getElementById('termId').value = '';
      document.getElementById('termLabel').value = '';
      document.getElementById('termType').value = 'TRIMESTER';
      document.getElementById('termModalTitle').textContent = 'Add Term';
      new bootstrap.Modal(document.getElementById('termModal')).show();
    }

    function openEditTermModal(term) {
      document.getElementById('termAction').value = 'update';
      document.getElementById('termId').value = term.id;
      document.getElementById('termLabel').value = term.term_label;
      document.getElementById('termType').value = term.term_type;
      document.getElementById('termModalTitle').textContent = 'Edit Term';
      new bootstrap.Modal(document.getElementById('termModal')).show();
    }

    function toggleTerm(termId, currentState) {
      var action = Number(currentState) === 1 ? 'deactivate' : 'activate';
      if (!confirm('Are you sure you want to ' + action + ' this term?')) return;

      var form = document.createElement('form');
      form.method = 'POST';
      form.action = '../api/terms/save.php';
      form.innerHTML = '<input type="hidden" name="action" value="toggle">' +
                       '<input type="hidden" name="id" value="' + termId + '">';
      document.body.appendChild(form);
      form.submit();
    }
  </script>
</body>

</html>
