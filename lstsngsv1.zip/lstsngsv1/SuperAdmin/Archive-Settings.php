<?php
session_start();

// Auth guard: must be logged in as Super Admin (role_id = 4)
if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 4) {
    header('Location: ../login.php');
    exit;
}

require_once __DIR__ . '/../api/shared/db_connect.php';
require_once __DIR__ . '/../includes/breadcrumb.php';

/* ----------------------------- POST handlers (PRG) ----------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');

    if ($action === 'save_settings') {
        $mode = strtoupper(trim((string)($_POST['mode'] ?? '')));
        if (!in_array($mode, ['AUTO', 'MANUAL'], true)) {
            $mode = 'AUTO';
        }
        $stmt = $pdo->prepare("
            UPDATE tblarchive_settings
            SET mode = ?,
                auto_term_lock = ?,
                auto_year_promote = ?,
                fallback_dashboard_check = ?,
                notify_on_archive = ?,
                updated_by = ?
            WHERE id = 1
        ");
        $stmt->execute([
            $mode,
            isset($_POST['auto_term_lock']) ? 1 : 0,
            isset($_POST['auto_year_promote']) ? 1 : 0,
            isset($_POST['fallback_dashboard_check']) ? 1 : 0,
            isset($_POST['notify_on_archive']) ? 1 : 0,
            (int)($_SESSION['user_id'] ?? 0),
        ]);
        header('Location: Archive-Settings.php?msg=saved');
        exit;
    }

    header('Location: Archive-Settings.php?msg=saved');
    exit;
}

/* ----------------------------- Settings row (self-healing) ----------------------------- */
$settings = $pdo->query("SELECT * FROM tblarchive_settings WHERE id = 1")
    ->fetch(PDO::FETCH_ASSOC);
if (!$settings) {
    $pdo->exec("INSERT INTO tblarchive_settings (id, mode) VALUES (1, 'AUTO')");
    $settings = $pdo->query("SELECT * FROM tblarchive_settings WHERE id = 1")->fetch();
}

/* ----------------------------- Flash messages ----------------------------- */
$flashMap = [
    'saved'             => ['Archive settings saved successfully.', 'success'],
];
$msgKey = (string)($_GET['msg'] ?? '');
if ($msgKey !== '' && isset($flashMap[$msgKey])) {
    [$flashMessage, $flashType] = $flashMap[$msgKey];
} else {
    $flashMessage = '';
    $flashType    = 'success';
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>STSN Grading System | Archive Settings</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <meta name="color-scheme" content="light dark" />
  <meta name="theme-color" content="#8B1A1A" media="(prefers-color-scheme: light)" />
  <meta name="theme-color" content="#8B1A1A" />
  <meta name="title" content="STSN | Archive Settings" />
  <meta name="author" content="G" />
  <meta name="description"
    content="STSN Grading System - A modern and accessible Bootstrap 5-based grading and student management platform for Schools. Secure, fast, and WCAG 2.1 AA compliant." />
  <meta name="supported-color-schemes" content="light dark" />
  <link rel="preload" href="../css/adminlte.css" as="style" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
    integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
    onload="this.media='all'" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="../css/adminlte.css" />
  <link rel="stylesheet" href="../css/dark-mode.css" />
  <link rel="stylesheet" href="../css/admin-responsive.css" />
  <link rel="stylesheet" href="../css/system-alerts.css" />
  <link rel="stylesheet" href="../css/superadmin-theme.css" />

  <style>
    .as-card {
      background: #fff;
      border: 1px solid var(--border, #E9ECEF);
      border-radius: 14px;
      box-shadow: 0 4px 12px rgba(10,47,68,0.06);
      margin-bottom: 1.25rem;
      overflow: hidden;
    }
    .as-card-header {
      padding: 1rem 1.25rem;
      border-bottom: 1px solid var(--border, #E9ECEF);
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 1rem;
      flex-wrap: wrap;
    }
    .as-card-title {
      font-size: 1.05rem;
      font-weight: 800;
      color: var(--primary, #0A2F44);
      display: flex;
      align-items: center;
      gap: 0.5rem;
      flex-wrap: wrap;
    }
    .as-card-title i { color: #C5A028; }
    .as-card-desc {
      font-size: 0.82rem;
      color: var(--muted, #6C757D);
      margin-top: 4px;
    }
    .as-card-body { padding: 1.25rem; }
    .as-help { font-size: 0.8rem; color: var(--muted, #6C757D); }
    .as-mode-option {
      border: 1px solid var(--border, #E9ECEF);
      border-radius: 10px;
      padding: 0.85rem 1rem;
      display: flex;
      gap: 0.65rem;
      align-items: flex-start;
    }
    .as-mode-option input[type="radio"] { margin-top: 0.2rem; }
    .as-toggle-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 1rem;
      padding: 0.65rem 0;
      border-bottom: 1px solid var(--border, #E9ECEF);
    }
    .as-toggle-row:last-child { border-bottom: none; }

    /* Dark mode support */
     [data-bs-theme="dark"] .as-card { background: #1a1d21; border-color: #2b3035; } 
 [data-bs-theme="dark"] .as-card-header { border-bottom-color: #2b3035; } 
 [data-bs-theme="dark"] .as-card-title { color: #e9ecef; } 
 [data-bs-theme="dark"] .as-mode-option { border-color: #2b3035; } 
 [data-bs-theme="dark"] .as-toggle-row { border-bottom-color: #2b3035; } 

  </style>

  <script src="../js/theme.js" defer></script>
</head>
<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">

  <div class="app-wrapper">
    <?php
    include_once '../includes/header.php';
    include_once '../includes/sAdmin_sidebar.php';
    ?>

    <main class="app-main">

      <div class="app-content-header">
      </div>
      <div class="app-content">
        <div class="container-fluid p-4">

          <!-- Page Header Banner -->
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3 p-4 text-white sa-page-header">
            <div class="d-flex align-items-center gap-3">
              <i class="bi bi-archive-fill" style="font-size:1.5rem;"></i>
              <div>
                <h1 class="mb-0" style="font-size:1.5rem; font-weight:600;">Archive Settings</h1>
                <p class="mb-0" style="font-size:0.85rem; opacity:0.85;">Configure automatic and manual archive behavior</p>
              </div>
            </div>
          </div>

          <!-- Breadcrumb -->
          <?php renderBreadcrumb([
            ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'],
            ['label' => 'System Settings', 'href' => '#', 'icon' => 'bi bi-gear'],
            ['label' => 'Archive Settings', 'icon' => 'bi bi-archive-fill'],
          ]); ?>

          <?php if ($flashMessage !== ''): ?>
            <div data-sa-flash="<?= htmlspecialchars($flashType) ?>"
                 data-sa-flash-message="<?= htmlspecialchars($flashMessage) ?>"
                 style="display:none"></div>
          <?php endif; ?>
          <?php $mode = (string)($settings['mode'] ?? 'AUTO'); ?>
          <form method="post" action="Archive-Settings.php">
            <input type="hidden" name="action" value="save_settings">

            <!-- Card 1: Archive Mode -->
            <div class="as-card">
              <div class="as-card-header">
                <div>
                  <div class="as-card-title"><i class="bi bi-gear-fill"></i> Archive Mode</div>
                  <div class="as-card-desc">Choose how school years are archived and locked.</div>
                </div>
                <button type="submit" class="btn btn-primary">
                  <i class="bi bi-check-lg me-1"></i> Save
                </button>
              </div>
              <div class="as-card-body">
                <div class="row g-3">
                  <div class="col-md-6">
                    <label class="as-mode-option">
                      <input class="form-check-input mt-0" type="radio" name="mode" value="AUTO"
                             <?= $mode === 'AUTO' ? 'checked' : '' ?>>
                      <span>
                        <span class="fw-bold">AUTO <span class="badge bg-success ms-1">Recommended</span></span>
                        <div class="as-help">The system automatically archives a finished academic year: locks grades at
                          term end, promotes students, freezes the year&rsquo;s grading configuration, and stores records
                          in the archive &mdash; driven by the daily cron check.</div>
                      </span>
                    </label>
                  </div>
                  <div class="col-md-6">
                    <label class="as-mode-option">
                      <input class="form-check-input mt-0" type="radio" name="mode" value="MANUAL"
                             <?= $mode === 'MANUAL' ? 'checked' : '' ?>>
                      <span>
                        <span class="fw-bold">MANUAL</span>
                        <div class="as-help">Nothing happens automatically. An administrator triggers the archive
                          from this panel when the school year is confirmed finished. Term-end locks are also applied
                          manually.</div>
                      </span>
                    </label>
                  </div>
                </div>
              </div>
            </div>

            <!-- Card 2: Auto Settings (AUTO mode only) -->
            <div class="as-card" id="autoCard" style="<?= $mode === 'AUTO' ? '' : 'display:none;' ?>">
              <div class="as-card-header">
                <div>
                  <div class="as-card-title"><i class="bi bi-toggles"></i> Auto Settings</div>
                  <div class="as-card-desc">Only used while <strong>AUTO</strong> mode is selected.</div>
                </div>
              </div>
              <div class="as-card-body">
                <div class="as-toggle-row">
                  <div>
                    <div class="fw-semibold">Auto-lock at term end</div>
                    <div class="as-help">Marks a term&rsquo;s grades read-only (<code>tblgrades.is_locked</code>) once the term end date passes.</div>
                  </div>
                  <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" role="switch" id="tglTermLock" name="auto_term_lock"
                           <?= !empty($settings['auto_term_lock']) ? 'checked' : '' ?>>
                  </div>
                </div>
                <div class="as-toggle-row">
                  <div>
                    <div class="fw-semibold">Auto-promote at year end</div>
                    <div class="as-help">Promotes students to the next grade level when the academic year is archived.</div>
                  </div>
                  <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" role="switch" id="tglYearPromote" name="auto_year_promote"
                           <?= !empty($settings['auto_year_promote']) ? 'checked' : '' ?>>
                  </div>
                </div>
                <div class="as-toggle-row">
                  <div>
                    <div class="fw-semibold">Fallback dashboard check</div>
                    <div class="as-help">Runs the archive check on dashboard load when the cron job has not fired recently.</div>
                  </div>
                  <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" role="switch" id="tglFallback" name="fallback_dashboard_check"
                           <?= !empty($settings['fallback_dashboard_check']) ? 'checked' : '' ?>>
                  </div>
                </div>
                <div class="as-toggle-row">
                  <div>
                    <div class="fw-semibold">Send notification on archive</div>
                    <div class="as-help">Notifies administrators whenever an archive action completes.</div>
                  </div>
                  <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" role="switch" id="tglNotify" name="notify_on_archive"
                           <?= !empty($settings['notify_on_archive']) ? 'checked' : '' ?>>
                  </div>
                </div>
              </div>
            </div>
          </form>

        </div>
      </div>

    </main>

    <?php
    include_once '../includes/footer.php';
    ?>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>

  <script src="../js/adminlte.js"></script>

  <script src="../js/system-alerts.js"></script>
  <script src="../js/superadmin-alerts.js"></script>

  <script>
    document.addEventListener('DOMContentLoaded', function () {
      // Auto-dismiss flash messages after 4s
      document.querySelectorAll('.alert-dismissible').forEach(function (alertEl) {
        setTimeout(function () {
          if (window.bootstrap && bootstrap.Alert) {
            bootstrap.Alert.getOrCreateInstance(alertEl).close();
          }
        }, 4000);
      });

      // Card 2 visible only when AUTO mode is selected
      var autoCard = document.getElementById('autoCard');
      var modeRadios = document.querySelectorAll('input[name="mode"]');
      if (autoCard && modeRadios.length) {
        function syncAutoCard() {
          var selected = document.querySelector('input[name="mode"]:checked');
          autoCard.style.display = (selected && selected.value === 'AUTO') ? '' : 'none';
        }
        modeRadios.forEach(function (radio) {
          radio.addEventListener('change', syncAutoCard);
        });
        syncAutoCard();
      }
    });
  </script>
</body>

</html>