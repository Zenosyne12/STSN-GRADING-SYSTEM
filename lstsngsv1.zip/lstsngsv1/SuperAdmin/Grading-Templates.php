<?php
session_start();

// Auth guard: must be logged in as Super Admin (role_id = 4)
if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 4) {
    header('Location: ../login.php');
    exit;
}

require_once __DIR__ . '/../api/shared/db_connect.php';
require_once __DIR__ . '/../includes/breadcrumb.php';

$roundingRuleOptions = ['ROUND', 'CEIL', 'FLOOR'];
$remarksOptions      = ['Passed', 'Failed'];
$gradingTypeOptions  = ['NUMERICAL', 'DESCRIPTIVE', 'KINDERGARTEN'];

// Active tab (PRG-safe: GET uses ?tab=, POST forms carry a hidden "tab" field)
// TRANSMUTATION TAB HIDDEN: 'transmutation' removed from valid tabs (falls back to 'templates').
// To restore: add 'transmutation' back here and uncomment the 3 blocks marked "TRANSMUTATION (HIDDEN)" below.
$validTabs = ['templates', 'transmutation', 'descriptors'];
$activeTab = (string)($_GET['tab'] ?? ($_POST['tab'] ?? 'templates'));
if (!in_array($activeTab, $validTabs, true)) {
    $activeTab = 'templates';
}
$transTemplateFilter = max(0, (int)($_GET['template_id'] ?? 0));
$descTypeFilter = strtoupper(trim((string)($_GET['filter_type'] ?? ($_POST['filter_type'] ?? ''))));
if (!in_array($descTypeFilter, $gradingTypeOptions, true)) {
    $descTypeFilter = '';
}

function gtRedirect(string $msg, string $tab, int $templateId = 0, string $descType = ''): void
{
    $url = 'Grading-Templates.php?msg=' . urlencode($msg) . '&tab=' . urlencode($tab);
    if ($templateId > 0) {
        $url .= '&template_id=' . $templateId;
    }
    if ($descType !== '') {
        $url .= '&filter_type=' . urlencode($descType);
    }
    header('Location: ' . $url);
    exit;
}

function gtFetchTemplate(PDO $pdo, int $id): ?array
{
    if ($id <= 0) {
        return null;
    }
    $stmt = $pdo->prepare('SELECT * FROM tblgrading_template WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row === false ? null : $row;
}

function gtFetchTransmutation(PDO $pdo, int $id): ?array
{
    if ($id <= 0) {
        return null;
    }
    $stmt = $pdo->prepare('SELECT * FROM tbltransmutation WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row === false ? null : $row;
}

function gtFetchDescriptor(PDO $pdo, int $id): ?array
{
    if ($id <= 0) {
        return null;
    }
    $stmt = $pdo->prepare('SELECT * FROM tbldescriptors WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row === false ? null : $row;
}

/**
 * Pretty number: trims trailing zeroes — 40.00 -> "40", 40.50 -> "40.5".
 */
function gtNum(float $value): string
{
    $formatted = rtrim(rtrim(number_format($value, 2, '.', ''), '0'), '.');
    return $formatted === '' ? '0' : $formatted;
}
?>
<?php

function gtValidateTemplateInput(array $post, array $roundingRuleOptions): array
{
    $name = trim((string)($post['template_name'] ?? ''));
    if ($name === '' || mb_strlen($name) > 100) {
        return [false, 'error_name'];
    }
    $description = trim((string)($post['description'] ?? ''));

    $weights   = [];
    $weightSum = 0.0;
    foreach (['ww' => 'ww_weight', 'pt' => 'pt_weight', 'qa' => 'qa_weight'] as $component => $field) {
        $raw = trim((string)($post[$field] ?? ''));
        if ($raw === '' || !is_numeric($raw)) {
            return [false, 'error_weights'];
        }
        $value = round((float)$raw, 2);
        if ($value < 0 || $value > 100) {
            return [false, 'error_weights'];
        }
        $weights[$component] = $value;
        $weightSum += $value;
    }
    if (abs($weightSum - 100) > 0.005) {
        return [false, 'error_weights'];
    }

    $thresholdRaw = trim((string)($post['passing_threshold'] ?? ''));
    if ($thresholdRaw === '' || !ctype_digit($thresholdRaw)) {
        return [false, 'error_threshold'];
    }
    $passingThreshold = (int)$thresholdRaw;
    if ($passingThreshold < 1 || $passingThreshold > 100) {
        return [false, 'error_threshold'];
    }

    $roundingRule = strtoupper(trim((string)($post['rounding_rule'] ?? 'ROUND')));
    if ($roundingRule === '') {
        $roundingRule = 'ROUND';
    }
    if (!in_array($roundingRule, $roundingRuleOptions, true)) {
        return [false, 'error_rounding'];
    }

    $gradeFromRaw = trim((string)($post['applies_to_grade_from'] ?? ''));
    $gradeToRaw   = trim((string)($post['applies_to_grade_to'] ?? ''));
    $gradeFrom = ($gradeFromRaw !== '' && ctype_digit($gradeFromRaw)) ? (int)$gradeFromRaw : null;
    $gradeTo   = ($gradeToRaw   !== '' && ctype_digit($gradeToRaw))   ? (int)$gradeToRaw   : null;
    if (($gradeFromRaw !== '' && $gradeFrom === null) || ($gradeToRaw !== '' && $gradeTo === null)) {
        return [false, 'error_grade'];
    }
    if ($gradeFrom !== null && ($gradeFrom < 1 || $gradeFrom > 12)) {
        return [false, 'error_grade'];
    }
    if ($gradeTo !== null && ($gradeTo < 1 || $gradeTo > 12)) {
        return [false, 'error_grade'];
    }
    if ($gradeFrom !== null && $gradeTo !== null && $gradeFrom > $gradeTo) {
        return [false, 'error_grade'];
    }
    return [true, [
        'template_name'         => $name,
        'description'           => $description !== '' ? $description : null,
        'ww_weight'             => $weights['ww'],
        'pt_weight'             => $weights['pt'],
        'qa_weight'             => $weights['qa'],
        'passing_threshold'     => $passingThreshold,
        'rounding_rule'         => $roundingRule,
        'applies_to_grade_from' => $gradeFrom,
        'applies_to_grade_to'   => $gradeTo,
    ]];
}
?>
<?php

function gtValidateTransmutationInput(array $post): array
{
    $minRaw = trim((string)($post['min_initial'] ?? ''));
    $maxRaw = trim((string)($post['max_initial'] ?? ''));
    if ($minRaw === '' || $maxRaw === '' || !is_numeric($minRaw) || !is_numeric($maxRaw)) {
        return [false, 'error_trans_invalid'];
    }
    $minInitial = round((float)$minRaw, 2);
    $maxInitial = round((float)$maxRaw, 2);
    if ($minInitial < 0 || $minInitial > 100 || $maxInitial < 0 || $maxInitial > 100 || $minInitial > $maxInitial) {
        return [false, 'error_trans_invalid'];
    }
    $gradeRaw = trim((string)($post['transmuted_grade'] ?? ''));
    if ($gradeRaw === '' || !ctype_digit($gradeRaw)) {
        return [false, 'error_trans_invalid'];
    }
    $transmutedGrade = (int)$gradeRaw;
    if ($transmutedGrade < 60 || $transmutedGrade > 100) {
        return [false, 'error_trans_invalid'];
    }
    $descriptor = trim((string)($post['descriptor'] ?? ''));
    if (mb_strlen($descriptor) > 50) {
        return [false, 'error_trans_invalid'];
    }
    return [true, [
        'min_initial'      => $minInitial,
        'max_initial'      => $maxInitial,
        'transmuted_grade' => $transmutedGrade,
        'descriptor'       => $descriptor !== '' ? $descriptor : null,
    ]];
}

function gtValidateDescriptorInput(array $post, array $remarksOptions, array $gradingTypeOptions): array
{
    $gradingType = strtoupper(trim((string)($post['grading_type'] ?? '')));
    if (!in_array($gradingType, $gradingTypeOptions, true)) {
        return [false, 'error_descriptor_invalid'];
    }

    $fromRaw = trim((string)($post['grade_from'] ?? ''));
    $toRaw   = trim((string)($post['grade_to'] ?? ''));
    $codeRaw = strtoupper(trim((string)($post['rating_code'] ?? '')));
    if ($gradingType === 'NUMERICAL') {
        if ($fromRaw === '' || $toRaw === '' || !ctype_digit($fromRaw) || !ctype_digit($toRaw)) {
            return [false, 'error_descriptor_invalid'];
        }
        $gradeFrom = (int)$fromRaw;
        $gradeTo   = (int)$toRaw;
        if ($gradeFrom < 0 || $gradeFrom > 100 || $gradeTo < 0 || $gradeTo > 100 || $gradeFrom > $gradeTo) {
            return [false, 'error_descriptor_invalid'];
        }
        $ratingCode = null;
    } else {
        if ($codeRaw === '' || mb_strlen($codeRaw) > 5) {
            return [false, 'error_descriptor_invalid'];
        }
        $ratingCode = $codeRaw;
        $gradeFrom  = null;
        $gradeTo    = null;
    }

    $descriptor = trim((string)($post['descriptor'] ?? ''));
    if ($descriptor === '' || mb_strlen($descriptor) > 50) {
        return [false, 'error_descriptor_invalid'];
    }
    $remarks = trim((string)($post['remarks'] ?? ''));
    if (!in_array($remarks, $remarksOptions, true)) {
        return [false, 'error_descriptor_invalid'];
    }
    $levelFromRaw = trim((string)($post['applies_to_grade_level_from'] ?? ''));
    $levelToRaw   = trim((string)($post['applies_to_grade_level_to'] ?? ''));
    $levelFrom = ($levelFromRaw !== '' && ctype_digit($levelFromRaw)) ? (int)$levelFromRaw : null;
    $levelTo   = ($levelToRaw   !== '' && ctype_digit($levelToRaw))   ? (int)$levelToRaw   : null;
    if (($levelFromRaw !== '' && $levelFrom === null) || ($levelToRaw !== '' && $levelTo === null)) {
        return [false, 'error_descriptor_invalid'];
    }
    if ($levelFrom !== null && ($levelFrom < 1 || $levelFrom > 12)) {
        return [false, 'error_descriptor_invalid'];
    }
    if ($levelTo !== null && ($levelTo < 1 || $levelTo > 12)) {
        return [false, 'error_descriptor_invalid'];
    }
    if ($levelFrom !== null && $levelTo !== null && $levelFrom > $levelTo) {
        return [false, 'error_descriptor_invalid'];
    }
    return [true, [
        'grading_type'                => $gradingType,
        'rating_code'                 => $ratingCode,
        'grade_from'                  => $gradeFrom,
        'grade_to'                    => $gradeTo,
        'descriptor'                  => $descriptor,
        'remarks'                     => $remarks,
        'applies_to_grade_level_from' => $levelFrom,
        'applies_to_grade_level_to'   => $levelTo,
    ]];
}
?>
<?php
/* POST handlers (PRG pattern) */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');
    $userId = (int)($_SESSION['user_id'] ?? 0);

    try {
        if ($action === 'create_template') {
            [$ok, $result] = gtValidateTemplateInput($_POST, $roundingRuleOptions);
            if (!$ok) { gtRedirect($result, $activeTab, $transTemplateFilter); }
            $pdo->prepare(
                'INSERT INTO tblgrading_template
                    (template_name, description, ww_weight, pt_weight, qa_weight,
                     passing_threshold, rounding_rule, applies_to_grade_from,
                     applies_to_grade_to, is_default, is_active, created_by)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 1, ?)'
            )->execute([
                $result['template_name'], $result['description'],
                $result['ww_weight'], $result['pt_weight'], $result['qa_weight'],
                $result['passing_threshold'], $result['rounding_rule'],
                $result['applies_to_grade_from'], $result['applies_to_grade_to'], $userId,
            ]);
            gtRedirect('template_created', 'templates', $transTemplateFilter);
        }

        if ($action === 'update_template') {
            $templateId = (int)($_POST['id'] ?? 0);
            $existing = gtFetchTemplate($pdo, $templateId);
            if ($existing === null) { gtRedirect('error_template_not_found', $activeTab, $transTemplateFilter); }
            [$ok, $result] = gtValidateTemplateInput($_POST, $roundingRuleOptions);
            if (!$ok) { gtRedirect($result, $activeTab, $transTemplateFilter); }
            $pdo->prepare(
                'UPDATE tblgrading_template
                 SET template_name = ?, description = ?, ww_weight = ?, pt_weight = ?, qa_weight = ?,
                     passing_threshold = ?, rounding_rule = ?,
                     applies_to_grade_from = ?, applies_to_grade_to = ?
                 WHERE id = ?'
            )->execute([
                $result['template_name'], $result['description'],
                $result['ww_weight'], $result['pt_weight'], $result['qa_weight'],
                $result['passing_threshold'], $result['rounding_rule'],
                $result['applies_to_grade_from'], $result['applies_to_grade_to'], $templateId,
            ]);
            gtRedirect('template_updated', 'templates', $transTemplateFilter);
        }

        if ($action === 'set_default') {
            $templateId = (int)($_POST['id'] ?? 0);
            $existing = gtFetchTemplate($pdo, $templateId);
            if ($existing === null) { gtRedirect('error_template_not_found', $activeTab, $transTemplateFilter); }
            $pdo->beginTransaction();
            $pdo->prepare('UPDATE tblgrading_template SET is_default = 0 WHERE id <> ?')->execute([$templateId]);
            $pdo->prepare('UPDATE tblgrading_template SET is_default = 1, is_active = 1 WHERE id = ?')->execute([$templateId]);
            $pdo->commit();
            gtRedirect('default_set', 'templates', $transTemplateFilter);
        }

        if ($action === 'toggle_template') {
            $templateId = (int)($_POST['id'] ?? 0);
            $existing = gtFetchTemplate($pdo, $templateId);
            if ($existing === null) { gtRedirect('error_template_not_found', $activeTab, $transTemplateFilter); }
            $newState = ((int)$existing['is_active'] === 1) ? 0 : 1;
            $pdo->prepare('UPDATE tblgrading_template SET is_active = ? WHERE id = ?')->execute([$newState, $templateId]);
            gtRedirect('template_toggled', 'templates', $transTemplateFilter);
        }

        if ($action === 'delete_template') {
            $templateId = (int)($_POST['id'] ?? 0);
            $existing = gtFetchTemplate($pdo, $templateId);
            if ($existing === null) { gtRedirect('error_template_not_found', $activeTab, $transTemplateFilter); }
            if ((int)$existing['is_default'] === 1) { gtRedirect('error_default_protected', $activeTab, $transTemplateFilter); }
            $pdo->beginTransaction();
            $pdo->prepare('DELETE FROM tbltransmutation WHERE template_id = ?')->execute([$templateId]);
            $pdo->prepare('DELETE FROM tblgrading_template WHERE id = ?')->execute([$templateId]);
            $pdo->commit();
            gtRedirect('template_deleted', 'templates', 0);
        }

        if ($action === 'add_transmutation') {
            $templateId = (int)($_POST['template_id'] ?? 0);
            $existing = gtFetchTemplate($pdo, $templateId);
            if ($existing === null) { gtRedirect('error_template_not_found', 'transmutation', $transTemplateFilter); }
            [$ok, $result] = gtValidateTransmutationInput($_POST);
            if (!$ok) { gtRedirect($result, 'transmutation', $templateId); }
            $sortStmt = $pdo->prepare('SELECT COALESCE(MAX(sort_order), 0) + 1 FROM tbltransmutation WHERE template_id = ?');
            $sortStmt->execute([$templateId]);
            $nextSort = (int)$sortStmt->fetchColumn();
            $pdo->prepare(
                'INSERT INTO tbltransmutation
                    (template_id, min_initial, max_initial, transmuted_grade, descriptor, sort_order)
                 VALUES (?, ?, ?, ?, ?, ?)'
            )->execute([
                $templateId, $result['min_initial'], $result['max_initial'],
                $result['transmuted_grade'], $result['descriptor'], $nextSort,
            ]);
            gtRedirect('transmutation_added', 'transmutation', $templateId);
        }

        if ($action === 'update_transmutation') {
            $rowId = (int)($_POST['id'] ?? 0);
            $existing = gtFetchTransmutation($pdo, $rowId);
            if ($existing === null) { gtRedirect('error_trans_not_found', 'transmutation', $transTemplateFilter); }
            [$ok, $result] = gtValidateTransmutationInput($_POST);
            if (!$ok) { gtRedirect($result, 'transmutation', (int)$existing['template_id']); }
            $pdo->prepare(
                'UPDATE tbltransmutation
                 SET min_initial = ?, max_initial = ?, transmuted_grade = ?, descriptor = ?
                 WHERE id = ?'
            )->execute([
                $result['min_initial'], $result['max_initial'],
                $result['transmuted_grade'], $result['descriptor'], $rowId,
            ]);
            gtRedirect('transmutation_updated', 'transmutation', (int)$existing['template_id']);
        }

        if ($action === 'delete_transmutation') {
            $rowId = (int)($_POST['id'] ?? 0);
            $existing = gtFetchTransmutation($pdo, $rowId);
            if ($existing === null) { gtRedirect('error_trans_not_found', 'transmutation', $transTemplateFilter); }
            $pdo->prepare('DELETE FROM tbltransmutation WHERE id = ?')->execute([$rowId]);
            gtRedirect('transmutation_deleted', 'transmutation', (int)$existing['template_id']);
        }

        if ($action === 'add_descriptor') {
            [$ok, $result] = gtValidateDescriptorInput($_POST, $remarksOptions, $gradingTypeOptions);
            if (!$ok) { gtRedirect($result, 'descriptors', $transTemplateFilter, $descTypeFilter); }
            $nextSort = (int)$pdo->query('SELECT COALESCE(MAX(sort_order), 0) + 1 FROM tbldescriptors')->fetchColumn();
            $pdo->prepare(
                'INSERT INTO tbldescriptors
                    (grade_from, grade_to, descriptor, remarks, grading_type, rating_code,
                     applies_to_grade_level_from, applies_to_grade_level_to, is_active, sort_order)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)'
            )->execute([
                $result['grade_from'], $result['grade_to'], $result['descriptor'], $result['remarks'],
                $result['grading_type'], $result['rating_code'],
                $result['applies_to_grade_level_from'], $result['applies_to_grade_level_to'], $nextSort,
            ]);
            gtRedirect('descriptor_added', 'descriptors', $transTemplateFilter, $descTypeFilter);
        }

        if ($action === 'update_descriptor') {
            $rowId = (int)($_POST['id'] ?? 0);
            $existing = gtFetchDescriptor($pdo, $rowId);
            if ($existing === null) { gtRedirect('error_descriptor_not_found', 'descriptors', $transTemplateFilter, $descTypeFilter); }
            [$ok, $result] = gtValidateDescriptorInput($_POST, $remarksOptions, $gradingTypeOptions);
            if (!$ok) { gtRedirect($result, 'descriptors', $transTemplateFilter, $descTypeFilter); }
            $pdo->prepare(
                'UPDATE tbldescriptors
                 SET grading_type = ?, rating_code = ?, grade_from = ?, grade_to = ?,
                     descriptor = ?, remarks = ?,
                     applies_to_grade_level_from = ?, applies_to_grade_level_to = ?
                 WHERE id = ?'
            )->execute([
                $result['grading_type'], $result['rating_code'], $result['grade_from'], $result['grade_to'],
                $result['descriptor'], $result['remarks'],
                $result['applies_to_grade_level_from'], $result['applies_to_grade_level_to'], $rowId,
            ]);
            gtRedirect('descriptor_updated', 'descriptors', $transTemplateFilter, $descTypeFilter);
        }

        if ($action === 'delete_descriptor') {
            $rowId = (int)($_POST['id'] ?? 0);
            $existing = gtFetchDescriptor($pdo, $rowId);
            if ($existing === null) { gtRedirect('error_descriptor_not_found', 'descriptors', $transTemplateFilter, $descTypeFilter); }
            $pdo->prepare('DELETE FROM tbldescriptors WHERE id = ?')->execute([$rowId]);
            gtRedirect('descriptor_deleted', 'descriptors', $transTemplateFilter, $descTypeFilter);
        }

        gtRedirect('error_unknown_action', $activeTab, $transTemplateFilter);
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) { $pdo->rollBack(); }
        error_log('Grading-Templates.php POST error: ' . $e->getMessage());
        gtRedirect('error_db', $activeTab, $transTemplateFilter);
    }
}
?>
<?php
// Flash message
$flashMap = [
    'template_created'           => ['Grading template created successfully.', 'success'],
    'template_updated'           => ['Grading template updated successfully.', 'success'],
    'template_deleted'           => ['Grading template and its transmutation table were deleted.', 'success'],
    'default_set'                => ['Default grading template updated.', 'success'],
    'template_toggled'           => ['Template status updated.', 'success'],
    'transmutation_added'        => ['Transmutation row added.', 'success'],
    'transmutation_updated'      => ['Transmutation row updated successfully.', 'success'],
    'transmutation_deleted'      => ['Transmutation row deleted.', 'success'],
    'descriptor_added'           => ['Descriptor added.', 'success'],
    'descriptor_updated'         => ['Descriptor updated successfully.', 'success'],
    'descriptor_deleted'         => ['Descriptor deleted.', 'success'],
    'error_name'                 => ['Template name is required and must be at most 100 characters.', 'danger'],
    'error_weights'              => ['WW, PT and QA weights must be numbers between 0 and 100 that total exactly 100.', 'danger'],
    'error_threshold'            => ['Passing threshold must be a whole number between 1 and 100.', 'danger'],
    'error_rounding'             => ['Invalid rounding rule.', 'danger'],
    'error_grade'                => ['Grade range must be between 1 and 12, and From must not exceed To.', 'danger'],
    'error_trans_invalid'        => ['Invalid transmutation values.', 'danger'],
    'error_descriptor_invalid'   => ['Invalid descriptor values.', 'danger'],
    'error_template_not_found'   => ['Grading template not found.', 'danger'],
    'error_trans_not_found'      => ['Transmutation row not found.', 'danger'],
    'error_descriptor_not_found' => ['Descriptor not found.', 'danger'],
    'error_default_protected'    => ['The default grading template cannot be deleted. Set another template as default first.', 'danger'],
    'error_db'                   => ['Database error: the operation could not be completed.', 'danger'],
    'error_unknown_action'       => ['Unknown action.', 'danger'],
];
$msgKey = (string)($_GET['msg'] ?? '');
if ($msgKey !== '' && isset($flashMap[$msgKey])) {
    [$flashMessage, $flashType] = $flashMap[$msgKey];
} else {
    $flashMessage = '';
    $flashType    = 'success';
}

// Fetch data
$templates = $pdo->query(
    'SELECT t.*,
            (SELECT COUNT(*) FROM tbltransmutation tr WHERE tr.template_id = t.id) AS transmutation_count
     FROM tblgrading_template t
     ORDER BY t.is_default DESC, t.template_name ASC, t.id ASC'
)->fetchAll(PDO::FETCH_ASSOC);

$templateNameMap = [];
foreach ($templates as $templateRow) {
    $templateNameMap[(int)$templateRow['id']] = (string)$templateRow['template_name'];
}

$transmutationRows = [];
if ($templates !== []) {
    $transSql =
        'SELECT tr.*, COALESCE(gt.template_name, "(Deleted template)") AS template_name
         FROM tbltransmutation tr
         LEFT JOIN tblgrading_template gt ON gt.id = tr.template_id';
    if ($transTemplateFilter > 0) {
        $transSql .= ' WHERE tr.template_id = ?';
    }
    $transSql .= ' ORDER BY tr.template_id ASC, tr.transmuted_grade DESC, tr.sort_order ASC, tr.id ASC';
    $transStmt = $pdo->prepare($transSql);
    $transStmt->execute($transTemplateFilter > 0 ? [$transTemplateFilter] : []);
    $transmutationRows = $transStmt->fetchAll(PDO::FETCH_ASSOC);
}

$descriptorRows = [];
$descSql = 'SELECT * FROM tbldescriptors'
    . ($descTypeFilter !== '' ? ' WHERE grading_type = ?' : '')
    . ' ORDER BY grading_type ASC, sort_order ASC, id ASC';
$descStmt = $pdo->prepare($descSql);
$descStmt->execute($descTypeFilter !== '' ? [$descTypeFilter] : []);
$descriptorRows = $descStmt->fetchAll(PDO::FETCH_ASSOC);

// Group descriptors by type
$groupedDescriptors = [
    'NUMERICAL'    => [],
    'DESCRIPTIVE'  => [],
    'KINDERGARTEN' => [],
];
foreach ($descriptorRows as $dRow) {
    $tKey = strtoupper((string)($dRow['grading_type'] ?? 'NUMERICAL'));
    if (!isset($groupedDescriptors[$tKey])) {
        $groupedDescriptors[$tKey] = [];
    }
    $groupedDescriptors[$tKey][] = $dRow;
}
$totalDescriptorCount = count($descriptorRows);
?>
<!doctype html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>STSN Grading System | Grading Templates</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <meta name="color-scheme" content="light dark" />
  <meta name="theme-color" content="#8B1A1A" media="(prefers-color-scheme: light)" />
  <meta name="theme-color" content="#8B1A1A" />
  <meta name="title" content="STSN | Grading Templates" />
  <meta name="author" content="G" />
  <meta name="description" content="STSN Grading System - Grading Templates" />
  <meta name="keywords" content="STSN, Grading Templates, school grading system" />
  <meta name="supported-color-schemes" content="light dark" />
  <link rel="preload" href="../css/adminlte.css" as="style" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
    integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
    onload="this.media='all'" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="../css/adminlte.css" />
  <link rel="stylesheet" href="../css/dark-mode.css" />
  <link rel="stylesheet" href="../css/admin-responsive.css" />
  <link rel="stylesheet" href="../css/system-alerts.css" />
  <link rel="stylesheet" href="../css/superadmin-theme.css" />

  <style>
    .template-card {
      background: #fff;
      border: 1px solid var(--border, #E9ECEF);
      border-radius: 14px;
      box-shadow: 0 4px 12px rgba(10,47,68,0.06);
      margin-bottom: 1.25rem;
      overflow: hidden;
    }
    .template-card-header {
      padding: 1rem 1.25rem;
      border-bottom: 1px solid var(--border, #E9ECEF);
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 1rem;
      flex-wrap: wrap;
    }
    .template-card-name {
      font-size: 1.05rem;
      font-weight: 800;
      color: var(--primary, #0A2F44);
      display: flex;
      align-items: center;
      gap: 0.5rem;
      flex-wrap: wrap;
    }
    .template-card-name i { color: #C5A028; }
    .template-card-desc {
      font-size: 0.82rem;
      color: var(--muted, #6C757D);
      margin-top: 4px;
    }
    .template-card-actions {
      display: flex;
      gap: 0.4rem;
      flex-wrap: wrap;
    }

    .metrics-list {
      padding: 1rem 1.25rem 1.25rem;
      background: #F8F9FA;
    }
    .metrics-row {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
    }
    .metric-chip {
      background: #fff;
      border: 1px solid var(--border, #E9ECEF);
      border-radius: 8px;
      padding: 0.35rem 0.75rem;
      min-width: 88px;
      text-align: center;
    }
    .metric-label {
      display: block;
      font-size: 0.66rem;
      font-weight: 700;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      color: var(--muted, #6C757D);
    }
    .metric-value {
      display: block;
      font-size: 0.95rem;
      font-weight: 800;
      color: var(--primary, #0A2F44);
    }

    .gt-table thead th {
      font-size: 0.72rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--muted, #6C757D);
      font-weight: 700;
      white-space: nowrap;
    }
    .gt-group-row td {
      background: #F1F3F5;
      font-weight: 700;
      font-size: 0.8rem;
      color: var(--primary, #0A2F44);
    }
    .gt-group-row td i { color: #C5A028; }

    /* Tabs */
    .gt-tabs {
      border-bottom: 2px solid var(--border, #E9ECEF);
      gap: 0.25rem;
    }
    .gt-tabs .nav-link {
      border: none;
      border-bottom: 3px solid transparent;
      border-radius: 0;
      background: transparent;
      color: #6C757D;
      font-weight: 700;
      font-size: 0.9rem;
      padding: 0.65rem 1rem;
      margin-bottom: -2px;
    }
    .gt-tabs .nav-link:hover {
      color: #8B1A1A;
    }
    .gt-tabs .nav-link.active {
      color: #8B1A1A;
      border-bottom-color: #8B1A1A;
      background: transparent;
    }
    /* Fix: active tab text disappearing (theme CSS was painting a maroon background) */
    .gt-tabs .nav-link.active,
    .gt-tabs .nav-link.active:hover,
    .gt-tabs .nav-link.active:focus {
      background: transparent !important;
      color: #8B1A1A !important;
      border-radius: 0 !important;
      border-bottom-color: #8B1A1A !important;
      box-shadow: none !important;
    }

    /* ============================================================
       Descriptor Sections — Grouped by Type (Maroon theme)
       ============================================================ */
    .descriptor-section {
        border: 1px solid #f0e0e0;
        border-radius: 12px;
        overflow: hidden;
        background: #fff;
        box-shadow: 0 2px 8px rgba(139, 26, 26, 0.06);
    }
    .descriptor-section-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 1rem 1.35rem;
        background: #fdf8f8;
        border-bottom: 1px solid #f5e5e5;
        border-left: 4px solid #8B1A1A;
        gap: 1rem;
        flex-wrap: wrap;
    }
    .descriptor-section-title {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }
    .descriptor-section-icon {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        background: #fdf2f2;
        color: #8B1A1A;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.1rem;
        flex-shrink: 0;
    }
    .descriptor-section-title h4 {
        margin: 0;
        font-size: 1rem;
        font-weight: 700;
        color: #8B1A1A;
    }
    .descriptor-section-title p {
        margin: 0;
        font-size: 0.78rem;
        color: #a08080;
    }
    .descriptor-section-table .table {
        margin-bottom: 0;
    }
    .descriptor-section-table .table thead th {
        background: #fdf8f8;
        font-size: 0.72rem;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: #8B1A1A;
        font-weight: 700;
        white-space: nowrap;
        border-bottom: 1px solid #f5e5e5;
        padding: 0.85rem 1.15rem;
    }
    .descriptor-section-table .table tbody td {
        padding: 0.85rem 1.15rem;
        vertical-align: middle;
    }
    .descriptor-section-table .table thead th:first-child,
    .descriptor-section-table .table tbody td:first-child {
        padding-left: 1.35rem;
    }
    .descriptor-section-table .table thead th:last-child,
    .descriptor-section-table .table tbody td:last-child {
        padding-right: 1.35rem;
    }

    /* Type badge — all maroon now */
    .gt-type-badge {
        background: #8B1A1A !important;
        color: #fff;
        min-width: 98px;
        padding: 4px 10px;
        border-radius: 6px;
        font-size: 0.72rem;
        font-weight: 700;
    }

    /* Dark mode support */
    [data-bs-theme="dark"] .template-card { background: #1a1d21; border-color: #2b3035; }
    [data-bs-theme="dark"] .template-card-name { color: #e9ecef; }
    [data-bs-theme="dark"] .template-card-header { border-bottom-color: #2b3035; }
    [data-bs-theme="dark"] .metrics-list { background: #131518; }
    [data-bs-theme="dark"] .metric-chip { background: #1a1d21; border-color: #2b3035; }
    [data-bs-theme="dark"] .metric-value { color: #e9ecef; }
    [data-bs-theme="dark"] .gt-tabs { border-bottom-color: #2b3035; }
    [data-bs-theme="dark"] .gt-tabs .nav-link { color: #adb5bd; }
    [data-bs-theme="dark"] .gt-tabs .nav-link:hover { color: #e9ecef; }
    [data-bs-theme="dark"] .gt-tabs .nav-link.active,
    [data-bs-theme="dark"] .gt-tabs .nav-link.active:hover,
    [data-bs-theme="dark"] .gt-tabs .nav-link.active:focus { color: #FFA8A8 !important; border-bottom-color: #FFA8A8 !important; }
    [data-bs-theme="dark"] .gt-table thead th { color: #adb5bd; }
    [data-bs-theme="dark"] .gt-group-row td { background: #26292d; color: #e9ecef; }
    [data-bs-theme="dark"] .descriptor-section { background: #1a1d21; border-color: #3a2a2a; }
    [data-bs-theme="dark"] .descriptor-section-header { background: #262020; border-bottom-color: #3a2a2a; }
    [data-bs-theme="dark"] .descriptor-section-title h4 { color: #FFA8A8; }
    [data-bs-theme="dark"] .descriptor-section-title p { color: #a08080; }
    [data-bs-theme="dark"] .descriptor-section-icon { background: #3a2a2a; color: #FFA8A8; }
    [data-bs-theme="dark"] .descriptor-section-table .table thead th { background: #262020; color: #FFA8A8; border-bottom-color: #3a2a2a; }

  </style>

  <script src="../js/theme.js" defer></script>
</head>

<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">

  <div class="app-wrapper">
    <?php
    include_once '../includes/header.php';
    include_once '../includes/sAdmin_sidebar.php';
    ?>

    <main class="app-main">

      <div class="app-content-header"></div>
      <div class="app-content">
        <div class="container-fluid p-4">

          <!-- Page Header Banner -->
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3 p-4 text-white sa-page-header">
            <div class="d-flex align-items-center gap-3">
              <i class="bi bi-calculator-fill" style="font-size:1.5rem;"></i>
              <div>
                <h1 class="mb-0" style="font-size:1.5rem; font-weight:600;">Grading Templates</h1>
                <p class="mb-0" style="font-size:0.85rem; opacity:0.85;">Component weights, grade transmutation and descriptors — configurable without code changes</p>
              </div>
            </div>
          </div>

          <!-- Breadcrumb -->
          <?php renderBreadcrumb([
            ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'],
            ['label' => 'System Configuration', 'href' => '#', 'icon' => 'bi bi-sliders'],
            ['label' => 'Grading Templates', 'icon' => 'bi bi-calculator-fill'],
          ]); ?>

          <?php if ($flashMessage !== ''): ?>
            <div data-sa-flash="<?= htmlspecialchars($flashType) ?>"
                 data-sa-flash-message="<?= htmlspecialchars($flashMessage) ?>"
                 style="display:none"></div>
          <?php endif; ?>

          <!-- Info Banner -->
          <div class="sa-info-banner">
            <i class="bi bi-info-circle-fill sa-alert-icon"></i>
            <div>
              Grading configuration powers every report card: the component weights (Written Works / Performance Tasks / Quarterly
              Assessment) build the initial grade, the transmutation table converts it into the final grade, and descriptors describe
              the learner&rsquo;s performance. Exactly one template is the system default.
            </div>
          </div>

          <!-- Tabs -->
          <ul class="nav nav-tabs gt-tabs mb-3" role="tablist">
            <li class="nav-item" role="presentation">
              <button class="nav-link<?= $activeTab === 'templates' ? ' active' : '' ?>" id="tabTemplatesBtn"
                      data-bs-toggle="tab" data-bs-target="#tabTemplates" type="button" role="tab"
                      aria-controls="tabTemplates" aria-selected="<?= $activeTab === 'templates' ? 'true' : 'false' ?>">
                <i class="bi bi-sliders me-1"></i> Templates (Weights)
              </button>
            </li>
            <li class="nav-item" role="presentation">
              <button class="nav-link<?= $activeTab === 'transmutation' ? ' active' : '' ?>" id="tabTransmutationBtn"
                      data-bs-toggle="tab" data-bs-target="#tabTransmutation" type="button" role="tab"
                      aria-controls="tabTransmutation" aria-selected="<?= $activeTab === 'transmutation' ? 'true' : 'false' ?>">
                <i class="bi bi-calculator me-1"></i> Transmutation
              </button>
            </li>
            <li class="nav-item" role="presentation">
              <button class="nav-link<?= $activeTab === 'descriptors' ? ' active' : '' ?>" id="tabDescriptorsBtn"
                      data-bs-toggle="tab" data-bs-target="#tabDescriptors" type="button" role="tab"
                      aria-controls="tabDescriptors" aria-selected="<?= $activeTab === 'descriptors' ? 'true' : 'false' ?>">
                <i class="bi bi-card-text me-1"></i> Descriptors
              </button>
            </li>
          </ul>

          <div class="tab-content">

            <!-- ============================ TAB 1: TEMPLATES (WEIGHTS) ============================ -->
            <div class="tab-pane fade<?= $activeTab === 'templates' ? ' show active' : '' ?>"
                 id="tabTemplates" role="tabpanel" aria-labelledby="tabTemplatesBtn" tabindex="0">

              <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                <span class="text-muted small">Total: <?= count($templates) ?> template<?= count($templates) === 1 ? '' : 's' ?></span>
                <button type="button" class="btn btn-primary" id="newTemplateBtn">
                  <i class="bi bi-plus-lg me-1"></i> New Template
                </button>
              </div>

              <?php if ($templates === []): ?>
                <div class="card">
                  <div class="card-body text-center py-5">
                    <i class="bi bi-inbox text-muted mb-2 d-block" style="font-size:3rem;"></i>
                    <div class="text-body">No grading templates yet</div>
                    <div class="text-muted" style="font-size:0.85rem;">Click &ldquo;New Template&rdquo; to create the first grading template.</div>
                  </div>
                </div>
              <?php else: ?>
                <?php foreach ($templates as $template): ?>
                  <?php
                  $templateId       = (int)$template['id'];
                  $isDefaultTpl     = (int)$template['is_default'] === 1;
                  $isActiveTpl      = (int)$template['is_active'] === 1;
                  $tplDescription   = trim((string)($template['description'] ?? ''));
                  $tplGradeFrom     = $template['applies_to_grade_from'] !== null ? (int)$template['applies_to_grade_from'] : null;
                  $tplGradeTo       = $template['applies_to_grade_to'] !== null ? (int)$template['applies_to_grade_to'] : null;
                  $wwWeight         = (float)$template['ww_weight'];
                  $ptWeight         = (float)$template['pt_weight'];
                  $qaWeight         = (float)$template['qa_weight'];
                  $passingThreshold = (int)$template['passing_threshold'];
                  $roundingRule     = (string)$template['rounding_rule'];
                  $transCount       = (int)$template['transmutation_count'];
                  if ($tplGradeFrom === null && $tplGradeTo === null) {
                      $gradeRangeText = 'All Grade Levels';
                  } elseif ($tplGradeFrom !== null && $tplGradeTo !== null) {
                      $gradeRangeText = $tplGradeFrom === $tplGradeTo ? 'Grade ' . $tplGradeFrom : 'Grades ' . $tplGradeFrom . '–' . $tplGradeTo;
                  } elseif ($tplGradeFrom !== null) {
                      $gradeRangeText = 'Grades ' . $tplGradeFrom . ' and up';
                  } else {
                      $gradeRangeText = 'Grades up to ' . $tplGradeTo;
                  }
                  ?>
                  <div class="template-card">
                    <div class="template-card-header">
                      <div>
                        <div class="template-card-name">
                          <i class="bi bi-sliders"></i>
                          <?= htmlspecialchars((string)$template['template_name']) ?>
                          <?php if ($isDefaultTpl): ?>
                            <span class="badge bg-warning text-dark"><i class="bi bi-star-fill me-1"></i>Default</span>
                          <?php endif; ?>
                          <?php if (!$isActiveTpl): ?>
                            <span class="badge bg-secondary"><i class="bi bi-slash-circle me-1"></i>Inactive</span>
                          <?php endif; ?>
                        </div>
                        <?php if ($tplDescription !== ''): ?>
                          <div class="template-card-desc ms-4"><?= htmlspecialchars($tplDescription) ?></div>
                        <?php endif; ?>
                        <div class="template-card-desc ms-4">
                          <i class="bi bi-funnel-fill me-1"></i>Applies to: <?= htmlspecialchars($gradeRangeText) ?>
                          &nbsp;&middot;&nbsp;
                          <i class="bi bi-calculator me-1"></i><?= $transCount ?> transmutation row<?= $transCount === 1 ? '' : 's' ?>
                        </div>
                      </div>
                      <div class="template-card-actions">
                        <?php if (!$isDefaultTpl): ?>
                          <form method="post" action="Grading-Templates.php" class="d-inline"
                                data-confirm="Set this template as the default grading template? It will also be activated.">
                            <input type="hidden" name="action" value="set_default">
                            <input type="hidden" name="tab" value="templates">
                            <input type="hidden" name="id" value="<?= $templateId ?>">
                            <button type="submit" class="btn btn-outline-warning btn-sm" title="Set Default">
                              <i class="bi bi-star me-1"></i> Set Default
                            </button>
                          </form>
                        <?php endif; ?>

                        <button type="button" class="btn btn-outline-primary btn-sm edit-template-btn" title="Edit"
                                data-id="<?= $templateId ?>"
                                data-name="<?= htmlspecialchars((string)$template['template_name']) ?>"
                                data-description="<?= htmlspecialchars($tplDescription) ?>"
                                data-ww="<?= htmlspecialchars(number_format($wwWeight, 2, '.', '')) ?>"
                                data-pt="<?= htmlspecialchars(number_format($ptWeight, 2, '.', '')) ?>"
                                data-qa="<?= htmlspecialchars(number_format($qaWeight, 2, '.', '')) ?>"
                                data-threshold="<?= $passingThreshold ?>"
                                data-rounding="<?= htmlspecialchars($roundingRule) ?>"
                                data-grade-from="<?= $tplGradeFrom !== null ? $tplGradeFrom : '' ?>"
                                data-grade-to="<?= $tplGradeTo !== null ? $tplGradeTo : '' ?>">
                          <i class="bi bi-pencil-square me-1"></i> Edit
                        </button>

                        <form method="post" action="Grading-Templates.php" class="d-inline"
                              data-confirm="<?= $isActiveTpl ? 'Deactivate this grading template?' : 'Activate this grading template?' ?>">
                          <input type="hidden" name="action" value="toggle_template">
                          <input type="hidden" name="tab" value="templates">
                          <input type="hidden" name="id" value="<?= $templateId ?>">
                          <button type="submit" class="btn btn-outline-secondary btn-sm"
                                  title="<?= $isActiveTpl ? 'Deactivate' : 'Activate' ?>">
                            <i class="bi bi-arrow-repeat me-1"></i> <?= $isActiveTpl ? 'Deactivate' : 'Activate' ?>
                          </button>
                        </form>

                        <?php if (!$isDefaultTpl): ?>
                          <form method="post" action="Grading-Templates.php" class="d-inline"
                                data-confirm="Delete this template? Its transmutation table will also be deleted. This cannot be undone.">
                            <input type="hidden" name="action" value="delete_template">
                            <input type="hidden" name="tab" value="templates">
                            <input type="hidden" name="id" value="<?= $templateId ?>">
                            <button type="submit" class="btn btn-outline-danger btn-sm" title="Delete">
                              <i class="bi bi-trash me-1"></i> Delete
                            </button>
                          </form>
                        <?php endif; ?>
                      </div>
                    </div>

                    <div class="metrics-list">
                      <div class="metrics-row">
                        <div class="metric-chip"><span class="metric-label">WW</span><span class="metric-value"><?= htmlspecialchars(gtNum($wwWeight)) ?>%</span></div>
                        <div class="metric-chip"><span class="metric-label">PT</span><span class="metric-value"><?= htmlspecialchars(gtNum($ptWeight)) ?>%</span></div>
                        <div class="metric-chip"><span class="metric-label">QA</span><span class="metric-value"><?= htmlspecialchars(gtNum($qaWeight)) ?>%</span></div>
                        <div class="metric-chip"><span class="metric-label">Passing</span><span class="metric-value"><?= $passingThreshold ?></span></div>
                        <div class="metric-chip"><span class="metric-label">Rounding</span><span class="metric-value"><?= htmlspecialchars($roundingRule !== '' ? $roundingRule : 'ROUND') ?></span></div>
                      </div>
                    </div>
                  </div>
                <?php endforeach; ?>
              <?php endif; ?>

            </div>

            <!-- ============================ TAB 2: TRANSMUTATION ============================ -->
            <div class="tab-pane fade<?= $activeTab === 'transmutation' ? ' show active' : '' ?>"
                 id="tabTransmutation" role="tabpanel" aria-labelledby="tabTransmutationBtn" tabindex="0">

              <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                <form method="get" action="Grading-Templates.php" id="transFilterForm" class="d-flex align-items-center gap-2">
                  <input type="hidden" name="tab" value="transmutation">
                  <label for="transFilterSelect" class="text-muted small mb-0">
                    <i class="bi bi-funnel-fill me-1"></i>Template:
                  </label>
                  <select class="form-select form-select-sm" id="transFilterSelect" name="template_id" style="min-width: 230px;">
                    <option value="0">All Templates</option>
                    <?php foreach ($templates as $templateOption): ?>
                      <option value="<?= (int)$templateOption['id'] ?>"<?= $transTemplateFilter === (int)$templateOption['id'] ? ' selected' : '' ?>>
                        <?= htmlspecialchars((string)$templateOption['template_name']) ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                </form>
                <button type="button" class="btn btn-primary" id="addTransmutationBtn"
                        <?= ($transTemplateFilter <= 0 || $templates === []) ? 'disabled' : '' ?>
                        title="<?= $templates === [] ? 'Create a grading template first' : ($transTemplateFilter <= 0 ? 'Select a template in the filter first' : 'Add a transmutation row') ?>">
                  <i class="bi bi-plus-lg me-1"></i> Add Transmutation
                </button>
              </div>

              <div class="card">
                <div class="card-body p-0">
                  <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 gt-table">
                      <thead>
                        <tr>
                          <th style="width:14%">Min</th>
                          <th style="width:14%">Max</th>
                          <th style="width:16%">Transmuted</th>
                          <th>Descriptor</th>
                          <th class="text-end text-nowrap" style="width:1%">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php if ($transmutationRows === []): ?>
                        <tr>
                          <td colspan="5" class="text-center py-5">
                            <i class="bi bi-inbox text-muted mb-2 d-block" style="font-size:3rem;"></i>
                            <?php if ($templates === []): ?>
                              <div class="text-body">No grading templates yet</div>
                              <div class="text-muted" style="font-size:0.85rem;">Create a template in the Templates tab first, then build its transmutation table here.</div>
                            <?php elseif ($transTemplateFilter > 0): ?>
                              <div class="text-body">No transmutation rows for this template</div>
                              <div class="text-muted" style="font-size:0.85rem;">Click &ldquo;Add Transmutation&rdquo; to build the table.</div>
                            <?php else: ?>
                              <div class="text-body">No transmutation rows yet</div>
                              <div class="text-muted" style="font-size:0.85rem;">Select a template in the filter above, then click &ldquo;Add Transmutation&rdquo;.</div>
                            <?php endif; ?>
                          </td>
                        </tr>
                      <?php else: ?>
                        <?php $lastTransTplId = null; ?>
                        <?php foreach ($transmutationRows as $transRow): ?>
                          <?php
                          $transRowId      = (int)$transRow['id'];
                          $transTplId      = (int)$transRow['template_id'];
                          $transDescriptor = trim((string)($transRow['descriptor'] ?? ''));
                          ?>
                          <?php if ($transTemplateFilter <= 0 && $transTplId !== $lastTransTplId): ?>
                            <?php $lastTransTplId = $transTplId; ?>
                            <tr class="gt-group-row">
                              <td colspan="5">
                                <i class="bi bi-sliders me-1"></i><?= htmlspecialchars((string)($templateNameMap[$transTplId] ?? $transRow['template_name'])) ?>
                              </td>
                            </tr>
                          <?php endif; ?>
                          <tr>
                            <td><?= htmlspecialchars(number_format((float)$transRow['min_initial'], 2)) ?></td>
                            <td><?= htmlspecialchars(number_format((float)$transRow['max_initial'], 2)) ?></td>
                            <td><span class="badge bg-primary"><?= (int)$transRow['transmuted_grade'] ?></span></td>
                            <td><?= $transDescriptor !== '' ? htmlspecialchars($transDescriptor) : '<span class="text-muted">&mdash;</span>' ?></td>
                            <td class="text-end text-nowrap">
                              <button type="button" class="btn btn-outline-primary btn-sm edit-transmutation-btn" title="Edit"
                                      data-id="<?= $transRowId ?>"
                                      data-template-id="<?= $transTplId ?>"
                                      data-min="<?= htmlspecialchars(number_format((float)$transRow['min_initial'], 2, '.', '')) ?>"
                                      data-max="<?= htmlspecialchars(number_format((float)$transRow['max_initial'], 2, '.', '')) ?>"
                                      data-grade="<?= (int)$transRow['transmuted_grade'] ?>"
                                      data-descriptor="<?= htmlspecialchars($transDescriptor) ?>">
                                <i class="bi bi-pencil-square"></i>
                              </button>
                              <form method="post" action="Grading-Templates.php" class="d-inline"
                                    data-confirm="Delete this transmutation row?">
                                <input type="hidden" name="action" value="delete_transmutation">
                                <input type="hidden" name="tab" value="transmutation">
                                <input type="hidden" name="id" value="<?= $transRowId ?>">
                                <button type="submit" class="btn btn-outline-danger btn-sm" title="Delete">
                                  <i class="bi bi-trash"></i>
                                </button>
                              </form>
                            </td>
                          </tr>
                        <?php endforeach; ?>
                      <?php endif; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

            </div>

            <!-- ============================ TAB 3: DESCRIPTORS ============================ -->
            <div class="tab-pane fade<?= $activeTab === 'descriptors' ? ' show active' : '' ?>"
                 id="tabDescriptors" role="tabpanel" aria-labelledby="tabDescriptorsBtn" tabindex="0">

              <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                <span class="text-muted small">
                  Total: <?= $totalDescriptorCount ?> descriptor<?= $totalDescriptorCount === 1 ? '' : 's' ?> across 3 grading types
                </span>
                <button type="button" class="btn btn-primary" id="addDescriptorBtn">
                  <i class="bi bi-plus-lg me-1"></i> Add Descriptor
                </button>
              </div>

              <?php
              $sectionMeta = [
                  'NUMERICAL'    => ['label' => 'Numerical Grading',      'sub' => 'Grades 4-12 · Numeric grades (60-100)',         'icon' => 'bi-bar-chart-fill'],
                  'DESCRIPTIVE'  => ['label' => 'Descriptive Grading',    'sub' => 'Grades 1-3 · Descriptive ratings (A / P / AP / D / B)', 'icon' => 'bi-journal-text'],
                  'KINDERGARTEN' => ['label' => 'Kindergarten Assessment','sub' => 'Kinder · Developmental domain ratings (A / S / R / N)', 'icon' => 'bi-palette-fill'],
              ];
              ?>

              <?php foreach ($sectionMeta as $typeKey => $meta): ?>
                <?php if (empty($groupedDescriptors[$typeKey])) continue; ?>
                <?php $isNumerical = ($typeKey === 'NUMERICAL'); ?>

                <div class="descriptor-section mb-4">
                  <div class="descriptor-section-header">
                    <div class="descriptor-section-title">
                      <div class="descriptor-section-icon">
                        <i class="bi <?= $meta['icon'] ?>"></i>
                      </div>
                      <div>
                        <h4><?= htmlspecialchars($meta['label']) ?></h4>
                        <p><?= htmlspecialchars($meta['sub']) ?></p>
                      </div>
                    </div>
                  </div>

                  <div class="descriptor-section-table">
                    <table class="table table-hover align-middle mb-0 gt-table">
                      <thead>
                        <tr>
                          <?php if ($isNumerical): ?>
                            <th class="text-nowrap" style="width:90px;">Grade From</th>
                            <th class="text-nowrap" style="width:90px;">Grade To</th>
                          <?php else: ?>
                            <th class="text-nowrap" style="width:80px;">Rating</th>
                          <?php endif; ?>
                          <th>Descriptor</th>
                          <th style="width:100px;">Remarks</th>
                          <th class="text-nowrap" style="width:110px;">Level Range</th>
                          <th class="text-end text-nowrap" style="width:1%;">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach ($groupedDescriptors[$typeKey] as $descriptorRow): ?>
                          <?php
                          $descriptorRowId = (int)$descriptorRow['id'];
                          $descGradingType = (string)$descriptorRow['grading_type'];
                          $descRatingCode  = strtoupper(trim((string)($descriptorRow['rating_code'] ?? '')));
                          $descDescriptor  = trim((string)$descriptorRow['descriptor']);
                          $descRemarks     = (string)$descriptorRow['remarks'];
                          $descGradeFrom   = $descriptorRow['grade_from'] !== null ? (int)$descriptorRow['grade_from'] : null;
                          $descGradeTo     = $descriptorRow['grade_to'] !== null ? (int)$descriptorRow['grade_to'] : null;
                          $descLevelFrom   = $descriptorRow['applies_to_grade_level_from'] !== null ? (int)$descriptorRow['applies_to_grade_level_from'] : null;
                          $descLevelTo     = $descriptorRow['applies_to_grade_level_to'] !== null ? (int)$descriptorRow['applies_to_grade_level_to'] : null;
                          if ($descLevelFrom === null && $descLevelTo === null) {
                              $descLevelText = 'All Levels';
                          } elseif ($descLevelFrom !== null && $descLevelTo !== null) {
                              $descLevelText = $descLevelFrom === $descLevelTo ? 'G' . $descLevelFrom : 'G' . $descLevelFrom . '–G' . $descLevelTo;
                          } elseif ($descLevelFrom !== null) {
                              $descLevelText = 'G' . $descLevelFrom . ' and up';
                          } else {
                              $descLevelText = 'Up to G' . $descLevelTo;
                          }
                          ?>
                          <tr>
                            <?php if ($isNumerical): ?>
                              <td class="fw-bold"><?= $descGradeFrom !== null ? $descGradeFrom : '<span class="text-muted">&mdash;</span>' ?></td>
                              <td class="fw-bold"><?= $descGradeTo !== null ? $descGradeTo : '<span class="text-muted">&mdash;</span>' ?></td>
                            <?php else: ?>
                              <td><?= $descRatingCode !== '' ? '<span class="fw-bold" style="color:#8B1A1A;">' . htmlspecialchars($descRatingCode) . '</span>' : '<span class="text-muted">&mdash;</span>' ?></td>
                            <?php endif; ?>
                            <td><?= htmlspecialchars($descDescriptor) ?></td>
                            <td>
                              <span class="badge bg-<?= $descRemarks === 'Passed' ? 'success' : 'danger' ?>"><?= htmlspecialchars($descRemarks) ?></span>
                            </td>
                            <td class="text-muted small"><?= htmlspecialchars($descLevelText) ?></td>
                            <td class="text-end text-nowrap">
                              <button type="button" class="btn btn-outline-primary btn-sm edit-descriptor-btn" title="Edit"
                                      data-id="<?= $descriptorRowId ?>"
                                      data-type="<?= htmlspecialchars($descGradingType) ?>"
                                      data-rating="<?= htmlspecialchars($descRatingCode) ?>"
                                      data-from="<?= $descGradeFrom !== null ? $descGradeFrom : '' ?>"
                                      data-to="<?= $descGradeTo !== null ? $descGradeTo : '' ?>"
                                      data-descriptor="<?= htmlspecialchars($descDescriptor) ?>"
                                      data-remarks="<?= htmlspecialchars($descRemarks) ?>"
                                      data-level-from="<?= $descLevelFrom !== null ? $descLevelFrom : '' ?>"
                                      data-level-to="<?= $descLevelTo !== null ? $descLevelTo : '' ?>">
                                <i class="bi bi-pencil-square"></i>
                              </button>
                              <form method="post" action="Grading-Templates.php" class="d-inline"
                                    data-confirm="Delete this descriptor?">
                                <input type="hidden" name="action" value="delete_descriptor">
                                <input type="hidden" name="tab" value="descriptors">
                                <input type="hidden" name="id" value="<?= $descriptorRowId ?>">
                                <button type="submit" class="btn btn-outline-danger btn-sm" title="Delete">
                                  <i class="bi bi-trash"></i>
                                </button>
                              </form>
                            </td>
                          </tr>
                        <?php endforeach; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              <?php endforeach; ?>

              <?php if ($totalDescriptorCount === 0): ?>
                <div class="card">
                  <div class="card-body text-center py-5">
                    <i class="bi bi-inbox text-muted mb-2 d-block" style="font-size:3rem;"></i>
                    <div class="text-body">No descriptors yet</div>
                    <div class="text-muted" style="font-size:0.85rem;">Click &ldquo;Add Descriptor&rdquo; to define performance descriptors.</div>
                  </div>
                </div>
              <?php endif; ?>

            </div>

          </div><!-- /tab-content -->

        </div>
      </div>

    </main>

    <?php include_once '../includes/footer.php'; ?>
  </div>

  <!-- Add/Edit Grading Template Modal -->
  <div class="modal fade" id="templateModal" tabindex="-1" aria-labelledby="templateModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
      <div class="modal-content">
        <form method="post" action="Grading-Templates.php" id="templateForm" autocomplete="off">
          <div class="modal-header">
            <h5 class="modal-title" id="templateModalLabel">New Template</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <input type="hidden" name="action" id="tplAction" value="create_template">
            <input type="hidden" name="tab" value="templates">
            <input type="hidden" name="id" id="tplId" value="">
            <div class="row g-3">
              <div class="col-md-12">
                <label class="form-label" for="tplName">Template Name <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="tplName" name="template_name"
                       maxlength="100" required placeholder="e.g. STSN Standard (JHS)">
              </div>
              <div class="col-md-12">
                <label class="form-label" for="tplDescription">Description</label>
                <textarea class="form-control" id="tplDescription" name="description" rows="2"
                          placeholder="Short description of this grading template"></textarea>
              </div>
              <div class="col-md-12">
                <label class="form-label d-block">
                  Component Weights <span class="text-danger">*</span>
                  <span class="text-muted small">(WW + PT + QA must total exactly 100%)</span>
                </label>
                <div class="row g-2">
                  <div class="col-md-4">
                    <div class="input-group">
                      <span class="input-group-text" title="Written Works">WW</span>
                      <input type="number" class="form-control" id="tplWwWeight" name="ww_weight"
                             min="0" max="100" step="0.01" required placeholder="e.g. 40">
                      <span class="input-group-text">%</span>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="input-group">
                      <span class="input-group-text" title="Performance Tasks">PT</span>
                      <input type="number" class="form-control" id="tplPtWeight" name="pt_weight"
                             min="0" max="100" step="0.01" required placeholder="e.g. 40">
                      <span class="input-group-text">%</span>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="input-group">
                      <span class="input-group-text" title="Quarterly Assessment">QA</span>
                      <input type="number" class="form-control" id="tplQaWeight" name="qa_weight"
                             min="0" max="100" step="0.01" required placeholder="e.g. 20">
                      <span class="input-group-text">%</span>
                    </div>
                  </div>
                </div>
                <div class="form-text" id="tplWeightHelp">
                  Total: <strong id="tplWeightTotal">&mdash;</strong>% &mdash; must equal exactly 100%.
                </div>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="tplThreshold">Passing Threshold <span class="text-danger">*</span></label>
                <input type="number" class="form-control" id="tplThreshold" name="passing_threshold"
                       min="1" max="100" value="75" required>
                <div class="form-text text-muted">Transmuted grade at or above this is a pass.</div>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="tplRounding">Rounding Rule</label>
                <select class="form-select" id="tplRounding" name="rounding_rule">
                  <?php foreach ($roundingRuleOptions as $roundingOption): ?>
                    <option value="<?= htmlspecialchars($roundingOption) ?>"><?= htmlspecialchars($roundingOption) ?></option>
                  <?php endforeach; ?>
                </select>
                <div class="form-text text-muted">ROUND = nearest &middot; CEIL = always up &middot; FLOOR = always down.</div>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="tplGradeFrom">Grade From</label>
                <input type="number" class="form-control" id="tplGradeFrom" name="applies_to_grade_from"
                       min="1" max="12" placeholder="All">
                <div class="form-text text-muted">Blank = all grade levels.</div>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="tplGradeTo">Grade To</label>
                <input type="number" class="form-control" id="tplGradeTo" name="applies_to_grade_to"
                       min="1" max="12" placeholder="All">
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-check-lg me-1"></i> Save Template
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Add/Edit Transmutation Modal -->
  <div class="modal fade" id="transmutationModal" tabindex="-1" aria-labelledby="transmutationModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <form method="post" action="Grading-Templates.php" id="transmutationForm" autocomplete="off">
          <div class="modal-header">
            <h5 class="modal-title" id="transmutationModalLabel">Add Transmutation Row</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <input type="hidden" name="action" id="transAction" value="add_transmutation">
            <input type="hidden" name="tab" value="transmutation">
            <input type="hidden" name="id" id="transId" value="">
            <input type="hidden" name="template_id" id="transTemplateId" value="">
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label" for="transMin">Min Initial Grade <span class="text-danger">*</span></label>
                <input type="number" class="form-control" id="transMin" name="min_initial"
                       min="0" max="100" step="0.01" required placeholder="e.g. 74.40">
              </div>
              <div class="col-md-6">
                <label class="form-label" for="transMax">Max Initial Grade <span class="text-danger">*</span></label>
                <input type="number" class="form-control" id="transMax" name="max_initial"
                       min="0" max="100" step="0.01" required placeholder="e.g. 75.99">
              </div>
              <div class="col-md-6">
                <label class="form-label" for="transGrade">Transmuted Grade <span class="text-danger">*</span></label>
                <input type="number" class="form-control" id="transGrade" name="transmuted_grade"
                       min="60" max="100" required placeholder="e.g. 84">
                <div class="form-text text-muted">Whole number between 60 and 100.</div>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="transDescriptor">Descriptor</label>
                <input type="text" class="form-control" id="transDescriptor" name="descriptor"
                       maxlength="50" placeholder="e.g. Good" list="descriptorNameList">
                <datalist id="descriptorNameList">
                  <?php foreach ($descriptorRows as $descriptorNameOption): ?>
                    <option value="<?= htmlspecialchars((string)$descriptorNameOption['descriptor']) ?>"></option>
                  <?php endforeach; ?>
                </datalist>
                <div class="form-text text-muted">Optional label shown beside the transmuted grade.</div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-check-lg me-1"></i> Save Transmutation
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Add/Edit Descriptor Modal -->
  <div class="modal fade" id="descriptorModal" tabindex="-1" aria-labelledby="descriptorModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <form method="post" action="Grading-Templates.php" id="descriptorForm" autocomplete="off">
          <div class="modal-header">
            <h5 class="modal-title" id="descriptorModalLabel">Add Descriptor</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <input type="hidden" name="action" id="descAction" value="add_descriptor">
            <input type="hidden" name="tab" value="descriptors">
            <input type="hidden" name="filter_type" value="<?= htmlspecialchars($descTypeFilter) ?>">
            <input type="hidden" name="id" id="descId" value="">
            <div class="row g-3">
              <div class="col-md-12">
                <label class="form-label" for="descType">Grading Type <span class="text-danger">*</span></label>
                <select class="form-select" id="descType" name="grading_type" required>
                  <?php foreach ($gradingTypeOptions as $gradingTypeOption): ?>
                    <option value="<?= htmlspecialchars($gradingTypeOption) ?>"><?= htmlspecialchars($gradingTypeOption) ?></option>
                  <?php endforeach; ?>
                </select>
                <div class="form-text text-muted">Numerical = grade range &middot; Descriptive / Kindergarten = rating code.</div>
              </div>
              <div class="col-md-12 d-none" id="descRatingField">
                <label class="form-label" for="descRatingCode">Rating Code <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="descRatingCode" name="rating_code"
                       maxlength="5" placeholder="e.g. A / AP" style="text-transform:uppercase;">
                <div class="form-text text-muted">Short code shown on the report card (max 5 chars).</div>
              </div>
              <div class="col-md-12" id="descNumericFields">
                <div class="row g-3">
                  <div class="col-md-6">
                    <label class="form-label" for="descGradeFrom">Grade From <span class="text-danger">*</span></label>
                    <input type="number" class="form-control" id="descGradeFrom" name="grade_from"
                           min="0" max="100" required placeholder="e.g. 90">
                  </div>
                  <div class="col-md-6">
                    <label class="form-label" for="descGradeTo">Grade To <span class="text-danger">*</span></label>
                    <input type="number" class="form-control" id="descGradeTo" name="grade_to"
                           min="0" max="100" required placeholder="e.g. 100">
                  </div>
                </div>
              </div>
              <div class="col-md-12">
                <label class="form-label" for="descDescriptor">Descriptor <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="descDescriptor" name="descriptor"
                       maxlength="50" required placeholder="e.g. Advancing">
              </div>
              <div class="col-md-12">
                <label class="form-label" for="descRemarks">Remarks</label>
                <select class="form-select" id="descRemarks" name="remarks">
                  <?php foreach ($remarksOptions as $remarksOption): ?>
                    <option value="<?= htmlspecialchars($remarksOption) ?>"><?= htmlspecialchars($remarksOption) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="descLevelFrom">Grade Level From</label>
                <input type="number" class="form-control" id="descLevelFrom" name="applies_to_grade_level_from"
                       min="1" max="12" placeholder="All">
                <div class="form-text text-muted">Blank = all grade levels.</div>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="descLevelTo">Grade Level To</label>
                <input type="number" class="form-control" id="descLevelTo" name="applies_to_grade_level_to"
                       min="1" max="12" placeholder="All">
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-check-lg me-1"></i> Save Descriptor
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>
  <script src="../js/adminlte.js"></script>
  <script src="../js/system-alerts.js"></script>
  <script src="../js/superadmin-alerts.js"></script>

  <script>
    document.addEventListener('DOMContentLoaded', function () {
      document.querySelectorAll('.alert-dismissible').forEach(function (alertEl) {
        setTimeout(function () {
          if (window.bootstrap && bootstrap.Alert) {
            bootstrap.Alert.getOrCreateInstance(alertEl).close();
          }
        }, 4000);
      });

      // Tab 1: Templates
      var templateForm = document.getElementById('templateForm');
      var weightInputs = [
        document.getElementById('tplWwWeight'),
        document.getElementById('tplPtWeight'),
        document.getElementById('tplQaWeight')
      ];

      function updateWeightTotal() {
        var total = 0, allFilled = true;
        weightInputs.forEach(function (input) {
          if (!input) return;
          var value = parseFloat(input.value);
          if (isNaN(value)) { allFilled = false; return; }
          total += value;
        });
        var totalEl = document.getElementById('tplWeightTotal');
        var helpEl  = document.getElementById('tplWeightHelp');
        if (!totalEl || !helpEl) return;
        if (!allFilled) {
          totalEl.textContent = '\u2014';
          helpEl.classList.remove('text-success', 'text-danger');
          helpEl.classList.add('text-muted');
          return;
        }
        totalEl.textContent = total.toFixed(2);
        var isExact = Math.abs(total - 100) <= 0.005;
        helpEl.classList.remove('text-muted');
        helpEl.classList.toggle('text-success', isExact);
        helpEl.classList.toggle('text-danger', !isExact);
      }

      weightInputs.forEach(function (input) {
        if (input) input.addEventListener('input', updateWeightTotal);
      });

      if (templateForm) {
        templateForm.addEventListener('submit', function (e) {
          var total = 0, allFilled = true;
          weightInputs.forEach(function (input) {
            if (!input) return;
            var value = parseFloat(input.value);
            if (isNaN(value)) { allFilled = false; return; }
            total += value;
          });
          if (allFilled && Math.abs(total - 100) > 0.005) {
            e.preventDefault();
            updateWeightTotal();
            window.saToast('Component weights must total exactly 100%. Current total: ' + total.toFixed(2) + '%.', 'danger');
          }
        });
      }

      var newTemplateBtn = document.getElementById('newTemplateBtn');
      if (newTemplateBtn) {
        newTemplateBtn.addEventListener('click', function () {
          templateForm.reset();
          document.getElementById('tplAction').value = 'create_template';
          document.getElementById('tplId').value = '';
          document.getElementById('tplWwWeight').value = '40';
          document.getElementById('tplPtWeight').value = '40';
          document.getElementById('tplQaWeight').value = '20';
          document.getElementById('tplThreshold').value = '75';
          document.getElementById('tplRounding').value = 'ROUND';
          document.getElementById('tplGradeFrom').value = '';
          document.getElementById('tplGradeTo').value = '';
          updateWeightTotal();
          document.getElementById('templateModalLabel').textContent = 'New Template';
          bootstrap.Modal.getOrCreateInstance(document.getElementById('templateModal')).show();
        });
      }

      document.querySelectorAll('.edit-template-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
          document.getElementById('tplAction').value = 'update_template';
          document.getElementById('tplId').value = btn.getAttribute('data-id');
          document.getElementById('tplName').value = btn.getAttribute('data-name');
          document.getElementById('tplDescription').value = btn.getAttribute('data-description');
          document.getElementById('tplWwWeight').value = btn.getAttribute('data-ww');
          document.getElementById('tplPtWeight').value = btn.getAttribute('data-pt');
          document.getElementById('tplQaWeight').value = btn.getAttribute('data-qa');
          document.getElementById('tplThreshold').value = btn.getAttribute('data-threshold');
          document.getElementById('tplRounding').value = btn.getAttribute('data-rounding') || 'ROUND';
          document.getElementById('tplGradeFrom').value = btn.getAttribute('data-grade-from');
          document.getElementById('tplGradeTo').value = btn.getAttribute('data-grade-to');
          updateWeightTotal();
          document.getElementById('templateModalLabel').textContent = 'Edit Template';
          bootstrap.Modal.getOrCreateInstance(document.getElementById('templateModal')).show();
        });
      });

      // Tab 2: Transmutation (HIDDEN — elements are commented out in the HTML, so these null-guarded handlers simply do nothing)
      var transFilterForm   = document.getElementById('transFilterForm');
      var transFilterSelect = document.getElementById('transFilterSelect');
      if (transFilterSelect && transFilterForm) {
        transFilterSelect.addEventListener('change', function () {
          transFilterForm.submit();
        });
      }

      var addTransmutationBtn = document.getElementById('addTransmutationBtn');
      if (addTransmutationBtn) {
        addTransmutationBtn.addEventListener('click', function () {
          var selectedTemplate = transFilterSelect ? transFilterSelect.value : '0';
          if (!selectedTemplate || selectedTemplate === '0') {
            window.saToast('Select a specific template in the filter first.', 'warning');
            return;
          }
          document.getElementById('transmutationForm').reset();
          document.getElementById('transAction').value = 'add_transmutation';
          document.getElementById('transId').value = '';
          document.getElementById('transTemplateId').value = selectedTemplate;
          document.getElementById('transmutationModalLabel').textContent = 'Add Transmutation Row';
          bootstrap.Modal.getOrCreateInstance(document.getElementById('transmutationModal')).show();
        });
      }

      document.querySelectorAll('.edit-transmutation-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
          document.getElementById('transAction').value = 'update_transmutation';
          document.getElementById('transId').value = btn.getAttribute('data-id');
          document.getElementById('transTemplateId').value = btn.getAttribute('data-template-id');
          document.getElementById('transMin').value = btn.getAttribute('data-min');
          document.getElementById('transMax').value = btn.getAttribute('data-max');
          document.getElementById('transGrade').value = btn.getAttribute('data-grade');
          document.getElementById('transDescriptor').value = btn.getAttribute('data-descriptor');
          document.getElementById('transmutationModalLabel').textContent = 'Edit Transmutation Row';
          bootstrap.Modal.getOrCreateInstance(document.getElementById('transmutationModal')).show();
        });
      });

      // Tab 3: Descriptors
      function toggleDescriptorFields() {
        var typeSelect  = document.getElementById('descType');
        var numericWrap = document.getElementById('descNumericFields');
        var ratingWrap  = document.getElementById('descRatingField');
        var fromInput   = document.getElementById('descGradeFrom');
        var toInput     = document.getElementById('descGradeTo');
        var ratingInput = document.getElementById('descRatingCode');
        if (!typeSelect || !numericWrap || !ratingWrap) return;
        var isNumeric = typeSelect.value === 'NUMERICAL';
        numericWrap.classList.toggle('d-none', !isNumeric);
        ratingWrap.classList.toggle('d-none', isNumeric);
        if (fromInput)   { fromInput.disabled = !isNumeric;  fromInput.required = isNumeric; }
        if (toInput)     { toInput.disabled = !isNumeric;    toInput.required = isNumeric; }
        if (ratingInput) { ratingInput.disabled = isNumeric; ratingInput.required = !isNumeric; }
        if (!isNumeric) {
          if (fromInput) fromInput.value = '';
          if (toInput) toInput.value = '';
        } else if (ratingInput) {
          ratingInput.value = '';
        }
      }

      var descTypeSelect = document.getElementById('descType');
      if (descTypeSelect) {
        descTypeSelect.addEventListener('change', toggleDescriptorFields);
      }

      var addDescriptorBtn = document.getElementById('addDescriptorBtn');
      if (addDescriptorBtn) {
        addDescriptorBtn.addEventListener('click', function () {
          document.getElementById('descriptorForm').reset();
          document.getElementById('descAction').value = 'add_descriptor';
          document.getElementById('descId').value = '';
          document.getElementById('descRemarks').value = 'Passed';
          document.getElementById('descType').value = 'NUMERICAL';
          toggleDescriptorFields();
          document.getElementById('descriptorModalLabel').textContent = 'Add Descriptor';
          bootstrap.Modal.getOrCreateInstance(document.getElementById('descriptorModal')).show();
        });
      }

      document.querySelectorAll('.edit-descriptor-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
          document.getElementById('descAction').value = 'update_descriptor';
          document.getElementById('descId').value = btn.getAttribute('data-id');
          document.getElementById('descType').value = btn.getAttribute('data-type') || 'NUMERICAL';
          document.getElementById('descRatingCode').value = btn.getAttribute('data-rating');
          document.getElementById('descGradeFrom').value = btn.getAttribute('data-from');
          document.getElementById('descGradeTo').value = btn.getAttribute('data-to');
          document.getElementById('descDescriptor').value = btn.getAttribute('data-descriptor');
          document.getElementById('descRemarks').value = btn.getAttribute('data-remarks');
          document.getElementById('descLevelFrom').value = btn.getAttribute('data-level-from');
          document.getElementById('descLevelTo').value = btn.getAttribute('data-level-to');
          toggleDescriptorFields();
          document.getElementById('descriptorModalLabel').textContent = 'Edit Descriptor';
          bootstrap.Modal.getOrCreateInstance(document.getElementById('descriptorModal')).show();
        });
      });

      updateWeightTotal();
    });
  </script>

</body>
</html>
