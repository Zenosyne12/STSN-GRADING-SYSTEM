<?php
require_once __DIR__ . '/../includes/auth.php';
requireSuperAdmin();
require_once __DIR__ . '/../api/shared/db_connect.php';
require_once __DIR__ . '/../includes/breadcrumb.php';

/* ============================================================
   Active tab (?tab=all | ?tab=workflow)
   ============================================================ */
$activeTab = $_GET['tab'] ?? 'all';
if (!in_array($activeTab, ['all', 'workflow'], true)) {
    $activeTab = 'all';
}

/* ============================================================
   TAB 1 — All Activity (tblactivity_log)
   ============================================================ */
$activities      = [];
$totalActivities = 0;
$activityPage    = max(1, (int)($_GET['page'] ?? 1));
$activityPerPage = 25;
$activityTotalPages = 1;
$activityStartEntry = 0;
$activityEndEntry = 0;
$filters = [
    'from'   => trim((string)($_GET['from'] ?? '')),
    'to'     => trim((string)($_GET['to'] ?? '')),
    'module' => trim((string)($_GET['module'] ?? '')),
    'action' => trim((string)($_GET['action'] ?? '')),
    'search' => trim((string)($_GET['search'] ?? '')),
];

$actionTypes = ['CREATE', 'UPDATE', 'DELETE', 'LOGIN', 'LOGOUT', 'SUBMIT', 'APPROVE', 'REJECT', 'PUBLISH', 'ENCODE', 'OTHER'];

try {
    $where  = [];
    $params = [];
    if ($filters['from'] !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $filters['from'])) {
        $where[]  = "created_at >= ?";
        $params[] = $filters['from'] . ' 00:00:00';
    }
    if ($filters['to'] !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $filters['to'])) {
        $where[]  = "created_at <= ?";
        $params[] = $filters['to'] . ' 23:59:59';
    }
    if ($filters['module'] !== '') {
        $where[]  = "module = ?";
        $params[] = $filters['module'];
    }
    if ($filters['action'] !== '' && in_array($filters['action'], $actionTypes, true)) {
        $where[]  = "action = ?";
        $params[] = $filters['action'];
    }
    if ($filters['search'] !== '') {
        $where[]  = "(user_name LIKE ? OR description LIKE ?)";
        $params[] = '%' . $filters['search'] . '%';
        $params[] = '%' . $filters['search'] . '%';
    }

    $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    // Count
    $cntStmt = $pdo->prepare("SELECT COUNT(*) FROM tblactivity_log $whereSql");
    $cntStmt->execute($params);
    $totalActivities = (int)$cntStmt->fetchColumn();

    $activityTotalPages = max(1, (int)ceil($totalActivities / $activityPerPage));
    $activityPage       = min($activityPage, $activityTotalPages);
    $activityOffset     = ($activityPage - 1) * $activityPerPage;

    // Fetch page
    $dataStmt = $pdo->prepare("
        SELECT * FROM tblactivity_log
        $whereSql
        ORDER BY created_at DESC, id DESC
        LIMIT {$activityPerPage} OFFSET {$activityOffset}
    ");
    $dataStmt->execute($params);
    $activities = $dataStmt->fetchAll(PDO::FETCH_ASSOC);

    if ($totalActivities > 0 && $activities) {
        $activityStartEntry = $activityOffset + 1;
        $activityEndEntry   = min($activityOffset + count($activities), $totalActivities);
    }
} catch (Throwable $e) {
    $activities      = [];
    $totalActivities = 0;
}

$activityFilterParams = array_filter([
    'tab'    => 'all',
    'from'   => $filters['from'],
    'to'     => $filters['to'],
    'module' => $filters['module'],
    'action' => $filters['action'],
    'search' => $filters['search'],
], static function ($value) {
    return $value !== '';
});

function activityPageUrl(array $params, int $page): string
{
    return 'Activity-Log.php?' . http_build_query(array_merge($params, ['page' => $page]));
}

// Module list for filter dropdown
$modules = [];
try {
    $modules = $pdo->query("SELECT DISTINCT module FROM tblactivity_log ORDER BY module ASC")
        ->fetchAll(PDO::FETCH_COLUMN);
} catch (Throwable $e) {
    $modules = [];
}

/* ============================================================
   TAB 2 — Workflow Actions (tblworkflow_action_log) — existing view
   ============================================================ */
$workflowActions = ['SUBMITTED', 'APPROVED', 'REJECTED', 'RETURNED', 'PUBLISHED', 'OVERRIDE'];
$perPage         = 50;
$hardCap         = 500;

$dateFrom = trim((string)($_GET['date_from'] ?? ''));
$dateTo   = trim((string)($_GET['date_to'] ?? ''));
$actorQ   = trim((string)($_GET['actor'] ?? ''));
$actionF  = strtoupper(trim((string)($_GET['action'] ?? '')));
if (!in_array($actionF, $workflowActions, true)) {
    $actionF = '';
}
$page = max(1, (int)($_GET['page'] ?? 1));

$wfWhere  = [];
$wfParams = [];
if ($dateFrom !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom)) {
    $wfWhere[]  = 'l.acted_at >= ?';
    $wfParams[] = $dateFrom . ' 00:00:00';
}
if ($dateTo !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo)) {
    $wfWhere[]  = 'l.acted_at <= ?';
    $wfParams[] = $dateTo . ' 23:59:59';
}
if ($actorQ !== '') {
    $wfWhere[]  = '(t.fname LIKE ? OR t.lname LIKE ? OR CONCAT(t.fname, " ", t.lname) LIKE ?)';
    $like       = '%' . $actorQ . '%';
    array_push($wfParams, $like, $like, $like);
}
if ($actionF !== '') {
    $wfWhere[]  = 'l.action = ?';
    $wfParams[] = $actionF;
}
$wfWhereSql = $wfWhere ? ('WHERE ' . implode(' AND ', $wfWhere)) : '';

$total = 0;
try {
    $countStmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM tblworkflow_action_log l
        LEFT JOIN tblteacher t ON t.id = l.actor_user_id
        {$wfWhereSql}
    ");
    $countStmt->execute($wfParams);
    $total = min((int)$countStmt->fetchColumn(), $hardCap);
} catch (Throwable $e) {
    $total = 0;
}

$totalPages = max(1, (int)ceil($total / $perPage));
$page       = min($page, $totalPages);
$offset     = ($page - 1) * $perPage;

$logs = [];
try {
    $logStmt = $pdo->prepare("
        SELECT l.id, l.instance_id, l.step_order, l.actor_position,
               l.actor_user_id, l.action, l.remarks, l.acted_at,
               t.fname, t.lname,
               i.section_id, i.subject_id
        FROM tblworkflow_action_log l
        LEFT JOIN tblteacher t ON t.id = l.actor_user_id
        LEFT JOIN tblworkflow_instance i ON i.id = l.instance_id
        {$wfWhereSql}
        ORDER BY l.acted_at DESC, l.id DESC
        LIMIT {$perPage} OFFSET {$offset}
    ");
    $logStmt->execute($wfParams);
    $logs = $logStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    $logs = [];
}

/* ============================================================
   Helper — action badge colours (foreground, background)
   ============================================================ */
if (!function_exists('alBadgeColors')) {
    function alBadgeColors(string $action): array
    {
        switch (strtoupper(trim($action))) {
            case 'CREATE':  return ['#065f46', '#d1fae5'];
            case 'UPDATE':  return ['#1e40af', '#dbeafe'];
            case 'DELETE':  return ['#991b1b', '#fee2e2'];
            case 'LOGIN':
            case 'LOGOUT':  return ['#475569', '#e2e8f0'];
            case 'SUBMIT':  return ['#92400e', '#fef3c7'];
            case 'APPROVE': return ['#065f46', '#d1fae5'];
            case 'REJECT':  return ['#991b1b', '#fee2e2'];
            case 'PUBLISH': return ['#5b21b6', '#ede9fe'];
            default:        return ['#334155', '#e2e8f0'];
        }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>STSN Grading System | Activity Log</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <meta name="color-scheme" content="light dark" />
  <meta name="theme-color" content="#8B1A1A" media="(prefers-color-scheme: light)" />
  <meta name="theme-color" content="#8B1A1A" />
  <meta name="title" content="STSN | Activity Log" />
  <meta name="author" content="G" />
  <meta name="description"
    content="STSN Grading System - A modern and accessible Bootstrap 5-based grading and student management platform for Schools. Secure, fast, and WCAG 2.1 AA compliant." />
  <meta name="supported-color-schemes" content="light dark" />
  <link rel="preload" href="../css/adminlte.css" as="style" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
    integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
    onload="this.media='all'" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="../css/adminlte.css" />
  <link rel="stylesheet" href="../css/dark-mode.css" />
  <link rel="stylesheet" href="../css/admin-responsive.css" />
  <link rel="stylesheet" href="../css/system-alerts.css" />
  <link rel="stylesheet" href="../css/superadmin-theme.css" />

  <style>
    .al-card {
      background: #fff;
      border: 1px solid var(--border, #E9ECEF);
      border-radius: 14px;
      box-shadow: 0 4px 12px rgba(10,47,68,0.06);
      margin-bottom: 1.25rem;
      overflow: hidden;
    }
    .al-card-header {
      padding: 1rem 1.25rem;
      border-bottom: 1px solid var(--border, #E9ECEF);
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 1rem;
      flex-wrap: wrap;
    }
    .al-card-title {
      font-size: 1.05rem;
      font-weight: 800;
      color: var(--primary, #0A2F44);
      display: flex;
      align-items: center;
      gap: 0.5rem;
      flex-wrap: wrap;
    }
    .al-card-title i { color: #C5A028; }
    .al-card-desc {
      font-size: 0.82rem;
      color: var(--muted, #6C757D);
      margin-top: 4px;
    }
    .al-card-body { padding: 1.25rem; }

    .al-table thead th {
      font-size: 0.72rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--muted, #6C757D);
      font-weight: 700;
      white-space: nowrap;
    }
    .al-action-badge { min-width: 96px; }
    .al-remarks { max-width: 320px; word-break: break-word; }
    .al-pagination-footer {
      display: flex;
      justify-content: flex-end;
      align-items: center;
      gap: 1rem;
      padding: 1rem 1.25rem;
      border-top: 1px solid var(--sa-border, #e5e7eb);
      flex-wrap: wrap;
    }
    .al-pagination-info {
      margin-right: auto;
      font-size: 0.85rem;
      color: #6b7280;
      white-space: nowrap;
    }
    .al-pagination-controls {
      display: flex;
      gap: 0.25rem;
      align-items: center;
      margin-left: auto;
      flex-wrap: wrap;
    }
    .al-pagination-footer .page-btn {
      padding: 0.4rem 0.75rem;
      border: 1px solid #e5e7eb;
      border-radius: 6px;
      font-size: 0.85rem;
      color: #374151;
      text-decoration: none;
      transition: background 0.15s;
      background: #fff;
    }
    .al-pagination-footer .page-btn:hover { background: #f3f4f6; }
    .al-pagination-footer .page-btn.active {
      background: #8B1A1A;
      color: #fff;
      border-color: #8B1A1A;
      font-weight: 700;
    }
    .al-pagination-footer .page-ellipsis {
      padding: 0.4rem 0.25rem;
      color: #6b7280;
    }

    /* Action pill */
    .al-pill {
      display: inline-block;
      padding: 0.18rem 0.55rem;
      border-radius: 999px;
      font-size: 0.72rem;
      font-weight: 700;
      letter-spacing: 0.02em;
      white-space: nowrap;
    }

    /* Tabs */
    .sa-tabs {
      display: flex;
      gap: 0.25rem;
      background: #fff;
      border: 1px solid #f5bcbc;
      border-radius: 12px;
      padding: 0.35rem;
      margin-bottom: 1rem;
    }
    .sa-tab {
      flex: 1;
      text-align: center;
      padding: 0.65rem 1rem;
      border-radius: 8px;
      text-decoration: none;
      color: #8B1A1A;
      font-weight: 700;
      font-size: 0.85rem;
      transition: all 0.15s;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 0.4rem;
    }
    .sa-tab:hover { background: #fdf2f2; }
    .sa-tab.active {
      background: #8B1A1A;
      color: #fff;
    }

    /* Dark mode support */
    [data-bs-theme="dark"] .al-card { background: #1a1d21; border-color: #2b3035; }
    [data-bs-theme="dark"] .al-card-header { border-bottom-color: #2b3035; }
    [data-bs-theme="dark"] .al-card-title { color: #e9ecef; }
    [data-bs-theme="dark"] .al-table thead th { color: #adb5bd; }
    [data-bs-theme="dark"] .sa-tabs { background: #1a1d21; border-color: #2b3035; }
    [data-bs-theme="dark"] .sa-tab { color: #f1a3a3; }
    [data-bs-theme="dark"] .sa-tab:hover { background: #2b3035; }
    [data-bs-theme="dark"] .sa-tab.active { background: #8B1A1A; color: #fff; }
  </style>

  <script src="../js/theme.js" defer></script>
</head>

<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">

  <div class="app-wrapper">
    <?php
    include_once '../includes/header.php';
    include_once '../includes/sAdmin_sidebar.php';
    ?>

    <main class="app-main">

      <div class="app-content-header">
      </div>
      <div class="app-content">
        <div class="container-fluid p-4">

          <!-- Page Header Banner -->
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3 p-4 text-white sa-page-header">
            <div class="d-flex align-items-center gap-3">
              <i class="bi bi-activity" style="font-size:1.5rem;"></i>
              <div>
                <h1 class="mb-0" style="font-size:1.5rem; font-weight:600;">Activity Log</h1>
                <p class="mb-0" style="font-size:0.85rem; opacity:0.85;">Full system audit trail — user actions, workflow steps and system events</p>
              </div>
            </div>
          </div>

          <!-- Breadcrumb -->
          <?php renderBreadcrumb([
            ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'],
            ['label' => 'System', 'href' => '#', 'icon' => 'bi bi-gear'],
            ['label' => 'Activity Log', 'icon' => 'bi bi-clock-history'],
          ]); ?>

          <!-- Info Banner -->
          <div class="alert alert-info d-flex align-items-start gap-2 small mb-3" role="alert">
            <i class="bi bi-info-circle mt-1"></i>
            <div>
              Browse every recorded system mutation on the <strong>All Activity</strong> tab, or switch to <strong>Workflow Actions</strong> for the approval audit trail. Lists show the 500 most recent records.
            </div>
          </div>

          <!-- Tabs -->
          <div class="sa-tabs">
            <a href="?tab=all" class="sa-tab <?= $activeTab === 'all' ? 'active' : '' ?>">
              <i class="bi bi-activity"></i> All Activity
            </a>
            <a href="?tab=workflow" class="sa-tab <?= $activeTab === 'workflow' ? 'active' : '' ?>">
              <i class="bi bi-diagram-3"></i> Workflow Actions
            </a>
          </div>


          <?php if ($activeTab === 'all'): ?>

          <!-- ============ TAB 1: All Activity ============ -->
          <div class="al-card">
            <div class="al-card-header">
              <div>
                <div class="al-card-title"><i class="bi bi-activity"></i> All Activity</div>
                <div class="al-card-desc">
                  Showing <?= $activityStartEntry ?>-<?= $activityEndEntry ?> of <?= $totalActivities ?> entr<?= $totalActivities === 1 ? 'y' : 'ies' ?> · page <?= $activityPage ?> of <?= $activityTotalPages ?>
                </div>
              </div>
              <form method="get" action="Activity-Log.php" class="d-flex flex-wrap align-items-end gap-2">
                <input type="hidden" name="tab" value="all">
                <div>
                  <label class="form-label mb-1" style="font-size:0.72rem;text-transform:uppercase;letter-spacing:.05em;color:var(--muted,#6C757D);">From</label>
                  <input type="date" class="form-control form-control-sm" name="from" value="<?= htmlspecialchars($filters['from']) ?>">
                </div>
                <div>
                  <label class="form-label mb-1" style="font-size:0.72rem;text-transform:uppercase;letter-spacing:.05em;color:var(--muted,#6C757D);">To</label>
                  <input type="date" class="form-control form-control-sm" name="to" value="<?= htmlspecialchars($filters['to']) ?>">
                </div>
                <div>
                  <label class="form-label mb-1" style="font-size:0.72rem;text-transform:uppercase;letter-spacing:.05em;color:var(--muted,#6C757D);">Module</label>
                  <select class="form-select form-select-sm" name="module" style="width:150px;">
                    <option value="">All modules</option>
                    <?php foreach ($modules as $m): ?>
                      <option value="<?= htmlspecialchars((string)$m) ?>" <?= $filters['module'] === (string)$m ? 'selected' : '' ?>><?= htmlspecialchars((string)$m) ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div>
                  <label class="form-label mb-1" style="font-size:0.72rem;text-transform:uppercase;letter-spacing:.05em;color:var(--muted,#6C757D);">Action</label>
                  <select class="form-select form-select-sm" name="action" style="width:150px;">
                    <option value="">All actions</option>
                    <?php foreach ($actionTypes as $type): ?>
                      <option value="<?= htmlspecialchars($type) ?>" <?= $filters['action'] === $type ? 'selected' : '' ?>><?= htmlspecialchars($type) ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div>
                  <label class="form-label mb-1" style="font-size:0.72rem;text-transform:uppercase;letter-spacing:.05em;color:var(--muted,#6C757D);">Search</label>
                  <input type="text" class="form-control form-control-sm" name="search" value="<?= htmlspecialchars($filters['search']) ?>" placeholder="User / description…" style="width:170px;">
                </div>
                <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-funnel-fill me-1"></i>Filter</button>
                <a href="Activity-Log.php?tab=all" class="btn btn-outline-secondary btn-sm"><i class="bi bi-x-circle me-1"></i>Reset</a>
              </form>
            </div>
            <div class="al-card-body">

              <?php if (!$activities): ?>
                <div class="d-flex flex-column align-items-center py-5 text-center">
                  <i class="bi bi-inbox" style="font-size:2rem; color:var(--muted, #6C757D);"></i>
                  <div class="fw-semibold mt-2">
                    <?= ($filters['from'] || $filters['to'] || $filters['module'] || $filters['action'] || $filters['search']) ? 'No results match your filters.' : 'No activity recorded yet' ?>
                  </div>
                  <div class="text-muted" style="font-size:0.85rem;">System actions (student/teacher/section changes, grade encoding, logins) are recorded here.</div>
                </div>
              <?php else: ?>
                <div class="table-responsive">
                  <table class="table table-sm table-hover align-middle al-table mb-0">
                    <thead>
                      <tr>
                        <th>Time</th>
                        <th>User</th>
                        <th>Role</th>
                        <th>Module</th>
                        <th>Action</th>
                        <th>Description</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($activities as $row): ?>
                        <?php
                        [$fg, $bg] = alBadgeColors((string)($row['action'] ?? ''));
                        $rowUser = (string)($row['user_name'] ?? '');
                        if ($rowUser === '') { $rowUser = 'System'; }
                        $rowRole = (string)($row['role'] ?? '');
                        ?>
                        <tr>
                          <td style="white-space:nowrap;"><?= htmlspecialchars(date('M d, Y h:i A', strtotime((string)($row['created_at'] ?? 'now')))) ?></td>
                          <td><?= htmlspecialchars($rowUser) ?></td>
                          <td><?= $rowRole !== '' ? htmlspecialchars($rowRole) : '<span class="text-muted">&mdash;</span>' ?></td>
                          <td><?= htmlspecialchars((string)($row['module'] ?? '')) ?></td>
                          <td><span class="al-pill" style="color:<?= $fg ?>;background:<?= $bg ?>;"><?= htmlspecialchars((string)($row['action'] ?? '')) ?></span></td>
                          <td class="al-remarks"><?= ((string)($row['description'] ?? '')) !== '' ? htmlspecialchars((string)$row['description']) : '<span class="text-muted">&mdash;</span>' ?></td>
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
                <div class="al-pagination-footer">
                  <div class="al-pagination-info">
                    Showing <?= $activityStartEntry ?>-<?= $activityEndEntry ?> of <?= $totalActivities ?> entries
                  </div>
                  <?php if ($activityTotalPages > 1): ?>
                    <nav class="al-pagination-controls" aria-label="Activity log pagination">
                      <?php if ($activityPage > 1): ?>
                        <a class="page-btn" href="<?= htmlspecialchars(activityPageUrl($activityFilterParams, $activityPage - 1)) ?>">&larr; Previous</a>
                      <?php endif; ?>

                      <?php
                      $activityPages = [1];
                      for ($p = max(1, $activityPage - 2); $p <= min($activityTotalPages, $activityPage + 2); $p++) {
                          $activityPages[] = $p;
                      }
                      $activityPages[] = $activityTotalPages;
                      $activityPages = array_values(array_unique(array_filter($activityPages, static function ($p) use ($activityTotalPages) {
                          return $p >= 1 && $p <= $activityTotalPages;
                      })));
                      sort($activityPages);
                      $lastPage = 0;
                      foreach ($activityPages as $p):
                          if ($lastPage > 0 && $p > $lastPage + 1):
                      ?>
                        <span class="page-ellipsis">&hellip;</span>
                      <?php endif; ?>
                        <a class="page-btn <?= $p === $activityPage ? 'active' : '' ?>"
                           href="<?= htmlspecialchars(activityPageUrl($activityFilterParams, $p)) ?>"><?= $p ?></a>
                      <?php
                          $lastPage = $p;
                      endforeach;
                      ?>

                      <?php if ($activityPage < $activityTotalPages): ?>
                        <a class="page-btn" href="<?= htmlspecialchars(activityPageUrl($activityFilterParams, $activityPage + 1)) ?>">Next &rarr;</a>
                      <?php endif; ?>
                    </nav>
                  <?php endif; ?>
                </div>
              <?php endif; ?>
            </div>
          </div>

          <?php else: ?>

          <!-- ============ TAB 2: Workflow Actions ============ -->
          <div class="al-card">
            <div class="al-card-header">
              <div>
                <div class="al-card-title"><i class="bi bi-list-check"></i> Workflow Activity</div>
                <div class="al-card-desc">Page <?= $page ?> of <?= $totalPages ?> · <?= $total ?> entr<?= $total === 1 ? 'y' : 'ies' ?> (capped at 500)</div>
              </div>
              <form method="get" action="Activity-Log.php" class="d-flex flex-wrap align-items-end gap-2">
                <input type="hidden" name="tab" value="workflow">
                <div>
                  <label class="form-label mb-1" style="font-size:0.72rem;text-transform:uppercase;letter-spacing:.05em;color:var(--muted,#6C757D);">From</label>
                  <input type="date" class="form-control form-control-sm" name="date_from" value="<?= htmlspecialchars($dateFrom) ?>">
                </div>
                <div>
                  <label class="form-label mb-1" style="font-size:0.72rem;text-transform:uppercase;letter-spacing:.05em;color:var(--muted,#6C757D);">To</label>
                  <input type="date" class="form-control form-control-sm" name="date_to" value="<?= htmlspecialchars($dateTo) ?>">
                </div>
                <div>
                  <label class="form-label mb-1" style="font-size:0.72rem;text-transform:uppercase;letter-spacing:.05em;color:var(--muted,#6C757D);">Actor</label>
                  <input type="text" class="form-control form-control-sm" name="actor" value="<?= htmlspecialchars($actorQ) ?>" placeholder="Name&hellip;" style="width:140px;">
                </div>
                <div>
                  <label class="form-label mb-1" style="font-size:0.72rem;text-transform:uppercase;letter-spacing:.05em;color:var(--muted,#6C757D);">Action</label>
                  <select class="form-select form-select-sm" name="action" style="width:150px;">
                    <option value="">All actions</option>
                    <?php foreach ($workflowActions as $type): ?>
                      <option value="<?= $type ?>" <?= $actionF === $type ? 'selected' : '' ?>><?= $type ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-funnel-fill me-1"></i>Filter</button>
                <a href="Activity-Log.php?tab=workflow" class="btn btn-outline-secondary btn-sm"><i class="bi bi-x-circle me-1"></i>Reset</a>
              </form>
            </div>
            <div class="al-card-body">
              <?php if (!$logs): ?>
                <div class="d-flex flex-column align-items-center py-5 text-center">
                  <i class="bi bi-inbox" style="font-size:2rem; color:var(--muted, #6C757D);"></i>
                  <div class="fw-semibold mt-2">No activity yet</div>
                  <div class="text-muted" style="font-size:0.85rem;">Workflow actions (submissions, approvals, overrides) will appear here once recorded.</div>
                </div>
              <?php else: ?>
                <div class="table-responsive">
                  <table class="table table-sm table-hover align-middle al-table mb-0">
                    <thead>
                      <tr>
                        <th>Timestamp</th>
                        <th>Actor</th>
                        <th>Position</th>
                        <th>Action</th>
                        <th>Step</th>
                        <th>Remarks</th>
                      </tr>
                    </thead>
                    <tbody>

                      <?php foreach ($logs as $log): ?>
                        <?php
                        $badgeClass = 'bg-secondary';
                        if ($log['action'] === 'SUBMITTED') { $badgeClass = 'bg-primary'; }
                        elseif ($log['action'] === 'APPROVED') { $badgeClass = 'bg-success'; }
                        elseif ($log['action'] === 'REJECTED') { $badgeClass = 'bg-danger'; }
                        elseif ($log['action'] === 'OVERRIDE') { $badgeClass = 'bg-warning text-dark'; }
                        elseif ($log['action'] === 'PUBLISHED') { $badgeClass = 'bg-info text-dark'; }
                        /* safe access — actor_user_id may be absent/NULL (system actions) */
                        $actorId   = (int)($log['actor_user_id'] ?? 0);
                        $actorName = trim(trim((string)($log['fname'] ?? '')) . ' ' . trim((string)($log['lname'] ?? '')));
                        if ($actorName === '') {
                            $actorName = $actorId > 0 ? ('User #' . $actorId) : 'System';
                        }
                        ?>
                        <tr>
                          <td style="white-space:nowrap;"><?= htmlspecialchars(date('M d, Y h:i A', strtotime((string)$log['acted_at']))) ?></td>
                          <td><?= $actorName !== '' ? htmlspecialchars($actorName) : '<span class="text-muted">System</span>' ?></td>
                          <td><?= htmlspecialchars((string)($log['actor_position'] ?? '')) ?></td>
                          <td><span class="badge <?= $badgeClass ?> al-action-badge"><?= htmlspecialchars((string)$log['action']) ?></span></td>
                          <td>Step <?= (int)$log['step_order'] ?><?= (int)$log['instance_id'] > 0 ? ' &middot; #' . (int)$log['instance_id'] : '' ?></td>
                          <td class="al-remarks"><?= htmlspecialchars((string)($log['remarks'] ?? '')) ?></td>
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
                <?php if ($totalPages > 1): ?>
                  <nav class="mt-3">
                    <ul class="pagination pagination-sm justify-content-center mb-0">
                      <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                        <a class="page-link" href="?<?= htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $page - 1, 'tab' => 'workflow']))) ?>">&laquo;</a>
                      </li>
                      <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                        <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                          <a class="page-link" href="?<?= htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $p, 'tab' => 'workflow']))) ?>"><?= $p ?></a>
                        </li>
                      <?php endfor; ?>
                      <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                        <a class="page-link" href="?<?= htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $page + 1, 'tab' => 'workflow']))) ?>">&raquo;</a>
                      </li>
                    </ul>
                  </nav>
                <?php endif; ?>
              <?php endif; ?>
            </div>
          </div>

          <?php endif; ?>


        </div>
      </div>

    </main>

    <?php
    include_once '../includes/footer.php';
    ?>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>

  <script src="../js/adminlte.js"></script>

  <script src="../js/system-alerts.js"></script>
  <script src="../js/superadmin-alerts.js"></script>
</body>

</html>

