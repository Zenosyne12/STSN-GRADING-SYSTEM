<?php
session_start();

// Auth guard: must be logged in as Super Admin (role_id = 4)
if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 4) {
    header('Location: ../login.php');
    exit;
}

require_once __DIR__ . '/../api/shared/db_connect.php';
require_once __DIR__ . '/../includes/breadcrumb.php';

$roles = [
    1 => 'Admin',
    2 => 'Teacher',
    3 => 'Student',
    4 => 'Super Admin',
];

// ------------------------- Filters -------------------------
$roleFilter = (int)($_GET['role_id'] ?? 0);
if ($roleFilter !== 0 && !isset($roles[$roleFilter])) {
    $roleFilter = 0;
}
$statusFilter = (string)($_GET['status'] ?? '');
if (!in_array($statusFilter, ['Active', 'Inactive'], true)) {
    $statusFilter = '';
}
$search = trim((string)($_GET['search'] ?? ''));
if (mb_strlen($search) > 100) {
    $search = mb_substr($search, 0, 100);
}

function uaFilterQuery(int $roleId, string $status, string $search): string
{
    $params = [];
    if ($roleId > 0) { $params['role_id'] = $roleId; }
    if ($status !== '') { $params['status'] = $status; }
    if ($search !== '') { $params['search'] = $search; }
    return $params === [] ? '' : '?' . http_build_query($params);
}

// ------------------------- POST handlers -------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');
    $back   = 'User-Accounts.php' . uaFilterQuery($roleFilter, $statusFilter, $search);

    $redirectWith = static function (string $key, array $extra = []) use ($back): void {
        $url = $back . (strpos($back, '?') !== false ? '&' : '?') . 'msg=' . urlencode($key);
        foreach ($extra as $k => $v) {
            $url .= '&' . urlencode((string)$k) . '=' . urlencode((string)$v);
        }
        header('Location: ' . $url);
        exit;
    };

    try {
        if ($action === 'toggle_status') {
            $userId = (int)($_POST['id'] ?? 0);
            if ($userId === (int)($_SESSION['user_id'] ?? 0)) {
                $redirectWith('error_self');
            }
            $stmt = $pdo->prepare('SELECT id, status FROM tblusers WHERE id = ? LIMIT 1');
            $stmt->execute([$userId]);
            $target = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($target === false) {
                $redirectWith('error_not_found');
            }
            $newStatus = strtolower((string)$target['status']) === 'active' ? 'Inactive' : 'Active';
            $upd = $pdo->prepare('UPDATE tblusers SET status = ? WHERE id = ?');
            $upd->execute([$newStatus, $userId]);
            $redirectWith('status_changed');
        }

        if ($action === 'reset_password') {
            $userId = (int)($_POST['id'] ?? 0);
            $stmt = $pdo->prepare('SELECT id FROM tblusers WHERE id = ? LIMIT 1');
            $stmt->execute([$userId]);
            if ($stmt->fetch(PDO::FETCH_ASSOC) === false) {
                $redirectWith('error_not_found');
            }
            $tempPassword = 'Stsn' . bin2hex(random_bytes(4));
            $upd = $pdo->prepare('UPDATE tblusers SET password_hash = ?, must_change_password = 1 WHERE id = ?');
            $upd->execute([password_hash($tempPassword, PASSWORD_DEFAULT), $userId]);
            $redirectWith('reset_ok', ['temp' => $tempPassword]);
        }

        if ($action === 'add_user') {
            $username  = trim((string)($_POST['username'] ?? ''));
            $newRole   = 1; // Always Admin

            if ($username === '' || mb_strlen($username) > 100) {
                $redirectWith('error_invalid_input');
            }

            $dup = $pdo->prepare('SELECT id FROM tblusers WHERE username = ? LIMIT 1');
            $dup->execute([$username]);
            if ($dup->fetch(PDO::FETCH_ASSOC) !== false) {
                $redirectWith('error_username_taken');
            }

            // Generate temporary password
            $tempPassword = 'Stsn' . bin2hex(random_bytes(4));
            $ins = $pdo->prepare(
                'INSERT INTO tblusers (username, password_hash, role_id, reference_id, status, must_change_password)
                 VALUES (?, ?, ?, ?, ?, 1)'
            );
            $ins->execute([$username, password_hash($tempPassword, PASSWORD_DEFAULT), $newRole, null, 'Active']);
            $redirectWith('added', ['temp' => $tempPassword]);
        }

        if ($action === 'update_workflow_role') {
            $teacherId  = (int)($_POST['teacher_id'] ?? 0);
            $role       = trim((string)($_POST['role'] ?? ''));
            $validRoles = ['ADVISER', 'SUBJECT_COORDINATOR', 'PRINCIPAL'];

            if ($teacherId <= 0) {
                $redirectWith('error_not_found');
            }
            if ($role === '') {
                $del = $pdo->prepare('DELETE FROM tblworkflow_role WHERE teacher_id = ?');
                $del->execute([$teacherId]);
                $redirectWith('workflow_role_removed');
            }
            if (!in_array($role, $validRoles, true)) {
                $redirectWith('error_invalid_input');
            }

            // Check if role is already assigned (only one Principal and one Subject Coordinator allowed)
            if ($role === 'PRINCIPAL' || $role === 'SUBJECT_COORDINATOR') {
                $check = $pdo->prepare('SELECT teacher_id FROM tblworkflow_role WHERE role = ? AND is_active = 1 LIMIT 1');
                $check->execute([$role]);
                if ($check->fetch(PDO::FETCH_ASSOC) !== false) {
                    $roleLabel = $role === 'PRINCIPAL' ? 'Principal' : 'Subject Coordinator';
                    $redirectWith('error_role_taken', ['role_name' => $roleLabel]);
                }
            }

            $assignedBy = (int)($_SESSION['user_id'] ?? 0);
            $upd = $pdo->prepare('UPDATE tblworkflow_role SET role = ?, is_active = 1, assigned_at = NOW(), assigned_by = ? WHERE teacher_id = ?');
            $upd->execute([$role, $assignedBy, $teacherId]);
            if ($upd->rowCount() === 0) {
                $ins = $pdo->prepare('INSERT INTO tblworkflow_role (teacher_id, role, is_active, assigned_at, assigned_by) VALUES (?, ?, 1, NOW(), ?)');
                $ins->execute([$teacherId, $role, $assignedBy]);
            }
            $redirectWith('workflow_role_updated');
        }

        $redirectWith('error_unknown_action');
    } catch (Throwable $e) {
        $redirectWith('error_db');
    }
}

// ------------------------- Flash message -------------------------
$flashMap = [
    'status_changed'            => ['User status updated successfully.', 'success'],
    'added'                     => ['User account created. Temporary password shared.', 'success'],
    'error_not_found'           => ['User account not found.', 'danger'],
    'error_self'                => ['You cannot deactivate your own account.', 'danger'],
    'error_invalid_input'       => ['Invalid input — username is required (max 100 characters).', 'danger'],
    'error_username_taken'      => ['That username is already taken.', 'danger'],
    'error_role_taken'          => ['This role is already assigned to another teacher.', 'danger'],
    'error_db'                  => ['Database error: the operation could not be completed.', 'danger'],
    'error_unknown_action'      => ['Unknown action.', 'danger'],
    'workflow_role_updated'     => ['Workflow role assigned successfully.', 'success'],
    'workflow_role_removed'     => ['Workflow role removed.', 'success'],
];
$msgKey       = (string)($_GET['msg'] ?? '');
$flashMessage = '';
$flashType    = 'success';
if ($msgKey === 'reset_ok') {
    $temp = (string)($_GET['temp'] ?? '');
    $flashMessage = $temp !== ''
        ? 'Password reset. Temporary password: <code>' . htmlspecialchars($temp, ENT_QUOTES, 'UTF-8') . '</code>'
        : 'Password reset successfully.';
    $flashType = 'success';
} elseif ($msgKey === 'added') {
    $temp = (string)($_GET['temp'] ?? '');
    $flashMessage = $temp !== ''
        ? 'Admin account created. Temporary password: <code>' . htmlspecialchars($temp, ENT_QUOTES, 'UTF-8') . '</code>'
        : 'Admin account created successfully.';
    $flashType = 'success';
} elseif ($msgKey !== '' && isset($flashMap[$msgKey])) {
    [$flashMessage, $flashType] = $flashMap[$msgKey];
}

// ------------------------- User list -------------------------
$sql = "SELECT u.id, u.username, u.role_id, u.reference_id, u.status, u.created_at,
           CASE
             WHEN u.role_id = 2 THEN (SELECT CONCAT(t.fname, ' ', t.lname) FROM tblteacher t WHERE t.id = u.reference_id)
             WHEN u.role_id = 3 THEN (SELECT CONCAT(s.fname, ' ', s.lname) FROM tblstudents s WHERE s.id = u.reference_id)
             ELSE NULL
           END AS reference_name
        FROM tblusers u
        WHERE u.role_id IN (1, 2)
          AND (:role_id = 0 OR u.role_id = :role_id)
          AND (:status = '' OR u.status = :status)
          AND (:search = '' OR u.username LIKE :search_like_u
               OR EXISTS (SELECT 1 FROM tblteacher t WHERE t.id = u.reference_id AND u.role_id = 2 AND CONCAT(t.fname, ' ', t.lname) LIKE :search_like_t)
               OR EXISTS (SELECT 1 FROM tblstudents s WHERE s.id = u.reference_id AND u.role_id = 3 AND CONCAT(s.fname, ' ', s.lname) LIKE :search_like_s))
        ORDER BY u.role_id ASC, u.username ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute([
    ':role_id'       => $roleFilter,
    ':status'        => $statusFilter,
    ':search'        => $search,
    ':search_like_u' => '%' . $search . '%',
    ':search_like_t' => '%' . $search . '%',
    ':search_like_s' => '%' . $search . '%',
]);
$users     = $stmt->fetchAll(PDO::FETCH_ASSOC);
$currentQs = uaFilterQuery($roleFilter, $statusFilter, $search);

$workflowRoles = [];
try {
    $wrStmt = $pdo->query('SELECT teacher_id, role FROM tblworkflow_role WHERE is_active = 1');
    foreach ($wrStmt->fetchAll(PDO::FETCH_ASSOC) as $wr) {
        $workflowRoles[(int)$wr['teacher_id']] = (string)$wr['role'];
    }
} catch (Throwable $e) {
    $workflowRoles = [];
}
?>
<!doctype html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>STSN Super Admin | Roles &amp; Permissions</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <meta name="color-scheme" content="light dark" />
  <meta name="theme-color" content="#8B1A1A" media="(prefers-color-scheme: light)" />
  <meta name="theme-color" content="#8B1A1A" />
  <meta name="supported-color-schemes" content="light dark" />
  <link rel="preload" href="../css/adminlte.css" as="style" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
    integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
    onload="this.media='all'" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="../css/adminlte.css" />
  <link rel="stylesheet" href="../css/dark-mode.css" />
  <link rel="stylesheet" href="../css/admin-responsive.css" />
  <link rel="stylesheet" href="../css/system-alerts.css" />
  <link rel="stylesheet" href="../css/superadmin-theme.css" />

  <style>
    .sa-table thead th {
      font-size: 0.72rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--muted, #6C757D);
      font-weight: 700;
      white-space: nowrap;
    }
    .sa-table td {
      vertical-align: middle;
    }

    /* Dark mode */
    [data-bs-theme="dark"] .sa-table thead th { color: #adb5bd; }
  </style>

  <script src="../js/theme.js" defer></script>
</head>

<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">

  <div class="app-wrapper">
    <?php
    include_once '../includes/header.php';
    include_once '../includes/sAdmin_sidebar.php';
    ?>

    <main class="app-main">

      <div class="app-content-header"></div>
      <div class="app-content">
        <div class="container-fluid p-4">

          <!-- Page Header Banner -->
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3 p-4 text-white sa-page-header">
            <div class="d-flex align-items-center gap-3">
              <i class="bi bi-shield-lock" style="font-size:1.5rem;"></i>
              <div>
                <h1 class="mb-0" style="font-size:1.5rem; font-weight:600;">Roles &amp; Permissions</h1>
                <p class="mb-0" style="font-size:0.85rem; opacity:0.85;">Manage user accounts and assign workflow roles to teachers</p>
              </div>
            </div>
          </div>

          <!-- Breadcrumb -->
          <?php renderBreadcrumb([
            ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'],
            ['label' => 'Access Control', 'href' => '#', 'icon' => 'bi bi-shield-lock'],
            ['label' => 'Roles & Permissions', 'icon' => 'bi bi-shield-lock'],
          ]); ?>

          <?php if ($flashMessage !== ''): ?>
            <div data-sa-flash="<?= htmlspecialchars($flashType) ?>"
                 data-sa-flash-message="<?= htmlspecialchars($flashMessage) ?>"
                 style="display:none"></div>
          <?php endif; ?>

          <!-- Toolbar -->
          <div class="card mb-4">
            <div class="card-body p-3">
              <form method="get" action="User-Accounts.php" id="filterForm" class="row g-2 align-items-end">
                <div class="col-auto">
                  <label class="form-label small mb-1" for="roleFilterSelect">Role</label>
                  <select class="form-select" id="roleFilterSelect" name="role_id" onchange="document.getElementById('filterForm').submit()">
                    <option value="0"<?= $roleFilter === 0 ? ' selected' : '' ?>>All Roles</option>
                    <option value="1"<?= $roleFilter === 1 ? ' selected' : '' ?>>Admin</option>
                    <option value="2"<?= $roleFilter === 2 ? ' selected' : '' ?>>Teacher</option>
                  </select>
                </div>
                <div class="col-auto">
                  <label class="form-label small mb-1" for="statusFilterSelect">Status</label>
                  <select class="form-select" id="statusFilterSelect" name="status" onchange="document.getElementById('filterForm').submit()">
                    <option value=""<?= $statusFilter === '' ? ' selected' : '' ?>>All</option>
                    <option value="Active"<?= $statusFilter === 'Active' ? ' selected' : '' ?>>Active</option>
                    <option value="Inactive"<?= $statusFilter === 'Inactive' ? ' selected' : '' ?>>Inactive</option>
                  </select>
                </div>
                <div class="col-auto flex-grow-1" style="min-width:220px;">
                  <label class="form-label small mb-1" for="searchInput">Search</label>
                  <input type="text" class="form-control" id="searchInput" name="search"
                         value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>"
                         placeholder="Username or linked name…" maxlength="100">
                </div>
                <div class="col-auto ms-auto d-flex gap-2">
                  <button type="button" class="btn btn-primary" id="addUserBtn"><i class="bi bi-person-plus me-1"></i> Add Admin</button>
                  <button type="button" class="btn btn-outline-primary" id="assignRoleBtn"><i class="bi bi-person-check-fill me-1"></i> Assign Role</button>
                </div>
              </form>
            </div>
          </div>

          <!-- User List -->
          <div class="card">
            <div class="card-header d-flex align-items-center gap-2">
              <i class="bi bi-people"></i>
              <strong>User List</strong>
              <span class="badge bg-secondary ms-2"><?= count($users) ?></span>
            </div>
            <div class="card-body p-0">
              <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 sa-table">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Username</th>
                      <th>Role</th>
                      <th>Reference</th>
                      <th>Status</th>
                      <th>Created</th>
                      <th class="text-end">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if ($users === []): ?>
                      <tr>
                        <td colspan="7" class="text-center text-muted py-4"><i class="bi bi-inbox me-1"></i>No user accounts match the current filters.</td>
                      </tr>
                    <?php else: foreach ($users as $user):
                        $userId        = (int)$user['id'];
                        $isActive      = strtolower((string)$user['status']) === 'active';
                        $roleName      = $roles[(int)$user['role_id']] ?? 'Unknown';
                        $rowQs         = htmlspecialchars($currentQs, ENT_QUOTES, 'UTF-8');
                        $referenceName = $user['reference_name'] !== null ? (string)$user['reference_name'] : '';
                        $isTeacher     = ((int)$user['role_id'] === 2) && !empty($user['reference_id']);
                    ?>
                      <tr>
                        <td><?= $userId ?></td>
                        <td class="fw-semibold"><?= htmlspecialchars((string)$user['username'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td><span class="badge <?= (int)$user['role_id'] === 4 ? 'bg-dark' : 'bg-secondary' ?>"><?= htmlspecialchars($roleName, ENT_QUOTES, 'UTF-8') ?></span></td>
                        <td>
                          <?php if ($isTeacher && !empty($user['reference_id'])): 
                            $teacherRole = $workflowRoles[(int)$user['reference_id']] ?? '';
                            $roleLabels = [
                              'ADVISER' => ['label' => 'Adviser', 'color' => 'primary'],
                              'SUBJECT_COORDINATOR' => ['label' => 'Subject Coordinator', 'color' => 'danger'],
                              'PRINCIPAL' => ['label' => 'Principal', 'color' => 'success'],
                            ];
                          ?>
                            <?= $referenceName !== '' ? htmlspecialchars($referenceName, ENT_QUOTES, 'UTF-8') : '—' ?>
                            <?php if ($teacherRole !== ''): 
                              $roleInfo = $roleLabels[$teacherRole] ?? ['label' => $teacherRole, 'color' => 'secondary'];
                            ?>
                              <span class="badge bg-<?= $roleInfo['color'] ?> ms-2" data-role="<?= htmlspecialchars($teacherRole) ?>"><?= htmlspecialchars($roleInfo['label']) ?></span>
                            <?php endif; ?>
                          <?php else: ?>
                            <?= $referenceName !== '' ? htmlspecialchars($referenceName, ENT_QUOTES, 'UTF-8') : '—' ?>
                          <?php endif; ?>
                        </td>
                        <td><span class="badge bg-<?= $isActive ? 'success' : 'secondary' ?>"><?= $isActive ? 'Active' : 'Inactive' ?></span></td>
                        <td><?= $user['created_at'] !== null && $user['created_at'] !== '' ? htmlspecialchars(date('M j, Y', strtotime((string)$user['created_at'])), ENT_QUOTES, 'UTF-8') : '—' ?></td>
                        <td class="text-end">
                          <div class="d-inline-flex gap-2 align-items-center">
                            <form method="post" action="User-Accounts.php<?= $rowQs ?>" class="d-inline"
                                  data-confirm="<?= $isActive ? 'Deactivate this account? The user will no longer be able to log in.' : 'Activate this account?' ?>">
                              <input type="hidden" name="action" value="toggle_status">
                              <input type="hidden" name="id" value="<?= $userId ?>">
                              <button type="submit" class="btn btn-outline-<?= $isActive ? 'warning' : 'success' ?> btn-sm"
                                      title="<?= $isActive ? 'Deactivate' : 'Activate' ?>">
                                <i class="bi bi-<?= $isActive ? 'person-slash' : 'person-check' ?> me-1"></i><?= $isActive ? 'Deactivate' : 'Activate' ?>
                              </button>
                            </form>
                            <form method="post" action="User-Accounts.php<?= $rowQs ?>" class="d-inline"
                                  data-confirm="Reset this user's password? A temporary password will be generated.">
                              <input type="hidden" name="action" value="reset_password">
                              <input type="hidden" name="id" value="<?= $userId ?>">
                              <button type="submit" class="btn btn-outline-primary btn-sm" title="Reset Password">
                                <i class="bi bi-key me-1"></i>Reset Password
                              </button>
                            </form>
                          </div>
                        </td>
                      </tr>
                    <?php endforeach; endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
      </div>

    </main>

    <?php include_once '../includes/footer.php'; ?>
  </div>

  <!-- Add Admin Modal -->
  <div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="addUserModalLabel">Add Admin</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form method="post" action="User-Accounts.php" id="addUserForm">
          <div class="modal-body">
            <input type="hidden" name="action" value="add_user">
            <div class="mb-3">
              <label class="form-label" for="newUsername">Username</label>
              <input type="text" class="form-control" id="newUsername" name="username" required maxlength="100"
                     placeholder="e.g. juandelacruz2026" autofocus>
              <div class="form-text">Admin account will be created with a temporary password.</div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary"><i class="bi bi-person-plus me-1"></i> Create Admin</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Workflow Role Modal -->
  <div class="modal fade" id="workflowModal" tabindex="-1" aria-labelledby="workflowModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="workflowModalLabel">Assign Workflow Role</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form method="post" action="User-Accounts.php" id="workflowForm">
          <div class="modal-body">
            <input type="hidden" name="action" value="update_workflow_role">
            
            <div class="mb-3">
              <label class="form-label" for="workflowTeacherSelect">Teacher</label>
              <select class="form-select" id="workflowTeacherSelect" name="teacher_id" required>
                <option value="">— Select Teacher —</option>
                <?php foreach ($users as $u):
                  if ((int)$u['role_id'] === 2 && !empty($u['reference_id'])):
                    $refName = $u['reference_name'] ?? '';
                    $currentRole = $workflowRoles[(int)$u['reference_id']] ?? '';
                    // Only show teachers WITHOUT roles
                    if ($currentRole === ''):
                ?>
                <option value="<?= (int)$u['reference_id'] ?>"><?= htmlspecialchars($refName) ?></option>
                <?php endif; endif; endforeach; ?>
              </select>
              <div class="form-text">Only unassigned teachers are shown.</div>
            </div>

            <div class="mb-3">
              <label class="form-label" for="workflowRoleSelect">Role</label>
              <select class="form-select" id="workflowRoleSelect" name="role" required>
                <option value="">— Clear Role —</option>
                <option value="ADVISER">Adviser</option>
                <option value="SUBJECT_COORDINATOR">Subject Coordinator</option>
                <option value="PRINCIPAL">Principal</option>
              </select>
              <div class="form-text mt-2">
                <strong>Adviser:</strong> Reviews and approves section grades<br>
                <strong>Subject Coordinator:</strong> Reviews subject-level submissions<br>
                <strong>Principal:</strong> Final approval of all submissions
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg me-1"></i> Assign Role</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>

  <script src="../js/adminlte.js"></script>

  <script src="../js/system-alerts.js"></script>
  <script src="../js/superadmin-alerts.js"></script>

  <script>
    document.addEventListener('DOMContentLoaded', function () {
      // Auto-dismiss alerts after 4s
      document.querySelectorAll('.alert-dismissible, .sa-alert').forEach(function (alertEl) {
        setTimeout(function () {
          if (window.bootstrap && bootstrap.Alert) {
            try {
              bootstrap.Alert.getOrCreateInstance(alertEl).close();
            } catch (e) {}
          } else {
            alertEl.remove();
          }
        }, 4000);
      });

      // (Form[data-confirm] dialogs are handled by js/superadmin-alerts.js — shared ay-confirm dialog)

      // Auto-submit search input
      var searchInput = document.getElementById('searchInput');
      if (searchInput) {
        var searchTimeout;
        searchInput.addEventListener('input', function () {
          clearTimeout(searchTimeout);
          searchTimeout = setTimeout(function () {
            document.getElementById('filterForm').submit();
          }, 500);
        });
      }

      // Add Admin button
      var addUserBtn = document.getElementById('addUserBtn');
      if (addUserBtn) {
        addUserBtn.addEventListener('click', function () {
          document.getElementById('addUserForm').reset();
          bootstrap.Modal.getOrCreateInstance(document.getElementById('addUserModal')).show();
        });
      }

      // Assign Role button
      var assignRoleBtn = document.getElementById('assignRoleBtn');
      if (assignRoleBtn) {
        assignRoleBtn.addEventListener('click', function () {
          document.getElementById('workflowForm').reset();
          updateRoleOptions();
          bootstrap.Modal.getOrCreateInstance(document.getElementById('workflowModal')).show();
        });
      }
    });

    // Update role dropdown to disable already-assigned roles
    function updateRoleOptions() {
      var assignedRoles = {};
      document.querySelectorAll('span.badge[data-role]').forEach(function(badge) {
        var role = badge.getAttribute('data-role');
        if (role) assignedRoles[role] = true;
      });

      var roleSelect = document.getElementById('workflowRoleSelect');
      roleSelect.querySelectorAll('option').forEach(function(option) {
        var optionValue = option.value;
        if (optionValue === 'ADVISER') {
          option.disabled = false;
        } else if (optionValue === '' || optionValue === 'ADVISER') {
          option.disabled = false;
        } else {
          option.disabled = assignedRoles[optionValue] || false;
        }
      });
    }
  </script>

</body>

</html>