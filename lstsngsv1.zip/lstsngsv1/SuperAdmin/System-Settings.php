<?php
session_start();

// Auth guard: must be logged in as Super Admin (role_id = 4)
if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 4) {
    header('Location: ../login.php');
    exit;
}

require_once __DIR__ . '/../api/shared/db_connect.php';
require_once __DIR__ . '/../includes/breadcrumb.php';
?>
<!doctype html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>STSN Grading System | System Settings</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <meta name="color-scheme" content="light dark" />
  <meta name="theme-color" content="#8B1A1A" media="(prefers-color-scheme: light)" />
  <meta name="theme-color" content="#8B1A1A" />
  <meta name="title" content="STSN | System Settings" />
  <meta name="author" content="G" />
  <meta name="description"
    content="STSN Grading System - A modern and accessible Bootstrap 5-based grading and student management platform for Schools. Secure, fast, and WCAG 2.1 AA compliant." />
  <meta name="supported-color-schemes" content="light dark" />
  <link rel="preload" href="../css/adminlte.css" as="style" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
    integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
    onload="this.media='all'" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="../css/adminlte.css" />
  <link rel="stylesheet" href="../css/dark-mode.css" />
  <link rel="stylesheet" href="../css/admin-responsive.css" />
  <link rel="stylesheet" href="../css/system-alerts.css" />
  <link rel="stylesheet" href="../css/superadmin-theme.css" />

  <style>
    .as-card {
      background: #fff;
      border: 1px solid var(--border, #E9ECEF);
      border-radius: 14px;
      box-shadow: 0 4px 12px rgba(10,47,68,0.06);
      margin-bottom: 1.25rem;
      overflow: hidden;
    }
    .as-card-header {
      padding: 1rem 1.25rem;
      border-bottom: 1px solid var(--border, #E9ECEF);
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 1rem;
      flex-wrap: wrap;
    }
    .as-card-title {
      font-size: 1.05rem;
      font-weight: 800;
      color: var(--primary, #0A2F44);
      display: flex;
      align-items: center;
      gap: 0.5rem;
      flex-wrap: wrap;
    }
    .as-card-title i { color: #C5A028; }
    .as-card-desc {
      font-size: 0.82rem;
      color: var(--muted, #6C757D);
      margin-top: 4px;
    }
    .as-card-body { padding: 1.25rem; }

    /* Hub link cards */
    .ss-link-card {
      display: flex;
      align-items: flex-start;
      gap: 0.85rem;
      height: 100%;
      background: #fff;
      border: 1px solid var(--border, #E9ECEF);
      border-radius: 12px;
      padding: 1rem;
      text-decoration: none;
      transition: border-color .15s ease, box-shadow .15s ease, transform .15s ease;
    }
    .ss-link-card:hover {
      border-color: #0D6EFD;
      box-shadow: 0 6px 16px rgba(13,110,253,0.12);
      transform: translateY(-2px);
    }
    .ss-link-icon {
      width: 42px;
      height: 42px;
      flex-shrink: 0;
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.15rem;
      background: rgba(13,110,253,0.08);
      color: #0D6EFD;
    }
    .ss-link-card:hover .ss-link-icon { background: rgba(13,110,253,0.14); }
    .ss-link-title {
      font-size: 0.95rem;
      font-weight: 700;
      color: var(--primary, #0A2F44);
      margin-bottom: 2px;
    }
    .ss-link-desc {
      font-size: 0.8rem;
      color: var(--muted, #6C757D);
      margin: 0;
    }
    .ss-link-arrow {
      margin-left: auto;
      align-self: center;
      color: #0D6EFD;
      opacity: 0;
      transform: translateX(-4px);
      transition: opacity .15s ease, transform .15s ease;
    }
    .ss-link-card:hover .ss-link-arrow { opacity: 1; transform: translateX(0); }

    /* Dark mode support */
     [data-bs-theme="dark"] .as-card { background: #1a1d21; border-color: #2b3035; } 
 [data-bs-theme="dark"] .as-card-header { border-bottom-color: #2b3035; } 
 [data-bs-theme="dark"] .as-card-title { color: #e9ecef; } 
 [data-bs-theme="dark"] .ss-link-card { background: #1a1d21; border-color: #2b3035; } 
 [data-bs-theme="dark"] .ss-link-title { color: #e9ecef; } 
 [data-bs-theme="dark"] .ss-link-icon { background: rgba(13,110,253,0.18); color: #6ea8fe; } 

  </style>

  <script src="../js/theme.js" defer></script>
</head>
<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">

  <div class="app-wrapper">
    <?php
    include_once '../includes/header.php';
    include_once '../includes/sAdmin_sidebar.php';
    ?>

    <main class="app-main">

      <div class="app-content-header">
      </div>
      <div class="app-content">
        <div class="container-fluid p-4">

          <!-- Page Header Banner -->
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3 p-4 text-white sa-page-header">
            <div class="d-flex align-items-center gap-3">
              <i class="bi bi-gear-fill" style="font-size:1.5rem;"></i>
              <div>
                <h1 class="mb-0" style="font-size:1.5rem; font-weight:600;">System Settings</h1>
                <p class="mb-0" style="font-size:0.85rem; opacity:0.85;">Central configuration hub for the grading system</p>
              </div>
            </div>
          </div>

          <!-- Breadcrumb -->
          <?php renderBreadcrumb([
            ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'],
            ['label' => 'System Settings', 'icon' => 'bi bi-gear-fill'],
          ]); ?>

          <!-- Section 1: System Configuration -->
          <div class="as-card">
            <div class="as-card-header">
              <div>
                <div class="as-card-title"><i class="bi bi-gear-fill"></i> System Configuration</div>
                <div class="as-card-desc">Programs, subjects, curriculum, grading, workflow and archive configuration.</div>
              </div>
            </div>
            <div class="as-card-body">
              <div class="row g-3">
                <div class="col-md-4">
                  <a href="Subjects.php" class="ss-link-card">
                    <div class="ss-link-icon"><i class="bi bi-diagram-3"></i></div>
                    <div>
                      <div class="ss-link-title">Programs</div>
                      <p class="ss-link-desc">Manage program offerings and strands.</p>
                    </div>
                    <i class="bi bi-arrow-right ss-link-arrow"></i>
                  </a>
                </div>
                <div class="col-md-4">
                  <a href="Subjects.php" class="ss-link-card">
                    <div class="ss-link-icon"><i class="bi bi-book"></i></div>
                    <div>
                      <div class="ss-link-title">Subject Master</div>
                      <p class="ss-link-desc">Master list of subjects across programs.</p>
                    </div>
                    <i class="bi bi-arrow-right ss-link-arrow"></i>
                  </a>
                </div>
                <div class="col-md-4">
                  <a href="../Curriculum.php" class="ss-link-card">
                    <div class="ss-link-icon"><i class="bi bi-journals"></i></div>
                    <div>
                      <div class="ss-link-title">Curriculum Templates</div>
                      <p class="ss-link-desc">Curriculum checklists and template management.</p>
                    </div>
                    <i class="bi bi-arrow-right ss-link-arrow"></i>
                  </a>
                </div>
                <div class="col-md-4">
                  <a href="Grading-Templates.php" class="ss-link-card">
                    <div class="ss-link-icon"><i class="bi bi-sliders"></i></div>
                    <div>
                      <div class="ss-link-title">Grading Configuration</div>
                      <p class="ss-link-desc">Grading periods, weights and computation rules.</p>
                    </div>
                    <i class="bi bi-arrow-right ss-link-arrow"></i>
                  </a>
                </div>
                <div class="col-md-4">
                  <a href="Workflow-Configuration.php" class="ss-link-card">
                    <div class="ss-link-icon"><i class="bi bi-diagram-2"></i></div>
                    <div>
                      <div class="ss-link-title">Workflow Templates</div>
                      <p class="ss-link-desc">Approval workflow steps for grade submissions.</p>
                    </div>
                    <i class="bi bi-arrow-right ss-link-arrow"></i>
                  </a>
                </div>
                <div class="col-md-4">
                  <a href="Archive-Settings.php" class="ss-link-card">
                    <div class="ss-link-icon"><i class="bi bi-archive"></i></div>
                    <div>
                      <div class="ss-link-title">Archive Settings</div>
                      <p class="ss-link-desc">Automatic and manual academic-year archiving.</p>
                    </div>
                    <i class="bi bi-arrow-right ss-link-arrow"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>

          <!-- Section 2: Access Control -->
          <div class="as-card">
            <div class="as-card-header">
              <div>
                <div class="as-card-title"><i class="bi bi-shield-lock-fill"></i> Access Control</div>
                <div class="as-card-desc">Roles, permissions and user account management.</div>
              </div>
            </div>
            <div class="as-card-body">
              <div class="row g-3">
                <div class="col-md-6">
                  <a href="../manageA.php" class="ss-link-card">
                    <div class="ss-link-icon"><i class="bi bi-shield-lock"></i></div>
                    <div>
                      <div class="ss-link-title">Roles &amp; Permissions</div>
                      <p class="ss-link-desc">Administrator and staff role definitions.</p>
                    </div>
                    <i class="bi bi-arrow-right ss-link-arrow"></i>
                  </a>
                </div>
                <div class="col-md-6">
                  <a href="../teacher.php" class="ss-link-card">
                    <div class="ss-link-icon"><i class="bi bi-people"></i></div>
                    <div>
                      <div class="ss-link-title">User Accounts</div>
                      <p class="ss-link-desc">Teacher, staff and admin account management.</p>
                    </div>
                    <i class="bi bi-arrow-right ss-link-arrow"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>

          <!-- Section 3: System Tools -->
          <div class="as-card">
            <div class="as-card-header">
              <div>
                <div class="as-card-title"><i class="bi bi-tools"></i> System Tools</div>
                <div class="as-card-desc">System activity monitoring and data safety.</div>
              </div>
            </div>
            <div class="as-card-body">
              <div class="row g-3">
                <div class="col-md-6">
                  <a href="../activity_log.php" class="ss-link-card">
                    <div class="ss-link-icon"><i class="bi bi-clock-history"></i></div>
                    <div>
                      <div class="ss-link-title">Activity Log</div>
                      <p class="ss-link-desc">Record of actions taken across the system.</p>
                    </div>
                    <i class="bi bi-arrow-right ss-link-arrow"></i>
                  </a>
                </div>
                <div class="col-md-6">
                  <a href="Backup-Restore.php" class="ss-link-card">
                    <div class="ss-link-icon"><i class="bi bi-database"></i></div>
                    <div>
                      <div class="ss-link-title">Backup &amp; Restore</div>
                      <p class="ss-link-desc">Database backups and restoration tools.</p>
                    </div>
                    <i class="bi bi-arrow-right ss-link-arrow"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>

    </main>

    <?php
    include_once '../includes/footer.php';
    ?>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>

  <script src="../js/adminlte.js"></script>

  <script src="../js/system-alerts.js"></script>
  <script src="../js/superadmin-alerts.js"></script>
</body>

</html>