<?php
session_start();

// Auth guard: must be logged in as Super Admin (role_id = 4)
if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 4) {
    header('Location: ../login.php');
    exit;
}

require_once '../api/shared/db_connect.php';
require_once __DIR__ . '/../includes/breadcrumb.php';

/* ============================================================
   Dashboard analytics — SuperAdmin
   ============================================================ */
$activeYearIdSA = 0;
try {
    $activeYearIdSA = (int)$pdo->query("SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1")->fetchColumn();
} catch (Throwable $e) {
    $activeYearIdSA = 0;
}

/* Block A — School Analytics Overview */
$stats = ['students' => 0, 'sections' => 0, 'teachers' => 0, 'grades' => 0];
try {
    if ($activeYearIdSA > 0) {
        $stmt = $pdo->prepare("SELECT COUNT(DISTINCT ss.student_id)
            FROM tblsectionstudent ss
            WHERE ss.academic_year_id = ? AND ss.is_active = 1");
        $stmt->execute([$activeYearIdSA]);
        $stats['students'] = (int)$stmt->fetchColumn();
    }
    $stats['sections'] = (int)$pdo->query("SELECT COUNT(*) FROM tblsection WHERE is_active = 1")->fetchColumn();
    $stats['teachers'] = (int)$pdo->query("SELECT COUNT(*) FROM tblteacher")->fetchColumn();
    $stats['grades']   = (int)$pdo->query("SELECT COUNT(*) FROM tblgrades")->fetchColumn();
} catch (Throwable $e) {
    $stats = ['students' => 0, 'sections' => 0, 'teachers' => 0, 'grades' => 0];
}

/* Block B — Performance by Grade Level */
$gradeLevelAverages = [];
try {
    if ($activeYearIdSA > 0) {
        $stmt = $pdo->prepare("SELECT gl.grade_level_name, AVG(g.numeric_grade) AS avg_grade
            FROM tblgrades g
            JOIN tblsection sec ON sec.id = g.section_id
            JOIN tblgradelevel gl ON gl.id = sec.grade_level_id
            WHERE g.academic_year_id = ? AND g.numeric_grade IS NOT NULL
            GROUP BY gl.id, gl.grade_level_name
            ORDER BY gl.grade_level_code ASC");
        $stmt->execute([$activeYearIdSA]);
        $gradeLevelAverages = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }
} catch (Throwable $e) {
    $gradeLevelAverages = [];
}

/* Block C — Top Performing Sections */
$topSections = [];
try {
    if ($activeYearIdSA > 0) {
        $stmt = $pdo->prepare("SELECT s.section_name, gl.grade_level_name,
               AVG(g.numeric_grade) AS avg_grade,
               COUNT(DISTINCT g.student_id) AS student_count
            FROM tblgrades g
            JOIN tblsection s ON s.id = g.section_id
            JOIN tblgradelevel gl ON gl.id = s.grade_level_id
            WHERE g.academic_year_id = ? AND g.numeric_grade IS NOT NULL
            GROUP BY s.id, s.section_name, gl.grade_level_name
            ORDER BY avg_grade DESC
            LIMIT 5");
        $stmt->execute([$activeYearIdSA]);
        $topSections = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }
} catch (Throwable $e) {
    $topSections = [];
}

/* Block D — Performance Forecast (Linear Regression) */
function linearRegression(array $xs, array $ys): array {
    $n = count($xs);
    if ($n < 2) return ['slope' => 0, 'intercept' => 0, 'predict' => null];
    $sumX = array_sum($xs); $sumY = array_sum($ys);
    $sumXY = 0; $sumX2 = 0;
    for ($i = 0; $i < $n; $i++) {
        $sumXY += $xs[$i] * $ys[$i];
        $sumX2 += $xs[$i] * $xs[$i];
    }
    $denom = ($n * $sumX2) - ($sumX * $sumX);
    if ($denom == 0) return ['slope' => 0, 'intercept' => 0, 'predict' => null];
    $slope     = (($n * $sumXY) - ($sumX * $sumY)) / $denom;
    $intercept = ($sumY - ($slope * $sumX)) / $n;
    $nextX     = $n + 1;
    $predict   = ($slope * $nextX) + $intercept;
    return [
        'slope'     => round($slope, 4),
        'intercept' => round($intercept, 2),
        'predict'   => round($predict, 2),
    ];
}

$termAverages = [];
try {
    if ($activeYearIdSA > 0) {
        $stmt = $pdo->prepare("SELECT t.term_number, t.term_label, AVG(g.numeric_grade) AS avg_grade
            FROM tblgrades g
            JOIN tblconfig_terms t ON t.academic_year_id = g.academic_year_id
                                   AND t.term_number = g.quarter
            WHERE g.academic_year_id = ? AND g.numeric_grade IS NOT NULL
              AND g.quarter BETWEEN 1 AND 3
            GROUP BY t.term_number, t.term_label
            ORDER BY t.term_number ASC");
        $stmt->execute([$activeYearIdSA]);
        $termAverages = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }
} catch (Throwable $e) {
    $termAverages = [];
}

$forecast       = null;
$forecastTrend  = 'STABLE';
$forecastBadge  = 'bg-secondary-subtle text-secondary-emphasis';
if (count($termAverages) >= 2) {
    $forecast = linearRegression(
        array_map('intval', array_column($termAverages, 'term_number')),
        array_map('floatval', array_column($termAverages, 'avg_grade'))
    );
    if ($forecast !== null && $forecast['predict'] !== null) {
        if ($forecast['slope'] > 0.5) {
            $forecastTrend = 'UP';
            $forecastBadge = 'bg-success-subtle text-success-emphasis';
        } elseif ($forecast['slope'] < -0.5) {
            $forecastTrend = 'DOWN';
            $forecastBadge = 'bg-danger-subtle text-danger-emphasis';
        }
    }
}
?>
<!doctype html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>STSN Grading System | Super Admin Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <meta name="color-scheme" content="light dark" />
  <meta name="theme-color" content="#8B1A1A" media="(prefers-color-scheme: light)" />
  <meta name="theme-color" content="#8B1A1A" />
  <meta name="title" content="STSN | Super Admin Dashboard" />
  <meta name="author" content="G" />
  <meta name="description"
    content="STSN Grading System - A modern and accessible Bootstrap 5-based grading and student management platform for Schools. Secure, fast, and WCAG 2.1 AA compliant." />
  <meta name="keywords"
    content="STSN, STSN Grading System, school grading system, student information system, bootstrap 5 admin dashboard, grading dashboard, student records, class management, teacher tools, accessible admin panel" />
  <meta name="supported-color-schemes" content="light dark" />
  <link rel="preload" href="../css/adminlte.css" as="style" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
    integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
    onload="this.media='all'" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="../css/adminlte.css" />
  <link rel="stylesheet" href="../css/dark-mode.css" />
  <link rel="stylesheet" href="../css/admin-responsive.css" />
  <link rel="stylesheet" href="../css/system-alerts.css" />
  <link rel="stylesheet" href="../css/superadmin-theme.css" />
  <script src="../js/theme.js" defer></script>
</head>

<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">

  <div class="app-wrapper">
    <?php
    include_once '../includes/header.php';
    include_once '../includes/sAdmin_sidebar.php';
    ?>

    <main class="app-main">

      <div class="app-content-header">
      </div>
      <div class="app-content">
        <div class="container-fluid p-4">

          <!-- SECTION 1: Page Header Banner -->
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3 p-4 text-white sa-page-header">
            <div class="d-flex align-items-center gap-3">
              <i class="bi bi-speedometer2" style="font-size:1.5rem;"></i>
              <div>
                <h1 class="mb-0" style="font-size:1.5rem; font-weight:600;">System Dashboard</h1>
                <p class="mb-0" style="font-size:0.85rem; opacity:0.85;">System configuration and activity overview</p>
              </div>
            </div>
            <div class="small opacity-75">
              <i class="bi bi-calendar3 me-1"></i>S.Y. 2026-2027
            </div>
          </div>

          <!-- SECTION 2: Breadcrumb -->
          <?php renderBreadcrumb([
            ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'],
            ['label' => 'Dashboard', 'icon' => 'bi bi-speedometer2'],
          ]); ?>

          <!-- SECTION 3: Stat Cards -->
          <div class="row g-3 mb-3">
            <div class="col-md-3">
              <div class="card h-100">
                <div class="card-body p-3">
                  <div class="d-flex align-items-center justify-content-center rounded-circle mb-3"
                       style="width:48px; height:48px; background-color:#0D6EFD;">
                    <i class="bi bi-calendar-check text-white" style="font-size:1.25rem;"></i>
                  </div>
                  <h2 class="mb-0 fw-bold" style="font-size:1.5rem;">2026-2027</h2>
                  <div class="text-muted" style="font-size:0.85rem;">3 Terms &middot; Active</div>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="card h-100">
                <div class="card-body p-3">
                  <div class="d-flex align-items-center justify-content-center rounded-circle mb-3"
                       style="width:48px; height:48px; background-color:#198754;">
                    <i class="bi bi-diagram-3 text-white" style="font-size:1.25rem;"></i>
                  </div>
                  <h2 class="mb-0 fw-bold" style="font-size:1.5rem;">3</h2>
                  <div class="text-muted" style="font-size:0.85rem;">ELEM &middot; JHS &middot; SHS</div>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="card h-100">
                <div class="card-body p-3">
                  <div class="d-flex align-items-center justify-content-center rounded-circle mb-3"
                       style="width:48px; height:48px; background-color:#0DCAF0;">
                    <i class="bi bi-journal-bookmark text-dark" style="font-size:1.25rem;"></i>
                  </div>
                  <h2 class="mb-0 fw-bold" style="font-size:1.5rem;">0</h2>
                  <div class="text-muted" style="font-size:0.85rem;">None configured</div>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="card h-100">
                <div class="card-body p-3">
                  <div class="d-flex align-items-center justify-content-center rounded-circle mb-3"
                       style="width:48px; height:48px; background-color:#FFC107;">
                    <i class="bi bi-people text-dark" style="font-size:1.25rem;"></i>
                  </div>
                  <h2 class="mb-0 fw-bold" style="font-size:1.5rem;">0</h2>
                  <div class="text-muted" style="font-size:0.85rem;">Active accounts</div>
                </div>
              </div>
            </div>
          </div>


          <!-- SECTION 4: School Analytics Overview (Block A) -->
          <div class="row g-3 mb-3">
            <div class="col-md-3">
              <div class="card h-100">
                <div class="card-body p-3">
                  <div class="d-flex align-items-center justify-content-center rounded-circle mb-3"
                       style="width:48px; height:48px; background-color:#8B1A1A;">
                    <i class="bi bi-people-fill text-white" style="font-size:1.25rem;"></i>
                  </div>
                  <h2 class="mb-0 fw-bold" style="font-size:1.5rem;"><?= number_format($stats['students']) ?></h2>
                  <div class="text-muted" style="font-size:0.85rem;">Total Students &middot; Active, Current S.Y.</div>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="card h-100">
                <div class="card-body p-3">
                  <div class="d-flex align-items-center justify-content-center rounded-circle mb-3"
                       style="width:48px; height:48px; background-color:#8B1A1A;">
                    <i class="bi bi-grid-3x3-gap-fill text-white" style="font-size:1.25rem;"></i>
                  </div>
                  <h2 class="mb-0 fw-bold" style="font-size:1.5rem;"><?= number_format($stats['sections']) ?></h2>
                  <div class="text-muted" style="font-size:0.85rem;">Total Sections</div>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="card h-100">
                <div class="card-body p-3">
                  <div class="d-flex align-items-center justify-content-center rounded-circle mb-3"
                       style="width:48px; height:48px; background-color:#6B1414;">
                    <i class="bi bi-person-video3 text-white" style="font-size:1.25rem;"></i>
                  </div>
                  <h2 class="mb-0 fw-bold" style="font-size:1.5rem;"><?= number_format($stats['teachers']) ?></h2>
                  <div class="text-muted" style="font-size:0.85rem;">Total Teachers</div>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="card h-100">
                <div class="card-body p-3">
                  <div class="d-flex align-items-center justify-content-center rounded-circle mb-3"
                       style="width:48px; height:48px; background-color:#9E2626;">
                    <i class="bi bi-journal-check text-white" style="font-size:1.25rem;"></i>
                  </div>
                  <h2 class="mb-0 fw-bold" style="font-size:1.5rem;"><?= number_format($stats['grades']) ?></h2>
                  <div class="text-muted" style="font-size:0.85rem;">Total Grade Records</div>
                </div>
              </div>
            </div>
          </div>
          <!-- SECTION 5: Performance by Grade Level + Top Performing Sections -->
          <div class="row g-3 mb-3">
            <div class="col-lg-7">
              <div class="card h-100">
                <div class="card-header d-flex align-items-center gap-2">
                  <i class="bi bi-bar-chart-fill" style="color:#8B1A1A;"></i>
                  <strong>Performance by Grade Level</strong>
                  <span class="ms-auto small text-muted">Average grade &middot; Current S.Y.</span>
                </div>
                <div class="card-body">
                  <?php if ($gradeLevelAverages === []): ?>
                    <div class="alert alert-info mb-0">
                      <i class="bi bi-info-circle me-1"></i>No grade data recorded yet for the current school year.
                    </div>
                  <?php else: ?>
                    <div style="height:280px; position:relative;">
                      <canvas id="gradeLevelChart"></canvas>
                    </div>
                  <?php endif; ?>
                </div>
              </div>
            </div>
            <div class="col-lg-5">
              <div class="card h-100">
                <div class="card-header d-flex align-items-center gap-2">
                  <i class="bi bi-trophy-fill" style="color:#C5A028;"></i>
                  <strong>Top Performing Sections</strong>
                  <span class="ms-auto small text-muted">Top 5 &middot; Current S.Y.</span>
                </div>
                <div class="card-body p-0">
                  <?php if ($topSections === []): ?>
                    <div class="p-3">
                      <div class="alert alert-info mb-0">
                        <i class="bi bi-info-circle me-1"></i>No grade data recorded yet for the current school year.
                      </div>
                    </div>
                  <?php else: ?>
                    <div class="table-responsive">
                      <table class="table table-hover align-middle mb-0">
                        <thead>
                          <tr>
                            <th style="width:44px;">#</th>
                            <th>Section</th>
                            <th>Grade Level</th>
                            <th class="text-center">Students</th>
                            <th class="text-end">Avg Grade</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php foreach ($topSections as $i => $ts): ?>
                            <tr>
                              <td class="text-muted"><?= $i + 1 ?></td>
                              <td class="fw-semibold"><?= htmlspecialchars($ts['section_name']) ?></td>
                              <td><span class="badge bg-secondary-subtle text-secondary-emphasis"><?= htmlspecialchars($ts['grade_level_name']) ?></span></td>
                              <td class="text-center"><?= number_format((int)$ts['student_count']) ?></td>
                              <td class="text-end fw-bold" style="color:#8B1A1A;"><?= number_format((float)$ts['avg_grade'], 2) ?></td>
                            </tr>
                          <?php endforeach; ?>
                        </tbody>
                      </table>
                    </div>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          </div>

          <!-- SECTION 6: Performance Forecast (Block D) -->
          <div class="card mb-3">
            <div class="card-header d-flex align-items-center gap-2">
              <i class="bi bi-graph-up-arrow" style="color:#8B1A1A;"></i>
              <strong>Performance Forecast</strong>
              <span class="small text-muted">(Linear Regression)</span>
              <?php if ($forecast !== null): ?>
                <span class="badge <?= $forecastBadge ?> ms-auto">
                  <i class="bi bi-arrow-<?= $forecastTrend === 'UP' ? 'up' : ($forecastTrend === 'DOWN' ? 'down' : 'dash') ?>"></i>
                  <?= $forecastTrend ?>
                </span>
              <?php endif; ?>
            </div>
            <div class="card-body">
              <?php if ($forecast === null): ?>
                <div class="alert alert-info mb-0">
                  <i class="bi bi-info-circle me-1"></i>
                  Not enough data for prediction. Need at least 2 terms of recorded grades.
                </div>
              <?php else: ?>
                <div style="height:220px; position:relative;">
                  <canvas id="forecastChart"></canvas>
                </div>
                <p class="mb-0 mt-3" style="font-size:0.9rem;">
                  <i class="bi bi-info-circle me-1" style="color:#8B1A1A;"></i>
                  Based on <?= count($termAverages) ?> term<?= count($termAverages) === 1 ? '' : 's' ?> of data,
                  the average grade is trending <strong><?= $forecastTrend ?></strong>
                  by <strong><?= number_format(abs($forecast['slope']), 2) ?></strong> points per term.
                  Predicted Term <?= count($termAverages) + 1 ?> average:
                  <strong style="color:#8B1A1A;"><?= number_format($forecast['predict'], 2) ?></strong>.
                </p>
              <?php endif; ?>
            </div>
          </div>


          <!-- SECTION 5: System Health + DepEd Compliance -->
          <div class="row g-3 mb-3">
            <div class="col-lg-6">
              <div class="card h-100">
                <div class="card-header d-flex align-items-center gap-2">
                  <i class="bi bi-heart-pulse"></i>
                  <strong>System Health</strong>
                </div>
                <div class="card-body p-3">
                  <div class="d-flex align-items-center justify-content-between py-2">
                    <span class="d-flex align-items-center gap-2 text-body"><i class="bi bi-database"></i> Database Connection</span>
                    <span class="badge bg-success-subtle text-success-emphasis">Connected</span>
                  </div>
                  <div class="d-flex align-items-center justify-content-between py-2">
                    <span class="d-flex align-items-center gap-2 text-body"><i class="bi bi-filetype-php"></i> PHP Version</span>
                    <span class="badge bg-secondary-subtle text-secondary-emphasis"><?= htmlspecialchars(PHP_VERSION) ?></span>
                  </div>
                  <div class="d-flex align-items-center justify-content-between py-2">
                    <span class="d-flex align-items-center gap-2 text-body"><i class="bi bi-server"></i> MySQL Version</span>
                    <span class="badge bg-secondary-subtle text-secondary-emphasis">8.4</span>
                  </div>
                  <div class="d-flex align-items-center justify-content-between py-2">
                    <span class="d-flex align-items-center gap-2 text-body"><i class="bi bi-cloud-arrow-up"></i> Last Backup</span>
                    <span class="badge bg-secondary-subtle text-secondary-emphasis">Never</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="card h-100">
                <div class="card-header d-flex align-items-center gap-2">
                  <i class="bi bi-patch-check"></i>
                  <strong>DepEd Compliance (DO 015, s. 2026)</strong>
                </div>
                <div class="card-body p-3">
                  <div class="d-flex align-items-start gap-2 py-2">
                    <i class="bi bi-check-circle-fill text-success"></i>
                    <div>
                      <div class="text-body fw-semibold">3-Term Structure</div>
                      <div class="text-muted" style="font-size:0.85rem;">Enabled for SY 2026-2027</div>
                    </div>
                  </div>
                  <div class="d-flex align-items-start gap-2 py-2">
                    <i class="bi bi-exclamation-triangle-fill text-warning"></i>
                    <div>
                      <div class="text-body fw-semibold">Transmutation Phase-out</div>
                      <div class="text-muted" style="font-size:0.85rem;">Adjusted table active (until SY 2027-2028)</div>
                    </div>
                  </div>
                  <div class="d-flex align-items-start gap-2 py-2">
                    <i class="bi bi-check-circle-fill text-success"></i>
                    <div>
                      <div class="text-body fw-semibold">New Honors Criteria</div>
                      <div class="text-muted" style="font-size:0.85rem;">GA &ge; 90, no grade &lt; 80</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>

    </main>

    <?php
    include_once '../includes/footer.php';
    ?>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>

  <script src="../js/adminlte.js"></script>

  <script src="../js/system-alerts.js"></script>
  <script src="../js/superadmin-alerts.js"></script>

  <script>
    const SELECTOR_SIDEBAR_WRAPPER = '.sidebar-wrapper';
    const Default = {
      scrollbarTheme: 'os-theme-light',
      scrollbarAutoHide: 'leave',
      scrollbarClickScroll: true,
    };
    document.addEventListener('DOMContentLoaded', function () {
      const sidebarWrapper = document.querySelector(SELECTOR_SIDEBAR_WRAPPER);
      if (sidebarWrapper && OverlayScrollbarsGlobal?.OverlayScrollbars !== undefined) {
        OverlayScrollbarsGlobal.OverlayScrollbars(sidebarWrapper, {
          scrollbars: {
            theme: Default.scrollbarTheme,
            autoHide: Default.scrollbarAutoHide,
            clickScroll: Default.scrollbarClickScroll,
          },
        });
      }
    });
  </script>

  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
  <script>
    <?php if ($gradeLevelAverages !== []): ?>
      new Chart(document.getElementById('gradeLevelChart'), {
        type: 'bar',
        data: {
          labels: <?= json_encode(array_map(static fn($r) => $r['grade_level_name'], $gradeLevelAverages)) ?>,
          datasets: [{
            label: 'Average Grade',
            data: <?= json_encode(array_map(static fn($r) => round((float)$r['avg_grade'], 2), $gradeLevelAverages)) ?>,
            backgroundColor: '#8B1A1A',
            borderRadius: 6,
            maxBarThickness: 48
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            y: { suggestedMin: 60, suggestedMax: 100, title: { display: true, text: 'Average Grade' } },
            x: { title: { display: true, text: 'Grade Level' } }
          }
        }
      });
    <?php endif; ?>

    <?php if ($forecast !== null): ?>
      (function () {
        const labels   = <?= json_encode(array_map(static fn($r) => 'Term ' . (int)$r['term_number'], $termAverages)) ?>;
        const actual   = <?= json_encode(array_map(static fn($r) => round((float)$r['avg_grade'], 2), $termAverages)) ?>;
        const slope    = <?= json_encode($forecast['slope']) ?>;
        const intercept = <?= json_encode($forecast['intercept']) ?>;
        const n        = labels.length;
        const trend    = actual.map((_, i) => +(slope * (i + 1) + intercept).toFixed(2));
        const predicted = +(slope * (n + 1) + intercept).toFixed(2);
        new Chart(document.getElementById('forecastChart'), {
          type: 'line',
          data: {
            labels: [...labels, 'Term ' + (n + 1) + ' (Predicted)'],
            datasets: [
              {
                label: 'Actual Average',
                data: [...actual, null],
                borderColor: '#8B1A1A',
                backgroundColor: 'rgba(139, 26, 26, 0.12)',
                fill: true,
                tension: 0.3,
                pointRadius: 4,
                pointBackgroundColor: '#8B1A1A'
              },
              {
                label: 'Trend',
                data: [...trend, predicted],
                borderColor: '#C5A028',
                borderDash: [6, 5],
                fill: false,
                tension: 0,
                pointRadius: 3,
                pointBackgroundColor: '#C5A028'
              }
            ]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: 'bottom' } },
            scales: {
              y: { suggestedMin: 60, suggestedMax: 100, title: { display: true, text: 'Average Grade' } },
              x: { title: { display: true, text: 'Term' } }
            }
          }
        });
      })();
    <?php endif; ?>
  </script>

</body>

</html>

