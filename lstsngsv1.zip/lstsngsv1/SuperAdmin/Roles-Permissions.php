<?php
session_start();

// Auth guard: must be logged in as Super Admin (role_id = 4)
if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 4) {
    header('Location: ../login.php');
    exit;
}

require_once __DIR__ . '/../api/shared/db_connect.php';
require_once __DIR__ . '/../includes/breadcrumb.php';

// System roles (fixed — role assignments are managed per user account)
$roles = [
    1 => ['name' => 'Admin',       'description' => 'Registrar/Admin panel access'],
    2 => ['name' => 'Teacher',     'description' => 'Teacher panel access'],
    3 => ['name' => 'Student',     'description' => 'Student portal'],
    4 => ['name' => 'Super Admin', 'description' => 'System configuration access'],
];

// Active user count per role
$countStmt = $pdo->prepare('SELECT COUNT(*) FROM tblusers WHERE role_id = ? AND status = ?');
$roleCounts = [];
foreach (array_keys($roles) as $roleId) {
    $countStmt->execute([$roleId, 'Active']);
    $roleCounts[$roleId] = (int)$countStmt->fetchColumn();
}
?>
<!doctype html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>STSN Grading System | Roles &amp; Permissions</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <meta name="color-scheme" content="light dark" />
  <meta name="theme-color" content="#8B1A1A" media="(prefers-color-scheme: light)" />
  <meta name="theme-color" content="#8B1A1A" />
  <meta name="title" content="STSN | Roles &amp; Permissions" />
  <meta name="author" content="G" />
  <meta name="description"
    content="STSN Grading System - A modern and accessible Bootstrap 5-based grading and student management platform for Schools. Secure, fast, and WCAG 2.1 AA compliant." />
  <meta name="keywords"
    content="STSN, STSN Grading System, school grading system, student information system, bootstrap 5 admin dashboard, grading dashboard, student records, class management, teacher tools, accessible admin panel" />
  <meta name="supported-color-schemes" content="light dark" />
  <link rel="preload" href="../css/adminlte.css" as="style" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
    integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
    onload="this.media='all'" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="../css/adminlte.css" />
  <link rel="stylesheet" href="../css/dark-mode.css" />
  <link rel="stylesheet" href="../css/admin-responsive.css" />
  <link rel="stylesheet" href="../css/system-alerts.css" />
  <link rel="stylesheet" href="../css/superadmin-theme.css" />

  <style>
    .sa-table thead th {
      font-size: 0.72rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--muted, #6C757D);
      font-weight: 700;
      white-space: nowrap;
    }
    .sa-table td {
      vertical-align: middle;
    }

    /* Dark mode support */
     [data-bs-theme="dark"] .sa-table thead th { color: #adb5bd; } 

  </style>

  <script src="../js/theme.js" defer></script>
</head>

<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">

  <div class="app-wrapper">
    <?php
    include_once '../includes/header.php';
    include_once '../includes/sAdmin_sidebar.php';
    ?>

    <main class="app-main">

      <div class="app-content-header">
      </div>
      <div class="app-content">
        <div class="container-fluid p-4">

          <!-- Page Header Banner -->
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3 p-4 text-white sa-page-header">
            <div class="d-flex align-items-center gap-3">
              <i class="bi bi-shield-lock" style="font-size:1.5rem;"></i>
              <div>
                <h1 class="mb-0" style="font-size:1.5rem; font-weight:600;">Roles &amp; Permissions</h1>
                <p class="mb-0" style="font-size:0.85rem; opacity:0.85;">System-level role reference and per-role account counts</p>
              </div>
            </div>
          </div>

          <!-- Breadcrumb -->
          <?php renderBreadcrumb([
            ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'],
            ['label' => 'Access Control', 'href' => '#', 'icon' => 'bi bi-shield-lock'],
            ['label' => 'Roles & Permissions', 'icon' => 'bi bi-shield-lock'],
          ]); ?>

          <!-- Info Banner -->
          <div class="sa-info-banner">
            <i class="bi bi-info-circle-fill sa-alert-icon"></i>
            <div>
              Roles are system-level and cannot be modified. Role assignments are managed per user account in the
              <a href="User-Accounts.php" class="fw-semibold">User Accounts</a> page.
            </div>
          </div>

          <!-- Roles List -->
          <div class="card">
            <div class="card-header d-flex align-items-center gap-2">
              <i class="bi bi-shield-lock"></i>
              <strong>Roles</strong>
              <span class="badge bg-secondary ms-2"><?= count($roles) ?></span>
            </div>
            <div class="card-body p-0">
              <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 sa-table">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Role Name</th>
                      <th>Description</th>
                      <th>User Count</th>
                      <th class="text-end">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($roles as $roleId => $role): ?>
                      <tr>
                        <td><?= $roleId ?></td>
                        <td class="fw-semibold">
                          <i class="bi bi-<?= $roleId === 4 ? 'shield-lock-fill' : 'person-badge' ?> me-1" style="color:#8B1A1A;"></i>
                          <?= htmlspecialchars($role['name']) ?>
                        </td>
                        <td><?= htmlspecialchars($role['description']) ?></td>
                        <td><span class="badge bg-secondary"><?= $roleCounts[$roleId] ?></span></td>
                        <td class="text-end">
                          <a href="User-Accounts.php?role_id=<?= $roleId ?>" class="btn btn-outline-primary btn-sm">
                            <i class="bi bi-people me-1"></i> View Users
                          </a>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
      </div>

    </main>

    <?php
    include_once '../includes/footer.php';
    ?>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>

  <script src="../js/adminlte.js"></script>

  <script src="../js/system-alerts.js"></script>
  <script src="../js/superadmin-alerts.js"></script>

  <script>
    const SELECTOR_SIDEBAR_WRAPPER = '.sidebar-wrapper';
    const Default = {
      scrollbarTheme: 'os-theme-light',
      scrollbarAutoHide: 'leave',
      scrollbarClickScroll: true,
    };
    document.addEventListener('DOMContentLoaded', function () {
      const sidebarWrapper = document.querySelector(SELECTOR_SIDEBAR_WRAPPER);
      if (sidebarWrapper && OverlayScrollbarsGlobal?.OverlayScrollbars !== undefined) {
        OverlayScrollbarsGlobal.OverlayScrollbars(sidebarWrapper, {
          scrollbars: {
            theme: Default.scrollbarTheme,
            autoHide: Default.scrollbarAutoHide,
            clickScroll: Default.scrollbarClickScroll,
          },
        });
      }
    });
  </script>

</body>

</html>