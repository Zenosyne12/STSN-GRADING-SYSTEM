<?php
session_start();

// Auth guard: must be logged in as Super Admin (role_id = 4)
if (!isset($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 4) {
    header('Location: ../login.php');
    exit;
}

require_once __DIR__ . '/../api/shared/db_connect.php';
require_once __DIR__ . '/../includes/breadcrumb.php';
require_once __DIR__ . '/../api/system/backup.php';

/* ----------------------------- POST handlers (PRG) ----------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');

    if ($action === 'create_backup') {
        set_time_limit(0);
        [$ok, $value] = brCreateBackupFile();
        if ($ok) {
            header('Location: ../api/system/backup.php?action=download&file=' . rawurlencode($value));
        } else {
            header('Location: Backup-Restore.php?msg=backup_failed&detail=' . urlencode($value));
        }
        exit;
    }

    if ($action === 'restore') {
        set_time_limit(0);
        $file = $_FILES['restore_file'] ?? null;
        $ext  = $file ? strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION)) : '';
        if (!$file || (int)($file['error'] ?? 1) !== UPLOAD_ERR_OK || (int)($file['size'] ?? 0) <= 0) {
            brPageRedirect('restore_failed', 'No valid .sql file was uploaded.');
        }
        if ($ext !== 'sql') {
            brPageRedirect('restore_failed', 'Only .sql files can be restored.');
        }
        if ((int)$file['size'] > 536870912) {
            brPageRedirect('restore_failed', 'The uploaded file exceeds the 512 MB limit.');
        }
        [$ok, $value] = brRestoreDatabase((string)$file['tmp_name']);
        brPageRedirect($ok ? 'restore_success' : 'restore_failed', $value);
    }

    if ($action === 'delete_backup') {
        $name = brSafeBackupName((string)($_POST['file'] ?? ''));
        if ($name === null) {
            brPageRedirect('backup_failed', 'Invalid backup filename.');
        }
        $path = brBackupDir() . DIRECTORY_SEPARATOR . $name;
        if (!is_file($path) || !@unlink($path)) {
            brPageRedirect('backup_failed', 'The backup file could not be deleted.');
        }
        brPageRedirect('backup_deleted');
    }

    brPageRedirect('backup_failed', 'Unknown action.');
}

/* ----------------------------- Flash messages ----------------------------- */
$flashMap = [
    'backup_created'  => ['Backup created successfully. The download should start automatically.', 'success'],
    'backup_deleted'  => ['Backup file deleted.', 'success'],
    'restore_success' => ['Database restored successfully.', 'success'],
    'restore_failed'  => ['Restore failed.', 'danger'],
    'backup_failed'   => ['Backup operation failed.', 'danger'],
];
$msgKey = (string)($_GET['msg'] ?? '');
if ($msgKey !== '' && isset($flashMap[$msgKey])) {
    [$flashMessage, $flashType] = $flashMap[$msgKey];
} else {
    $flashMessage = '';
    $flashType    = 'success';
}
$flashDetail = trim((string)($_GET['detail'] ?? ''));

/* ----------------------------- Backup history ----------------------------- */
$backups      = brListBackups();
$lastBackup   = $backups[0] ?? null;
$lastBackupAt = $lastBackup ? date('M d, Y h:i A', (int)$lastBackup['mtime']) : '';
$lastBackupSz = $lastBackup ? brHumanSize((int)$lastBackup['size']) : '';
?>
<!doctype html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>STSN Grading System | Backup &amp; Restore</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <meta name="color-scheme" content="light dark" />
  <meta name="theme-color" content="#8B1A1A" media="(prefers-color-scheme: light)" />
  <meta name="theme-color" content="#8B1A1A" />
  <meta name="title" content="STSN | Backup &amp; Restore" />
  <meta name="author" content="G" />
  <meta name="description"
    content="STSN Grading System - A modern and accessible Bootstrap 5-based grading and student management platform for Schools. Secure, fast, and WCAG 2.1 AA compliant." />
  <meta name="supported-color-schemes" content="light dark" />
  <link rel="preload" href="../css/adminlte.css" as="style" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
    integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="print"
    onload="this.media='all'" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
    crossorigin="anonymous" />

  <link rel="stylesheet" href="../css/adminlte.css" />
  <link rel="stylesheet" href="../css/dark-mode.css" />
  <link rel="stylesheet" href="../css/admin-responsive.css" />
  <link rel="stylesheet" href="../css/system-alerts.css" />
  <link rel="stylesheet" href="../css/superadmin-theme.css" />

  <style>
    .br-card {
      background: #fff;
      border: 1px solid var(--border, #E9ECEF);
      border-radius: 14px;
      box-shadow: 0 4px 12px rgba(10,47,68,0.06);
      margin-bottom: 1.25rem;
      overflow: hidden;
    }
    .br-card-header {
      padding: 1rem 1.25rem;
      border-bottom: 1px solid var(--border, #E9ECEF);
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 1rem;
      flex-wrap: wrap;
    }
    .br-card-title {
      font-size: 1.05rem;
      font-weight: 800;
      color: var(--primary, #0A2F44);
      display: flex;
      align-items: center;
      gap: 0.5rem;
      flex-wrap: wrap;
    }
    .br-card-title i { color: #C5A028; }
    .br-card-desc {
      font-size: 0.82rem;
      color: var(--muted, #6C757D);
      margin-top: 4px;
    }
    .br-card-body { padding: 1.25rem; }

    .br-table thead th {
      font-size: 0.72rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--muted, #6C757D);
      font-weight: 700;
      white-space: nowrap;
    }

    /* Dark mode support */
     [data-bs-theme="dark"] .br-card { background: #1a1d21; border-color: #2b3035; } 
 [data-bs-theme="dark"] .br-card-header { border-bottom-color: #2b3035; } 
 [data-bs-theme="dark"] .br-card-title { color: #e9ecef; } 
 [data-bs-theme="dark"] .br-table thead th { color: #adb5bd; } 

  </style>

  <script src="../js/theme.js" defer></script>
</head>
<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">

  <div class="app-wrapper">
    <?php
    include_once '../includes/header.php';
    include_once '../includes/sAdmin_sidebar.php';
    ?>

    <main class="app-main">

      <div class="app-content-header">
      </div>
      <div class="app-content">
        <div class="container-fluid p-4">

          <!-- Page Header Banner -->
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3 p-4 text-white sa-page-header">
            <div class="d-flex align-items-center gap-3">
              <i class="bi bi-database" style="font-size:1.5rem;"></i>
              <div>
                <h1 class="mb-0" style="font-size:1.5rem; font-weight:600;">Backup &amp; Restore</h1>
                <p class="mb-0" style="font-size:0.85rem; opacity:0.85;">Database dumps, restore and backup history — safeguard student records</p>
              </div>
            </div>
          </div>

          <!-- Breadcrumb -->
          <?php renderBreadcrumb([
            ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'],
            ['label' => 'System Settings', 'href' => '#', 'icon' => 'bi bi-gear'],
            ['label' => 'Backup & Restore', 'icon' => 'bi bi-database'],
          ]); ?>

          <?php if ($flashMessage !== ''): ?>
            <?php $flashToastMsg = trim($flashMessage . ((isset($flashDetail) && $flashDetail !== '') ? ' — ' . $flashDetail : '')); ?>
            <div data-sa-flash="<?= htmlspecialchars($flashType) ?>"
                 data-sa-flash-message="<?= htmlspecialchars($flashToastMsg) ?>"
                 style="display:none"></div>
          <?php endif; ?>

          <!-- Info Banner -->
          <div class="alert alert-info d-flex align-items-start gap-2 small mb-3" role="alert">
            <i class="bi bi-info-circle mt-1"></i>
            <div>
              Download full database backup. Store in a safe location.
            </div>
          </div>
          <!-- Card 1: Create Backup -->
          <div class="br-card">
            <div class="br-card-header">
              <div>
                <div class="br-card-title"><i class="bi bi-cloud-arrow-down-fill"></i> Create Backup</div>
                <div class="br-card-desc">Generate a .sql dump of the entire database.</div>
              </div>
            </div>
            <div class="br-card-body">
              <form method="post" action="Backup-Restore.php" class="d-inline">
                <input type="hidden" name="action" value="create_backup">
                <button type="submit" class="btn btn-success">
                  <i class="bi bi-download me-1"></i> Download Full Backup
                </button>
              </form>
              <div class="mt-2" style="font-size:0.82rem; color:var(--muted, #6C757D);">
                <?php if ($lastBackup): ?>
                  <i class="bi bi-clock-history me-1"></i>Last backup:
                  <strong><?= htmlspecialchars((string)$lastBackup['name']) ?></strong>
                  (<?= htmlspecialchars($lastBackupSz) ?>, <?= htmlspecialchars($lastBackupAt) ?>)
                <?php else: ?>
                  <i class="bi bi-clock-history me-1"></i>No backups yet.
                <?php endif; ?>
              </div>
            </div>
          </div>

          <!-- Card 2: Restore (WARNING) -->
          <div class="br-card">
            <div class="br-card-header">
              <div>
                <div class="br-card-title"><i class="bi bi-arrow-counterclockwise"></i> Restore</div>
                <div class="br-card-desc">Restore database from a .sql file. This will OVERWRITE all current data.</div>
              </div>
            </div>
            <div class="br-card-body">
              <div class="alert alert-danger d-flex align-items-start gap-2 small mb-3" role="alert">
                <i class="bi bi-exclamation-octagon mt-1"></i>
                <div>
                  <strong>Danger zone.</strong> Restoring replaces every table in <strong>dbstsn</strong> with the
                  contents of the uploaded file. Current grades, accounts and settings will be lost. Create a fresh
                  backup first.
                </div>
              </div>
              <form method="post" action="Backup-Restore.php" enctype="multipart/form-data"
                    data-confirm="Restore the database from this file? ALL current data will be overwritten. This cannot be undone.">
                <input type="hidden" name="action" value="restore">
                <div class="d-flex flex-wrap align-items-center gap-2">
                  <input type="file" class="form-control" id="restoreFile" name="restore_file" accept=".sql" style="max-width:360px;">
                  <button type="submit" class="btn btn-danger" id="restoreBtn" disabled>
                    <i class="bi bi-arrow-counterclockwise me-1"></i> Restore Database
                  </button>
                </div>
              </form>
            </div>
          </div>
          <!-- Card 3: Backup History -->
          <div class="br-card">
            <div class="br-card-header">
              <div>
                <div class="br-card-title"><i class="bi bi-clock-history"></i> Backup History</div>
                <div class="br-card-desc">Dumps stored on the server (backups/ folder, auto-created via mysqldump if writable).</div>
              </div>
            </div>
            <div class="br-card-body">
              <?php if (!$backups): ?>
                <div class="d-flex flex-column align-items-center py-5 text-center">
                  <i class="bi bi-inbox" style="font-size:2rem; color:var(--muted, #6C757D);"></i>
                  <div class="fw-semibold mt-2">No backups yet</div>
                  <div class="text-muted" style="font-size:0.85rem;">Click &ldquo;Download Full Backup&rdquo; to create the first database dump.</div>
                </div>
              <?php else: ?>
                <div class="table-responsive">
                  <table class="table table-sm table-hover align-middle br-table mb-0">
                    <thead>
                      <tr>
                        <th>Date</th>
                        <th>Filename</th>
                        <th>Size</th>
                        <th class="text-end">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($backups as $backup): ?>
                        <tr>
                          <td style="white-space:nowrap;"><?= htmlspecialchars(date('M d, Y h:i A', (int)$backup['mtime'])) ?></td>
                          <td style="word-break:break-all;"><?= htmlspecialchars((string)$backup['name']) ?></td>
                          <td style="white-space:nowrap;"><?= htmlspecialchars(brHumanSize((int)$backup['size'])) ?></td>
                          <td class="text-end" style="white-space:nowrap;">
                            <a class="btn btn-sm btn-outline-primary"
                               href="../api/system/backup.php?action=download&file=<?= rawurlencode((string)$backup['name']) ?>">
                              <i class="bi bi-download"></i> Download
                            </a>
                            <form method="post" action="Backup-Restore.php" class="d-inline"
                                  data-confirm="Delete this backup file permanently?">
                              <input type="hidden" name="action" value="delete_backup">
                              <input type="hidden" name="file" value="<?= htmlspecialchars((string)$backup['name']) ?>">
                              <button type="submit" class="btn btn-sm btn-outline-danger">
                                <i class="bi bi-trash"></i> Delete
                              </button>
                            </form>
                          </td>
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              <?php endif; ?>
            </div>
          </div>

        </div>
      </div>

    </main>

    <?php
    include_once '../includes/footer.php';
    ?>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>

  <script src="../js/adminlte.js"></script>

  <script src="../js/system-alerts.js"></script>
  <script src="../js/superadmin-alerts.js"></script>

  <script>
    document.addEventListener('DOMContentLoaded', function () {
      // Auto-dismiss flash messages after 4s
      document.querySelectorAll('.alert-dismissible').forEach(function (alertEl) {
        setTimeout(function () {
          if (window.bootstrap && bootstrap.Alert) {
            bootstrap.Alert.getOrCreateInstance(alertEl).close();
          }
        }, 4000);
      });

      // Restore button stays disabled until a .sql file is chosen
      var restoreFile = document.getElementById('restoreFile');
      var restoreBtn  = document.getElementById('restoreBtn');
      if (restoreFile && restoreBtn) {
        restoreFile.addEventListener('change', function () {
          var name = (restoreFile.value || '').toLowerCase();
          restoreBtn.disabled = !(name !== '' && name.slice(-4) === '.sql');
        });
      }
    });
  </script>
</body>

</html>


