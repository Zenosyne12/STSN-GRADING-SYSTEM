function togglePassword(fieldId, btn) {
    const input = document.getElementById(fieldId);
    if (!input) return;
    const icon = (btn && btn.querySelector('i')) || input.parentElement.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        if (icon) { icon.classList.remove('bi-eye'); icon.classList.add('bi-eye-slash'); }
    } else {
        input.type = 'password';
        if (icon) { icon.classList.remove('bi-eye-slash'); icon.classList.add('bi-eye'); }
    }
}

function checkPasswordStrength(password) {
    let score = 0;
    if (password.length >= 8) score += 2;
    if (/[A-Z]/.test(password)) score += 2;
    if (/[a-z]/.test(password)) score += 2;
    if (/[0-9]/.test(password)) score += 2;
    if (/[^A-Za-z0-9]/.test(password)) score += 1;

    const bar = document.getElementById('passwordStrength');
    const text = document.getElementById('strengthText');
    if (!bar || !text) return score;

    let label = 'None';
    let color = '#999';
    let width = 0;
    if (score >= 7) { label = 'Strong'; color = '#198754'; width = 100; }
    else if (score >= 4) { label = 'Medium'; color = '#f0ad4e'; width = 62; }
    else if (password.length > 0) { label = 'Weak'; color = '#dc3545'; width = 32; }

    bar.style.width = width + '%';
    bar.style.background = color;
    text.style.color = color;
    text.textContent = 'Strength: ' + label;
    return score;
}

function validatePasswordForm() {
    const current = document.getElementById('currentPasswordModal');
    const next = document.getElementById('newPasswordModal');
    const confirm = document.getElementById('confirmPasswordModal');
    const currentErr = document.getElementById('currentPwError');
    const confirmErr = document.getElementById('confirmPwError');
    let valid = true;

    if (currentErr) currentErr.style.display = 'none';
    if (confirmErr) confirmErr.style.display = 'none';
    if (current) current.classList.remove('is-invalid');
    if (next) next.classList.remove('is-invalid');
    if (confirm) confirm.classList.remove('is-invalid');

    if (!current || !current.value) {
        if (current) current.classList.add('is-invalid');
        valid = false;
    }
    if (!next || !next.value || next.value.length < 8 || !/[A-Z]/.test(next.value) || !/[a-z]/.test(next.value) || !/[0-9]/.test(next.value)) {
        if (next) next.classList.add('is-invalid');
        valid = false;
    }
    if (next && confirm && next.value !== confirm.value) {
        confirm.classList.add('is-invalid');
        if (confirmErr) confirmErr.style.display = 'block';
        valid = false;
    }
    return valid;
}

async function submitPasswordForm(e) {
    e.preventDefault();
    if (!validatePasswordForm()) {
        toast('Please fix the password form errors.', 'warning');
        return;
    }
    const btn = document.getElementById('btnChangePassword');
    if (btn) btn.disabled = true;
    try {
        const data = await stsnFetchJson('api/settings/change_password.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                current_password: document.getElementById('currentPasswordModal').value,
                new_password: document.getElementById('newPasswordModal').value,
                confirm_password: document.getElementById('confirmPasswordModal').value
            })
        });
        if (data.success) {
            toast(data.message || 'Password changed successfully', 'success');
            const form = document.getElementById('changePasswordForm');
            if (form) form.reset();
            checkPasswordStrength('');
            bootstrap.Modal.getInstance(document.getElementById('changePasswordModal'))?.hide();
        } else {
            if ((data.error || '').toLowerCase().includes('current password')) {
                const current = document.getElementById('currentPasswordModal');
                const currentErr = document.getElementById('currentPwError');
                if (current) current.classList.add('is-invalid');
                if (currentErr) currentErr.style.display = 'block';
            }
            toast(data.error || 'Could not change password', 'danger');
        }
    } catch (err) {
        toast(err.message, 'danger');
    } finally {
        if (btn) btn.disabled = false;
    }
}

function getCapacityStatus(current, max) {
    if (current >= max) return { key: 'full', label: 'Full', cls: 'capacity-status-full', icon: '🔴' };
    if (current >= max * 0.9) return { key: 'nearly_full', label: 'Nearly Full', cls: 'capacity-status-nearly', icon: '🟡' };
    return { key: 'available', label: 'Available', cls: 'capacity-status-available', icon: '🟢' };
}

let capacityCache = [];

async function loadSectionCapacities() {
    const data = await stsnFetchJson('api/settings/section_capacity.php');
    capacityCache = data.sections || [];
    renderCapacityTable(capacityCache);
}

function renderCapacityTable(sections) {
    const tbody = document.getElementById('capacityTableBody');
    if (!tbody) return;
    if (!sections.length) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted py-3">No active sections.</td></tr>';
        return;
    }
    tbody.innerHTML = sections.map(s => {
        const st = getCapacityStatus(s.current_count, s.max_capacity);
        return `<tr>
            <td><strong>${escapeHtml(s.section_name)}</strong></td>
            <td>${escapeHtml(s.grade_level_name)}</td>
            <td>${s.current_count}</td>
            <td>${s.max_capacity}</td>
            <td>${s.remaining}</td>
            <td class="${st.cls}">${st.icon} ${st.label}</td>
            <td><button type="button" class="btn btn-sm btn-outline-secondary" onclick="openCapacityModal(${s.id})">Edit</button></td>
        </tr>`;
    }).join('');
}

function escapeHtml(v) {
    return String(v ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function openCapacityModal(sectionId) {
    const section = capacityCache.find(s => Number(s.id) === Number(sectionId));
    if (!section) return;
    document.getElementById('capacitySectionId').value = section.id;
    document.getElementById('sectionNameDisplay').textContent = section.section_name + ' (' + section.grade_level_name + ')';
    document.getElementById('maxCapacityInput').value = section.max_capacity;
    document.getElementById('occupancyInfo').innerHTML = 'Currently <strong>' + section.current_count + ' of ' + section.max_capacity + '</strong> students';
    document.getElementById('capacityWarning').style.display = 'none';
    document.getElementById('maxCapacityInput').dataset.currentCount = String(section.current_count);
    bootstrap.Modal.getOrCreateInstance(document.getElementById('capacityModal')).show();
}

async function updateCapacity() {
    const sectionId = Number(document.getElementById('capacitySectionId').value);
    const maxCapacity = Number(document.getElementById('maxCapacityInput').value);
    if (maxCapacity < 10 || maxCapacity > 100) {
        toast('Capacity must be between 10 and 100', 'warning');
        return;
    }
    try {
        const data = await stsnFetchJson('api/settings/section_capacity.php', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ section_id: sectionId, max_capacity: maxCapacity })
        });
        if (data.success) {
            toast('Capacity updated', 'success');
            bootstrap.Modal.getInstance(document.getElementById('capacityModal'))?.hide();
            loadSectionCapacities();
        } else {
            toast(data.error || 'Update failed', 'danger');
        }
    } catch (err) {
        toast(err.message, 'danger');
    }
}

async function toggleThemeAjax(theme) {
    if (typeof applyTheme === 'function') applyTheme(theme);
    try {
        const data = await stsnFetchJson('api/settings/update_theme.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ theme })
        });
        if (data.success) {
            toast(theme === 'dark' ? 'Dark mode enabled' : 'Light mode enabled', 'success');
        } else {
            toast(data.error || 'Could not save theme', 'danger');
        }
    } catch (err) {
        toast(err.message, 'danger');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const themeToggle = document.getElementById('darkModeToggle');
    if (themeToggle) {
        const current = (typeof detectTheme === 'function' ? detectTheme() : 'light');
        themeToggle.checked = current === 'dark';
        themeToggle.addEventListener('change', () => {
            toggleThemeAjax(themeToggle.checked ? 'dark' : 'light');
        });
    }

    const pwForm = document.getElementById('changePasswordForm');
    if (pwForm) pwForm.addEventListener('submit', submitPasswordForm);
    const newPw = document.getElementById('newPassword');
    const confirmPw = document.getElementById('confirmPassword');
    if (newPw) newPw.addEventListener('input', () => checkPasswordStrength(newPw.value));
    if (confirmPw) confirmPw.addEventListener('input', validatePasswordForm);

    const capInput = document.getElementById('maxCapacityInput');
    if (capInput) {
        capInput.addEventListener('input', () => {
            const current = Number(capInput.dataset.currentCount || 0);
            const next = Number(capInput.value);
            const warn = document.getElementById('capacityWarning');
            if (next < current) {
                warn.style.display = 'block';
                warn.innerHTML = '<i class="bi bi-exclamation-triangle me-2"></i>Reducing capacity below current enrollment (' + current + '). Existing students will remain assigned.';
            } else {
                warn.style.display = 'none';
            }
        });
    }
    const saveCap = document.getElementById('btnSaveCapacity');
    if (saveCap) saveCap.addEventListener('click', updateCapacity);

    const saveSectionCfg = document.getElementById('btnSaveSectionConfig');
    if (saveSectionCfg) {
        saveSectionCfg.addEventListener('click', async () => {
            const enabled = document.getElementById('autoAssignEnabled').checked;
            const max = Number(document.getElementById('defaultMaxCapacity').value);
            if (max < 10 || max > 100) {
                toast('Max capacity must be between 10 and 100', 'warning');
                return;
            }
            try {
                const data = await stsnFetchJson('api/settings/section_config.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ auto_assign_enabled: enabled, max_capacity: max })
                });
                if (data.success) {
                    toast('Settings updated', 'success');
                    loadSectionCapacities();
                } else {
                    toast(data.error || 'Could not save settings', 'danger');
                }
            } catch (err) {
                toast(err.message, 'danger');
            }
        });
    }

    loadSectionCapacities().catch(() => {});
    stsnFetchJson('api/settings/section_config.php').then(cfg => {
        const en = document.getElementById('autoAssignEnabled');
        const max = document.getElementById('defaultMaxCapacity');
        if (en) en.checked = !!cfg.auto_assign_enabled;
        if (max) max.value = cfg.max_capacity || 40;
    }).catch(() => {});
});
