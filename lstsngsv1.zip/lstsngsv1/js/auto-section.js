function toast(msg, type = 'success') {
    const map = {
        success: { title: 'Success', color: 'green', icon: 'bi bi-check-circle-fill' },
        danger: { title: 'Error', color: 'red', icon: 'bi bi-exclamation-octagon-fill' },
        warning: { title: 'Warning', color: 'yellow', icon: 'bi bi-exclamation-triangle-fill' },
        info: { title: 'Info', color: 'blue', icon: 'bi bi-info-circle-fill' },
    };
    const c = map[type] || map.success;
    if (typeof iziToast === 'undefined') {
        window.alert(msg);
        return;
    }
    iziToast.show({
        title: c.title,
        message: msg,
        color: c.color,
        icon: c.icon,
        iconColor: '#fff',
        theme: 'light',
        position: 'topRight',
        timeout: 4000,
        progressBar: true,
        close: true,
        pauseOnHover: true,
        transitionIn: 'fadeInDown',
        transitionOut: 'fadeOutUp'
    });
}

async function stsnFetchJson(url, options = {}) {
    const res = await fetch(url, options);
    const text = await res.text();
    try {
        return JSON.parse(text);
    } catch (e) {
        throw new Error('Server returned an unexpected response.');
    }
}

function showSectionFullPrompt(gradeName, gradeLevelId) {
    const label = gradeName || 'this grade';
    iziToast.question({
        timeout: 20000,
        close: true,
        overlay: true,
        displayMode: 'once',
        id: 'section-full-prompt',
        zindex: 99999,
        title: 'Section Full',
        message: 'All sections for ' + label + ' are at capacity. Create a new section to continue?',
        position: 'center',
        color: 'red',
        icon: 'bi bi-exclamation-octagon-fill',
        buttons: [
            ['<button><b>Create Section</b></button>', function (instance, toastEl) {
                instance.hide({ transitionOut: 'fadeOut' }, toastEl, 'button');
                const qs = gradeLevelId ? ('?grade_level_id=' + encodeURIComponent(gradeLevelId)) : '';
                window.location.href = 'section.php' + qs;
            }, true],
            ['<button>Cancel</button>', function (instance, toastEl) {
                instance.hide({ transitionOut: 'fadeOut' }, toastEl, 'button');
            }]
        ]
    });
}

async function checkAutoSectioningEnabled() {
    const data = await stsnFetchJson('api/settings/section_config.php');
    return {
        enabled: !!data.auto_assign_enabled,
        showPrompt: data.show_section_prompt !== false,
        maxCapacity: data.max_capacity || 40
    };
}

async function saveDontShowAgainPreference(dontShow) {
    if (!dontShow) return;
    await stsnFetchJson('api/settings/update_prompt_preference.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ show_section_prompt: 0 })
    });
}

function showAutoSectionModal(studentName) {
    const msg = document.getElementById('sectionModalMessage');
    if (msg) {
        const safe = studentName ? '<strong>' + String(studentName).replace(/[<>]/g, '') + '</strong>' : 'imported students';
        msg.innerHTML = 'Add ' + safe + ' to an available section?';
    }
    const check = document.getElementById('dontShowAgainCheck');
    if (check) check.checked = false;
    const el = document.getElementById('autoSectionModal');
    if (!el) return null;
    return bootstrap.Modal.getOrCreateInstance(el);
}

async function handleAutoAssign(studentIdOrIds, gradeId, academicYearId, extra = {}) {
    const payload = {
        grade_level_id: gradeId,
        academic_year_id: academicYearId,
        strand: extra.strand || ''
    };
    if (Array.isArray(studentIdOrIds)) {
        payload.student_ids = studentIdOrIds;
    } else {
        payload.student_id = studentIdOrIds;
    }

    const data = await stsnFetchJson('api/students/auto_assign.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });

    if (data.success) {
        if (data.section_name) {
            toast('Student assigned to Section ' + data.section_name, 'success');
        } else if (data.assigned_count) {
            toast(data.message || (data.assigned_count + ' student(s) assigned'), 'success');
        }
        if (data.unassigned_count > 0) {
            toast('Some students could not be assigned because sections are full.', 'warning');
            showSectionFullPrompt(data.grade_level_name, data.grade_level_id || gradeId);
        }
        return data;
    }

    toast(data.error || 'Could not auto-assign student(s).', 'danger');
    showSectionFullPrompt(data.grade_level_name, data.grade_level_id || gradeId);
    return data;
}

window.stsnAutoSection = {
    toast,
    checkAutoSectioningEnabled,
    showAutoSectionModal,
    handleAutoAssign,
    saveDontShowAgainPreference,
    showSectionFullPrompt
};
