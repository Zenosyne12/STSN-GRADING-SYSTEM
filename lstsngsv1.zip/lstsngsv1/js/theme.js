(function () {
    function themeKey() {
        return window.stsnThemeKey || 'stsn_theme';
    }

    function currentTheme() {
        try {
            return localStorage.getItem(themeKey()) || document.documentElement.getAttribute('data-stsn-theme') || 'light';
        } catch (e) {
            return 'light';
        }
    }

    window.applyTheme = function applyTheme(theme) {
        const next = theme === 'dark' ? 'dark' : 'light';
        document.documentElement.classList.toggle('dark-mode', next === 'dark');
        document.documentElement.classList.toggle('light-mode', next !== 'dark');
        document.documentElement.setAttribute('data-bs-theme', next);
        document.documentElement.setAttribute('data-stsn-theme', next);
        if (document.body) {
            document.body.classList.toggle('dark-mode', next === 'dark');
            document.body.classList.toggle('light-mode', next !== 'dark');
        }
        try { localStorage.setItem(themeKey(), next); } catch (e) { /* ignore */ }
    };

    window.detectTheme = function detectTheme() {
        return currentTheme();
    };

    function initHeaderDarkModeToggle() {
        const toggle = document.getElementById('headerDarkModeToggle');
        const icon = document.getElementById('headerDarkModeIcon');
        if (!toggle || !icon) {
            return;
        }

        const computedTheme = currentTheme();
        toggle.checked = computedTheme === 'dark';
        icon.className = computedTheme === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-stars-fill';

        toggle.addEventListener('change', function () {
            const next = toggle.checked ? 'dark' : 'light';
            applyTheme(next);
            icon.className = next === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-stars-fill';
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initHeaderDarkModeToggle);
    } else {
        initHeaderDarkModeToggle();
    }

    window.applyTheme(currentTheme());
})();
