(function () {
    function normalizeType(type) {
        const value = String(type || 'success').toLowerCase();
        if (['danger', 'error', 'failed', 'fail', 'red'].includes(value)) return 'error';
        if (['warn', 'yellow'].includes(value)) return 'warning';
        if (['notice', 'blue'].includes(value)) return 'info';
        if (['green'].includes(value)) return 'success';
        return ['success', 'warning', 'info', 'question'].includes(value) ? value : 'success';
    }

    function defaultTitle(icon) {
        return {
            success: 'Success',
            error: 'Action failed',
            warning: 'Check this first',
            info: 'Notice',
            question: 'Confirm action'
        }[icon] || 'Notice';
    }

    function showToast(message, type = 'success', options = {}) {
        const icon = normalizeType(type);
        const Toast = Swal.mixin({
            toast: true,
            position: options.position || 'top-end',
            showConfirmButton: false,
            timer: options.timer || options.timeout || 4200,
            timerProgressBar: options.timerProgressBar !== false,
            showCloseButton: options.showCloseButton !== false,
            customClass: { popup: 'swal2-module-toast' },
            didOpen: toast => {
                toast.addEventListener('mouseenter', Swal.stopTimer);
                toast.addEventListener('mouseleave', Swal.resumeTimer);
            }
        });

        return Toast.fire({
            icon,
            title: options.title || defaultTitle(icon),
            text: String(message || '')
        });
    }

    function confirmAction(options = {}) {
        const settings = typeof options === 'string' ? { text: options } : options;
        return Swal.fire({
            title: settings.title || 'Confirm action',
            text: settings.text || '',
            html: settings.html,
            icon: settings.icon || 'question',
            showCancelButton: true,
            confirmButtonText: settings.confirmButtonText || settings.confirmText || 'Yes, continue',
            cancelButtonText: settings.cancelButtonText || 'Cancel',
            confirmButtonColor: settings.confirmButtonColor || '#1a6ef5',
            cancelButtonColor: settings.cancelButtonColor || '#6c757d',
            reverseButtons: true,
            focusCancel: true
        });
    }

    function legacyButtonText(button, fallback) {
        if (!button || !button[0]) return fallback;
        const wrapper = document.createElement('div');
        wrapper.innerHTML = String(button[0]);
        return (wrapper.textContent || wrapper.innerText || fallback).trim() || fallback;
    }

    function runLegacyButton(button) {
        if (!button || typeof button[1] !== 'function') return;
        const instance = { hide: function () {} };
        button[1](instance, null);
    }

    window.AppAlerts = { showToast, confirmAction, normalizeType };

    // Compatibility bridge for modules that previously called iziToast directly.
    // The old dependency is no longer loaded; these calls now render through SweetAlert2.
    window.iziToast = {
        show: function (options = {}) {
            const legacyType = options.type || options.title || options.color || 'success';
            return showToast(options.message || '', legacyType, {
                title: options.title,
                timeout: options.timeout,
                position: 'top-end'
            });
        },
        success: function (options = {}) {
            return showToast(options.message || '', 'success', { title: options.title || 'Success', timeout: options.timeout });
        },
        error: function (options = {}) {
            return showToast(options.message || '', 'error', { title: options.title || 'Error', timeout: options.timeout });
        },
        warning: function (options = {}) {
            return showToast(options.message || '', 'warning', { title: options.title || 'Warning', timeout: options.timeout });
        },
        info: function (options = {}) {
            return showToast(options.message || '', 'info', { title: options.title || 'Info', timeout: options.timeout });
        },
        destroy: function () { Swal.close(); },
        question: function (options = {}) {
            const buttons = Array.isArray(options.buttons) ? options.buttons : [];
            return confirmAction({
                title: options.title || 'Confirm action',
                html: options.message || options.text || '',
                icon: 'question',
                confirmButtonText: options.confirmButtonText || legacyButtonText(buttons[0], 'Yes'),
                cancelButtonText: options.cancelButtonText || legacyButtonText(buttons[1], 'Cancel')
            }).then(result => {
                if (result.isConfirmed) runLegacyButton(buttons[0]);
                else runLegacyButton(buttons[1]);
            });
        }
    };
})();

