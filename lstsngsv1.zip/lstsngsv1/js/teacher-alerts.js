(function () {
    const ICONS = {
        success: 'bi-check-circle-fill',
        error: 'bi-exclamation-circle-fill',
        danger: 'bi-exclamation-circle-fill',
        warning: 'bi-exclamation-triangle-fill',
        info: 'bi-info-circle-fill'
    };

    function normalizeType(type) {
        if (type === 'danger') return 'error';
        return type || 'success';
    }

    function ensureToastHost() {
        let host = document.getElementById('teacherToastHost');
        if (!host) {
            host = document.createElement('div');
            host.id = 'teacherToastHost';
            host.className = 'teacher-toast-host';
            document.body.appendChild(host);
        }
        return host;
    }

    function toast(message, type = 'success', duration = 4000) {
        if (window.SystemAlerts) {
            return SystemAlerts.show(message, type, { duration });
        }
        const normalized = normalizeType(type);
        const host = ensureToastHost();
        const node = document.createElement('div');
        node.className = `teacher-toast ${normalized}`;
        node.setAttribute('role', normalized === 'error' ? 'alert' : 'status');
        node.innerHTML = `<i class="bi ${ICONS[normalized] || ICONS.info}"></i><span></span>`;
        node.querySelector('span').textContent = message || '';
        host.appendChild(node);
        requestAnimationFrame(() => node.classList.add('show'));
        window.setTimeout(() => {
            node.classList.remove('show');
            window.setTimeout(() => node.remove(), 240);
        }, duration);
        return node;
    }

    function confirm(options) {
        if (window.SystemAlerts) return SystemAlerts.confirm(options);
        const config = typeof options === 'string' ? { message: options } : (options || {});
        const title = config.title || 'Confirm action';
        const message = config.message || '';
        const confirmText = config.confirmText || 'Confirm';
        const cancelText = config.cancelText || 'Cancel';

        return new Promise((resolve) => {
            const backdrop = document.createElement('div');
            backdrop.className = 'teacher-confirm-backdrop';
            backdrop.innerHTML = `
                <div class="teacher-confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="teacherConfirmTitle">
                    <div class="teacher-confirm-body">
                        <div class="teacher-confirm-icon"><i class="bi bi-question-circle-fill"></i></div>
                        <div>
                            <h2 class="teacher-confirm-title" id="teacherConfirmTitle"></h2>
                            <p class="teacher-confirm-message"></p>
                        </div>
                    </div>
                    <div class="teacher-confirm-actions">
                        <button type="button" class="teacher-confirm-btn" data-action="cancel"></button>
                        <button type="button" class="teacher-confirm-btn primary" data-action="confirm"></button>
                    </div>
                </div>`;

            backdrop.querySelector('.teacher-confirm-title').textContent = title;
            backdrop.querySelector('.teacher-confirm-message').textContent = message;
            backdrop.querySelector('[data-action="cancel"]').textContent = cancelText;
            backdrop.querySelector('[data-action="confirm"]').textContent = confirmText;

            let isClosing = false;
            function close(result) {
                if (isClosing) return;
                isClosing = true;
                document.removeEventListener('keydown', onKeyDown);
                backdrop.classList.remove('show');
                backdrop.classList.add('closing');
                window.setTimeout(() => {
                    backdrop.remove();
                    resolve(result);
                }, 280);
            }

            function onKeyDown(event) {
                if (event.key === 'Escape') close(false);
            }

            backdrop.addEventListener('click', (event) => {
                if (event.target === backdrop) close(false);
                const action = event.target.closest('[data-action]')?.dataset.action;
                if (action === 'cancel') close(false);
                if (action === 'confirm') close(true);
            });

            document.addEventListener('keydown', onKeyDown);
            document.body.appendChild(backdrop);
            requestAnimationFrame(() => backdrop.classList.add('show'));
            backdrop.querySelector('[data-action="confirm"]').focus();
        });
    }

    window.TeacherAlerts = { toast, confirm };
})();
