(function () {
    const ICONS = {
        success: '\u2713',
        error: '\u0021',
        warning: '\u26a0',
        info: '\u2139'
    };
    const TITLES = { success: 'Success', error: 'Error', warning: 'Warning', info: 'Information' };

    function normalize(type) {
        return type === 'danger' ? 'error' : (type || 'success');
    }

    function actionTitle(message, severity, suppliedTitle) {
        if (suppliedTitle && !['Success', 'Error', 'Warning', 'Info', 'Information'].includes(suppliedTitle)) {
            return suppliedTitle;
        }
        if (severity !== 'success') return suppliedTitle || TITLES[severity] || TITLES.info;

        const text = String(message || '').toLowerCase();
        const actions = [
            [/\b(import|imported)\b/, 'Imported'],
            [/\b(add|added|create|created)\b/, 'Added'],
            [/\b(update|updated|edit|edited|save|saved)\b/, 'Updated'],
            [/\b(delete|deleted|permanently deleted)\b/, 'Deleted'],
            [/\b(archive|archived)\b/, 'Archived'],
            [/\b(restore|restored)\b/, 'Restored'],
            [/\b(submit|submitted)\b/, 'Submitted'],
            [/\b(send|sent)\b/, 'Sent'],
            [/\b(remove|removed)\b/, 'Removed'],
            [/\b(activate|activated)\b/, 'Activated'],
            [/\b(deactivate|deactivated)\b/, 'Deactivated']
        ];
        const match = actions.find(([pattern]) => pattern.test(text));
        return match ? match[1] : (suppliedTitle || TITLES.success);
    }

    function safeMarkup(value) {
        const container = document.createElement('div');
        container.textContent = String(value || '');
        return container.innerHTML
            .replace(/&lt;(strong|b)&gt;/gi, '<$1>')
            .replace(/&lt;\/(strong|b)&gt;/gi, '</$1>')
            .replace(/&lt;br\s*\/?&gt;/gi, '<br>');
    }

    function host() {
        let element = document.getElementById('systemAlertHost');
        if (!element) {
            element = document.createElement('div');
            element.id = 'systemAlertHost';
            element.className = 'system-alert-host';
            document.body.appendChild(element);
        }
        return element;
    }

    function show(message, type = 'success', options = {}) {
        const severity = normalize(type);
        const alertHost = host();
        alertHost.querySelectorAll('.system-alert').forEach((existing) => existing.remove());
        const alert = document.createElement('div');
        alert.className = `system-alert ${severity}`;
        alert.setAttribute('role', severity === 'error' ? 'alert' : 'status');
        alert.innerHTML = `
            <span class="system-alert-icon" aria-hidden="true">${ICONS[severity] || ICONS.info}</span>
            <div class="system-alert-content">
                <span class="system-alert-title"></span>
                <span class="system-alert-message"></span>
            </div>`;
        alert.querySelector('.system-alert-title').textContent = actionTitle(message, severity, options.title);
        alert.querySelector('.system-alert-message').textContent = String(message || '').replace(/<[^>]+>/g, '');
        alertHost.appendChild(alert);
        requestAnimationFrame(() => alert.classList.add('is-visible'));
        window.setTimeout(() => remove(alert), options.duration || 4000);
        return alert;
    }

    function remove(alert) {
        if (!alert || alert.dataset.removing) return;
        alert.dataset.removing = '1';
        alert.classList.remove('is-visible');
        window.setTimeout(() => alert.remove(), 220);
    }

    function confirm(options) {
        const config = typeof options === 'string' ? { message: options } : (options || {});
        return new Promise((resolve) => {
            const backdrop = document.createElement('div');
            backdrop.className = 'system-confirm-backdrop';
            backdrop.innerHTML = `<div class="system-confirm" role="dialog" aria-modal="true">
                <div class="system-confirm-body"><span class="system-confirm-icon" aria-hidden="true">?</span><div><h2 class="system-confirm-title"></h2><p class="system-confirm-message"></p></div></div>
                <div class="system-confirm-actions"><button class="system-confirm-btn cancel" type="button"></button><button class="system-confirm-btn confirm" type="button"></button></div>
            </div>`;
            backdrop.querySelector('.system-confirm-title').textContent = config.title || 'Confirm action';
            backdrop.querySelector('.system-confirm-message').innerHTML = safeMarkup(config.message);
            backdrop.querySelector('.cancel').textContent = config.cancelText || 'Cancel';
            backdrop.querySelector('.confirm').textContent = config.confirmText || 'Confirm';
            const close = (result) => {
                document.removeEventListener('keydown', onKey);
                backdrop.classList.remove('is-visible');
                backdrop.classList.add('is-closing');
                window.setTimeout(() => {
                    backdrop.remove();
                    resolve(result);
                }, 220);
            };
            const onKey = (event) => { if (event.key === 'Escape') close(false); };
            backdrop.addEventListener('click', (event) => {
                if (event.target === backdrop || event.target.closest('.cancel')) close(false);
                if (event.target.closest('.confirm')) close(true);
            });
            document.addEventListener('keydown', onKey);
            document.body.appendChild(backdrop);
            requestAnimationFrame(() => backdrop.classList.add('is-visible'));
            window.setTimeout(() => backdrop.querySelector('.confirm').focus(), 220);
        });
    }

    window.SystemAlerts = { show, confirm, remove };

    function bridgeIziToast() {
        if (!window.iziToast || window.iziToast.__systemAlertBridge) return;
        const bridge = {
            __systemAlertBridge: true,
            show(config = {}) {
                const severity = config.color === 'red'
                    ? 'error'
                    : config.color === 'yellow'
                        ? 'warning'
                        : config.title === 'Info'
                            ? 'info'
                            : 'success';
                return show(config.message, severity, { title: config.title });
            },
            success(message, title) { return show(message, 'success', { title }); },
            error(message, title) { return show(message, 'error', { title }); },
            warning(message, title) { return show(message, 'warning', { title }); },
            info(message, title) { return show(message, 'info', { title }); },
            question(config = {}) {
                const buttons = config.buttons || [];
                return confirm({ title: config.title, message: config.message, confirmText: 'Yes', cancelText: 'No' }).then((accepted) => {
                    const button = accepted ? buttons[0] : buttons[1];
                    if (button && typeof button[1] === 'function') button[1]({ hide() {} }, null);
                    return accepted;
                });
            },
            destroy() {}
        };
        window.iziToast = bridge;
    }

    window.setInterval(bridgeIziToast, 50);
    bridgeIziToast();
})();
