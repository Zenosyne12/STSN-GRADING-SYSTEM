(function () {
    const lastSeenKey = 'teacher-notif-last-seen-id';
    let highestLoadedNotificationId = null;
    let notificationAlertTimer = null;
    let notificationAudioContext = null;

    function escapeHtml(value) {
        const element = document.createElement('div');
        element.textContent = value ?? '';
        return element.innerHTML;
    }

    function isVisible(element) {
        if (!element) return false;
        const style = getComputedStyle(element);
        return style.display !== 'none' && style.visibility !== 'hidden' && element.getClientRects().length > 0;
    }

    function getNotificationHost() {
        const header = document.querySelector('header.top-bar, .page-header, header');
        const scope = header || document;

        for (const selector of ['.top-bar-right', '.header-meta']) {
            const host = Array.from(scope.querySelectorAll(selector)).find(isVisible);
            if (host) return host;
        }

        const profileBadge = Array.from(scope.querySelectorAll('.meta-chip, .profile-badge')).find(isVisible);
        if (profileBadge?.parentElement && isVisible(profileBadge.parentElement)) {
            return profileBadge.parentElement;
        }

        const alignedHost = Array.from(scope.querySelectorAll('.d-flex.align-items-center')).find(isVisible);
        if (alignedHost) return alignedHost;

        const fallbackHost = document.createElement('div');
        fallbackHost.className = 'teacher-notification-fallback d-flex align-items-center ms-auto';
        if (header && isVisible(header)) {
            header.appendChild(fallbackHost);
        } else {
            fallbackHost.classList.add('teacher-notification-fixed');
            document.body.appendChild(fallbackHost);
        }
        return fallbackHost;
    }

    function unlockNotificationAudio() {
        const AudioContextConstructor = window.AudioContext || window.webkitAudioContext;
        if (!AudioContextConstructor) return;
        if (!notificationAudioContext) notificationAudioContext = new AudioContextConstructor();
        if (notificationAudioContext.state === 'suspended') {
            notificationAudioContext.resume().catch(error => {
                console.warn('Unable to enable notification sound:', error);
            });
        }
    }

    function playNotificationSound() {
        if (!notificationAudioContext || notificationAudioContext.state !== 'running') return;
        const now = notificationAudioContext.currentTime;
        [880, 1174].forEach((frequency, index) => {
            const oscillator = notificationAudioContext.createOscillator();
            const gain = notificationAudioContext.createGain();
            const startAt = now + index * 0.14;
            oscillator.type = 'sine';
            oscillator.frequency.value = frequency;
            gain.gain.setValueAtTime(0.0001, startAt);
            gain.gain.exponentialRampToValueAtTime(0.16, startAt + 0.02);
            gain.gain.exponentialRampToValueAtTime(0.0001, startAt + 0.12);
            oscillator.connect(gain);
            gain.connect(notificationAudioContext.destination);
            oscillator.start(startAt);
            oscillator.stop(startAt + 0.13);
        });
    }

    function showNotificationAlert(item) {
        let alert = document.getElementById('teacherNotificationAlert');
        if (!alert) {
            alert = document.createElement('div');
            alert.id = 'teacherNotificationAlert';
            alert.className = 'teacher-notification-alert';
            alert.setAttribute('role', 'status');
            document.body.appendChild(alert);
        }
        alert.replaceChildren();
        const icon = document.createElement('i');
        icon.className = 'bi bi-bell-fill';
        icon.setAttribute('aria-hidden', 'true');
        const content = document.createElement('div');
        content.className = 'teacher-notification-alert-content';
        const title = document.createElement('strong');
        title.textContent = item.title || 'New notification';
        const message = document.createElement('span');
        message.textContent = item.message || '';
        content.append(title, message);
        const close = document.createElement('button');
        close.type = 'button';
        close.className = 'teacher-notification-alert-close';
        close.setAttribute('aria-label', 'Dismiss notification');
        close.innerHTML = '&times;';
        close.addEventListener('click', () => alert.classList.remove('show'));
        alert.append(icon, content, close);
        requestAnimationFrame(() => alert.classList.add('show'));
        window.clearTimeout(notificationAlertTimer);
        notificationAlertTimer = window.setTimeout(() => alert.classList.remove('show'), 7000);
    }

    function mountBell() {
        if (document.getElementById('teacherNotificationsBell')) return;

        const existingBell = document.getElementById('notifBellBtn');
        if (existingBell) {
            const existingPanel = document.getElementById('notifPanel');
            existingPanel?.classList.add('teacher-notification-panel');
            let highestExistingNotificationId = null;
            const loadExistingBellNotifications = async () => {
                try {
                    const response = await fetch('../api/deadline/get_teacher_deadline_feed.php', {
                        headers: { Accept: 'application/json' }
                    });
                    const result = await response.json();
                    if (!response.ok || !result.success) {
                        throw new Error(result.message || 'Unable to load notifications.');
                    }
                    const notifications = Array.isArray(result.data?.reminders) ? result.data.reminders : [];
                    const newestId = notifications.reduce((maxId, item) => Math.max(maxId, Number(item.id || 0)), 0);
                    if (highestExistingNotificationId !== null && newestId > highestExistingNotificationId) {
                        notifications
                            .filter(item => Number(item.id || 0) > highestExistingNotificationId)
                            .reverse()
                            .forEach(item => {
                                showNotificationAlert(item);
                                playNotificationSound();
                            });
                    }
                    highestExistingNotificationId = Math.max(highestExistingNotificationId || 0, newestId);
                } catch (error) {
                    console.error('Unable to load teacher notifications:', error);
                }
            };
            existingBell.addEventListener('click', unlockNotificationAudio);
            document.addEventListener('pointerdown', unlockNotificationAudio, { once: true });
            document.addEventListener('keydown', unlockNotificationAudio, { once: true });
            loadExistingBellNotifications();
            window.setInterval(() => {
                if (document.visibilityState === 'visible') loadExistingBellNotifications();
            }, 30000);
            return;
        }

        const host = getNotificationHost();
        const wrap = document.createElement('div');

        wrap.className = 'teacher-notification-wrap d-flex align-items-center';
        wrap.innerHTML = `
            <button type="button" class="teacher-notification-btn" id="teacherNotificationsBell"
                    aria-label="Notifications" aria-expanded="false" aria-controls="teacherNotificationsPanel">
                <i class="bi bi-bell-fill" aria-hidden="true"></i>
            </button>
            <span class="teacher-notification-count" id="teacherNotificationsCount"></span>
            <div class="teacher-notification-panel" id="teacherNotificationsPanel" role="status">
                <div class="teacher-notification-title">Notifications</div>
                <div id="teacherNotificationsList">
                    <div class="teacher-notification-item"><div class="teacher-notification-item-sub">Loading due date...</div></div>
                </div>
            </div>`;
        host.appendChild(wrap);

        const button = document.getElementById('teacherNotificationsBell');
        const count = document.getElementById('teacherNotificationsCount');
        const panel = document.getElementById('teacherNotificationsPanel');
        const list = document.getElementById('teacherNotificationsList');
        let reminders = [];
        let deadlineInfo = null;

        function render() {
            let seenId = 0;
            try { seenId = Number(localStorage.getItem(lastSeenKey) || 0); } catch (error) {}
            const unreadCount = reminders.filter(item => Number(item.id || 0) > seenId).length;
            count.style.display = unreadCount > 0 ? 'inline-flex' : 'none';
            count.textContent = unreadCount > 9 ? '9+' : String(unreadCount);

            const items = [];
            if (deadlineInfo?.teacher_deadline_display) {
                const teacherDays = deadlineInfo.teacher_deadline_days;
                const teacherDaysSuffix = (teacherDays && teacherDays.label)
                    ? ` <span style="color:${teacherDays.is_overdue ? '#dc3545' : (teacherDays.is_today ? '#b96f00' : '#6c757d')};font-weight:600;">(${escapeHtml(teacherDays.label)})</span>`
                    : '';
                items.push(`<div class="teacher-notification-item"><div class="teacher-notification-item-title">Teacher Due Date</div><div class="teacher-notification-item-sub">${escapeHtml(deadlineInfo.teacher_deadline_display)}${teacherDaysSuffix}</div></div>`);
            }
            if (deadlineInfo?.is_adviser && deadlineInfo?.adviser_deadline_display) {
                const adviserDays = deadlineInfo.adviser_deadline_days;
                const adviserDaysSuffix = (adviserDays && adviserDays.label)
                    ? ` <span style="color:${adviserDays.is_overdue ? '#dc3545' : (adviserDays.is_today ? '#b96f00' : '#6c757d')};font-weight:600;">(${escapeHtml(adviserDays.label)})</span>`
                    : '';
                items.push(`<div class="teacher-notification-item"><div class="teacher-notification-item-title">Adviser Due Date</div><div class="teacher-notification-item-sub">${escapeHtml(deadlineInfo.adviser_deadline_display)}${adviserDaysSuffix}</div></div>`);
            }
            reminders.forEach(item => {
                const unread = Number(item.id || 0) > seenId;
                items.push(`<div class="teacher-notification-item${unread ? ' is-unread' : ''}"><div class="teacher-notification-item-title">${escapeHtml(item.title || 'Reminder')}</div><div class="teacher-notification-item-sub">${escapeHtml(item.message || '')}</div><div class="teacher-notification-item-sub">${escapeHtml(item.created_at_display || '')}</div></div>`);
            });
            list.innerHTML = items.length
                ? items.join('')
                : '<div class="teacher-notification-item"><div class="teacher-notification-item-sub">No notifications or active due dates.</div></div>';
        }

        async function loadNotifications() {
            try {
                const response = await fetch('../api/deadline/get_teacher_deadline_feed.php', {
                    headers: { Accept: 'application/json' }
                });
                const result = await response.json();
                if (!response.ok || !result.success) {
                    throw new Error(result.message || 'Unable to load notifications.');
                }
                deadlineInfo = result.success ? result.data || null : null;
                reminders = Array.isArray(deadlineInfo?.reminders) ? deadlineInfo.reminders : [];
                const newestId = reminders.reduce((maxId, item) => Math.max(maxId, Number(item.id || 0)), 0);
                if (highestLoadedNotificationId !== null && newestId > highestLoadedNotificationId) {
                    reminders
                        .filter(item => Number(item.id || 0) > highestLoadedNotificationId)
                        .reverse()
                        .forEach(item => {
                            showNotificationAlert(item);
                            playNotificationSound();
                        });
                }
                highestLoadedNotificationId = Math.max(highestLoadedNotificationId || 0, newestId);
            } catch (error) {
                console.error('Unable to load teacher notifications:', error);
            }
            render();
        }

        button.addEventListener('click', event => {
            event.stopPropagation();
            unlockNotificationAudio();
            const isOpen = panel.classList.toggle('show');
            button.setAttribute('aria-expanded', String(isOpen));
            if (isOpen && reminders.length) {
                const newestId = Math.max(...reminders.map(item => Number(item.id || 0)));
                try { localStorage.setItem(lastSeenKey, String(newestId)); } catch (error) {}
                render();
            }
        });

        document.addEventListener('click', event => {
            if (!wrap.contains(event.target)) {
                panel.classList.remove('show');
                button.setAttribute('aria-expanded', 'false');
            }
        });
        document.addEventListener('keydown', event => {
            if (event.key === 'Escape') {
                panel.classList.remove('show');
                button.setAttribute('aria-expanded', 'false');
            }
        });
        document.addEventListener('pointerdown', unlockNotificationAudio, { once: true });
        document.addEventListener('keydown', unlockNotificationAudio, { once: true });

        loadNotifications();
        window.setInterval(() => {
            if (document.visibilityState === 'visible') loadNotifications();
        }, 30000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', mountBell, { once: true });
    } else {
        mountBell();
    }
})();