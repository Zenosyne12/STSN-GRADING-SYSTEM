/**
 * SuperAdmin Alerts — shared confirm dialog + toast notifications
 *
 * CONFIRM DIALOG: exact copy of the schedule_manage.php "ay-confirm" overlay —
 * light/white dialog, warning-triangle title icon, OK + Cancel buttons, and the
 * same smooth fade + scale animation. The CSS is injected once from this file,
 * so every SuperAdmin page gets the same dialog with zero per-page markup.
 *
 * TOASTS: routed through js/system-alerts.js (SystemAlerts.show) so all feedback
 * uses the same system toast (e.g. "Removed — Adviser removed.").
 *
 * Public API:
 *   window.saConfirm(message, options) -> Promise<boolean> (true = OK)
 *       options: { title, confirmText, cancelText, variant ('danger'|'warning') }
 *   window.saToast(message, type)  — type: success | danger | warning | info
 *   window.saAlert(message, type)  — alias of saToast
 *   form[data-confirm] submits are auto-intercepted with saConfirm()
 *   [data-sa-flash-message] elements (PHP flash) are auto-shown as toasts
 */
(function () {
    'use strict';

    /* ============================================================
       1) ay-confirm dialog CSS — EXACT copy from schedule_manage.php
          (variables are scoped to the overlay so page styles are safe)
       ============================================================ */
    var STYLE_ID = 'saAyConfirmStyles';

    function injectConfirmStyles() {
        if (document.getElementById(STYLE_ID)) { return; }
        var css = [
            '.ay-confirm-overlay{--ay-card:#ffffff;--ay-card-soft:#fafcff;--ay-border:#dce8f8;--ay-text:#213a5e;' +
            '--ay-btn-light-bg:#ffffff;--ay-btn-light-text:#8B1A1A;--ay-btn-light-border:#b8d0fa;' +
            '--ay-btn-light-hover-bg:#eef4ff;--ay-btn-light-hover-border:#8db5f7;' +
            'position:fixed;inset:0;background:rgba(7,22,48,0.22);display:flex;align-items:center;justify-content:center;' +
            'z-index:2000;padding:1rem;opacity:0;visibility:hidden;pointer-events:none;' +
            'backdrop-filter:blur(0px);-webkit-backdrop-filter:blur(0px);' +
            'transition:opacity .22s ease,backdrop-filter .22s ease,-webkit-backdrop-filter .22s ease,visibility 0s linear .24s;}',

            '[data-bs-theme="dark"] .ay-confirm-overlay{--ay-card:#2D2D2D;--ay-card-soft:#262626;--ay-border:#3a3a3a;--ay-text:#e4e6e8;' +
            '--ay-btn-light-bg:#3a3a3a;--ay-btn-light-text:#e8eef7;--ay-btn-light-border:#4a4a4a;' +
            '--ay-btn-light-hover-bg:#444444;--ay-btn-light-hover-border:#5a5a5a;background:rgba(0,0,0,0.55);}',

            '.ay-confirm-overlay.show{opacity:1;visibility:visible;pointer-events:auto;' +
            'backdrop-filter:blur(3px);-webkit-backdrop-filter:blur(3px);' +
            'transition:opacity .22s ease,backdrop-filter .22s ease,-webkit-backdrop-filter .22s ease,visibility 0s linear 0s;}',

            '.ay-confirm-dialog{width:min(480px,calc(100vw - 2rem));border-radius:12px;background:var(--ay-card);' +
            'box-shadow:0 16px 40px rgba(0,0,0,0.28);overflow:hidden;border:1px solid var(--ay-border);' +
            'transform:translateY(-14px) scale(.94);opacity:0;' +
            'transition:transform .28s cubic-bezier(.18,.9,.32,1.18),opacity .22s ease;}',

            '.ay-confirm-overlay.show .ay-confirm-dialog{transform:translateY(0) scale(1);opacity:1;}',

            '.ay-confirm-title{background:linear-gradient(135deg,#8B1A1A 0%,#6B1414 100%);color:#fff;' +
            'padding:.85rem 1rem;font-size:1rem;font-weight:700;letter-spacing:.02em;' +
            'border-bottom:1px solid rgba(255,255,255,.2);display:flex;align-items:center;gap:.65rem;}',

            '.ay-confirm-title-icon{width:34px;height:34px;border-radius:50%;background:rgba(255,255,255,0.16);' +
            'border:1.5px solid rgba(255,255,255,0.8);display:flex;align-items:center;justify-content:center;' +
            'color:#fff;font-size:1rem;box-shadow:0 0 0 2px rgba(255,255,255,0.08);}',

            '.ay-confirm-message{padding:1rem 1rem .75rem;color:var(--ay-text);font-size:.93rem;line-height:1.55;}',

            '.ay-confirm-actions{padding:.85rem 1rem 1rem;display:flex;justify-content:flex-end;align-items:center;gap:.6rem;' +
            'background:var(--ay-card-soft);border-top:1px solid var(--ay-border);}',
            '.ay-confirm-actions .btn-ay{min-width:84px;}',

            '.btn-ay{font-weight:600;font-size:.82rem;border-radius:8px;padding:.42rem .9rem;cursor:pointer;' +
            'transition:all .15s;border:1.5px solid transparent;line-height:1.4;text-decoration:none;' +
            'display:inline-flex;align-items:center;justify-content:center;gap:.35rem;font-family:inherit;}',

            '.btn-ay-primary{background:linear-gradient(130deg,#8B1A1A,#6B1414);color:#fff;box-shadow:0 2px 8px rgba(139,26,26,.2);}',
            '.btn-ay-primary:hover{background:linear-gradient(130deg,#7A1717,#581111);color:#fff;}',

            '.btn-ay-light{background:var(--ay-btn-light-bg);color:var(--ay-btn-light-text);border-color:var(--ay-btn-light-border);}',
            '.btn-ay-light:hover{background:var(--ay-btn-light-hover-bg);border-color:var(--ay-btn-light-hover-border);color:var(--ay-btn-light-text);}',

            '.btn-ay:focus-visible{outline:2px solid #8B1A1A;outline-offset:2px;}'
        ].join('');
        var style = document.createElement('style');
        style.id = STYLE_ID;
        style.textContent = css;
        document.head.appendChild(style);
    }

    /* ============================================================
       2) Confirm dialog — exact schedule_manage.php ay-confirm look:
          warning-triangle title icon, OK + Cancel, fade + scale.
       ============================================================ */
    var backdrop = null;
    var pendingResolve = null;
    var CONFIRM_EXIT_MS = 240;   // matches the CSS exit transition (~.22s)

    function buildConfirmDialog() {
        if (backdrop) { return backdrop; }
        injectConfirmStyles();
        backdrop = document.createElement('div');
        backdrop.className = 'ay-confirm-overlay';
        backdrop.setAttribute('role', 'dialog');
        backdrop.setAttribute('aria-modal', 'true');
        backdrop.setAttribute('aria-hidden', 'true');
        backdrop.innerHTML =
            '<div class="ay-confirm-dialog">' +
            '  <div class="ay-confirm-title">' +
            '    <span class="ay-confirm-title-icon"><i class="bi bi-exclamation-triangle-fill"></i></span>' +
            '    <span class="ay-confirm-title-text">Confirm</span>' +
            '  </div>' +
            '  <div class="ay-confirm-message">Are you sure?</div>' +
            '  <div class="ay-confirm-actions">' +
            '    <button type="button" class="btn-ay btn-ay-primary sa-confirm-ok">OK</button>' +
            '    <button type="button" class="btn-ay btn-ay-light sa-confirm-cancel">Cancel</button>' +
            '  </div>' +
            '</div>';
        document.body.appendChild(backdrop);

        backdrop.querySelector('.sa-confirm-ok').addEventListener('click', function () {
            finishConfirm(true);
        });
        backdrop.querySelector('.sa-confirm-cancel').addEventListener('click', function () {
            finishConfirm(false);
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && backdrop.classList.contains('show')) {
                finishConfirm(false);
            }
        });
        return backdrop;
    }

    // Fade out first (same as schedule_manage.php closeOverlay), then resolve
    function finishConfirm(result) {
        if (!backdrop) { return; }
        backdrop.classList.remove('show');
        backdrop.setAttribute('aria-hidden', 'true');
        if (pendingResolve) {
            var r = pendingResolve;
            pendingResolve = null;
            setTimeout(function () { r(result); }, CONFIRM_EXIT_MS);
        }
    }

    window.saConfirm = function (message, options) {
        options = options || {};
        var dialog = buildConfirmDialog();
        dialog.querySelector('.ay-confirm-title-text').textContent = options.title || 'Confirm';
        dialog.querySelector('.ay-confirm-message').textContent = message;
        dialog.querySelector('.sa-confirm-ok').textContent = options.confirmText || 'OK';
        dialog.querySelector('.sa-confirm-cancel').textContent = options.cancelText || 'Cancel';

        var iconEl = dialog.querySelector('.ay-confirm-title-icon i');
        iconEl.className = (options.variant === 'danger')
            ? 'bi bi-exclamation-octagon-fill'
            : 'bi bi-exclamation-triangle-fill';

        dialog.classList.add('show');
        dialog.setAttribute('aria-hidden', 'false');
        var okBtn = dialog.querySelector('.sa-confirm-ok');
        try { okBtn.focus({ preventScroll: true }); } catch (e) { okBtn.focus(); }
        return new Promise(function (resolve) {
            pendingResolve = resolve;
        });
    };

    /* ============================================================
       3) Toast — routed through system-alerts.js so every SuperAdmin
          page shows the same system toast (green check, etc.)
       ============================================================ */
    window.saToast = function (message, type) {
        type = type || 'info';
        if (window.SystemAlerts && typeof window.SystemAlerts.show === 'function') {
            return window.SystemAlerts.show(message, type);
        }
        // Fallback (system-alerts.js not loaded): minimal toast
        var el = document.createElement('div');
        el.className = 'sa-toast ' + type;
        el.textContent = String(message || '');
        el.style.cssText = 'position:fixed;top:1rem;right:1rem;z-index:3000;background:#fff;' +
            'border-left:4px solid #198754;padding:.75rem 1rem;border-radius:8px;' +
            'box-shadow:0 8px 24px rgba(0,0,0,.15);font-size:.9rem;';
        if (type === 'danger') { el.style.borderLeftColor = '#dc3545'; }
        if (type === 'warning') { el.style.borderLeftColor = '#ffc107'; }
        document.body.appendChild(el);
        setTimeout(function () { el.remove(); }, 4000);
    };

    // -------- PHP flash messages become system toasts on page load --------
    // Pages render: <div data-sa-flash="success" data-sa-flash-message="..." style="display:none"></div>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('[data-sa-flash-message]').forEach(function (el) {
            var msg = el.getAttribute('data-sa-flash-message') || '';
            var type = el.getAttribute('data-sa-flash') || 'success';
            if (msg) { window.saToast(msg, type); }
            el.remove();
        });
    });

    // -------- Auto-intercept form[data-confirm] (uses the shared ay-confirm dialog) --------
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('form[data-confirm]').forEach(function (form) {
            form.addEventListener('submit', function (e) {
                if (form.dataset.saConfirmed === '1') {
                    delete form.dataset.saConfirmed;
                    return;
                }
                e.preventDefault();
                var msg = form.getAttribute('data-confirm') || 'Are you sure?';
                var isDanger = /delete|remove|deactivate/i.test(msg);
                window.saConfirm(msg, {
                    title: isDanger ? 'Confirm Action' : 'Confirm',
                    variant: isDanger ? 'danger' : 'warning'
                }).then(function (ok) {
                    if (ok) {
                        form.dataset.saConfirmed = '1';
                        form.submit();
                    }
                });
            });
        });
    });

    // -------- Alias: saAlert behaves like saToast --------
    window.saAlert = function (message, type) {
        window.saToast(message, type || 'info');
    };
})();
