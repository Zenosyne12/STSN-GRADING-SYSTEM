<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/api/shared/db_connect.php';

// â”€â”€ Get Active Academic Year for fixed filtering â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
$activeYearId = null;
try {
    $stmtActive = $pdo->query("SELECT id, year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
    $activeYear = $stmtActive ? $stmtActive->fetch(PDO::FETCH_ASSOC) : null;
    $activeYearId = $activeYear ? (int) $activeYear['id'] : null;
} catch (Throwable $e) {
    $activeYearId = null;
}

$defaultTab = isset($_GET['tab']) && $_GET['tab'] === 'archive' ? 'archive' : 'students';
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Student Management</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        body {
            background: #f3f7fd;
        }

        .students-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }

        .students-page-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 0.2rem;
            letter-spacing: 0.01em;
        }

        .students-page-header p {
            margin: 0;
            font-size: 0.88rem;
            opacity: 0.85;
        }

        .students-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            background: rgba(255, 255, 255, 0.15);
            border: 1.5px solid rgba(255, 255, 255, 0.3);
            border-radius: 999px;
            padding: 0.45rem 1rem;
            font-size: 0.88rem;
            font-weight: 700;
            color: #fff;
            white-space: nowrap;
        }

        /* â”€â”€ Tabs â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
        .st-tabs {
            border-bottom: 1px solid #e8f0fb;
            display: flex;
            gap: 0.2rem;
            padding: 0.2rem 1rem 0;
            background: #fff;
            margin-bottom: 0;
        }

        .st-tab-btn {
            padding: 0.85rem 1rem;
            font-size: 0.88rem;
            font-weight: 700;
            color: #6b84a2;
            border: none;
            background: none;
            cursor: pointer;
            border-bottom: 3px solid transparent;
            transition: color 0.13s, border-color 0.13s;
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
        }

        .st-tab-btn:hover:not(.active) {
            color: #1248a8;
        }

        .st-tab-btn.active {
            color: #1a6ef5;
            border-bottom-color: #1a6ef5;
        }

        .students-card {
            background: #fff;
            border: 1px solid #dce8f8;
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18, 72, 168, 0.06);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }

        .students-card-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid #e8f0fb;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 0.75rem;
            background: #fff;
        }

        .students-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: #132f62;
            margin: 0 0 0.15rem;
        }

        .students-card-subtitle {
            font-size: 0.8rem;
            color: #7a93b8;
            margin: 0;
        }

        .students-toolbar {
            display: flex;
            flex-wrap: wrap;
            gap: 0.65rem;
            align-items: center;
        }

        .students-search {
            min-width: 230px;
            height: 40px;
            border-radius: 10px;
            border: 1.5px solid #c8daf8;
            background: #fff;
            color: #213a5e;
            font-size: 0.9rem;
            padding: 0.45rem 0.9rem;
            outline: none;
            transition: 0.15s;
        }

        .students-search:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.12);
        }

        .students-card-body {
            padding: 0;
        }

        .students-card-footer {
            padding: 0.75rem 1.2rem;
            border-top: 1px solid #e8f0fb;
            background: #fafcff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 0.75rem;
            flex-wrap: wrap;
        }

        .students-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0;
        }

        .students-table thead th {
            background: #f4f8ff;
            color: #3b5e96;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 0.85rem 1rem;
            border-bottom: 1.5px solid #dce8f8;
            white-space: nowrap;
        }

        .students-table tbody tr {
            transition: background 0.12s;
        }

        .students-table tbody tr:not(:last-child) td {
            border-bottom: 1px solid #f0f5fc;
        }

        .students-table tbody tr:hover td {
            background: #f7fbff;
        }

        .students-table tbody td {
            padding: 0.9rem 1rem;
            font-size: 0.92rem;
            color: #213a5e;
            vertical-align: middle;
        }

        .students-table .row-num {
            color: #a0b4cc;
            font-size: 0.82rem;
            font-weight: 600;
        }

        .student-name {
            font-weight: 700;
            color: #132f62;
        }

        .student-grade {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.3rem 0.7rem;
            border-radius: 999px;
            background: #eef4ff;
            color: #1248a8;
            border: 1.5px solid #cfe0ff;
            font-size: 0.78rem;
            font-weight: 700;
        }

        .students-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.32rem 0.75rem;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }

        .students-badge-active {
            background: #e6f0ff;
            color: #1248a8;
            border: 1.5px solid #b8d0fa;
        }

        .students-badge-inactive {
            background: #f3f5f8;
            color: #7a8ea8;
            border: 1.5px solid #dde4ee;
        }

        .students-badge-promoted {
            background: #e6f4ea;
            color: #1a7a4a;
            border: 1.5px solid #a3cfbb;
        }

        .students-badge-retained {
            background: #fff7e6;
            color: #a46a00;
            border: 1.5px solid #ffe1a8;
        }

        .students-badge-dropped {
            background: #fce8e6;
            color: #c0392b;
            border: 1.5px solid #f5c6cb;
        }

        .students-badge-transferred {
            background: #e8eaf6;
            color: #3949ab;
            border: 1.5px solid #c5cae9;
        }

        .students-badge-graduated {
            background: #e0f2f1;
            color: #00695c;
            border: 1.5px solid #80cbc4;
        }

        .students-badge-not-enrolled {
            background: #f3f5f8;
            color: #7a8ea8;
            border: 1.5px solid #dde4ee;
        }

        .student-contact-link {
            color: #1a6ef5;
            text-decoration: none;
            font-weight: 600;
        }

        .student-contact-link:hover {
            color: #1248a8;
            text-decoration: underline;
        }

        .btn-student {
            font-weight: 600;
            font-size: 0.82rem;
            border-radius: 8px;
            padding: 0.42rem 0.9rem;
            cursor: pointer;
            transition: all 0.15s;
            border: 1.5px solid transparent;
            line-height: 1.4;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.35rem;
        }

        .btn-student-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            box-shadow: 0 2px 8px rgba(26, 110, 245, 0.2);
        }

        .btn-student-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
        }

        .btn-student-import {
            background: linear-gradient(130deg, #0f6c45, #0a5234);
            color: #fff;
            box-shadow: 0 2px 8px rgba(15, 108, 69, 0.2);
        }

        .btn-student-import:hover {
            background: linear-gradient(130deg, #0d5a3a, #084228);
            color: #fff;
        }

        .btn-student-edit {
            background: #fff7e6;
            color: #a46a00;
            border-color: #ffe1a8;
        }

        .btn-student-edit:hover {
            background: #ffefc8;
            color: #8a5800;
            border-color: #ffd27a;
        }

        .btn-student-activate {
            background: #1a6ef5;
            color: #fff;
            border-color: #1a6ef5;
        }

        .btn-student-activate:hover {
            background: #1560d8;
            border-color: #1560d8;
            color: #fff;
        }

        .btn-student-deactivate {
            background: #fff;
            color: #1248a8;
            border-color: #b8d0fa;
        }

        .btn-student-deactivate:hover {
            background: #eef4ff;
            border-color: #8db5f7;
            color: #0f3d90;
        }

        .students-actions {
            display: flex;
            gap: 0.45rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        .students-empty {
            text-align: center;
            padding: 2.5rem 1.5rem;
            color: #9ab0c8;
        }

        .students-empty i {
            font-size: 2.2rem;
            display: block;
            margin-bottom: 0.6rem;
            opacity: 0.5;
        }

        .students-empty p {
            margin: 0;
            font-size: 0.95rem;
        }

        .students-pagination {
            display: flex;
            gap: 0.3rem;
            list-style: none;
            margin: 0;
            padding: 0;
            justify-content: flex-end;
            align-items: center;
            flex-wrap: wrap;
        }

        .students-pagination .students-page-item .students-page-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
            border-radius: 7px;
            font-size: 0.83rem;
            font-weight: 600;
            cursor: pointer;
            border: 1.5px solid #dce8f8;
            color: #1a6ef5;
            background: #fff;
            transition: all 0.13s;
            padding: 0 0.5rem;
            text-decoration: none;
        }

        .students-pagination .students-page-item .students-page-link:hover {
            background: #eef4ff;
            border-color: #9cc2fc;
        }

        .students-pagination .students-page-item.active .students-page-link {
            background: #1a6ef5;
            border-color: #1a6ef5;
            color: #fff;
        }

        .students-pagination .students-page-item.disabled .students-page-link {
            background: #f8fbff;
            border-color: #e2ebf8;
            color: #9ab0c8;
            cursor: not-allowed;
            pointer-events: none;
        }

        .students-footer-note {
            font-size: 0.82rem;
            color: #7a93b8;
        }

        .students-mobile-card {
            background: #fff;
            border: 1.5px solid #dce8f8;
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 1px 6px rgba(18, 72, 168, 0.05);
        }

        .students-mobile-card+.students-mobile-card {
            margin-top: 0.75rem;
        }

        .students-mobile-card-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 0.75rem;
            padding: 0.9rem 1rem;
            border-bottom: 1px solid #edf3fc;
            background: #f9fbff;
        }

        .students-mobile-card-title {
            font-weight: 700;
            color: #132f62;
            font-size: 0.95rem;
            margin-bottom: 0.25rem;
        }

        .students-mobile-card-subtitle {
            font-size: 0.8rem;
            color: #7a93b8;
            margin: 0;
        }

        .students-mobile-card-body {
            padding: 0.9rem 1rem;
        }

        .students-mobile-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0.65rem 0.9rem;
            margin-bottom: 0.85rem;
        }

        .students-mobile-item small {
            display: block;
            font-size: 0.72rem;
            color: #8fa8c8;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 0.2rem;
        }

        .students-mobile-item span,
        .students-mobile-item a {
            font-size: 0.88rem;
            color: #213a5e;
            font-weight: 600;
            text-decoration: none;
            word-break: break-word;
        }

        .students-mobile-actions {
            display: flex;
            gap: 0.5rem;
            flex-direction: column;
        }

        /* â”€â”€ Archive / History Tab Styles â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
        .archive-filter-bar {
            padding: 1rem 1.2rem;
            display: flex;
            flex-wrap: wrap;
            align-items: end;
            gap: 0.9rem;
            background: #fff;
        }

        .archive-filter-group {
            display: flex;
            flex-direction: column;
            gap: 0.4rem;
            min-width: 180px;
            flex: 1 1 220px;
        }

        .archive-filter-group.search-group {
            flex: 2 1 320px;
        }

        .archive-filter-label {
            font-size: 0.78rem;
            font-weight: 700;
            color: #3b5e96;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .archive-filter-control {
            border-radius: 10px;
            border: 1.5px solid #c8daf8;
            min-height: 42px;
            font-size: 0.9rem;
            color: #213a5e;
            padding: 0.45rem 0.85rem;
            background: #fff;
            outline: none;
            transition: border-color 0.15s, box-shadow 0.15s;
        }

        .archive-filter-control:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, 0.12);
        }

        .archive-name {
            font-weight: 700;
            color: #132f62;
            margin-bottom: 0.1rem;
        }

        .archive-subtext {
            color: #7f96b8;
            font-size: 0.79rem;
            line-height: 1.35;
        }

        .archive-year-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            padding: 0.28rem 0.65rem;
            border-radius: 999px;
            font-size: 0.76rem;
            font-weight: 700;
            background: #f4f7fb;
            color: #6a84a9;
            border: 1.5px solid #e0e8f4;
        }

        .archive-actions {
            display: flex;
            gap: 0.5rem;
            justify-content: center;
            flex-wrap: nowrap;
        }

        .btn-archive-activate {
            background: #1a6ef5;
            color: #fff;
            border-color: #1a6ef5;
        }

        .btn-archive-activate:hover {
            background: #1560d8;
            border-color: #1560d8;
            color: #fff;
        }

        .btn-archive-delete {
            background: #fff;
            color: #d43f57;
            border-color: #f1c5cd;
        }

        .btn-archive-delete:hover {
            background: #fff1f3;
            color: #b92f45;
            border-color: #e6a5b1;
        }

        @media (max-width:767.98px) {
            .students-page-header {
                padding: 1.1rem 1.2rem;
                border-radius: 14px;
            }

            .students-toolbar {
                width: 100%;
            }

            .students-search {
                min-width: 100%;
                width: 100%;
            }

            .students-card-footer {
                justify-content: center;
            }

            .students-pagination {
                justify-content: center;
            }

            .st-tabs {
                width: 100%;
            }

            .st-tab-btn {
                flex: 1;
                justify-content: center;
            }
        }
    </style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <div class="app-wrapper">
        <?php require_once("includes/header.php"); ?>
        <?php require_once("includes/sidebar.php"); ?>

        <main class="app-main">
            <div class="app-content">
                <div class="container-fluid py-3">

                    <div class="students-page-header">
                        <div>
                            <h3><i class="bi bi-people-fill me-2"></i>Student Management</h3>
                            <p>Add, edit, and manage all student records.</p>
                        </div>
                        <div class="d-flex gap-2 align-items-center flex-wrap">
                            <div class="students-chip" id="studentDirectoryChip">
                                <i class="bi <?= $defaultTab === 'archive' ? 'bi-archive-fill' : 'bi-folder2-open' ?>" id="studentDirectoryIcon"></i>
                                <span id="studentDirectoryText"><?= $defaultTab === 'archive' ? 'Archive Directory' : 'Academic Year Directory' ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- Tabbed Card -->
                    <div class="students-card">
                        <div class="st-tabs">
                            <button class="st-tab-btn <?= $defaultTab === 'students' ? 'active' : '' ?>"
                                id="tab-students" onclick="switchTab('students')">
                                <i class="bi bi-people"></i> Student List
                            </button>
                            <button class="st-tab-btn <?= $defaultTab === 'archive' ? 'active' : '' ?>" id="tab-archive"
                                onclick="switchTab('archive')">
                                <i class="bi bi-archive"></i> History / Archive
                            </button>
                        </div>

                        <!-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
                         TAB: STUDENT LIST
                    â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• -->
                        <div id="pane-students" <?= $defaultTab !== 'students' ? 'style="display:none"' : '' ?>>
                            <div class="students-card-header">
                                <div>
                                    <p class="students-card-title">Student List</p>
                                    <p class="students-card-subtitle">Search, review, edit, and manage student accounts.
                                    </p>
                                </div>
                                <div class="students-toolbar">
                                    <input type="search" class="students-search" id="searchInput"
                                        placeholder="Search student, LRN, guardian, or contact">
                                    <a href="student_import.php" class="btn-student btn-student-import">
                                        <i class="bi bi-file-earmark-arrow-up"></i> Import Excel
                                    </a>
                                    <a href="student_form.php" class="btn-student btn-student-primary">
                                        <i class="bi bi-plus-circle"></i> New Student
                                    </a>
                                </div>
                            </div>

                            <div class="students-card-body">
                                <div class="d-none d-md-block">
                                    <table class="students-table">
                                        <thead>
                                            <tr>
                                                <th style="width:60px;text-align:center;">#</th>
                                                <th>LRN</th>
                                                <th>Name</th>
                                                <th>Grade</th>
                                                <th style="width:100px;text-align:center;">Age</th>
                                                <th style="width:150px;text-align:center;">Sex</th>
                                                <th>Guardian</th>
                                                <th>Contact</th>
                                                <th style="width:130px;text-align:center;">Status</th>
                                                <th style="width:200px;text-align:center;">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody id="studentTableBody">
                                            <tr>
                                                <td colspan="10">
                                                    <div class="students-empty"><i class="bi bi-hourglass-split"></i>
                                                        <p>Loading students...</p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="d-block d-md-none p-3" id="studentCardView"></div>
                            </div>

                            <div class="students-card-footer">
                                <div class="students-footer-note" id="studentCountText"></div>
                                <ul class="students-pagination" id="pagination"></ul>
                            </div>
                        </div>

                        <!-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
                         TAB: HISTORY / ARCHIVE
                    â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• -->
                        <div id="pane-archive" <?= $defaultTab !== 'archive' ? 'style="display:none"' : '' ?>>

                            <!-- Filter Bar -->
                            <div class="archive-filter-bar">
                                <div class="archive-filter-group">
                                    <label for="archiveStatusFilter" class="archive-filter-label">Status Filter</label>
                                    <select id="archiveStatusFilter" class="archive-filter-control">
                                        <option value="all">All Statuses</option>
                                        <option value="PROMOTED">Promoted</option>
                                        <option value="RETAINED">Retained</option>
                                        <option value="DROPPED">Dropped</option>
                                        <option value="TRANSFERRED">Transferred</option>
                                        <option value="GRADUATED">Graduated</option>
                                    </select>
                                </div>
                                <div class="archive-filter-group">
                                    <label for="archiveYearFilter" class="archive-filter-label">Academic Year</label>
                                    <select id="archiveYearFilter" class="archive-filter-control">
                                        <option value="all">All Years</option>
                                    </select>
                                </div>
                                <div class="archive-filter-group search-group">
                                    <label for="archiveSearchInput" class="archive-filter-label">Search</label>
                                    <input type="text" id="archiveSearchInput" class="archive-filter-control"
                                        placeholder="Search by name, LRN, or grade level">
                                </div>
                                <div class="archive-filter-group" style="flex: 0 0 auto; min-width: 140px;">
                                    <label class="archive-filter-label">&nbsp;</label>
                                    <button type="button" class="btn-student btn-student-deactivate w-100"
                                        id="clearArchiveFiltersBtn">
                                        <i class="bi bi-x-circle me-1"></i> Clear
                                    </button>
                                </div>
                            </div>

                            <div class="students-card-header" style="border-top:1px solid #e8f0fb;">
                                <div>
                                    <p class="students-card-title">Student Archive History</p>
                                    <p class="students-card-subtitle">View past academic year records and transition
                                        history.</p>
                                </div>
                            </div>
                            <div class="students-card-body">
                                <div class="d-none d-md-block">
                                    <table class="students-table" id="archiveTable">
                                        <thead>
                                            <tr>
                                                <th style="width:64px; text-align:center;">#</th>
                                                <th>Student Name</th>
                                                <th>LRN</th>
                                                <th style="width:120px; text-align:center;">Grade Level</th>
                                                <th style="width:120px; text-align:center;">Academic Year</th>
                                                <th style="width:130px; text-align:center;">Status</th>
                                                <th style="width:140px; text-align:center;">Final Average</th>
                                                <th style="width:180px; text-align:center;">Archived Date</th>
                                                <th style="width:200px; text-align:center;">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody id="archiveTableBody">
                                            <tr>
                                                <td colspan="9">
                                                    <div class="students-empty">
                                                        <i class="bi bi-hourglass-split"></i>
                                                        <p>Loading archived records...</p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="d-block d-md-none p-3" id="archiveCardView"></div>
                            </div>
                            <div class="students-card-footer">
                                <div class="students-footer-note" id="archiveCountText"></div>
                                <ul class="students-pagination" id="archivePagination"></ul>
                            </div>
                        </div>

                    </div><!-- /.students-card -->

                </div>
            </div>
        </main>
        <?php require_once("includes/footer.php"); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./js/adminlte.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="./js/sweet-alerts.js"></script>
    <script>
        // â”€â”€ Active year ID (fixed, always used for student list) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        const DEFAULT_YEAR_ID = <?= $activeYearId ? json_encode($activeYearId) : 'null' ?>;

        let currentPage = 1;
        let searchTerm = '';
        let totalStudents = 0;
        const rowsPerPage = 5;   // matches per_page=5 sent to API
        let searchDebounce = null;

        function escapeHtml(v) {
            return String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
        }

        function updateDirectoryLabel(tabName) {
            const icon = document.getElementById('studentDirectoryIcon');
            const text = document.getElementById('studentDirectoryText');
            if (!icon || !text) return;

            const isArchive = tabName === 'archive';
            icon.className = isArchive ? 'bi bi-archive-fill' : 'bi bi-folder2-open';
            text.textContent = isArchive ? 'Archive Directory' : 'Academic Year Directory';
        }

        function switchTab(tabName) {
            const isArchive = tabName === 'archive';

            document.getElementById('tab-students')?.classList.toggle('active', !isArchive);
            document.getElementById('tab-archive')?.classList.toggle('active', isArchive);
            document.getElementById('pane-students').style.display = isArchive ? 'none' : '';
            document.getElementById('pane-archive').style.display = isArchive ? '' : 'none';
            updateDirectoryLabel(tabName);

            if (isArchive) {
                loadArchive(archiveCurrentPage || 1, archiveCurrentStatus, archiveCurrentYear, archiveCurrentSearch);
            } else {
                loadStudents(currentPage || 1, searchTerm);
            }
        }

        function showAlert(message, type = 'success') {
            AppAlerts.showToast(message, type);
        }

        function confirmAction(options, onYes, onCancel) {
            AppAlerts.confirmAction(options).then(async (result) => {
                if (result.isConfirmed) await onYes();
                else if (onCancel) onCancel();
            });
        }

        function renderStudents(list, page, pages) {
            const tbody = document.getElementById('studentTableBody');
            const cardView = document.getElementById('studentCardView');
            const pagination = document.getElementById('pagination');
            const countEl = document.getElementById('studentCountText');

            if (!list.length) {
                const empty = `<div class="students-empty"><i class="bi bi-people"></i><p>No students found.</p></div>`;
                tbody.innerHTML = `<tr><td colspan="10">${empty}</td></tr>`;
                cardView.innerHTML = empty;
                pagination.innerHTML = '';
                if (countEl) countEl.textContent = 'No students to display.';
                return;
            }

            const offset = (page - 1) * rowsPerPage;
            if (countEl) countEl.textContent =
                `Showing ${offset + 1}–${offset + list.length} of ${totalStudents} student${totalStudents === 1 ? '' : 's'}`;

            tbody.innerHTML = list.map((s, i) => {
                const isActive = Number(s.is_active) === 1;
                const fullName = [s.fname, s.mname, s.lname].filter(Boolean).join(' ');
                const status = s.enrollment_status || null;
                const toggleBtn = isActive
                    ? `<button class="btn-student btn-student-deactivate" onclick='toggleStudent(${s.id},0,${JSON.stringify(fullName)})'>Deactivate</button>`
                    : `<button class="btn-student btn-student-activate"   onclick='toggleStudent(${s.id},1,${JSON.stringify(fullName)})'>Activate</button>`;
                return `<tr>
                <td style="text-align:center;"><span class="row-num">${offset + i + 1}</span></td>
                <td>${escapeHtml(s.lrn || '—')}</td>
                <td><span class="student-name">${escapeHtml(fullName || '—')}</span></td>
                <td>${s.grade_level_name
                        ? `<span class="student-grade">${escapeHtml(s.grade_level_name)}</span>`
                        : '<span style="color:#9ab0c8;">—</span>'}</td>
                <td style="text-align:center;">${escapeHtml(s.age || '—')}</td>
                <td style="text-align:center;">${escapeHtml(s.gender || '—')}</td>
                <td>${escapeHtml(s.guardian_name || '—')}</td>
                <td>${s.guardian_contact_num
                        ? `<a class="student-contact-link" href="tel:${escapeHtml(s.guardian_contact_num)}">${escapeHtml(s.guardian_contact_num)}</a>`
                        : '<span style="color:#9ab0c8;">—</span>'}</td>
                <td style="text-align:center;">${getStatusBadge(status)}</td>
                <td style="text-align:center;">
                    <div class="students-actions">
                        <a href="student_form.php?id=${encodeURIComponent(s.id)}" class="btn-student btn-student-edit">
                            <i class="bi bi-pencil-square"></i> Edit
                        </a>
                        ${toggleBtn}
                    </div>
                </td>
            </tr>`;
            }).join('');

            cardView.innerHTML = list.map((s, i) => {
                const isActive = Number(s.is_active) === 1;
                const fullName = [s.fname, s.mname, s.lname].filter(Boolean).join(' ');
                const status = s.enrollment_status || null;
                const toggleBtn = isActive
                    ? `<button class="btn-student btn-student-deactivate w-100" onclick='toggleStudent(${s.id},0,${JSON.stringify(fullName)})'>Deactivate</button>`
                    : `<button class="btn-student btn-student-activate w-100"   onclick='toggleStudent(${s.id},1,${JSON.stringify(fullName)})'>Activate</button>`;
                return `<div class="students-mobile-card">
                <div class="students-mobile-card-header">
                    <div>
                        <div class="students-mobile-card-title">${offset + i + 1}. ${escapeHtml(fullName)}</div>
                        <p class="students-mobile-card-subtitle">LRN: ${escapeHtml(s.lrn || '—')}</p>
                    </div>
                    ${getStatusBadge(status)}
                </div>
                <div class="students-mobile-card-body">
                    <div class="students-mobile-grid">
                        <div class="students-mobile-item"><small>Grade</small><span>${escapeHtml(s.grade_level_name || '—')}</span></div>
                        <div class="students-mobile-item"><small>Age</small><span>${escapeHtml(s.age || '—')}</span></div>
                        <div class="students-mobile-item"><small>Sex</small><span>${escapeHtml(s.gender || '—')}</span></div>
                        <div class="students-mobile-item"><small>Guardian</small><span>${escapeHtml(s.guardian_name || '—')}</span></div>
                        <div class="students-mobile-item" style="grid-column:1/-1;">
                            <small>Contact</small>
                            ${s.guardian_contact_num
                        ? `<a class="student-contact-link" href="tel:${escapeHtml(s.guardian_contact_num)}">${escapeHtml(s.guardian_contact_num)}</a>`
                        : '<span>—</span>'}
                        </div>
                    </div>
                    <div class="students-mobile-actions">
                        <a href="student_form.php?id=${encodeURIComponent(s.id)}" class="btn-student btn-student-edit w-100">
                            <i class="bi bi-pencil-square"></i> Edit Student
                        </a>
                        ${toggleBtn}
                    </div>
                </div>
            </div>`;
            }).join('');

            const maxPages = 7;
            const half = Math.floor(maxPages / 2);
            let startPage = Math.max(1, page - half);
            let endPage = Math.min(pages, startPage + maxPages - 1);
            if (endPage - startPage < maxPages - 1) startPage = Math.max(1, endPage - maxPages + 1);

            let html = `<li class="students-page-item ${page <= 1 ? 'disabled' : ''}">
            <a class="students-page-link" href="javascript:void(0)" onclick="loadStudents(${page - 1}, searchTerm)">
                <i class="bi bi-chevron-left"></i>
            </a></li>`;

            if (startPage > 1) {
                html += `<li class="students-page-item">
                <a class="students-page-link" href="javascript:void(0)" onclick="loadStudents(1, searchTerm)">1</a></li>`;
                if (startPage > 2) html += `<li class="students-page-item disabled"><a class="students-page-link">…</a></li>`;
            }

            for (let n = startPage; n <= endPage; n++) {
                html += `<li class="students-page-item ${n === page ? 'active' : ''}">
                <a class="students-page-link" href="javascript:void(0)" onclick="loadStudents(${n}, searchTerm)">${n}</a></li>`;
            }

            if (endPage < pages) {
                if (endPage < pages - 1) html += `<li class="students-page-item disabled"><a class="students-page-link">…</a></li>`;
                html += `<li class="students-page-item">
                <a class="students-page-link" href="javascript:void(0)" onclick="loadStudents(${pages}, searchTerm)">${pages}</a></li>`;
            }

            html += `<li class="students-page-item ${page >= pages ? 'disabled' : ''}">
            <a class="students-page-link" href="javascript:void(0)" onclick="loadStudents(${page + 1}, searchTerm)">
                <i class="bi bi-chevron-right"></i>
            </a></li>`;

            pagination.innerHTML = html;
        }

        function toggleStudent(id, newState, studentName = 'this student') {
            const action = newState === 1 ? 'activate' : 'deactivate';
            confirmAction({
                title: `${action.charAt(0).toUpperCase() + action.slice(1)} student?`,
                text: `This will ${action} ${studentName}.`,
                confirmButtonText: newState === 1 ? 'Activate' : 'Deactivate'
            }, async () => {
                try {
                    const res = await fetchJson('api/student/toggle.php?id=' + encodeURIComponent(id));
                    if (res.success) {
                        showAlert(res.message || `Student ${action}d successfully.`, 'success');
                        loadStudents(currentPage, searchTerm);
                    } else {
                        showAlert(res.message || res.error || 'Toggle failed.', 'danger');
                    }
                } catch (e) { showAlert(e.message, 'danger'); }
            }, () => showAlert(`${action.charAt(0).toUpperCase() + action.slice(1)} cancelled.`, 'info'));
        }

        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        // ARCHIVE / HISTORY TAB
        // â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        let archiveCurrentPage = 1;
        let archiveCurrentStatus = 'all';
        let archiveCurrentYear = 'all';
        let archiveCurrentSearch = '';
        let archiveSearchDebounce = null;
        let archiveYearsLoaded = false;

        function formatDate(value) {
            if (!value) return '—';
            const normalized = String(value).replace('T', ' ');
            return normalized.length >= 16 ? normalized.slice(0, 16) : normalized;
        }

        function populateArchiveYearDropdown(allYears) {
            if (archiveYearsLoaded) return;
            archiveYearsLoaded = true;
            const select = document.getElementById('archiveYearFilter');
            select.innerHTML = '<option value="all">All Years</option>';
            (allYears || []).forEach(y => {
                const opt = document.createElement('option');
                opt.value = y.id;
                opt.textContent = `S.Y. ${y.year_label}${Number(y.is_active) === 1 ? ' (Active)' : ''}`;
                select.appendChild(opt);
            });
        }

        async function loadArchive(page = 1, status = archiveCurrentStatus, year = archiveCurrentYear, search = archiveCurrentSearch) {
            archiveCurrentPage = page;
            archiveCurrentStatus = status;
            archiveCurrentYear = year;
            archiveCurrentSearch = search;

            document.getElementById('archiveTableBody').innerHTML =
                `<tr><td colspan="9"><div class="students-empty"><i class="bi bi-hourglass-split"></i><p>Loading archived records...</p></div></td></tr>`;
            document.getElementById('archiveCardView').innerHTML = '';

            try {
                let url = `api/student/archive-read.php?p=${page}`;
                if (status && status !== 'all') url += `&status=${encodeURIComponent(status)}`;
                if (year && year !== 'all') url += `&year_id=${encodeURIComponent(year)}`;
                if (search && search.trim() !== '') url += `&search=${encodeURIComponent(search.trim())}`;

                const data = await fetchJson(url);

                if (!data.success) {
                    showAlert(data.error || 'Failed to load archive.', 'danger');
                    document.getElementById('archiveTableBody').innerHTML =
                        `<tr><td colspan="9"><div class="students-empty"><i class="bi bi-exclamation-triangle"></i><p>${escapeHtml(data.error || 'Failed to load archive.')}</p></div></td></tr>`;
                    return;
                }

                populateArchiveYearDropdown(data.all_years);
                renderArchive(data.records || [], data.page || 1, data.pages || 1, data.total || 0);
            } catch (e) {
                showAlert(e.message, 'danger');
                document.getElementById('archiveTableBody').innerHTML =
                    `<tr><td colspan="9"><div class="students-empty"><i class="bi bi-exclamation-triangle"></i><p>${escapeHtml(e.message)}</p></div></td></tr>`;
            }
        }

        function renderArchive(list, page, pages, totalCount) {
            const tableBody = document.getElementById('archiveTableBody');
            const cardView = document.getElementById('archiveCardView');
            const pagination = document.getElementById('archivePagination');
            const countEl = document.getElementById('archiveCountText');

            // The chip now always shows "Archive Directory" – no count update needed.

            if (!Array.isArray(list) || !list.length) {
                const emptyHtml = `<div class="students-empty"><i class="bi bi-archive"></i><p>No archived records found.</p></div>`;
                tableBody.innerHTML = `<tr><td colspan="9">${emptyHtml}</td></tr>`;
                cardView.innerHTML = emptyHtml;
                pagination.innerHTML = '';
                if (countEl) countEl.textContent = 'No records to display.';
                return;
            }

            const offset = (page - 1) * rowsPerPage;
            if (countEl) countEl.textContent = `Showing ${offset + 1}–${offset + list.length} of ${totalCount} record${totalCount === 1 ? '' : 's'}`;

            tableBody.innerHTML = list.map((item, index) => {
                const fullName = [item.fname, item.mname, item.lname].filter(Boolean).join(' ');
                return `
                <tr>
                    <td style="text-align:center;"><span style="color:#a0b4cc; font-size:0.82rem; font-weight:600;">${offset + index + 1}</span></td>
                    <td>
                        <div class="archive-name">${escapeHtml(fullName || 'Unnamed')}</div>
                        <div class="archive-subtext">ID: ${escapeHtml(item.student_id || '—')}</div>
                    </td>
                    <td>${escapeHtml(item.lrn || '—')}</td>
                    <td style="text-align:center;">
                        <span class="student-grade">${escapeHtml(item.grade_level_name || '—')}</span>
                    </td>
                    <td style="text-align:center;">
                        <span class="archive-year-badge">
                            <i class="bi bi-calendar3"></i> ${escapeHtml(item.year_label || '—')}
                        </span>
                    </td>
                    <td style="text-align:center;">${getArchiveStatusBadge(item.status)}</td>
                    <td style="text-align:center;">
                        <span style="font-weight:700; color:${Number(item.final_average) >= 75 ? '#1a7a4a' : '#c0392b'};">
                            ${item.final_average !== null ? Number(item.final_average).toFixed(2) : '—'}
                        </span>
                    </td>
                    <td style="text-align:center;">
                        <span style="font-weight:600; color:#355787; font-size:0.85rem;">${escapeHtml(formatDate(item.archived_at))}</span>
                    </td>
                    <td style="text-align:center;">
                        <div class="archive-actions">
                            <button class="btn-student btn-archive-activate" onclick="restoreArchivedStudent(${Number(item.id)}, '${escapeHtml(item.status)}')">
                                <i class="bi bi-arrow-repeat me-1"></i> Restore
                            </button>
                            <button class="btn-student btn-archive-delete" onclick="deleteArchivedStudent(${Number(item.id)})">
                                <i class="bi bi-trash3 me-1"></i> Delete
                            </button>
                        </div>
                    </td>
                </tr>`;
            }).join('');

            cardView.innerHTML = list.map((item, index) => {
                const fullName = [item.fname, item.mname, item.lname].filter(Boolean).join(' ');
                return `
                <div class="students-mobile-card">
                    <div class="students-mobile-card-header">
                        <div>
                            <div class="students-mobile-card-title">${offset + index + 1}. ${escapeHtml(fullName || 'Unnamed')}</div>
                            <p class="students-mobile-card-subtitle">LRN: ${escapeHtml(item.lrn || '—')}</p>
                        </div>
                        ${getArchiveStatusBadge(item.status)}
                    </div>
                    <div class="students-mobile-card-body">
                        <div class="students-mobile-grid">
                            <div class="students-mobile-item"><small>Grade Level</small><span>${escapeHtml(item.grade_level_name || '—')}</span></div>
                            <div class="students-mobile-item"><small>Academic Year</small><span>${escapeHtml(item.year_label || '—')}</span></div>
                            <div class="students-mobile-item"><small>Final Average</small>
                                <span style="color:${Number(item.final_average) >= 75 ? '#1a7a4a' : '#c0392b'}; font-weight:700;">
                                    ${item.final_average !== null ? Number(item.final_average).toFixed(2) : '—'}
                                </span>
                            </div>
                            <div class="students-mobile-item"><small>Archived</small><span>${escapeHtml(formatDate(item.archived_at))}</span></div>
                        </div>
                        <div class="students-mobile-actions">
                            <button class="btn-student btn-archive-activate w-100" onclick="restoreArchivedStudent(${Number(item.id)}, '${escapeHtml(item.status)}')">
                                <i class="bi bi-arrow-repeat me-1"></i> Restore Student
                            </button>
                            <button class="btn-student btn-archive-delete w-100" onclick="deleteArchivedStudent(${Number(item.id)})">
                                <i class="bi bi-trash3 me-1"></i> Delete Permanently
                            </button>
                        </div>
                    </div>
                </div>`;
            }).join('');

            const maxPages = 7;
            const half = Math.floor(maxPages / 2);
            let startPage = Math.max(1, page - half);
            let endPage = Math.min(pages, startPage + maxPages - 1);
            if (endPage - startPage < maxPages - 1) startPage = Math.max(1, endPage - maxPages + 1);

            let html = `<li class="students-page-item ${page <= 1 ? 'disabled' : ''}">
            <a class="students-page-link" href="javascript:void(0)" onclick="loadArchive(${page - 1}, archiveCurrentStatus, archiveCurrentYear, archiveCurrentSearch)">
                <i class="bi bi-chevron-left"></i>
            </a></li>`;

            if (startPage > 1) {
                html += `<li class="students-page-item">
                <a class="students-page-link" href="javascript:void(0)" onclick="loadArchive(1, archiveCurrentStatus, archiveCurrentYear, archiveCurrentSearch)">1</a></li>`;
                if (startPage > 2) html += `<li class="students-page-item disabled"><a class="students-page-link">…</a></li>`;
            }

            for (let n = startPage; n <= endPage; n++) {
                html += `<li class="students-page-item ${n === page ? 'active' : ''}">
                <a class="students-page-link" href="javascript:void(0)" onclick="loadArchive(${n}, archiveCurrentStatus, archiveCurrentYear, archiveCurrentSearch)">${n}</a></li>`;
            }

            if (endPage < pages) {
                if (endPage < pages - 1) html += `<li class="students-page-item disabled"><a class="students-page-link">…</a></li>`;
                html += `<li class="students-page-item">
                <a class="students-page-link" href="javascript:void(0)" onclick="loadArchive(${pages}, archiveCurrentStatus, archiveCurrentYear, archiveCurrentSearch)">${pages}</a></li>`;
            }

            html += `<li class="students-page-item ${page >= pages ? 'disabled' : ''}">
            <a class="students-page-link" href="javascript:void(0)" onclick="loadArchive(${page + 1}, archiveCurrentStatus, archiveCurrentYear, archiveCurrentSearch)">
                <i class="bi bi-chevron-right"></i>
            </a></li>`;

            pagination.innerHTML = html;
        }

        function restoreArchivedStudent(archiveId, currentStatus) {
            confirmAction({
                title: 'Restore student?',
                text: 'This will restore the student to the active roster and set the status to ENROLLED.',
                confirmButtonText: 'Restore'
            }, async () => {
                try {
                    const res = await fetchJson('api/student/archive-restore.php', {
                        method: 'POST', headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id: archiveId })
                    });
                    if (res.success) {
                        showAlert(res.message || 'Student restored successfully.', 'success');
                        loadArchive(archiveCurrentPage, archiveCurrentStatus, archiveCurrentYear, archiveCurrentSearch);
                        if (document.getElementById('pane-students').style.display !== 'none') {
                            loadStudents(currentPage, searchTerm);
                        }
                    } else { showAlert(res.error || res.message || 'Restore failed.', 'danger'); }
                } catch (error) { showAlert(error.message, 'danger'); }
            }, () => showAlert('Restore cancelled.', 'info'));
        }

        function deleteArchivedStudent(archiveId) {
            confirmAction({
                title: 'Delete archived student permanently?',
                text: 'This will permanently delete the archived record. This action cannot be undone.',
                icon: 'warning',
                confirmButtonText: 'Delete'
            }, async () => {
                try {
                    const res = await fetchJson('api/student/archive-delete.php', {
                        method: 'POST', headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id: archiveId })
                    });
                    if (res.success) {
                        showAlert(res.message || 'Archived record permanently deleted.', 'success');
                        loadArchive(archiveCurrentPage, archiveCurrentStatus, archiveCurrentYear, archiveCurrentSearch);
                    } else { showAlert(res.error || res.message || 'Delete failed.', 'danger'); }
                } catch (error) { showAlert(error.message, 'danger'); }
            }, () => showAlert('Delete cancelled.', 'info'));
        }

        // Archive filter event listeners
        document.getElementById('archiveStatusFilter').addEventListener('change', function () {
            archiveCurrentStatus = this.value;
            loadArchive(1, archiveCurrentStatus, archiveCurrentYear, archiveCurrentSearch);
        });

        document.getElementById('archiveYearFilter').addEventListener('change', function () {
            archiveCurrentYear = this.value;
            loadArchive(1, archiveCurrentStatus, archiveCurrentYear, archiveCurrentSearch);
        });

        document.getElementById('archiveSearchInput').addEventListener('input', function () {
            const value = this.value;
            clearTimeout(archiveSearchDebounce);
            archiveSearchDebounce = setTimeout(() => {
                archiveCurrentSearch = value.trim();
                loadArchive(1, archiveCurrentStatus, archiveCurrentYear, archiveCurrentSearch);
            }, 500);
        });

        document.getElementById('clearArchiveFiltersBtn').addEventListener('click', function () {
            document.getElementById('archiveStatusFilter').value = 'all';
            document.getElementById('archiveYearFilter').value = 'all';
            document.getElementById('archiveSearchInput').value = '';
            archiveCurrentStatus = 'all';
            archiveCurrentYear = 'all';
            archiveCurrentSearch = '';
            loadArchive(1, archiveCurrentStatus, archiveCurrentYear, archiveCurrentSearch);
        });

        // Student search listener
        document.getElementById('searchInput').addEventListener('input', function (e) {
            clearTimeout(searchDebounce);
            searchDebounce = setTimeout(() => loadStudents(1, e.target.value.trim()), 300);
        });

        // â”€â”€ INIT â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        const defaultTab = '<?= $defaultTab ?>';
        if (defaultTab === 'archive') {
            loadArchive(1);
        } else {
            loadStudents(1, '');
        }
    </script>
</body>

</html>



