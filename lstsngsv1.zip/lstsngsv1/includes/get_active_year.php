<?php
function getActiveYear(PDO $pdo): ?array
{
    $stmt = $pdo->query("
        SELECT id, year_label, start_date, end_date
        FROM tblacademicyear
        WHERE is_active = 1
        LIMIT 1
    ");

    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}
