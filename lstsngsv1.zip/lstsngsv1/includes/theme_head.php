<?php
if (!isset($pdo)) {
    $dbConnectFile = __DIR__ . '/../api/shared/db_connect.php';
    if (file_exists($dbConnectFile)) {
        require_once $dbConnectFile;
    }
}

if (isset($pdo)) {
    require_once __DIR__ . '/../api/shared/settings_schema.php';
    stsnEnsureSettingsSchema($pdo);
}

$scriptName = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? ''));
$isTeacherContext = strpos($scriptName, '/pages/') !== false;
$stsnThemeKey = $isTeacherContext ? 'stsn_teacher_theme' : 'stsn_theme';

// Asset base: works from any folder depth (root pages, /pages/, /SuperAdmin/, ...).
// Falls back to the old behaviour if the path cannot be resolved.
$stsnProjectRoot = str_replace('\\', '/', (string) realpath(__DIR__ . '/..'));
$stsnPageDir     = str_replace('\\', '/', (string) realpath(dirname((string) ($_SERVER['SCRIPT_FILENAME'] ?? ''))));
$stsnAssetBase   = $isTeacherContext ? '../' : '';
if ($stsnProjectRoot !== '' && $stsnPageDir !== '' && stripos($stsnPageDir, $stsnProjectRoot) === 0) {
    $stsnRelDir    = trim(substr($stsnPageDir, strlen($stsnProjectRoot)), '/');
    $stsnDepth     = $stsnRelDir === '' ? 0 : count(explode('/', $stsnRelDir));
    $stsnAssetBase = str_repeat('../', $stsnDepth);
}

// Only emit tags for files that actually exist (no more 404s in the console).
$stsnHasDarkCss = $stsnProjectRoot !== '' && is_file($stsnProjectRoot . '/css/dark-mode.css');
$stsnHasThemeJs = $stsnProjectRoot !== '' && is_file($stsnProjectRoot . '/js/theme.js');

$stsnTheme = 'light';
if (!$isTeacherContext) {
    if (!empty($_COOKIE['stsn_theme']) && in_array($_COOKIE['stsn_theme'], ['dark', 'light'], true)) {
        $stsnTheme = $_COOKIE['stsn_theme'];
    } elseif (!empty($_SESSION['theme_preference']) && in_array($_SESSION['theme_preference'], ['dark', 'light'], true)) {
        $stsnTheme = $_SESSION['theme_preference'];
    } elseif (!empty($_SESSION['user_id']) && isset($pdo)) {
        try {
            $themeStmt = $pdo->prepare('SELECT theme_preference FROM tblusers WHERE id = ? LIMIT 1');
            $themeStmt->execute([(int) $_SESSION['user_id']]);
            $fetchedTheme = (string) $themeStmt->fetchColumn();
            if (in_array($fetchedTheme, ['dark', 'light'], true)) {
                $stsnTheme = $fetchedTheme;
                $_SESSION['theme_preference'] = $fetchedTheme;
            }
        } catch (Throwable $e) {
            $stsnTheme = 'light';
        }
    }
}
?>
<?php if ($stsnHasDarkCss): ?>
<link rel="stylesheet" href="<?= htmlspecialchars($stsnAssetBase) ?>css/dark-mode.css">
<?php endif; ?>
<?php if ($isTeacherContext && is_file($stsnProjectRoot . '/css/teacher-notifications.css')): ?>
<link rel="stylesheet" href="<?= htmlspecialchars($stsnAssetBase) ?>css/teacher-notifications.css">
<?php endif; ?>
<?php if ($isTeacherContext && is_file($stsnProjectRoot . '/css/teacher-transitions.css')): ?>
<link rel="stylesheet" href="<?= htmlspecialchars($stsnAssetBase) ?>css/teacher-transitions.css">
<?php endif; ?>
<script>
    (function () {
        var stsnThemeKey = <?= json_encode($stsnThemeKey) ?>;
        var serverTheme = <?= json_encode($stsnTheme) ?>;
        var stored = null;
        try { stored = localStorage.getItem(stsnThemeKey); } catch (e) { stored = null; }
        var theme = stored || serverTheme || 'light';
        document.documentElement.classList.toggle('dark-mode', theme === 'dark');
        document.documentElement.classList.toggle('light-mode', theme !== 'dark');
        document.documentElement.setAttribute('data-bs-theme', theme === 'dark' ? 'dark' : 'light');
        document.documentElement.setAttribute('data-stsn-theme', theme);
        try { localStorage.setItem(stsnThemeKey, theme); } catch (e) {}
        document.addEventListener('DOMContentLoaded', function () {
            document.body.classList.toggle('dark-mode', theme === 'dark');
            document.body.classList.toggle('light-mode', theme !== 'dark');
        });
    })();</script>
<script>window.stsnThemeKey = <?= json_encode($stsnThemeKey) ?>;</script>
<?php if ($stsnHasThemeJs): ?>
<script src="<?= htmlspecialchars($stsnAssetBase) ?>js/theme.js" defer></script>
<?php endif; ?>