<?php

function stsnXlsxXml(string $value): string
{
    return htmlspecialchars($value, ENT_XML1 | ENT_COMPAT, 'UTF-8');
}

function stsnXlsxColumnName(int $column): string
{
    $name = '';
    while ($column > 0) {
        $column--;
        $name = chr(65 + ($column % 26)) . $name;
        $column = intdiv($column, 26);
    }
    return $name;
}

function stsnXlsxCellXml(int $row, int $column, $cell): string
{
    $reference = stsnXlsxColumnName($column) . $row;
    $value = is_array($cell) ? ($cell['value'] ?? '') : $cell;
    $style = is_array($cell) ? (int)($cell['style'] ?? 0) : 0;
    $styleAttribute = $style > 0 ? ' s="' . $style . '"' : '';

    if (is_int($value) || is_float($value)) {
        $number = rtrim(rtrim(number_format((float)$value, 4, '.', ''), '0'), '.');
        if ($number === '') {
            $number = '0';
        }
        return '<c r="' . $reference . '"' . $styleAttribute . '><v>' . $number . '</v></c>';
    }

    return '<c r="' . $reference . '" t="inlineStr"' . $styleAttribute . '><is><t xml:space="preserve">'
        . stsnXlsxXml((string)$value) . '</t></is></c>';
}

function stsnXlsxCreate(array $rows, array $merges, array $columnWidths, string $sheetName = 'Grading Sheet'): string
{
    $sheetName = preg_replace('/[\\\\\/:?*\[\]]/', ' ', $sheetName) ?? '';
    $sheetName = trim(substr($sheetName, 0, 31));
    if ($sheetName === '') {
        $sheetName = 'Grading Sheet';
    }

    $sheetRows = '';
    $maxRow = 1;
    $maxColumn = 1;
    foreach ($rows as $rowNumber => $cells) {
        $maxRow = max($maxRow, (int)$rowNumber);
        ksort($cells);
        $rowXml = '';
        foreach ($cells as $column => $cell) {
            $maxColumn = max($maxColumn, (int)$column);
            $rowXml .= stsnXlsxCellXml((int)$rowNumber, (int)$column, $cell);
        }
        $height = in_array((int)$rowNumber, [1, 2], true) ? ' ht="26" customHeight="1"' : '';
        $sheetRows .= '<row r="' . (int)$rowNumber . '"' . $height . '>' . $rowXml . '</row>';
    }

    $columnsXml = '';
    foreach ($columnWidths as $column => $width) {
        $columnsXml .= '<col min="' . (int)$column . '" max="' . (int)$column . '" width="'
            . (float)$width . '" customWidth="1"/>';
    }
    $mergeXml = '';
    foreach ($merges as $merge) {
        $mergeXml .= '<mergeCell ref="' . stsnXlsxXml((string)$merge) . '"/>';
    }
    $mergesXml = $mergeXml !== ''
        ? '<mergeCells count="' . count($merges) . '">' . $mergeXml . '</mergeCells>'
        : '';

    $sheetXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        . '<dimension ref="A1:' . stsnXlsxColumnName($maxColumn) . $maxRow . '"/>'
        . '<sheetViews><sheetView workbookViewId="0"/></sheetViews>'
        . '<sheetFormatPr defaultRowHeight="20"/>'
        . '<cols>' . $columnsXml . '</cols>'
        . '<sheetData>' . $sheetRows . '</sheetData>'
        . $mergesXml
        . '<pageMargins left="0.25" right="0.25" top="0.5" bottom="0.5" header="0.2" footer="0.2"/>'
        . '</worksheet>';

    $stylesXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        . '<fonts count="5">'
        . '<font><sz val="11"/><name val="Calibri"/></font>'
        . '<font><b/><color rgb="FFFFFFFF"/><sz val="16"/><name val="Calibri"/></font>'
        . '<font><b/><color rgb="FF1E2A3E"/><sz val="11"/><name val="Calibri"/></font>'
        . '<font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Calibri"/></font>'
        . '<font><b/><color rgb="FF17365D"/><sz val="10"/><name val="Calibri"/></font>'
        . '</fonts>'
        . '<fills count="6">'
        . '<fill><patternFill patternType="none"/></fill>'
        . '<fill><patternFill patternType="gray125"/></fill>'
        . '<fill><patternFill patternType="solid"><fgColor rgb="FF17365D"/><bgColor indexed="64"/></patternFill></fill>'
        . '<fill><patternFill patternType="solid"><fgColor rgb="FF1F4E78"/><bgColor indexed="64"/></patternFill></fill>'
        . '<fill><patternFill patternType="solid"><fgColor rgb="FFD9EAF7"/><bgColor indexed="64"/></patternFill></fill>'
        . '<fill><patternFill patternType="solid"><fgColor rgb="FFFFF2CC"/><bgColor indexed="64"/></patternFill></fill>'
        . '</fills>'
        . '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>'
        . '<border><left style="thin"><color rgb="FFD5DDE5"/></left><right style="thin"><color rgb="FFD5DDE5"/></right>'
        . '<top style="thin"><color rgb="FFD5DDE5"/></top><bottom style="thin"><color rgb="FFD5DDE5"/></bottom><diagonal/></border></borders>'
        . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        . '<cellXfs count="10">'
        . '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
        . '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="center"/></xf>'
        . '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="center"/></xf>'
        . '<xf numFmtId="0" fontId="3" fillId="3" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
        . '<xf numFmtId="0" fontId="4" fillId="4" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
        . '<xf numFmtId="0" fontId="2" fillId="5" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>'
        . '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyAlignment="1"><alignment vertical="center"/></xf>'
        . '<xf numFmtId="0" fontId="3" fillId="2" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
        . '<xf numFmtId="0" fontId="2" fillId="4" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
        . '<xf numFmtId="0" fontId="2" fillId="5" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
        . '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
        . '</styleSheet>';

    $files = [
        '[Content_Types].xml' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            . '</Types>',
        '_rels/.rels' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            . '</Relationships>',
        'xl/workbook.xml' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<sheets><sheet name="' . stsnXlsxXml($sheetName) . '" sheetId="1" r:id="rId1"/></sheets></workbook>',
        'xl/_rels/workbook.xml.rels' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
            . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
            . '</Relationships>',
        'xl/styles.xml' => $stylesXml,
        'xl/worksheets/sheet1.xml' => $sheetXml,
    ];

    return stsnXlsxZip($files);
}

function stsnXlsxZip(array $files): string
{
    $archive = '';
    $centralDirectory = '';
    $dosTime = (int)(date('G') << 11 | date('i') << 5 | (int)(date('s') / 2));
    $dosDate = (int)(((int)date('Y') - 1980) << 9 | (int)date('n') << 5 | (int)date('j'));

    foreach ($files as $name => $contents) {
        $name = (string)$name;
        $compressed = gzdeflate((string)$contents);
        if ($compressed === false) {
            throw new RuntimeException('Could not compress spreadsheet content.');
        }
        $crc = crc32((string)$contents);
        $compressedSize = strlen($compressed);
        $uncompressedSize = strlen((string)$contents);
        $nameLength = strlen($name);
        $offset = strlen($archive);

        $archive .= pack(
            'VvvvvvVVVvv',
            0x04034b50,
            20,
            0,
            8,
            $dosTime,
            $dosDate,
            $crc,
            $compressedSize,
            $uncompressedSize,
            $nameLength,
            0
        ) . $name . $compressed;

        $centralDirectory .= pack(
            'VvvvvvvVVVvvvvvVV',
            0x02014b50,
            20,
            20,
            0,
            8,
            $dosTime,
            $dosDate,
            $crc,
            $compressedSize,
            $uncompressedSize,
            $nameLength,
            0,
            0,
            0,
            0,
            0,
            $offset
        ) . $name;
    }

    $centralOffset = strlen($archive);
    $archive .= $centralDirectory;
    $archive .= pack(
        'VvvvvVVv',
        0x06054b50,
        0,
        0,
        count($files),
        count($files),
        strlen($centralDirectory),
        $centralOffset,
        0
    );

    return $archive;
}

function stsnXlsxRead(string $archivePath): array
{
    $archiveSize = filesize($archivePath);
    if ($archiveSize === false || $archiveSize < 22 || $archiveSize > 20 * 1024 * 1024) {
        throw new RuntimeException('The workbook is empty or exceeds the 20 MB upload limit.');
    }
    $archive = file_get_contents($archivePath);
    if ($archive === false) {
        throw new RuntimeException('Unable to read the uploaded workbook.');
    }
    return stsnXlsxReadBytes($archive);
}

function stsnXlsxReadBytes(string $archive): array
{
    if (strlen($archive) < 22 || strlen($archive) > 20 * 1024 * 1024) {
        throw new RuntimeException('The workbook is empty or exceeds the 20 MB upload limit.');
    }
    $endOffset = strrpos($archive, "PK\x05\x06");
    if ($endOffset === false || strlen($archive) - $endOffset < 22) {
        throw new RuntimeException('The uploaded file is not a valid .xlsx workbook.');
    }
    $end = unpack('Vsignature/vdisk/vcd_disk/ventries_disk/ventries/Vcd_size/Vcd_offset/vcomment_len', substr($archive, $endOffset, 22));
    if (!$end || $end['signature'] !== 0x06054b50 || $end['entries'] < 1 || $end['entries'] > 1000) {
        throw new RuntimeException('The .xlsx workbook has an invalid ZIP directory.');
    }

    $entries = [];
    $position = (int)$end['cd_offset'];
    for ($index = 0; $index < (int)$end['entries']; $index++) {
        $header = unpack(
            'Vsignature/vmade/vneeded/vflags/vmethod/vmtime/vmdate/Vcrc/Vcompressed/Vuncompressed/vname_len/vextra_len/vcomment_len/vdisk/vinternal/Vexternal/Vlocal_offset',
            substr($archive, $position, 46)
        );
        if (!$header || $header['signature'] !== 0x02014b50) {
            throw new RuntimeException('The .xlsx workbook contains a malformed ZIP entry.');
        }
        $nameStart = $position + 46;
        $name = substr($archive, $nameStart, (int)$header['name_len']);
        $position = $nameStart + (int)$header['name_len'] + (int)$header['extra_len'] + (int)$header['comment_len'];
        if ($header['flags'] & 1) {
            throw new RuntimeException('Encrypted Excel workbooks are not supported.');
        }
        if ($header['uncompressed'] > 30 * 1024 * 1024) {
            throw new RuntimeException('The workbook contains an oversized XML part.');
        }
        $entries[$name] = $header;
    }

    $readEntry = static function (string $name) use ($archive, $entries): string {
        if (!isset($entries[$name])) {
            throw new RuntimeException('The workbook is missing required Excel data.');
        }
        $entry = $entries[$name];
        $localOffset = (int)$entry['local_offset'];
        $local = unpack('Vsignature/vneeded/vflags/vmethod/vmtime/vmdate/Vcrc/Vcompressed/Vuncompressed/vname_len/vextra_len', substr($archive, $localOffset, 30));
        if (!$local || $local['signature'] !== 0x04034b50) {
            throw new RuntimeException('The workbook contains a malformed ZIP entry.');
        }
        $dataStart = $localOffset + 30 + (int)$local['name_len'] + (int)$local['extra_len'];
        $compressed = substr($archive, $dataStart, (int)$entry['compressed']);
        if ($entry['method'] === 0) {
            $contents = $compressed;
        } elseif ($entry['method'] === 8) {
            $contents = gzinflate($compressed, 30 * 1024 * 1024);
        } else {
            throw new RuntimeException('This .xlsx workbook uses an unsupported ZIP compression method.');
        }
        if (
            $contents === false
            || strlen($contents) !== (int)$entry['uncompressed']
            || sprintf('%u', crc32($contents)) !== sprintf('%u', (int)$entry['crc'])
        ) {
            throw new RuntimeException('The workbook contains a damaged or incomplete XML part.');
        }
        return $contents;
    };

    $loadXml = static function (string $xml): DOMDocument {
        $document = new DOMDocument();
        $previous = libxml_use_internal_errors(true);
        $loaded = $document->loadXML($xml, LIBXML_NONET | LIBXML_NOBLANKS);
        libxml_clear_errors();
        libxml_use_internal_errors($previous);
        if (!$loaded) {
            throw new RuntimeException('The workbook contains invalid Excel XML.');
        }
        return $document;
    };

    $workbook = $loadXml($readEntry('xl/workbook.xml'));
    $sheetNodes = $workbook->getElementsByTagNameNS('*', 'sheet');
    if ($sheetNodes->length < 1) {
        throw new RuntimeException('The workbook does not contain a worksheet.');
    }
    $sheetRelation = $sheetNodes->item(0)->getAttributeNS(
        'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
        'id'
    );
    $relationships = $loadXml($readEntry('xl/_rels/workbook.xml.rels'));
    $sheetTarget = '';
    foreach ($relationships->getElementsByTagNameNS('*', 'Relationship') as $relationship) {
        if ($relationship->getAttribute('Id') === $sheetRelation) {
            $sheetTarget = $relationship->getAttribute('Target');
            break;
        }
    }
    if ($sheetTarget === '') {
        throw new RuntimeException('The workbook worksheet reference is invalid.');
    }
    $sheetPath = ltrim($sheetTarget, '/');
    if (strpos($sheetPath, 'xl/') !== 0) {
        $sheetPath = 'xl/' . $sheetPath;
    }
    $sharedStrings = [];
    if (isset($entries['xl/sharedStrings.xml'])) {
        $sharedXml = $loadXml($readEntry('xl/sharedStrings.xml'));
        foreach ($sharedXml->getElementsByTagNameNS('*', 'si') as $sharedItem) {
            $text = '';
            foreach ($sharedItem->getElementsByTagNameNS('*', 't') as $textNode) {
                $text .= $textNode->textContent;
            }
            $sharedStrings[] = $text;
        }
    }

    $worksheet = $loadXml($readEntry($sheetPath));
    $rows = [];
    foreach ($worksheet->getElementsByTagNameNS('*', 'row') as $rowNode) {
        $rowNumber = (int)$rowNode->getAttribute('r');
        if ($rowNumber <= 0) {
            continue;
        }
        $row = [];
        foreach ($rowNode->getElementsByTagNameNS('*', 'c') as $cellNode) {
            $reference = $cellNode->getAttribute('r');
            if (!preg_match('/^([A-Z]+)[0-9]+$/', $reference, $matches)) {
                continue;
            }
            $column = 0;
            foreach (str_split($matches[1]) as $letter) {
                $column = $column * 26 + ord($letter) - 64;
            }
            $column--;
            $type = $cellNode->getAttribute('t');
            $valueNode = $cellNode->getElementsByTagNameNS('*', 'v')->item(0);
            if ($type === 'inlineStr') {
                $value = '';
                foreach ($cellNode->getElementsByTagNameNS('*', 't') as $textNode) {
                    $value .= $textNode->textContent;
                }
            } elseif ($valueNode) {
                $value = $valueNode->textContent;
                if ($type === 's') {
                    $value = $sharedStrings[(int)$value] ?? '';
                }
            } else {
                $value = '';
            }
            $row[$column] = $value;
        }
        if ($row) {
            $rows[$rowNumber] = $row;
        }
    }

    return $rows;
}
