<?php
$footerActiveYear = '';
$footerActiveYearId = null;
$footerActiveQuarter = '';

try {
    if (!isset($pdo)) {
        require_once __DIR__ . '/../api/shared/db_connect.php';
    }

    $stmtFooterYear = $pdo->query("SELECT id, year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
    if ($stmtFooterYear) {
        $footerYear = $stmtFooterYear->fetch(PDO::FETCH_ASSOC) ?: [];
        $footerActiveYearId = isset($footerYear['id']) ? (int) $footerYear['id'] : null;
        $footerActiveYear = (string) ($footerYear['year_label'] ?? '');
    }

    if ($footerActiveYearId !== null) {
        // Use tblconfig_terms (trimester system)
        try {
            $pdo->prepare("
                UPDATE tblconfig_terms 
                SET is_active = CASE 
                    WHEN start_date <= CURDATE() AND end_date >= CURDATE() THEN 1 
                    ELSE 0 
                END 
                WHERE academic_year_id = ?
            ")->execute([$footerActiveYearId]);

            $stmtFooterQuarter = $pdo->prepare("
                SELECT term_label
                FROM tblconfig_terms
                WHERE academic_year_id = ? 
                  AND is_active = 1
                  AND is_closed = 0
                ORDER BY term_number ASC
                LIMIT 1
            ");
            $stmtFooterQuarter->execute([$footerActiveYearId]);
            $footerActiveQuarter = (string) ($stmtFooterQuarter->fetchColumn() ?: '');

            // Fallback: latest non-closed term if none active
            if ($footerActiveQuarter === '') {
                $stmtFooterQuarter = $pdo->prepare("
                    SELECT term_label FROM tblconfig_terms
                    WHERE academic_year_id = ? AND is_closed = 0
                    ORDER BY term_number ASC LIMIT 1
                ");
                $stmtFooterQuarter->execute([$footerActiveYearId]);
                $footerActiveQuarter = (string) ($stmtFooterQuarter->fetchColumn() ?: '');
            }
        } catch (Throwable $e) {
            $footerActiveQuarter = '';
        }
    }
} catch (Throwable $e) {
    $footerActiveYear = '';
    $footerActiveYearId = null;
    $footerActiveQuarter = '';
}
?>

<style>
    .app-footer.stsn-footer {
        background: #fff;
        border-top: 2px solid #e3ecfb;
        padding: 0;
    }

    .stsn-footer-inner {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 0.5rem;
        padding: 0.75rem 1.5rem;
        max-width: 100%;
    }

    .stsn-footer-left {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-size: 0.875rem;
        color: #5a7299;
        font-weight: 500;
    }

    .stsn-footer-left .stsn-footer-copy {
        color: #8fa8c8;
        font-weight: 400;
    }

    .stsn-footer-sep {
        color: #c8d8ee;
        font-weight: 300;
        font-size: 1rem;
    }

    .stsn-footer-brand {
        font-weight: 700;
        color: #0d6efd;
        text-decoration: none;
        letter-spacing: 0.03em;
        transition: color 0.15s;
    }

    .stsn-footer-brand:hover {
        color: #0a58ca;
        text-decoration: none;
    }

    .stsn-footer-system {
        color: #7a94b8;
        font-size: 0.85rem;
    }

    .stsn-footer-right {
        display: flex;
        align-items: center;
        gap: 0.45rem;
        flex-wrap: wrap;
    }

    .stsn-year-chip {
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        padding: 0.35rem 0.85rem;
        border-radius: 999px;
        background: #eef4ff;
        border: 1.5px solid #c6dafb;
        color: #1a56c4;
        font-weight: 700;
        font-size: 0.82rem;
        letter-spacing: 0.02em;
        white-space: nowrap;
    }

    .stsn-year-chip i {
        font-size: 0.85rem;
        color: #4d8ef0;
    }

    .stsn-year-chip.no-year {
        background: #f5f6f8;
        border-color: #dde3ec;
        color: #9aabb8;
    }

    .stsn-year-chip.no-year i {
        color: #b8c5d0;
    }

    @media (max-width: 575.98px) {
        .stsn-footer-inner {
            padding: 0.7rem 1rem;
            flex-direction: column;
            align-items: flex-start;
            gap: 0.6rem;
        }

        .stsn-footer-left {
            flex-wrap: wrap;
        }
    }
</style>

<footer class="app-footer stsn-footer" data-bs-theme="light">
    <div class="stsn-footer-inner">
        <div class="stsn-footer-left">
            <span class="stsn-footer-copy">&copy; 2014&ndash;<?= date('Y') ?></span>
            <span class="stsn-footer-sep">|</span>
            <a href="https://www.facebook.com/stsni90" class="stsn-footer-brand" target="_blank" rel="noopener noreferrer">
                STSN
            </a>
            <span class="stsn-footer-sep">|</span>
            <span class="stsn-footer-system">Grading System</span>
        </div>

        <div class="stsn-footer-right">
            <?php if ($footerActiveYear !== ''): ?>
                <span class="stsn-year-chip" id="footerAcademicYear">
                    <i class="bi bi-calendar2-check-fill"></i>
                    S.Y. <?= htmlspecialchars($footerActiveYear, ENT_QUOTES, 'UTF-8') ?>
                </span>
            <?php else: ?>
                <span class="stsn-year-chip no-year" id="footerAcademicYear">
                    <i class="bi bi-calendar2-x"></i>
                    No Active Year
                </span>
            <?php endif; ?>

            <?php if ($footerActiveQuarter !== ''): ?>
                <span class="stsn-year-chip" id="footerActiveQuarter">
                    <i class="bi bi-calendar3"></i>
                    <?= htmlspecialchars($footerActiveQuarter, ENT_QUOTES, 'UTF-8') ?>
                </span>
            <?php else: ?>
                <span class="stsn-year-chip no-year" id="footerActiveQuarter">
                    <i class="bi bi-calendar3"></i>
                    No Active Term
                </span>
            <?php endif; ?>
        </div>
    </div>
</footer>

<link rel="stylesheet" href="css/system-alerts.css">
<script src="js/system-alerts.js"></script>

