<?php
/**
 * workflow_engine.php
 * Dynamic, configurable grade validation workflow engine.
 * Flow: Teacher -> Adviser -> Subject Coordinator -> Principal -> Registrar
 * (driven by tblworkflow_template / tblworkflow_step / tblworkflow_instance /
 *  tblworkflow_action_log — see sql/migration_workflow_system.sql)
 *
 * Approval steps are required for official grade publication. Callers may
 * still show saved grades internally, but must not publish without completion.
 */

if (!function_exists('wfLogAction')) {
    /**
     * Insert a row into tblworkflow_action_log.
     * Never throws — returns false on failure.
     */
    function wfLogAction(
        PDO $pdo,
        int $instanceId,
        int $stepOrder,
        int $actorUserId,
        int $actorRoleId,
        ?string $actorPosition,
        string $action,
        ?string $remarks
    ): bool {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO tblworkflow_action_log
                    (instance_id, step_order, actor_user_id, actor_role_id,
                     actor_position, action, remarks, acted_at, created_at, updated_at)
                VALUES
                    (:instance_id, :step_order, :actor_user_id, :actor_role_id,
                     :actor_position, :action, :remarks, NOW(), NOW(), NOW())
            ");
            $stmt->execute([
                ':instance_id'    => $instanceId,
                ':step_order'     => $stepOrder,
                ':actor_user_id'  => $actorUserId,
                ':actor_role_id'  => $actorRoleId > 0 ? $actorRoleId : 2, // 2 = Teacher fallback
                ':actor_position' => $actorPosition,
                ':action'         => $action,
                ':remarks'        => $remarks,
            ]);
            return true;
        } catch (Throwable $e) {
            return false;
        }
    }
}

if (!function_exists('getActiveTemplate')) {
    /**
     * Resolve the active workflow template for a grade level, with its steps.
     *
     * PHASE B match order (per-school-year templates):
     *   1. academic_year_id = $academicYearId AND is_active = 1
     *      (resolved from the ACTIVE academic year when not supplied)
     *   2. applies_to_grade_from <= gradeLevelId <= applies_to_grade_to AND is_active = 1
     *   3. is_default = 1 AND is_active = 1
     *   4. any is_active = 1 (ORDER BY id ASC)
     *
     * The 3rd argument is OPTIONAL so existing callers keep working:
     *   getActiveTemplate($pdo)
     *   getActiveTemplate($pdo, $gradeLevelId)
     *
     * @return array|null ['template' => row, 'steps' => [rows]] or null
     */
    function getActiveTemplate(PDO $pdo, int $gradeLevelId = 0, int $academicYearId = 0): ?array
    {
        try {
            $template = null;

            // Resolve the active academic year when the caller did not pass one.
            if ($academicYearId <= 0) {
                try {
                    $academicYearId = (int)$pdo->query("
                        SELECT id FROM tblacademicyear WHERE is_active = 1 ORDER BY id ASC LIMIT 1
                    ")->fetchColumn();
                } catch (Throwable $e) {
                    $academicYearId = 0; // tblacademicyear not present — keep going.
                }
            }

            // 1. Template bound to this academic year (preferred).
            if ($academicYearId > 0) {
                try {
                    $stmt = $pdo->prepare("
                        SELECT *
                        FROM tblworkflow_template
                        WHERE academic_year_id = ? AND is_active = 1
                        ORDER BY id ASC
                        LIMIT 1
                    ");
                    $stmt->execute([$academicYearId]);
                    $template = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
                } catch (Throwable $e) {
                    $template = null; // academic_year_id column not added yet.
                }
            }

            // 2. Legacy most-specific match: grade-level range + active.
            if (!$template && $gradeLevelId > 0) {
                $stmt = $pdo->prepare("
                    SELECT *
                    FROM tblworkflow_template
                    WHERE is_active = 1
                      AND applies_to_grade_from IS NOT NULL
                      AND applies_to_grade_to IS NOT NULL
                      AND applies_to_grade_from <= ?
                      AND applies_to_grade_to >= ?
                    ORDER BY id ASC
                    LIMIT 1
                ");
                $stmt->execute([$gradeLevelId, $gradeLevelId]);
                $template = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
            }

            // 3. Default active template.
            if (!$template) {
                $stmt = $pdo->prepare("
                    SELECT *
                    FROM tblworkflow_template
                    WHERE is_default = 1 AND is_active = 1
                    ORDER BY id ASC
                    LIMIT 1
                ");
                $stmt->execute();
                $template = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
            }

            // 4. Any active template.
            if (!$template) {
                $stmt = $pdo->prepare("
                    SELECT *
                    FROM tblworkflow_template
                    WHERE is_active = 1
                    ORDER BY id ASC
                    LIMIT 1
                ");
                $stmt->execute();
                $template = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
            }

            if (!$template) {
                return null;
            }

            $stepsStmt = $pdo->prepare("
                SELECT *
                FROM tblworkflow_step
                WHERE template_id = ?
                ORDER BY step_order ASC
            ");
            $stepsStmt->execute([(int)$template['id']]);
            $steps = $stepsStmt->fetchAll(PDO::FETCH_ASSOC);

            return [
                'template' => $template,
                'steps'    => $steps,
            ];
        } catch (Throwable $e) {
            return null; // Tables may not exist yet — treat as "no workflow".
        }
    }
}

if (!function_exists('startWorkflow')) {
    /**
     * Start (or resume) a workflow instance for a section/subject/term combo.
     * $params = [
     *   'section_id', 'subject_id', 'term_id', 'academic_year_id',
     *   'teacher_id', 'template_id',
     *   'actor_role_id' => optional (default 2 = Teacher),
     * ]
     *
     * First step (Teacher Encoding) is already done at submit time, so the
     * instance starts at current_step_order = 2.
     */
    function startWorkflow(PDO $pdo, array $params): array
    {
        try {
            $sectionId      = (int)($params['section_id'] ?? 0);
            $subjectId      = (int)($params['subject_id'] ?? 0);
            $termId         = (int)($params['term_id'] ?? 0);
            $academicYearId = (int)($params['academic_year_id'] ?? 0);
            $teacherId      = (int)($params['teacher_id'] ?? 0);
            $templateId     = (int)($params['template_id'] ?? 0);
            $actorRoleId    = (int)($params['actor_role_id'] ?? 2);

            if (!$sectionId || !$subjectId || !$termId || !$academicYearId || !$teacherId || !$templateId) {
                return ['success' => false, 'message' => 'Missing required workflow parameters.'];
            }

            // 1. Check if instance already exists for this combo.
            $findStmt = $pdo->prepare("
                SELECT *
                FROM tblworkflow_instance
                WHERE section_id = ? AND subject_id = ? AND term_id = ? AND academic_year_id = ?
                LIMIT 1
            ");
            $findStmt->execute([$sectionId, $subjectId, $termId, $academicYearId]);
            $existing = $findStmt->fetch(PDO::FETCH_ASSOC);

            $instanceId = 0;
            $status     = '';

            if ($existing) {
                $instanceId = (int)$existing['id'];
                $status     = (string)$existing['status'];

                // 2. Existing IN_PROGRESS / COMPLETED / LOCKED → return as-is (no duplicate).
                if (in_array($status, ['IN_PROGRESS', 'COMPLETED', 'LOCKED'], true)) {
                    return [
                        'success'         => true,
                        'instance_id'     => $instanceId,
                        'status'          => $status,
                        'already_existed' => true,
                        'next_step'       => getCurrentStep($pdo, $instanceId),
                    ];
                }

                // 3. Existing REJECTED → reset for resubmission (back to step 2).
                $resetStmt = $pdo->prepare("
                    UPDATE tblworkflow_instance
                    SET status = 'IN_PROGRESS',
                        current_step_order = 2,
                        submitted_at = NOW(),
                        completed_at = NULL,
                        updated_at = NOW()
                    WHERE id = ?
                ");
                $resetStmt->execute([$instanceId]);

                wfLogAction(
                    $pdo,
                    $instanceId,
                    1,
                    $teacherId,
                    $actorRoleId,
                    'Teacher',
                    'SUBMITTED',
                    'Resubmitted after rejection'
                );
            } else {
                // 4. Insert new instance (step 1 "Teacher Encoding" already done).
                $insStmt = $pdo->prepare("
                    INSERT INTO tblworkflow_instance
                        (section_id, subject_id, term_id, academic_year_id, teacher_id,
                         template_id, current_step_order, status, submitted_at, created_at, updated_at)
                    VALUES
                        (:section_id, :subject_id, :term_id, :academic_year_id, :teacher_id,
                         :template_id, 2, 'IN_PROGRESS', NOW(), NOW(), NOW())
                ");
                $insStmt->execute([
                    ':section_id'       => $sectionId,
                    ':subject_id'       => $subjectId,
                    ':term_id'          => $termId,
                    ':academic_year_id' => $academicYearId,
                    ':teacher_id'       => $teacherId,
                    ':template_id'      => $templateId,
                ]);
                $instanceId = (int)$pdo->lastInsertId();
                $status     = 'IN_PROGRESS';

                // 5. Log the initial submission (step 1 = Teacher Encoding).
                wfLogAction(
                    $pdo,
                    $instanceId,
                    1,
                    $teacherId,
                    $actorRoleId,
                    'Teacher',
                    'SUBMITTED',
                    'Initial submission'
                );
            }

            // 6. Return instance + the step awaiting action.
            return [
                'success'         => true,
                'instance_id'     => $instanceId,
                'status'          => $status,
                'already_existed' => false,
                'next_step'       => getCurrentStep($pdo, $instanceId),
            ];
        } catch (Throwable $e) {
            return ['success' => false, 'message' => 'Workflow start failed: ' . $e->getMessage()];
        }
    }
}

if (!function_exists('advanceWorkflow')) {
    /**
     * Advance (approve) or reject a workflow instance.
     * $params = [
     *   'instance_id', 'actor_user_id', 'actor_role_id', 'actor_position',
     *   'action' ('APPROVED'|'REJECTED'), 'remarks'
     * ]
     */
    function advanceWorkflow(PDO $pdo, array $params): array
    {
        try {
            $instanceId    = (int)($params['instance_id'] ?? 0);
            $actorUserId   = (int)($params['actor_user_id'] ?? 0);
            $actorRoleId   = (int)($params['actor_role_id'] ?? 0);
            $actorPosition = trim((string)($params['actor_position'] ?? ''));
            $action        = strtoupper(trim((string)($params['action'] ?? 'APPROVED')));
            $remarks       = $params['remarks'] ?? null;

            if (!$instanceId) {
                return ['success' => false, 'message' => 'instance_id is required.'];
            }

            $allowedActions = ['APPROVED', 'REJECTED', 'RETURNED', 'OVERRIDE'];
            if (!in_array($action, $allowedActions, true)) {
                return ['success' => false, 'message' => 'Invalid workflow action.'];
            }

            // 1. Load instance.
            $instStmt = $pdo->prepare("
                SELECT *
                FROM tblworkflow_instance
                WHERE id = ?
                LIMIT 1
            ");
            $instStmt->execute([$instanceId]);
            $instance = $instStmt->fetch(PDO::FETCH_ASSOC);

            if (!$instance) {
                return ['success' => false, 'message' => 'Workflow instance not found.'];
            }

            $status = (string)$instance['status'];
            if ($status !== 'IN_PROGRESS') {
                return [
                    'success' => false,
                    'message' => "Workflow instance is {$status}; no action allowed.",
                    'status'  => $status,
                ];
            }

            // 2. Load the current step.
            $currentStepOrder = (int)$instance['current_step_order'];
            $stepStmt = $pdo->prepare("
                SELECT *
                FROM tblworkflow_step
                WHERE template_id = ? AND step_order = ?
                LIMIT 1
            ");
            $stepStmt->execute([(int)$instance['template_id'], $currentStepOrder]);
            $currentStep = $stepStmt->fetch(PDO::FETCH_ASSOC);

            if (!$currentStep) {
                return ['success' => false, 'message' => 'Workflow step configuration is missing for the current step.'];
            }

            $requiredPosition = (string)$currentStep['required_position'];

            // Admin (role_id 1) can override position matching.
            $isAdmin         = $actorRoleId === 1;
            $positionMatches = strcasecmp($actorPosition, $requiredPosition) === 0;
            if (!$positionMatches && strcasecmp($requiredPosition, 'Adviser') === 0 && $actorUserId > 0) {
                $adviserStmt = $pdo->prepare("
                    SELECT 1
                    FROM tblsectionadviser
                    WHERE teacher_id = ? AND section_id = ? AND academic_year_id = ?
                    LIMIT 1
                ");
                $adviserStmt->execute([
                    $actorUserId,
                    (int)$instance['section_id'],
                    (int)$instance['academic_year_id'],
                ]);
                $positionMatches = (bool)$adviserStmt->fetchColumn();
                if ($positionMatches) {
                    $actorPosition = 'Adviser';
                }
            }

            if (!$positionMatches && !$isAdmin) {
                return [
                    'success' => false,
                    'message' => "Only {$requiredPosition} can act on this step.",
                    'status'  => $status,
                ];
            }

            $logPosition = $actorPosition !== '' ? $actorPosition : $requiredPosition;

            // 3. APPROVED (or admin OVERRIDE) → log, move forward.
            if ($action === 'APPROVED' || $action === 'OVERRIDE') {
                wfLogAction(
                    $pdo,
                    $instanceId,
                    $currentStepOrder,
                    $actorUserId,
                    $actorRoleId,
                    $logPosition,
                    $action,
                    $remarks
                );

                $maxStmt = $pdo->prepare("
                    SELECT MAX(step_order)
                    FROM tblworkflow_step
                    WHERE template_id = ?
                ");
                $maxStmt->execute([(int)$instance['template_id']]);
                $maxStepOrder = (int)$maxStmt->fetchColumn();

                $newStepOrder = $currentStepOrder + 1;

                if ($newStepOrder > $maxStepOrder) {
                    // Past the last step → workflow complete.
                    $updStmt = $pdo->prepare("
                        UPDATE tblworkflow_instance
                        SET current_step_order = ?, status = 'COMPLETED',
                            completed_at = NOW(), updated_at = NOW()
                        WHERE id = ?
                    ");
                    $updStmt->execute([$newStepOrder, $instanceId]);

                    $newStatus = 'COMPLETED';
                    $legacySyncOk = true;

                    // At the end, kapag na-hit yung final step (status = COMPLETED):
                    if ($newStatus === 'COMPLETED') {
                        try {
                            // Legacy keys: numeric quarter (tblconfig_terms.term_number)
                            // and school-year label (tblacademicyear.year_label).
                            $termNumber = 0;
                            $yearLabel  = '';
                            try {
                                $tStmt = $pdo->prepare("SELECT term_number FROM tblconfig_terms WHERE id = ? LIMIT 1");
                                $tStmt->execute([(int)$instance['term_id']]);
                                $termNumber = (int)$tStmt->fetchColumn();
                            } catch (Throwable $e) {
                                $termNumber = (int)$instance['term_id']; // term ids are already numeric
                            }
                            try {
                                $yStmt = $pdo->prepare("SELECT year_label FROM tblacademicyear WHERE id = ? LIMIT 1");
                                $yStmt->execute([(int)$instance['academic_year_id']]);
                                $yearLabel = (string)$yStmt->fetchColumn();
                            } catch (Throwable $e) {
                                $yearLabel = '';
                            }

                            // 1. Mark grades as finalized
                            $pdo->prepare("
                                UPDATE tblgrades
                                SET status = 'finalized'
                                WHERE section_id = ? AND subject_id = ?
                                  AND quarter = ? AND academic_year_id = ?
                            ")->execute([
                                $instance['section_id'],
                                $instance['subject_id'],
                                $termNumber,
                                $instance['academic_year_id']
                            ]);

                            $approvalStateStmt = $pdo->prepare("
                                SELECT
                                    COUNT(DISTINCT sch.subject_id) AS expected_subjects,
                                    COUNT(DISTINCT CASE WHEN wi.status = 'COMPLETED' THEN sch.subject_id END) AS completed_subjects
                                FROM tblschedule sch
                                LEFT JOIN tblworkflow_instance wi
                                    ON wi.section_id = sch.section_id
                                   AND wi.subject_id = sch.subject_id
                                   AND wi.term_id = ?
                                   AND wi.academic_year_id = ?
                                   AND wi.id = (
                                       SELECT MAX(wi_latest.id)
                                       FROM tblworkflow_instance wi_latest
                                       WHERE wi_latest.section_id = sch.section_id
                                         AND wi_latest.subject_id = sch.subject_id
                                         AND wi_latest.term_id = ?
                                         AND wi_latest.academic_year_id = ?
                                   )
                                WHERE sch.section_id = ?
                                  AND sch.school_year = ?
                                  AND sch.is_active = 1
                            ");
                            $approvalStateStmt->execute([
                                (int)$instance['term_id'],
                                (int)$instance['academic_year_id'],
                                (int)$instance['term_id'],
                                (int)$instance['academic_year_id'],
                                (int)$instance['section_id'],
                                $yearLabel,
                            ]);
                            $approvalState = $approvalStateStmt->fetch(PDO::FETCH_ASSOC) ?: [];
                            $expectedSubjects = (int)($approvalState['expected_subjects'] ?? 0);
                            $completedSubjects = (int)($approvalState['completed_subjects'] ?? 0);

                            if ($expectedSubjects > 0 && $completedSubjects === $expectedSubjects) {
                                $pdo->prepare("
                                    UPDATE tbladviser_submissions
                                    SET status = 'approved', reviewed_at = NOW(), updated_at = NOW()
                                    WHERE section_id = ? AND quarter = ? AND school_year = ?
                                      AND status = 'pending'
                                ")->execute([
                                    (int)$instance['section_id'],
                                    $termNumber,
                                    $yearLabel,
                                ]);
                            }
                        } catch (Throwable $legacyError) {
                            // Additive design: legacy-table problems must not fail the
                            // workflow transition (instance is already COMPLETED here).
                            $legacySyncOk = false;
                        }
                    }

                    $teacherNotificationSent = false;
                    try {
                        $publishedContextStmt = $pdo->prepare("
                            SELECT sub.subject_name, sec.section_name, gl.grade_level_name,
                                   term.term_label, ay.year_label
                            FROM tblsection sec
                            JOIN tblgradelevel gl ON gl.id = sec.grade_level_id
                            JOIN tblsubjects sub ON sub.id = ?
                            JOIN tblconfig_terms term ON term.id = ?
                            JOIN tblacademicyear ay ON ay.id = ?
                            WHERE sec.id = ?
                            LIMIT 1
                        ");
                        $publishedContextStmt->execute([
                            (int)$instance['subject_id'],
                            (int)$instance['term_id'],
                            (int)$instance['academic_year_id'],
                            (int)$instance['section_id'],
                        ]);
                        $publishedContext = $publishedContextStmt->fetch(PDO::FETCH_ASSOC);
                        if (!$publishedContext || (int)$instance['teacher_id'] <= 0) {
                            throw new RuntimeException('Unable to resolve the grade submission recipient or context.');
                        }
                        $publishedNotificationStmt = $pdo->prepare("
                            INSERT INTO system_notifications (title, message, type, created_at)
                            VALUES (?, ?, ?, NOW())
                        ");
                        $publishedNotificationStmt->execute([
                            'Grades published',
                            sprintf(
                                '%s grades for %s - %s (%s, S.Y. %s) have been approved and published.',
                                (string)$publishedContext['subject_name'],
                                (string)$publishedContext['grade_level_name'],
                                (string)$publishedContext['section_name'],
                                (string)$publishedContext['term_label'],
                                (string)$publishedContext['year_label']
                            ),
                            'teacher:' . (int)$instance['teacher_id'],
                        ]);
                        $teacherNotificationSent = true;
                    } catch (Throwable $notificationError) {
                        error_log('[workflow publish notification] ' . $notificationError->getMessage());
                    }

                    return [
                        'success'     => true,
                        'new_step'    => $newStepOrder,
                        'status'      => 'COMPLETED',
                        'completed'   => true,
                        'next_step'   => null,
                        'legacy_sync' => $legacySyncOk,
                        'teacher_notification_sent' => $teacherNotificationSent,
                    ];
                }

                // Next step exists → stays IN_PROGRESS. If the next step is the
                // Registrar's PUBLISH step, it simply waits there for the registrar.
                $nextStmt = $pdo->prepare("
                    SELECT *
                    FROM tblworkflow_step
                    WHERE template_id = ? AND step_order = ?
                    LIMIT 1
                ");
                $nextStmt->execute([(int)$instance['template_id'], $newStepOrder]);
                $nextStep = $nextStmt->fetch(PDO::FETCH_ASSOC);

                $updStmt = $pdo->prepare("
                    UPDATE tblworkflow_instance
                    SET current_step_order = ?, status = 'IN_PROGRESS', updated_at = NOW()
                    WHERE id = ?
                ");
                $updStmt->execute([$newStepOrder, $instanceId]);

                return [
                    'success'   => true,
                    'new_step'  => $newStepOrder,
                    'status'    => 'IN_PROGRESS',
                    'completed' => false,
                    'next_step' => $nextStep ?: null,
                ];
            }

            // 4. REJECTED / RETURNED → back to teacher (step 1).
            if (!(int)$currentStep['can_reject']) {
                return [
                    'success' => false,
                    'message' => "This step ({$currentStep['step_label']}) does not allow rejection.",
                    'status'  => $status,
                ];
            }

            wfLogAction(
                $pdo,
                $instanceId,
                $currentStepOrder,
                $actorUserId,
                $actorRoleId,
                $logPosition,
                $action,
                $remarks
            );

            $updStmt = $pdo->prepare("
                UPDATE tblworkflow_instance
                SET status = 'REJECTED', current_step_order = 1, updated_at = NOW()
                WHERE id = ?
            ");
            $updStmt->execute([$instanceId]);

            return [
                'success'   => true,
                'new_step'  => 1,
                'status'    => 'REJECTED',
                'completed' => false,
                'next_step' => null,
            ];
        } catch (Throwable $e) {
            return ['success' => false, 'message' => 'Workflow advance failed: ' . $e->getMessage()];
        }
    }
}

if (!function_exists('rejectWorkflow')) {
    /**
     * Shortcut: advanceWorkflow with action = 'REJECTED'.
     */
    function rejectWorkflow(PDO $pdo, array $params): array
    {
        $params['action'] = 'REJECTED';
        return advanceWorkflow($pdo, $params);
    }
}

if (!function_exists('getCurrentStep')) {
    /**
     * Current step row for a workflow instance
     * (instance -> current_step_order -> tblworkflow_step).
     *
     * @return array|null Step row (with instance context) or null.
     */
    function getCurrentStep(PDO $pdo, int $instanceId): ?array
    {
        try {
            $stmt = $pdo->prepare("
                SELECT ws.*, wi.id AS instance_id, wi.status AS instance_status,
                       wi.template_id AS instance_template_id,
                       wi.current_step_order AS instance_current_step_order
                FROM tblworkflow_instance wi
                INNER JOIN tblworkflow_step ws
                        ON ws.template_id = wi.template_id
                       AND ws.step_order = wi.current_step_order
                WHERE wi.id = ?
                LIMIT 1
            ");
            $stmt->execute([$instanceId]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row ?: null;
        } catch (Throwable $e) {
            return null;
        }
    }
}

if (!function_exists('getPendingForPosition')) {
    /**
     * All IN_PROGRESS workflow instances currently waiting on the given
     * position (Adviser / Subject Coordinator / Principal / Registrar).
     * Used by role dashboards. Includes section / subject / teacher info.
     *
     * @return array[] Instance rows.
     */
    function getPendingForPosition(
        PDO $pdo,
        string $position,
        int $academicYearId,
        int $termId = 0,
        int $teacherId = 0
    ): array
    {
        try {
            $sql = "
                SELECT wi.id AS instance_id,
                       wi.section_id, wi.subject_id, wi.term_id,
                       wi.academic_year_id, wi.teacher_id, wi.template_id,
                       wi.current_step_order, wi.status, wi.submitted_at,
                       ws.id AS step_id, ws.step_label, ws.required_position,
                       ws.action_type, ws.allow_mark_checked,
                       s.section_name, s.section_code, s.grade_level_id,
                       gl.grade_level_name,
                       sub.subject_code, sub.subject_name,
                       CONCAT_WS(' ', t.fname, t.lname) AS teacher_name
                FROM tblworkflow_instance wi
                INNER JOIN tblworkflow_step ws
                        ON ws.template_id = wi.template_id
                       AND ws.step_order = wi.current_step_order
                LEFT JOIN tblsection s    ON s.id = wi.section_id
                LEFT JOIN tblgradelevel gl ON gl.id = s.grade_level_id
                LEFT JOIN tblsubjects sub ON sub.id = wi.subject_id
                LEFT JOIN tblteacher t    ON t.id = wi.teacher_id
                WHERE wi.status = 'IN_PROGRESS'
                  AND wi.academic_year_id = ?
                  AND (
                      (
                          ws.required_position = ?
                          AND (
                              ? = 0
                              OR ws.required_position <> 'Adviser'
                              OR EXISTS (
                                  SELECT 1
                                  FROM tblsectionadviser assigned_adviser
                                  WHERE assigned_adviser.teacher_id = ?
                                    AND assigned_adviser.section_id = wi.section_id
                                    AND assigned_adviser.academic_year_id = wi.academic_year_id
                              )
                          )
                      )
                      OR (
                          ? > 0
                          AND ws.required_position = 'Adviser'
                          AND EXISTS (
                              SELECT 1
                              FROM tblsectionadviser assigned_adviser
                              WHERE assigned_adviser.teacher_id = ?
                                AND assigned_adviser.section_id = wi.section_id
                                AND assigned_adviser.academic_year_id = wi.academic_year_id
                          )
                      )
                  )
            ";
            $params = [
                $academicYearId,
                $position,
                $teacherId,
                $teacherId,
                $teacherId,
                $teacherId,
            ];

            if ($termId > 0) {
                $sql .= " AND wi.term_id = ? ";
                $params[] = $termId;
            }

            $sql .= " ORDER BY wi.submitted_at ASC, wi.id ASC ";

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);

            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {
            return []; // Tables may not exist yet — treat as "no pending items".
        }
    }
}

if (!function_exists('getReturnedForTeacher')) {
    /**
     * All REJECTED workflow instances that belong to the given teacher and
     * were sent back to them (step 1). Includes the latest rejection reason,
     * who rejected it, and when. Used by the teacher dashboard's
     * "Returned to Me" section.
     *
     * @return array[] Instance rows.
     */
    function getReturnedForTeacher(PDO $pdo, int $teacherId, int $academicYearId): array
    {
        try {
            $sql = "
                SELECT wi.id AS instance_id,
                       wi.section_id, wi.subject_id, wi.term_id,
                       wi.academic_year_id, wi.teacher_id, wi.template_id,
                       wi.current_step_order, wi.status, wi.submitted_at,
                       s.section_name, s.section_code, s.grade_level_id,
                       sub.subject_code, sub.subject_name,
                       CONCAT_WS(' ', t.fname, t.lname) AS teacher_name,
                       (
                           SELECT al.remarks
                           FROM tblworkflow_action_log al
                           WHERE al.instance_id = wi.id AND al.action = 'REJECTED'
                           ORDER BY al.id DESC LIMIT 1
                       ) AS rejection_reason,
                       (
                           SELECT CONCAT_WS(' ', t2.fname, t2.lname)
                           FROM tblworkflow_action_log al
                           LEFT JOIN tblteacher t2 ON t2.id = al.actor_user_id
                           WHERE al.instance_id = wi.id AND al.action = 'REJECTED'
                           ORDER BY al.id DESC LIMIT 1
                       ) AS rejected_by,
                       (
                           SELECT al.acted_at
                           FROM tblworkflow_action_log al
                           WHERE al.instance_id = wi.id AND al.action = 'REJECTED'
                           ORDER BY al.id DESC LIMIT 1
                       ) AS rejected_at
                FROM tblworkflow_instance wi
                LEFT JOIN tblsection s    ON s.id = wi.section_id
                LEFT JOIN tblsubjects sub ON sub.id = wi.subject_id
                LEFT JOIN tblteacher t    ON t.id = wi.teacher_id
                WHERE wi.status = 'REJECTED'
                  AND wi.teacher_id = ?
                  AND wi.academic_year_id = ?
                ORDER BY wi.submitted_at DESC, wi.id DESC
            ";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$teacherId, $academicYearId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {
            return [];
        }
    }
}
