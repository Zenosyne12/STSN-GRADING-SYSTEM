<?php
/**
 * STSN Activity Log Helper
 * 
 * Usage:
 *   logActivity($pdo, 'Students', 'CREATE', 'student', $id, 'Created student Juan Dela Cruz');
 *   logActivity($pdo, 'Students', 'UPDATE', 'student', $id, 'Updated LRN', $old, $new);
 *   logActivity($pdo, 'Auth', 'LOGIN', null, null, 'Login successful');
 */

if (!function_exists('logActivity')) {
    function logActivity(
        PDO $pdo,
        string $module,
        string $action,
        ?string $entityType = null,
        ?int $entityId = null,
        ?string $description = null,
        $oldValues = null,
        $newValues = null
    ): void {
        try {
            // Resolve current user from session (works for admin, teacher, superadmin)
            $userId   = (int)($_SESSION['user_id'] ?? $_SESSION['teacher_id'] ?? 0);
            $userName = (string)($_SESSION['username'] ?? $_SESSION['teacher_name'] ?? 'System');
            $role     = (string)($_SESSION['role_name'] ?? 'Guest');
            
            // If role_name not in session, try to resolve from role_id
            if ($role === 'Guest' && !empty($_SESSION['role_id'])) {
                try {
                    $rStmt = $pdo->prepare("SELECT role_name FROM tblrole WHERE id = ? LIMIT 1");
                    $rStmt->execute([(int)$_SESSION['role_id']]);
                    $role = (string)($rStmt->fetchColumn() ?: 'Guest');
                } catch (Throwable $e) {
                    // ignore
                }
            }
            
            // Serialize old/new values
            $oldJson = null;
            $newJson = null;
            if ($oldValues !== null) {
                $oldJson = is_string($oldValues) ? $oldValues : json_encode($oldValues, JSON_UNESCAPED_UNICODE);
            }
            if ($newValues !== null) {
                $newJson = is_string($newValues) ? $newValues : json_encode($newValues, JSON_UNESCAPED_UNICODE);
            }
            
            // IP address
            $ip = $_SERVER['REMOTE_ADDR'] ?? null;
            if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
            }
            
            // Truncate description to 500 chars
            if ($description !== null) {
                $description = mb_substr($description, 0, 500);
            }
            
            $stmt = $pdo->prepare("
                INSERT INTO tblactivity_log
                    (user_id, user_name, role, module, action,
                     entity_type, entity_id, description,
                     old_values, new_values, ip_address)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $userId ?: null,
                $userName,
                $role,
                mb_substr($module, 0, 50),
                mb_substr($action, 0, 30),
                $entityType ? mb_substr($entityType, 0, 50) : null,
                $entityId ?: null,
                $description,
                $oldJson,
                $newJson,
                $ip ? mb_substr($ip, 0, 45) : null,
            ]);
            
            // Retention: keep only latest 1000
            $count = (int)$pdo->query("SELECT COUNT(*) FROM tblactivity_log")->fetchColumn();
            if ($count > 1000) {
                $excess = $count - 1000;
                $pdo->exec("
                    DELETE FROM tblactivity_log
                    ORDER BY id ASC
                    LIMIT $excess
                ");
            }
        } catch (Throwable $e) {
            // Activity log should never break the app
            error_log('logActivity failed: ' . $e->getMessage());
        }
    }
}
