<?php
/**
 * includes/grade_compute.php
 * Server-side computation helpers for the Teacher Grading Sheet.
 * Weights are HARDCODED (30/50/20) for now — dynamic weights is Phase 2.
 */

const GS_WEIGHT_WW = 30; // Written Works %
const GS_WEIGHT_PT = 50; // Performance Tasks %
const GS_WEIGHT_QA = 20; // Quarterly Assessment %

if (!function_exists('computePS')) {
    /** Percentage Score: raw total over HPS, expressed as %. */
    function computePS($total, $hps): float
    {
        $total = (float) $total;
        $hps   = (float) $hps;
        if ($hps <= 0) {
            return 0.0;
        }
        return round(($total / $hps) * 100, 2);
    }
}

if (!function_exists('computeWS')) {
    /** Weighted Score: PS x component weight%. */
    function computeWS($ps, $weightPercent): float
    {
        return round(((float) $ps) * ((float) $weightPercent / 100), 2);
    }
}

if (!function_exists('computeInitialGrade')) {
    /** Initial Grade = sum of the three Weighted Scores. */
    function computeInitialGrade($wwWS, $ptWS, $qaWS): float
    {
        return round(((float) $wwWS) + ((float) $ptWS) + ((float) $qaWS), 2);
    }
}

if (!function_exists('transmute')) {
    /**
     * DepEd ADJUSTED transmutation table for SY 2026-2027: raw 70 -> 75.
     * Simplified rule: initial < 70 stays as-is (failing);
     * otherwise final = initial + 5, capped at 100.
     */
    function transmute($initial): int
    {
        $initial = (float) $initial;
        if ($initial < 70) {
            return (int) round($initial);
        }
        return (int) min(100, round($initial + 5));
    }
}

if (!function_exists('computeRemarks')) {
    /** Descriptive remarks based on the final grade (passing = 75). */
    function computeRemarks($finalGrade, $passing = 75): string
    {
        $finalGrade = (float) $finalGrade;
        if ($finalGrade < $passing) {
            return 'Failed';
        }
        if ($finalGrade >= 90) {
            return 'Outstanding';
        }
        if ($finalGrade >= 85) {
            return 'Very Satisfactory';
        }
        if ($finalGrade >= 80) {
            return 'Satisfactory';
        }
        return 'Fairly Satisfactory';
    }
}

if (!function_exists('gsIsLockedStatus')) {
    /** Statuses that lock the grading sheet against further editing. */
    function gsIsLockedStatus(?string $status): bool
    {
        return in_array($status, [
            'pending_adviser',
            'submitted_to_adviser',
            'approved',
            'approved_by_adviser',
            'finalized',
        ], true);
    }
}

if (!function_exists('gsStatusBadge')) {
    /** [label, bootstrap-subtle classes] for a grade status. */
    function gsStatusBadge(?string $status): array
    {
        switch ($status) {
            case 'draft':
                return ['Draft', 'bg-secondary-subtle text-secondary-emphasis'];
            case 'pending_adviser':
            case 'submitted_to_adviser':
                return ['Pending Adviser', 'bg-warning-subtle text-warning-emphasis'];
            case 'approved':
            case 'approved_by_adviser':
                return ['Approved', 'bg-success-subtle text-success-emphasis'];
            case 'finalized':
                return ['Finalized', 'bg-primary-subtle text-primary-emphasis'];
            case 'returned':
                return ['Returned', 'bg-danger-subtle text-danger-emphasis'];
            default:
                return ['Not Saved', 'bg-secondary-subtle text-secondary-emphasis'];
        }
    }
}
