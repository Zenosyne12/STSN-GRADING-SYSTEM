<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($pdo)) {
    $dbConnectFile = __DIR__ . '/../api/shared/db_connect.php';
    if (file_exists($dbConnectFile)) {
        require_once $dbConnectFile;
    }
}

$userName = 'Guest';
$userRole = '';
$userId = (int) ($_SESSION['user_id'] ?? 0);
$memberSince = '';

if ($userId > 0 && isset($pdo)) {
    try {
        $stmt = $pdo->prepare(
            'SELECT u.id, u.username, u.status, u.created_at, r.role_name
             FROM tblusers u
             LEFT JOIN tblrole r ON r.id = u.role_id
             WHERE u.id = ?
             LIMIT 1'
        );
        $stmt->execute([$userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            $userName = $user['username'] ?? 'User';
            $userRole = $user['role_name'] ?? '';
            $memberSince = !empty($user['created_at'])
                ? date('M. Y', strtotime($user['created_at']))
                : '';
        }
    } catch (PDOException $e) {
        error_log('Header User Fetch Error: ' . $e->getMessage());
    }
}

if (!function_exists('getInitials')) {
    function getInitials(string $name): string
    {
        $initials = '';
        $parts = preg_split('/[\s._-]+/', $name);
        foreach ($parts as $part) {
            if ($part !== '') {
                $initials .= strtoupper($part[0]);
            }
        }
        return substr($initials, 0, 2) ?: 'U';
    }
}
?>
<?php require_once __DIR__ . '/theme_head.php'; ?>
<?php
$stsnHdrBase = isset($stsnAssetBase) ? $stsnAssetBase : '';
$stsnHdrRoot = isset($stsnProjectRoot) ? $stsnProjectRoot : str_replace('\\', '/', (string) realpath(__DIR__ . '/..'));
$stsnShowAdminNotifications = (int) ($_SESSION['role_id'] ?? 0) === 1;
if (is_file($stsnHdrRoot . '/css/admin-responsive.css')):
?>
<link rel="stylesheet" href="<?= htmlspecialchars($stsnHdrBase) ?>css/admin-responsive.css">
<?php endif; ?>
<link rel="stylesheet" href="<?= htmlspecialchars($stsnHdrBase) ?>css/admin-animations.css">
<style>
    /* Make the nav-item host a flex container so its content is vertically centered */
    .app-header .navbar-nav > .nav-item.darkmode-nav-item {
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .header-darkmode-control {
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 34px;
        padding: 0 0.5rem;
        line-height: 1;
    }

    .header-darkmode-control .form-check {
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: center;
        gap: 0.4rem;
        margin: 0;
        padding: 0;
        min-height: 34px;
        line-height: 1;
    }

    .header-darkmode-control .form-check-input {
        width: 2rem;
        height: 1.15rem;
        margin: 0;
        float: none;
        cursor: pointer;
        background-color: #eef2f6;
        border-color: #9ba8b5;
        box-shadow: none;
        transform: none;
        position: relative;
        top: 0;
        flex-shrink: 0;
        vertical-align: middle;
    }

    .header-darkmode-control .form-check-input:checked {
        background-color: #0d6efd;
        border-color: #0d6efd;
    }

    .header-darkmode-control .form-check-label {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        margin: 0;
        padding: 0;
        cursor: pointer;
        color: var(--bs-body-color, #061b33);
        min-width: 20px;
        line-height: 1;
    }

    .header-darkmode-control .form-check-label i {
        font-size: 0.95rem;
        line-height: 1;
        display: inline-block;
        vertical-align: middle;
    }
    .header-admin-notifications {
        position: relative;
    }
    .header-admin-notifications .admin-notification-toggle {
        position: relative;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 38px;
        height: 38px;
        padding: 0;
        color: var(--bs-body-color, #061b33);
        font-size: 1.15rem;
        border: 0;
        background: transparent;
        border-radius: 50%;
    }
    .header-admin-notifications .admin-notification-toggle:hover,
    .header-admin-notifications .admin-notification-toggle:focus {
        background: rgba(18, 72, 168, 0.08);
        color: #1248a8;
    }
    .admin-notification-count {
        position: absolute;
        top: 1px;
        right: -2px;
        min-width: 17px;
        height: 17px;
        padding: 0 4px;
        border: 2px solid var(--bs-body-bg, #fff);
        border-radius: 999px;
        background: #dc3545;
        color: #fff;
        font: 700 10px/13px system-ui, sans-serif;
        text-align: center;
    }
    .admin-notification-menu {
        width: min(370px, calc(100vw - 24px));
        max-height: min(460px, calc(100vh - 80px));
        padding: 0;
        overflow: hidden;
        border: 1px solid #dce8f8;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(19, 47, 98, .18);
    }
    .admin-notification-heading {
        padding: .85rem 1rem;
        color: #132f62;
        font-weight: 700;
        border-bottom: 1px solid #e8f0fb;
    }
    .admin-notification-list {
        max-height: 380px;
        overflow-y: auto;
    }
    .admin-notification-item {
        padding: .75rem 1rem;
        white-space: normal;
        border-bottom: 1px solid #eef3fa;
    }
    .admin-notification-item:last-child { border-bottom: 0; }
    .admin-notification-title {
        color: #132f62;
        font-size: .84rem;
        font-weight: 700;
    }
    .admin-notification-message {
        margin-top: .2rem;
        color: #536985;
        font-size: .78rem;
        line-height: 1.4;
    }
    .admin-notification-time {
        margin-top: .3rem;
        color: #8aa0bb;
        font-size: .7rem;
    }
    .admin-notification-empty {
        padding: 1.6rem 1rem;
        color: #8aa0bb;
        text-align: center;
        font-size: .82rem;
    }
    [data-bs-theme="dark"] .header-admin-notifications .admin-notification-toggle {
        color: #e4e6e8;
    }
    [data-bs-theme="dark"] .header-admin-notifications .admin-notification-toggle:hover,
    [data-bs-theme="dark"] .header-admin-notifications .admin-notification-toggle:focus {
        background: rgba(138, 180, 248, .14);
        color: #8ab4f8;
    }
    [data-bs-theme="dark"] .admin-notification-menu {
        background: #2d2d2d !important;
        border-color: #454545 !important;
        box-shadow: 0 10px 30px rgba(0, 0, 0, .45);
    }
    [data-bs-theme="dark"] .admin-notification-heading {
        color: #f1f3f5;
        border-bottom-color: #454545;
    }
    [data-bs-theme="dark"] .admin-notification-item {
        border-bottom-color: #404040;
    }
    [data-bs-theme="dark"] .admin-notification-item:hover {
        background: #363636;
    }
    [data-bs-theme="dark"] .admin-notification-title {
        color: #8ab4f8;
    }
    [data-bs-theme="dark"] .admin-notification-message {
        color: #d1d5db;
    }
    [data-bs-theme="dark"] .admin-notification-time,
    [data-bs-theme="dark"] .admin-notification-empty {
        color: #a0a8b1;
    }
</style>
<nav class="app-header navbar navbar-expand bg-body">
    <div class="container-fluid">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
                    <i class="bi bi-list"></i>
                </a>
            </li>
        </ul>

        <ul class="navbar-nav ms-auto align-items-center">
            <li class="nav-item d-flex align-items-center">
                <a class="nav-link" href="#" data-lte-toggle="fullscreen">
                    <i data-lte-icon="maximize" class="bi bi-arrows-fullscreen"></i>
                    <i data-lte-icon="minimize" class="bi bi-fullscreen-exit" style="display:none"></i>
                </a>
            </li>

            <li class="nav-item darkmode-nav-item">
                <div class="header-darkmode-control">
                    <div class="form-check form-switch mb-0">
                        <input class="form-check-input" type="checkbox" role="switch" id="headerDarkModeToggle">
                        <label class="form-check-label" for="headerDarkModeToggle">
                            <i id="headerDarkModeIcon" class="bi bi-moon-stars-fill"></i>
                        </label>
                    </div>
                </div>
            </li>

            <?php if ($stsnShowAdminNotifications): ?>
                <li class="nav-item dropdown header-admin-notifications"
                    id="headerAdminNotifications"
                    data-feed-url="<?= htmlspecialchars($stsnHdrBase . 'api/notifications/admin_feed.php', ENT_QUOTES, 'UTF-8') ?>"
                    data-user-id="<?= $userId ?>">
                    <button class="admin-notification-toggle"
                            type="button"
                            id="headerAdminNotificationsToggle"
                            data-bs-toggle="dropdown"
                            data-bs-auto-close="outside"
                            aria-expanded="false"
                            aria-label="Admin notifications">
                        <i class="bi bi-bell"></i>
                        <span class="admin-notification-count" id="headerAdminNotificationCount" hidden></span>
                    </button>
                    <div class="dropdown-menu dropdown-menu-end admin-notification-menu"
                         aria-labelledby="headerAdminNotificationsToggle">
                        <div class="admin-notification-heading">
                            <i class="bi bi-bell-fill me-2"></i>Notifications
                        </div>
                        <div class="admin-notification-list" id="headerAdminNotificationList">
                            <div class="admin-notification-empty">Loading notifications...</div>
                        </div>
                    </div>
                </li>
            <?php endif; ?>

            <li class="nav-item dropdown user-menu d-flex align-items-center">
                <a href="#" class="nav-link dropdown-toggle d-flex align-items-center" data-bs-toggle="dropdown">
                    <span id="headerNavInitials"
                          class="user-image rounded-circle shadow d-inline-flex align-items-center justify-content-center"
                          style="width:25px;height:25px;background:linear-gradient(135deg,#0b3d91 0%,#1457b8 52%,#1d75e8 100%);color:#fff;font-size:11px;font-weight:700;">
                        <?= getInitials($userName) ?>
                    </span>
                    <span class="d-none d-md-inline ms-1"><?= htmlspecialchars($userName) ?></span>
                </a>

                <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-end">
                    <li class="user-header text-bg-secondary"
                        style="background:linear-gradient(135deg, #0b3d91 0%, #1457b8 52%, #1d75e8 100%) !important; border-radius:12px; padding:10px;">
                        <div class="text-decoration-none text-white" style="display:block; pointer-events:none;">
                            <div id="headerDropdownInitials"
                                 class="rounded-circle shadow d-inline-flex align-items-center justify-content-center mx-auto"
                                 style="width:90px;height:90px;background:rgba(255,255,255,0.15);border:3px solid rgba(255,255,255,0.3);color:#fff;font-size:36px;font-weight:800;">
                                <?= getInitials($userName) ?>
                            </div>
                            <p style="margin-top:10px; color:#fff;">
                                <?= htmlspecialchars($userName) ?>
                                <small style="display:block;text-align:center; color:#fff; opacity:0.85;">Since 2025</small>
                                <?php if ($userRole): ?>
                                    <small style="display:block;margin-top:4px;opacity:0.85; color:#fff;">
                                        <i class="bi bi-shield-check"></i> <?= htmlspecialchars($userRole) ?>
                                    </small>
                                <?php endif; ?>
                            </p>
                        </div>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</nav>
<?php if ($stsnShowAdminNotifications): ?>
<script>
    (function () {
        const root = document.getElementById('headerAdminNotifications');
        if (!root) return;

        const list = document.getElementById('headerAdminNotificationList');
        const badge = document.getElementById('headerAdminNotificationCount');
        const seenKey = 'stsn_admin_notifications_seen_' + root.dataset.userId;
        let notifications = [];
        let latestId = 0;
        let isOpen = false;

        function escapeNotification(value) {
            return String(value ?? '').replace(/[&<>"']/g, character => ({
                '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
            }[character]));
        }

        function getSeenId() {
            try { return Number(localStorage.getItem(seenKey) || 0); }
            catch (error) { return 0; }
        }

        function updateBadge() {
            let unseen = notifications.filter(item => Number(item.id || 0) > getSeenId()).length;
            if (isOpen && latestId) unseen = 0;
            badge.hidden = unseen === 0;
            badge.textContent = unseen > 99 ? '99+' : String(unseen);
        }

        function renderNotifications() {
            if (!notifications.length) {
                list.innerHTML = '<div class="admin-notification-empty">No notifications yet.</div>';
                return;
            }

            list.innerHTML = notifications.map(item =>
                '<div class="admin-notification-item">'
                + '<div class="admin-notification-title">' + escapeNotification(item.title) + '</div>'
                + '<div class="admin-notification-message">' + escapeNotification(item.message) + '</div>'
                + '<div class="admin-notification-time">' + escapeNotification(item.created_at_display) + '</div>'
                + '</div>'
            ).join('');
        }

        async function loadNotifications() {
            try {
                const response = await fetch(root.dataset.feedUrl, {
                    headers: { 'Accept': 'application/json' }
                });
                const result = await response.json();
                if (!response.ok || !result.success || !Array.isArray(result.notifications)) {
                    throw new Error(result.message || 'Unable to load notifications.');
                }
                notifications = result.notifications;
                latestId = notifications.reduce((maxId, item) => Math.max(maxId, Number(item.id || 0)), 0);
                renderNotifications();
                updateBadge();
            } catch (error) {
                console.error('Unable to load admin notifications:', error);
                list.innerHTML = '<div class="admin-notification-empty">Unable to load notifications.</div>';
            }
        }

        root.addEventListener('shown.bs.dropdown', function () {
            isOpen = true;
            if (latestId) {
                try { localStorage.setItem(seenKey, String(latestId)); }
                catch (error) { console.warn('Unable to save notification read state.', error); }
            }
            updateBadge();
        });
        root.addEventListener('hidden.bs.dropdown', function () {
            isOpen = false;
            updateBadge();
        });

        loadNotifications();
        window.setInterval(function () {
            if (document.visibilityState === 'visible') loadNotifications();
        }, 15000);
    })();
</script>
<?php endif; ?>