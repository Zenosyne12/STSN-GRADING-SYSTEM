<?php
// ── STEP 1: Start session FIRST ──────────────────────────────────────────────
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ── STEP 2: Self-require db_connect if $pdo is not available ─────────────────
if (!isset($pdo)) {
    $dbConnectFile = __DIR__ . '/../api/shared/db_connect.php';
    if (file_exists($dbConnectFile)) {
        require_once $dbConnectFile;
    } else {
        $altFile = __DIR__ . '/../../api/shared/db_connect.php';
        if (file_exists($altFile)) {
            require_once $altFile;
        }
    }
}

// ── STEP 3: Fetch user data ──────────────────────────────────────────────────
$userName    = 'Guest';
$userRole    = '';
$userAvatar  = '';
$userId      = (int)($_SESSION['user_id'] ?? 0);
$memberSince = '';

if ($userId > 0 && isset($pdo)) {
    try {
        $stmt = $pdo->prepare("
            SELECT u.username, u.status, u.created_at, r.role_name
            FROM tblusers u
            LEFT JOIN tblrole r ON r.id = u.role_id
            WHERE u.id = ?
            LIMIT 1
        ");
        $stmt->execute([$userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            $userName    = $user['username'] ?? 'User';
            $userRole    = $user['role_name'] ?? '';
            $memberSince = !empty($user['created_at'])
                ? date('M. Y', strtotime($user['created_at']))
                : '';

            $docRoot   = rtrim($_SERVER['DOCUMENT_ROOT'], '/\\');
            $avatarPng = $docRoot . '/assets/img/' . $userName . '.png';
            $avatarJpg = $docRoot . '/assets/img/' . $userName . '.jpg';

            if (file_exists($avatarPng)) {
                $userAvatar = './assets/img/' . $userName . '.png';
            } elseif (file_exists($avatarJpg)) {
                $userAvatar = './assets/img/' . $userName . '.jpg';
            }
        }
    } catch (PDOException $e) {
        error_log('Header User Fetch Error: ' . $e->getMessage());
    }
}

$hasAvatar = $userAvatar !== '';

if (!function_exists('getInitials')) {
    function getInitials(string $name): string {
        $initials = '';
        $parts    = preg_split('/[\s._-]+/', $name);
        foreach ($parts as $part) {
            if ($part !== '') {
                $initials .= strtoupper($part[0]);
            }
        }
        return substr($initials, 0, 2) ?: 'U';
    }
}
?>
<nav class="app-header navbar navbar-expand bg-body">
    <div class="container-fluid">

        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
                    <i class="bi bi-list"></i>
                </a>
            </li>
        </ul>

        <ul class="navbar-nav ms-auto">
            <li class="nav-item">
                <a class="nav-link" href="#" data-lte-toggle="fullscreen">
                    <i data-lte-icon="maximize" class="bi bi-arrows-fullscreen"></i>
                    <i data-lte-icon="minimize" class="bi bi-fullscreen-exit" style="display:none"></i>
                </a>
            </li>

            <li class="nav-item dropdown user-menu">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <?php if ($hasAvatar): ?>
                        <img src="<?= htmlspecialchars($userAvatar) ?>"
                             class="user-image rounded-circle shadow"
                             alt="<?= htmlspecialchars($userName) ?>">
                    <?php else: ?>
                        <span class="user-image rounded-circle shadow d-inline-flex align-items-center justify-content-center"
                              style="width:25px;height:25px;background:linear-gradient(135deg,#0A2F44,#1a4a6b);color:#fff;font-size:11px;font-weight:700;">
                            <?= getInitials($userName) ?>
                        </span>
                    <?php endif; ?>
                    <span class="d-none d-md-inline"><?= htmlspecialchars($userName) ?></span>
                </a>

                <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-end">
                    <li class="user-header text-bg-secondary"
                        style="background:linear-gradient(135deg,#0A2F44 0%,#1a4a6b 100%) !important;">
                        <?php if ($hasAvatar): ?>
                            <img src="<?= htmlspecialchars($userAvatar) ?>"
                                 class="rounded-circle shadow"
                                 alt="<?= htmlspecialchars($userName) ?>"
                                 style="width:90px;height:90px;object-fit:cover;border:3px solid rgba(255,255,255,0.3);">
                        <?php else: ?>
                            <div class="rounded-circle shadow d-inline-flex align-items-center justify-content-center mx-auto"
                                 style="width:90px;height:90px;background:rgba(255,255,255,0.15);border:3px solid rgba(255,255,255,0.3);color:#fff;font-size:36px;font-weight:800;">
                                <?= getInitials($userName) ?>
                            </div>
                        <?php endif; ?>
                        <p style="margin-top:10px;">
                            <?= htmlspecialchars($userName) ?>
                            <?php if ($memberSince): ?>
                                <small>Member since <?= $memberSince ?></small>
                            <?php endif; ?>
                            <?php if ($userRole): ?>
                                <small style="display:block;margin-top:4px;opacity:0.85;">
                                    <i class="bi bi-shield-check"></i> <?= htmlspecialchars($userRole) ?>
                                </small>
                            <?php endif; ?>
                        </p>
                    </li>

                    <li class="user-footer">
                        <a href="admin-profile.php" class="btn btn-default btn-flat">
                            <i class="bi bi-person-circle"></i> Profile
                        </a>
                        <a href="api/login/logout.php" class="btn btn-default btn-flat float-end">
                            <i class="bi bi-box-arrow-right"></i> Sign out
                        </a>
                    </li>
                </ul>
            </li>
        </ul>

    </div>
</nav>