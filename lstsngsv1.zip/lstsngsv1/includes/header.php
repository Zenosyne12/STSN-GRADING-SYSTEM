<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($pdo)) {
    $dbConnectFile = __DIR__ . '/../api/shared/db_connect.php';
    if (file_exists($dbConnectFile)) {
        require_once $dbConnectFile;
    }
}

$userName = 'Guest';
$userRole = '';
$userId = (int) ($_SESSION['user_id'] ?? 0);
$memberSince = '';

if ($userId > 0 && isset($pdo)) {
    try {
        $stmt = $pdo->prepare(
            'SELECT u.id, u.username, u.status, u.created_at, r.role_name
             FROM tblusers u
             LEFT JOIN tblrole r ON r.id = u.role_id
             WHERE u.id = ?
             LIMIT 1'
        );
        $stmt->execute([$userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            $userName = $user['username'] ?? 'User';
            $userRole = $user['role_name'] ?? '';
            $memberSince = !empty($user['created_at'])
                ? date('M. Y', strtotime($user['created_at']))
                : '';
        }
    } catch (PDOException $e) {
        error_log('Header User Fetch Error: ' . $e->getMessage());
    }
}

if (!function_exists('getInitials')) {
    function getInitials(string $name): string
    {
        $initials = '';
        $parts = preg_split('/[\s._-]+/', $name);
        foreach ($parts as $part) {
            if ($part !== '') {
                $initials .= strtoupper($part[0]);
            }
        }
        return substr($initials, 0, 2) ?: 'U';
    }
}
?>
<?php require_once __DIR__ . '/theme_head.php'; ?>
<?php
$stsnHdrBase = isset($stsnAssetBase) ? $stsnAssetBase : '';
$stsnHdrRoot = isset($stsnProjectRoot) ? $stsnProjectRoot : str_replace('\\', '/', (string) realpath(__DIR__ . '/..'));
if (is_file($stsnHdrRoot . '/css/admin-responsive.css')):
?>
<link rel="stylesheet" href="<?= htmlspecialchars($stsnHdrBase) ?>css/admin-responsive.css">
<?php endif; ?>
<link rel="stylesheet" href="<?= htmlspecialchars($stsnHdrBase) ?>css/admin-animations.css">
<style>
    /* Make the nav-item host a flex container so its content is vertically centered */
    .app-header .navbar-nav > .nav-item.darkmode-nav-item {
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .header-darkmode-control {
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 34px;
        padding: 0 0.5rem;
        line-height: 1;
    }

    .header-darkmode-control .form-check {
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: center;
        gap: 0.4rem;
        margin: 0;
        padding: 0;
        min-height: 34px;
        line-height: 1;
    }

    .header-darkmode-control .form-check-input {
        width: 2rem;
        height: 1.15rem;
        margin: 0;
        float: none;
        cursor: pointer;
        background-color: #eef2f6;
        border-color: #9ba8b5;
        box-shadow: none;
        transform: none;
        position: relative;
        top: 0;
        flex-shrink: 0;
        vertical-align: middle;
    }

    .header-darkmode-control .form-check-input:checked {
        background-color: #0d6efd;
        border-color: #0d6efd;
    }

    .header-darkmode-control .form-check-label {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        margin: 0;
        padding: 0;
        cursor: pointer;
        color: var(--bs-body-color, #061b33);
        min-width: 20px;
        line-height: 1;
    }

    .header-darkmode-control .form-check-label i {
        font-size: 0.95rem;
        line-height: 1;
        display: inline-block;
        vertical-align: middle;
    }
</style>
<nav class="app-header navbar navbar-expand bg-body">
    <div class="container-fluid">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
                    <i class="bi bi-list"></i>
                </a>
            </li>
        </ul>

        <ul class="navbar-nav ms-auto align-items-center">
            <li class="nav-item d-flex align-items-center">
                <a class="nav-link" href="#" data-lte-toggle="fullscreen">
                    <i data-lte-icon="maximize" class="bi bi-arrows-fullscreen"></i>
                    <i data-lte-icon="minimize" class="bi bi-fullscreen-exit" style="display:none"></i>
                </a>
            </li>

            <li class="nav-item darkmode-nav-item">
                <div class="header-darkmode-control">
                    <div class="form-check form-switch mb-0">
                        <input class="form-check-input" type="checkbox" role="switch" id="headerDarkModeToggle">
                        <label class="form-check-label" for="headerDarkModeToggle">
                            <i id="headerDarkModeIcon" class="bi bi-moon-stars-fill"></i>
                        </label>
                    </div>
                </div>
            </li>

            <li class="nav-item dropdown user-menu d-flex align-items-center">
                <a href="#" class="nav-link dropdown-toggle d-flex align-items-center" data-bs-toggle="dropdown">
                    <span id="headerNavInitials"
                          class="user-image rounded-circle shadow d-inline-flex align-items-center justify-content-center"
                          style="width:25px;height:25px;background:linear-gradient(135deg,#0b3d91 0%,#1457b8 52%,#1d75e8 100%);color:#fff;font-size:11px;font-weight:700;">
                        <?= getInitials($userName) ?>
                    </span>
                    <span class="d-none d-md-inline ms-1"><?= htmlspecialchars($userName) ?></span>
                </a>

                <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-end">
                    <li class="user-header text-bg-secondary"
                        style="background:linear-gradient(135deg, #0b3d91 0%, #1457b8 52%, #1d75e8 100%) !important; border-radius:12px; padding:10px;">
                        <div class="text-decoration-none text-white" style="display:block; pointer-events:none;">
                            <div id="headerDropdownInitials"
                                 class="rounded-circle shadow d-inline-flex align-items-center justify-content-center mx-auto"
                                 style="width:90px;height:90px;background:rgba(255,255,255,0.15);border:3px solid rgba(255,255,255,0.3);color:#fff;font-size:36px;font-weight:800;">
                                <?= getInitials($userName) ?>
                            </div>
                            <p style="margin-top:10px; color:#fff;">
                                <?= htmlspecialchars($userName) ?>
                                <small style="display:block;text-align:center; color:#fff; opacity:0.85;">Since 2025</small>
                                <?php if ($userRole): ?>
                                    <small style="display:block;margin-top:4px;opacity:0.85; color:#fff;">
                                        <i class="bi bi-shield-check"></i> <?= htmlspecialchars($userRole) ?>
                                    </small>
                                <?php endif; ?>
                            </p>
                        </div>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</nav>