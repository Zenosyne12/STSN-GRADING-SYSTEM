<footer class="app-footer bg-secondary-subtle" data-bs-theme="light">
        <!--begin::To the end-->
        <div class="float-end d-none d-sm-inline">Grading System</div>
        <!--end::To the end-->
        <!--begin::Copyright-->
        <strong>
          Copyright &copy; 2014-2025&nbsp;
          <a href="https://www.facebook.com/lukenazaren.sanjose/" class="text-decoration-none">Nazaren </a>.
        </strong>
        STSN GRADING SYSTEM
        <!--end::Copyright-->
      </footer>