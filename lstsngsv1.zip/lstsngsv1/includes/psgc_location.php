<?php

function ensurePsgcLocationCache(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS tblpsgc_location_cache (
            location_type ENUM('REGION', 'PROVINCE', 'CITY', 'BARANGAY') NOT NULL,
            psgc_code VARCHAR(16) NOT NULL,
            parent_code VARCHAR(16) NOT NULL,
            local_id INT NOT NULL,
            location_name VARCHAR(150) NOT NULL,
            postal_code VARCHAR(20) NULL,
            cached_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (location_type, psgc_code),
            KEY idx_psgc_location_parent (location_type, parent_code, cached_at),
            KEY idx_psgc_location_local (location_type, local_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS tblpsgc_location_cache_state (
            location_type ENUM('REGION', 'PROVINCE', 'CITY', 'BARANGAY') NOT NULL,
            parent_code VARCHAR(16) NOT NULL,
            synced_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (location_type, parent_code)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
}

function fetchPsgcLocationData(string $path): array
{
    $url = 'https://psgc.gitlab.io/api/' . ltrim($path, '/');
    $curl = curl_init($url);
    curl_setopt_array($curl, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 4,
        CURLOPT_TIMEOUT => 12,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTPHEADER => ['Accept: application/json'],
        CURLOPT_USERAGENT => 'STSN-Grading-System/1.0',
    ]);
    $body = curl_exec($curl);
    $status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $error = curl_error($curl);
    curl_close($curl);

    if (!is_string($body) || $status !== 200) {
        throw new RuntimeException('PSGC API request failed' . ($error !== '' ? ': ' . $error : '.'));
    }

    $items = json_decode($body, true);
    if (!is_array($items) || array_values($items) !== $items) {
        throw new RuntimeException('PSGC API returned invalid location data.');
    }

    return $items;
}

function psgcLocationNameKeys(string $name): array
{
    $name = strtolower(trim($name));
    $name = preg_replace('/\([^)]*\)/u', ' ', $name) ?? $name;
    $name = preg_replace('/\b(city|municipality|municipal|of|the|pob\.?)\b/u', ' ', $name) ?? $name;
    $name = preg_replace('/[^a-z0-9]+/u', '', $name) ?? $name;
    $keys = [$name];

    if (str_ends_with($name, 'region')) {
        $keys[] = substr($name, 0, -6);
    }
    if (str_starts_with($name, 'region')) {
        $keys[] = substr($name, 6);
    }

    return array_values(array_unique(array_filter($keys)));
}

function findPsgcLocalLocation(PDO $pdo, string $type, int $parentId, array $names): ?array
{
    $config = [
        'REGION' => ['table' => 'tblregion', 'id' => 'id', 'name' => 'region_name', 'parent' => 'country_id'],
        'PROVINCE' => ['table' => 'tblprovince', 'id' => 'id', 'name' => 'province_name', 'parent' => 'region_id'],
        'CITY' => ['table' => 'tblcity', 'id' => 'id', 'name' => 'city_name', 'parent' => 'province_id'],
        'BARANGAY' => ['table' => 'tblbarangay', 'id' => 'id', 'name' => 'barangay_name', 'parent' => 'city_id'],
    ];
    $table = $config[$type];
    $stmt = $pdo->prepare(sprintf(
        'SELECT `%s` AS id, `%s` AS name FROM `%s` WHERE `%s` = ? ORDER BY id',
        $table['id'],
        $table['name'],
        $table['table'],
        $table['parent']
    ));
    $stmt->execute([$parentId]);
    $localRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $remoteKeys = [];
    foreach ($names as $name) {
        foreach (psgcLocationNameKeys((string) $name) as $key) {
            $remoteKeys[$key] = true;
        }
    }

    foreach ($localRows as $row) {
        foreach (psgcLocationNameKeys((string) $row['name']) as $localKey) {
            if (isset($remoteKeys[$localKey])) {
                return $row;
            }
        }
    }

    if ($type === 'REGION' && in_array('barmm', $remoteKeys, true)) {
        foreach ($localRows as $row) {
            $localName = strtolower((string) $row['name']);
            if (str_contains($localName, 'armm') || str_contains($localName, 'bangsamoro')) {
                return $row;
            }
        }
    }

    return null;
}

function psgcCachedLocationId(PDO $pdo, string $type, string $code): ?int
{
    $stmt = $pdo->prepare("
        SELECT local_id FROM tblpsgc_location_cache
        WHERE location_type = ? AND psgc_code = ?
        LIMIT 1
    ");
    $stmt->execute([$type, $code]);
    $id = $stmt->fetchColumn();
    return $id === false ? null : (int) $id;
}

function psgcFreshLocationOptions(PDO $pdo, string $type, string $parentCode): ?array
{
    $state = $pdo->prepare("
        SELECT synced_at
        FROM tblpsgc_location_cache_state
        WHERE location_type = ? AND parent_code = ?
          AND synced_at >= CURRENT_TIMESTAMP - INTERVAL 1 DAY
        LIMIT 1
    ");
    $state->execute([$type, $parentCode]);
    if ($state->fetchColumn() === false) {
        return null;
    }

    $stmt = $pdo->prepare("
        SELECT local_id AS id, location_name AS name, postal_code
        FROM tblpsgc_location_cache
        WHERE location_type = ? AND parent_code = ?
        ORDER BY location_name
    ");
    $stmt->execute([$type, $parentCode]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function psgcParentCode(PDO $pdo, string $type, int $localId): ?string
{
    $stmt = $pdo->prepare("
        SELECT psgc_code FROM tblpsgc_location_cache
        WHERE location_type = ? AND local_id = ?
        ORDER BY cached_at DESC
        LIMIT 1
    ");
    $stmt->execute([$type, $localId]);
    $code = $stmt->fetchColumn();
    return $code === false ? null : (string) $code;
}

function psgcSaveLocationMapping(
    PDO $pdo,
    string $type,
    string $code,
    string $parentCode,
    int $localId,
    string $name,
    ?string $postalCode = null
): void {
    $stmt = $pdo->prepare("
        INSERT INTO tblpsgc_location_cache
            (location_type, psgc_code, parent_code, local_id, location_name, postal_code, cached_at)
        VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        ON DUPLICATE KEY UPDATE
            parent_code = VALUES(parent_code),
            local_id = VALUES(local_id),
            location_name = VALUES(location_name),
            postal_code = COALESCE(VALUES(postal_code), postal_code),
            cached_at = CURRENT_TIMESTAMP
    ");
    $stmt->execute([$type, $code, $parentCode, $localId, $name, $postalCode]);
}

function psgcLocalLocationRows(PDO $pdo, string $type, int $parentId): array
{
    $config = [
        'REGION' => ['table' => 'tblregion', 'name' => 'region_name', 'parent' => 'country_id'],
        'PROVINCE' => ['table' => 'tblprovince', 'name' => 'province_name', 'parent' => 'region_id'],
        'CITY' => ['table' => 'tblcity', 'name' => 'city_name', 'parent' => 'province_id'],
        'BARANGAY' => ['table' => 'tblbarangay', 'name' => 'barangay_name', 'parent' => 'city_id'],
    ];
    $table = $config[$type];
    $stmt = $pdo->prepare(sprintf(
        'SELECT id, `%s` AS name%s FROM `%s` WHERE `%s` = ? ORDER BY `%s`',
        $table['name'],
        $type === 'BARANGAY' ? ', postal_code' : '',
        $table['table'],
        $table['parent'],
        $table['name']
    ));
    $stmt->execute([$parentId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getPsgcLocationOptions(PDO $pdo, string $type, int $parentId): array
{
    ensurePsgcLocationCache($pdo);

    $type = strtoupper($type);
    $configs = [
        'REGION' => ['table' => 'tblregion', 'name' => 'region_name', 'parent' => 'country_id'],
        'PROVINCE' => ['table' => 'tblprovince', 'name' => 'province_name', 'parent' => 'region_id'],
        'CITY' => ['table' => 'tblcity', 'name' => 'city_name', 'parent' => 'province_id'],
        'BARANGAY' => ['table' => 'tblbarangay', 'name' => 'barangay_name', 'parent' => 'city_id'],
    ];
    if (!isset($configs[$type]) || $parentId <= 0) {
        throw new InvalidArgumentException('A valid location level and parent ID are required.');
    }
    $config = $configs[$type];

    $parentCode = null;
    $apiPath = '';
    if ($type === 'REGION') {
        $parentCode = 'PH';
        $apiPath = 'regions/';
    } elseif ($type === 'PROVINCE') {
        $parentCode = psgcParentCode($pdo, 'REGION', $parentId);
        if ($parentCode !== null) {
            $apiPath = 'regions/' . rawurlencode($parentCode) . '/provinces/';
        }
    } elseif ($type === 'CITY') {
        $parentCode = psgcParentCode($pdo, 'PROVINCE', $parentId);
        if ($parentCode !== null) {
            $apiPath = 'provinces/' . rawurlencode($parentCode) . '/cities-municipalities/';
        } else {
            $regionStmt = $pdo->prepare('SELECT region_id FROM tblprovince WHERE id = ? LIMIT 1');
            $regionStmt->execute([$parentId]);
            $regionId = (int) $regionStmt->fetchColumn();
            $regionCode = $regionId > 0 ? psgcParentCode($pdo, 'REGION', $regionId) : null;
            if ($regionCode !== null) {
                $parentCode = $regionCode;
                $apiPath = 'regions/' . rawurlencode($regionCode) . '/cities-municipalities/';
            }
        }
    } else {
        $parentCode = psgcParentCode($pdo, 'CITY', $parentId);
        if ($parentCode !== null) {
            $apiPath = 'cities-municipalities/' . rawurlencode($parentCode) . '/barangays/';
        }
    }

    $remoteItems = null;
    $remoteItemsFetched = false;
    if ($parentCode !== null && $apiPath !== '') {
        $cachedItems = psgcFreshLocationOptions($pdo, $type, $parentCode);
        if ($cachedItems !== null) {
            if ($cachedItems !== []) {
                return ['items' => $cachedItems, 'source' => 'psgc_cache'];
            }
            $remoteItems = [];
        } else {
            try {
                $remoteItems = fetchPsgcLocationData($apiPath);
                $remoteItemsFetched = true;
            } catch (Throwable $e) {
                error_log('[psgc_location] PSGC lookup failed; using local cache: ' . $e->getMessage());
            }
        }

        if ($remoteItemsFetched) {
            $pdo->beginTransaction();
            try {
                foreach ($remoteItems as $item) {
                    if (!is_array($item) || empty($item['code']) || empty($item['name'])) {
                        continue;
                    }
                    $code = (string) $item['code'];
                    $name = (string) $item['name'];
                    $itemParentCode = match ($type) {
                        'REGION' => 'PH',
                        'PROVINCE' => (string) ($item['regionCode'] ?? ''),
                        'CITY' => (string) (($item['provinceCode'] ?? '') ?: ($item['regionCode'] ?? '')),
                        'BARANGAY' => (string) (($item['municipalityCode'] ?? '') ?: ($item['cityCode'] ?? '')),
                    };

                    if ($type === 'REGION') {
                        $localParentId = $parentId;
                        $matchNames = array_filter([$name, (string) ($item['regionName'] ?? '')]);
                    } elseif ($type === 'PROVINCE') {
                        $localParentId = $parentId;
                        $matchNames = [$name];
                    } elseif ($type === 'CITY') {
                        if (!empty($item['provinceCode'])) {
                            $localParentId = psgcCachedLocationId($pdo, 'PROVINCE', (string) $item['provinceCode']);
                        } else {
                            $regionCode = (string) ($item['regionCode'] ?? $parentCode);
                            $regionId = psgcCachedLocationId($pdo, 'REGION', $regionCode);
                            $localParentId = $regionId === null ? null : $parentId;
                        }
                        $matchNames = [$name];
                    } else {
                        $remoteCityCode = (string) (($item['municipalityCode'] ?? '') ?: ($item['cityCode'] ?? ''));
                        $localParentId = psgcCachedLocationId($pdo, 'CITY', $remoteCityCode);
                        $matchNames = [$name];
                    }

                    if (!isset($localParentId) || $localParentId === null) {
                        continue;
                    }

                    $local = findPsgcLocalLocation($pdo, $type, (int) $localParentId, $matchNames);
                    if ($local) {
                        $localId = (int) $local['id'];
                    } else {
                        $insert = $pdo->prepare(sprintf(
                            'INSERT INTO `%s` (`%s`, `%s`%s) VALUES (?, ?%s)',
                            $config['table'],
                            $config['name'],
                            $config['parent'],
                            $type === 'BARANGAY' ? ', postal_code' : '',
                            $type === 'BARANGAY' ? ', NULL' : ''
                        ));
                        $insert->execute([$name, (int) $localParentId]);
                        $localId = (int) $pdo->lastInsertId();
                    }

                    $postalCode = null;
                    if ($type === 'BARANGAY') {
                        $postalStmt = $pdo->prepare('SELECT postal_code FROM tblbarangay WHERE id = ? LIMIT 1');
                        $postalStmt->execute([$localId]);
                        $postalCode = $postalStmt->fetchColumn();
                        $postalCode = $postalCode === false ? null : (string) $postalCode;
                    }
                    psgcSaveLocationMapping($pdo, $type, $code, $itemParentCode, $localId, $name, $postalCode);
                    unset($localParentId);
                }
                $syncState = $pdo->prepare("
                    INSERT INTO tblpsgc_location_cache_state (location_type, parent_code, synced_at)
                    VALUES (?, ?, CURRENT_TIMESTAMP)
                    ON DUPLICATE KEY UPDATE synced_at = CURRENT_TIMESTAMP
                ");
                $syncState->execute([$type, $parentCode]);
                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                throw $e;
            }
        }
    }

    if (is_array($remoteItems) && $remoteItems !== []) {
        $items = [];
        foreach ($remoteItems as $item) {
            if (!is_array($item) || empty($item['code'])) {
                continue;
            }
            if ($type === 'CITY' && empty($item['provinceCode'])) {
                $regionStmt = $pdo->prepare('SELECT region_id FROM tblprovince WHERE id = ? LIMIT 1');
                $regionStmt->execute([$parentId]);
                $regionId = (int) $regionStmt->fetchColumn();
                $remoteRegionId = psgcCachedLocationId($pdo, 'REGION', (string) ($item['regionCode'] ?? ''));
                if ($remoteRegionId !== $regionId) {
                    continue;
                }
            }
            $localId = psgcCachedLocationId($pdo, $type, (string) $item['code']);
            if ($localId === null) {
                continue;
            }
            $optionName = (string) ($item['name'] ?? '');
            $option = ['id' => $localId, 'name' => $optionName];
            if ($type === 'BARANGAY') {
                $stmt = $pdo->prepare('SELECT postal_code FROM tblbarangay WHERE id = ? LIMIT 1');
                $stmt->execute([$localId]);
                $option['postal_code'] = $stmt->fetchColumn() ?: '';
            }
            $items[] = $option;
        }
        if ($items !== []) {
            return ['items' => $items, 'source' => 'psgc'];
        }
    }

    $items = psgcLocalLocationRows($pdo, $type, $parentId);
    if ($items === []) {
        throw new RuntimeException('No locations are available from the PSGC API or local cache.');
    }

    return ['items' => $items, 'source' => 'local_cache'];
}
