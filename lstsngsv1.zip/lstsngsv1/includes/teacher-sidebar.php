<?php
require_once __DIR__ . '/theme_head.php';
require_once __DIR__ . '/teacher_modules.php';
$currentPage = basename($_SERVER['PHP_SELF']);
$sidebarCollapsed = isset($_COOKIE['stsn_sidebar_collapsed']) && $_COOKIE['stsn_sidebar_collapsed'] === '1';

// --- Assignment-based module visibility (see includes/teacher_modules.php) ---
$sidebarTeacherId = (int) ($_SESSION['teacher_id'] ?? 0);
$sidebarYearId = 0;
if (isset($pdo)) {
    try {
        $sidebarYearStmt = $pdo->query("SELECT id FROM tblacademicyear WHERE is_active = 1 ORDER BY id DESC LIMIT 1");
        $sidebarYearId = (int) ($sidebarYearStmt ? $sidebarYearStmt->fetchColumn() : 0);
    } catch (Throwable $e) {
        $sidebarYearId = 0;
    }
}
$teacherModules = [
    'show_kinder'     => false,
    'show_approvals'  => false,
    'show_honors'     => false,
    'show_deportment' => false,
    'show_advisory'   => false,
    'position'        => 'Teacher',
];
if (isset($pdo) && $pdo instanceof PDO && $sidebarTeacherId > 0) {
    $teacherModules = getTeacherModules($pdo, $sidebarTeacherId, $sidebarYearId);
}

// --- Position + assignment based visibility (helpers live in api/login/teacher_auth.php) ---
if (!isset($pdo) || !($pdo instanceof PDO)) {
    require_once __DIR__ . '/../api/shared/db_connect.php';
}

$sidebarPosition = function_exists('getTeacherPosition')
    ? getTeacherPosition($pdo, $sidebarTeacherId)
    : ($teacherModules['position'] ?? 'Teacher');

$showAdvisory = !empty($teacherModules['show_advisory'])
    || (function_exists('isTeacherAdviser') && $sidebarTeacherId > 0 && isTeacherAdviser($pdo, $sidebarTeacherId));

$showApprovals = !empty($teacherModules['show_approvals'])
    || (function_exists('isTeacherApprover') && isTeacherApprover($sidebarPosition));

$showK3 = !empty($teacherModules['show_kinder']);

$hasAcademicsModules = $showApprovals || $teacherModules['show_deportment']
    || $showK3 || $teacherModules['show_honors'];
?>

<?php if ($sidebarCollapsed): ?>
    <script>document.documentElement.classList.add('stsn-pre-collapsed');</script>
<?php endif; ?>

<aside id="stsn-sidebar" class="stsn-sidebar<?php echo $sidebarCollapsed ? ' collapsed' : ''; ?>">
    <a href="#" class="stsn-brand">
        <div class="stsn-brand-logo">ST</div>
        <div class="stsn-brand-text">
            <span class="stsn-brand-name">St. Theresa's School</span>
            <span class="stsn-brand-sub">of Novaliches</span>
        </div>
    </a>

    <div class="stsn-nav-wrap">
        <p class="stsn-section-label">Main</p>
        <ul class="stsn-nav">
            <li class="stsn-nav-item">
                <a href="Dashboard.php"
                    class="stsn-link <?php echo ($currentPage == 'Dashboard.php') ? 'active' : ''; ?>"
                    data-tooltip="Dashboard">
                    <span class="stsn-icon-wrap"><i class="bi bi-speedometer2"></i></span>
                    <span class="stsn-link-text">Dashboard</span>
                </a>
            </li>
            <?php if ($showAdvisory): ?>
            <li class="stsn-nav-item">
                <a href="My-Advisory.php"
                    class="stsn-link <?php echo ($currentPage == 'My-Advisory.php') ? 'active' : ''; ?>"
                    data-tooltip="My Advisory">
                    <span class="stsn-icon-wrap"><i class="bi bi-person-rolodex"></i></span>
                    <span class="stsn-link-text">My Advisory</span>
                </a>
            </li>
            <?php endif; ?>
            <li class="stsn-nav-item">
                <a href="My-Sections.php"
                    class="stsn-link <?php echo ($currentPage == 'My-Sections.php') ? 'active' : ''; ?>"
                    data-tooltip="My Sections">
                    <span class="stsn-icon-wrap"><i class="bi bi-journal-bookmark-fill"></i></span>
                    <span class="stsn-link-text">My Section</span>
                </a>
            </li>
        </ul>

        <?php if ($hasAcademicsModules): ?>
        <p class="stsn-section-label">Academics</p>
        <ul class="stsn-nav">
            <?php if ($showApprovals): ?>
            <li>
                <a href="Approvals.php"
                    class="stsn-link <?php echo ($currentPage == 'Approvals.php') ? 'active' : ''; ?>"
                    data-tooltip="Approvals">
                    <span class="stsn-icon-wrap"><i class="bi bi-inbox"></i></span>
                    <span class="stsn-link-text">Approvals</span>
                </a>
            </li>
            <?php endif; ?>

            <?php if ($teacherModules['show_deportment']): ?>
            <li>
                <a href="Deportment.php"
                    class="stsn-link <?php echo ($currentPage == 'Deportment.php') ? 'active' : ''; ?>"
                    data-tooltip="Deportment">
                    <span class="stsn-icon-wrap"><i class="bi bi-star"></i></span>
                    <span class="stsn-link-text">Deportment</span>
                </a>
            </li>
            <?php endif; ?>

            <?php if ($showK3): ?>
            <li>
                <a href="K3-Report.php"
                    class="stsn-link <?php echo ($currentPage == 'K3-Report.php') ? 'active' : ''; ?>"
                    data-tooltip="K-3 Report">
                    <span class="stsn-icon-wrap"><i class="bi bi-file-earmark-text"></i></span>
                    <span class="stsn-link-text">K-3 Report</span>
                </a>
            </li>
            <li>
                <a href="Kinder-Assessment.php"
                    class="stsn-link <?php echo ($currentPage == 'Kinder-Assessment.php') ? 'active' : ''; ?>"
                    data-tooltip="Kindergarten Assessment">
                    <span class="stsn-icon-wrap"><i class="bi bi-clipboard-check"></i></span>
                    <span class="stsn-link-text">Kinder Assessment</span>
                </a>
            </li>
            <?php endif; ?>

            <?php if ($teacherModules['show_honors']): ?>
            <li>
                <a href="Honors-Detection.php"
                    class="stsn-link <?php echo ($currentPage == 'Honors-Detection.php') ? 'active' : ''; ?>"
                    data-tooltip="Honors Detection">
                    <span class="stsn-icon-wrap"><i class="bi bi-trophy"></i></span>
                    <span class="stsn-link-text">Honors Detection</span>
                </a>
            </li>
            <?php endif; ?>
        </ul>
        <?php endif; ?>

        <p class="stsn-section-label">Account</p>
        <ul class="stsn-nav">

            <li>
                <a href="Profile.php" class="stsn-link <?php echo ($currentPage == 'Profile.php') ? 'active' : ''; ?>"
                    data-tooltip="Profile">
                    <span class="stsn-icon-wrap"><i class="bi bi-person-circle"></i></span>
                    <span class="stsn-link-text">Profile / Account</span>
                </a>
            </li>
        </ul>

        <div class="stsn-divider"></div>

        <ul class="stsn-nav">
            <li>
                <a href="../api/login/logout.php" class="stsn-link logout" data-tooltip="Logout">
                    <span class="stsn-icon-wrap"><i class="bi bi-box-arrow-right"></i></span>
                    <span class="stsn-link-text">Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <div class="stsn-footer">
        <div class="stsn-avatar">MR</div>
        <div class="stsn-user-info">
            <div class="stsn-user-name"><?php echo htmlspecialchars($teacherName ?? 'Teacher'); ?></div>
            <div class="stsn-user-role"><?php echo htmlspecialchars($teacherModules['position'] ?? 'Teacher'); ?></div>
        </div>
        <button class="stsn-collapse-btn" id="stsn-collapse-btn" aria-label="Toggle sidebar">
            <i class="bi <?php echo $sidebarCollapsed ? 'bi-chevron-right' : 'bi-chevron-left'; ?>"></i>
        </button>
    </div>
</aside>

<script>
    (function () {
        if (document.documentElement.classList.contains('stsn-pre-collapsed')) {
            document.body.classList.add('sidebar-collapsed');
        }
    })();
</script>
<script src="../js/sidebar.js"></script>
<script src="../js/teacher-notifications.js"></script>
