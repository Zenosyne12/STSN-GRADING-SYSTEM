<?php
$currentPage = basename($_SERVER['PHP_SELF']);
?>

<aside id="stsn-sidebar" class="stsn-sidebar">
    <a href="#" class="stsn-brand">
        <div class="stsn-brand-logo">ST</div>
        <div class="stsn-brand-text">
            <span class="stsn-brand-name">St. Theresa's School</span>
            <span class="stsn-brand-sub">of Novaliches</span>
        </div>
    </a>

    <div class="stsn-nav-wrap">
        <p class="stsn-section-label">Main</p>
        <ul class="stsn-nav">
            <li class="stsn-nav-item">
                <a href="Dashboard.php" class="stsn-link <?php echo ($currentPage == 'Dashboard.php') ? 'active' : ''; ?>" data-tooltip="Dashboard">
                    <span class="stsn-icon-wrap"><i class="bi bi-speedometer2"></i></span>
                    <span class="stsn-link-text">Dashboard</span>
                </a>
            </li>

            <li class="stsn-nav-item">
                <a href="My-Advisory.php" class="stsn-link <?php echo ($currentPage == 'My-Advisory.php') ? 'active' : ''; ?>" data-tooltip="My Advisory">
                    <span class="stsn-icon-wrap"><i class="bi bi-person-rolodex"></i></span>
                    <span class="stsn-link-text">My Advisory</span>
                </a>
            </li>

            <li class="stsn-nav-item">
                <a href="My-Subjects.php" class="stsn-link <?php echo ($currentPage == 'My-Subjects.php') ? 'active' : ''; ?>" data-tooltip="My Subjects">
                    <span class="stsn-icon-wrap"><i class="bi bi-journal-bookmark-fill"></i></span>
                    <span class="stsn-link-text">My Subjects</span>
                </a>
            </li>
        </ul>

        <p class="stsn-section-label">Academics</p>
        <ul class="stsn-nav">
            <li>
                <a href="Grading-Sheet.php" class="stsn-link <?php echo ($currentPage == 'Grading-Sheet.php') ? 'active' : ''; ?>" data-tooltip="Grading Sheet">
                    <span class="stsn-icon-wrap"><i class="bi bi-pencil-square"></i></span>
                    <span class="stsn-link-text">Grading Sheet</span>
                </a>
            </li>

            <li>
                <a href="Deportment.php" class="stsn-link <?php echo ($currentPage == 'Character-Evaluation.php') ? 'active' : ''; ?>" data-tooltip="Character Evaluation">
                    <span class="stsn-icon-wrap"><i class="bi bi-star"></i></span>
                    <span class="stsn-link-text">Deportment</span>
                </a>
            </li>

            <li>
                <a href="Performance-Prediction.php" class="stsn-link <?php echo ($currentPage == 'Performance-Prediction.php') ? 'active' : ''; ?>" data-tooltip="Performance Prediction">
                    <span class="stsn-icon-wrap"><i class="bi bi-graph-up-arrow"></i></span>
                    <span class="stsn-link-text">Performance Prediction</span>
                </a>
            </li>

            <li>
                <a href="Honors-Detection.php" class="stsn-link <?php echo ($currentPage == 'Honors-Detection.php') ? 'active' : ''; ?>" data-tooltip="Honors Detection">
                    <span class="stsn-icon-wrap"><i class="bi bi-trophy"></i></span>
                    <span class="stsn-link-text">Honors Detection</span>
                </a>
            </li>

            <li>
                <a href="Reports.php" class="stsn-link <?php echo ($currentPage == 'Reports.php') ? 'active' : ''; ?>" data-tooltip="Reports">
                    <span class="stsn-icon-wrap"><i class="bi bi-file-earmark-bar-graph"></i></span>
                    <span class="stsn-link-text">Reports</span>
                </a>
            </li>
        </ul>

        <p class="stsn-section-label">Account</p>
        <ul class="stsn-nav">
            <li>
                <a href="Notifications.php" class="stsn-link <?php echo ($currentPage == 'Notifications.php') ? 'active' : ''; ?>" data-tooltip="Notifications">
                    <span class="stsn-icon-wrap"><i class="bi bi-bell"></i></span>
                    <span class="stsn-link-text">Notifications</span>
                </a>
            </li>

            <li>
                <a href="Profile.php" class="stsn-link <?php echo ($currentPage == 'Profile.php') ? 'active' : ''; ?>" data-tooltip="Profile">
                    <span class="stsn-icon-wrap"><i class="bi bi-person-circle"></i></span>
                    <span class="stsn-link-text">Profile / Account</span>
                </a>
            </li>
        </ul>

        <div class="stsn-divider"></div>

        <ul class="stsn-nav">
            <li>
                <a href="../api/login/logout.php" class="stsn-link logout" data-tooltip="Logout">
                    <span class="stsn-icon-wrap"><i class="bi bi-box-arrow-right"></i></span>
                    <span class="stsn-link-text">Logout</span>
                </a>
            </li>
        </ul>
    </div>

    <div class="stsn-footer">
        <div class="stsn-avatar">MR</div>
        <div class="stsn-user-info">
            <div class="stsn-user-name"><?php echo htmlspecialchars($teacherName); ?></div>
            <div class="stsn-user-role">Teacher</div>
        </div>
        <button class="stsn-collapse-btn" id="stsn-collapse-btn">
            <i class="bi bi-chevron-left"></i>
        </button>
    </div>
</aside>