<?php
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
    session_start();
}

function redirectTo(string $path): void
{
    header('Location: ' . $path);
    exit;
}

function isJsonRequest(): bool
{
    return stripos((string) ($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json') !== false
        || strtolower((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'xmlhttprequest';
}

function jsonAuthError(int $status, string $message): void
{
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => $message]);
    exit;
}

function requireLogin(): void
{
    if (
        !isset($_SESSION['user_id']) ||
        (int) $_SESSION['user_id'] <= 0 ||
        !isset($_SESSION['role_id']) ||
        (int) $_SESSION['role_id'] <= 0
    ) {
        if (isJsonRequest()) {
            jsonAuthError(401, 'Your session has expired. Please log in again.');
        }
        redirectTo('/lstsngsv1/login.php');
    }

    if (isset($_SESSION['must_change_password']) && (int) $_SESSION['must_change_password'] === 1) {
        $currentPage = basename($_SERVER['PHP_SELF']);
        $allowedPages = ['change-password.php', 'logout.php', 'authenticate.php'];

        if (!in_array($currentPage, $allowedPages, true)) {
            if (isJsonRequest()) {
                jsonAuthError(403, 'Password change is required before continuing.');
            }
            redirectTo('/lstsngsv1/pages/change-password.php');
        }
    }
}

function getSessionRoleId(): int
{
    requireLogin();
    return (int) ($_SESSION['role_id'] ?? 0);
}

function isAdminSession(): bool
{
    return getSessionRoleId() === 1;
}

function isTeacherSession(): bool
{
    return getSessionRoleId() === 2;
}

function requireAdmin(): void
{
    requireLogin();

    if (!isAdminSession()) {
        if (isJsonRequest()) {
            jsonAuthError(403, 'Administrator access is required.');
        }
        // Route to correct dashboard based on role
        $roleId = (int) ($_SESSION['role_id'] ?? 0);
        if ($roleId === 2) {
            redirectTo('/lstsngsv1/pages/Dashboard.php');
        } elseif ($roleId === 4) {
            redirectTo('/lstsngsv1/SuperAdmin/Dashboard.php');
        } else {
            // Unknown or invalid role — force logout
            redirectTo('/lstsngsv1/api/login/logout.php');
        }
    }
}

function requireTeacher(): void
{
    requireLogin();

    if (!isTeacherSession()) {
        redirectTo('/lstsngsv1/pages/Dashboard.php');
    }

    if (!isset($_SESSION['teacher_id']) || (int) $_SESSION['teacher_id'] <= 0) {
        redirectTo('/lstsngsv1/login.php');
    }
}
function isSuperAdminSession(): bool
{
    return getSessionRoleId() === 4;
}

function requireSuperAdmin(): void
{
    requireLogin();

    if (!isSuperAdminSession()) {
        if (isJsonRequest()) {
            jsonAuthError(403, 'Super Admin access is required.');
        }
        // Route to correct dashboard based on role
        $roleId = (int) ($_SESSION['role_id'] ?? 0);
        if ($roleId === 1) {
            redirectTo('/lstsngsv1/Dashboard.php');
        } elseif ($roleId === 2) {
            redirectTo('/lstsngsv1/pages/Dashboard.php');
        } else {
            redirectTo('/lstsngsv1/api/login/logout.php');
        }
    }
}