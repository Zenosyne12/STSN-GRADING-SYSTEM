<?php
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
    session_start();
}

function redirectTo(string $path): void
{
    header('Location: ' . $path);
    exit;
}

function requireLogin(): void
{
    if (
        !isset($_SESSION['user_id']) ||
        (int) $_SESSION['user_id'] <= 0 ||
        !isset($_SESSION['role_id']) ||
        (int) $_SESSION['role_id'] <= 0
    ) {
        redirectTo('/lstsngsv1/login.php');
    }

    if (isset($_SESSION['must_change_password']) && (int) $_SESSION['must_change_password'] === 1) {
        $currentPage = basename($_SERVER['PHP_SELF']);
        $allowedPages = ['change-password.php', 'logout.php', 'authenticate.php'];

        if (!in_array($currentPage, $allowedPages, true)) {
            redirectTo('/lstsngsv1/pages/change-password.php');
        }
    }
}

function getSessionRoleId(): int
{
    requireLogin();
    return (int) ($_SESSION['role_id'] ?? 0);
}

function isAdminSession(): bool
{
    return getSessionRoleId() === 1;
}

function isTeacherSession(): bool
{
    return getSessionRoleId() === 2;
}

function requireAdmin(): void
{
    requireLogin();

    if (!isAdminSession()) {
        redirectTo('/lstsngsv1/pages/Dashboard.php');
    }
}

function requireTeacher(): void
{
    requireLogin();

    if (!isTeacherSession()) {
        redirectTo('/lstsngsv1/Dashboard.php');
    }

    if (!isset($_SESSION['teacher_id']) || (int) $_SESSION['teacher_id'] <= 0) {
        redirectTo('/lstsngsv1/login.php');
    }
}