<div class="modal fade ay-modal" id="autoSectionModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">
          <i class="bi bi-diagram-3 me-2"></i>Add to Section Automatically?
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <p id="sectionModalMessage">
          Add students to an available section?
        </p>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" id="dontShowAgainCheck">
          <label class="form-check-label" for="dontShowAgainCheck">
            Don't show this again
          </label>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal" id="btnSkipAutoAssign">
          No, Select Manually
        </button>
        <button type="button" class="btn btn-primary" id="btnAutoAssign">
          <i class="bi bi-check me-1"></i>Yes, Auto-Assign
        </button>
      </div>
    </div>
  </div>
</div>
