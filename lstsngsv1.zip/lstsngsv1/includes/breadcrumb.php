<?php
if (!function_exists('renderBreadcrumb')) {
    function renderBreadcrumb(array $items, string $variant = 'admin'): void
    {
        static $stylePrinted = false;

        if (!$stylePrinted) {
            $stylePrinted = true;
            ?>
            <style>
                .stsn-breadcrumb {
                    --bc-bg: #fff;
                    --bc-border: #dce8f8;
                    --bc-text: #132f62;
                    --bc-muted: #7a93b8;
                    --bc-hover-bg: #eef4ff;
                    --bc-hover-text: #1248a8;
                    --bc-active-bg: #f4f8ff;
                    --bc-active-text: #132f62;
                    --bc-shadow: 0 2px 10px rgba(18, 72, 168, .04);
                    display: flex;
                    align-items: center;
                    justify-content: flex-start;
                    gap: .35rem;
                    flex-wrap: wrap;
                    margin: 0 0 1rem;
                    padding: .62rem .8rem;
                    background: var(--bc-bg);
                    border: 1px solid var(--bc-border);
                    border-radius: 12px;
                    color: var(--bc-muted);
                    font-size: .82rem;
                    line-height: 1.3;
                    box-shadow: var(--bc-shadow);
                    transition: background-color .2s ease, border-color .2s ease, color .2s ease;
                }

                .stsn-breadcrumb.teacher {
                    --bc-bg: var(--surface, #fff);
                    --bc-border: var(--border, #E9ECEF);
                    --bc-text: var(--primary, #0A2F44);
                    --bc-muted: var(--muted, #6C757D);
                    --bc-hover-bg: var(--surface-2, #F8F9FA);
                    --bc-hover-text: var(--primary, #0A2F44);
                    --bc-active-bg: var(--primary-soft, rgba(10, 47, 68, .08));
                    --bc-active-text: var(--primary, #0A2F44);
                    --bc-shadow: var(--shadow, 0 10px 30px rgba(10, 47, 68, .08));
                }

                /* ============================================
                   DARK MODE SUPPORT
                   Covers: [data-bs-theme="dark"], .dark-mode,
                   body.dark, html.dark, and prefers-color-scheme
                   ============================================ */
                [data-bs-theme="dark"] .stsn-breadcrumb,
                [data-theme="dark"] .stsn-breadcrumb,
                html.dark .stsn-breadcrumb,
                body.dark .stsn-breadcrumb,
                body.dark-mode .stsn-breadcrumb,
                .dark-mode .stsn-breadcrumb,
                .dark .stsn-breadcrumb {
                    --bc-bg: #2D2D2D;
                    --bc-border: #2D2D2D;
                    --bc-text: #e6edf7;
                    --bc-muted: #9fb0c7;
                    --bc-hover-bg: #253047;
                    --bc-hover-text: #dbe7ff;
                    --bc-active-bg: #22304a;
                    --bc-active-text: #ffffff;
                    --bc-shadow: 0 2px 10px rgba(0, 0, 0, .35);
                }

                @media (prefers-color-scheme: dark) {
                    html:not([data-bs-theme="light"]):not([data-theme="light"]):not(.light) .stsn-breadcrumb {
                        --bc-bg: #2D2D2D;
                        --bc-border: #2D2D2D;
                        --bc-text: #e6edf7;
                        --bc-muted: #9fb0c7;
                        --bc-hover-bg: #253047;
                        --bc-hover-text: #dbe7ff;
                        --bc-active-bg: #22304a;
                        --bc-active-text: #ffffff;
                        --bc-shadow: 0 2px 10px rgba(0, 0, 0, .35);
                    }
                }

                .page-shell > .stsn-breadcrumb {
                    margin: 1rem 1.5rem 1rem;
                }

                .stsn-breadcrumb a,
                .stsn-breadcrumb span {
                    min-width: 0;
                }

                .stsn-breadcrumb a {
                    display: inline-flex;
                    align-items: center;
                    gap: .35rem;
                    color: var(--bc-muted);
                    text-decoration: none;
                    font-weight: 700;
                    border-radius: 8px;
                    padding: .2rem .35rem;
                    cursor: pointer;
                    transition: background .14s ease, color .14s ease;
                }

                .stsn-breadcrumb a:hover,
                .stsn-breadcrumb a:focus {
                    background: var(--bc-hover-bg);
                    color: var(--bc-hover-text);
                }

                .stsn-breadcrumb .bc-active {
                    display: inline-flex;
                    align-items: center;
                    gap: .35rem;
                    color: var(--bc-active-text);
                    background: var(--bc-active-bg);
                    border-radius: 8px;
                    padding: .2rem .48rem;
                    font-weight: 800;
                }

                .stsn-breadcrumb .bc-separator {
                    color: var(--bc-muted);
                    opacity: .65;
                    font-size: .72rem;
                }

                .stsn-breadcrumb i {
                    font-size: .86rem;
                    flex: 0 0 auto;
                }

                @media (max-width: 575.98px) {
                    .stsn-breadcrumb {
                        justify-content: flex-start;
                        gap: .25rem;
                        padding: .55rem .62rem;
                        font-size: .78rem;
                        border-radius: 10px;
                    }

                    .page-shell > .stsn-breadcrumb {
                        margin: .75rem 1rem;
                    }

                    .stsn-breadcrumb a,
                    .stsn-breadcrumb .bc-active {
                        max-width: 100%;
                        overflow-wrap: anywhere;
                    }
                }
            </style>
            <?php
        }

        $items = array_values(array_filter($items, static function ($item) {
            return is_array($item) && trim((string)($item['label'] ?? '')) !== '';
        }));

        if (!$items) {
            return;
        }

        $lastIndex = count($items) - 1;
        ?>
        <nav class="stsn-breadcrumb <?= htmlspecialchars($variant) ?>" aria-label="Breadcrumb">
            <?php foreach ($items as $index => $item): ?>
                <?php
                $label = (string)$item['label'];
                $href = (string)($item['href'] ?? '');
                $icon = (string)($item['icon'] ?? '');
                $isLast = $index === $lastIndex;
                ?>
                <?php if ($index > 0): ?>
                    <i class="bi bi-chevron-right bc-separator" aria-hidden="true"></i>
                <?php endif; ?>

                <?php if (!$isLast && $href !== ''): ?>
                    <a href="<?= htmlspecialchars($href) ?>">
                        <?php if ($icon !== ''): ?><i class="<?= htmlspecialchars($icon) ?>" aria-hidden="true"></i><?php endif; ?>
                        <span><?= htmlspecialchars($label) ?></span>
                    </a>
                <?php elseif ($isLast): ?>
                    <span class="bc-active" aria-current="page">
                        <?php if ($icon !== ''): ?><i class="<?= htmlspecialchars($icon) ?>" aria-hidden="true"></i><?php endif; ?>
                        <span><?= htmlspecialchars($label) ?></span>
                    </span>
                <?php else: ?>
                    <span>
                        <?php if ($icon !== ''): ?><i class="<?= htmlspecialchars($icon) ?>" aria-hidden="true"></i><?php endif; ?>
                        <span><?= htmlspecialchars($label) ?></span>
                    </span>
                <?php endif; ?>
            <?php endforeach; ?>
        </nav>
        <?php
    }
}