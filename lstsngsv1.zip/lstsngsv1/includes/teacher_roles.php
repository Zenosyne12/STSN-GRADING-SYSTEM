<?php
/**
 * Teacher Workflow Roles
 * Separate from teaching position (tblteacher.position) and 
 * advisory assignment (tblsectionadviser).
 */

if (!function_exists('getTeacherWorkflowRoles')) {

    function getTeacherWorkflowRoles(PDO $pdo, int $teacherId, int $yearId = 0): array {
        static $cache = [];
        $key = $teacherId . ':' . $yearId;
        if (isset($cache[$key])) return $cache[$key];

        $result = [];
        if ($teacherId <= 0) {
            $cache[$key] = $result;
            return $result;
        }

        try {
            $stmt = $pdo->prepare("
                SELECT id, role, scope_subject_id, scope_strand, academic_year_id
                FROM tblworkflow_role
                WHERE teacher_id = ?
                  AND is_active = 1
                  AND (academic_year_id IS NULL OR academic_year_id = ?)
                ORDER BY role, scope_subject_id
            ");
            $stmt->execute([$teacherId, $yearId]);
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (Throwable $e) {
            error_log('getTeacherWorkflowRoles error: ' . $e->getMessage());
            $result = [];
        }
        $cache[$key] = $result;
        return $result;
    }

    /**
     * Convenience: returns array of role names, e.g. 
     * ['SUBJECT_COORDINATOR', 'PRINCIPAL']
     */
    function getTeacherRoleNames(PDO $pdo, int $teacherId, int $yearId = 0): array {
        $roles = getTeacherWorkflowRoles($pdo, $teacherId, $yearId);
        return array_values(array_unique(array_column($roles, 'role')));
    }

    function hasWorkflowRole(PDO $pdo, int $teacherId, string $role, int $yearId = 0): bool {
        return in_array(strtoupper($role), getTeacherRoleNames($pdo, $teacherId, $yearId), true);
    }

    function isSubjectCoordinator(PDO $pdo, int $teacherId, int $yearId = 0): bool {
        return hasWorkflowRole($pdo, $teacherId, 'SUBJECT_COORDINATOR', $yearId);
    }

    function isPrincipal(PDO $pdo, int $teacherId, int $yearId = 0): bool {
        return hasWorkflowRole($pdo, $teacherId, 'PRINCIPAL', $yearId);
    }

    function isRegistrar(PDO $pdo, int $teacherId, int $yearId = 0): bool {
        return hasWorkflowRole($pdo, $teacherId, 'REGISTRAR', $yearId);
    }
}