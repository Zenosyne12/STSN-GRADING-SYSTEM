<?php

/**
 * Returns the active term for the active academic year, or null if none is found.
 */
function getActiveTerm(PDO $pdo): ?array
{
    try {
        $stmt = $pdo->prepare("
            SELECT id, academic_year_id, term_number, term_label, term_type,
                   start_date, end_date, is_active
            FROM tblconfig_terms
            WHERE is_active = 1
              AND academic_year_id = (
                  SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1
              )
            LIMIT 1
        ");
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) {
        return null;
    }
}

/**
 * Returns all terms for an academic year, or an empty array if the query fails.
 */
function getAllTermsForYear(PDO $pdo, int $academicYearId): array
{
    try {
        $stmt = $pdo->prepare("
            SELECT id, term_number, term_label, start_date, end_date,
                   is_active, is_closed
            FROM tblconfig_terms
            WHERE academic_year_id = ?
            ORDER BY term_number ASC
        ");
        $stmt->execute([$academicYearId]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        return [];
    }
}

/**
 * Returns a term by ID, or null if no matching term is found.
 */
function getTermById(PDO $pdo, int $termId): ?array
{
    try {
        $stmt = $pdo->prepare("SELECT * FROM tblconfig_terms WHERE id = ? LIMIT 1");
        $stmt->execute([$termId]);

        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) {
        return null;
    }
}

/**
 * Returns a term by its number within an academic year, or null if none is found.
 */
function getTermByNumber(PDO $pdo, int $academicYearId, int $termNumber): ?array
{
    try {
        $stmt = $pdo->prepare("
            SELECT * FROM tblconfig_terms
            WHERE academic_year_id = ? AND term_number = ?
            LIMIT 1
        ");
        $stmt->execute([$academicYearId, $termNumber]);

        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) {
        return null;
    }
}

/**
 * Returns the active term number, or 0 if no active term is found.
 */
function getActiveTermNumber(PDO $pdo): int
{
    $term = getActiveTerm($pdo);

    return $term === null ? 0 : (int) $term['term_number'];
}
