<?php
$basePath = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? $_SERVER['PHP_SELF'] ?? '')), '/');
$base = ($basePath === '' || $basePath === '.' || $basePath === false) ? '/' : rtrim($basePath, '/') . '/';
$saSidebarCurrentPage = basename($_SERVER['PHP_SELF']);

function sAdminIsActive($file)
{
  global $saSidebarCurrentPage;
  return $file === $saSidebarCurrentPage ? 'active' : '';
}
?>

<aside class="app-sidebar bg-dark text-white border-end shadow-sm custom-sidebar">
  <div class="sidebar-brand">
    <a href="Dashboard.php" class="sidebar-brand-link text-decoration-none text-white">
      <div class="sidebar-logo rounded-circle d-flex align-items-center justify-content-center"
           style="width:48px; height:48px; background-color:#8B1A1A;">
        <i class="bi bi-person-gear fs-5 text-white"></i>
      </div>
      <div class="sidebar-brand-text">
        <div class="sidebar-title" style="font-size:0.95rem;">STSN SUPER ADMIN</div>
        <small class="sidebar-subtitle" style="font-size:0.7rem; opacity:0.75;">System Control Panel</small>
      </div>
    </a>
  </div>

  <div class="sidebar-body">
    <ul class="nav flex-column sidebar-menu">

      <li class="nav-item">
        <a href="Dashboard.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= sAdminIsActive('Dashboard.php') ?>">
          <i class="bi bi-speedometer2 me-2"></i>
          <span>Dashboard</span>
        </a>
      </li>

      <li class="nav-label">
        <small class="text-uppercase text-white-50 fw-semibold">System Configuration</small>
      </li>

      <li class="nav-item">
        <a href="Clusters.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= sAdminIsActive('Clusters.php') ?>">
          <i class="bi bi-diagram-3 me-2"></i>
          <span>Clusters</span>
        </a>
      </li>

      <!-- (Curriculum Templates removed — admin's Curriculum.php is used instead) -->

      <li class="nav-item">
        <a href="<?= $base ?>Grading-Templates.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= sAdminIsActive('Grading-Templates.php') ?>">
          <i class="bi bi-sliders me-2"></i>
          <span>Grading Configuration</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="Workflow-Configuration.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= sAdminIsActive('Workflow-Configuration.php') ?>">
          <i class="bi bi-diagram-2 me-2"></i>
          <span>Workflow Templates</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>Kinder-Skills.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= sAdminIsActive('Kinder-Skills.php') ?>">
          <i class="bi bi-people-fill me-2"></i>
          <span>Kindergarten Skills</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>Terms-Configuration.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= sAdminIsActive('Terms-Configuration.php') ?>">
          <i class="bi bi-calendar3 me-2"></i>
          <span>Terms Configuration</span>
        </a>
      </li>

      <li class="nav-label">
        <small class="text-uppercase text-white-50 fw-semibold">Access Control</small>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>User-Accounts.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= sAdminIsActive('User-Accounts.php') ?>">
          <i class="bi bi-shield-lock me-2"></i>
          <span>Roles &amp; Permissions</span>
        </a>
      </li>

      <!-- User Accounts merged into Roles & Permissions -->

      <li class="nav-label">
        <small class="text-uppercase text-white-50 fw-semibold">System</small>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>Archive-Settings.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= sAdminIsActive('Archive-Settings.php') ?>">
          <i class="bi bi-archive me-2"></i>
          <span>Archive Settings</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>System-Settings.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= sAdminIsActive('System-Settings.php') ?>">
          <i class="bi bi-gear me-2"></i>
          <span>System Settings</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="Activity-Log.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= sAdminIsActive('Activity-Log.php') ?>">
          <i class="bi bi-clock-history me-2"></i>
          <span>Activity Log</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>Backup-Restore.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= sAdminIsActive('Backup-Restore.php') ?>">
          <i class="bi bi-cloud-arrow-up me-2"></i>
          <span>Backup &amp; Restore</span>
        </a>
      </li>

      <li class="nav-label">
        <small class="text-uppercase text-white-50 fw-semibold">Account</small>
      </li>

      <li class="nav-item logout-item">
        <a href="../api/login/logout.php"
          class="nav-link rounded-3 px-3 py-2 d-flex align-items-center sidebar-logout">
          <i class="bi bi-box-arrow-right me-2"></i>
          <span>Logout</span>
        </a>
      </li>

    </ul>
  </div>
</aside>

<style>
  /* Selected sidebar item — clean solid maroon */
  .sidebar-link.active,
  .sidebar-link.active:hover {
      background: #8B1A1A !important;
      color: #ffffff !important;
      box-shadow: none !important;
      border-radius: 8px;
      font-weight: 600;
  }

  .sidebar-link.active i {
      color: #ffffff !important;
  }

  /* Remove any pseudo-element decorations on the active item */
  .sidebar-link.active::before,
  .sidebar-link.active::after {
      content: none !important;
      display: none !important;
  }

  .sidebar-link:hover {
      background: rgba(139, 26, 26, 0.15) !important;
      color: #ffffff !important;
      border-radius: 8px;
  }
</style>
