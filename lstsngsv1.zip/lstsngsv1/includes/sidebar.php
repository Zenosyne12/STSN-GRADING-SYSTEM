<?php
$basePath = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? $_SERVER['PHP_SELF'] ?? '')), '/');

if ($basePath === '' || $basePath === '.' || $basePath === false) {
  $basePath = '/';
} elseif (strpos($basePath, '/') !== 0) {
  $basePath = '/' . $basePath;
}

$base = rtrim($basePath, '/') . '/';

function isActive($file)
{
  return basename($_SERVER['PHP_SELF']) === $file ? 'active' : '';
}

function isExpanded($files)
{
  return in_array(basename($_SERVER['PHP_SELF']), $files) ? 'show' : '';
}

function isAriaExpanded($files)
{
  return in_array(basename($_SERVER['PHP_SELF']), $files) ? 'true' : 'false';
}
?>

<aside class="app-sidebar bg-dark text-white border-end shadow-sm custom-sidebar">
  <div class="sidebar-brand">
    <a href="<?= $base ?>Dashboard.php" class="sidebar-brand-link text-decoration-none text-white">
      <div class="sidebar-logo">
        <i class="bi bi-person-fill-gear fs-5"></i>
      </div>
      <div class="sidebar-brand-text">
        <div class="sidebar-title">STSN ADMIN</div>
        <small class="sidebar-subtitle">Management Panel</small>
      </div>
    </a>
  </div>

  <div class="sidebar-body">
    <ul class="nav flex-column sidebar-menu">

      <li class="nav-item">
        <a href="<?= $base ?>Dashboard.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('Dashboard.php') ?>">
          <i class="bi bi-speedometer2 me-2"></i>
          <span>Dashboard</span>
        </a>
      </li>

      <li class="nav-label">
        <small class="text-uppercase text-white-50 fw-semibold">Users</small>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>teacher.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('teacher.php') ?>">
          <i class="bi bi-people me-2"></i>
          <span>Manage Faculty</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>Student.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('Student.php') ?>">
          <i class="bi bi-people me-2"></i>
          <span>Manage Students</span>
        </a>
      </li>

      <li class="nav-label">
        <small class="text-uppercase text-white-50 fw-semibold">Maintenance</small>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>section.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('section.php') ?>">
          <i class="bi bi-journals me-2"></i>
          <span>Section</span>
        </a>
      </li>
      <li class="nav-item">
        <a href="<?= $base ?>Curriculum.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('Curriculum.php') ?>">
          <i class="bi bi-journal-bookmark-fill me-2"></i>
          <span>Curriculum</span>
        </a>
      </li>
      <li class="nav-item">
        <a href="<?= $base ?>schedule.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('schedule.php') ?>">
          <i class="bi bi-calendar-week-fill me-2"></i>
          <span>Scheduling</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>sectioning.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('sectioning.php') ?>">
          <i class="bi bi-pin-map me-2"></i>
          <span>Sectioning</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>grades-report.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('grades-report.php') ?>">
          <i class="bi bi-file-text-fill me-2"></i>
          <span>Reports</span>
        </a>
      </li>

      <li class="nav-label">
        <small class="text-uppercase text-white-50 fw-semibold">Deadline Management</small>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>Approvals.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('Approvals.php') ?>">
          <i class="bi bi-inbox me-2"></i>
          <span>Grade Approvals</span>
        </a>
      </li>


      <li class="nav-item">
        <a href="<?= $base ?>Deadline.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('Deadline.php') ?>">
          <i class="bi bi-alarm me-2"></i>
          <span>Deadline</span>
        </a>
      </li>

      <li class="nav-label">
        <small class="text-uppercase text-white-50 fw-semibold">Academic Settings</small>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>academic_year.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('academic_year.php') ?>">
          <i class="bi bi-calendar-range me-2"></i>
          <span>Academic Year</span>
        </a>
      </li>

      <?php /* Grade Descriptor moved to SuperAdmin (Grading-Templates.php → Descriptors tab) */ ?>

      <li class="nav-label">
        <small class="text-uppercase text-white-50 fw-semibold">Archive</small>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>historical_records.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('historical_records.php') ?>">
          <i class="bi bi-clock-history me-2"></i>
          <span>Historical Records</span>
        </a>
      </li>

      <li class="nav-label">
        <small class="text-uppercase text-white-50 fw-semibold">System Settings</small>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>admin_settings.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('admin_settings.php') ?>">
          <i class="bi bi-gear-fill me-2"></i>
          <span>Settings</span>
        </a>
      </li>

      <!-- Activity Log removed -->

      <li class="nav-item logout-item">
        <a href="<?= $base ?>api/login/logout.php"
          class="nav-link rounded-3 px-3 py-2 d-flex align-items-center sidebar-logout">
          <i class="bi bi-box-arrow-right me-2"></i>
          <span>Logout</span>
        </a>
      </li>

    </ul>
  </div>
</aside>
<script>
  (() => {
    const sidebarBody = document.querySelector('.custom-sidebar .sidebar-body');
    if (!sidebarBody) return;

    let hideTimer;
    sidebarBody.addEventListener('scroll', () => {
      sidebarBody.classList.add('is-scrolling');
      clearTimeout(hideTimer);
      hideTimer = setTimeout(() => sidebarBody.classList.remove('is-scrolling'), 1200);
    }, { passive: true });
  })();
</script>