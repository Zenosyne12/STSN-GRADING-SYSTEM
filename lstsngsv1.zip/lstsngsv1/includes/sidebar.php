<?php
$basePath = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? $_SERVER['PHP_SELF'] ?? '')), '/');

if ($basePath === '' || $basePath === '.' || $basePath === false) {
  $basePath = '/';
} elseif (strpos($basePath, '/') !== 0) {
  $basePath = '/' . $basePath;
}

$base = rtrim($basePath, '/') . '/';
$pendingPromotionCount = 0;
$hasActiveYear = true;
$curriculumNeedsSetup = false;
if (isset($pdo) && $pdo instanceof PDO) {
  try {
    $activeYearStmt = $pdo->query("
      SELECT
        COUNT(*) AS cnt,
        COALESCE(SUM(CASE WHEN curriculum_status = 'NONE' THEN 1 ELSE 0 END), 0) AS none_cnt
      FROM tblacademicyear
      WHERE is_active = 1 AND archived_at IS NULL
    ");
    $ayRow = $activeYearStmt->fetch(PDO::FETCH_ASSOC) ?: [];
    $hasActiveYear = ((int) ($ayRow['cnt'] ?? 0)) > 0;
    $curriculumNeedsSetup = $hasActiveYear && ((int) ($ayRow['none_cnt'] ?? 0) > 0);
  } catch (Throwable $e) {
    error_log('[sidebar] Active academic year check failed: ' . $e->getMessage());
  }

  try {
    $pendingPromotionStmt = $pdo->query("
      SELECT COUNT(*) AS pending_count
      FROM tblenrollment e
      JOIN tblacademicyear ay ON ay.id = e.academic_year_id
      WHERE e.promotion_decision = 'PENDING_REVIEW'
        AND ay.archived_at IS NOT NULL
    ");
    $pendingPromotion = $pendingPromotionStmt->fetch(PDO::FETCH_ASSOC) ?: [];
    $pendingPromotionCount = (int) ($pendingPromotion['pending_count'] ?? 0);
  } catch (Throwable $e) {
    error_log('[sidebar] Promotion review count failed: ' . $e->getMessage());
  }
}

function isActive($file)
{
  return basename($_SERVER['PHP_SELF']) === $file ? 'active' : '';
}

function isExpanded($files)
{
  return in_array(basename($_SERVER['PHP_SELF']), $files) ? 'show' : '';
}

function isAriaExpanded($files)
{
  return in_array(basename($_SERVER['PHP_SELF']), $files) ? 'true' : 'false';
}
?>

<style>
  .sidebar-alert-dot {
    display: inline-block;
    width: 8px;
    height: 8px;
    background: #ef4444;
    border-radius: 50%;
    margin-left: auto;
    box-shadow: 0 0 0 2px rgba(239, 68, 68, 0.25);
    animation: sidebarDotPulse 1.8s ease-in-out infinite;
  }

  @keyframes sidebarDotPulse {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.6; transform: scale(1.15); }
  }
</style>

<aside class="app-sidebar bg-dark text-white border-end shadow-sm custom-sidebar">
  <div class="sidebar-brand">
    <a href="<?= $base ?>Dashboard.php" class="sidebar-brand-link text-decoration-none text-white">
      <div class="sidebar-logo">
        <i class="bi bi-person-fill-gear fs-5"></i>
      </div>
      <div class="sidebar-brand-text">
        <div class="sidebar-title">STSN ADMIN</div>
        <small class="sidebar-subtitle">Management Panel</small>
      </div>
    </a>
  </div>

  <div class="sidebar-body">
    <ul class="nav flex-column sidebar-menu">

      <li class="nav-item">
        <a href="<?= $base ?>Dashboard.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('Dashboard.php') ?>">
          <i class="bi bi-speedometer2 me-2"></i>
          <span>Dashboard</span>
        </a>
      </li>

      <li class="nav-label">
        <small class="text-uppercase text-white-50 fw-semibold">Users</small>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>teacher.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('teacher.php') ?>">
          <i class="bi bi-people me-2"></i>
          <span>Manage Faculty</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>Student.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('Student.php') ?>">
          <i class="bi bi-people me-2"></i>
          <span>Manage Students</span>
        </a>
      </li>

      <li class="nav-label">
        <small class="text-uppercase text-white-50 fw-semibold">Maintenance</small>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>section.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('section.php') ?>">
          <i class="bi bi-journals me-2"></i>
          <span>Section</span>
        </a>
      </li>
      <li class="nav-item">
        <a href="<?= $base ?>Curriculum.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('Curriculum.php') ?>">
          <i class="bi bi-journal-bookmark-fill me-2"></i>
          <span>Curriculum</span>
          <span id="curriculumAlertDot" class="sidebar-alert-dot<?= $curriculumNeedsSetup ? '' : ' d-none' ?>"
            title="Curriculum setup needed" aria-label="Curriculum setup needed"></span>
        </a>
      </li>
      <li class="nav-item">
        <a href="<?= $base ?>schedule.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('schedule.php') ?>">
          <i class="bi bi-calendar-week-fill me-2"></i>
          <span>Scheduling</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>sectioning.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('sectioning.php') ?>">
          <i class="bi bi-pin-map me-2"></i>
          <span>Sectioning</span>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>grades-report.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('grades-report.php') ?>">
          <i class="bi bi-file-text-fill me-2"></i>
          <span>Reports</span>
        </a>
      </li>

      <li class="nav-label">
        <small class="text-uppercase text-white-50 fw-semibold">Deadline Management</small>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>Approvals.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('Approvals.php') ?>">
          <i class="bi bi-inbox me-2"></i>
          <span>Grade Approvals</span>
        </a>
      </li>


      <li class="nav-item">
        <a href="<?= $base ?>Deadline.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('Deadline.php') ?>">
          <i class="bi bi-alarm me-2"></i>
          <span>Deadline</span>
        </a>
      </li>

      <li class="nav-label">
        <small class="text-uppercase text-white-50 fw-semibold">Academic Settings</small>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>academic_year.php"
          id="academicYearNavLink"
          data-has-active-year="<?= $hasActiveYear ? '1' : '0' ?>"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('academic_year.php') ?>">
          <i class="bi bi-calendar-range me-2"></i>
          <span>Academic Year</span>
          <span id="academicYearAlertDot" class="sidebar-alert-dot<?= $hasActiveYear ? ' d-none' : '' ?>"
            title="No active academic year" aria-label="No active academic year"></span>
        </a>
      </li>
      <li class="nav-item">
        <a href="<?= $base ?>Promotion-Review.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('Promotion-Review.php') ?>">
          <i class="bi bi-person-check me-2"></i>
          <span>Promotion Review</span>
          <?php if ($pendingPromotionCount > 0): ?>
          <span class="badge bg-warning text-dark ms-auto"><?= $pendingPromotionCount ?></span>
          <?php endif; ?>
        </a>
      </li>

      <?php /* Grade Descriptor moved to SuperAdmin (Grading-Templates.php → Descriptors tab) */ ?>

      <li class="nav-label">
        <small class="text-uppercase text-white-50 fw-semibold">Archive</small>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>historical_records.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('historical_records.php') ?>">
          <i class="bi bi-clock-history me-2"></i>
          <span>Historical Records</span>
        </a>
      </li>

      <li class="nav-label">
        <small class="text-uppercase text-white-50 fw-semibold">System Settings</small>
      </li>

      <li class="nav-item">
        <a href="<?= $base ?>admin_settings.php"
          class="nav-link text-white rounded-3 px-3 py-2 d-flex align-items-center sidebar-link <?= isActive('admin_settings.php') ?>">
          <i class="bi bi-gear-fill me-2"></i>
          <span>Settings</span>
        </a>
      </li>

      <!-- Activity Log removed -->

      <li class="nav-item logout-item">
        <a href="<?= $base ?>api/login/logout.php"
          class="nav-link rounded-3 px-3 py-2 d-flex align-items-center sidebar-logout">
          <i class="bi bi-box-arrow-right me-2"></i>
          <span>Logout</span>
        </a>
      </li>

    </ul>
  </div>
</aside>
<script>
  (() => {
    const dot = document.getElementById('academicYearAlertDot');
    const curriculumDot = document.getElementById('curriculumAlertDot');
    const navLink = document.getElementById('academicYearNavLink');
    if (!dot || !curriculumDot || !navLink) return;

    const statusUrl = <?= json_encode($base . 'api/academic-year/active-status.php', JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?>;

    async function checkActiveYear() {
      try {
        const response = await fetch(statusUrl, { cache: 'no-store' });
        if (!response.ok) {
          throw new Error(`Active-year status request failed (${response.status}).`);
        }

        const result = await response.json();
        if (!result.success
            || typeof result.has_active_year !== 'boolean'
            || typeof result.curriculum_none !== 'boolean') {
          throw new Error(result.message || 'Invalid active-year status response.');
        }

        const hasActiveYear = result.has_active_year;
        const curriculumNone = result.curriculum_none;
        dot.classList.toggle('d-none', hasActiveYear);
        curriculumDot.classList.toggle('d-none', !(hasActiveYear && curriculumNone));
        navLink.dataset.hasActiveYear = result.has_active_year ? '1' : '0';
      } catch (error) {
        console.error('Unable to refresh academic-year sidebar indicator:', error);
      }
    }

    window.refreshAcademicYearDot = checkActiveYear;
    checkActiveYear();
    window.setInterval(checkActiveYear, 30000);
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) checkActiveYear();
    });
  })();
</script>
<script>
  (() => {
    const sidebarBody = document.querySelector('.custom-sidebar .sidebar-body');
    if (!sidebarBody) return;

    let hideTimer;
    sidebarBody.addEventListener('scroll', () => {
      sidebarBody.classList.add('is-scrolling');
      clearTimeout(hideTimer);
      hideTimer = setTimeout(() => sidebarBody.classList.remove('is-scrolling'), 1200);
    }, { passive: true });
  })();
</script>