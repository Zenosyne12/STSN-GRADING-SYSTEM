<?php
/**
 * Teacher Module Visibility
 * Assignment-based: kung saan naka-assign si teacher, 
 * yun yung modules na nakikita.
 */

if (!function_exists('getTeacherModules')) {

    function getTeacherModules(PDO $pdo, int $teacherId, int $yearId): array {
        $modules = [
            'show_kinder'     => false,
            'show_approvals'  => false,
            'show_honors'     => false,
            'show_deportment' => false,
            'show_advisory'   => false,
            'position'        => 'Teacher',
        ];
        if ($teacherId <= 0) return $modules;

        try {
            // 1. Get position
            $p = $pdo->prepare("SELECT position FROM tblteacher WHERE id = ? LIMIT 1");
            $p->execute([$teacherId]);
            $modules['position'] = $p->fetchColumn() ?: 'Teacher';

            // 2. Kinder assignment = adviser of any Kinder section OR subject 
            //    teacher scheduled in a Kinder section.
            $k = $pdo->prepare("
                SELECT (
                  (SELECT COUNT(*) 
                   FROM tblsectionadviser sa
                   JOIN tblsection s ON s.id = sa.section_id
                   JOIN tblgradelevel gl ON gl.id = s.grade_level_id
                   WHERE sa.teacher_id = ?
                     AND sa.academic_year_id = (
                         SELECT id FROM tblacademicyear WHERE is_active = 1 LIMIT 1
                     )
                     AND gl.grade_level_code = 0)
                  +
                  (SELECT COUNT(*) 
                   FROM tblschedule sch
                   JOIN tblsection s ON s.id = sch.section_id
                   JOIN tblgradelevel gl ON gl.id = s.grade_level_id
                   WHERE sch.teacher_id = ?
                     AND sch.is_active = 1
                     AND sch.school_year = (
                         SELECT year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1
                     )
                     AND gl.grade_level_code = 0)
                ) AS kinder_count
            ");
            $k->execute([$teacherId, $teacherId]);
            $modules['show_kinder'] = ((int)$k->fetchColumn() > 0);

            // 3. Adviser check — via tblsectionadviser
            $a = $pdo->prepare("
                SELECT COUNT(*) 
                FROM tblsectionadviser 
                WHERE teacher_id = ? AND academic_year_id = ?
            ");
            $a->execute([$teacherId, $yearId]);
            $hasAdviser = ((int)$a->fetchColumn() > 0);
            $modules['show_advisory']   = $hasAdviser;
            // Honors Detection and Deportment visible to ALL teachers
            $modules['show_honors']     = true;
            $modules['show_deportment'] = true;

            // 4. Approvals — position-based
            $approverPositions = ['Adviser', 'Subject Coordinator', 'Principal', 'Registrar'];
            $modules['show_approvals'] = in_array($modules['position'], $approverPositions, true)
                || $hasAdviser;  // Adviser din may approvals (reviews submissions)

        } catch (Throwable $e) {
            error_log('getTeacherModules error: ' . $e->getMessage());
        }
        return $modules;
    }
}