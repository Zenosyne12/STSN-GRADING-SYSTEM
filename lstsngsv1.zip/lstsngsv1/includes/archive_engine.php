<?php
/**
 * includes/archive_engine.php
 * STSN Grading System — central archive logic shared by
 * SuperAdmin, Admin and Teacher sides.
 *
 * Hostinger-compatible: no MySQL Event Scheduler, no shell tools —
 * everything runs through PDO. Intended callers:
 *   - SuperAdmin/Archive-Settings.php (manual archive configuration)
 *   - api/archive/manage.php (manual archive/restore actions)
 *
 * Conventions:
 *   - Every function is wrapped in function_exists() guards
 *   - PDO prepared statements only
 *   - Throwable is caught → error_log() + safe return value
 *   - No output, no headers
 *   - Multi-value returns are arrays containing a 'success' key
 */

if (!function_exists('getArchiveSettings')) {
    /**
     * Read tblarchive_settings (id = 1) with per-request static cache.
     * Self-heals: inserts the default row when missing.
     *
     * @return array Keys: id, mode, auto_term_lock, auto_year_promote,
     *               fallback_dashboard_check, cron_token, last_cron_run,
     *               last_cron_status, notify_on_archive
     */
    function getArchiveSettings(PDO $pdo): array
    {
        static $cache = null;
        if ($cache !== null) {
            return $cache;
        }

        $defaults = [
            'id'                      => 1,
            'mode'                    => 'AUTO',
            'auto_term_lock'          => 1,
            'auto_year_promote'       => 1,
            'fallback_dashboard_check'=> 1,
            'cron_token'              => '',
            'last_cron_run'           => null,
            'last_cron_status'        => null,
            'notify_on_archive'       => 1,
        ];

        try {
            $row = $pdo->query("SELECT * FROM tblarchive_settings WHERE id = 1")
                ->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                $pdo->exec("INSERT IGNORE INTO tblarchive_settings (id, mode) VALUES (1, 'AUTO')");
                $row = $pdo->query("SELECT * FROM tblarchive_settings WHERE id = 1")
                    ->fetch(PDO::FETCH_ASSOC);
            }
            $cache = is_array($row) ? array_merge($defaults, $row) : $defaults;
        } catch (Throwable $e) {
            error_log('[archive_engine] getArchiveSettings failed: ' . $e->getMessage());
            $cache = $defaults;
        }
        return $cache;
    }
}

if (!function_exists('isTermLocked')) {
    /**
     * True when at least one grade row for the section/subject/term
     * is flagged read-only (tblgrades.is_locked = 1).
     */
    function isTermLocked(PDO $pdo, int $sectionId, int $subjectId, int $termNum): bool
    {
        try {
            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM tblgrades
                WHERE section_id = ? AND subject_id = ? AND quarter = ? AND is_locked = 1
            ");
            $stmt->execute([$sectionId, $subjectId, $termNum]);
            return (int)$stmt->fetchColumn() > 0;
        } catch (Throwable $e) {
            error_log('[archive_engine] isTermLocked failed: ' . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('ensureProfileArchiveSchema')) {
    function ensureProfileArchiveSchema(PDO $pdo): void
    {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS tblprofile_archive (
                id INT NOT NULL AUTO_INCREMENT,
                profile_type ENUM('STUDENT', 'TEACHER') NOT NULL,
                profile_id INT NOT NULL,
                academic_year_id INT NOT NULL,
                archived_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                archived_by INT NULL,
                restored_at TIMESTAMP NULL DEFAULT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uq_profile_year (profile_type, profile_id, academic_year_id),
                KEY idx_profile_archive_year (academic_year_id, profile_type, restored_at),
                CONSTRAINT fk_profile_archive_year
                    FOREIGN KEY (academic_year_id) REFERENCES tblacademicyear (id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
        ");
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS tblprofile_archive_section (
                profile_archive_id INT NOT NULL,
                section_student_id INT NOT NULL,
                PRIMARY KEY (profile_archive_id, section_student_id),
                CONSTRAINT fk_profile_archive_section_archive
                    FOREIGN KEY (profile_archive_id) REFERENCES tblprofile_archive (id) ON DELETE CASCADE,
                CONSTRAINT fk_profile_archive_section_membership
                    FOREIGN KEY (section_student_id) REFERENCES tblsectionstudent (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
        ");
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS tblprofile_archive_enrollment (
                profile_archive_id INT NOT NULL,
                enrollment_id INT NOT NULL,
                PRIMARY KEY (profile_archive_id, enrollment_id),
                CONSTRAINT fk_profile_archive_enrollment_archive
                    FOREIGN KEY (profile_archive_id) REFERENCES tblprofile_archive (id) ON DELETE CASCADE,
                KEY idx_profile_archive_enrollment_record (enrollment_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
        ");
    }
}

if (!function_exists('restoreArchivedStudentSectionMemberships')) {
    function restoreArchivedStudentSectionMemberships(PDO $pdo, int $studentId): void
    {
        $stmt = $pdo->prepare("
            SELECT pas.profile_archive_id, pas.section_student_id
            FROM tblprofile_archive pa
            INNER JOIN tblprofile_archive_section pas ON pas.profile_archive_id = pa.id
            WHERE pa.profile_type = 'STUDENT'
              AND pa.profile_id = ?
              AND pa.restored_at IS NULL
        ");
        $stmt->execute([$studentId]);
        $memberships = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $activate = $pdo->prepare("
            UPDATE tblsectionstudent
            SET is_active = 1
            WHERE id = ? AND student_id = ?
        ");
        $deleteSnapshot = $pdo->prepare("
            DELETE FROM tblprofile_archive_section
            WHERE profile_archive_id = ? AND section_student_id = ?
        ");
        $enrollmentStmt = $pdo->prepare("
            SELECT pae.profile_archive_id, pae.enrollment_id
            FROM tblprofile_archive pa
            INNER JOIN tblprofile_archive_enrollment pae ON pae.profile_archive_id = pa.id
            WHERE pa.profile_type = 'STUDENT'
              AND pa.profile_id = ?
              AND pa.restored_at IS NULL
        ");
        $enrollmentStmt->execute([$studentId]);
        $enrollments = $enrollmentStmt->fetchAll(PDO::FETCH_ASSOC);
        $activateEnrollment = $pdo->prepare("
            UPDATE tblenrollment
            SET is_active = 1
            WHERE id = ? AND student_id = ?
        ");
        $deleteEnrollmentSnapshot = $pdo->prepare("
            DELETE FROM tblprofile_archive_enrollment
            WHERE profile_archive_id = ? AND enrollment_id = ?
        ");

        foreach ($memberships as $membership) {
            $archiveId = (int) $membership['profile_archive_id'];
            $membershipId = (int) $membership['section_student_id'];
            $activate->execute([$membershipId, $studentId]);
            $deleteSnapshot->execute([$archiveId, $membershipId]);
        }
        foreach ($enrollments as $enrollment) {
            $archiveId = (int) $enrollment['profile_archive_id'];
            $enrollmentId = (int) $enrollment['enrollment_id'];
            $activateEnrollment->execute([$enrollmentId, $studentId]);
            $deleteEnrollmentSnapshot->execute([$archiveId, $enrollmentId]);
        }
    }
}

if (!function_exists('lockTerm')) {
    /**
     * Mark every unlocked grade row of the given term as read-only.
     * NOTE: tblworkflow_action_log.instance_id is NOT NULL in the schema,
     * so 0 (not NULL) is written for system-level rows.
     *
     * @return array ['success' => bool, 'locked_count' => int, 'message' => string]
     */
    function lockTerm(PDO $pdo, int $academicYearId, int $termNumber): array
    {
        try {
            $stmt = $pdo->prepare("
                UPDATE tblgrades
                SET is_locked = 1, updated_at = NOW()
                WHERE quarter = ? AND academic_year_id = ? AND is_locked = 0
            ");
            $stmt->execute([$termNumber, $academicYearId]);
            $lockedCount = $stmt->rowCount();

            $logStmt = $pdo->prepare("
                INSERT INTO tblworkflow_action_log
                    (instance_id, step_order, actor_user_id, actor_role_id,
                     actor_position, action, remarks, acted_at)
                VALUES (0, 1, 0, 4, 'System', 'TERM_LOCK', ?, NOW())
            ");
            $logStmt->execute(['Auto-locked term ' . $termNumber . ' (school year #' . $academicYearId . ')']);

            return ['success' => true, 'locked_count' => $lockedCount, 'message' => ''];
        } catch (Throwable $e) {
            error_log('[archive_engine] lockTerm failed: ' . $e->getMessage());
            return ['success' => false, 'locked_count' => 0, 'message' => $e->getMessage()];
        }
    }
}

if (!function_exists('archiveYear')) {
    /**
     * Archive a finished academic year: snapshot student outcomes into
     * tblstudent_archive, deactivate the year and record the action.
     * Uses a transaction — everything or nothing.
     *
     * @return array ['status' => string, 'success' => bool, 'archived_count' => int, 'message' => string]
     */
    function archiveYear(PDO $pdo, int $yearId, string $reason, int $adminId, string $mode = 'MANUAL'): array
    {
        if (!in_array($mode, ['AUTO', 'MANUAL'], true)) {
            $mode = 'MANUAL';
        }

        try {
            $pdo->beginTransaction();

            $yearStmt = $pdo->prepare("SELECT year_label FROM tblacademicyear WHERE id = ? LIMIT 1");
            $yearStmt->execute([$yearId]);
            $yearLabel = $yearStmt->fetchColumn();
            if ($yearLabel === false) {
                throw new RuntimeException('School year not found.');
            }

            // Grade-level code map (graduation check needs the numeric level)
            $gradeCodeMap = [];
            try {
                $glRows = $pdo->query("SELECT id, grade_level_code FROM tblgradelevel")->fetchAll(PDO::FETCH_ASSOC);
                foreach ($glRows as $gl) {
                    $gradeCodeMap[(int)$gl['id']] = (int)$gl['grade_level_code'];
                }
            } catch (Throwable $e) {
                error_log('[archive_engine] grade level map failed, falling back to ids: ' . $e->getMessage());
            }

            $stmt = $pdo->prepare("
                SELECT cohort.student_id,
                       COALESCE(e.grade_level_id, latest_section.grade_level_id, student.grade_level_id) AS grade_level_id,
                       e.promotion_decision, e.enrollment_status,
                       COALESCE(AVG(g.final_grade), 0) AS final_average
                FROM (
                    SELECT student_id FROM tblsectionstudent WHERE academic_year_id = ?
                    UNION
                    SELECT student_id FROM tblenrollment WHERE academic_year_id = ?
                    UNION
                    SELECT student_id FROM tblstudent_archive WHERE academic_year_id = ?
                ) cohort
                INNER JOIN tblstudents student ON student.id = cohort.student_id
                LEFT JOIN (
                    SELECT enrollment.*
                    FROM tblenrollment enrollment
                    INNER JOIN (
                        SELECT student_id, MAX(id) AS id
                        FROM tblenrollment
                        WHERE academic_year_id = ?
                        GROUP BY student_id
                    ) latest ON latest.id = enrollment.id
                ) e ON e.student_id = cohort.student_id AND e.academic_year_id = ?
                LEFT JOIN (
                    SELECT section_student.student_id, section.grade_level_id
                    FROM tblsectionstudent section_student
                    INNER JOIN (
                        SELECT student_id, MAX(id) AS id
                        FROM tblsectionstudent
                        WHERE academic_year_id = ?
                        GROUP BY student_id
                    ) latest ON latest.id = section_student.id
                    INNER JOIN tblsection section ON section.id = section_student.section_id
                ) latest_section ON latest_section.student_id = cohort.student_id
                LEFT JOIN tblgrades g ON g.student_id = cohort.student_id
                     AND g.academic_year_id = ?
                GROUP BY cohort.student_id, e.grade_level_id, latest_section.grade_level_id,
                         student.grade_level_id, e.promotion_decision, e.enrollment_status
            ");
            $stmt->execute([$yearId, $yearId, $yearId, $yearId, $yearId, $yearId, $yearId]);
            $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $insert = $pdo->prepare("
                INSERT IGNORE INTO tblstudent_archive
                    (student_id, academic_year_id, grade_level_id, final_average,
                     status, archived_at, archived_by, archive_reason)
                VALUES (?, ?, ?, ?, ?, NOW(), ?, ?)
                ON DUPLICATE KEY UPDATE
                    grade_level_id = VALUES(grade_level_id),
                    final_average = VALUES(final_average),
                    status = VALUES(status),
                    archived_at = VALUES(archived_at),
                    archived_by = VALUES(archived_by),
                    archive_reason = VALUES(archive_reason)
            ");

            $archivedCount = 0;
            foreach ($students as $student) {
                $studentId   = (int)$student['student_id'];
                $gradeLvlId  = (int)$student['grade_level_id'];
                $avg         = round((float)$student['final_average'], 2);
                $levelCode   = $gradeCodeMap[$gradeLvlId] ?? $gradeLvlId;

                $promotionDecision = strtoupper(trim((string) ($student['promotion_decision'] ?? '')));
                if (!in_array($promotionDecision, ['PROMOTED', 'RETAINED', 'DROPPED', 'TRANSFERRED', 'GRADUATED'], true)) {
                    $promotionDecision = strtoupper(trim((string) ($student['enrollment_status'] ?? '')));
                }
                if (in_array($promotionDecision, ['PROMOTED', 'RETAINED', 'DROPPED', 'TRANSFERRED', 'GRADUATED'], true)) {
                    $status = $promotionDecision;
                } elseif ($avg >= 75 && $levelCode >= 12) {
                    $status = 'GRADUATED';
                } elseif ($avg >= 75) {
                    $status = 'PROMOTED';
                } else {
                    $status = 'RETAINED';
                }

                $insert->execute([
                    $studentId,
                    $yearId,
                    $gradeLvlId,
                    $avg,
                    $status,
                    $adminId,
                    $reason,
                ]);
                $archivedCount += $insert->rowCount();

            }

            $closeTerms = $pdo->prepare("
                UPDATE tblconfig_terms
                SET is_closed = 1, is_active = 0
                WHERE academic_year_id = ?
            ");
            $closeTerms->execute([$yearId]);

            $lockGrades = $pdo->prepare("
                UPDATE tblgrades
                SET is_locked = 1
                WHERE academic_year_id = ?
            ");
            $lockGrades->execute([$yearId]);

            $deactivateSchedules = $pdo->prepare("
                UPDATE tblschedule
                SET is_active = 0
                WHERE school_year = ?
            ");
            $deactivateSchedules->execute([$yearLabel]);

            $upd = $pdo->prepare("
                UPDATE tblacademicyear
                SET is_active = 0, archived_at = NOW(), archived_by = ?,
                    archive_reason = ?, archive_mode = ?
                WHERE id = ?
            ");
            $upd->execute([$adminId, $reason, $mode, $yearId]);

            $actorStmt = $pdo->prepare("
                SELECT u.username, u.role_id, r.role_name,
                       t.fname, t.lname
                FROM tblusers u
                LEFT JOIN tblrole r ON r.id = u.role_id
                LEFT JOIN tblteacher t ON u.role_id = 2 AND t.id = u.reference_id
                WHERE u.id = ?
                LIMIT 1
            ");
            $actorStmt->execute([$adminId]);
            $actor = $actorStmt->fetch(PDO::FETCH_ASSOC) ?: [];
            $actorName = trim((string)($actor['fname'] ?? '') . ' ' . (string)($actor['lname'] ?? ''));
            if ($actorName === '') {
                $actorName = (string)($actor['username'] ?? 'System');
            }
            $actorRole = (string)($actor['role_name'] ?? 'System');
            $ipAddress = $_SERVER['REMOTE_ADDR'] ?? null;
            $description = 'Manual archive of S.Y. ' . $yearLabel
                . ' (' . $archivedCount . ' student record(s)): ' . $reason;

            $logStmt = $pdo->prepare("
                INSERT INTO tblactivity_log
                    (user_id, user_name, role, module, action, entity_type,
                     entity_id, description, ip_address, created_at)
                VALUES (?, ?, ?, 'Archive', ?, 'academic_year', ?, ?, ?, NOW())
            ");
            $logStmt->execute([
                $adminId > 0 ? $adminId : null,
                $actorName,
                $actorRole,
                $mode . '_ARCHIVE',
                $yearId,
                $description,
                $ipAddress,
            ]);

            $archiveCurriculum = $pdo->prepare("
                UPDATE tblacademicyear
                SET curriculum_status = 'ARCHIVED',
                    curriculum_archived_at = COALESCE(curriculum_archived_at, NOW())
                WHERE id = ? AND curriculum_status = 'ACTIVE'
            ");
            $archiveCurriculum->execute([$yearId]);

            $pdo->commit();
            return ['status' => 'success', 'success' => true, 'archived_count' => $archivedCount, 'message' => ''];
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('[archive_engine] archiveYear failed: ' . $e->getMessage());
            return ['status' => 'error', 'success' => false, 'archived_count' => 0, 'message' => $e->getMessage()];
        }
    }
}
if (!function_exists('restoreYear')) {
    /**
     * Restore a year and undo the locks applied by archiveYear().
     *
     * @return array ['status' => string, 'success' => bool, 'year_label' => string, 'message' => string]
     */
    function restoreYear(PDO $pdo, int $yearId, int $adminId, string $reason = ''): array
    {
        try {
            $pdo->beginTransaction();

            $yearStmt = $pdo->prepare("
                SELECT year_label, is_active, archived_at
                FROM tblacademicyear
                WHERE id = ?
                LIMIT 1
                FOR UPDATE
            ");
            $yearStmt->execute([$yearId]);
            $year = $yearStmt->fetch(PDO::FETCH_ASSOC);
            if (!$year) {
                throw new RuntimeException('School year not found.');
            }
            if (empty($year['archived_at']) || (int) $year['is_active'] === 1) {
                throw new RuntimeException('Only an archived school year can be restored.');
            }

            // Auto-deactivate the currently active year(s) and clear any globally-active
            // term/quarter flags, mirroring the activation flow in api/academic-year/toggle.php.
            // The old year's data is preserved; only the active flags change.
            $pdo->exec("UPDATE tblacademicyear SET is_active = 0 WHERE is_active = 1");
            $pdo->exec("UPDATE tblconfig_terms SET is_active = 0 WHERE is_active = 1");
            $pdo->exec("UPDATE tblquarters SET is_active = 0 WHERE is_active = 1");
            $yearLabel = (string) $year['year_label'];

            $reopenTerms = $pdo->prepare("
                UPDATE tblconfig_terms
                SET is_closed = 0, is_active = 0
                WHERE academic_year_id = ?
            ");
            $reopenTerms->execute([$yearId]);

            $unlockGrades = $pdo->prepare("
                UPDATE tblgrades
                SET is_locked = 0
                WHERE academic_year_id = ?
            ");
            $unlockGrades->execute([$yearId]);

            $reactivateSchedules = $pdo->prepare("
                UPDATE tblschedule
                SET is_active = 1
                WHERE school_year = ?
            ");
            $reactivateSchedules->execute([(string)$yearLabel]);

            $activateYear = $pdo->prepare("
                UPDATE tblacademicyear
                SET is_active = 1, archived_at = NULL, archived_by = NULL,
                    archive_reason = NULL, archive_mode = NULL
                WHERE id = ?
            ");
            $activateYear->execute([$yearId]);

            // Reverse the curriculum status flip performed by archiveYear().
            // Only ARCHIVED → ACTIVE; a NONE row stays NONE (that year never had a curriculum).
            $restoreCurriculum = $pdo->prepare("
                UPDATE tblacademicyear
                SET curriculum_status = 'ACTIVE',
                    curriculum_archived_at = NULL
                WHERE id = ? AND curriculum_status = 'ARCHIVED'
            ");
            $restoreCurriculum->execute([$yearId]);

            require_once __DIR__ . '/activity_log.php';
            logActivity(
                $pdo,
                'Archive',
                'RESTORE',
                'academic_year',
                $yearId,
                'Restored school year ' . $yearLabel . ' to active. Reason: ' . $reason
            );

            try {
                $logStmt = $pdo->prepare("
                    INSERT INTO tblworkflow_action_log
                        (instance_id, step_order, actor_user_id, actor_role_id,
                         actor_position, action, remarks, acted_at)
                    VALUES (0, 1, ?, 1, 'Admin', 'RESTORE', ?, NOW())
                ");
                $logStmt->execute([
                    $adminId,
                    'Restored school year ' . $yearLabel . ' to active. Reason: ' . $reason,
                ]);
            } catch (Throwable $logErr) {
                error_log('[archive_engine] RESTORE log write failed: ' . $logErr->getMessage());
            }

            $pdo->commit();
            return [
                'status' => 'success',
                'success' => true,
                'year_label' => (string)$yearLabel,
                'message' => '',
            ];
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('[archive_engine] restoreYear failed: ' . $e->getMessage());
            return [
                'status' => 'error',
                'success' => false,
                'year_label' => '',
                'message' => $e->getMessage(),
            ];
        }
    }
}
