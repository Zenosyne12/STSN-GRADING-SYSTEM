<?php
/**
 * includes/archive_engine.php
 * STSN Grading System — central archive logic shared by
 * SuperAdmin, Admin and Teacher sides.
 *
 * Hostinger-compatible: no MySQL Event Scheduler, no shell tools —
 * everything runs through PDO. Intended callers:
 *   - SuperAdmin/Archive-Settings.php (manual archive, cron config)
 *   - api/archive/auto_check.php (cron entry point, token-protected)
 *   - dashboards (fallback check, when enabled in settings)
 *
 * Conventions:
 *   - Every function is wrapped in function_exists() guards
 *   - PDO prepared statements only
 *   - Throwable is caught → error_log() + safe return value
 *   - No output, no headers
 *   - Multi-value returns are arrays containing a 'success' key
 */

if (!function_exists('getArchiveSettings')) {
    /**
     * Read tblarchive_settings (id = 1) with per-request static cache.
     * Self-heals: inserts the default row when missing.
     *
     * @return array Keys: id, mode, auto_term_lock, auto_year_promote,
     *               fallback_dashboard_check, cron_token, last_cron_run,
     *               last_cron_status, notify_on_archive
     */
    function getArchiveSettings(PDO $pdo): array
    {
        static $cache = null;
        if ($cache !== null) {
            return $cache;
        }

        $defaults = [
            'id'                      => 1,
            'mode'                    => 'AUTO',
            'auto_term_lock'          => 1,
            'auto_year_promote'       => 1,
            'fallback_dashboard_check'=> 1,
            'cron_token'              => '',
            'last_cron_run'           => null,
            'last_cron_status'        => null,
            'notify_on_archive'       => 1,
        ];

        try {
            $row = $pdo->query("SELECT * FROM tblarchive_settings WHERE id = 1")
                ->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                $pdo->exec("INSERT IGNORE INTO tblarchive_settings (id, mode) VALUES (1, 'AUTO')");
                $row = $pdo->query("SELECT * FROM tblarchive_settings WHERE id = 1")
                    ->fetch(PDO::FETCH_ASSOC);
            }
            $cache = is_array($row) ? array_merge($defaults, $row) : $defaults;
        } catch (Throwable $e) {
            error_log('[archive_engine] getArchiveSettings failed: ' . $e->getMessage());
            $cache = $defaults;
        }
        return $cache;
    }
}

if (!function_exists('isTermLocked')) {
    /**
     * True when at least one grade row for the section/subject/term
     * is flagged read-only (tblgrades.is_locked = 1).
     */
    function isTermLocked(PDO $pdo, int $sectionId, int $subjectId, int $termNum): bool
    {
        try {
            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM tblgrades
                WHERE section_id = ? AND subject_id = ? AND quarter = ? AND is_locked = 1
            ");
            $stmt->execute([$sectionId, $subjectId, $termNum]);
            return (int)$stmt->fetchColumn() > 0;
        } catch (Throwable $e) {
            error_log('[archive_engine] isTermLocked failed: ' . $e->getMessage());
            return false;
        }
    }
}
if (!function_exists('lockTerm')) {
    /**
     * Mark every unlocked grade row of the given term as read-only.
     * NOTE: tblworkflow_action_log.instance_id is NOT NULL in the schema,
     * so 0 (not NULL) is written for system-level rows.
     *
     * @return array ['success' => bool, 'locked_count' => int, 'message' => string]
     */
    function lockTerm(PDO $pdo, int $academicYearId, int $termNumber): array
    {
        try {
            $stmt = $pdo->prepare("
                UPDATE tblgrades
                SET is_locked = 1, updated_at = NOW()
                WHERE quarter = ? AND academic_year_id = ? AND is_locked = 0
            ");
            $stmt->execute([$termNumber, $academicYearId]);
            $lockedCount = $stmt->rowCount();

            $logStmt = $pdo->prepare("
                INSERT INTO tblworkflow_action_log
                    (instance_id, step_order, actor_user_id, actor_role_id,
                     actor_position, action, remarks, acted_at)
                VALUES (0, 1, 0, 4, 'System', 'TERM_LOCK', ?, NOW())
            ");
            $logStmt->execute(['Auto-locked term ' . $termNumber . ' (school year #' . $academicYearId . ')']);

            return ['success' => true, 'locked_count' => $lockedCount, 'message' => ''];
        } catch (Throwable $e) {
            error_log('[archive_engine] lockTerm failed: ' . $e->getMessage());
            return ['success' => false, 'locked_count' => 0, 'message' => $e->getMessage()];
        }
    }
}

if (!function_exists('archiveYear')) {
    /**
     * Archive a finished academic year: snapshot student outcomes into
     * tblstudent_archive, deactivate the year and record the action.
     * Uses a transaction — everything or nothing.
     *
     * @return array ['success' => bool, 'archived_count' => int, 'message' => string]
     */
    function archiveYear(PDO $pdo, int $yearId, string $reason, int $adminId, string $mode = 'MANUAL'): array
    {
        if (!in_array($mode, ['AUTO', 'MANUAL'], true)) {
            $mode = 'MANUAL';
        }

        try {
            $pdo->beginTransaction();

            // Grade-level code map (graduation check needs the numeric level)
            $gradeCodeMap = [];
            try {
                $glRows = $pdo->query("SELECT id, grade_level_code FROM tblgradelevel")->fetchAll(PDO::FETCH_ASSOC);
                foreach ($glRows as $gl) {
                    $gradeCodeMap[(int)$gl['id']] = (int)$gl['grade_level_code'];
                }
            } catch (Throwable $e) {
                error_log('[archive_engine] grade level map failed, falling back to ids: ' . $e->getMessage());
            }

            $stmt = $pdo->prepare("
                SELECT ss.student_id, s.grade_level_id,
                       COALESCE(AVG(g.final_grade), 0) AS final_average
                FROM tblsectionstudent ss
                JOIN tblsection s ON s.id = ss.section_id
                LEFT JOIN tblgrades g ON g.student_id = ss.student_id
                     AND g.academic_year_id = ss.academic_year_id
                WHERE ss.academic_year_id = ? AND ss.is_active = 1
                GROUP BY ss.student_id, s.grade_level_id
            ");
            $stmt->execute([$yearId]);
            $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $insert = $pdo->prepare("
                INSERT IGNORE INTO tblstudent_archive
                    (student_id, academic_year_id, grade_level_id, final_average,
                     status, archived_at, archived_by, archive_reason)
                VALUES (?, ?, ?, ?, ?, NOW(), ?, ?)
            ");

            $archivedCount = 0;
            foreach ($students as $student) {
                $studentId   = (int)$student['student_id'];
                $gradeLvlId  = (int)$student['grade_level_id'];
                $avg         = round((float)$student['final_average'], 2);
                $levelCode   = $gradeCodeMap[$gradeLvlId] ?? $gradeLvlId;

                if ($avg >= 75 && $levelCode >= 12) {
                    $status = 'GRADUATED';
                } elseif ($avg >= 75) {
                    $status = 'PROMOTED';
                } else {
                    $status = 'RETAINED';
                }

                $insert->execute([
                    $studentId,
                    $yearId,
                    $gradeLvlId,
                    $avg,
                    $status,
                    $adminId,
                    $reason,
                ]);
                $archivedCount += $insert->rowCount();
            }

            $upd = $pdo->prepare("
                UPDATE tblacademicyear
                SET is_active = 0, archived_at = NOW(), archived_by = ?,
                    archive_reason = ?, archive_mode = ?
                WHERE id = ?
            ");
            $upd->execute([$adminId, $reason, $mode, $yearId]);

            $logStmt = $pdo->prepare("
                INSERT INTO tblworkflow_action_log
                    (instance_id, step_order, actor_user_id, actor_role_id,
                     actor_position, action, remarks, acted_at)
                VALUES (0, 1, ?, ?, 'Admin', ?, ?, NOW())
            ");
            $logStmt->execute([
                $adminId,
                $adminId > 0 ? 1 : 4,
                $mode . '_ARCHIVE',
                $reason . ' (' . $archivedCount . ' student record(s))',
            ]);

            $pdo->commit();
            return ['success' => true, 'archived_count' => $archivedCount, 'message' => ''];
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('[archive_engine] archiveYear failed: ' . $e->getMessage());
            return ['success' => false, 'archived_count' => 0, 'message' => $e->getMessage()];
        }
    }
}
if (!function_exists('checkAutoArchive')) {
    /**
     * The AUTO-mode heartbeat (cron / fallback-dashboard entry point):
     * locks finished terms, archives finished school years, then records
     * the run status in tblarchive_settings.
     *
     * @return array ['success' => bool, 'actions' => string[], 'message' => string]
     */
    function checkAutoArchive(PDO $pdo): array
    {
        $settings = getArchiveSettings($pdo);
        $actions  = [];

        if ((string)$settings['mode'] !== 'AUTO') {
            return ['success' => true, 'actions' => $actions, 'message' => 'Mode is MANUAL — nothing to do.'];
        }

        $success = true;

        // ---- 1. Finished, not-yet-closed terms → lock + close ----
        try {
            $termStmt = $pdo->query("
                SELECT id, term_number, academic_year_id
                FROM tblconfig_terms
                WHERE is_closed = 0 AND end_date < NOW()
            ");
            $terms = $termStmt->fetchAll(PDO::FETCH_ASSOC);

            $closeStmt = $pdo->prepare("UPDATE tblconfig_terms SET is_closed = 1 WHERE id = ?");
            foreach ($terms as $term) {
                $termId     = (int)$term['id'];
                $termNumber = (int)$term['term_number'];
                $yearId     = (int)$term['academic_year_id'];

                if (!empty($settings['auto_term_lock'])) {
                    $result = lockTerm($pdo, $yearId, $termNumber);
                    if (!$result['success']) {
                        $success = false;
                        continue;
                    }
                    if ($result['locked_count'] > 0) {
                        $actions[] = "Locked Term {$termNumber} ({$result['locked_count']} grade row(s))";
                    }
                }
                $closeStmt->execute([$termId]);
            }
        } catch (Throwable $e) {
            $success = false;
            error_log('[archive_engine] checkAutoArchive term pass failed: ' . $e->getMessage());
        }

        // ---- 2. Finished, still-active school year → archive ----
        try {
            $yearStmt = $pdo->query("
                SELECT id, year_label
                FROM tblacademicyear
                WHERE is_active = 1 AND end_date < CURDATE()
            ");
            $years = $yearStmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($years as $year) {
                $yearId    = (int)$year['id'];
                $yearLabel = (string)$year['year_label'];
                if (!empty($settings['auto_year_promote'])) {
                    $result = archiveYear($pdo, $yearId, 'Auto-archived at year end', 0, 'AUTO');
                    if ($result['success']) {
                        $actions[] = "Archived year {$yearLabel} ({$result['archived_count']} student record(s))";
                    } else {
                        $success = false;
                    }
                }
            }
        } catch (Throwable $e) {
            $success = false;
            error_log('[archive_engine] checkAutoArchive year pass failed: ' . $e->getMessage());
        }

        // ---- 3. Record the run ----
        try {
            $upd = $pdo->prepare("
                UPDATE tblarchive_settings
                SET last_cron_run = NOW(), last_cron_status = ?
                WHERE id = 1
            ");
            $upd->execute([$success ? 'success' : 'failed']);
        } catch (Throwable $e) {
            error_log('[archive_engine] checkAutoArchive status update failed: ' . $e->getMessage());
        }

        return ['success' => $success, 'actions' => $actions, 'message' => ''];
    }
}

if (!function_exists('verifyCronToken')) {
    /**
     * Timing-safe comparison of the provided cron token against the
     * stored one. False when either side is empty.
     */
    function verifyCronToken(PDO $pdo, string $token): bool
    {
        $token = trim($token);
        if ($token === '') {
            return false;
        }
        $settings = getArchiveSettings($pdo);
        $stored   = trim((string)($settings['cron_token'] ?? ''));
        if ($stored === '') {
            return false;
        }
        return hash_equals($stored, $token);
    }
}


