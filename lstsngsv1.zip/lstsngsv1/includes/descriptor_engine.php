<?php
/**
 * includes/descriptor_engine.php
 * ---------------------------------------------------------------------
 * Single source of truth for descriptor/remarks lookup across the three
 * grading types stored in tbldescriptors.
 *
 * Consumers: grading_engine.php (delegates via lookupDescriptor()),
 *            grades-report.php, Form 138 rendering, Honors Detection,
 *            SuperAdmin/Grading-Templates.php (Tab 3 listing).
 *
 * Seed data (grading_type / applies_to_grade_level_from-to):
 *   KINDERGARTEN (0-0)  : A=Always Observed, S=Sometimes Observed,
 *                         R=Rarely Observed, N=Not Yet Observed
 *   DESCRIPTIVE  (1-3)  : A=Advanced, P=Proficient, AP=Approaching
 *                         Proficiency, D=Developing, B=Beginning
 *   NUMERICAL    (4-12) : 90-100=Advancing, 80-89=Benchmarking,
 *                         75-79=Connecting, 65-74=Developing,
 *                         0-64=Emerging
 *
 * Rules:
 *   - PDO prepared statements only.
 *   - try/catch (Throwable) -> error_log + safe default; no exceptions
 *     escape this file.
 *   - Static caching per function (per request).
 *   - Raw strings are returned (no escaping here — callers handle output).
 * ---------------------------------------------------------------------
 */

/* ============================================================
   getGradingTypeForGradeLevel — pure helper (no DB)
   ============================================================ */
if (!function_exists('getGradingTypeForGradeLevel')) {
    /**
     * Map a grade code (0 = Kindergarten, 1-12 = grade level) to its
     * grading type: 0 -> KINDERGARTEN, 1-3 -> DESCRIPTIVE, 4-12 -> NUMERICAL.
     */
    function getGradingTypeForGradeLevel(int $gradeCode): string
    {
        if ($gradeCode <= 0) {
            return 'KINDERGARTEN';
        }
        if ($gradeCode <= 3) {
            return 'DESCRIPTIVE';
        }
        return 'NUMERICAL';
    }
}

/* ============================================================
   geDescriptiveEquivalents — single source of truth
   ============================================================ */
if (!function_exists('geDescriptiveEquivalents')) {
    /**
     * Rating code -> representative numeric value for descriptive ratings.
     *
     * Used ONLY to display a numeric equivalent on the grading sheet in
     * DESCRIPTIVE mode (K-3). This is the ONE place defining the values —
     * the Grading Sheet JavaScript receives them injected from here so the
     * browser can never silently diverge from the server.
     *
     * NOTE: these are display equivalents, not stored grades. Descriptive
     * records keep final_grade = 0 in tblgrades; the rating_code itself is
     * the official result.
     */
    function geDescriptiveEquivalents(): array
    {
        return ['A' => 95, 'P' => 90, 'AP' => 85, 'D' => 80, 'B' => 75];
    }
}

/* ============================================================
   lookupDescriptor — CRITICAL signature used by grading_engine.php
   ============================================================ */
if (!function_exists('lookupDescriptor')) {
    /**
     * Resolve the descriptor, remarks and rating code for a grade.
     *
     * $gradeCode  : 0 = Kindergarten, 1-12 = grade level code.
     * $finalGrade : numeric final grade (0-100) for NUMERICAL lookups, or a
     *               rating code string ('A', 'S', 'AP', ...) for the
     *               DESCRIPTIVE / KINDERGARTEN types. Numeric strings
     *               (e.g. "85") are treated as numbers.
     *
     * DESCRIPTIVE numeric input is mapped through the DepEd-equivalent
     * bands (>= 90 A, 85-89 P, 80-84 AP, 75-79 D, below 75 B) and the
     * matching rating_code row is fetched. KINDERGARTEN has no numeric
     * mapping (observational ratings only).
     *
     * Returns ['descriptor' => string, 'remarks' => string,
     *          'rating_code' => string|null]. Fallback when nothing
     * matches: empty descriptor, Passed/Failed from the >= 75 rule,
     * rating_code null. Cached per (gradeCode, input).
     */
    function lookupDescriptor(PDO $pdo, int $gradeCode, int|string $finalGrade): array
    {
        static $cache = [];

        // --- normalize input (number or rating code) -----------------------
        $mode         = 'number';
        $ratingCode   = null;
        $numericGrade = 0.0;

        if (is_string($finalGrade)) {
            $candidate = strtoupper(trim($finalGrade));
            if ($candidate !== '' && !is_numeric($candidate)) {
                $mode       = 'rating';
                $ratingCode = $candidate;
            } elseif ($candidate !== '') {
                $numericGrade = max(0.0, min(100.0, (float)$candidate));
            }
        } else {
            $numericGrade = max(0.0, min(100.0, (float)$finalGrade));
        }

        $cacheKey = $gradeCode . '|' . $mode . '|'
            . ($mode === 'rating' ? $ratingCode : number_format($numericGrade, 2, '.', ''));
        if (array_key_exists($cacheKey, $cache)) {
            return $cache[$cacheKey];
        }

        $gradingType = getGradingTypeForGradeLevel($gradeCode);
        $result      = null;

        try {
            if ($mode === 'rating') {
                // 1) Rating-code input (DESCRIPTIVE / KINDERGARTEN)
                $result = deFetchDescriptorByRating($pdo, $gradingType, $gradeCode, (string)$ratingCode);
            } elseif ($gradingType === 'NUMERICAL') {
                // 2) Numeric input against the NUMERICAL grade ranges
                $result = deFetchDescriptorByRange($pdo, $gradingType, $gradeCode, $numericGrade);
            } elseif ($gradingType === 'DESCRIPTIVE') {
                // 3) Numeric input for DESCRIPTIVE — DepEd-equivalent bands
                $mappedCode = $numericGrade >= 90 ? 'A'
                    : ($numericGrade >= 85 ? 'P'
                    : ($numericGrade >= 80 ? 'AP'
                    : ($numericGrade >= 75 ? 'D' : 'B')));
                $result = deFetchDescriptorByRating($pdo, $gradingType, $gradeCode, $mappedCode);
            }
            // 4) KINDERGARTEN numeric input — no mapping, falls to fallback.
        } catch (Throwable $e) {
            error_log('descriptor_engine: lookupDescriptor failed: ' . $e->getMessage());
        }

        // Fallback: nothing matched.
        if ($result === null) {
            $result = [
                'descriptor'  => '',
                'remarks'     => ($mode === 'number' && $numericGrade >= 75) ? 'Passed' : 'Failed',
                'rating_code' => null,
            ];
        }

        $cache[$cacheKey] = $result;
        return $result;
    }
}

/* ============================================================
   Private fetch helpers (safe, exception-free)
   ============================================================ */
if (!function_exists('deFetchDescriptorByRating')) {
    /**
     * Fetch one active descriptor row of a grading type by rating code,
     * limited to rows whose grade-level range covers $gradeCode.
     * Returns null when not found / on error.
     */
    function deFetchDescriptorByRating(PDO $pdo, string $gradingType, int $gradeCode, string $ratingCode): ?array
    {
        try {
            $stmt = $pdo->prepare(
                'SELECT descriptor, remarks, rating_code
                 FROM tbldescriptors
                 WHERE is_active = 1
                   AND grading_type = ?
                   AND (applies_to_grade_level_from IS NULL OR applies_to_grade_level_from <= ?)
                   AND (applies_to_grade_level_to IS NULL OR applies_to_grade_level_to >= ?)
                   AND rating_code = ?
                 ORDER BY sort_order ASC, id ASC
                 LIMIT 1'
            );
            $stmt->execute([$gradingType, $gradeCode, $gradeCode, $ratingCode]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row !== false) {
                return [
                    'descriptor'  => (string)$row['descriptor'],
                    'remarks'     => (string)$row['remarks'],
                    'rating_code' => ($row['rating_code'] !== null && $row['rating_code'] !== '')
                        ? (string)$row['rating_code'] : $ratingCode,
                ];
            }
        } catch (Throwable $e) {
            error_log('descriptor_engine: rating lookup failed: ' . $e->getMessage());
        }
        return null;
    }
}

if (!function_exists('deFetchDescriptorByRange')) {
    /**
     * Fetch one active descriptor row of a grading type whose
     * grade_from/grade_to range contains $finalGrade, limited to rows
     * whose grade-level range covers $gradeCode.
     * Returns null when not found / on error.
     */
    function deFetchDescriptorByRange(PDO $pdo, string $gradingType, int $gradeCode, float $finalGrade): ?array
    {
        try {
            $stmt = $pdo->prepare(
                'SELECT descriptor, remarks, rating_code
                 FROM tbldescriptors
                 WHERE is_active = 1
                   AND grading_type = ?
                   AND (applies_to_grade_level_from IS NULL OR applies_to_grade_level_from <= ?)
                   AND (applies_to_grade_level_to IS NULL OR applies_to_grade_level_to >= ?)
                   AND grade_from IS NOT NULL AND grade_to IS NOT NULL
                   AND ? >= grade_from AND ? <= grade_to
                 ORDER BY sort_order ASC, id ASC
                 LIMIT 1'
            );
            $stmt->execute([$gradingType, $gradeCode, $gradeCode, $finalGrade, $finalGrade]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row !== false) {
                return [
                    'descriptor'  => (string)$row['descriptor'],
                    'remarks'     => (string)$row['remarks'],
                    'rating_code' => ($row['rating_code'] !== null && $row['rating_code'] !== '')
                        ? (string)$row['rating_code'] : null,
                ];
            }
        } catch (Throwable $e) {
            error_log('descriptor_engine: range lookup failed: ' . $e->getMessage());
        }
        return null;
    }
}

/* ============================================================
   2) 3) 4) Convenience wrappers
   ============================================================ */
if (!function_exists('getDescriptorForGrade')) {
    /**
     * Convenience wrapper — returns only the descriptor string ('' if not found).
     */
    function getDescriptorForGrade(PDO $pdo, int $finalGrade, int $gradeCode): string
    {
        try {
            $result = lookupDescriptor($pdo, $gradeCode, $finalGrade);
            return (string)($result['descriptor'] ?? '');
        } catch (Throwable $e) {
            error_log('descriptor_engine: getDescriptorForGrade failed: ' . $e->getMessage());
            return '';
        }
    }
}

if (!function_exists('getRemarksForGrade')) {
    /**
     * Convenience wrapper — returns 'Passed' or 'Failed' ('' if not found).
     */
    function getRemarksForGrade(PDO $pdo, int $finalGrade, int $gradeCode): string
    {
        try {
            $result = lookupDescriptor($pdo, $gradeCode, $finalGrade);
            return (string)($result['remarks'] ?? '');
        } catch (Throwable $e) {
            error_log('descriptor_engine: getRemarksForGrade failed: ' . $e->getMessage());
            return '';
        }
    }
}

if (!function_exists('isPassed')) {
    /**
     * Convenience wrapper — true when the resolved remarks === 'Passed'.
     */
    function isPassed(PDO $pdo, int $finalGrade, int $gradeCode): bool
    {
        return getRemarksForGrade($pdo, $finalGrade, $gradeCode) === 'Passed';
    }
}

/* ============================================================
   5) getDescriptorsByType — full list for SuperAdmin Tab 3 filter
   ============================================================ */
if (!function_exists('getDescriptorsByType')) {
    /**
     * Full list of tbldescriptors rows for one grading type, ordered by
     * sort_order. $gradingType must be 'NUMERICAL', 'DESCRIPTIVE' or
     * 'KINDERGARTEN' (invalid input returns []). Cached per request.
     */
    function getDescriptorsByType(PDO $pdo, string $gradingType): array
    {
        static $cache = [];
        $gradingType = strtoupper(trim($gradingType));

        if (!in_array($gradingType, ['NUMERICAL', 'DESCRIPTIVE', 'KINDERGARTEN'], true)) {
            error_log('descriptor_engine: invalid grading type requested: ' . $gradingType);
            return [];
        }
        if (array_key_exists($gradingType, $cache)) {
            return $cache[$gradingType];
        }

        $rows = [];
        try {
            $stmt = $pdo->prepare(
                'SELECT id, grade_from, grade_to, descriptor, grading_type, rating_code,
                        remarks, applies_to_grade_level_from, applies_to_grade_level_to,
                        is_active, sort_order
                 FROM tbldescriptors
                 WHERE grading_type = ?
                 ORDER BY sort_order ASC, id ASC'
            );
            $stmt->execute([$gradingType]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {
            error_log('descriptor_engine: list by type failed: ' . $e->getMessage());
            $rows = [];
        }

        $cache[$gradingType] = $rows;
        return $rows;
    }
}