<?php

return [
    'CORE' => [
        'label' => 'Core (English, Math, Science, Filipino, AP)',
        'ww' => 20,
        'pt' => 50,
        'qa' => 30,
    ],
    'EPP_TLE' => [
        'label' => 'EPP / TLE',
        'ww' => 20,
        'pt' => 60,
        'qa' => 20,
    ],
    'GMRC' => [
        'label' => 'GMRC / Values Education',
        'ww' => 20,
        'pt' => 50,
        'qa' => 30,
    ],
    'MAPEH' => [
        'label' => 'MAPEH (Music/Arts, PE/Health)',
        'ww' => 20,
        'pt' => 60,
        'qa' => 20,
    ],
];
