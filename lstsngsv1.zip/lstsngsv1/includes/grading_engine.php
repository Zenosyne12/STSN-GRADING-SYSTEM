<?php
/**
 * includes/grading_engine.php
 * ---------------------------------------------------------------------
 * Single source of truth for dynamic grade computation.
 *
 * Reads from (all SuperAdmin-configurable):
 *   - tblgrading_template  — component weights (WW/PT/QA), passing
 *                            threshold, rounding rule
 *   - tbltransmutation     — initial grade -> transmuted final grade
 *   - tbldescriptors       — descriptor lookup (3 grading types:
 *                            NUMERICAL, DESCRIPTIVE, KINDERGARTEN)
 *
 * Conventions:
 *   - $gradeLevelId is a tblgradelevel id (1=Kindergarten, 2=Grade 1,
 *     ... 13=Grade 12). It is resolved to a grade code (0-12) via
 *     tblgradelevel.grade_level_code; if that table is unavailable the
 *     raw id is used as-is. Template/descriptor "applies_to_*" ranges
 *     store grade CODES (0-12), not ids.
 *   - All queries are PDO prepared statements.
 *   - No exceptions escape this file: failures are logged via error_log()
 *     and safe defaults (null / zeroed arrays) are returned.
 *   - Results are cached per request through static variables.
 *
 * Descriptor engine delegation:
 *   If includes/descriptor_engine.php exists and defines lookupDescriptor(),
 *   it is included once and receives priority:
 *       lookupDescriptor(PDO $pdo, int $gradeCode, int $finalGrade): array
 *       => ['descriptor' => string, 'remarks' => string]
 *   Otherwise the internal fallback below queries tbldescriptors directly.
 * ---------------------------------------------------------------------
 */

if (is_file(__DIR__ . '/descriptor_engine.php')) {
    require_once __DIR__ . '/descriptor_engine.php';
}

/**
 * Resolve a grade code (0=Kindergarten, 1-12) from a grade level id.
 * Falls back to the raw id when tblgradelevel is unavailable.
 */
function geResolveGradeCode(PDO $pdo, int $gradeLevelId): int
{
    static $cache = [];
    if ($gradeLevelId <= 0) {
        return 0;
    }
    if (array_key_exists($gradeLevelId, $cache)) {
        return $cache[$gradeLevelId];
    }

    $code = $gradeLevelId; // safe fallback: treat the id as the code
    try {
        $stmt = $pdo->prepare('SELECT grade_level_code FROM tblgradelevel WHERE id = ? LIMIT 1');
        $stmt->execute([$gradeLevelId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row !== false && $row['grade_level_code'] !== null) {
            $code = (int)$row['grade_level_code'];
        }
    } catch (Throwable $e) {
        error_log('grading_engine: grade code lookup failed: ' . $e->getMessage());
    }

    $cache[$gradeLevelId] = max(0, $code);
    return $cache[$gradeLevelId];
}

/**
 * Resolve the active grading template for a grade level (and program).
 *
 * Precedence:
 *   1. is_active template matching program_id + grade range
 *   2. is_active template matching grade range only (system-wide)
 *   3. is_default = 1
 *   4. any is_active = 1 (oldest first)
 *
 * Returns null when no template exists. Cached per request.
 */
function getActiveGradingTemplate(PDO $pdo, int $gradeLevelId, ?int $programId = null): ?array
{
    static $cache = [];
    $cacheKey = $gradeLevelId . '|' . ($programId !== null ? $programId : 'any');
    if (array_key_exists($cacheKey, $cache)) {
        return $cache[$cacheKey];
    }

    $gradeCode = geResolveGradeCode($pdo, $gradeLevelId);

    // NULL range bounds mean "all grade levels".
    $gradeMatch =
        '(applies_to_grade_from IS NULL OR applies_to_grade_from <= :code_from)
         AND (applies_to_grade_to IS NULL OR applies_to_grade_to >= :code_to)';

    $columns =
        'id, template_name, ww_weight, pt_weight, qa_weight, passing_threshold,
         rounding_rule, is_default, is_active, applies_to_program_id,
         applies_to_grade_from, applies_to_grade_to';

    // The most recently CONFIGURED applicable template must win when several
    // active templates overlap (updated_at is bumped on every save), so the
    // queries below order by updated_at DESC — NOT id ASC, which let the
    // oldest seeded template silently override newer configuration.
    $orderNewest = 'ORDER BY updated_at DESC, id DESC LIMIT 1';

    $queries = [];

    // 1) Program + grade range match
    if ($programId !== null && $programId > 0) {
        $queries[] = [
            "SELECT {$columns} FROM tblgrading_template
             WHERE is_active = 1 AND applies_to_program_id = :program_id AND {$gradeMatch}
             {$orderNewest}",
            [':program_id' => $programId, ':code_from' => $gradeCode, ':code_to' => $gradeCode],
        ];
    }

    // 2) Grade range only (system-wide templates)
    $queries[] = [
        "SELECT {$columns} FROM tblgrading_template
         WHERE is_active = 1 AND applies_to_program_id IS NULL AND {$gradeMatch}
         {$orderNewest}",
        [':code_from' => $gradeCode, ':code_to' => $gradeCode],
    ];

    // 3) Configured default template — MUST still be active. Without the
    //    is_active filter an old inactive default template would keep
    //    overriding the currently configured applicable templates.
    $queries[] = [
        "SELECT {$columns} FROM tblgrading_template
         WHERE is_default = 1 AND is_active = 1
         {$orderNewest}",
        [],
    ];

    // 4) Any active template (newest first as a last resort)
    $queries[] = [
        "SELECT {$columns} FROM tblgrading_template
         WHERE is_active = 1
         {$orderNewest}",
        [],
    ];

    $template = null;
    foreach ($queries as [$sql, $bindings]) {
        try {
            $stmt = $pdo->prepare($sql);
            $stmt->execute($bindings);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row !== false) {
                $template = [
                    'id'                => (int)$row['id'],
                    'template_name'     => (string)$row['template_name'],
                    'ww_weight'         => (float)$row['ww_weight'],
                    'pt_weight'         => (float)$row['pt_weight'],
                    'qa_weight'         => (float)$row['qa_weight'],
                    'passing_threshold' => (int)$row['passing_threshold'],
                    'rounding_rule'     => strtoupper((string)($row['rounding_rule'] ?? 'ROUND')),
                    'is_default'        => (int)$row['is_default'],
                    'is_active'         => (int)$row['is_active'],
                ];
                break;
            }
        } catch (Throwable $e) {
            error_log('grading_engine: template lookup failed: ' . $e->getMessage());
        }
    }

    // Debug trace (safe: no student data) — confirms which template was
    // actually selected during development/support.
    error_log(
        'grading_engine: selected template=' . ($template['id'] ?? 'NULL')
        . ', name=' . ($template['template_name'] ?? 'NONE')
        . ', gradeCode=' . $gradeCode
        . ', programId=' . ($programId !== null ? $programId : 'NULL')
    );

    // Cache even null results so repeated calls stay cheap.
    $cache[$cacheKey] = $template;
    return $template;
}

/**
 * Fetch the transmutation table (initial -> transmuted brackets) of a
 * template, ordered by min_initial DESC (highest bracket first).
 *
 * Returns [] when the template has no rows. Cached per request.
 */
function getTransmutationTable(PDO $pdo, int $templateId): array
{
    static $cache = [];
    if ($templateId <= 0) {
        return [];
    }
    if (array_key_exists($templateId, $cache)) {
        return $cache[$templateId];
    }

    $table = [];
    try {
        $stmt = $pdo->prepare(
            'SELECT min_initial, max_initial, transmuted_grade
             FROM tbltransmutation
             WHERE template_id = ?
             ORDER BY min_initial DESC, sort_order ASC, id ASC'
        );
        $stmt->execute([$templateId]);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $table[] = [
                'min'        => (float)$row['min_initial'],
                'max'        => (float)$row['max_initial'],
                'transmuted' => (int)$row['transmuted_grade'],
            ];
        }
    } catch (Throwable $e) {
        error_log('grading_engine: transmutation lookup failed: ' . $e->getMessage());
        $table = [];
    }

    $cache[$templateId] = $table;
    return $table;
}

/**
 * Apply a transmutation table to an initial grade.
 * First bracket (highest min first) whose [min, max] contains the initial
 * grade wins. If no bracket matches, falls back to round($initial),
 * clamped to the 0-100 DepEd grade scale.
 */
function transmuteGrade(float $initial, array $transmutationTable): int
{
    foreach ($transmutationTable as $bracket) {
        $min = (float)($bracket['min'] ?? 0);
        $max = (float)($bracket['max'] ?? 0);
        if ($initial >= $min && $initial <= $max) {
            return (int)($bracket['transmuted'] ?? 0);
        }
    }
    return max(0, min(100, (int)round($initial)));
}

/**
 * Percentage Score (PS) and Weighted Score (WS) of one component.
 *   PS = (rawTotal / hps) * 100   (0 when hps is 0)
 *   WS = PS * (weight / 100)
 */
function computeWeightedScore(float $rawTotal, float $hps, float $weight): array
{
    $ps = ($hps > 0) ? ($rawTotal / $hps) * 100 : 0.0;
    $ws = $ps * ($weight / 100);
    return ['ps' => $ps, 'ws' => $ws];
}

/**
 * Apply a template's rounding rule to a value.
 *   ROUND -> nearest integer, CEIL -> always up, FLOOR -> always down.
 * Unknown/blank rules fall back to ROUND.
 */
function applyRounding(float $value, string $rule): float
{
    switch (strtoupper(trim($rule))) {
        case 'CEIL':
            return (float)ceil($value);
        case 'FLOOR':
            return (float)floor($value);
        case 'ROUND':
        default:
            return round($value, 0);
    }
}

/**
 * Descriptor + remarks lookup for a final grade.
 *
 * 1) Delegates to includes/descriptor_engine.php::lookupDescriptor() when
 *    that file defines the function:
 *        lookupDescriptor(PDO $pdo, int $gradeCode, int $finalGrade): array
 * 2) Internal fallback: queries tbldescriptors for the grading type implied
 *    by the grade code (0 = KINDERGARTEN, 1-3 = DESCRIPTIVE, 4-12 =
 *    NUMERICAL) and returns the first active row whose grade_from/grade_to
 *    range contains the final grade.
 * 3) Safe default when nothing matches (also covers DESCRIPTIVE /
 *    KINDERGARTEN sets, which do not use numeric ranges): empty descriptor
 *    plus Passed/Failed derived from the passing threshold.
 *
 * Always returns ['descriptor' => string, 'remarks' => string]. Cached.
 */
function geLookupDescriptor(PDO $pdo, int $gradeCode, int $finalGrade, int $passingThreshold = 75): array
{
    static $cache = [];
    $cacheKey = $gradeCode . '|' . $finalGrade . '|' . $passingThreshold;
    if (array_key_exists($cacheKey, $cache)) {
        return $cache[$cacheKey];
    }

    $result = null;

    // 1) Delegate to the dedicated descriptor engine when available.
    if (function_exists('lookupDescriptor')) {
        try {
            $delegated = lookupDescriptor($pdo, $gradeCode, $finalGrade);
            if (is_array($delegated) && isset($delegated['descriptor'], $delegated['remarks'])) {
                $result = [
                    'descriptor' => (string)$delegated['descriptor'],
                    'remarks'    => (string)$delegated['remarks'],
                ];
            }
        } catch (Throwable $e) {
            error_log('grading_engine: descriptor engine delegation failed: ' . $e->getMessage());
        }
    }

    // 2) Internal fallback: direct tbldescriptors query.
    if ($result === null) {
        $gradingType = ($gradeCode === 0) ? 'KINDERGARTEN' : ($gradeCode <= 3 ? 'DESCRIPTIVE' : 'NUMERICAL');
        try {
            $stmt = $pdo->prepare(
                'SELECT descriptor, remarks
                 FROM tbldescriptors
                 WHERE is_active = 1
                   AND grading_type = ?
                   AND (applies_to_grade_level_from IS NULL OR applies_to_grade_level_from <= ?)
                   AND (applies_to_grade_level_to IS NULL OR applies_to_grade_level_to >= ?)
                   AND grade_from IS NOT NULL AND grade_to IS NOT NULL
                   AND ? >= grade_from AND ? <= grade_to
                 ORDER BY sort_order ASC, id ASC
                 LIMIT 1'
            );
            $stmt->execute([$gradingType, $gradeCode, $gradeCode, $finalGrade, $finalGrade]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row !== false) {
                $result = [
                    'descriptor' => (string)$row['descriptor'],
                    'remarks'    => (string)$row['remarks'],
                ];
            }
        } catch (Throwable $e) {
            error_log('grading_engine: descriptor lookup failed: ' . $e->getMessage());
        }
    }

    // 3) Safe default.
    if ($result === null) {
        $result = [
            'descriptor' => '',
            'remarks'    => ($passingThreshold > 0 && $finalGrade >= $passingThreshold) ? 'Passed' : 'Failed',
        ];
    }

    $cache[$cacheKey] = $result;
    return $result;
}

/**
 * Full grade computation for one learner/subject/quarter.
 *
 * $params = [
 *   'ww_total', 'pt_total', 'qa_total',   raw component scores
 *   'hps_ww', 'hps_pt', 'hps_qa',         highest possible scores
 *   'grade_level_id',                     tblgradelevel id
 *   'program_id'                          optional
 * ]
 *
 * Steps: resolve template -> PS/WS per component -> initial grade ->
 * rounding rule -> transmute -> descriptor lookup.
 *
 * Always returns the full result array; safe zeroed defaults are returned
 * (with an error_log entry) when no template is available or a query fails.
 */
function computeFinalGrade(PDO $pdo, array $params): array
{
    $defaults = [
        'ww_ps'         => 0.0,
        'ww_ws'         => 0.0,
        'pt_ps'         => 0.0,
        'pt_ws'         => 0.0,
        'qa_ps'         => 0.0,
        'qa_ws'         => 0.0,
        'initial_grade' => 0.0,
        'final_grade'   => 0,
        'descriptor'    => '',
        'remarks'       => '',
        'template_id'   => 0,
        'template_name' => '',
    ];

    try {
        $gradeLevelId = (int)($params['grade_level_id'] ?? 0);
        $programId    = (isset($params['program_id']) && $params['program_id'] !== null) ? (int)$params['program_id'] : null;

        $template = getActiveGradingTemplate($pdo, $gradeLevelId, $programId);
        if ($template === null) {
            error_log('grading_engine: no active grading template found — returning safe defaults.');
            return $defaults;
        }

        $ww = computeWeightedScore(
            (float)($params['ww_total'] ?? 0),
            (float)($params['hps_ww'] ?? 0),
            $template['ww_weight']
        );
        $pt = computeWeightedScore(
            (float)($params['pt_total'] ?? 0),
            (float)($params['hps_pt'] ?? 0),
            $template['pt_weight']
        );
        $qa = computeWeightedScore(
            (float)($params['qa_total'] ?? 0),
            (float)($params['hps_qa'] ?? 0),
            $template['qa_weight']
        );

        // Initial Grade = WW_WS + PT_WS + QA_WS, then apply the template's
        // rounding rule and clamp to the 0-100 DepEd scale before transmuting.
        $initialGrade = $ww['ws'] + $pt['ws'] + $qa['ws'];
        $roundedGrade = applyRounding($initialGrade, $template['rounding_rule']);
        $roundedGrade = max(0.0, min(100.0, $roundedGrade));

        $transTable = getTransmutationTable($pdo, (int)$template['id']);
        $finalGrade = transmuteGrade($roundedGrade, $transTable);

        $gradeCode  = geResolveGradeCode($pdo, $gradeLevelId);
        $descriptor = geLookupDescriptor($pdo, $gradeCode, $finalGrade, (int)$template['passing_threshold']);

        // Remarks follow the ACTIVE TEMPLATE's passing rule (the configured
        // passing_threshold) — NOT a descriptor band — so changing the
        // threshold on the Grading Templates page flips Passed/Failed on the
        // next sheet load while leaving the score itself untouched.
        $remarks = ((int)$template['passing_threshold'] > 0 && $finalGrade >= (int)$template['passing_threshold'])
            ? 'Passed'
            : 'Failed';

        return [
            'ww_ps'         => $ww['ps'],
            'ww_ws'         => $ww['ws'],
            'pt_ps'         => $pt['ps'],
            'pt_ws'         => $pt['ws'],
            'qa_ps'         => $qa['ps'],
            'qa_ws'         => $qa['ws'],
            'initial_grade' => $roundedGrade,
            'final_grade'   => $finalGrade,
            'descriptor'    => $descriptor['descriptor'],
            'remarks'       => $remarks,
            'template_id'   => (int)$template['id'],
            'template_name' => (string)$template['template_name'],
        ];
    } catch (Throwable $e) {
        error_log('grading_engine: computeFinalGrade failed: ' . $e->getMessage());
        return $defaults;
    }
}

/**
 * Resolve the program id of a section for program-specific template matching.
 *
 * The template table supports `applies_to_program_id`, but this database does
 * NOT yet contain a program entity (only a free-text `strand` on tblsection).
 * The resolver therefore returns null today and automatically starts
 * resolving once a `tblprograms` table (with id + a program_id link on
 * tblsection) is introduced — no other code has to change.
 */
function geResolveProgramId(PDO $pdo, int $sectionId): ?int
{
    static $hasProgramTable = null;
    if ($hasProgramTable === null) {
        try {
            $hasProgramTable = (bool)$pdo->query("SHOW TABLES LIKE 'tblprograms'")->fetchColumn();
        } catch (Throwable $e) {
            $hasProgramTable = false;
        }
    }
    if (!$hasProgramTable || $sectionId <= 0) {
        return null;
    }
    try {
        $stmt = $pdo->prepare(
            'SELECT p.id FROM tblprograms p
             JOIN tblsection s ON s.applies_to_program_id = p.id
             WHERE s.id = ? LIMIT 1'
        );
        $stmt->execute([$sectionId]);
        $id = $stmt->fetchColumn();
        return $id !== false ? (int)$id : null;
    } catch (Throwable $e) {
        // Unknown column layout — treat as "no program reference".
        return null;
    }
}

/**
 * Active descriptor/rating options applicable to a grade level.
 *
 * Reads tbldescriptors (single source of truth edited on the Grading
 * Templates page) for the grading type implied by the grade code:
 *   0 = KINDERGARTEN, 1-3 = DESCRIPTIVE, 4-12 = NUMERICAL.
 *
 * Returns an ordered list of:
 *   ['rating_code' => 'A', 'descriptor' => 'Advance', 'remarks' => 'Passed', ...]
 * ([] when nothing is configured — callers apply their legacy fallback).
 */
function geGetRatingOptions(PDO $pdo, int $gradeLevelId): array
{
    $gradeCode = geResolveGradeCode($pdo, $gradeLevelId);
    $gradingType = function_exists('getGradingTypeForGradeLevel')
        ? getGradingTypeForGradeLevel($gradeCode)
        : ($gradeCode <= 0 ? 'KINDERGARTEN' : ($gradeCode <= 3 ? 'DESCRIPTIVE' : 'NUMERICAL'));

    try {
        $stmt = $pdo->prepare(
            'SELECT id, rating_code, descriptor, remarks, grade_from, grade_to, sort_order
             FROM tbldescriptors
             WHERE is_active = 1
               AND grading_type = ?
               AND (applies_to_grade_level_from IS NULL OR applies_to_grade_level_from <= ?)
               AND (applies_to_grade_level_to IS NULL OR applies_to_grade_level_to >= ?)
             ORDER BY sort_order ASC, id ASC'
        );
        $stmt->execute([$gradingType, $gradeCode, $gradeCode]);
        $options = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $options[] = [
                'id'          => (int)$row['id'],
                'rating_code' => (string)$row['rating_code'],
                'descriptor'  => (string)$row['descriptor'],
                'remarks'     => (string)$row['remarks'],
                'grade_from'  => $row['grade_from'] !== null ? (float)$row['grade_from'] : null,
                'grade_to'    => $row['grade_to'] !== null ? (float)$row['grade_to'] : null,
                'sort_order'  => (int)$row['sort_order'],
            ];
        }
        return $options;
    } catch (Throwable $e) {
        error_log('grading_engine: rating options lookup failed: ' . $e->getMessage());
        return [];
    }
}