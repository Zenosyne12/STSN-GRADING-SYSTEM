<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/api/shared/db_connect.php';

$activeYearLabel = '';
try {
    $stmtActive      = $pdo->query("SELECT year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
    $activeYearLabel = $stmtActive ? (string)$stmtActive->fetchColumn() : '';
} catch (Throwable $e) { $activeYearLabel = ''; }

$activeQuarter = null;
try {
    $stmt = $pdo->query("
        SELECT q.*, ay.year_label
        FROM tblquarters q
        JOIN tblacademicyear ay ON q.academic_year_id = ay.id
        WHERE q.is_active = 1 LIMIT 1
    ");
    $activeQuarter = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $activeQuarter = null; }

$allYears = [];
try {
    $allYears = $pdo->query("SELECT id, year_label, is_active FROM tblacademicyear ORDER BY year_label DESC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $allYears = []; }

$allGradeLevels = [];
try {
    $allGradeLevels = $pdo->query("SELECT id, grade_level_name, grade_level_code FROM tblgradelevel ORDER BY sort_order ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $allGradeLevels = []; }

$viewYearId  = isset($_GET['view_year']) ? (int)$_GET['view_year'] : null;
$viewingYear = null;
if ($viewYearId) {
    $stmt = $pdo->prepare("SELECT id, year_label, is_active FROM tblacademicyear WHERE id = ?");
    $stmt->execute([$viewYearId]);
    $viewingYear = $stmt->fetch(PDO::FETCH_ASSOC);
}
if (!$viewingYear) {
    $stmt = $pdo->query("SELECT id, year_label, is_active FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
    $viewingYear = $stmt->fetch(PDO::FETCH_ASSOC);
}
if (!$viewingYear && $allYears) { $viewingYear = $allYears[0]; }
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>STSN Grading System | Grades Report</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">

    <style>
        /* â”€â”€ SCREEN â”€â”€ */
        body { background:#f3f7fd; }
        .ay-page-header { background:linear-gradient(130deg,#1248a8 0%,#1a6ef5 100%); border-radius:16px; padding:1.4rem 1.6rem; color:#fff; margin-bottom:1.25rem; display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:1rem; }
        .ay-page-header h3 { font-size:1.25rem; font-weight:700; margin:0 0 .2rem; }
        .ay-page-header p  { margin:0; font-size:.88rem; opacity:.85; }
        .ay-active-chip { display:inline-flex; align-items:center; gap:.45rem; background:rgba(255,255,255,.15); border:1.5px solid rgba(255,255,255,.3); border-radius:999px; padding:.45rem 1rem; font-size:.88rem; font-weight:700; color:#fff; white-space:nowrap; }
        .ay-card { background:#fff; border:1px solid #dce8f8; border-radius:16px; box-shadow:0 2px 12px rgba(18,72,168,.06); overflow:hidden; margin-bottom:1.5rem; }
        .ay-card-header { padding:1.1rem 1.4rem; border-bottom:1px solid #e8f0fb; display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:.75rem; background:#fff; }
        .ay-card-title  { font-size:1rem; font-weight:700; color:#132f62; margin:0 0 .15rem; }
        .ay-card-subtitle { font-size:.8rem; color:#7a93b8; margin:0; }
        .ay-card-footer { padding:.75rem 1.2rem; border-top:1px solid #e8f0fb; background:#fafcff; display:flex; justify-content:space-between; align-items:center; gap:.75rem; flex-wrap:wrap; }
        .ay-footer-note { font-size:.82rem; color:#7a93b8; }
        .ay-table { width:100%; border-collapse:collapse; }
        .ay-table thead th { background:#f4f8ff; color:#3b5e96; font-size:.75rem; font-weight:700; text-transform:uppercase; letter-spacing:.06em; padding:.85rem 1.2rem; border-bottom:1.5px solid #dce8f8; white-space:nowrap; }
        .ay-table tbody tr:not(:last-child) td { border-bottom:1px solid #f0f5fc; }
        .ay-table tbody tr:hover td { background:#f7fbff; }
        .ay-table tbody td { padding:.9rem 1.2rem; font-size:.93rem; color:#213a5e; vertical-align:middle; }
        .btn-ay { font-weight:600; font-size:.82rem; border-radius:8px; padding:.42rem .9rem; cursor:pointer; transition:all .14s; border:1.5px solid transparent; line-height:1.4; }
        .btn-ay-primary { background:linear-gradient(130deg,#1a6ef5,#1248a8); color:#fff; box-shadow:0 2px 8px rgba(26,110,245,.2); }
        .btn-ay-primary:hover { background:linear-gradient(130deg,#1560d8,#103d90); color:#fff; }
        .btn-ay-outline { background:#fff; color:#1a6ef5; border-color:#dce8f8; }
        .btn-ay-outline:hover { background:#eef4ff; border-color:#9cc2fc; }
        .btn-ay-success { background:#ecfdf5; color:#065f46; border-color:#a7f3d0; }
        .btn-ay-success:hover { background:#d1fae5; border-color:#6ee7b7; }
        .btn-ay-sm { padding:.28rem .65rem; font-size:.78rem; }
        .ay-badge { display:inline-flex; align-items:center; gap:.3rem; padding:.32rem .75rem; border-radius:999px; font-size:.78rem; font-weight:700; letter-spacing:.03em; }
        .ay-badge-passed { background:#d1fae5; color:#065f46; border:1.5px solid #a7f3d0; }
        .ay-badge-failed { background:#fee2e2; color:#991b1b; border:1.5px solid #fecaca; }
        .ay-badge-conditional { background:#fef3c7; color:#92400e; border:1.5px solid #fde68a; }
        .ay-pagination { display:flex; gap:.3rem; list-style:none; margin:0; padding:0; justify-content:flex-end; align-items:center; flex-wrap:wrap; }
        .ay-pagination .ay-page-item .ay-page-link { display:inline-flex; align-items:center; justify-content:center; min-width:32px; height:32px; border-radius:7px; font-size:.83rem; font-weight:600; cursor:pointer; border:1.5px solid #dce8f8; color:#1a6ef5; background:#fff; transition:all .13s; padding:0 .65rem; }
        .ay-pagination .ay-page-item .ay-page-link:hover { background:#eef4ff; border-color:#9cc2fc; }
        .ay-pagination .ay-page-item.active .ay-page-link { background:#1a6ef5; border-color:#1a6ef5; color:#fff; }
        .ay-pagination .ay-page-item.disabled .ay-page-link { background:#f8fbff; border-color:#e2ebf8; color:#9ab0c8; cursor:not-allowed; pointer-events:none; }
        .ay-select { border:1.5px solid #c8daf8; border-radius:10px; padding:.42rem .85rem; font-size:.88rem; color:#213a5e; background:#fff; cursor:pointer; }
        .ay-select:focus { border-color:#1a6ef5; outline:none; box-shadow:0 0 0 3px rgba(26,110,245,.1); }
        .ay-empty { text-align:center; padding:2.5rem 1.5rem; color:#9ab0c8; }
        .ay-empty i { font-size:2.2rem; display:block; margin-bottom:.6rem; opacity:.5; }
        .ay-empty p { margin:0; font-size:.95rem; }
        .gr-level-badge { font-size:.7rem; font-weight:700; padding:.25rem .7rem; border-radius:20px; white-space:nowrap; }
        .gl-k{background:#fce7f3;color:#9d174d;}.gl-1{background:#dbeafe;color:#1e40af;}.gl-2{background:#d1fae5;color:#065f46;}.gl-3{background:#fef3c7;color:#92400e;}.gl-4{background:#ede9fe;color:#4c1d95;}.gl-5{background:#ccfbf1;color:#0f766e;}.gl-6{background:#ffedd5;color:#9a3412;}.gl-7{background:#e0e7ff;color:#3730a3;}.gl-8{background:#dcfce7;color:#15803d;}.gl-9{background:#fef9c3;color:#854d0e;}.gl-10{background:#fae8ff;color:#86198f;}.gl-11{background:#cffafe;color:#155e75;}.gl-12{background:#fee2e2;color:#991b1b;}
        .gr-avg-pill { display:inline-block; font-size:.74rem; font-weight:700; padding:.18rem .55rem; border-radius:10px; }
        .avg-high{background:#d1fae5;color:#065f46;}.avg-mid{background:#fef3c7;color:#92400e;}.avg-low{background:#fee2e2;color:#991b1b;}
        .gr-search-wrap{position:relative;}.gr-search-wrap i{position:absolute;left:.65rem;top:50%;transform:translateY(-50%);color:#a0aec0;font-size:.85rem;pointer-events:none;}
        .gr-search-input{height:36px;padding:0 .75rem 0 2rem;border:1.5px solid #c8daf8;border-radius:10px;background:#fff;color:#213a5e;font-size:.85rem;outline:none;width:210px;font-family:inherit;}
        .gr-search-input:focus{border-color:#1a6ef5;box-shadow:0 0 0 3px rgba(26,110,245,.1);}
        .gr-select{height:36px;padding:0 .65rem;border:1.5px solid #c8daf8;border-radius:10px;background:#fff;color:#213a5e;font-size:.85rem;outline:none;font-family:inherit;cursor:pointer;}
        .gr-select:focus{border-color:#1a6ef5;box-shadow:0 0 0 3px rgba(26,110,245,.1);}
        .ay-mobile-card{background:#fff;border:1.5px solid #dce8f8;border-radius:14px;overflow:hidden;box-shadow:0 1px 6px rgba(18,72,168,.05);}
        .ay-mobile-card+.ay-mobile-card{margin-top:.75rem;}
        .ay-mobile-card-header{display:flex;align-items:center;justify-content:space-between;padding:.85rem 1rem;border-bottom:1px solid #edf3fc;background:#f9fbff;}
        .ay-mobile-card-title{font-weight:700;color:#132f62;font-size:.95rem;}
        .ay-mobile-card-body{padding:.85rem 1rem;}
        .ay-mobile-card-body .grade-label{font-size:.82rem;color:#6b84a2;margin-bottom:.65rem;}
        @media(max-width:767.98px){.ay-page-header{padding:1.1rem 1.2rem;border-radius:14px;}.ay-card-footer{justify-content:center;}.ay-pagination{justify-content:center;}}

        /* â”€â”€ DepEd Class Record table â”€â”€ */
        .cr-wrap { overflow-x: auto; }
        .cr-table { border-collapse: collapse; font-size: 8.5pt; font-family: Arial, sans-serif; min-width: 100%; background: #fff; }
        .cr-table th, .cr-table td { border: 1px solid #aab8cc; }
        .cr-num { width: 28px; text-align: center; font-size: 8pt; color: #555; padding: 3px 2px; }
        .cr-name-th { min-width: 200px; padding: 5px 10px; font-size: 9.5pt; font-weight: 700; color: #132f62; background: #f0f4ff; vertical-align: bottom; }
        .cr-name { min-width: 200px; padding: 4px 8px; font-size: 9pt; }
        .cr-grade { width: 46px; text-align: center; padding: 4px 2px; font-size: 9pt; }
        .cr-avg { width: 72px; text-align: center; font-weight: 700; padding: 4px 3px; font-size: 9pt; }
        /* Angled header */
        .cr-angled-th {
            height: 95px;
            width: 46px;
            position: relative;
            vertical-align: bottom;
            padding: 0;
            border: 1px solid #aab8cc;
            overflow: hidden;
            background: #f0f4ff;
        }
        .cr-angled-th .cr-th-inner {
            display: block;
            transform-origin: bottom left;
            transform: rotate(-55deg);
            white-space: nowrap;
            font-size: 8pt;
            font-weight: 700;
            padding: 2px 4px;
            position: absolute;
            bottom: 8px;
            left: 10px;
            color: #132f62;
            line-height: 1.2;
        }
        .cr-avg-th {
            width: 72px;
            text-align: center;
            font-size: 9pt;
            font-weight: 700;
            background: #f0f4ff;
            color: #132f62;
            vertical-align: bottom;
            padding: 5px 3px;
        }
        .cr-header-num {
            text-align: center;
            font-size: 8pt;
            font-weight: 700;
            padding: 3px 2px;
            background: #e8eef8;
            color: #3b5e96;
        }
        .cr-row-group {
            background: #d0d8e8;
            font-weight: 700;
            font-size: 8.5pt;
        }
        .cr-row-group td {
            padding: 3px 8px;
            color: #132f62;
            letter-spacing: .04em;
        }
        .cr-pass { color: #059669; font-weight: 700; }
        .cr-fail { color: #dc2626; font-weight: 700; }
        .cr-avg-cell { background: #f4f8ff; font-weight: 700; }
        .cr-empty-row td { background: #fff; }
        .cr-empty-row:nth-child(even) td { background: #fafcff; }
        .cr-num-th { width: 28px; text-align: center; font-size: 8pt; font-weight: 700; background: #f0f4ff; color: #3b5e96; vertical-align: bottom; padding: 5px 2px; }

        #printArea { display:none; }

        @media print {
            @page { size:216mm 279mm; margin:0; }
            body > *:not(#printArea) { display:none !important; }
            html,body { width:216mm; height:279mm; margin:0; padding:0; background:#fff; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
            #printArea { display:block !important; width:216mm; margin:0; padding:0; }
            .rc-page { width:216mm; height:279mm; padding:7mm 9mm 6mm 9mm; box-sizing:border-box; overflow:hidden; page-break-after:always; page-break-inside:avoid; break-after:page; break-inside:avoid; display:flex; flex-direction:column; background:#fff; }
            .rc-page:last-child { page-break-after:avoid; break-after:avoid; }
            .rc-page > .sf9-wrap { flex:1; min-height:0; width:100%; box-sizing:border-box; }
        }

        #printArea { font-family:Arial,Helvetica,sans-serif; font-size:9pt; color:#000; background:#fff; }
        .rc-page { page-break-after:always; break-after:page; position:relative; }
        .rc-page:last-child { page-break-after:avoid; break-after:avoid; }
        .rc-page-label { position:absolute; top:0; left:0; font-size:6pt; color:#888; }
        .sf9-wrap { width:100%; height:100%; display:flex; flex-direction:column; box-sizing:border-box; }
        .sf9-top { display:flex; flex:1; min-height:0; }
        .sf9-left { flex:1.05; border-right:1.5px solid #000; padding:0 7px 0 0; display:flex; flex-direction:column; box-sizing:border-box; overflow:hidden; }
        .sf9-right { flex:0.95; padding:0 0 0 7px; display:flex; flex-direction:column; box-sizing:border-box; overflow:hidden; }
        .sf9-sec { text-align:center; font-weight:bold; font-size:8pt; border-top:1.5px solid #000; border-bottom:1.5px solid #000; padding:2.5px 0; margin:5px 0 3px; text-transform:uppercase; letter-spacing:.4px; }
        .sf9-gt { width:100%; border-collapse:collapse; font-size:8.5pt; }
        .sf9-gt th,.sf9-gt td { border:1px solid #000; padding:2px 4px; text-align:center; }
        .sf9-gt th { font-size:8pt; font-weight:bold; background:#f0f0f0; }
        .sf9-gt .sc { text-align:left; padding-left:5px; font-size:8pt; }
        .sf9-gt .fc { font-weight:bold; background:#f8f8f8; }
        .sf9-gt .fg { color:#cc0000; }
        .sf9-gt .pg { color:#000; }
        .sf9-dt { width:100%; border-collapse:collapse; font-size:8pt; margin-top:4px; }
        .sf9-dt th,.sf9-dt td { border:1px solid #000; padding:2px 5px; }
        .sf9-dt th { font-weight:bold; background:#f0f0f0; }
        .sf9-at { width:100%; border-collapse:collapse; font-size:7.5pt; margin-top:3px; }
        .sf9-at th,.sf9-at td { border:1px solid #000; padding:2.5px 2px; text-align:center; }
        .sf9-at th { background:#f0f0f0; font-weight:bold; font-size:7.5pt; }
        .sf9-at td.lft { text-align:left; padding-left:4px; white-space:nowrap; font-size:7.5pt; }
        .sf9-vt { width:100%; border-collapse:collapse; font-size:8pt; }
        .sf9-vt th,.sf9-vt td { border:1px solid #000; padding:2.5px 4px; }
        .sf9-vt th { font-size:7.5pt; font-weight:bold; text-align:center; background:#f0f0f0; }
        .sf9-vt .qc { text-align:center; width:18px; font-size:8pt; }
        .sf9-mt { width:100%; border-collapse:collapse; font-size:8pt; margin-top:5px; }
        .sf9-mt th,.sf9-mt td { border:1px solid #000; padding:2px 5px; }
        .sf9-mt th { font-weight:bold; background:#f0f0f0; }
        .shs-wrap { width:100%; height:100%; display:flex; flex-direction:column; box-sizing:border-box; }
        .shs-gt { width:100%; border-collapse:collapse; font-size:8.5pt; }
        .shs-gt th,.shs-gt td { border:1px solid #000; padding:2.5px 4px; }
        .shs-gt th { font-size:8pt; font-weight:bold; text-align:center; background:#f0f0f0; }
        .shs-gt .sc { text-align:left; padding-left:6px; }
        .shs-gt .ch td { font-weight:bold; font-size:8pt; background:#e8e8e8; font-style:italic; }
        .shs-gt .ar td { font-weight:bold; background:#e8e8e8; }
        .shs-gt .nc { text-align:center; }
        .shs-gt .fg { color:#cc0000; }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
    <?php require_once("includes/header.php"); ?>
    <?php require_once("includes/sidebar.php"); ?>
    <main class="app-main">
        <div class="app-content">
            <div class="container-fluid py-3">

                <div class="ay-page-header">
                    <div>
                        <h3><i class="bi bi-bar-chart-line me-2"></i>Grades Report</h3>
                        <p>View &amp; print student grades by section (K-12 DepEd format)</p>
                    </div>
                    <div class="d-flex gap-2 align-items-center flex-wrap">
                        <div class="ay-active-chip"><i class="bi bi-calendar2-check-fill"></i> Active Year:&nbsp;<?= htmlspecialchars($activeYearLabel ?: 'None') ?></div>
                        <div class="ay-active-chip"><i class="bi bi-calendar3"></i> Active Quarter:&nbsp;<?= $activeQuarter ? htmlspecialchars($activeQuarter['quarter_label'].' Quarter, '.$activeQuarter['year_label']) : 'None' ?></div>
                    </div>
                </div>

                <!-- Section list -->
                <div id="view-sections">
                    <div class="ay-card">
                        <div class="ay-card-header">
                            <div>
                                <p class="ay-card-title">Sections &amp; Grade Levels</p>
                                <p class="ay-card-subtitle" id="sectionSubtitle">S.Y. <?= htmlspecialchars($viewingYear['year_label'] ?? '') ?> &mdash; Click a section to view &amp; print student grades.</p>
                            </div>
                            <div style="display:flex;gap:.5rem;align-items:center;flex-wrap:wrap;">
                                <select class="ay-select" id="yearNavigator" onchange="changeYear(this.value)">
                                    <?php foreach ($allYears as $yr): ?>
                                        <option value="<?= $yr['id'] ?>" <?= ($viewingYear && $viewingYear['id']==$yr['id'])?'selected':'' ?>>S.Y. <?= htmlspecialchars($yr['year_label']) ?> <?= $yr['is_active']?'(Active)':'' ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <select class="ay-select" id="gradeLevelFilter" onchange="loadSections()">
                                    <option value="">All Grade Levels</option>
                                    <?php foreach ($allGradeLevels as $gl): ?>
                                        <option value="<?= (int)$gl['id'] ?>"><?= htmlspecialchars($gl['grade_level_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <select class="ay-select" id="quarterFilter" onchange="loadSections()"></select>
                                <button class="btn-ay btn-ay-primary" onclick="loadSections()"><i class="bi bi-arrow-clockwise"></i> Refresh</button>
                            </div>
                        </div>
                        <div class="d-none d-md-block">
                            <table class="ay-table" id="sectionTable">
                                <thead><tr><th style="width:56px;text-align:center;">#</th><th>Grade Level</th><th>Section Name</th><th style="text-align:center;">Students</th><th style="text-align:center;">Passed</th><th style="text-align:center;">Failed</th><th style="text-align:center;">Class Avg</th><th style="width:200px;text-align:center;">Actions</th></tr></thead>
                                <tbody id="sectionTableBody"><tr><td colspan="8"><div class="ay-empty"><span class="spinner-border spinner-border-sm me-1"></span> Loading…</div></td></tr></tbody>
                            </table>
                        </div>
                        <div class="d-block d-md-none p-3" id="sectionCardView"></div>
                        <div class="ay-card-footer">
                            <div class="ay-footer-note" id="sectionCountText"></div>
                            <ul class="ay-pagination" id="sectionPagination"></ul>
                        </div>
                    </div>
                </div>

                <!-- Student grades view -->
                <div id="view-grades" style="display:none">
                    <div style="display:flex;align-items:center;gap:.75rem;flex-wrap:wrap;margin-bottom:1.25rem;">
                        <button class="btn-ay btn-ay-outline" onclick="showSections()"><i class="bi bi-arrow-left me-1"></i> Back</button>
                        <div>
                            <h5 class="mb-0" id="detailTitle" style="font-weight:700;color:#132f62;"></h5>
                            <p class="mb-0" id="detailSub" style="font-size:.82rem;color:#7a93b8;"></p>
                        </div>
                    </div>

                    <div class="ay-card">
                        <div class="ay-card-header">
                            <div>
                                <p class="ay-card-title" id="tableCardTitle">Student Grades</p>
                                <p class="ay-card-subtitle" id="tableCardSub"></p>
                            </div>
                            <div style="display:flex;gap:.5rem;align-items:center;flex-wrap:wrap;">
                                <div class="gr-search-wrap"><i class="bi bi-search"></i><input type="text" class="gr-search-input" id="studentSearch" placeholder="Search name or LRN..." oninput="applyFilters()"></div>
                                <select class="gr-select" id="remarkFilter" onchange="applyFilters()"><option value="">All Remarks</option><option value="Passed">Passed</option><option value="Failed">Failed</option><option value="Conditional">Conditional</option></select>
                                <button class="btn-ay btn-ay-success" onclick="printReportCards()"><i class="bi bi-printer-fill"></i> Print Report Cards</button>
                                <button class="btn-ay btn-ay-primary" onclick="exportSection()"><i class="bi bi-download"></i> Export CSV</button>
                            </div>
                        </div>
                        <div class="d-none d-md-block cr-wrap">
                            <table class="cr-table">
                                <thead id="gradesHead"></thead>
                                <tbody id="gradesBody">
                                    <tr><td colspan="20"><div class="ay-empty"><i class="bi bi-hourglass-split"></i><p>Loading...</p></div></td></tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="d-block d-md-none p-3" id="gradesCardView"></div>
                        <div class="ay-card-footer">
                            <div class="ay-footer-note" id="gradeCountText"></div>
                            <ul class="ay-pagination" id="gradePagination"></ul>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </main>
    <?php require_once("includes/footer.php"); ?>
</div>

<!-- Hidden print area -->
<div id="printArea"></div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./js/adminlte.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="./js/sweet-alerts.js"></script>
<script>
/* â”€â”€ State â”€â”€ */
let currentYearId    = <?= $viewingYear ? (int)$viewingYear['id'] : 'null' ?>;
let currentSection   = null;
let allStudents      = [];
let filteredStudents = [];
let currentPage      = 1;
const PER_PAGE       = 30;
let currentSectionData = null;

const GRADE_LEVEL_MAP = {
    0:{name:'Kindergarten',class:'gl-k'},1:{name:'Grade 1',class:'gl-1'},2:{name:'Grade 2',class:'gl-2'},
    3:{name:'Grade 3',class:'gl-3'},4:{name:'Grade 4',class:'gl-4'},5:{name:'Grade 5',class:'gl-5'},
    6:{name:'Grade 6',class:'gl-6'},7:{name:'Grade 7',class:'gl-7'},8:{name:'Grade 8',class:'gl-8'},
    9:{name:'Grade 9',class:'gl-9'},10:{name:'Grade 10',class:'gl-10'},11:{name:'Grade 11',class:'gl-11'},12:{name:'Grade 12',class:'gl-12'}
};

function esc(v){return String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');}
function escText(v){return String(v??'');}

function toast(msg,type='success'){
    const map={success:{title:'Success',color:'green',icon:'bi bi-check-circle-fill'},danger:{title:'Error',color:'red',icon:'bi bi-exclamation-octagon-fill'},warning:{title:'Warning',color:'yellow',icon:'bi bi-exclamation-triangle-fill'},info:{title:'Info',color:'blue',icon:'bi bi-info-circle-fill'}};
    const c=map[type]||map.success;
    iziToast.show({title:c.title,message:msg,color:c.color,icon:c.icon,iconColor:'#fff',theme:'light',position:'topRight',timeout:5000,progressBar:true,close:true,pauseOnHover:true,transitionIn:'fadeInDown',transitionOut:'fadeOutUp',maxWidth:460});
}

async function fetchJson(url,options={}){
    const res=await fetch(url,options);
    const raw=await res.text();
    try{return JSON.parse(raw);}catch(e){console.error('Non-JSON:',raw);throw new Error('Server returned an invalid response.');}
}

function buildPagination(containerId,page,pages,fn){
    let html=`<li class="ay-page-item ${page<=1?'disabled':''}"><a class="ay-page-link" href="javascript:void(0)" onclick="${fn}(${page-1})">Previous</a></li>`;
    for(let n=1;n<=pages;n++) html+=`<li class="ay-page-item ${n===page?'active':''}"><a class="ay-page-link" href="javascript:void(0)" onclick="${fn}(${n})">${n}</a></li>`;
    html+=`<li class="ay-page-item ${page>=pages?'disabled':''}"><a class="ay-page-link" href="javascript:void(0)" onclick="${fn}(${page+1})">Next</a></li>`;
    document.getElementById(containerId).innerHTML=html;
}

function avgPillClass(avg){return avg>=85?'avg-high':avg>=75?'avg-mid':'avg-low';}
function gradeClass(g){return g>=75?'cr-pass':'cr-fail';}
function remarkBadgeClass(r){if(r==='Passed')return 'ay-badge-passed';if(r==='Failed')return 'ay-badge-failed';return 'ay-badge-conditional';}

async function loadQuarterFilter(){
    try{
        const data=await fetchJson(`api/quarters/read.php?view_year_id=${currentYearId}`);
        const select=document.getElementById('quarterFilter');
        const quarters=data.quarters||[];
        select.innerHTML='<option value="">All Quarters</option>';
        quarters.forEach(q=>{const opt=document.createElement('option');opt.value=q.id;opt.textContent=q.quarter_label+' Quarter';if(q.is_active==1)opt.selected=true;select.appendChild(opt);});
    }catch(e){document.getElementById('quarterFilter').innerHTML='<option value="">All Quarters</option>';}
}

function changeYear(id){
    currentYearId=id;
    const sub=document.getElementById('sectionSubtitle');
    const nav=document.getElementById('yearNavigator');
    const selOpt=nav.options[nav.selectedIndex];
    if(sub&&selOpt)sub.textContent=selOpt.textContent.trim()+' — Click a section to view student grades.';
    loadQuarterFilter();loadSections();
}

async function loadSections(){
    const gradeLevel=document.getElementById('gradeLevelFilter').value;
    const quarterId=document.getElementById('quarterFilter').value;
    document.getElementById('sectionTableBody').innerHTML=`<tr><td colspan="8"><div class="ay-empty"><span class="spinner-border spinner-border-sm me-1"></span> Loading sections…</div></td></tr>`;
    document.getElementById('sectionCardView').innerHTML=`<div class="ay-empty"><span class="spinner-border spinner-border-sm me-1"></span> Loading…</div>`;
    try{
        let url=`api/grades/sections.php?year_id=${currentYearId}`;
        if(gradeLevel)url+=`&grade_level=${gradeLevel}`;
        if(quarterId)url+=`&quarter_id=${quarterId}`;
        const data=await fetchJson(url);
        renderSections(data.sections||[],data.quarter_label||'');
    }catch(e){toast(e.message,'danger');document.getElementById('sectionTableBody').innerHTML=`<tr><td colspan="8"><div class="ay-empty"><i class="bi bi-exclamation-circle"></i><p>Failed to load sections.</p></div></td></tr>`;}
}

function renderSections(list,quarterLabel){
    const tbody=document.getElementById('sectionTableBody');
    const cards=document.getElementById('sectionCardView');
    const countEl=document.getElementById('sectionCountText');
    if(!list.length){
        const empty=`<div class="ay-empty"><i class="bi bi-journals"></i><p>No sections found for this selection.</p></div>`;
        tbody.innerHTML=`<tr><td colspan="8">${empty}</td></tr>`;cards.innerHTML=empty;
        if(countEl)countEl.textContent='';document.getElementById('sectionPagination').innerHTML='';return;
    }
    if(countEl)countEl.textContent=`${list.length} section${list.length===1?'':'s'} found`;
    tbody.innerHTML=list.map((s,i)=>{
        const avg=Number(s.class_average||0),enrolled=Number(s.enrolled||0),passed=Number(s.passed||0),failed=Number(s.failed||0);
        const glCode=Number(s.grade_level_code??0);
        const glCfg=GRADE_LEVEL_MAP[glCode]||{name:s.grade_level_name||'Unknown',class:'gl-k'};
        return `<tr style="cursor:pointer;" onclick="openSection(${s.id})">
            <td style="text-align:center;color:#9ab0c8;font-size:.82rem;">${i+1}</td>
            <td><span class="gr-level-badge ${glCfg.class}">${glCfg.name}</span></td>
            <td><strong style="color:#132f62;">${esc(s.section_name)}</strong></td>
            <td style="text-align:center;font-weight:700;">${enrolled}</td>
            <td style="text-align:center;color:#059669;font-weight:700;">${passed}</td>
            <td style="text-align:center;color:#dc2626;font-weight:700;">${failed}</td>
            <td style="text-align:center;"><span class="gr-avg-pill ${avgPillClass(avg)}">${avg>0?avg.toFixed(1):'—'}</span></td>
            <td style="text-align:center;">
                <button class="btn-ay btn-ay-primary btn-ay-sm me-1" onclick="event.stopPropagation();openSection(${s.id})"><i class="bi bi-eye"></i> View</button>
                <button class="btn-ay btn-ay-success btn-ay-sm" onclick="event.stopPropagation();quickPrint(${s.id})"><i class="bi bi-printer"></i> Print</button>
            </td>
        </tr>`;
    }).join('');
    cards.innerHTML=list.map((s,i)=>{
        const avg=Number(s.class_average||0),enrolled=Number(s.enrolled||0),passed=Number(s.passed||0),failed=Number(s.failed||0);
        const glCode=Number(s.grade_level_code??0);
        const glCfg=GRADE_LEVEL_MAP[glCode]||{name:s.grade_level_name||'Unknown',class:'gl-k'};
        return `<div class="ay-mobile-card" onclick="openSection(${s.id})" style="cursor:pointer;">
            <div class="ay-mobile-card-header"><span class="ay-mobile-card-title">${esc(s.section_name)}</span><span class="gr-level-badge ${glCfg.class}">${glCfg.name}</span></div>
            <div class="ay-mobile-card-body">
                <div class="grade-label"><i class="bi bi-person-badge me-1"></i>${esc(s.adviser_name||'No adviser assigned')}</div>
                <div style="display:flex;gap:.5rem;margin-top:.5rem;">
                    <div style="flex:1;text-align:center;background:#f4f8ff;border-radius:8px;padding:.5rem;"><div style="font-weight:700;color:#132f62;">${enrolled}</div><div style="font-size:.7rem;color:#7a93b8;">Students</div></div>
                    <div style="flex:1;text-align:center;background:#ecfdf5;border-radius:8px;padding:.5rem;"><div style="font-weight:700;color:#059669;">${passed}</div><div style="font-size:.7rem;color:#7a93b8;">Passed</div></div>
                    <div style="flex:1;text-align:center;background:#fef2f2;border-radius:8px;padding:.5rem;"><div style="font-weight:700;color:#dc2626;">${failed}</div><div style="font-size:.7rem;color:#7a93b8;">Failed</div></div>
                    <div style="flex:1;text-align:center;background:#fffbeb;border-radius:8px;padding:.5rem;"><div style="font-weight:700;color:#132f62;">${avg>0?avg.toFixed(1):'—'}</div><div style="font-size:.7rem;color:#7a93b8;">Avg</div></div>
                </div>
            </div>
        </div>`;
    }).join('');
    document.getElementById('sectionPagination').innerHTML='';
}

async function openSection(sectionId){
    const quarterId=document.getElementById('quarterFilter').value;
    document.getElementById('view-sections').style.display='none';
    document.getElementById('view-grades').style.display='';
    document.getElementById('detailTitle').textContent='Loading...';
    document.getElementById('gradesBody').innerHTML=`<tr><td colspan="20"><div class="ay-empty"><i class="bi bi-hourglass-split"></i><p>Loading grades...</p></div></td></tr>`;
    try{
        let url=`api/grades/section_grades.php?section_id=${sectionId}&year_id=${currentYearId}`;
        if(quarterId)url+=`&quarter_id=${quarterId}`;
        const data=await fetchJson(url);
        currentSectionData=data;currentSection=data.section||null;allStudents=data.students||[];filteredStudents=[...allStudents];currentPage=1;
        document.getElementById('studentSearch').value='';document.getElementById('remarkFilter').value='';
        renderGradeHeader(data);renderGradesTable(data.subjects||[]);
    }catch(e){toast(e.message,'danger');showSections();}
}

function renderGradeHeader(data){
    const sec=data.section||{};const glCode=Number(sec.grade_level_code??0);const glCfg=GRADE_LEVEL_MAP[glCode]||{name:sec.grade_level_name||'Unknown'};
    document.getElementById('detailTitle').innerHTML=`<i class="bi bi-people-fill me-2" style="color:#1a6ef5"></i>${esc(sec.section_name)} — ${glCfg.name}`;
    document.getElementById('detailSub').textContent=`Adviser: ${sec.adviser_name||'None'} · ${esc(data.quarter_label||'All Quarters')} · S.Y. ${esc(sec.year_label||'')}`;
    document.getElementById('tableCardTitle').textContent=`Student Grades — ${esc(sec.section_name)}`;
    document.getElementById('tableCardSub').textContent=`${allStudents.length} student${allStudents.length===1?'':'s'} enrolled`;
}

/* â”€â”€ DepEd Class Record style grades table â”€â”€ */
function renderGradesTable(subjects){
    window._lastSubjects = subjects;

    const total  = filteredStudents.length;
    const pages  = Math.max(1, Math.ceil(total / PER_PAGE));
    if (currentPage > pages) currentPage = 1;
    const slice  = filteredStudents.slice((currentPage - 1) * PER_PAGE, currentPage * PER_PAGE);
    const offset = (currentPage - 1) * PER_PAGE;

    /* â”€â”€ thead: row 1 = angled subject names + LEARNERS' NAMES + AVERAGE
              row 2 = column numbers â”€â”€ */
    const angledThs = subjects.map(s =>
        `<th class="cr-angled-th"><span class="cr-th-inner">${esc(s.subject_name)}</span></th>`
    ).join('');
    const colNums = subjects.map((s, i) =>
        `<th class="cr-header-num cr-grade">${i + 1}</th>`
    ).join('');

    const thead = `
        <tr>
            <th class="cr-num-th" rowspan="2">#</th>
            <th class="cr-name-th" rowspan="2">LEARNERS' NAMES</th>
            ${angledThs}
            <th class="cr-avg-th" rowspan="2">AVERAGE</th>
        </tr>
        <tr>${colNums}</tr>`;

    /* â”€â”€ Split by sex for grouped rows â”€â”€ */
    const isMale   = st => ['male','m'].includes((st.sex||'').toLowerCase());
    const isFemale = st => ['female','f'].includes((st.sex||'').toLowerCase());
    const maleList   = slice.filter(isMale);
    const femaleList = slice.filter(isFemale);
    const otherList  = slice.filter(st => !isMale(st) && !isFemale(st));

    const hasSexGroups = maleList.length > 0 || femaleList.length > 0;

    /* render a data row */
    const dataRow = (st, rowNum) => {
        const gradeCells = subjects.map(s => {
            const g = Number(st.grades?.[s.id] ?? 0);
            const cls = g >= 75 ? 'cr-pass' : g > 0 ? 'cr-fail' : '';
            return `<td class="cr-grade ${cls}">${g > 0 ? g : ''}</td>`;
        }).join('');
        const avg    = Number(st.general_average || 0);
        const avgCls = avg >= 75 ? 'cr-pass' : avg > 0 ? 'cr-fail' : '';
        return `<tr>
            <td class="cr-num">${rowNum}</td>
            <td class="cr-name">${esc(st.full_name)}</td>
            ${gradeCells}
            <td class="cr-avg cr-avg-cell ${avgCls}">${avg > 0 ? avg.toFixed(2) : ''}</td>
        </tr>`;
    };

    /* render N blank filler rows */
    const blankRows = (count, startNum) => Array.from({length: count}, (_, i) =>
        `<tr class="cr-empty-row">
            <td class="cr-num" style="color:#ccc;">${startNum + i}</td>
            <td class="cr-name">&nbsp;</td>
            ${subjects.map(() => '<td class="cr-grade"></td>').join('')}
            <td class="cr-avg cr-avg-cell"></td>
        </tr>`
    ).join('');

    /* group header row */
    const groupRow = label =>
        `<tr class="cr-row-group">
            <td class="cr-num"></td>
            <td colspan="${subjects.length + 2}">${label}</td>
        </tr>`;

    const MIN_PER_GROUP = 13; /* minimum filler rows per group */
    let tbody = '';
    let rowNum = offset + 1;

    if (!total) {
        const colspan = subjects.length + 3;
        tbody = `<tr><td colspan="${colspan}"><div class="ay-empty"><i class="bi bi-person-x"></i><p>No students match your search.</p></div></td></tr>`;
    } else if (hasSexGroups) {
        /* MALE group */
        tbody += groupRow('MALE');
        maleList.forEach(st => { tbody += dataRow(st, rowNum++); });
        const maleFill = Math.max(0, MIN_PER_GROUP - maleList.length);
        tbody += blankRows(maleFill, rowNum); rowNum += maleFill;

        /* FEMALE group */
        tbody += groupRow('FEMALE');
        femaleList.forEach(st => { tbody += dataRow(st, rowNum++); });
        const femaleFill = Math.max(0, MIN_PER_GROUP - femaleList.length);
        tbody += blankRows(femaleFill, rowNum); rowNum += femaleFill;

        /* others without group header */
        otherList.forEach(st => { tbody += dataRow(st, rowNum++); });
    } else {
        /* no sex data — flat list with minimum rows */
        otherList.forEach(st => { tbody += dataRow(st, rowNum++); });
        const fill = Math.max(0, 25 - otherList.length);
        tbody += blankRows(fill, rowNum);
    }

    document.getElementById('gradesHead').innerHTML = thead;
    document.getElementById('gradesBody').innerHTML  = tbody;

    /* â”€â”€ Mobile card view â”€â”€ */
    document.getElementById('gradesCardView').innerHTML = !slice.length
        ? `<div class="ay-empty"><i class="bi bi-person-x"></i><p>No students found.</p></div>`
        : slice.map((st, i) => {
            const avg = Number(st.general_average || 0);
            const gradesGrid = subjects.map(s => {
                const g = Number(st.grades?.[s.id] ?? 0);
                return `<div style="background:#f4f8ff;border-radius:6px;padding:.3rem .5rem;font-size:.78rem;">
                    <div style="color:#7a93b8;font-size:.7rem;">${esc(s.subject_name)}</div>
                    <div style="font-weight:700;" class="${g >= 75 ? 'cr-pass' : g > 0 ? 'cr-fail' : ''}">${g > 0 ? g : '—'}</div>
                </div>`;
            }).join('');
            return `<div class="ay-mobile-card">
                <div class="ay-mobile-card-header">
                    <span class="ay-mobile-card-title">${offset + i + 1}. ${esc(st.full_name)}</span>
                    <span class="ay-badge ${remarkBadgeClass(st.remark)}">${esc(st.remark || '—')}</span>
                </div>
                <div class="ay-mobile-card-body">
                    <div class="grade-label">${esc(st.lrn || '')}</div>
                    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(80px,1fr));gap:.35rem;margin-top:.5rem;">${gradesGrid}</div>
                    <div style="margin-top:.65rem;font-size:.82rem;color:#4a5568;">General Average: <strong class="${avg >= 75 ? 'cr-pass' : avg > 0 ? 'cr-fail' : ''}">${avg > 0 ? avg.toFixed(2) : '—'}</strong></div>
                </div>
            </div>`;
        }).join('');

    /* footer */
    document.getElementById('gradeCountText').textContent = total > 0
        ? `Showing ${offset + 1}–${Math.min(offset + slice.length, total)} of ${total} student${total === 1 ? '' : 's'}`
        : 'No students to display.';
    buildPagination('gradePagination', currentPage, pages, 'goPage');
}

function goPage(n){currentPage=n;renderGradesTable(window._lastSubjects||[]);}
function applyFilters(){
    const q=document.getElementById('studentSearch').value.toLowerCase();const rem=document.getElementById('remarkFilter').value;
    filteredStudents=allStudents.filter(st=>{const mq=!q||st.full_name.toLowerCase().includes(q)||(st.lrn||'').toLowerCase().includes(q);const mr=!rem||st.remark===rem;return mq&&mr;});
    currentPage=1;renderGradesTable(window._lastSubjects||[]);
}
function showSections(){document.getElementById('view-grades').style.display='none';document.getElementById('view-sections').style.display='';}

function exportSection(){
    if(!currentSection||!window._lastSubjects)return;
    const subjects=window._lastSubjects;let csv='No.,Student Name,LRN,';
    csv+=subjects.map(s=>s.subject_name).join(',')+',General Average,Remarks\n';
    allStudents.forEach((st,i)=>{const grades=subjects.map(s=>Number(st.grades?.[s.id]??0)||'').join(',');csv+=`${i+1},"${st.full_name}","${st.lrn||''}",${grades},${Number(st.general_average||0).toFixed(2)},${st.remark||''}\n`;});
    const blob=new Blob([csv],{type:'text/csv'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`grades_${currentSection.section_name}_${currentSection.year_label}.csv`.replace(/\s/g,'_');a.click();URL.revokeObjectURL(url);
    toast('CSV exported successfully.','success');
}

/* â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
   PRINT
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• */
async function quickPrint(sectionId){
    const quarterId=document.getElementById('quarterFilter').value;
    toast('Loading data for printing...','info');
    try{
        let url=`api/grades/section_grades.php?section_id=${sectionId}&year_id=${currentYearId}`;
        if(quarterId)url+=`&quarter_id=${quarterId}`;
        const data=await fetchJson(url);buildAndPrint(data);
    }catch(e){toast(e.message,'danger');}
}
function printReportCards(){if(!currentSectionData){toast('No section loaded.','warning');return;}buildAndPrint(currentSectionData);}

function buildAndPrint(data){
    const sec=data.section||{};const glCode=Number(sec.grade_level_code??0);const isSHS=(glCode===11||glCode===12);
    const subjects=data.subjects||[];const students=data.students||[];
    const yearLabel=escText(sec.year_label||data.year_label||'');const sectionName=escText(sec.section_name||'');
    const adviserName=escText(sec.adviser_name||'');const principal=escText(sec.principal||'');
    const glName=GRADE_LEVEL_MAP[glCode]?.name||`Grade ${glCode}`;const quarterLabel=escText(data.quarter_label||'');
    let html='';
    students.forEach(st=>{
        html+=isSHS
            ?buildSHSCard(st,subjects,sec,data,yearLabel,sectionName,adviserName,principal,glName,glCode,quarterLabel)
            :buildSF9Card(st,subjects,sec,data,yearLabel,sectionName,adviserName,principal,glName,glCode,quarterLabel);
    });
    document.getElementById('printArea').innerHTML=html;
    requestAnimationFrame(()=>requestAnimationFrame(()=>window.print()));
}

/* â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
   SF9 CARD — Grades 1–10
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• */
function buildSF9Card(st,subjects,sec,data,yearLabel,sectionName,adviserName,principal,glName,glCode,quarterLabel){
    const fullName  = escText(st.full_name||'');
    const lrn       = escText(st.lrn||'');
    const avg       = Number(st.general_average||0);
    const remark    = escText(st.remark||'');
    const age       = escText(st.age||'');
    const sex       = escText(st.sex||'');
    const address   = escText(sec.school_address||'');
    const gradeCode = glName.replace('Grade ','').toUpperCase();

    const gradeRows = subjects.map(s=>{
        const q1=Number(st.quarter_grades?.[s.id]?.['1']||0);
        const q2=Number(st.quarter_grades?.[s.id]?.['2']||0);
        const q3=Number(st.quarter_grades?.[s.id]?.['3']||0);
        const q4=Number(st.quarter_grades?.[s.id]?.['4']||0);
        const fg=Number(st.grades?.[s.id]||0);
        const fc=fg>0&&fg<75?'fg':'pg';
        return `<tr>
          <td class="sc">${escText(s.subject_name)}</td>
          <td>${q1>0?q1:''}</td><td>${q2>0?q2:''}</td><td>${q3>0?q3:''}</td><td>${q4>0?q4:''}</td>
          <td class="fc ${fc}">${fg>0?fg:''}</td>
          <td>${fg>=75?'Passed':fg>0?'Failed':''}</td>
        </tr>`;
    }).join('');

    const avgCls=avg>0&&avg<75?'fg':'pg';

    const coreValues=[
        {g:'1. Maka-Diyos',b:["Expresses one's spiritual belief while respecting the spiritual beliefs of others.","Shows adherence to ethical principles by upholding truth."]},
        {g:'2. Makatao',b:['Is sensitive to individual, social, and cultural differences.','Demonstrates contributions toward solidarity.']},
        {g:'3. Maka-kalikasan',b:['Cares for the environment and utilizes resources wisely, judiciously and economically.']},
        {g:'4. Maka-bansa',b:['Demonstrates pride in being a Filipino; exercises the rights and responsibilities of a Filipino.','Demonstrates appropriate behavior in carrying out activities in the school, community and country.']}
    ];
    const valRows=coreValues.map(cv=>cv.b.map((b,bi)=>`<tr>
        ${bi===0?`<td rowspan="${cv.b.length}" style="vertical-align:middle;font-size:8pt;font-weight:bold;padding:2px 4px;">${escText(cv.g)}</td>`:''}
        <td style="font-size:8pt;padding:2px 4px;">${escText(b)}</td>
        <td class="qc"></td><td class="qc"></td><td class="qc"></td><td class="qc"></td>
    </tr>`).join('')).join('');

    return `
<div class="rc-page">
  <div class="rc-page-label">DEPED SF9 · ${glName}</div>
  <div class="sf9-wrap">
    <div class="sf9-top">
      <div class="sf9-left">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px;">
          <img src="assets/img/deped.png" style="width:52px;height:52px;object-fit:contain;flex-shrink:0;" alt="DepEd">
          <div style="text-align:center;flex:1;line-height:1.35;">
            <div style="font-size:8pt;">Republic of the Philippines</div>
            <div style="font-size:8.5pt;font-weight:bold;">Department of Education</div>
            <div style="font-size:8pt;">National Capital Region</div>
            <div style="font-size:8pt;">Division of Quezon City</div>
            <div style="font-size:9.5pt;font-weight:bold;text-transform:uppercase;">St. Theresa's School of Novaliches, Inc.</div>
            <div style="font-size:7.5pt;">${address}</div>
          </div>
          <img src="assets/img/stsn logo.png" style="width:52px;height:52px;object-fit:contain;flex-shrink:0;" alt="STSN">
        </div>
        <table style="width:100%;border-collapse:collapse;margin-top:2px;font-size:9pt;">
          <tr>
            <td style="width:72px;color:#333;font-size:8.5pt;white-space:nowrap;">Name:</td>
            <td colspan="3" style="font-weight:bold;font-size:11.5pt;font-family:'Arial Black',Arial,sans-serif;border-bottom:1.5px solid #000;padding-left:4px;">${fullName}</td>
          </tr>
          <tr>
            <td style="font-size:8.5pt;color:#333;padding-top:2px;">Age:</td>
            <td style="font-weight:bold;border-bottom:1px solid #000;padding-left:4px;width:40px;font-size:9.5pt;">${age}</td>
            <td style="font-size:8.5pt;color:#333;padding-left:8px;">Sex:</td>
            <td style="font-weight:bold;border-bottom:1px solid #000;padding-left:4px;font-size:9.5pt;text-transform:uppercase;">${sex}</td>
          </tr>
          <tr>
            <td style="font-size:8.5pt;color:#333;padding-top:2px;">Grade:</td>
            <td style="font-weight:bold;border-bottom:1px solid #000;padding-left:4px;font-size:9.5pt;">${gradeCode}</td>
            <td style="font-size:8.5pt;color:#333;padding-left:8px;">Section:</td>
            <td style="font-weight:bold;border-bottom:1px solid #000;padding-left:4px;font-size:9.5pt;">${sectionName}</td>
          </tr>
          <tr>
            <td style="font-size:8.5pt;color:#333;padding-top:2px;white-space:nowrap;">School Year:</td>
            <td colspan="3" style="font-weight:bold;border-bottom:1px solid #000;padding-left:4px;font-size:9.5pt;">${yearLabel}</td>
          </tr>
          <tr>
            <td style="font-size:8.5pt;color:#333;padding-top:2px;">LRN:</td>
            <td colspan="3" style="font-weight:bold;border-bottom:1px solid #000;padding-left:4px;font-size:9.5pt;">${lrn}</td>
          </tr>
        </table>
        <div style="font-size:7.5pt;margin-top:4px;line-height:1.5;color:#333;font-style:italic;">
          Dear Parent:<br>
          &nbsp;&nbsp;This report card shows the ability and progress your child has made in the different learning areas as well as his/her core values.<br>
          &nbsp;&nbsp;The school welcomes you, should you desire to know more about your child's progress.
        </div>
        <div class="sf9-sec">REPORT ON LEARNING PROGRESS AND ACHIEVEMENT</div>
        <table class="sf9-gt">
          <thead>
            <tr>
              <th class="sc" rowspan="2">Learning Areas</th>
              <th colspan="4">Quarter</th>
              <th rowspan="2">Final<br>Grade</th>
              <th rowspan="2">Remarks</th>
            </tr>
            <tr><th>1</th><th>2</th><th>3</th><th>4</th></tr>
          </thead>
          <tbody>
            ${gradeRows}
            <tr style="background:#e8e8e8;">
              <td colspan="5" style="text-align:center;font-weight:bold;font-size:8.5pt;">General Average</td>
              <td class="fc ${avgCls}" style="font-weight:bold;">${avg>0?avg.toFixed(2):''}</td>
              <td style="font-size:8pt;">${remark}</td>
            </tr>
          </tbody>
        </table>
        <table class="sf9-dt">
          <tr><th>Descriptors</th><th style="text-align:center;">Grading Scale</th><th style="text-align:center;">Remarks</th></tr>
          <tr><td>Outstanding</td><td style="text-align:center;">90-100</td><td style="text-align:center;">Passed</td></tr>
          <tr><td>Very Satisfactory</td><td style="text-align:center;">85-89</td><td style="text-align:center;">Passed</td></tr>
          <tr><td>Satisfactory</td><td style="text-align:center;">80-84</td><td style="text-align:center;">Passed</td></tr>
          <tr><td>Fairly Satisfactory</td><td style="text-align:center;">75-79</td><td style="text-align:center;">Passed</td></tr>
          <tr><td>Did not Meet Expectations</td><td style="text-align:center;">Below 75</td><td style="text-align:center;">Failed</td></tr>
        </table>
        <div class="sf9-sec">REPORT ON ATTENDANCE</div>
        <table class="sf9-at">
          <thead>
            <tr>
              <th style="text-align:left;padding-left:3px;min-width:90px;"></th>
              <th>Oct</th><th>Nov</th><th>Dec</th><th>Jan</th><th>Feb</th>
              <th>Mar</th><th>Apr</th><th>May</th><th>Jun</th><th>Jul</th>
              <th>O</th><th>Total</th>
            </tr>
          </thead>
          <tbody>
            <tr><td class="lft">No. of School days</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
            <tr><td class="lft">No. of days Present</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
            <tr><td class="lft">No. of days Absent</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
          </tbody>
        </table>
        <div style="margin-top:5px;font-size:8pt;">
          <div style="display:flex;align-items:flex-end;gap:4px;margin-bottom:3px;"><span style="white-space:nowrap;">Classified as :</span><span style="flex:1;border-bottom:1px solid #000;">&nbsp;</span></div>
          <div style="display:flex;align-items:flex-end;gap:4px;margin-bottom:3px;"><span style="white-space:nowrap;">Has advanced learning areas:</span><span style="flex:1;border-bottom:1px solid #000;">&nbsp;</span></div>
          <div style="display:flex;align-items:flex-end;gap:4px;margin-bottom:3px;"><span style="white-space:nowrap;">Lack learning areas :</span><span style="flex:1;border-bottom:1px solid #000;">&nbsp;</span></div>
          <div style="display:flex;align-items:flex-end;gap:4px;"><span>Date :</span><span style="flex:1;border-bottom:1px solid #000;">&nbsp;</span></div>
        </div>
        <div style="flex:1;min-height:6px;"></div>
        <div style="display:flex;justify-content:space-between;gap:16px;margin-top:6px;">
          <div style="flex:1;text-align:center;">
            <div style="border-top:1.5px solid #000;padding-top:2px;font-size:8pt;font-weight:bold;text-decoration:underline;">${escText(principal)}</div>
            <div style="font-size:7.5pt;">Principal IV</div>
          </div>
          <div style="flex:1;text-align:center;">
            <div style="border-top:1.5px solid #000;padding-top:2px;font-size:8pt;font-weight:bold;text-decoration:underline;">${adviserName}</div>
            <div style="font-size:7.5pt;">Adviser</div>
          </div>
        </div>
      </div><!-- /left -->

      <div class="sf9-right">
        <div class="sf9-sec" style="margin-top:0;border-top:none;">REPORT ON LEARNER'S OBSERVED VALUES</div>
        <table class="sf9-vt">
          <thead>
            <tr>
              <th style="width:68px;">CORE VALUES</th>
              <th>Behavior Statement</th>
              <th colspan="4">Quarter</th>
            </tr>
            <tr>
              <th></th><th></th>
              <th style="width:20px;">1</th><th style="width:20px;">2</th>
              <th style="width:20px;">3</th><th style="width:20px;">4</th>
            </tr>
          </thead>
          <tbody>${valRows}</tbody>
        </table>
        <table class="sf9-mt">
          <tr><th style="text-align:center;width:65px;">Marking</th><th>Non-numerical Rating</th></tr>
          <tr><td style="text-align:center;">AO</td><td>Always Observed</td></tr>
          <tr><td style="text-align:center;">SO</td><td>Sometimes Observed</td></tr>
          <tr><td style="text-align:center;">RO</td><td>Rarely Observed</td></tr>
          <tr><td style="text-align:center;">NO</td><td>Not Observed</td></tr>
        </table>
        <div style="margin-top:12px;">
          <div style="font-size:9pt;font-weight:bold;text-align:center;margin-bottom:6px;">PARENT / GUARDIAN'S SIGNATURE</div>
          <table style="width:100%;font-size:8.5pt;border-collapse:collapse;">
            <tr><td style="padding:3px 0;">1st Quarter</td><td style="border-bottom:1px solid #000;width:62%;">&nbsp;</td></tr>
            <tr><td style="padding:3px 0;">2nd Quarter</td><td style="border-bottom:1px solid #000;">&nbsp;</td></tr>
            <tr><td style="padding:3px 0;">3rd Quarter</td><td style="border-bottom:1px solid #000;">&nbsp;</td></tr>
            <tr><td style="padding:3px 0;">4th Quarter</td><td style="border-bottom:1px solid #000;">&nbsp;</td></tr>
          </table>
        </div>
        <div style="flex:1;min-height:10px;"></div>
        <div style="border-top:1.5px solid #000;padding-top:6px;margin-top:10px;">
          <div style="font-size:9pt;font-weight:bold;text-align:center;margin-bottom:5px;">CERTIFICATE OF TRANSFER</div>
          <div style="font-size:8pt;display:flex;align-items:flex-end;gap:3px;margin-bottom:4px;">
            <span style="white-space:nowrap;">Admitted to Grade:</span>
            <span style="border-bottom:1px solid #000;flex:1;">&nbsp;</span>
            <span style="white-space:nowrap;margin-left:4px;">Section:</span>
            <span style="border-bottom:1px solid #000;flex:1;">&nbsp;</span>
          </div>
          <div style="font-size:8pt;display:flex;align-items:flex-end;gap:3px;margin-bottom:4px;">
            <span style="white-space:nowrap;">Eligibility for Admission to Grade:</span>
            <span style="border-bottom:1px solid #000;flex:1;">&nbsp;</span>
          </div>
          <div style="font-size:8pt;display:flex;align-items:flex-end;gap:3px;margin-bottom:5px;">
            <span>Approved:</span>
            <span style="border-bottom:1px solid #000;flex:1;">&nbsp;</span>
          </div>
          <div style="display:flex;justify-content:space-between;gap:12px;margin-top:16px;">
            <div style="flex:1;text-align:center;">
              <div style="border-top:1.5px solid #000;padding-top:2px;font-size:8pt;font-weight:bold;text-decoration:underline;">${escText(principal)}</div>
              <div style="font-size:7.5pt;">Principal IV</div>
            </div>
            <div style="flex:1;text-align:center;">
              <div style="border-top:1.5px solid #000;padding-top:2px;font-size:8pt;font-weight:bold;text-decoration:underline;">${adviserName}</div>
              <div style="font-size:7.5pt;">Adviser</div>
            </div>
          </div>
        </div>
        <div style="border-top:1.5px solid #000;padding-top:6px;margin-top:10px;">
          <div style="font-size:9pt;font-weight:bold;text-align:center;margin-bottom:5px;">CANCELLATION OF ELIGIBILITY TO TRANSFER</div>
          <div style="font-size:8pt;display:flex;align-items:flex-end;gap:3px;margin-bottom:4px;">
            <span>Admitted in:</span><span style="border-bottom:1px solid #000;flex:1;">&nbsp;</span>
          </div>
          <div style="font-size:8pt;display:flex;align-items:flex-end;gap:3px;margin-bottom:4px;">
            <span>Date:</span><span style="border-bottom:1px solid #000;flex:1;">&nbsp;</span>
          </div>
          <div style="text-align:right;margin-top:16px;">
            <div style="display:inline-block;text-align:center;">
              <div style="border-top:1.5px solid #000;padding-top:2px;font-size:8pt;font-weight:bold;text-decoration:underline;">${escText(principal)}</div>
              <div style="font-size:7.5pt;">Principal IV</div>
            </div>
          </div>
        </div>
      </div><!-- /right -->
    </div><!-- /sf9-top -->
  </div><!-- /sf9-wrap -->
</div>`;
}

/* â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
   SHS CARD — Grades 11–12
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• */
function buildSHSCard(st,subjects,sec,data,yearLabel,sectionName,adviserName,principal,glName,glCode,quarterLabel){
    const fullName=escText(st.full_name||'');const lrn=escText(st.lrn||'');const avg=Number(st.general_average||0);
    const age=escText(st.age||'');const sex=escText(st.sex||'');const strand=escText(sec.strand||'');const address=escText(sec.school_address||'');

    const coreSubjects=subjects.filter(s=>(s.category||'').toLowerCase().includes('core')||!s.category);
    const appliedSubjects=subjects.filter(s=>(s.category||'').toLowerCase().includes('applied'));
    const specializedSubjects=subjects.filter(s=>(s.category||'').toLowerCase().includes('specialized'));

    const semRow=(s,sk)=>{
        const q1=Number(st.quarter_grades?.[s.id]?.['1']||0),q2=Number(st.quarter_grades?.[s.id]?.['2']||0);
        const q3=Number(st.quarter_grades?.[s.id]?.['3']||0),q4=Number(st.quarter_grades?.[s.id]?.['4']||0);
        const fg=Number(st.grades?.[s.id]||0);const fc=fg>0&&fg<75?'fg':'';const rem=fg>=75?'Passed':fg>0?'Failed':'';
        return sk==='s1'
            ?`<tr><td class="sc">${escText(s.subject_name)}</td><td class="nc">${q1>0?q1:''}</td><td class="nc">${q2>0?q2:''}</td><td class="nc ${fc}">${fg>0?fg:''}</td><td>${rem}</td></tr>`
            :`<tr><td class="sc">${escText(s.subject_name)}</td><td class="nc">${q3>0?q3:''}</td><td class="nc">${q4>0?q4:''}</td><td class="nc ${fc}">${fg>0?fg:''}</td><td>${rem}</td></tr>`;
    };
    const catBlock=(lbl,subjs,sk)=>!subjs.length?'':
        `<tr class="ch"><td colspan="5" style="padding-left:6px;">${lbl}</td></tr>`+subjs.map(s=>semRow(s,sk)).join('');

    const s1Avg=subjects.length?(subjects.reduce((a,s)=>{
        const q1=Number(st.quarter_grades?.[s.id]?.['1']||0),q2=Number(st.quarter_grades?.[s.id]?.['2']||0);
        return a+((q1+q2)/2||Number(st.grades?.[s.id]||0));
    },0)/subjects.length):avg;
    const avgCls=avg>0&&avg<75?'fg':'';

    return `
<div class="rc-page">
  <div class="shs-wrap">
    <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px;">
      <img src="assets/img/deped.png" style="width:50px;height:50px;object-fit:contain;flex-shrink:0;" alt="DepEd">
      <div style="text-align:center;flex:1;line-height:1.35;">
        <div style="font-size:8pt;">Republic of the Philippines</div>
        <div style="font-size:8.5pt;font-weight:bold;">Department of Education</div>
        <div style="font-size:8pt;">National Capital Region · Division of Quezon City</div>
        <div style="font-size:10pt;font-weight:bold;text-transform:uppercase;">St. Theresa's School of Novaliches, Inc.</div>
        <div style="font-size:7.5pt;">${address}</div>
      </div>
      <img src="assets/img/stsn logo.png" style="width:50px;height:50px;object-fit:contain;flex-shrink:0;" alt="STSN">
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:0;border-top:1px solid #000;border-bottom:1px solid #000;padding:4px 0;font-size:9pt;">
      <div><div><span style="font-size:8pt;color:#555;">Name: </span><strong>${fullName}</strong></div><div style="border-bottom:1px solid #000;margin-top:2px;"></div></div>
      <div style="padding-left:8px;"><div><span style="font-size:8pt;color:#555;">Age: </span><strong>${age}</strong></div><div><span style="font-size:8pt;color:#555;">Sex: </span><strong>${sex.toUpperCase()}</strong></div></div>
      <div style="padding-left:8px;"><div><span style="font-size:8pt;color:#555;">LRN: </span><strong>${lrn}</strong></div><div><span style="font-size:8pt;color:#555;">S.Y.: </span><strong>${yearLabel}</strong></div></div>
    </div>
    <div style="font-size:8pt;padding:2px 0;border-bottom:1px solid #000;"><span style="color:#555;">Grade: </span><strong>${glName.replace('Grade ','')}${strand?' – '+strand:''}</strong>&nbsp;&nbsp;<span style="color:#555;">Section: </span><strong>${sectionName}</strong>&nbsp;&nbsp;<span style="color:#555;">S.Y.: </span><strong>${yearLabel}</strong></div>
    <div style="text-align:right;padding:2px 0;font-size:8.5pt;border-bottom:1px solid #000;"><strong>${escText(principal)}</strong> — <span style="font-size:8pt;">Principal IV</span></div>
    <div style="text-align:center;font-weight:bold;font-size:9pt;border-bottom:1px solid #000;padding:3px;background:#f0f0f0;text-transform:uppercase;">Report on Learning Progress and Achievement — First Semester</div>
    <table class="shs-gt">
      <thead><tr><th class="sc">Subjects</th><th colspan="2">Quarter</th><th>Semester Final Grade</th><th>Remarks</th></tr><tr><th class="sc"></th><th>1</th><th>2</th><th></th><th></th></tr></thead>
      <tbody>
        ${catBlock('Core Subjects',coreSubjects,'s1')}
        ${catBlock('Applied Subjects',appliedSubjects,'s1')}
        ${catBlock('Specialized Subjects',specializedSubjects,'s1')}
        <tr class="ar"><td class="sc" colspan="2">General Average for the Semester</td><td class="${avgCls}">${s1Avg>0?s1Avg.toFixed(0):''}</td><td></td><td>${s1Avg>=75?'Passed':s1Avg>0?'Failed':''}</td></tr>
      </tbody>
    </table>
    <div style="text-align:right;padding:2px 0;font-size:8.5pt;border-bottom:1px solid #000;"><strong>${adviserName}</strong> — <span style="font-size:8pt;">Adviser</span></div>
    <div style="text-align:center;font-weight:bold;font-size:9pt;border-bottom:1px solid #000;padding:3px;background:#f0f0f0;text-transform:uppercase;">Report on Learning Progress and Achievement — Second Semester</div>
    <table class="shs-gt">
      <thead><tr><th class="sc">Subjects</th><th colspan="2">Quarter</th><th>Semester Final Grade</th><th>Remarks</th></tr><tr><th class="sc"></th><th>3</th><th>4</th><th></th><th></th></tr></thead>
      <tbody>
        ${catBlock('Core Subjects',coreSubjects,'s2')}
        ${catBlock('Applied Subjects',appliedSubjects,'s2')}
        ${catBlock('Specialized Subjects',specializedSubjects,'s2')}
        <tr class="ar"><td class="sc" colspan="2">General Average for the Semester</td><td class="${avgCls}">${avg>0?avg.toFixed(0):''}</td><td></td><td>${avg>=75?'Passed':avg>0?'Failed':''}</td></tr>
      </tbody>
    </table>
    <div style="text-align:right;padding:2px 0;font-size:8.5pt;border-bottom:1px solid #000;"><strong>${adviserName}</strong> — <span style="font-size:8pt;">Adviser</span></div>
    <div style="padding:4px 0;">
      <div style="font-size:8.5pt;font-weight:bold;text-align:center;margin-bottom:3px;">REPORT ON ATTENDANCE</div>
      <table class="sf9-at">
        <thead><tr><th></th><th>Sept</th><th>Oct</th><th>Nov</th><th>Dec</th><th>Jan</th><th>Feb</th><th>Mar</th><th>Apr</th><th>May</th><th>Jun</th><th>Total</th></tr></thead>
        <tbody>
          <tr><td class="lft">No. of school days</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
          <tr><td class="lft">No. of days present</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
          <tr><td class="lft">No. of days absent</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
        </tbody>
      </table>
    </div>
  </div>
</div>`;
}

/* â”€â”€ Init â”€â”€ */
(async function(){
    await loadQuarterFilter();
    await loadSections();
})();
</script>
</body>
</html>
