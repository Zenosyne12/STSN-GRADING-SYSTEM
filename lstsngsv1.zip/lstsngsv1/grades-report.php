<?php
require_once __DIR__ . '/includes/auth.php';
requireAdmin();
require_once __DIR__ . '/includes/descriptor_engine.php';
require_once __DIR__ . '/api/shared/db_connect.php';

$activeYearLabel = '';
try {
    $stmtActive = $pdo->query("SELECT year_label FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
    $activeYearLabel = $stmtActive ? (string) $stmtActive->fetchColumn() : '';
} catch (Throwable $e) {
    $activeYearLabel = '';
}

$activeQuarter = null;
try {
    $stmt = $pdo->query("
        SELECT q.*, ay.year_label
        FROM tblquarters q
        JOIN tblacademicyear ay ON q.academic_year_id = ay.id
        WHERE q.is_active = 1 LIMIT 1
    ");
    $activeQuarter = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    $activeQuarter = null;
}

$allYears = [];
try {
    $allYears = $pdo->query("SELECT id, year_label, is_active FROM tblacademicyear ORDER BY year_label DESC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    $allYears = [];
}

$allGradeLevels = [];
try {
    $allGradeLevels = $pdo->query("SELECT id, grade_level_name, grade_level_code FROM tblgradelevel ORDER BY sort_order ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    $allGradeLevels = [];
}

$viewYearId = isset($_GET['view_year']) ? (int) $_GET['view_year'] : null;
$viewingYear = null;
if ($viewYearId) {
    $stmt = $pdo->prepare("SELECT id, year_label, is_active FROM tblacademicyear WHERE id = ?");
    $stmt->execute([$viewYearId]);
    $viewingYear = $stmt->fetch(PDO::FETCH_ASSOC);
}
if (!$viewingYear) {
    $stmt = $pdo->query("SELECT id, year_label, is_active FROM tblacademicyear WHERE is_active = 1 LIMIT 1");
    $viewingYear = $stmt->fetch(PDO::FETCH_ASSOC);
}
if (!$viewingYear && $allYears) {
    $viewingYear = $allYears[0];
}

/* ============================================================
   Form 138 (K-10) — 3-TERM STRUCTURE
   Term columns are sourced from tblconfig_terms
   (academic_year_id + term_number + term_label) for the
   academic year currently being viewed.
   ============================================================ */
$formTerms = [];
$termLabels = [];
try {
    if ($viewingYear) {
        $stmtTerms = $pdo->prepare("
            SELECT id, term_number, term_label
            FROM tblconfig_terms
            WHERE academic_year_id = ?
            ORDER BY term_number ASC
        ");
        $stmtTerms->execute([(int) $viewingYear['id']]);
        $formTerms = $stmtTerms->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Throwable $e) {
    $formTerms = [];
}
foreach ($formTerms as $t) {
    $termLabels[(int) $t['term_number']] = (string) $t['term_label'];
}
?>
<!doctype html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
    <meta charset="utf-8">
    <title>STSN Grading System | Grades Report</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./css/adminlte.css">
    <style>
        /* ============================================================
           THEME VARIABLES (Light & Dark)
           ============================================================ */
        :root,
        [data-bs-theme="light"] {
            --ay-bg: #f3f7fd;
            --ay-card: #ffffff;
            --ay-card-soft: #fafcff;
            --ay-border: #dce8f8;
            --ay-border-soft: #e8f0fb;
            --ay-text: #213a5e;
            --ay-text-strong: #132f62;
            --ay-text-muted: #7a93b8;
            --ay-text-dim: #9ab0c8;
            --ay-head-bg: #f4f8ff;
            --ay-head-text: #3b5e96;
            --ay-row-hover: #f7fbff;
            --ay-row-border: #f0f5fc;
            --ay-input-bg: #ffffff;
            --ay-input-border: #c8daf8;
            --ay-input-text: #213a5e;
            --ay-section-name: #132f62;
            --ay-grade-text: #213a5e;

            /* Buttons */
            --ay-btn-outline-bg: #ffffff;
            --ay-btn-outline-text: #1a6ef5;
            --ay-btn-outline-border: #dce8f8;
            --ay-btn-outline-hover-bg: #eef4ff;
            --ay-btn-outline-hover-border: #9cc2fc;

            --ay-btn-success-bg: #ecfdf5;
            --ay-btn-success-text: #065f46;
            --ay-btn-success-border: #a7f3d0;
            --ay-btn-success-hover-bg: #d1fae5;
            --ay-btn-success-hover-border: #6ee7b7;
        }

        [data-bs-theme="dark"] {
            --ay-bg: #1a1a1a;
            --ay-card: #2D2D2D;
            --ay-card-soft: #262626;
            --ay-border: #3a3a3a;
            --ay-border-soft: #3a3a3a;
            --ay-text: #e4e6e8;
            --ay-text-strong: #ffffff;
            --ay-text-muted: #adb5bd;
            --ay-text-dim: #8b939a;
            --ay-head-bg: #2D2D2D;
            --ay-head-text: #ffffff;
            --ay-row-hover: #343434;
            --ay-row-border: #3a3a3a;
            --ay-input-bg: #3a3a3a;
            --ay-input-border: #4a5a6e;
            --ay-input-text: #e4e6e8;
            --ay-section-name: #ffffff;
            --ay-grade-text: #e4e6e8;

            --ay-btn-outline-bg: #3a3a3a;
            --ay-btn-outline-text: #8ab4f8;
            --ay-btn-outline-border: #4a5a6e;
            --ay-btn-outline-hover-bg: #4a4a4a;
            --ay-btn-outline-hover-border: #6a7a8e;

            --ay-btn-success-bg: #17351f;
            --ay-btn-success-text: #6ee7a0;
            --ay-btn-success-border: #2b5c38;
            --ay-btn-success-hover-bg: #1e4028;
            --ay-btn-success-hover-border: #3a7048;
        }

        /* ============================================================
           BASE
           ============================================================ */
        body {
            background: var(--ay-bg);
        }

        /* ============================================================
           PAGE HEADER
           ============================================================ */
        .ay-page-header {
            background: linear-gradient(130deg, #1248a8 0%, #1a6ef5 100%);
            border-radius: 16px;
            padding: 1.4rem 1.6rem;
            color: #fff;
            margin-bottom: 1.25rem;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }
        .ay-page-header h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 .2rem;
        }
        .ay-page-header p {
            margin: 0;
            font-size: .88rem;
            opacity: .85;
        }
        .ay-active-chip {
            display: inline-flex;
            align-items: center;
            gap: .45rem;
            background: rgba(255, 255, 255, .15);
            border: 1.5px solid rgba(255, 255, 255, .3);
            border-radius: 999px;
            padding: .45rem 1rem;
            font-size: .88rem;
            font-weight: 700;
            color: #fff;
            white-space: nowrap;
        }

        /* ============================================================
           CARDS
           ============================================================ */
        .ay-card {
            background: var(--ay-card);
            border: 1px solid var(--ay-border);
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(18, 72, 168, .06);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }
        .ay-card-header {
            padding: 1.1rem 1.4rem;
            border-bottom: 1px solid var(--ay-border-soft);
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: .75rem;
            background: var(--ay-card);
        }
        .ay-card-title {
            font-size: 1rem;
            font-weight: 700;
            color: var(--ay-text-strong);
            margin: 0 0 .15rem;
        }
        .ay-card-subtitle {
            font-size: .8rem;
            color: var(--ay-text-muted);
            margin: 0;
        }
        .ay-card-footer {
            padding: .75rem 1.2rem;
            border-top: 1px solid var(--ay-border-soft);
            background: var(--ay-card-soft);
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: .75rem;
            flex-wrap: wrap;
        }
        .ay-footer-note {
            font-size: .82rem;
            color: var(--ay-text-muted);
        }

        /* ============================================================
           TABLE
           ============================================================ */
        .ay-table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
        }
        .ay-table thead th {
            background: var(--ay-head-bg);
            color: var(--ay-head-text);
            font-size: .75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .06em;
            padding: .85rem 1.2rem;
            border-bottom: 1.5px solid var(--ay-border);
            white-space: nowrap;
        }
        .ay-table tbody tr:not(:last-child) td {
            border-bottom: 1px solid var(--ay-row-border);
        }
        .ay-table tbody tr:hover td {
            background: var(--ay-row-hover);
        }
        .ay-table tbody td {
            padding: .9rem 1.2rem;
            font-size: .93rem;
            color: var(--ay-text);
            vertical-align: middle;
        }
        [data-bs-theme="dark"] .ay-table tbody td {
            color: #ffffff !important;
        }

        /* ============================================================
           BUTTONS
           ============================================================ */
        .btn-ay {
            font-weight: 600;
            font-size: .82rem;
            border-radius: 8px;
            padding: .42rem .9rem;
            cursor: pointer;
            transition: all .14s;
            border: 1.5px solid transparent;
            line-height: 1.4;
            display: inline-flex;
            align-items: center;
            gap: .3rem;
        }
        .btn-ay-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            box-shadow: 0 2px 8px rgba(26, 110, 245, .2);
        }
        .btn-ay-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
        }
        .btn-ay-outline {
            background: var(--ay-btn-outline-bg);
            color: var(--ay-btn-outline-text);
            border-color: var(--ay-btn-outline-border);
        }
        .btn-ay-outline:hover {
            background: var(--ay-btn-outline-hover-bg);
            border-color: var(--ay-btn-outline-hover-border);
            color: var(--ay-btn-outline-text);
        }
        .btn-ay-success {
            background: var(--ay-btn-success-bg);
            color: var(--ay-btn-success-text);
            border-color: var(--ay-btn-success-border);
        }
        .btn-ay-success:hover {
            background: var(--ay-btn-success-hover-bg);
            border-color: var(--ay-btn-success-hover-border);
            color: var(--ay-btn-success-text);
        }
        .btn-ay-send {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            box-shadow: 0 2px 8px rgba(26, 110, 245, .2);
        }
        .btn-ay-send:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
            color: #fff;
        }
        .btn-ay-sm {
            padding: .28rem .65rem;
            font-size: .78rem;
        }

        /* ============================================================
           BADGES
           ============================================================ */
        .ay-badge {
            display: inline-flex;
            align-items: center;
            gap: .3rem;
            padding: .32rem .75rem;
            border-radius: 999px;
            font-size: .78rem;
            font-weight: 700;
            letter-spacing: .03em;
        }
        .ay-badge-passed {
            background: #d1fae5;
            color: #065f46;
            border: 1.5px solid #a7f3d0;
        }
        .ay-badge-failed {
            background: #fee2e2;
            color: #991b1b;
            border: 1.5px solid #fecaca;
        }
        .ay-badge-conditional {
            background: #fef3c7;
            color: #92400e;
            border: 1.5px solid #fde68a;
        }
        [data-bs-theme="dark"] .ay-badge-passed {
            background: #17351f;
            color: #6ee7a0;
            border-color: #2b5c38;
        }
        [data-bs-theme="dark"] .ay-badge-failed {
            background: #3a1f24;
            color: #ff8b9e;
            border-color: #5c2d35;
        }
        [data-bs-theme="dark"] .ay-badge-conditional {
            background: #3a2f14;
            color: #ffcc66;
            border-color: #5c4820;
        }

        /* ============================================================
           PAGINATION
           ============================================================ */
        .ay-pagination {
            display: flex;
            gap: .3rem;
            list-style: none;
            margin: 0;
            padding: 0;
            justify-content: flex-end;
            align-items: center;
            flex-wrap: wrap;
        }
        .ay-pagination .ay-page-item .ay-page-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
            border-radius: 7px;
            font-size: .83rem;
            font-weight: 600;
            cursor: pointer;
            border: 1.5px solid var(--ay-border);
            color: #1a6ef5;
            background: var(--ay-card);
            transition: all .13s;
            padding: 0 .65rem;
        }
        .ay-pagination .ay-page-item .ay-page-link:hover {
            background: var(--ay-row-hover);
            border-color: #9cc2fc;
        }
        [data-bs-theme="dark"] .ay-pagination .ay-page-item .ay-page-link {
            color: #8ab4f8;
        }
        .ay-pagination .ay-page-item.active .ay-page-link {
            background: #1a6ef5;
            border-color: #1a6ef5;
            color: #fff;
        }
        .ay-pagination .ay-page-item.disabled .ay-page-link {
            background: var(--ay-card-soft);
            border-color: var(--ay-border);
            color: var(--ay-text-dim);
            cursor: not-allowed;
            pointer-events: none;
        }

        /* ============================================================
           SELECTS & INPUTS - FIXED FOR DARK MODE
           ============================================================ */
        .ay-select {
            border: 1.5px solid var(--ay-input-border);
            border-radius: 10px;
            padding: .42rem .85rem;
            font-size: .88rem;
            color: var(--ay-input-text);
            background: var(--ay-input-bg);
            cursor: pointer;
        }
        .ay-select:focus {
            border-color: #1a6ef5;
            outline: none;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, .1);
        }
        [data-bs-theme="dark"] .ay-select {
            color: #e4e6e8 !important;
            background-color: #3a3a3a !important;
            border-color: #4a5a6e !important;
        }
        [data-bs-theme="dark"] .ay-select option {
            background-color: #2D2D2D;
            color: #e4e6e8;
        }

        /* ============================================================
           EMPTY STATES
           ============================================================ */
        .ay-empty {
            text-align: center;
            padding: 2.5rem 1.5rem;
            color: var(--ay-text-dim);
        }
        .ay-empty i {
            font-size: 2.2rem;
            display: block;
            margin-bottom: .6rem;
            opacity: .5;
        }
        .ay-empty p {
            margin: 0;
            font-size: .95rem;
        }

        /* ============================================================
           GRADE LEVEL TEXT
           ============================================================ */
        .grade-level-text {
            font-size: .9rem;
            color: var(--ay-grade-text);
            font-weight: 600;
        }
        [data-bs-theme="dark"] .grade-level-text {
            color: #e4e6e8 !important;
        }

        .ay-left { text-align: left !important; }
        .ay-center { text-align: center !important; }

        .section-report-table .col-row { width: 56px; }
        .section-report-table .col-grade { width: 18%; }
        .section-report-table .col-section { width: 22%; }
        .section-report-table .col-students,
        .section-report-table .col-passed,
        .section-report-table .col-failed,
        .section-report-table .col-average { width: 105px; }
        .section-report-table .col-actions { width: 220px; }

        .gr-avg-pill {
            display: inline-block;
            font-size: .74rem;
            font-weight: 700;
            padding: .18rem .55rem;
            border-radius: 10px;
        }
        .avg-high { background: #d1fae5; color: #065f46; }
        .avg-mid { background: #fef3c7; color: #92400e; }
        .avg-low { background: #fee2e2; color: #991b1b; }
        [data-bs-theme="dark"] .avg-high { background: #17351f; color: #6ee7a0; }
        [data-bs-theme="dark"] .avg-mid { background: #3a2f14; color: #ffcc66; }
        [data-bs-theme="dark"] .avg-low { background: #3a1f24; color: #ff8b9e; }

        .gr-search-wrap {
            position: relative;
        }
        .gr-search-wrap i {
            position: absolute;
            left: .65rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--ay-text-muted);
            font-size: .85rem;
            pointer-events: none;
        }
        .gr-search-input {
            height: 36px;
            padding: 0 .75rem 0 2rem;
            border: 1.5px solid var(--ay-input-border);
            border-radius: 10px;
            background: var(--ay-input-bg);
            color: var(--ay-input-text);
            font-size: .85rem;
            outline: none;
            width: 210px;
            font-family: inherit;
        }
        .gr-search-input:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, .1);
        }
        [data-bs-theme="dark"] .gr-search-input {
            background-color: #3a3a3a;
            color: #e4e6e8;
            border-color: #4a5a6e;
        }
        [data-bs-theme="dark"] .gr-search-input::placeholder {
            color: #adb5bd;
        }

        .gr-select {
            height: 36px;
            padding: 0 .65rem;
            border: 1.5px solid var(--ay-input-border);
            border-radius: 10px;
            background: var(--ay-input-bg);
            color: var(--ay-input-text);
            font-size: .85rem;
            outline: none;
            font-family: inherit;
            cursor: pointer;
        }
        .gr-select:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, .1);
        }
        [data-bs-theme="dark"] .gr-select {
            background-color: #3a3a3a;
            color: #e4e6e8;
            border-color: #4a5a6e;
        }
        [data-bs-theme="dark"] .gr-select option {
            background-color: #2D2D2D;
            color: #e4e6e8;
        }

        /* ============================================================
           MOBILE CARDS
           ============================================================ */
        .ay-mobile-card {
            background: var(--ay-card);
            border: 1.5px solid var(--ay-border);
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 1px 6px rgba(18, 72, 168, .05);
        }
        .ay-mobile-card+.ay-mobile-card {
            margin-top: .75rem;
        }
        .ay-mobile-card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: .85rem 1rem;
            border-bottom: 1px solid var(--ay-border-soft);
            background: var(--ay-card-soft);
        }
        .ay-mobile-card-title {
            font-weight: 700;
            color: var(--ay-section-name);
            font-size: .95rem;
        }
        [data-bs-theme="dark"] .ay-mobile-card-title {
            color: #ffffff !important;
        }
        .ay-mobile-card-body {
            padding: .85rem 1rem;
        }
        .ay-mobile-card-body .grade-label {
            font-size: .82rem;
            color: var(--ay-text-muted);
            margin-bottom: .65rem;
        }

        @media(max-width:767.98px) {
            .ay-page-header {
                padding: 1.1rem 1.2rem;
                border-radius: 14px;
            }
            .ay-card-footer {
                justify-content: center;
            }
            .ay-pagination {
                justify-content: center;
            }
        }

        /* ============================================================
           CR TABLE (Grades Grid)
           ============================================================ */
        .cr-wrap {
            overflow-x: auto;
        }
        .cr-table {
            border-collapse: collapse;
            font-size: 8.5pt;
            font-family: Arial, sans-serif;
            min-width: 100%;
            background: var(--ay-card);
        }
        .cr-table th,
        .cr-table td {
            border: 1px solid var(--ay-border);
        }
        .cr-num {
            width: 28px;
            text-align: center;
            font-size: 8pt;
            color: var(--ay-text-muted);
            padding: 3px 2px;
        }
        .cr-name {
            min-width: 130px;
            max-width: 160px;
            padding: 4px 6px;
            font-size: 8.5pt;
            color: var(--ay-text);
        }
        .cr-grade {
            width: 52px;
            text-align: center;
            padding: 3px 2px;
            font-size: 9pt;
            color: var(--ay-text);
        }
        .cr-avg {
            width: 64px;
            text-align: center;
            font-weight: 700;
            padding: 4px 3px;
            font-size: 9pt;
        }
        .cr-subject-th {
            min-width: 100px;
            max-width: 150px;
            padding: 8px 6px;
            background: var(--ay-head-bg);
            color: var(--ay-head-text);
            font-size: 8.5pt;
            font-weight: 700;
            text-align: center;
            vertical-align: bottom;
            line-height: 1.35;
            border: 1px solid var(--ay-border);
            word-break: break-word;
            hyphens: auto;
            white-space: normal;
        }
        .cr-subject-th .cr-subject-inner {
            display: block;
            white-space: normal;
        }
        .cr-num-th {
            width: 28px;
            text-align: center;
            font-size: 8pt;
            font-weight: 700;
            background: var(--ay-head-bg);
            color: var(--ay-head-text);
            vertical-align: bottom;
            padding: 5px 2px;
        }
        .cr-header-num {
            text-align: center;
            font-size: 8pt;
            font-weight: 700;
            padding: 3px 2px;
            background: var(--ay-card-soft);
            color: var(--ay-head-text);
        }
        .cr-name-th {
            min-width: 130px;
            max-width: 160px;
            padding: 5px 6px;
            font-size: 9pt;
            font-weight: 700;
            color: var(--ay-head-text);
            background: var(--ay-head-bg);
            vertical-align: bottom;
        }
        .cr-avg-th {
            width: 64px;
            text-align: center;
            font-size: 9pt;
            font-weight: 700;
            background: var(--ay-head-bg);
            color: var(--ay-head-text);
            vertical-align: bottom;
            padding: 5px 3px;
        }
        .cr-row-group {
            background: var(--ay-card-soft);
            font-weight: 700;
            font-size: 8.5pt;
        }
        .cr-row-group td {
            padding: 3px 8px;
            color: var(--ay-text-strong);
            letter-spacing: .04em;
        }
        .cr-pass {
            color: #059669;
            font-weight: 700;
        }
        .cr-fail {
            color: #dc2626;
            font-weight: 700;
        }
        [data-bs-theme="dark"] .cr-pass { color: #6ee7a0; }
        [data-bs-theme="dark"] .cr-fail { color: #ff8b9e; }

        .cr-avg-cell {
            background: var(--ay-card-soft);
            font-weight: 700;
        }
        .cr-empty-row td {
            background: var(--ay-card);
        }
        .cr-empty-row:nth-child(even) td {
            background: var(--ay-card-soft);
        }

        /* ============================================================
           SEND GRADES MODAL
           ============================================================ */
        .sg-modal-content {
            border: none;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 8px 40px rgba(18, 72, 168, .18);
            background: var(--ay-card);
        }
        .sg-modal-header {
            background: linear-gradient(130deg, #1248a8, #1a6ef5);
            color: #fff;
            padding: 1rem 1.4rem;
            display: flex;
            align-items: center;
            gap: .85rem;
        }
        .sg-modal-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            background: rgba(255, 255, 255, .18);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            flex-shrink: 0;
        }
        .sg-modal-title {
            font-size: 1.05rem;
            font-weight: 700;
            margin: 0 0 .1rem;
        }
        .sg-modal-subtitle {
            font-size: .78rem;
            opacity: .88;
            margin: 0;
        }
        .sg-close-btn {
            margin-left: auto;
            background: rgba(255, 255, 255, .15);
            border: 1.5px solid rgba(255, 255, 255, .3);
            color: #fff;
            border-radius: 8px;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: .9rem;
            flex-shrink: 0;
            transition: .14s;
        }
        .sg-close-btn:hover {
            background: rgba(255, 255, 255, .28);
        }
        .sg-modal-body {
            padding: 1.2rem 1.4rem;
            background: var(--ay-card);
        }
        .sg-modal-footer {
            padding: .85rem 1.4rem;
            border-top: 1px solid var(--ay-border-soft);
            background: var(--ay-card-soft);
            display: flex;
            justify-content: flex-end;
            gap: .55rem;
            flex-wrap: wrap;
        }

        .sg-section-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: .65rem;
            margin-top: .75rem;
            max-height: 340px;
            overflow-y: auto;
            padding-right: 4px;
        }
        .sg-section-item {
            border: 1.5px solid var(--ay-border);
            border-radius: 12px;
            padding: .75rem 1rem;
            cursor: pointer;
            transition: .15s;
            display: flex;
            align-items: center;
            gap: .65rem;
            user-select: none;
            background: var(--ay-card);
        }
        .sg-section-item:hover {
            border-color: #1a6ef5;
            background: var(--ay-row-hover);
        }
        .sg-section-item.selected {
            border-color: #1a6ef5;
            background: var(--ay-row-hover);
            box-shadow: 0 0 0 2px rgba(26, 110, 245, .2);
        }
        .sg-section-item .sg-check {
            width: 20px;
            height: 20px;
            border-radius: 6px;
            border: 2px solid var(--ay-input-border);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            font-size: .78rem;
            color: #fff;
            transition: .14s;
        }
        .sg-section-item.selected .sg-check {
            background: #1a6ef5;
            border-color: #1a6ef5;
        }
        .sg-section-name {
            font-weight: 700;
            font-size: .88rem;
            color: var(--ay-text-strong);
        }
        .sg-section-meta {
            font-size: .74rem;
            color: var(--ay-text-muted);
        }
        .sg-filter-row {
            display: flex;
            gap: .55rem;
            flex-wrap: wrap;
            align-items: center;
        }
        .sg-filter-input {
            height: 36px;
            padding: 0 .75rem;
            border: 1.5px solid var(--ay-input-border);
            border-radius: 10px;
            font-size: .84rem;
            color: var(--ay-input-text);
            background: var(--ay-input-bg);
            outline: none;
            width: 200px;
        }
        .sg-filter-input:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, .1);
        }
        .sg-filter-select {
            height: 36px;
            padding: 0 .65rem;
            border: 1.5px solid var(--ay-input-border);
            border-radius: 10px;
            font-size: .84rem;
            color: var(--ay-input-text);
            background: var(--ay-input-bg);
            cursor: pointer;
            outline: none;
        }
        .sg-filter-select:focus {
            border-color: #1a6ef5;
            box-shadow: 0 0 0 3px rgba(26, 110, 245, .1);
        }
        .sg-select-all-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-top: .85rem;
            margin-bottom: .1rem;
        }
        .sg-select-all-label {
            font-size: .82rem;
            font-weight: 700;
            color: #1a6ef5;
        }
        .sg-count-chip {
            display: inline-flex;
            align-items: center;
            gap: .3rem;
            background: var(--ay-row-hover);
            border: 1.5px solid var(--ay-border);
            border-radius: 999px;
            padding: .22rem .75rem;
            font-size: .76rem;
            font-weight: 700;
            color: var(--ay-text-strong);
        }
        .sg-info-box {
            background: var(--ay-row-hover);
            border: 1.5px solid var(--ay-border);
            border-radius: 10px;
            padding: .7rem 1rem;
            font-size: .82rem;
            color: var(--ay-text);
            margin-bottom: .85rem;
            display: flex;
            gap: .5rem;
            align-items: flex-start;
        }
        .sg-info-box i {
            flex-shrink: 0;
            margin-top: .1rem;
            font-size: 1rem;
        }
        .sg-quarter-pills {
            display: flex;
            gap: .4rem;
            flex-wrap: wrap;
            margin-bottom: .75rem;
        }
        .sg-q-pill {
            border: 1.5px solid var(--ay-input-border);
            border-radius: 999px;
            padding: .28rem .85rem;
            font-size: .78rem;
            font-weight: 600;
            color: var(--ay-text);
            cursor: pointer;
            background: var(--ay-card);
            transition: .14s;
        }
        .sg-q-pill:hover {
            border-color: #1a6ef5;
            color: #1a6ef5;
            background: var(--ay-row-hover);
        }
        .sg-q-pill.active {
            background: #1a6ef5;
            border-color: #1248a8;
            color: #fff;
        }
        .sg-progress-wrap {
            text-align: center;
            padding: 2.5rem 1rem;
        }
        .sg-spinner {
            width: 48px;
            height: 48px;
            border: 4px solid var(--ay-border);
            border-top-color: #1a6ef5;
            border-radius: 50%;
            animation: sgspin .75s linear infinite;
            margin: 0 auto 1.1rem;
        }
        @keyframes sgspin {
            to { transform: rotate(360deg) }
        }
        .sg-progress-title {
            font-size: 1rem;
            font-weight: 700;
            color: var(--ay-text-strong);
            margin-bottom: .3rem;
        }
        .sg-progress-sub {
            font-size: .82rem;
            color: var(--ay-text-muted);
        }
        .sg-result-ok {
            background: #ecfdf5;
            border: 1.5px solid #6ee7b7;
            border-radius: 12px;
            padding: .85rem 1rem;
            font-size: .88rem;
            color: #065f46;
        }
        .sg-result-ok h6 {
            font-size: .92rem;
            font-weight: 700;
            margin: 0 0 .3rem;
        }
        [data-bs-theme="dark"] .sg-result-ok {
            background: #17351f;
            border-color: #2b5c38;
            color: #6ee7a0;
        }

        .btn-sg-outline {
            background: var(--ay-btn-outline-bg);
            color: var(--ay-btn-outline-text);
            border: 1.5px solid var(--ay-btn-outline-border);
            border-radius: 8px;
            padding: .42rem .9rem;
            font-size: .82rem;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: .3rem;
            transition: .14s;
        }
        .btn-sg-outline:hover {
            background: var(--ay-btn-outline-hover-bg);
            border-color: var(--ay-btn-outline-hover-border);
        }
        .btn-sg-primary {
            background: linear-gradient(130deg, #1a6ef5, #1248a8);
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: .42rem 1.1rem;
            font-size: .82rem;
            font-weight: 700;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: .3rem;
            transition: .14s;
            box-shadow: 0 2px 8px rgba(26, 110, 245, .25);
        }
        .btn-sg-primary:hover {
            background: linear-gradient(130deg, #1560d8, #103d90);
        }
        .btn-sg-primary:disabled {
            opacity: .55;
            cursor: not-allowed;
        }

        /* ============================================================
           MODAL DARK MODE FIXES
           ============================================================ */
        [data-bs-theme="dark"] #sendGradesModal .modal-content {
            background-color: #2D2D2D !important;
        }
        [data-bs-theme="dark"] #sendGradesModal .sg-modal-body {
            background-color: #2D2D2D !important;
            color: #e4e6e8 !important;
        }
        [data-bs-theme="dark"] #sendGradesModal .sg-modal-footer {
            background-color: #262626 !important;
            border-top-color: #3a3a3a !important;
        }
        [data-bs-theme="dark"] #sendGradesModal .sg-filter-input,
        [data-bs-theme="dark"] #sendGradesModal .sg-filter-select {
            background-color: #3a3a3a !important;
            color: #e4e6e8 !important;
            border-color: #4a5a6e !important;
        }
        [data-bs-theme="dark"] #sendGradesModal .sg-filter-select option {
            background-color: #2D2D2D;
            color: #e4e6e8;
        }

        /* ============================================================
           PRINT
           ============================================================ */
        #printArea {
            display: none;
        }

        @media print {
            @page {
                size: A4 portrait;
                margin: 15mm;      /* 180mm x 267mm usable inside A4 portrait */
            }
            body>*:not(#printArea) {
                display: none !important;
            }
            html,
            body {
                width: 176mm;
                max-width: 176mm;
                height: auto;        /* AUTO — a fixed height clips printing to a single page */
                margin: 0;
                padding: 0;
                background: #fff;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
                overflow: visible;   /* must NOT be hidden — hidden clips pages 2..N */
            }
            #printArea {
                display: block !important;
                width: 176mm;
                max-width: 176mm;
                margin: 0;
                padding: 0;
                overflow: visible;
            }
            /* ── Form 138 / SF9 — one sheet per learner ── */
            .rc-page {
                width: 176mm;
                max-width: 176mm;
                height: 267mm;
                max-height: 267mm;
                padding: 3mm;
                margin: 0;
                box-sizing: border-box;
                overflow: hidden;
                display: block;
                page-break-after: always !important;
                page-break-inside: avoid !important;
                break-after: page !important;
                break-inside: avoid !important;
                background: #fff;
                position: relative;
            }
            .rc-page:last-child {
                page-break-after: auto !important;
                break-after: auto !important;
            }
            .rc-page>.sf9-wrap {
                /* No zoom / no scale — plain responsive sizing (one .rc-page per learner) */
                width: 100%;
                height: auto;
                flex: 0 0 auto;
                min-height: 0;
                box-sizing: border-box;
                overflow: hidden;
            }
        }

        #printArea {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 6.5pt;
            line-height: 1.15;
            color: #000;
            background: #fff;
        }
        .rc-page {
            width: 176mm;
            max-width: 176mm;
            height: 267mm;
            max-height: 267mm;
            padding: 3mm;
            margin: 0 auto;
            box-sizing: border-box;
            overflow: hidden;
            display: block;
            page-break-after: always !important;
            page-break-inside: avoid !important;
            break-after: page !important;
            break-inside: avoid !important;
            background: #fff;
            position: relative;
        }
        .rc-page:last-child {
            page-break-after: auto;
            break-after: auto;
        }
        .sf9-wrap {
            width: 100%;
            height: auto;
            display: flex;
            flex-direction: column;
            box-sizing: border-box;
            overflow: hidden;
        }
        .sf9-top {
            display: flex;
            width: 100%;
            flex-wrap: nowrap;
            align-items: flex-start;
            overflow: hidden;
            gap: 4px;
        }
        .sf9-left {
            flex: 1 1 0;
            min-width: 0;
            border-right: 1.5px solid #000;
            padding: 0 4px 0 0;
            display: flex;
            flex-direction: column;
            box-sizing: border-box;
            overflow: hidden;
        }
        .sf9-right {
            flex: 1 1 0;
            min-width: 0;
            padding: 0 0 0 4px;
            display: flex;
            flex-direction: column;
            box-sizing: border-box;
            overflow: hidden;
        }
        .sf9-sec {
            text-align: center;
            font-weight: bold;
            font-size: 5.5pt;
            border-top: 1.5px solid #000;
            border-bottom: 1.5px solid #000;
            padding: 1.5px 0;
            margin: 3px 0 2px;
            text-transform: uppercase;
            letter-spacing: .4px;
        }
        .sf9-gt {
            width: 100%;
            border-collapse: collapse;
            font-size: 6pt;
        }
        .sf9-gt th,
        .sf9-gt td {
            border: 1px solid #000;
            padding: 1px 3px;
            text-align: center;
        }
        .sf9-gt th {
            font-size: 6pt;
            font-weight: bold;
            background: #f0f0f0;
        }
        .sf9-gt .sc {
            text-align: left;
            padding-left: 3px;
            font-size: 6pt;
        }
        .sf9-gt .fc {
            font-weight: bold;
            background: #f8f8f8;
        }
        .sf9-gt .fg {
            color: #cc0000;
        }
        .sf9-gt .pg {
            color: #000;
        }
        .sf9-dt {
            width: 100%;
            border-collapse: collapse;
            font-size: 6pt;
            margin-top: 2px;
        }
        .sf9-dt th,
        .sf9-dt td {
            border: 1px solid #000;
            padding: 1px 3px;
        }
        .sf9-dt th {
            font-weight: bold;
            background: #f0f0f0;
        }
        .sf9-at {
            width: 100%;
            border-collapse: collapse;
            font-size: 6pt;
            margin-top: 2px;
        }
        .sf9-at th,
        .sf9-at td {
            border: 1px solid #000;
            padding: 1px 2px;
            text-align: center;
        }
        .sf9-at th {
            background: #f0f0f0;
            font-weight: bold;
            font-size: 6pt;
        }
        .sf9-at td.lft {
            text-align: left;
            padding-left: 3px;
            white-space: nowrap;
            font-size: 6pt;
        }
        .sf9-vt {
            width: 100%;
            border-collapse: collapse;
            font-size: 6pt;
        }
        .sf9-vt th,
        .sf9-vt td {
            border: 1px solid #000;
            padding: 1px 3px;
        }
        .sf9-vt th {
            font-size: 6pt;
            font-weight: bold;
            text-align: center;
            background: #f0f0f0;
        }
        .sf9-vt .qc {
            text-align: center;
            width: 15px;
            font-size: 6pt;
        }
        .sf9-mt {
            width: 100%;
            border-collapse: collapse;
            font-size: 6pt;
            margin-top: 3px;
        }
        .sf9-mt th,
        .sf9-mt td {
            border: 1px solid #000;
            padding: 1px 4px;
        }
        .sf9-mt th {
            font-weight: bold;
            background: #f0f0f0;
        }
        .shs-wrap {
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            box-sizing: border-box;
        }
        .shs-gt {
            width: 100%;
            border-collapse: collapse;
            font-size: 8.5pt;
        }
        .shs-gt th,
        .shs-gt td {
            border: 1px solid #000;
            padding: 2.5px 4px;
        }
        .shs-gt th {
            font-size: 8pt;
            font-weight: bold;
            text-align: center;
            background: #f0f0f0;
        }
        .shs-gt .sc {
            text-align: left;
            padding-left: 6px;
        }
        .shs-gt .ch td {
            font-weight: bold;
            font-size: 8pt;
            background: #e8e8e8;
            font-style: italic;
        }
        .shs-gt .ar td {
            font-weight: bold;
            background: #e8e8e8;
        }
        .shs-gt .nc {
            text-align: center;
        }
        .shs-gt .fg {
            color: #cc0000;
        }
    /* ============================================================
           PRINT HARDENING — Form 138 single-sheet guarantees
           (placed last so it overrides every earlier declaration)
           ============================================================ */
        .rc-page-label {
            font-size: 6pt;
            line-height: 1;
            color: #555;
            text-align: right;
            margin: 0 0 1px;
        }
        @media print {
            @page {
                size: A4 portrait;
                margin: 15mm;
            }
            html,
            body {
                width: 176mm;
                max-width: 176mm;
                margin: 0;
                padding: 0;
                overflow: visible;          /* visible so pages 2..N are NOT clipped */
            }
            #printArea {
                width: 176mm;
                max-width: 176mm;
                margin: 0;
                padding: 0;
                overflow: visible;
            }
            .rc-page {
                width: 176mm !important;
                max-width: 176mm !important;
                height: 267mm !important;
                max-height: 267mm !important;
                margin: 0 !important;
                padding: 3mm !important;
                overflow: hidden !important;
                page-break-after: always !important;
                break-after: page !important;
                page-break-inside: avoid !important;
                break-inside: avoid !important;
                box-sizing: border-box !important;
                position: relative;
            }
            .rc-page:last-child {
                page-break-after: auto !important;
                break-after: auto !important;
            }
            .sf9-wrap,
            .sf9-top,
            .sf9-left,
            .sf9-right {
                width: 100% !important;
                max-width: 100% !important;
                overflow: hidden !important;
                box-sizing: border-box !important;
            }
            .sf9-top {
                display: flex !important;
                flex-wrap: nowrap !important;
            }
            .rc-page-label {
                display: none;              /* dev-only label — reclaims vertical space */
            }
            .sf9-card,
            .print-card {
                page-break-inside: avoid !important;
                break-inside: avoid !important;
            }
            table,
            tr,
            td,
            th {
                page-break-inside: avoid;
            }
            .sf9-gt,
            .sf9-at,
            .sf9-vt,
            .sf9-mt,
            .sf9-dt,
            .shs-gt {
                page-break-inside: avoid;
            }
        }
    </style>
</head>

<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
    <div class="app-wrapper">
        <?php require_once("includes/header.php"); ?>
        <?php require_once("includes/sidebar.php"); ?>
        <main class="app-main">
            <div class="app-content">
                <div class="container-fluid py-3">

                    <div class="page-header">
                        <div>
                            <h3><i class="bi bi-bar-chart-line me-2"></i>Grades Report</h3>
                            <p>View &amp; print student grades by section (K-12 DepEd format)</p>
                        </div>
                    </div>


                    <?php require_once __DIR__ . '/includes/breadcrumb.php';
                    renderBreadcrumb([
                        ['label' => 'Home', 'href' => 'Dashboard.php', 'icon' => 'bi bi-house-door-fill'],
                        ['label' => 'Maintenance', 'href' => 'grades-report.php', 'icon' => 'bi bi-tools'],
                        ['label' => 'Reports', 'href' => 'grades-report.php', 'icon' => 'bi bi-bar-chart-fill']
                    ]); ?>
                    <div id="view-sections">
                        <div class="ay-card">
                            <div class="ay-card-header">
                                <div>
                                    <p class="ay-card-title">Sections &amp; Grade Levels</p>
                                    <p class="ay-card-subtitle" id="sectionSubtitle">Click a section to view &amp; print
                                        student grades.</p>
                                </div>
                                <div style="display:flex;gap:.5rem;align-items:center;flex-wrap:wrap;">
                                    <select class="ay-select" id="gradeLevelFilter" onchange="loadSections()">
                                        <option value="">All Grade Levels</option>
                                        <?php foreach ($allGradeLevels as $gl): ?>
                                            <option value="<?= (int) $gl['id'] ?>">
                                                <?= htmlspecialchars($gl['grade_level_name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <select class="ay-select" id="quarterFilter" onchange="loadSections()"></select>

                                    <!-- <button class="btn-ay btn-ay-primary" onclick="openSendGradesModal()">
                                        <i class="bi bi-send-fill"></i> Send Grades
                                    </button> -->

                                </div>
                            </div>
                            <div class="d-none d-md-block">
                                <table class="ay-table section-report-table" id="sectionTable">
                                    <colgroup>
                                        <col class="col-row">
                                        <col class="col-grade">
                                        <col class="col-section">
                                        <col class="col-students">
                                        <col class="col-passed">
                                        <col class="col-failed">
                                        <col class="col-average">
                                        <col class="col-actions">
                                    </colgroup>
                                    <thead>
                                        <tr>
                                            <th class="ay-center">#</th>
                                            <th class="ay-left">Grade Level</th>
                                            <th class="ay-left">Section Name</th>
                                            <th class="ay-center">Students</th>
                                            <th class="ay-center">Passed</th>
                                            <th class="ay-center">Failed</th>
                                            <th class="ay-center">Class Avg</th>
                                            <th class="ay-center">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="sectionTableBody">
                                        <tr>
                                            <td colspan="8">
                                                <div class="ay-empty"><span
                                                        class="spinner-border spinner-border-sm me-1"></span> Loading…
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="d-block d-md-none p-3" id="sectionCardView"></div>
                            <div class="ay-card-footer">
                                <div class="ay-footer-note" id="sectionCountText"></div>
                                <ul class="ay-pagination" id="sectionPagination"></ul>
                            </div>
                        </div>
                    </div>


                    <div id="view-grades" style="display:none">
                        <div style="display:flex;align-items:center;gap:.75rem;flex-wrap:wrap;margin-bottom:1.25rem;">
                            <div>
                                <h5 class="mb-0" id="detailTitle" style="font-weight:700;color:var(--ay-text-strong);"></h5>
                                <p class="mb-0" id="detailSub" style="font-size:.82rem;color:var(--ay-text-muted);"></p>
                            </div>
                        </div>
                        <div class="ay-card">
                            <div class="ay-card-header">
                                <div>
                                    <p class="ay-card-title" id="tableCardTitle">Student Grades</p>
                                    <p class="ay-card-subtitle" id="tableCardSub"></p>
                                </div>
                                <div style="display:flex;gap:.5rem;align-items:center;flex-wrap:wrap;">
                                    <div class="gr-search-wrap"><i class="bi bi-search"></i><input type="text"
                                            class="gr-search-input" id="studentSearch"
                                            placeholder="Search name or LRN..." oninput="applyFilters()"></div>
                                    <select class="gr-select" id="remarkFilter" onchange="applyFilters()">
                                        <option value="">All Remarks</option>
                                        <option value="Passed">Passed</option>
                                        <option value="Failed">Failed</option>
                                        <option value="Conditional">Conditional</option>
                                    </select>
                                    <!-- <button class="btn-ay btn-ay-primary btn-ay-sm"
                                        onclick="openSendGradesModal(currentSection?.id)">
                                        <i class="bi bi-send-fill"></i> Send Grades
                                    </button> -->
                                    <button class="btn-ay btn-ay-success" id="printReportBtn" onclick="printReportCards()"><i
                                            class="bi bi-printer"></i> <span id="printReportCardsLabel">Print Report Cards</span></button>
                                    <!-- (removed — will be re-added in chain view) -->
                                    <button class="btn-ay btn-ay-primary" onclick="exportSection()"><i
                                            class="bi bi-download"></i> Export CSV</button>
                                    <!-- Download CSV removed (duplicate of Export CSV) -->
                                </div>
                            </div>
                            <div class="d-none d-md-block cr-wrap">
                                <table class="cr-table">
                                    <thead id="gradesHead"></thead>
                                    <tbody id="gradesBody">
                                        <tr>
                                            <td colspan="20">
                                                <div class="ay-empty"><i class="bi bi-hourglass-split"></i>
                                                    <p>Loading...</p>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="d-block d-md-none p-3" id="gradesCardView"></div>
                            <div class="ay-card-footer">
                                <div class="ay-footer-note" id="gradeCountText"></div>
                                <ul class="ay-pagination" id="gradePagination"></ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </main>
        <?php require_once("includes/footer.php"); ?>
    </div>


    <div id="printArea"></div>


    <div class="modal fade" id="sendGradesModal" tabindex="-1" aria-labelledby="sendGradesModalLabel" aria-hidden="true"
        data-bs-backdrop="false">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content sg-modal-content">


                <div class="sg-modal-header">
                    <div class="sg-modal-icon"><i class="bi bi-send-fill"></i></div>
                    <div>
                        <h5 class="sg-modal-title" id="sendGradesModalLabel">Send Grades to Students</h5>
                        <p class="sg-modal-subtitle">Select sections and quarters — grade notifications will be sent to
                            all enrolled students.</p>
                    </div>
                    <button type="button" class="sg-close-btn" data-bs-dismiss="modal"><i
                            class="bi bi-x-lg"></i></button>
                </div>


                <div class="sg-modal-body" id="sgStep1">
                    <div class="sg-info-box">
                        <i class="bi bi-info-circle-fill"></i>
                        <div>Students with a linked account will receive an in-app notification with their grades for
                            the selected quarter(s). You can send to a single section or all sections at once.</div>
                    </div>


                    <div style="margin-bottom:.75rem;">
                        <label
                            style="font-size:.78rem;font-weight:700;color:var(--ay-text-strong);display:block;margin-bottom:.45rem;"><i
                                class="bi bi-calendar3 me-1"></i>Select Quarter(s) to Include</label>
                        <div class="sg-quarter-pills" id="sgQuarterPills">
                            <span class="sg-q-pill active" data-q="all">All Quarters</span>
                        </div>
                    </div>


                    <div class="sg-filter-row" style="margin-bottom:.65rem;">
                        <input type="text" class="sg-filter-input" id="sgSectionSearch"
                            placeholder="Search section name…" oninput="filterSgSections()">
                        <select class="sg-filter-select" id="sgGradeFilter" onchange="filterSgSections()">
                            <option value="">All Grade Levels</option>
                            <?php foreach ($allGradeLevels as $gl): ?>
                                <option value="<?= (int) $gl['id'] ?>"><?= htmlspecialchars($gl['grade_level_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="sg-select-all-bar">
                        <label
                            style="display:flex;align-items:center;gap:.45rem;cursor:pointer;font-size:.85rem;font-weight:700;color:var(--ay-text-strong);">
                            <input type="checkbox" id="sgSelectAll"
                                style="width:16px;height:16px;accent-color:#1a6ef5;cursor:pointer;"
                                onchange="toggleSelectAll(this.checked)">
                            Select All Sections
                        </label>
                        <span class="sg-count-chip" id="sgCountChip"><i class="bi bi-check2-square"></i> 0
                            selected</span>
                    </div>

                    <div class="sg-section-grid" id="sgSectionGrid">
                        <div style="grid-column:1/-1;text-align:center;padding:2rem;color:var(--ay-text-dim);">
                            <span class="spinner-border spinner-border-sm me-1"></span> Loading sections…
                        </div>
                    </div>
                </div>


                <div class="sg-modal-body d-none" id="sgStep2">
                    <div class="sg-progress-wrap">
                        <div class="sg-spinner"></div>
                        <p class="sg-progress-title">Sending grade notifications…</p>
                        <p class="sg-progress-sub" id="sgProgressSub">Preparing data, please wait.</p>
                    </div>
                </div>


                <div class="sg-modal-body d-none" id="sgStep3">
                    <div class="sg-result-ok" id="sgResultBox">
                        <h6><i class="bi bi-check-circle-fill me-2"></i>Notifications Sent Successfully</h6>
                        <ul id="sgResultList" style="margin:0;padding-left:1.1rem;font-size:.85rem;"></ul>
                    </div>
                </div>

                <div class="sg-modal-footer">
                    <button type="button" class="btn-sg-outline" data-bs-dismiss="modal"
                        id="sgCancelBtn">Cancel</button>
                    <!-- <button type="button" class="btn-sg-primary" id="sgSendBtn" onclick="doSendGrades()" disabled>
                        <i class="bi bi-send-fill me-1"></i> Send Grades
                    </button> -->
                    <button type="button" class="btn-sg-primary d-none" id="sgDoneBtn" onclick="sgFinish()">
                        <i class="bi bi-check2 me-1"></i> Done
                    </button>
                </div>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>
    <script src="./js/adminlte.js"></script>
    <script>

        let currentYearId = <?= $viewingYear ? (int) $viewingYear['id'] : 'null' ?>;
        let currentSection = null;
        let allStudents = [];
        let filteredStudents = [];
        let currentPage = 1;
        const PER_PAGE = 30;
        let currentSectionData = null;
        let currentSectionPage = 1;
        const SECTION_PER_PAGE = 5;
        let allSectionsCache = [];

        const GRADE_LEVEL_MAP = {
            0: { name: 'Kindergarten' }, 1: { name: 'Grade 1' }, 2: { name: 'Grade 2' }, 3: { name: 'Grade 3' },
            4: { name: 'Grade 4' }, 5: { name: 'Grade 5' }, 6: { name: 'Grade 6' }, 7: { name: 'Grade 7' },
            8: { name: 'Grade 8' }, 9: { name: 'Grade 9' }, 10: { name: 'Grade 10' }, 11: { name: 'Grade 11' }, 12: { name: 'Grade 12' }
        };

        // ============================================================
        // Form 138 (K-10) 3-TERM STRUCTURE — tblconfig_terms
        // ============================================================
        const FORM_TERMS = <?= json_encode(array_values($formTerms)) ?>;
        const TERM_LABELS = <?= json_encode($termLabels) ?>;
        const TERM_NUMBERS = (FORM_TERMS.length ? FORM_TERMS.map(t => Number(t.term_number)) : [1, 2, 3]);
        const TERM_HEADER_CAPTION = (FORM_TERMS.length
            ? FORM_TERMS.map(t => String(t.term_label || ('Term ' + t.term_number))).join(' · ')
            : 'Term 1 · Term 2 · Term 3');

        /** Term number -> full label ("1st Term") with safe fallback */
        function termLabel(n) { return TERM_LABELS[n] || ('Term ' + n); }
        /** Term number -> compact column header ("Term 1") */
        function termShort(n) { return 'Term ' + n; }

        // Dynamic descriptor set (tbldescriptors, NUMERICAL) — used by the class record cells
        const SF9_DESCRIPTORS = <?= json_encode(getDescriptorsByType($pdo, 'NUMERICAL')) ?>;

        // Form 138 / SF9 print legend (DepEd descriptors)
        const SF9_FORM138_LEGEND = [
            { descriptor: 'Outstanding', code: 'O', from: 90, to: 100, remarks: 'Passed' },
            { descriptor: 'Very Satisfactory', code: 'VS', from: 85, to: 89, remarks: 'Passed' },
            { descriptor: 'Satisfactory', code: 'S', from: 80, to: 84, remarks: 'Passed' },
            { descriptor: 'Fairly Satisfactory', code: 'FS', from: 75, to: 79, remarks: 'Passed' },
            { descriptor: 'Did Not Meet Expectations', code: 'DNME', from: 0, to: 74, remarks: 'Failed' }
        ];
        const SF9_LEGEND_ROWS = SF9_FORM138_LEGEND.map(d =>
            `<tr><td class="sc">${d.descriptor} (${d.code})</td><td class="nc">${d.code === 'DNME' ? 'Below 75' : d.from + '-' + d.to}</td><td class="nc">${d.remarks}</td></tr>`
        ).join('');

        function esc(v) { return String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;'); }
        function escText(v) { return String(v ?? ''); }

        function toast(msg, type = 'success') {
            const map = { success: { title: 'Success', color: 'green', icon: 'bi bi-check-circle-fill' }, danger: { title: 'Error', color: 'red', icon: 'bi bi-exclamation-octagon-fill' }, warning: { title: 'Warning', color: 'yellow', icon: 'bi bi-exclamation-triangle-fill' }, info: { title: 'Info', color: 'blue', icon: 'bi bi-info-circle-fill' } };
            const c = map[type] || map.success;
            iziToast.show({ title: c.title, message: msg, color: c.color, icon: c.icon, iconColor: '#fff', theme: 'light', position: 'topRight', timeout: 5000, progressBar: true, close: true, pauseOnHover: true, transitionIn: 'fadeInDown', transitionOut: 'fadeOutUp', maxWidth: 460 });
        }

        async function fetchJson(url, options = {}) {
            const res = await fetch(url, options); const raw = await res.text();
            try { return JSON.parse(raw); } catch (e) { console.error('Non-JSON:', raw); throw new Error('Server returned an invalid response.'); }
        }

        function buildPagination(containerId, page, pages, fn) {
            let html = `<li class="ay-page-item ${page <= 1 ? 'disabled' : ''}"><a class="ay-page-link" href="javascript:void(0)" onclick="${fn}(${page - 1})">Previous</a></li>`;
            for (let n = 1; n <= pages; n++) html += `<li class="ay-page-item ${n === page ? 'active' : ''}"><a class="ay-page-link" href="javascript:void(0)" onclick="${fn}(${n})">${n}</a></li>`;
            html += `<li class="ay-page-item ${page >= pages ? 'disabled' : ''}"><a class="ay-page-link" href="javascript:void(0)" onclick="${fn}(${page + 1})">Next</a></li>`;
            document.getElementById(containerId).innerHTML = html;
        }

        function avgPillClass(avg) { return avg >= 85 ? 'avg-high' : avg >= 75 ? 'avg-mid' : 'avg-low'; }
        function gradeClass(g) { return g >= 75 ? 'cr-pass' : 'cr-fail'; }
        function remarkBadgeClass(r) { if (r === 'Passed') return 'ay-badge-passed'; if (r === 'Failed') return 'ay-badge-failed'; return 'ay-badge-conditional'; }

        /* ══════════════════════════════════════════════════════════════
           QUARTER FILTER
        ══════════════════════════════════════════════════════════════ */
        async function loadQuarterFilter() {
            try {
                const data = await fetchJson(`api/terms/read.php?year_id=${currentYearId}`);
                const select = document.getElementById('quarterFilter');
                const terms = (data.terms || [])
                    .sort((a, b) => Number(a.term_number) - Number(b.term_number));
                select.innerHTML = '';

                if (!terms.length) {
                    const opt = document.createElement('option');
                    opt.value = '';
                    opt.textContent = 'No terms configured';
                    select.appendChild(opt);
                    select.disabled = true;
                    return;
                }

                select.disabled = false;

                // Add "All Terms" option
                const allOpt = document.createElement('option');
                allOpt.value = '';
                allOpt.textContent = 'All Terms';
                allOpt.selected = true;
                select.appendChild(allOpt);

                terms.forEach(t => {
                    const opt = document.createElement('option');
                    opt.value = t.id;
                    opt.textContent = t.term_label;
                    select.appendChild(opt);
                });
            } catch (e) {
                console.error('Term filter load error:', e);
                const select = document.getElementById('quarterFilter');
                select.innerHTML = '<option value="">No terms</option>';
                select.disabled = true;
            }
        }

        function changeYear(id) {
            currentYearId = id; allSectionsCache = [];
            loadQuarterFilter(); loadSections();
        }

        /* ══════════════════════════════════════════════════════════════
           SECTIONS LIST
        ══════════════════════════════════════════════════════════════ */
        async function loadSections() {
            const gradeLevel = document.getElementById('gradeLevelFilter').value;
            const quarterId = document.getElementById('quarterFilter').value;
            document.getElementById('sectionTableBody').innerHTML = `<tr><td colspan="8"><div class="ay-empty"><span class="spinner-border spinner-border-sm me-1"></span> Loading sections…</div></td></tr>`;
            document.getElementById('sectionCardView').innerHTML = `<div class="ay-empty"><span class="spinner-border spinner-border-sm me-1"></span> Loading…</div>`;
            try {
                let url = `api/grades/sections.php?year_id=${currentYearId}`;
                if (gradeLevel) url += `&grade_level=${gradeLevel}`;
                if (quarterId) url += `&quarter_id=${quarterId}`;
                const data = await fetchJson(url);
                allSectionsCache = data.sections || [];   // cache for send-grades modal
                renderSections(data.sections || [], data.quarter_label || '');
            } catch (e) { toast(e.message, 'danger'); document.getElementById('sectionTableBody').innerHTML = `<tr><td colspan="8"><div class="ay-empty"><i class="bi bi-exclamation-circle"></i><p>Failed to load sections.</p></div></td></tr>`; }
        }

        function renderSections(list, quarterLabel) {
            const tbody = document.getElementById('sectionTableBody');
            const cards = document.getElementById('sectionCardView');
            const countEl = document.getElementById('sectionCountText');
            if (!list.length) {
                const empty = `<div class="ay-empty"><i class="bi bi-journals"></i><p>No sections found for this selection.</p></div>`;
                tbody.innerHTML = `<tr><td colspan="8">${empty}</td></tr>`; cards.innerHTML = empty;
                if (countEl) countEl.textContent = ''; document.getElementById('sectionPagination').innerHTML = ''; return;
            }
            const sectionPages = Math.max(1, Math.ceil(list.length / SECTION_PER_PAGE));
            if (currentSectionPage > sectionPages) currentSectionPage = 1;
            const offset = (currentSectionPage - 1) * SECTION_PER_PAGE;
            const slice = list.slice(offset, offset + SECTION_PER_PAGE);
            if (countEl) countEl.textContent = `${list.length} section${list.length === 1 ? '' : 's'} found`;

            tbody.innerHTML = slice.map((s, i) => {
                const avg = Number(s.class_average || 0), enrolled = Number(s.enrolled || 0), passed = Number(s.passed || 0), failed = Number(s.failed || 0);
                const glCode = Number(s.grade_level_code ?? 0);
                const glName = (GRADE_LEVEL_MAP[glCode] || {}).name || s.grade_level_name || 'Unknown';
                return `<tr>
            <td class="ay-center" style="color:var(--ay-text-dim);font-size:.82rem;">${offset + i + 1}</td>
            <td class="ay-left"><span class="grade-level-text">${glName}</span></td>
            <td class="ay-left"><strong style="color:var(--ay-text-strong);">${esc(s.section_name)}</strong></td>
            <td class="ay-center" style="font-weight:700;">${enrolled}</td>
            <td class="ay-center" style="color:#059669;font-weight:700;">${passed}</td>
            <td class="ay-center" style="color:#dc2626;font-weight:700;">${failed}</td>
            <td style="text-align:center;"><span class="gr-avg-pill ${avgPillClass(avg)}">${avg > 0 ? avg.toFixed(1) : '—'}</span></td>
            <td class="ay-center">
                <button class="btn-ay btn-ay-outline btn-ay-sm me-1" onclick="event.stopPropagation();openSection(${s.id})" title="View" aria-label="View"><i class="bi bi-eye"></i> View</button>
                ${enrolled > 0 ? `<button class="btn-ay btn-ay-success btn-ay-sm me-1" onclick="event.stopPropagation();quickPrint(${s.id})"><i class="bi bi-printer"></i> Print</button>` : ''}
                <!-- <button class="btn-ay btn-ay-send btn-ay-sm" onclick="event.stopPropagation();openSendGradesModal(${s.id})" title="Send grades to students in this section"><i class="bi bi-send-fill"></i></button> -->
            </td>
        </tr>`;
            }).join('');

            cards.innerHTML = slice.map((s, i) => {
                const avg = Number(s.class_average || 0), enrolled = Number(s.enrolled || 0), passed = Number(s.passed || 0), failed = Number(s.failed || 0);
                const glCode = Number(s.grade_level_code ?? 0);
                const glName = (GRADE_LEVEL_MAP[glCode] || {}).name || s.grade_level_name || 'Unknown';
                return `<div class="ay-mobile-card">
            <div class="ay-mobile-card-header"><span class="ay-mobile-card-title">${esc(s.section_name)}</span><span class="grade-level-text">${glName}</span></div>
            <div class="ay-mobile-card-body">
                <div class="grade-label"><i class="bi bi-person-badge me-1"></i>${esc(s.adviser_name || 'No adviser assigned')}</div>
                <div style="display:flex;gap:.5rem;margin-top:.5rem;">
                    <div style="flex:1;text-align:center;background:var(--ay-card-soft);border-radius:8px;padding:.5rem;"><div style="font-weight:700;color:var(--ay-text-strong);">${enrolled}</div><div style="font-size:.7rem;color:var(--ay-text-muted);">Students</div></div>
                    <div style="flex:1;text-align:center;background:var(--ay-card-soft);border-radius:8px;padding:.5rem;"><div style="font-weight:700;color:#059669;">${passed}</div><div style="font-size:.7rem;color:var(--ay-text-muted);">Passed</div></div>
                    <div style="flex:1;text-align:center;background:var(--ay-card-soft);border-radius:8px;padding:.5rem;"><div style="font-weight:700;color:#dc2626;">${failed}</div><div style="font-size:.7rem;color:var(--ay-text-muted);">Failed</div></div>
                    <div style="flex:1;text-align:center;background:var(--ay-card-soft);border-radius:8px;padding:.5rem;"><div style="font-weight:700;color:var(--ay-text-strong);">${avg > 0 ? avg.toFixed(1) : '—'}</div><div style="font-size:.7rem;color:var(--ay-text-muted);">Avg</div></div>
                </div>
                <div style="display:flex;gap:.4rem;margin-top:.65rem;">
                    <button class="btn-ay btn-ay-outline btn-ay-sm" style="flex:1;" onclick="event.stopPropagation();openSection(${s.id})" title="View" aria-label="View"><i class="bi bi-eye"></i> View</button>
                    ${enrolled > 0 ? `<button class="btn-ay btn-ay-success btn-ay-sm" style="flex:1;" onclick="event.stopPropagation();quickPrint(${s.id})"><i class="bi bi-printer"></i> Print</button>` : ''}
                    <!-- <button class="btn-ay btn-ay-send btn-ay-sm" style="flex:1;" onclick="event.stopPropagation();openSendGradesModal(${s.id})"><i class="bi bi-send-fill"></i> Send</button> -->
                </div>
            </div>
        </div>`;
            }).join('');

            buildPagination('sectionPagination', currentSectionPage, sectionPages, 'goSectionPage');
        }

        function goSectionPage(n) { currentSectionPage = n; loadSections(); }

        /* ══════════════════════════════════════════════════════════════
           GRADES VIEW
        ══════════════════════════════════════════════════════════════ */
        async function openSection(sectionId) {
            const termId = document.getElementById('quarterFilter').value;
            document.getElementById('view-sections').style.display = 'none';
            document.getElementById('view-grades').style.display = '';
            document.getElementById('detailTitle').textContent = 'Loading...';
            document.getElementById('gradesBody').innerHTML = `<tr><td colspan="20"><div class="ay-empty"><i class="bi bi-hourglass-split"></i><p>Loading grades...</p></div></td></tr>`;
            try {
                let url = `api/grades/section_grades.php?section_id=${sectionId}&year_id=${currentYearId}&view_mode=report`;
                if (termId) url += `&term_id=${termId}`;
                const data = await fetchJson(url);
                currentSectionData = data; currentSection = data.section || null; allStudents = data.students || []; filteredStudents = [...allStudents]; currentPage = 1;
                document.getElementById('studentSearch').value = ''; document.getElementById('remarkFilter').value = '';
                renderGradeHeader(data); renderGradesTable(data.subjects || []);
            } catch (e) { toast(e.message, 'danger'); showSections(); }
        }

        function renderGradeHeader(data) {
            const sec = data.section || {}; const glCode = Number(sec.grade_level_code ?? 0);
            const glName = (GRADE_LEVEL_MAP[glCode] || {}).name || `Grade ${glCode}`;
            document.getElementById('detailTitle').innerHTML = `<i class="bi bi-people-fill me-2" style="color:#1a6ef5"></i>${esc(sec.section_name)} — ${glName}`;
            document.getElementById('detailSub').textContent = `Adviser: ${sec.adviser_name || 'None'} · ${esc(data.quarter_label || 'All Quarters')}`;
            document.getElementById('tableCardTitle').textContent = `Student Grades — ${esc(sec.section_name)}`;
            const statusText = data.report_finalized === false
                ? `Grades hidden pending adviser finalization · ${allStudents.length} student${allStudents.length === 1 ? '' : 's'} enrolled`
                : `${allStudents.length} student${allStudents.length === 1 ? '' : 's'} enrolled`;
            document.getElementById('tableCardSub').textContent = statusText;
            document.getElementById('printReportBtn').style.display = allStudents.length ? '' : 'none';
            /* Unified print center: button label reflects the report format for this grade level */
            const labelEl = document.getElementById('printReportCardsLabel');
            if (labelEl) {
                labelEl.textContent =
                    glCode === 0 ? 'Print Kinder Report' :
                    (glCode >= 1 && glCode <= 3) ? 'Print K3 Report' :
                    (glCode >= 4 && glCode <= 10) ? 'Print Form 138' :
                    'Print SHS SF9';
            }
        }

        function renderGradesTable(subjects) {
            window._lastSubjects = subjects;
            const sec = currentSectionData?.section || {};
            const glCode = Number(sec.grade_level_code ?? 0);
            const isSHS = (glCode === 11 || glCode === 12);
            const total = filteredStudents.length;
            document.getElementById('printReportBtn').style.display = total ? '' : 'none';
            const pages = Math.max(1, Math.ceil(total / PER_PAGE));
            if (currentPage > pages) currentPage = 1;
            const slice = filteredStudents.slice((currentPage - 1) * PER_PAGE, currentPage * PER_PAGE);
            const offset = (currentPage - 1) * PER_PAGE;
            let thead = ''; let totalSubjectCols = 0;

            if (isSHS) {
                const s1Subjects = subjects.filter(s => s.semester === '1st' || !s.semester);
                const s2Subjects = subjects.filter(s => s.semester === '2nd');
                totalSubjectCols = s1Subjects.length + s2Subjects.length;
                const s1Ths = s1Subjects.map(s => `<th class="cr-subject-th"><span class="cr-subject-inner">${esc(s.subject_name)}</span></th>`).join('');
                const s2Ths = s2Subjects.map(s => `<th class="cr-subject-th"><span class="cr-subject-inner">${esc(s.subject_name)}</span></th>`).join('');
                const s1Nums = s1Subjects.map((_, i) => `<th class="cr-header-num cr-grade">${i + 1}</th>`).join('');
                const s2Nums = s2Subjects.map((_, i) => `<th class="cr-header-num cr-grade">${s1Subjects.length + i + 1}</th>`).join('');
                thead = `<tr><th class="cr-num-th" rowspan="2" style="vertical-align:bottom;">#</th><th class="cr-name-th" rowspan="2" style="vertical-align:bottom;">LEARNERS' NAMES</th><th class="cr-name-th" rowspan="2" style="vertical-align:bottom;">SEX</th><th class="cr-subject-th" colspan="${s1Subjects.length}" style="background:var(--ay-head-bg);font-size:8pt;">1st Semester</th>${s2Subjects.length ? `<th class="cr-subject-th" colspan="${s2Subjects.length}" style="background:var(--ay-head-bg);font-size:8pt;">2nd Semester</th>` : ''}<th class="cr-avg-th" rowspan="2" style="vertical-align:bottom;">AVERAGE</th></tr><tr>${s1Nums}${s2Nums}</tr>`;
                window._s1Subjects = s1Subjects; window._s2Subjects = s2Subjects;
            } else {
                totalSubjectCols = subjects.length;
                const subjectThs = subjects.map(s => `<th class="cr-subject-th"><span class="cr-subject-inner">${esc(s.subject_name)}</span></th>`).join('');
                const colNums = subjects.map((_, i) => `<th class="cr-header-num cr-grade">${i + 1}</th>`).join('');
                thead = `<tr><th class="cr-num-th" rowspan="2" style="vertical-align:bottom;">#</th><th class="cr-name-th" rowspan="2" style="vertical-align:bottom;">LEARNERS' NAMES</th><th class="cr-name-th" rowspan="2" style="vertical-align:bottom;">SEX</th>${subjectThs}<th class="cr-avg-th" rowspan="2" style="vertical-align:bottom;">AVERAGE</th></tr><tr>${colNums}</tr>`;
            }

            const isMale = st => ['male', 'm'].includes((st.sex || '').toLowerCase());
            const isFemale = st => ['female', 'f'].includes((st.sex || '').toLowerCase());
            const maleList = slice.filter(isMale); const femaleList = slice.filter(isFemale); const otherList = slice.filter(st => !isMale(st) && !isFemale(st));
            const hasSexGroups = maleList.length > 0 || femaleList.length > 0;

            const dataRow = (st, rowNum) => {
                let gradeCells = '';
                if (isSHS) {
                    gradeCells += window._s1Subjects.map(s => { const g = Number(st.grades?.[s.id] ?? 0); const cls = g >= 75 ? 'cr-pass' : g > 0 ? 'cr-fail' : ''; const desc = g > 0 ? getDescriptorJS(g, glCode) : ''; return `<td class="cr-grade ${cls}">${g > 0 ? g : (currentSectionData?.report_finalized === false ? '<span style="font-size:7pt;color:var(--ay-text-muted);font-weight:700;">Pending</span>' : '')}${desc ? `<span style="display:block;font-size:7pt;color:#888;font-weight:400;">${esc(desc)}</span>` : ''}</td>`; }).join('');
                    gradeCells += window._s2Subjects.map(s => { const g = Number(st.grades?.[s.id] ?? 0); const cls = g >= 75 ? 'cr-pass' : g > 0 ? 'cr-fail' : ''; const desc = g > 0 ? getDescriptorJS(g, glCode) : ''; return `<td class="cr-grade ${cls}">${g > 0 ? g : (currentSectionData?.report_finalized === false ? '<span style="font-size:7pt;color:var(--ay-text-muted);font-weight:700;">Pending</span>' : '')}${desc ? `<span style="display:block;font-size:7pt;color:#888;font-weight:400;">${esc(desc)}</span>` : ''}</td>`; }).join('');
                } else {
                    gradeCells = subjects.map(s => { const g = Number(st.grades?.[s.id] ?? 0); const cls = g >= 75 ? 'cr-pass' : g > 0 ? 'cr-fail' : ''; const desc = g > 0 ? getDescriptorJS(g, glCode) : ''; return `<td class="cr-grade ${cls}">${g > 0 ? g : (currentSectionData?.report_finalized === false ? '<span style="font-size:7pt;color:var(--ay-text-muted);font-weight:700;">Pending</span>' : '')}${desc ? `<span style="display:block;font-size:7pt;color:#888;font-weight:400;">${esc(desc)}</span>` : ''}</td>`; }).join('');
                }
                const avg = Number(st.general_average || 0); const avgCls = avg >= 75 ? 'cr-pass' : avg > 0 ? 'cr-fail' : '';
                const locked = currentSectionData?.report_finalized === false;
                const avgText = locked ? '<span style="font-size:7pt;color:var(--ay-text-muted);font-weight:700;">Pending Submission</span>' : (avg > 0 ? avg.toFixed(2) : '');
                return `<tr><td class="cr-num">${rowNum}</td><td class="cr-name">${esc(st.full_name)}</td><td class="cr-name cr-sex">${esc(st.sex ?? '')}</td>${gradeCells}<td class="cr-avg cr-avg-cell ${avgCls}">${avgText}</td></tr>`;
            };

            const blankRows = (count, startNum) => Array.from({ length: count }, (_, i) => {
                let bc = '';
                if (isSHS) { bc = Array(window._s1Subjects.length + window._s2Subjects.length).fill('<td class="cr-grade"></td>').join(''); }
                else { bc = subjects.map(() => '<td class="cr-grade"></td>').join(''); }
                return `<tr class="cr-empty-row"><td class="cr-num" style="color:var(--ay-text-dim);">${startNum + i}</td><td class="cr-name">&nbsp;</td><td class="cr-name">&nbsp;</td>${bc}<td class="cr-avg cr-avg-cell"></td></tr>`;
            }).join('');

            const groupRow = label => `<tr class="cr-row-group"><td class="cr-num"></td><td colspan="${totalSubjectCols + 3}">${label}</td></tr>`;
            const MIN_PER_GROUP = 13;
            let tbody = ''; let rowNum = offset + 1;

            if (!total) {
                tbody = `<tr><td colspan="${totalSubjectCols + 4}"><div class="ay-empty"><i class="bi bi-person-x"></i><p>No students match your search.</p></div></td></tr>`;
            } else if (hasSexGroups) {
                tbody += groupRow('MALE');
                maleList.forEach(st => { tbody += dataRow(st, rowNum++); });
                const mf = Math.max(0, MIN_PER_GROUP - maleList.length); tbody += blankRows(mf, rowNum); rowNum += mf;
                tbody += groupRow('FEMALE');
                femaleList.forEach(st => { tbody += dataRow(st, rowNum++); });
                const ff = Math.max(0, MIN_PER_GROUP - femaleList.length); tbody += blankRows(ff, rowNum); rowNum += ff;
                otherList.forEach(st => { tbody += dataRow(st, rowNum++); });
            } else {
                otherList.forEach(st => { tbody += dataRow(st, rowNum++); });
                tbody += blankRows(Math.max(0, 25 - otherList.length), rowNum);
            }

            document.getElementById('gradesHead').innerHTML = thead;
            document.getElementById('gradesBody').innerHTML = tbody;

            document.getElementById('gradesCardView').innerHTML = !slice.length
                ? `<div class="ay-empty"><i class="bi bi-person-x"></i><p>No students found.</p></div>`
                : slice.map((st, i) => {
                    const avg = Number(st.general_average || 0);
                    let gradesGrid = '';
                    if (isSHS) {
                        gradesGrid = window._s1Subjects.map(s => { const g = Number(st.grades?.[s.id] ?? 0); return `<div style="background:var(--ay-card-soft);border-radius:6px;padding:.3rem .5rem;font-size:.78rem;"><div style="color:var(--ay-text-muted);font-size:.7rem;">${esc(s.subject_name)} <span style="color:#1a6ef5;font-size:.65rem;">(S1)</span></div><div style="font-weight:700;" class="${g >= 75 ? 'cr-pass' : g > 0 ? 'cr-fail' : ''}">${g > 0 ? g : '—'}</div></div>`; }).join('');
                        gradesGrid += window._s2Subjects.map(s => { const g = Number(st.grades?.[s.id] ?? 0); return `<div style="background:var(--ay-card-soft);border-radius:6px;padding:.3rem .5rem;font-size:.78rem;"><div style="color:var(--ay-text-muted);font-size:.7rem;">${esc(s.subject_name)} <span style="color:#9333ea;font-size:.65rem;">(S2)</span></div><div style="font-weight:700;" class="${g >= 75 ? 'cr-pass' : g > 0 ? 'cr-fail' : ''}">${g > 0 ? g : '—'}</div></div>`; }).join('');
                    } else {
                        gradesGrid = subjects.map(s => { const g = Number(st.grades?.[s.id] ?? 0); return `<div style="background:var(--ay-card-soft);border-radius:6px;padding:.3rem .5rem;font-size:.78rem;"><div style="color:var(--ay-text-muted);font-size:.7rem;">${esc(s.subject_name)}</div><div style="font-weight:700;" class="${g >= 75 ? 'cr-pass' : g > 0 ? 'cr-fail' : ''}">${g > 0 ? g : '—'}</div></div>`; }).join('');
                    }
                    return `<div class="ay-mobile-card"><div class="ay-mobile-card-header"><span class="ay-mobile-card-title">${offset + i + 1}. ${esc(st.full_name)}</span><span class="ay-badge ${remarkBadgeClass(st.remark)}">${esc(st.remark || '—')}</span></div><div class="ay-mobile-card-body"><div class="grade-label">${esc(st.lrn || '')}</div><div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(80px,1fr));gap:.35rem;margin-top:.5rem;">${gradesGrid}</div><div style="margin-top:.65rem;font-size:.82rem;color:var(--ay-text);">General Average: <strong class="${avg >= 75 ? 'cr-pass' : avg > 0 ? 'cr-fail' : ''}">${avg > 0 ? avg.toFixed(2) : '—'}</strong></div></div></div>`;
                }).join('');

            document.getElementById('gradeCountText').textContent = total > 0 ? `Showing ${offset + 1}–${Math.min(offset + slice.length, total)} of ${total} student${total === 1 ? '' : 's'}` : 'No students to display.';
            buildPagination('gradePagination', currentPage, pages, 'goPage');
        }

        const DESCRIPTORS = <?= json_encode(getDescriptorsByType($pdo, 'NUMERICAL')) ?>;

        function getDescriptorJS(grade, gradeCode) {
            if (gradeCode >= 4) {
                for (const row of DESCRIPTORS) {
                    if (grade >= Number(row.grade_from) && grade <= Number(row.grade_to)) {
                        return row.descriptor;
                    }
                }
            }
            return '';
        }

        function goPage(n) { currentPage = n; renderGradesTable(window._lastSubjects || []); }
        function applyFilters() {
            const q = document.getElementById('studentSearch').value.toLowerCase(); const rem = document.getElementById('remarkFilter').value;
            filteredStudents = allStudents.filter(st => { const mq = !q || st.full_name.toLowerCase().includes(q) || (st.lrn || '').toLowerCase().includes(q); const mr = !rem || st.remark === rem; return mq && mr; });
            currentPage = 1; renderGradesTable(window._lastSubjects || []);
        }

        function showSections() {
            document.getElementById('view-grades').style.display = 'none';
            document.getElementById('view-sections').style.display = '';
        }

        function exportSection() {
            if (!currentSection || !window._lastSubjects) {
                toast('No section or grade data is available for export.', 'warning');
                return;
            }

            try {
                const subjects = window._lastSubjects;
                let csv = 'No.,Student Name,LRN,Sex,';
                csv += subjects.map(s => s.subject_name).join(',') + ',General Average,Remarks\n';

                allStudents.forEach((st, i) => {
                    const grades = subjects.map(s => Number(st.grades?.[s.id] ?? 0) || '').join(',');
                    const sex = st.sex || st.gender || '';
                    csv += `${i + 1},"${st.full_name}","${st.lrn || ''}","${sex}",${grades},${Number(st.general_average || 0).toFixed(2)},${st.remark || ''}\n`;
                });

                const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                const filename = `grades_${currentSection.section_name}_${currentSection.year_label}.csv`.replace(/\s/g, '_');

                a.href = url;
                a.download = filename;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);

                setTimeout(() => URL.revokeObjectURL(url), 1000);
            } catch (e) {
                console.error(e);
                toast('Unable to export the CSV file.', 'danger');
            }
        }

        /* downloadGradesCSV() removed — use exportSection() instead */

        /* ══════════════════════════════════════════════════════════════
           SEND GRADES MODAL
        ══════════════════════════════════════════════════════════════ */
        let sgSelectedSections = new Set();
        let sgAllModalSections = [];
        let sgFilteredSections = [];
        let sgSelectedQuarters = new Set(['all']);
        let sgAvailableQuarters = [];

        async function openSendGradesModal(preselectSectionId) {
            document.getElementById('sgStep1').classList.remove('d-none');
            document.getElementById('sgStep2').classList.add('d-none');
            document.getElementById('sgStep3').classList.add('d-none');
            document.getElementById('sgSendBtn').classList.remove('d-none');
            document.getElementById('sgDoneBtn').classList.add('d-none');
            document.getElementById('sgCancelBtn').textContent = 'Cancel';
            document.getElementById('sgCancelBtn').disabled = false;
            document.getElementById('sgSendBtn').disabled = true;
            document.getElementById('sgSectionSearch').value = '';
            document.getElementById('sgGradeFilter').value = '';
            sgSelectedSections.clear();
            sgSelectedQuarters = new Set(['all']);

            new bootstrap.Modal(document.getElementById('sendGradesModal')).show();

            await loadSgQuarterPills();
            await loadSgSections(preselectSectionId ? parseInt(preselectSectionId) : null);
        }

        async function loadSgQuarterPills() {
            const pillsEl = document.getElementById('sgQuarterPills');
            pillsEl.innerHTML = `<span class="sg-q-pill active" data-q="all">All Quarters</span>`;
            try {
                const data = await fetchJson(`api/quarters/read.php?view_year_id=${currentYearId}`);
                sgAvailableQuarters = data.quarters || [];
                sgAvailableQuarters.forEach(q => {
                    const pill = document.createElement('span');
                    pill.className = 'sg-q-pill';
                    pill.dataset.q = q.id;
                    pill.textContent = q.quarter_label + ' Quarter';
                    if (q.is_active == 1) {
                        pill.classList.add('active');
                        sgSelectedQuarters.delete('all');
                        sgSelectedQuarters.add(String(q.id));
                        document.querySelector('[data-q="all"]').classList.remove('active');
                    }
                    pill.addEventListener('click', () => toggleSgQuarterPill(pill));
                    pillsEl.appendChild(pill);
                });
            } catch (e) { }

            document.querySelector('[data-q="all"]').addEventListener('click', function () {
                toggleSgQuarterPill(this);
            });
        }

        function toggleSgQuarterPill(pill) {
            const val = pill.dataset.q;
            if (val === 'all') {
                sgSelectedQuarters = new Set(['all']);
                document.querySelectorAll('.sg-q-pill').forEach(p => p.classList.remove('active'));
                pill.classList.add('active');
            } else {
                sgSelectedQuarters.delete('all');
                document.querySelector('[data-q="all"]').classList.remove('active');
                if (pill.classList.contains('active')) {
                    pill.classList.remove('active');
                    sgSelectedQuarters.delete(val);
                    if (sgSelectedQuarters.size === 0) {
                        sgSelectedQuarters.add('all');
                        document.querySelector('[data-q="all"]').classList.add('active');
                    }
                } else {
                    pill.classList.add('active');
                    sgSelectedQuarters.add(val);
                }
            }
        }

        async function loadSgSections(preselectId) {
            const grid = document.getElementById('sgSectionGrid');
            grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:2rem;color:var(--ay-text-dim);"><span class="spinner-border spinner-border-sm me-1"></span> Loading sections…</div>`;

            try {
                let sections = allSectionsCache;
                if (!sections.length) {
                    const data = await fetchJson(`api/grades/sections.php?year_id=${currentYearId}`);
                    sections = data.sections || [];
                    allSectionsCache = sections;
                }

                sgAllModalSections = sections.map(s => ({
                    id: s.id,
                    name: s.section_name,
                    glName: (GRADE_LEVEL_MAP[Number(s.grade_level_code ?? 0)] || {}).name || s.grade_level_name || '?',
                    gradeId: s.grade_level_id,
                    enrolled: Number(s.enrolled || 0),
                    adviser: s.adviser_name || '',
                }));

                sgFilteredSections = [...sgAllModalSections];

                if (preselectId) {
                    sgSelectedSections.add(preselectId);
                }

                renderSgGrid();
            } catch (e) {
                grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:2rem;color:#c0392b;"><i class="bi bi-exclamation-triangle me-1"></i>Failed to load sections.</div>`;
            }
        }

        function filterSgSections() {
            const q = document.getElementById('sgSectionSearch').value.toLowerCase();
            const gid = document.getElementById('sgGradeFilter').value;
            sgFilteredSections = sgAllModalSections.filter(s => {
                const mq = !q || s.name.toLowerCase().includes(q) || s.glName.toLowerCase().includes(q);
                const mg = !gid || String(s.gradeId) === gid;
                return mq && mg;
            });
            renderSgGrid();
        }

        function renderSgGrid() {
            const grid = document.getElementById('sgSectionGrid');
            if (!sgFilteredSections.length) {
                grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:2rem;color:var(--ay-text-dim);"><i class="bi bi-search me-1"></i>No sections match your filter.</div>`;
                updateSgCount(); return;
            }

            grid.innerHTML = sgFilteredSections.map(s => {
                const sel = sgSelectedSections.has(s.id);
                return `<div class="sg-section-item ${sel ? 'selected' : ''}" data-id="${s.id}" onclick="toggleSgSection(${s.id}, this)">
            <div class="sg-check">${sel ? '<i class="bi bi-check-lg"></i>' : ''}</div>
            <div>
                <div class="sg-section-name">${esc(s.name)}</div>
                <div class="sg-section-meta">${esc(s.glName)} &nbsp;·&nbsp; ${s.enrolled} student${s.enrolled === 1 ? '' : 's'}</div>
                ${s.adviser ? `<div class="sg-section-meta"><i class="bi bi-person-fill"></i> ${esc(s.adviser)}</div>` : ''}
            </div>
        </div>`;
            }).join('');

            const allVisible = sgFilteredSections.every(s => sgSelectedSections.has(s.id));
            document.getElementById('sgSelectAll').checked = sgFilteredSections.length > 0 && allVisible;
            updateSgCount();
        }

        function toggleSgSection(id, el) {
            if (sgSelectedSections.has(id)) {
                sgSelectedSections.delete(id);
                el.classList.remove('selected');
                el.querySelector('.sg-check').innerHTML = '';
            } else {
                sgSelectedSections.add(id);
                el.classList.add('selected');
                el.querySelector('.sg-check').innerHTML = '<i class="bi bi-check-lg"></i>';
            }
            const allVisible = sgFilteredSections.every(s => sgSelectedSections.has(s.id));
            document.getElementById('sgSelectAll').checked = sgFilteredSections.length > 0 && allVisible;
            updateSgCount();
        }

        function toggleSelectAll(checked) {
            sgFilteredSections.forEach(s => {
                if (checked) sgSelectedSections.add(s.id);
                else sgSelectedSections.delete(s.id);
            });
            renderSgGrid();
        }

        function updateSgCount() {
            const n = sgSelectedSections.size;
            document.getElementById('sgCountChip').innerHTML = `<i class="bi bi-check2-square"></i> ${n} selected`;
            document.getElementById('sgSendBtn').disabled = n === 0;
        }

        async function doSendGrades() {
            if (!sgSelectedSections.size) { toast('Please select at least one section.', 'warning'); return; }

            const quarterIds = sgSelectedQuarters.has('all')
                ? sgAvailableQuarters.map(q => q.id)
                : [...sgSelectedQuarters].map(Number);

            document.getElementById('sgStep1').classList.add('d-none');
            document.getElementById('sgStep2').classList.remove('d-none');
            document.getElementById('sgSendBtn').classList.add('d-none');
            document.getElementById('sgCancelBtn').disabled = true;

            const sectionIds = [...sgSelectedSections];
            let totalSent = 0, totalStudents = 0, totalSections = 0;

            for (let i = 0; i < sectionIds.length; i++) {
                const sid = sectionIds[i];
                const secName = sgAllModalSections.find(s => s.id === sid)?.name || `Section ${sid}`;
                document.getElementById('sgProgressSub').textContent =
                    `Sending section ${i + 1} of ${sectionIds.length}: ${secName}…`;

                try {
                    const res = await fetchJson('api/grades/send_grades.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            section_id: sid,
                            year_id: currentYearId,
                            quarter_ids: quarterIds.length ? quarterIds : null,
                        }),
                    });
                    if (res.success) {
                        totalSent += Number(res.notifications_sent || 0);
                        totalStudents += Number(res.students_processed || 0);
                        totalSections++;
                    }
                } catch (e) {
                    console.error(`Section ${sid}:`, e.message);
                }
            }

            document.getElementById('sgStep2').classList.add('d-none');
            document.getElementById('sgStep3').classList.remove('d-none');
            document.getElementById('sgSendBtn').classList.add('d-none');
            document.getElementById('sgDoneBtn').classList.remove('d-none');
            document.getElementById('sgCancelBtn').textContent = 'Close';
            document.getElementById('sgCancelBtn').disabled = false;

            document.getElementById('sgResultList').innerHTML = `
        <li><strong>${totalSections}</strong> section${totalSections !== 1 ? 's' : ''} processed</li>
        <li><strong>${totalStudents}</strong> student${totalStudents !== 1 ? 's' : ''} found</li>
        <li><strong>${totalSent}</strong> grade notification${totalSent !== 1 ? 's' : ''} sent successfully</li>
    `;
            toast(`${totalSent} grade notification${totalSent !== 1 ? 's' : ''} sent!`, totalSent > 0 ? 'success' : 'warning');
        }

        function sgFinish() {
            bootstrap.Modal.getInstance(document.getElementById('sendGradesModal')).hide();
        }

        /* ══════════════════════════════════════════════════════════════
           PRINT
        ══════════════════════════════════════════════════════════════ */
        async function quickPrint(sectionId) {
            const termId = document.getElementById('quarterFilter').value;
            toast('Loading data for printing...', 'info');
            try {
                let url = `api/grades/section_grades.php?section_id=${sectionId}&year_id=${currentYearId}&view_mode=report`;
                if (termId) url += `&term_id=${termId}`;
                const data = await fetchJson(url); buildAndPrint(data);
            } catch (e) { toast(e.message, 'danger'); }
        }
        function printReportCards() {
            if (!currentSectionData) { toast('No section loaded.', 'warning'); return; }
            /* Unified print center: route by grade level */
            const sec = currentSectionData.section || {};
            const glCode = Number(sec.grade_level_code ?? -1);
            const sectionId = sec.id || currentSection?.id || '';
            const termId = document.getElementById('quarterFilter')?.value || '';
            if (!sectionId) { toast('Please select a section first.', 'warning'); return; }
            /* Kindergarten + Grades 1-3 (Descriptive) -> unified K-3 Progress Report */
            if (glCode >= 0 && glCode <= 3) {
                window.open(
                    `pages/K3-Report.php?section_id=${encodeURIComponent(sectionId)}&term_id=${encodeURIComponent(termId)}`,
                    '_blank'
                );
                return;
            }
            /* Grades 4-12 → existing SF9 browser print */
            buildAndPrint(currentSectionData);
        }

        /* printApprovalDoc() removed — will be re-implemented in chain view */

        function buildAndPrint(data) {
            const sec = data.section || {}; const glCode = Number(sec.grade_level_code ?? 0); const isSHS = (glCode === 11 || glCode === 12);
            const subjects = data.subjects || []; const students = data.students || [];
            if (!students.length) {
                toast('No student data available to print.', 'warning');
                return;
            }
            const yearLabel = escText(sec.year_label || data.year_label || ''); const sectionName = escText(sec.section_name || '');
            const adviserName = escText(sec.adviser_name || ''); const principal = escText(sec.principal || '');
            const glName = (GRADE_LEVEL_MAP[glCode] || {}).name || `Grade ${glCode}`; const quarterLabel = escText(data.quarter_label || '');
            let html = '';
            students.forEach(st => {
                html += isSHS
                    ? buildSHSCard(st, subjects, sec, data, yearLabel, sectionName, adviserName, principal, glName, glCode, quarterLabel)
                    : buildSF9Card(st, subjects, sec, data, yearLabel, sectionName, adviserName, principal, glName, glCode, quarterLabel);
            });
            document.getElementById('printArea').innerHTML = html;
            requestAnimationFrame(() => requestAnimationFrame(() => window.print()));
        }

        function attNumber(value) { const n = Number(value || 0); if (!Number.isFinite(n) || n <= 0) return ''; return Number.isInteger(n) ? String(n) : n.toFixed(1).replace(/\.0$/, ''); }
        function attendanceRows(st, monthNumbers) {
            const attendance = st.attendance || {};
            const cells = (field) => monthNumbers.map(m => `<td>${attNumber(attendance[m]?.[field])}</td>`).join('');
            const total = (field) => monthNumbers.reduce((sum, m) => sum + Number(attendance[m]?.[field] || 0), 0);
            return `<tr><td class="lft">No. of School days</td>${cells('school_days')}<td>${attNumber(total('school_days'))}</td></tr>
        <tr><td class="lft">No. of days Present</td>${cells('days_present')}<td>${attNumber(total('days_present'))}</td></tr>
        <tr><td class="lft">No. of days Absent</td>${cells('days_absent')}<td>${attNumber(total('days_absent'))}</td></tr>`;
        }

        /* ── ATTENDANCE (Form 138 table) ───────────────────────────────
           Month | School Days | Days Present | Days Absent
           Rows come from tblattendance_records via section_grades.php
           (st.attendance keyed by month_number), ordered in school-year
           sequence (Jun → Mar) with a Total row. */
        const SCHOOL_MONTH_ORDER = [6, 7, 8, 9, 10, 11, 12, 1, 2, 3, 4, 5];
        const SCHOOL_MONTH_NAMES = {
            1: 'January', 2: 'February', 3: 'March', 4: 'April', 5: 'May', 6: 'June',
            7: 'July', 8: 'August', 9: 'September', 10: 'October', 11: 'November', 12: 'December'
        };
        function attendanceMonthRows(st) {
            const attendance = st.attendance || {};
            const recorded = Object.keys(attendance).map(Number).filter(m => attendance[m]);
            recorded.sort((a, b) => SCHOOL_MONTH_ORDER.indexOf(a) - SCHOOL_MONTH_ORDER.indexOf(b));
            const months = recorded.length ? recorded : [6, 7, 8, 9, 10, 11, 12, 1, 2, 3];
            const total = (field) => months.reduce((sum, m) => sum + Number(attendance[m]?.[field] || 0), 0);
            const rows = months.map(m => {
                const name = escText(attendance[m]?.month_name || SCHOOL_MONTH_NAMES[m] || ('Month ' + m));
                return `<tr><td class="lft">${name}</td><td>${attNumber(attendance[m]?.school_days)}</td><td>${attNumber(attendance[m]?.days_present)}</td><td>${attNumber(attendance[m]?.days_absent)}</td></tr>`;
            }).join('');
            return rows + `<tr style="font-weight:bold;background:#f0f0f0;"><td class="lft">Total</td><td>${attNumber(total('school_days'))}</td><td>${attNumber(total('days_present'))}</td><td>${attNumber(total('days_absent'))}</td></tr>`;
        }
        function deportmentMark(st, statementIndex, quarter) {
            const value = st.deportment?.[statementIndex]?.[quarter] || st.deportment?.[String(statementIndex)]?.[String(quarter)] || '';
            return ['AO', 'SO', 'RO', 'NO'].includes(String(value).toUpperCase()) ? String(value).toUpperCase() : '';
        }

        function buildSF9Card(st, subjects, sec, data, yearLabel, sectionName, adviserName, principal, glName, glCode, quarterLabel) {
            /* Legend rows are rendered inline via SF9_LEGEND_ROWS — no post-processing needed. */
            return buildSF9CardInner(st, subjects, sec, data, yearLabel, sectionName, adviserName, principal, glName, glCode, quarterLabel);
        }

        function buildSF9CardInner(st, subjects, sec, data, yearLabel, sectionName, adviserName, principal, glName, glCode, quarterLabel) {
            const fullName = escText(st.full_name || ''); const lrn = escText(st.lrn || ''); const avg = Number(st.general_average || 0); const remark = escText(st.remark || ''); const age = escText(st.age || ''); const sex = escText(st.sex || ''); const address = escText(sec.school_address || ''); const gradeCode = glName.replace('Grade ', '').toUpperCase();
            /* Per-term values + Final Grade (= average of the 3 terms) */
            const termNos = TERM_NUMBERS;
            const subjectTermVals = (s) => termNos.map(n => Number(st.quarter_grades?.[s.id]?.[String(n)] || 0));
            const subjectFinal = (s) => { const vals = subjectTermVals(s).filter(v => v > 0); return vals.length ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length) : Number(st.grades?.[s.id] || 0); };
            const gradeRows = subjects.map(s => { const tv = subjectTermVals(s); const fg = subjectFinal(s); const fc = fg > 0 && fg < 75 ? 'fg' : 'pg'; return `<tr><td class="sc">${escText(s.subject_name)}</td><td class="nc">${tv[0] > 0 ? tv[0] : ''}</td><td class="nc">${tv[1] > 0 ? tv[1] : ''}</td><td class="nc">${tv[2] > 0 ? tv[2] : ''}</td><td class="fc ${fc}" style="text-align:center;">${fg > 0 ? fg : ''}</td><td class="nc">${fg >= 75 ? 'Passed' : fg > 0 ? 'Failed' : ''}</td></tr>`; }).join('');
            const avgCls = avg > 0 && avg < 75 ? 'fg' : 'pg';
            // DO 15, s. 2026 3-term format:
            //   General Average row   = average of all learning areas for EACH term
            //   Final Grade (per row) = average of the 3 term averages per learning area
            const termColumnAvg = (idx) => { const vals = subjects.map(s => subjectTermVals(s)[idx]).filter(v => v > 0); return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0; };
            const termAvgs = [0, 1, 2].map(i => termColumnAvg(i));
            const finals = subjects.map(s => subjectFinal(s)).filter(v => v > 0);
            const genAvg = finals.length ? (finals.reduce((a, b) => a + b, 0) / finals.length) : avg;
            const genRemark = genAvg >= 75 ? 'Passed' : genAvg > 0 ? 'Failed' : '';
            const coreValues = [{ g: '1. Maka-Diyos', b: ["Expresses one's spiritual belief while respecting the spiritual beliefs of others.", "Shows adherence to ethical principles by upholding truth."] }, { g: '2. Makatao', b: ['Is sensitive to individual, social, and cultural differences.', 'Demonstrates contributions toward solidarity.'] }, { g: '3. Maka-kalikasan', b: ['Cares for the environment and utilizes resources wisely, judiciously and economically.'] }, { g: '4. Maka-bansa', b: ['Demonstrates pride in being a Filipino; exercises the rights and responsibilities of a Filipino.', 'Demonstrates appropriate behavior in carrying out activities in the school, community and country.'] }];
            let statementIndex = 0;
            const valRows = coreValues.map(cv => cv.b.map((b, bi) => { const si = statementIndex++; return `<tr>${bi === 0 ? `<td rowspan="${cv.b.length}" style="vertical-align:middle;font-size:8pt;font-weight:bold;padding:2px 4px;">${escText(cv.g)}</td>` : ''}<td style="font-size:8pt;padding:2px 4px;">${escText(b)}</td><td class="qc">${deportmentMark(st, si, TERM_NUMBERS[0])}</td><td class="qc">${deportmentMark(st, si, TERM_NUMBERS[1])}</td><td class="qc">${deportmentMark(st, si, TERM_NUMBERS[2])}</td></tr>`; }).join('')).join('');
            return `<div class="rc-page"><div class="rc-page-label">DEPED SF9 · ${glName}</div><div class="sf9-wrap"><div class="sf9-top"><div class="sf9-left"><div style="display:flex;align-items:center;gap:6px;margin-bottom:4px;"><img src="assets/img/deped.png" style="width:38px;height:38px;object-fit:contain;flex-shrink:0;" alt="DepEd"><div style="text-align:center;flex:1;line-height:1.25;"><div style="font-size:6.5pt;">Republic of the Philippines</div><div style="font-size:7pt;font-weight:bold;">Department of Education</div><div style="font-size:6.5pt;">National Capital Region</div><div style="font-size:6.5pt;">Division of Quezon City</div><div style="font-size:8.5pt;font-weight:bold;text-transform:uppercase;">St. Theresa's School of Novaliches, Inc.</div><div style="font-size:6.5pt;">${address}</div></div><img src="assets/img/stsn logo.png" style="width:38px;height:38px;object-fit:contain;flex-shrink:0;" alt="STSN"></div><table style="width:100%;border-collapse:collapse;margin-top:2px;font-size:7.5pt;"><tr><td style="width:64px;color:#333;font-size:7pt;white-space:nowrap;">Name:</td><td colspan="3" style="font-weight:bold;font-size:9.5pt;font-family:'Arial Black',Arial,sans-serif;border-bottom:1.5px solid #000;padding-left:4px;">${fullName}</td></tr><tr><td style="font-size:7pt;color:#333;padding-top:2px;">Age:</td><td style="font-weight:bold;border-bottom:1px solid #000;padding-left:4px;width:40px;font-size:8pt;">${age}</td><td style="font-size:7pt;color:#333;padding-left:8px;">Sex:</td><td style="font-weight:bold;border-bottom:1px solid #000;padding-left:4px;font-size:8pt;text-transform:uppercase;">${sex}</td></tr><tr><td style="font-size:7pt;color:#333;padding-top:2px;">Grade:</td><td style="font-weight:bold;border-bottom:1px solid #000;padding-left:4px;font-size:8pt;">${gradeCode}</td><td style="font-size:7pt;color:#333;padding-left:8px;">Section:</td><td style="font-weight:bold;border-bottom:1px solid #000;padding-left:4px;font-size:8pt;">${sectionName}</td></tr><tr><td style="font-size:7pt;color:#333;padding-top:2px;white-space:nowrap;">School Year:</td><td colspan="3" style="font-weight:bold;border-bottom:1px solid #000;padding-left:4px;font-size:8pt;">${yearLabel}</td></tr><tr><td style="font-size:7pt;color:#333;padding-top:2px;">LRN:</td><td colspan="3" style="font-weight:bold;border-bottom:1px solid #000;padding-left:4px;font-size:8pt;">${lrn}</td></tr></table><div style="font-size:6.5pt;margin-top:2px;line-height:1.3;color:#333;font-style:italic;">Dear Parent:<br>&nbsp;&nbsp;This report card shows the ability and progress your child has made in the different learning areas as well as his/her core values.<br>&nbsp;&nbsp;The school welcomes you, should you desire to know more about your child's progress.</div><div class="sf9-sec">REPORT ON LEARNING PROGRESS AND ACHIEVEMENT</div><div style="text-align:center;font-size:6.5pt;font-weight:bold;margin:0 0 2px;">${TERM_HEADER_CAPTION}</div><table class="sf9-gt"><thead><tr><th class="sc" rowspan="2">Learning Areas</th><th colspan="3">Term</th><th rowspan="2">Final<br>Grade</th><th rowspan="2">Remarks</th></tr><tr><th>${termShort(TERM_NUMBERS[0])}</th><th>${termShort(TERM_NUMBERS[1])}</th><th>${termShort(TERM_NUMBERS[2])}</th></tr></thead><tbody>${gradeRows}<tr style="background:#e8e8e8;"><td style="text-align:center;font-weight:bold;font-size:7pt;">General Average</td><td class="nc" style="font-weight:bold;">${termAvgs[0] > 0 ? termAvgs[0].toFixed(0) : ''}</td><td class="nc" style="font-weight:bold;">${termAvgs[1] > 0 ? termAvgs[1].toFixed(0) : ''}</td><td class="nc" style="font-weight:bold;">${termAvgs[2] > 0 ? termAvgs[2].toFixed(0) : ''}</td><td class="fc ${avgCls}" style="font-weight:bold;text-align:center;">${genAvg > 0 ? genAvg.toFixed(0) : ''}</td><td class="nc" style="font-size:8pt;">${genRemark}</td></tr></tbody></table><div class="sf9-sec">REPORT ON ATTENDANCE</div><table class="sf9-at"><thead><tr><th style="text-align:left;padding-left:4px;min-width:110px;">Month</th><th>School Days</th><th>Days Present</th><th>Days Absent</th></tr></thead><tbody>${attendanceMonthRows(st)}</tbody></table><div style="border-top:1px solid #000;padding-top:6px;margin-top:8px;"><div style="font-size:9pt;font-weight:bold;text-align:center;margin-bottom:4px;">PERFORMANCE DESCRIPTORS</div><table class="sf9-gt" style="font-size:8pt;"><thead><tr><th class="sc">Descriptors</th><th>Grading Scale</th><th>Remarks</th></tr></thead><tbody>${SF9_LEGEND_ROWS}</tbody></table></div><div style="margin-top:3px;font-size:7pt;"><div style="display:flex;align-items:flex-end;gap:4px;margin-bottom:3px;"><span style="white-space:nowrap;">Classified as :</span><span style="flex:1;border-bottom:1px solid #000;">&nbsp;</span></div><div style="display:flex;align-items:flex-end;gap:4px;margin-bottom:3px;"><span style="white-space:nowrap;">Has advanced learning areas:</span><span style="flex:1;border-bottom:1px solid #000;">&nbsp;</span></div><div style="display:flex;align-items:flex-end;gap:4px;margin-bottom:3px;"><span style="white-space:nowrap;">Lack learning areas :</span><span style="flex:1;border-bottom:1px solid #000;">&nbsp;</span></div><div style="display:flex;align-items:flex-end;gap:4px;"><span>Date :</span><span style="flex:1;border-bottom:1px solid #000;">&nbsp;</span></div></div><div style="flex:1;min-height:6px;"></div><div style="display:flex;justify-content:space-between;gap:10px;margin-top:6px;"><div style="flex:1;text-align:center;"><div style="border-top:1.5px solid #000;padding-top:2px;font-size:8pt;font-weight:bold;text-decoration:underline;">${adviserName}</div><div style="font-size:7.5pt;">Teacher's Signature / Adviser</div></div><div style="flex:1;text-align:center;"><div style="border-top:1.5px solid #000;padding-top:2px;font-size:8pt;font-weight:bold;text-decoration:underline;">${escText(principal)}</div><div style="font-size:7.5pt;">Principal / School Head</div></div></div></div><div class="sf9-right"><div class="sf9-sec" style="margin-top:0;border-top:none;">REPORT ON LEARNER'S OBSERVED VALUES</div><table class="sf9-vt"><thead><tr><th style="width:68px;">CORE VALUES</th><th>Behavior Statement</th><th colspan="3">Term</th></tr><tr><th></th><th></th><th style="width:26px;">Term 1</th><th style="width:26px;">Term 2</th><th style="width:26px;">Term 3</th></tr></thead><tbody>${valRows}</tbody></table><table class="sf9-mt"><tr><th style="text-align:center;width:65px;">Marking</th><th>Non-numerical Rating</th></tr><tr><td style="text-align:center;">AO</td><td>Always Observed</td></tr><tr><td style="text-align:center;">SO</td><td>Sometimes Observed</td></tr><tr><td style="text-align:center;">RO</td><td>Rarely Observed</td></tr><tr><td style="text-align:center;">NO</td><td>Not Observed</td></tr></table><div style="margin-top:6px;"><div style="font-size:8pt;font-weight:bold;text-align:center;margin-bottom:3px;">PARENT / GUARDIAN'S SIGNATURE</div><table style="width:100%;font-size:7.5pt;border-collapse:collapse;"><tr><td style="padding:2px 0;">Term 1</td><td style="border-bottom:1px solid #000;width:62%;">&nbsp;</td></tr><tr><td style="padding:2px 0;">Term 2</td><td style="border-bottom:1px solid #000;">&nbsp;</td></tr><tr><td style="padding:2px 0;">Term 3</td><td style="border-bottom:1px solid #000;">&nbsp;</td></tr></table></div><div style="flex:1;min-height:2px;"></div><div style="border-top:1.5px solid #000;padding-top:3px;margin-top:6px;"><div style="font-size:8pt;font-weight:bold;text-align:center;margin-bottom:3px;">CERTIFICATE OF TRANSFER</div><div style="font-size:7pt;display:flex;align-items:flex-end;gap:3px;margin-bottom:2px;"><span style="white-space:nowrap;">Admitted to Grade:</span><span style="border-bottom:1px solid #000;flex:1;">&nbsp;</span><span style="white-space:nowrap;margin-left:4px;">Section:</span><span style="border-bottom:1px solid #000;flex:1;">&nbsp;</span></div><div style="font-size:7pt;display:flex;align-items:flex-end;gap:3px;margin-bottom:2px;"><span style="white-space:nowrap;">Eligibility for Admission to Grade:</span><span style="border-bottom:1px solid #000;flex:1;">&nbsp;</span></div><div style="font-size:7pt;display:flex;align-items:flex-end;gap:3px;margin-bottom:3px;"><span>Approved:</span><span style="border-bottom:1px solid #000;flex:1;">&nbsp;</span></div><div style="display:flex;justify-content:space-between;gap:12px;margin-top:6px;"><div style="flex:1;text-align:center;"><div style="border-top:1.5px solid #000;padding-top:2px;font-size:8pt;font-weight:bold;text-decoration:underline;">${escText(principal)}</div><div style="font-size:7.5pt;">Principal IV</div></div><div style="flex:1;text-align:center;"><div style="border-top:1.5px solid #000;padding-top:2px;font-size:8pt;font-weight:bold;text-decoration:underline;">${adviserName}</div><div style="font-size:7.5pt;">Adviser</div></div></div></div><div style="border-top:1.5px solid #000;padding-top:3px;margin-top:6px;"><div style="font-size:8pt;font-weight:bold;text-align:center;margin-bottom:3px;">CANCELLATION OF ELIGIBILITY TO TRANSFER</div><div style="font-size:7pt;display:flex;align-items:flex-end;gap:3px;margin-bottom:2px;"><span>Admitted in:</span><span style="border-bottom:1px solid #000;flex:1;">&nbsp;</span></div><div style="font-size:7pt;display:flex;align-items:flex-end;gap:3px;margin-bottom:2px;"><span>Date:</span><span style="border-bottom:1px solid #000;flex:1;">&nbsp;</span></div><div style="text-align:right;margin-top:6px;"><div style="display:inline-block;text-align:center;"><div style="border-top:1.5px solid #000;padding-top:2px;font-size:8pt;font-weight:bold;text-decoration:underline;">${escText(principal)}</div><div style="font-size:7.5pt;">Principal IV</div></div></div></div></div></div></div></div>`;
        }
        function buildSHSCard(st, subjects, sec, data, yearLabel, sectionName, adviserName, principal, glName, glCode, quarterLabel) {
            const fullName = escText(st.full_name || ''); const lrn = escText(st.lrn || ''); const age = escText(st.age || ''); const sex = escText(st.sex || ''); const strand = escText(sec.strand || ''); const address = escText(sec.school_address || '');
            const coreSubjects = subjects.filter(s => (s.category || '').toLowerCase().includes('core') || !s.category);
            const appliedSubjects = subjects.filter(s => (s.category || '').toLowerCase().includes('applied'));
            const specializedSubjects = subjects.filter(s => (s.category || '').toLowerCase().includes('specialized'));
            const termRow = (s) => { const t1 = Number(st.quarter_grades?.[s.id]?.['1'] || 0), t2 = Number(st.quarter_grades?.[s.id]?.['2'] || 0), t3 = Number(st.quarter_grades?.[s.id]?.['3'] || 0), fg = Number(st.grades?.[s.id] || 0); const fc = fg > 0 && fg < 75 ? 'fg' : ''; const rem = fg >= 75 ? 'Passed' : fg > 0 ? 'Failed' : ''; return `<tr><td class="sc">${escText(s.subject_name)}</td><td class="nc">${t1 > 0 ? t1 : ''}</td><td class="nc">${t2 > 0 ? t2 : ''}</td><td class="nc">${t3 > 0 ? t3 : ''}</td><td class="nc ${fc}">${fg > 0 ? fg : ''}</td><td>${rem}</td></tr>`; };
            const catBlock = (lbl, subjs) => !subjs.length ? '' : (`<tr class="ch"><td colspan="6" style="padding-left:6px;">${lbl}</td></tr>` + subjs.map(s => termRow(s)).join(''));
            const withGrades = subjects.filter(s => Number(st.grades?.[s.id] || 0) > 0); const generalAvg = withGrades.length ? withGrades.reduce((a, s) => a + Number(st.grades[s.id] || 0), 0) / withGrades.length : 0;
            const avgCls = generalAvg > 0 && generalAvg < 75 ? 'fg' : '';
            return `<div class="rc-page"><div class="shs-wrap"><div style="display:flex;align-items:center;gap:6px;margin-bottom:4px;"><img src="assets/img/deped.png" style="width:50px;height:50px;object-fit:contain;flex-shrink:0;" alt="DepEd"><div style="text-align:center;flex:1;line-height:1.35;"><div style="font-size:8pt;">Republic of the Philippines</div><div style="font-size:8.5pt;font-weight:bold;">Department of Education</div><div style="font-size:8pt;">National Capital Region · Division of Quezon City</div><div style="font-size:10pt;font-weight:bold;text-transform:uppercase;">St. Theresa's School of Novaliches, Inc.</div><div style="font-size:7.5pt;">${address}</div></div><img src="assets/img/stsn logo.png" style="width:50px;height:50px;object-fit:contain;flex-shrink:0;" alt="STSN"></div><div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:0;border-top:1px solid #000;border-bottom:1px solid #000;padding:4px 0;font-size:9pt;"><div><div><span style="font-size:8pt;color:#555;">Name: </span><strong>${fullName}</strong></div><div style="border-bottom:1px solid #000;margin-top:2px;"></div></div><div style="padding-left:8px;"><div><span style="font-size:8pt;color:#555;">Age: </span><strong>${age}</strong></div><div><span style="font-size:8pt;color:#555;">Sex: </span><strong>${sex.toUpperCase()}</strong></div></div><div style="padding-left:8px;"><div><span style="font-size:8pt;color:#555;">LRN: </span><strong>${lrn}</strong></div><div><span style="font-size:8pt;color:#555;">S.Y.: </span><strong>${yearLabel}</strong></div></div></div><div style="font-size:8pt;padding:2px 0;border-bottom:1px solid #000;"><span style="color:#555;">Grade: </span><strong>${glName.replace('Grade ', '')}${strand ? ' – ' + strand : ''}</strong>&nbsp;&nbsp;<span style="color:#555;">Section: </span><strong>${sectionName}</strong>&nbsp;&nbsp;<span style="color:#555;">S.Y.: </span><strong>${yearLabel}</strong></div><div style="text-align:right;padding:2px 0;font-size:8.5pt;border-bottom:1px solid #000;"><strong>${escText(principal)}</strong> — <span style="font-size:8pt;">Principal IV</span></div><div style="text-align:center;font-weight:bold;font-size:9pt;border-bottom:1px solid #000;padding:3px;background:#f0f0f0;text-transform:uppercase;">Report on Learning Progress and Achievement</div><table class="shs-gt"><thead><tr><th class="sc">Subjects</th><th>Term 1</th><th>Term 2</th><th>Term 3</th><th>Final Grade</th><th>Remarks</th></tr></thead><tbody>${catBlock('Core Subjects', coreSubjects)}${catBlock('Applied Subjects', appliedSubjects)}${catBlock('Specialized Subjects', specializedSubjects)}<tr class="ar"><td class="sc" colspan="4">General Average</td><td class="${avgCls}">${generalAvg > 0 ? generalAvg.toFixed(0) : ''}</td><td>${generalAvg >= 75 ? 'Passed' : generalAvg > 0 ? 'Failed' : ''}</td></tr></tbody></table><div style="text-align:right;padding:2px 0;font-size:8.5pt;border-bottom:1px solid #000;"><strong>${adviserName}</strong> — <span style="font-size:8pt;">Adviser</span></div><div style="padding:4px 0;"><div style="font-size:8.5pt;font-weight:bold;text-align:center;margin-bottom:3px;">REPORT ON ATTENDANCE</div><table class="sf9-at"><thead><tr><th></th><th>Sept</th><th>Oct</th><th>Nov</th><th>Dec</th><th>Jan</th><th>Feb</th><th>Mar</th><th>Apr</th><th>May</th><th>Jun</th><th>Total</th></tr></thead><tbody>${attendanceRows(st, [9, 10, 11, 12, 1, 2, 3, 4, 5, 6])}</tbody></table><div style="border-top:1px solid #000;padding-top:6px;margin-top:8px;"><div style="font-size:9pt;font-weight:bold;text-align:center;margin-bottom:4px;">PERFORMANCE DESCRIPTORS</div><table class="shs-gt" style="font-size:8pt;"><thead><tr><th class="sc">Descriptors</th><th>Grading Scale</th><th>Remarks</th></tr></thead><tbody>${(Array.isArray(SF9_DESCRIPTORS) ? SF9_DESCRIPTORS : []).map(d => `<tr><td class="sc">${esc(d.descriptor)}</td><td class="nc">${Number(d.grade_from)}-${Number(d.grade_to)}</td><td class="nc">${esc(d.remarks)}</td></tr>`).join('')}</tbody></table></div></div></div></div>`;
        }

        /* ── Init ── */
        (async function () {
            await loadQuarterFilter();
            await loadSections();
        })();
    </script>
</body>

</html>